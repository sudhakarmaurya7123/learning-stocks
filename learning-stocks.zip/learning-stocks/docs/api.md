# API reference (Phase 9)

Base path `/api`. Every response is `{ data, meta }`; every error is `{ error: { code, message, details? } }`.

## Envelope

```json
{
  "data": { "...": "..." },
  "meta": {
    "data_mode": "MOCK",
    "generated_at": "2026-10-07T05:32:07.794Z",
    "freshness": {
      "as_of": "2026-10-06T03:45:00.000Z",
      "age_seconds": 92835,
      "stale": true,
      "market_open": true
    }
  }
}
```

`freshness` is **market-aware**: `stale` is only ever true while the market is open. Friday's close is not stale on a Sunday — it is the most recent fact there is, and flagging it would make every weekend look like an outage.

`cadence` says which threshold judged `stale`:

| cadence | Applies to                                                        | Fresh while                                                    |
| ------- | ----------------------------------------------------------------- | -------------------------------------------------------------- |
| `quote` | quotes, bars, news                                                | newer than `app_settings.quote_staleness_minutes` (default 20) |
| `daily` | indicators, evaluation, fundamentals, AI analysis, market summary | it covers the most recent **completed** session                |

A daily fact cannot be judged by a duration. Daily bars are stored only after the close plus a 30-minute settle, so mid-session the newest one is the _previous_ session's — over 24 h old at today's open and 72 h old on a Monday. Judging those on the quote threshold reported "stale" on every panel from 09:35 onward while the data was as current as a daily fact can be.

## Authentication

Supabase Auth. Send `Authorization: Bearer <access token>`.

- The backend verifies the JWT (HS256 with `JWT_SECRET` locally, JWKS from `SUPABASE_URL` in the cloud), pinning the algorithm, issuer and audience.
- The **app role comes from `user_profiles`**, never from the token's `role` claim (which is always `authenticated`). A valid token with no profile row gets **403**: a token proves identity, not authorization.
- Phase 1's `handle_new_user()` trigger provisions the row on signup — **the first user to sign up becomes OWNER**, everyone after VIEWER. There is no role-granting CLI; signing up once is the whole setup.
- `/api/health` is public, so a load balancer can reach it.

**Local development without a Supabase user:** set `AUTH_MODE=none` in `.env`. Every request is then treated as OWNER. It is refused when `MOCK_DATA=false`, refused when `HOST` is not loopback, and logs a warning at startup.

## Errors

| Code              | Status | Meaning                                                                        |
| ----------------- | ------ | ------------------------------------------------------------------------------ |
| `VALIDATION`      | 400    | A param, query or body failed its schema. `details.issues` names the field.    |
| `UNAUTHORIZED`    | 401    | No bearer token, or it is invalid/expired.                                     |
| `FORBIDDEN`       | 403    | Authenticated but not permitted (no profile row, or VIEWER on an admin route). |
| `NOT_FOUND`       | 404    | Unknown symbol or route.                                                       |
| `RATE_LIMITED`    | 429    | Per-route limit hit. `Retry-After` says when.                                  |
| `BUDGET_EXCEEDED` | 429    | The daily ₹ LLM budget is spent.                                               |
| `UNSUPPORTED`     | 501    | The feature is switched off by configuration (e.g. `LLM_PROVIDER=none`).       |
| `INTERNAL`        | 500    | A bug. The message is deliberately generic.                                    |

## Reads

All require a token; **none ever calls the LLM** (PRD §14: no page load spends money — enforced by a test that hits every GET route with a provider that throws). Rate limit 120/min per user per route.

| Method | Path                                       | Returns                                                                                                                                                         |
| ------ | ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET    | `/markets`                                 | Index cards with their latest quote                                                                                                                             |
| GET    | `/news?limit=`                             | Market-wide feed: newest articles with their linked stocks and sentiment                                                                                        |
| GET    | `/market-status`                           | Open/closed/holiday and next open, in IST                                                                                                                       |
| GET    | `/market-summary`                          | Latest AI market summary, or `null`                                                                                                                             |
| GET    | `/stocks?query=&sector=&action=`           | Stocks with their latest evaluation, price, valuation, R:R, sentiment and factor scores                                                                         |
| GET    | `/stocks/:symbol`                          | **The aggregate** — 13 sections, below                                                                                                                          |
| GET    | `/stocks/:symbol/quote`                    | Latest quote (30 s cache)                                                                                                                                       |
| GET    | `/stocks/:symbol/history?range=&interval=` | Bars, plus `indicators.sma_20/50/200` aligned one point per bar                                                                                                 |
| GET    | `/stocks/:symbol/technical`                | Latest indicators + the stored technical score                                                                                                                  |
| GET    | `/stocks/:symbol/fundamentals`             | Snapshot + 8 quarterly statements                                                                                                                               |
| GET    | `/stocks/:symbol/evaluation`               | Deterministic scores, levels, action state                                                                                                                      |
| GET    | `/stocks/:symbol/news`                     | Articles with relevance, plus per-article `sentiment`, `impact_level` and `ai_summary`                                                                          |
| GET    | `/stocks/:symbol/sentiment`                | Aggregated news sentiment (30-day window)                                                                                                                       |
| GET    | `/stocks/:symbol/analysis`                 | Latest AI analysis, in full                                                                                                                                     |
| GET    | `/stocks/:symbol/ai-summary`               | The compact card view                                                                                                                                           |
| GET    | `/system-status`                           | PRD §16: providers, last syncs, failures, budget, worker, plus `jobs[]` (one row per job: status, records, duration) and `llm_spend` (today's calls, tokens, ₹) |

**Missing data is a 200 with `null`, never a 500.** A stock nobody has analysed yet renders an empty panel; it does not blank the dashboard.

**`/history` validates `range` against `interval`**, because Yahoo keeps only ~60 days of intraday bars:

| range                  | allowed intervals |
| ---------------------- | ----------------- |
| `1D`                   | `5m`, `15m`       |
| `1W`, `1M`             | `15m`, `1d`       |
| `3M`, `6M`, `1Y`, `5Y` | `1d`              |

`range=5Y&interval=5m` is a 400 rather than a chart that silently covers a different period than its label claims.

`indicators` holds the **stored** moving averages — the same series the decision engine scored, never recomputed per request, so a chart overlay cannot drift away from the decision card. Each series is aligned one point per bar with `value: null` where no indicator row exists (dropping those points would shift the line against the candles), and is **empty for an intraday range**, because a daily SMA has no meaning on a 5-minute axis.

### Citations are snake_case

`sources[]` on `/analysis`, the aggregate and `/qa` carries `as_of`. It was `asOf` — a camelCase key inside an otherwise snake_case payload, because the stored jsonb was passed straight through.

### The aggregate: `GET /stocks/:symbol`

One call, 13 sections, 60 s cache: `stock`, `quote`, `performance`, `technical`, `fundamental`, `valuation`, `decision`, `news`, `sentiment`, `ai_analysis`, `signal`, `market_context`, `data_freshness`.

Every section is independently nullable and resolved in isolation — one broken or empty section never fails the request. `performance` holds trailing returns in percent (`1d`, `1w`, `1m`, `3m`, `1y`), `null` where the history does not reach back (never `0`, which would read as a flat year). `data_freshness` carries the same freshness shape per section.

## Actions

† = OWNER or ADMIN.

| Method | Path                   | Body                       | Limit   |
| ------ | ---------------------- | -------------------------- | ------- |
| POST   | `/sync/market` †       | `{symbols?}`               | 6/hour  |
| POST   | `/sync/news` †         | `{symbols?}`               | 6/hour  |
| POST   | `/sync/fundamentals` † | `{symbols?}`               | 4/day   |
| POST   | `/jobs/:name/run` †    | `{}`                       | 10/hour |
| POST   | `/ai/analyze` †        | `{symbol}`                 | 20/hour |
| POST   | `/ai/regenerate` †     | `{symbol}`                 | 5/hour  |
| POST   | `/stocks/:symbol/qa`   | `{question}` (≤ 500 chars) | 30/hour |

Sync and job routes **enqueue** and return `202`:

```json
{ "data": { "job": "market.sync.eod", "job_id": "80aa27ea-…", "already_queued": false } }
```

`job_id: null` with `already_queued: true` means a run of that job was already queued — the queue working as intended, not a lost request. **Check `worker.status` in `/system-status`**: a 202 promises nothing if no worker is running.

A manual trigger bypasses a **calendar** gate (so a weekend "Sync Market" does something) but never a provider-disabled gate, and never the LLM budget. It does **not** bypass the AI hash cache: only `POST /ai/regenerate` does that, which is why it has the tightest limit.

`/ai/analyze` and `/ai/regenerate` run synchronously — the caller wants the answer. Both still honour the hash, min-interval and budget gates, and an exhausted budget surfaces as `BUDGET_EXCEEDED` (429).

## Not in this phase

`/portfolio` and `/paper-trade/*` arrive in **Phase 11**, alongside the `FeeCalculator` and `PaperTradingService` that make them work. No route in this phase places an order of any kind.
