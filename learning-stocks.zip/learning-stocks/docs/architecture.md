# Architecture

How the backend is organised and the rules every phase follows. Product intent lives in [PRD.md](../PRD.md), and the schema in [database.md](database.md).

## Layers

```
config ─► utils ─► database ─► repositories ─► services ─► container ─► app / routes
 (env)   (errors,   (Kysely,     (row ↔ domain   (calendar,   (composition   (Fastify,
          retry,     generated    mapping,         later:       root)          envelope,
          http,      types)       numeric→number)  providers,                   error handler)
          cache,                                    scoring, AI)
          logger,
          ist)
```

Each layer imports only from the layers to its left. Domain types (`src/domain/`) are shared by every layer and import nothing.

| Path                        | Responsibility                                                                 |
| --------------------------- | ------------------------------------------------------------------------------ |
| `src/config/env.ts`         | Parse and validate env (zod) into a typed `AppConfig`; enforce mock/live rules |
| `src/config/dotenv.ts`      | Load the repo-root `.env` if present                                           |
| `src/utils/errors.ts`       | `AppError` + error taxonomy                                                    |
| `src/utils/retry.ts`        | `withRetry`: exponential backoff with jitter                                   |
| `src/utils/http.ts`         | `fetch` wrapper: timeouts, status → error mapping, URL redaction               |
| `src/utils/cache.ts`        | `Cache` interface + in-memory TTL/LRU with stampede protection                 |
| `src/utils/logger.ts`       | pino with secret redaction                                                     |
| `src/utils/ist.ts`          | IST (fixed +05:30) date/time arithmetic                                        |
| `src/database/`             | Kysely instance, generated `DB` types, numeric conversion                      |
| `src/repositories/`         | One class per aggregate. Accepts a `Database` (or a transaction)               |
| `src/services/`             | Business logic (`MarketCalendarService` today)                                 |
| `src/container.ts`          | **The only place concrete classes are instantiated** (dependency injection)    |
| `src/app.ts`, `src/routes/` | Fastify app, `/api/*` routes                                                   |
| `src/server.ts`             | Process entrypoint: load env → config → container → listen → graceful shutdown |

## Dependency injection

Services receive their dependencies through constructors, typed as interfaces where a substitute is useful (`HolidayLookup`, `Cache`, `MarketDataProvider`, `NewsProvider`, `FundamentalsProvider`, and from Phase 6 `LLMProvider`). A provider set to `none` is `null` in the container, and its service is `null` too. `createContainer(config, overrides)` wires everything. Tests pass overrides (a silent logger, a dead database, an in-memory holiday source) without any mocking framework.

## Errors and retries

| Code               | Meaning                              | Retried | HTTP |
| ------------------ | ------------------------------------ | ------- | ---- |
| `TIMEOUT`          | Upstream did not answer in time      | yes     | 504  |
| `RATE_LIMITED`     | Upstream 429 (honours `Retry-After`) | yes     | 429  |
| `NETWORK`          | Connection failed                    | yes     | 502  |
| `PROVIDER_DOWN`    | Upstream 5xx                         | yes     | 503  |
| `AUTH_FAILED`      | Upstream 401/403 (bad key)           | **no**  | 502  |
| `INVALID_RESPONSE` | Malformed body or unexpected 4xx     | no      | 502  |
| `EMPTY_RESPONSE`   | No body                              | no      | 502  |
| `UNSUPPORTED`      | Provider can't serve this request    | no      | 501  |
| `VALIDATION`       | Bad input from our API caller        | no      | 400  |
| `NOT_FOUND`        | Unknown resource                     | no      | 404  |
| `CONFLICT`         | State conflict                       | no      | 409  |
| `INTERNAL`         | Bug or invariant violation           | no      | 500  |

`withRetry` defaults to 3 attempts with a 500 ms base delay, doubling each time, equal jitter, and an 8 s cap. Unknown (non-`AppError`) errors are never retried: they are bugs, not transient failures. Batch jobs catch errors per instrument, so one failure never aborts the batch (Phase 3+).

## API envelope

```json
{ "data": { … }, "meta": { "data_mode": "MOCK", "generated_at": "2026-10-05T13:56:05.278Z" } }
{ "error": { "code": "NOT_FOUND", "message": "Stock XYZ not found", "details": { … } } }
```

Fields are snake_case. Unexpected errors return `INTERNAL` with a generic message; details go to the log, never to the client. The server binds to `127.0.0.1:4000` by default.

## Logging and secrets

- Logs are structured JSON (pino) with `service`, ISO time and a request ID.
- Secret-bearing keys (`apiKey`, `password`, `token`, `authorization`, `secrets`, `*_API_KEY`, `JWT_SECRET`, …) are redacted as `[REDACTED]`.
- Provider URLs are reduced to origin + path before they reach any error or log, because query strings often carry API keys.
- Secrets live only in the backend environment. The frontend will receive only `NEXT_PUBLIC_*` values.

## Market data providers

All prices enter through `MarketDataProvider` (`src/providers/market/types.ts`): `capabilities()`, `getHistorical(ref, from, to, interval)` and `getQuote(ref)`. `providers/factory.ts` picks the adapter from `MARKET_DATA_PROVIDER`. Nothing else imports a provider SDK.

| Adapter | Source                                                    | Intervals       | Notes                                                                                       |
| ------- | --------------------------------------------------------- | --------------- | ------------------------------------------------------------------------------------------- |
| `mock`  | Deterministic simulator (market + sector + stock factors) | 5m, 15m, 1d     | Synthetic **MOCK** prices; follows the real trading calendar; daily = aggregate of intraday |
| `yahoo` | `yahoo-finance2` (unofficial, delayed)                    | 1m, 5m, 15m, 1d | NSE/BSE listings only; 2 req/s token bucket; lookback 7d (1m) / 59d (5m, 15m)               |

`MarketDataService.sync()` resolves instruments from `provider_symbols`, then per instrument (4 at a time) runs `withRetry` → `normalizeBars` → change vs the previous session's daily close → idempotent insert. Failures are isolated per instrument, and every run writes one `system_logs` row.

**Normalisation (`services/marketData/barNormalizer.ts`):**

| Outcome  | Reason                                                                           | When                                                           |
| -------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------- |
| dropped  | `EMPTY`                                                                          | any OHLC value missing (provider placeholder)                  |
| dropped  | `HOLIDAY_PLACEHOLDER`                                                            | flat (O=H=L=C), zero-volume bar on a non-trading day           |
| dropped  | `INCOMPLETE`                                                                     | intraday bar not yet ended, or daily bar before close + 30 min |
| dropped  | `DUPLICATE_IN_BATCH`                                                             | same normalised timestamp twice in one response (last wins)    |
| rejected | `NON_POSITIVE_PRICE`, `OHLC_INCONSISTENT`, `NEGATIVE_VOLUME`, `FUTURE_TIMESTAMP` | invalid values                                                 |
| rejected | `NOT_A_TRADING_DAY`                                                              | priced bar on a weekend/holiday                                |
| rejected | `OUTSIDE_SESSION`                                                                | intraday bar outside the session window                        |

Daily bars are re-stamped at their IST date's session open, whatever the provider sent. Run status: `SUCCESS`; `PARTIAL` if any instrument failed or any bar was rejected; `FAILED` if nothing succeeded or the timeframe is unsupported. Run counts are in bars: `records_skipped` = duplicates + dropped, `records_failed` = rejected. Instrument failures are in `message` and `error_details.failures`.

## News providers

All news enters through `NewsProvider` (`src/providers/news/types.ts`): `capabilities()` (`maxInstrumentsPerQuery`, latency), `fetchForInstruments({subjects, since, limit})` and `fetchMarketNews({since, limit})`. Both return `{ articles, failures }`, so one dead feed is reported without hiding the others.

| Adapter   | Source                                                                                                           | Notes                                                                                                                              |
| --------- | ---------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| `mock`    | Deterministic per (symbol, IST date)                                                                             | Titles start with `[MOCK]`; qualitative, no numbers; URLs on `mock-news.invalid`                                                   |
| `rss`     | Google News search (`"<company>" when:Nd`, India English) + Economic Times, Mint, Business Standard market feeds | `fast-xml-parser`; 1 req/s; a 401/403 from a feed is reported as "blocked" (`PROVIDER_DOWN`), not a bad key                        |
| `newsapi` | newsapi.org `/v2/everything`                                                                                     | Key in the `x-api-key` header (redacted in logs); 10 companies per query; any rate limit fails fast (free tier = 100 requests/day) |

`NewsService.sync()`: market feeds + one query per group of stocks (2 at a time, `withRetry`) → `normalizeArticles` → store (`NewsRepository.saveArticles` returns the id of each article, new or existing) → `MentionMatcher` → upsert mentions → one `system_logs` row (`fetched` = raw articles, `inserted` = new, `skipped` = already stored + dropped, `failed` = failed queries). Status: `FAILED` if no query succeeded, `PARTIAL` if any query or feed failed.

**Normalisation (`services/news/articleNormalizer.ts`)** never repairs data:

| Dropped              | When                                                                    |
| -------------------- | ----------------------------------------------------------------------- |
| `MISSING_TITLE`      | blank after HTML stripping                                              |
| `INVALID_URL`        | not http(s)                                                             |
| `INVALID_DATE`       | no parseable publish date (never replaced by the fetch time)            |
| `FUTURE_DATE`        | more than 5 minutes ahead                                               |
| `TOO_OLD`            | before the requested window                                             |
| `DUPLICATE_IN_BATCH` | same `content_hash` or same canonical URL as another article in the run |

Text is HTML-stripped and entity-decoded; URLs lose tracking parameters (`utm_*`, `oc`, …) and fragments; a description that only repeats the title (Google News) is dropped; `source` = publisher host.

**Mention matching (`services/news/mentionMatcher.ts`)**, deterministic and explainable:

- Terms per instrument: name (company name minus "Limited"; index name), aliases (`stocks.aliases` / `markets.aliases`), symbol if 3+ characters.
- A term with no lowercase letters (RIL, SBI, L&T, TCS) matches case-sensitively; others ignore case. Unicode letter/number boundaries, so `L&T` works.
- A match followed by a Title Case entity word (`Life`, `Finance`, `Hotels`, `Midcap`, `Infotech`, `Technology Services`, `Funds`, …) names a different, often separately listed entity and is dropped (in all-caps headlines the word is compared ignoring case). Index names followed by 100/200/500 ("Nifty 500") are another index; "Sensex 500-point rally" and "Reliance Industries 500 crore" still count. Tax acronyms are recognised in context: `TDS/TCS` and `ITC claims` are not TCS or ITC. Overlapping matches: the longest wins ("Nifty Bank" beats "Nifty").
- Relevance = field weight (title 1, description 0.75, content 0.6) × kind weight (name 1, alias 0.9, symbol 0.85) + 0.05 per repeat (max 2), capped at 1. `matched_by` records the best kind and field, e.g. `name:title`.
- Roundups (4+ stocks named): a stock not in the title is capped at 0.45. A stock whose own query returned an article that never names it gets 0.4 (`query`). Both sit below `news_relevance_threshold` (0.5), so Phase 7 never spends LLM calls on them.

## Fundamentals providers

`FundamentalsProvider` (`src/providers/fundamentals/types.ts`): `capabilities()` (fields the source can supply), `getSnapshot(ref)` and `getStatements(ref, 'QUARTERLY' | 'ANNUAL')`, both reporting the company's `reportingCurrency`. Units are fixed in `domain/fundamentals.ts` (percent fields as percentages, D/E as a ratio, money in absolute INR).

| Adapter | Notes                                                                                                                                                                                                 |
| ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `mock`  | Deterministic per symbol and internally consistent (TTM = last 4 quarters, a year = its 4 quarters, P/E = mock price / TTM EPS); banks have no D/E or ROCE                                            |
| `yahoo` | `quoteSummary` + `fundamentalsTimeSeries`; fractions → percent, D/E percent → ratio; no ROCE; shares one Yahoo session and the 2 req/s budget with the market adapter; every call has a 10 s deadline |

`FundamentalsService.sync()` (stocks only, 2 at a time): snapshot → if `reportingCurrency ≠ INR`, absolute amounts become null (note) → `fitMetrics` nulls values that would overflow their column (note) → upsert (`as_of` = IST date) → statements per period (skipped when not INR) → upsert → one `system_logs` row. Currency gating and out-of-range values are notes, not failures; a failed stock makes the run `PARTIAL`.

## Analytics engine (Phase 5)

Pure modules (no I/O, time passed in) composed by `scoring/evaluate.ts` (`buildEvaluation`); `services/EvaluationService.ts` gathers inputs from the database, persists the result and logs the run.

| Module                       | Responsibility                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `technical/indicators.ts`    | SMA 20/50/200, EMA 20/50/200, RSI 14, MACD (12,26,9), Bollinger (20,2), ATR 14, ADX 14, Stochastic (fast %K 14, %D 3), volume SMA 20, classic pivots, session VWAP (intraday). Wraps `trading-signals`; a value is `null` until the indicator is stable (EMA would otherwise report from bar 0) and never non-finite. Verified against the StockCharts textbook RSI and reference values computed with `technicalindicators`                                                                       |
| `technical/stats.ts`         | Returns, relative strength, beta and max drawdown, always **joined by IST trading date** (never array index); percentile, piecewise-linear interpolation                                                                                                                                                                                                                                                                                                                                           |
| `technical/trend.ts`         | Trend: UPTREND = close > SMA50 > SMA200 with SMA200 rising over 20 sessions; DOWNTREND = mirror; else SIDEWAYS. Regime: RISK_OFF on a NIFTY 50 downtrend or India VIX ≥ 25; RISK_ON on a NIFTY uptrend with VIX < 20; else NEUTRAL                                                                                                                                                                                                                                                                 |
| `technical/levels.ts`        | Swing pivots (±5 bars, last 250 bars) + SMA50/200 + 52-week high/low clustered within 0.5×ATR into zones. Entry: SMA20–SMA50 band in an uptrend, else [nearest support, +0.5×ATR]. Stop: entry base − 1.5×ATR. Targets: the next **significant** resistance (≥ 2 touches or a structural level) at least 1×ATR above the entry zone, ignoring the 52-week high when price is within 1×ATR of it; else 2R/3R. Size: floor(1% × capital ÷ risk), capped by capital. Any invalid level set → no trade |
| `scoring/ValuationEngine.ts` | P/E vs own history (≥ 250 days; EPS used only from its results date: quarter + 45 days, year + 60 days; current P/E = last close ÷ the EPS in effect that day, so a company whose latest EPS is ≤ 0 has none; own history is dropped when the implied share count (net profit ÷ EPS) changes by more than 25% between reports (bonus, split or merger) or when it disagrees with the provider P/E by > 25%) and vs ≥ 4 sector peers. Percentile ≤ 30 UNDERVALUED, ≥ 70 OVERVALUED                  |
| `scoring/rubrics.ts`         | Every score breakpoint, versioned by `ENGINE_VERSION`                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| `scoring/ScoringEngine.ts`   | Six factors (0–100 or null; missing components dropped), overall = weighted mean of available factors (weights renormalised, `coverage` recorded), separate risk score → risk level                                                                                                                                                                                                                                                                                                                |
| `scoring/DecisionEngine.ts`  | PRD §8.5 rule table (first match wins), bias and paper-signal mapping, invalidation sentence with a computed price (bias language only)                                                                                                                                                                                                                                                                                                                                                            |

**Reproducibility:** `input_hash` covers the engine version, config version and thresholds, and every input; it never includes the wall clock (except the news-decay date when news exists). Changing a rubric means bumping `ENGINE_VERSION`.

**Window:** each instrument's daily history is the last 1830 days **before its last bar** (not before now), so re-running without new data reproduces the same hash.

**Staleness:** if the last daily bar is more than `max_stale_sessions` completed sessions old (calendar-aware), the state is `INSUFFICIENT_DATA` and no levels are stored. Market context (NIFTY 50 trend, India VIX, regime) is computed once per run; sector context once per sector index.

## RAG (Phase 6)

All model access goes through `LLMProvider` (`providers/llm/types.ts`): `MockLLMProvider` (deterministic hashed bag-of-words embeddings; schema-valid structured output from the zod schema or a registered responder) and `OpenAIProvider` (HTTPS via `httpJson`, no SDK; Structured Outputs with a strict JSON Schema generated from zod; the key only in the `authorization` header). `LLM_PROVIDER=none` disables the whole RAG stack.

| Module                             | Responsibility                                                                                                                                                                                                                                                         |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `rag/chunker.ts`                   | ~500-token windows (estimated at 4 chars/token) on word boundaries, 50-token overlap                                                                                                                                                                                   |
| `rag/documents.ts`                 | News text (title + description + content, de-duplicated); deterministic statement summaries (₹ crore, YoY vs the same period a year earlier, unreported fields listed); availability date = period end + 45 / 60 days                                                  |
| `services/rag/EmbeddingService`    | Plans pending work, chunks, **reuses vectors by content hash**, embeds the rest in batches of 64, writes one row per (chunk, target), records every batch in `llm_calls`, logs the run. Auth/unsupported errors abort the remaining batches. Max 500 documents per run |
| `rag/retriever.ts`                 | `match_documents` (scoped by mode, embedding model, stock) → re-rank by similarity × recency × mention relevance → MMR (λ 0.7) → top 8. Query vectors cached 24 h                                                                                                      |
| `rag/contextBuilder.ts`            | ID'd, as-of-stamped blocks Q/P/T/F/R/V/E/M, N1…N8, A1. Values from daily bars are stamped "as of close of session <date>" (bars are stored at the session open); `contextHash` = sha256 of the text                                                                    |
| `rag/citationValidator.ts`         | Rejects any cited ID the builder did not issue (in `source_ids` or inline `[X9]`); flags facts without citations                                                                                                                                                       |
| `services/rag/StockContextService` | Gathers quote, performance, latest evaluation (and its stored inputs), snapshot and retrieved documents, then builds the context                                                                                                                                       |

**Targets.** A news article gets one row per stock mentioned with relevance ≥ `news_relevance_threshold`; with none, one market-level row (`stock_id` null) if an index/VIX mention qualifies; otherwise it is not embedded (weak query-only matches would otherwise flood every stock's context). A stock mention that arrives later adds the missing row and removes the market-level row; the vector is reused.

**Windows.** News: 180 days, 30-day half-life. Financial summaries: 550 days, 365-day half-life, at most 4 candidates (otherwise the latest annual result would drop out for half the year). Market-level news is added only when asked (`includeMarket`) and at most 2 market-level documents reach a stock's results. The stock context retrieves **news only**: the latest quarterly and annual results are added deterministically from the database as structured blocks `R1`/`R2` (never left to similarity ranking, and their numbers count as structured). Financial-summary embeddings remain available for question answering (Phase 7).

**Injection hygiene.** Retrieved text is collapsed, capped at 2000 chars, has `<<<`/`>>>` and bracketed IDs like `[E1]` neutralised, and sits between `BEGIN/END DOCUMENT` markers labelled as data. Numbers for analysis come only from the structured blocks.

**Stable hash.** The context text never includes retrieval scores (they decay with time), so the same data gives the same `contextHash`; Phase 7 gates LLM calls on it.

**Cost.** Every embedding and query-embedding call is an `llm_calls` row (tokens, ₹ estimate from `providers/llm/pricing.ts` × `USD_INR_RATE`). Live mode refuses an embedding model without a price entry. The daily ₹ budget gate arrives in Phase 7.

## AI layer (Phase 7)

**Gateway.** Every chat call goes through `ai/LlmGateway.ts`: budget check (`ai/LlmBudget.ts`, before every attempt) → provider call with retries (transient errors only) → zod schema → extra guards → on failure one repair attempt with the issues fed back → otherwise `INVALID_RESPONSE`. Each attempt writes one `llm_calls` row (`OK`, `INVALID_OUTPUT`, `FAILED`, `BUDGET_EXCEEDED`) with tokens and a ₹ estimate (USD price by longest model-name prefix × `USD_INR_RATE`; usage is kept even when the output is unusable). Embedding batches and query embeddings pass the same budget gate.

**Guards** (`ai/outputGuards.ts`): banned phrases anywhere in the output (PRD §1); every ₹ amount must match a number in the context within 1%; cited IDs (in `source_ids`, `[X1]` or `[X1, Y2]`) must have been issued; sentiment may not contradict the computed bias; market sectors must come from block S1. Confidence is capped at the evaluation's factor coverage.

**Code-owned fields.** Stock analysis: all scores (fundamental = mean of quality and valuation), trend, risk level and recommendation come from the latest evaluation; the computed invalidation is always listed first. Market summary: regime and NIFTY trend from the evaluations' stored market context, risk level from India VIX bands (< 15 LOW, < 20 MEDIUM, < 25 HIGH, else VERY_HIGH). Signals: type (BUY_ZONE → BUY, REDUCE → SELL), prices, R:R and quantity from the evaluation; the model writes only the reasoning, with a deterministic fallback.

**Gates.** `input_hash = sha256(prompt template hash incl. shared rules | context hash | chat model)`, so editing prompt text re-analyses without a version bump. The stock analysis context excludes the previous analysis (A1), otherwise each analysis would change the next hash; Q&A includes it. `FAILED` analyses are stored and replaced by the next attempt with the same inputs; `OK` and `INSUFFICIENT_DATA` rows are never overwritten (except `--force`). Minimum re-analysis interval: `analysis_min_interval_minutes` (0 disables). Sentiment only for mentions ≥ `news_relevance_threshold`.

**Prompts.** `backend/prompts/*_v1.txt` (header, `### SYSTEM`, `### USER`), with `shared_rules_v1.txt` inlined; the file stem is the stored `prompt_version`. Untrusted text (articles, retrieved documents, questions) is sanitised and quoted between BEGIN/END markers.

**MOCK.** `ai/mockResponders.ts` produces deterministic outputs from the prompt (keyword sentiment for news, the computed bias for analyses, the computed regime for the market) that cite only issued IDs and pass every guard.

**Expected churn.** Once news sentiment exists, the evaluation hash includes the IST date (news decay), so evaluations and analyses change once a day even without new bars.

## Jobs (Phase 8)

A pg-boss worker drives every pipeline step on PRD §13's IST schedule. It adds **no business logic**: each handler translates a job payload into a call on a service that already exists.

**The queue stays behind an interface.** `jobs/types.ts` declares `JobQueue` (`start`, `stop`, `ensureQueues`, `enqueue`, `applySchedules`, `work`) and `jobs/PgBossQueue.ts` is the only file in the codebase that imports pg-boss. Phase 9's `POST /sync/*` endpoints return `202 {job_id}` by calling `enqueue`, so no route or service depends on the queue implementation. `enqueue` resolving to `null` means the send was deduplicated — a run is already queued — which is the queue working, not a failure.

**One execution path.** `jobs/runJob.ts` is how every job runs, whether a cron, a chain or `pnpm job` started it:

1. **Gate** (`jobs/gates.ts`) — a refusal is a `SKIPPED` run carrying its reason, and **chains nothing**. A holiday must not trigger an evaluation or an AI call.
2. **Run** — the handler calls its service.
3. **Chain** — follow-ups are enqueued unless the run was `SKIPPED` or `FAILED`. `PARTIAL` still chains, because some instruments did succeed.
4. **Log** — see the logging contract below.

**Chain origins.** `evaluation.compute` is reached from three parents, each with its own singleton key so dedup never collapses one into another:

```
market.sync.intraday ──(origin intraday, key intraday)──┐
market.sync.eod ──────(origin eod,       key eod)───────┼──> evaluation.compute
fundamentals.sync ────(origin fundamentals, …)──────────┘        │
                                                                 └─ ai.stock.analyze ─> signals.generate
                                                                    (ONLY when origin = 'eod')
news.sync ──> embeddings.generate ──> news.sentiment
```

Only the EOD path continues into AI analysis. During the session `ai.stock.analyze` has its own 30-minute cron, so chaining it from every 5-minute intraday tick would bypass that interval and spend the LLM budget twelve times faster for no new information.

**Why `stately` and not `exclusive`.** Measured against pg-boss 12.37.0 with one job held active: `exclusive` **drops** the first follow-up enqueued during the run, `stately` keeps one and drops the rest. The dropped job is the one carrying fresh data, so every queue is `stately` — one active plus one queued.

**Why the intraday gate asks about an interval, not a moment.** The session is `[09:15, 15:30)`, so `isOpen(now)` is already false at 15:30 — and the 15:30 tick is the only one that can collect the 15:25 bar, which is still incomplete at 15:25. `intradayWindowGate` passes when `[now - 5min, now)` overlapped a session, so the last bars of the day are stored and a tick outside the session is skipped. Each run syncs a trailing 30-minute window, so a missed tick heals on the next one.

**Why EOD runs at 16:05 and verifies.** A daily bar is final only at `close + 30 min` = 16:00 IST exactly. A 16:00 run sits on that boundary: a clock a second slow drops the bar as `INCOMPLETE`, the sync still reports SUCCESS, and the chain evaluates yesterday's close while the AI explains it as today's. So EOD runs at 16:05 and then checks that the most recent **settled** session has a stored daily bar. If not, the run is amended to `PARTIAL` and the chain stops. (It asks about the last settled session rather than today's date, so a catch-up run on a Monday morning does not report PARTIAL merely because Monday has not traded yet.)

**The logging contract — exactly one `system_logs` row per run.** Phase 9's `/system-status` reads this table and nothing else, so:

- Handlers pass the **queue name** as the service's `jobName`. The service's own row _is_ the job's row.
- `runJob` writes a row itself only when no service will: a gate SKIP, a job with no service behind it (`signals.expire`, `holidays.check`), or a crash before the service opened its run. That last case matters — a handler that dies while resolving dependencies would otherwise leave no trace at all.
- When a handler **overrides** its service's verdict (EOD finding no settled bar), `runJob` calls `SystemLogRepository.amendRun` to correct the stored row. A status that lives only in memory is invisible to `/system-status`.

**Retries.** Services already retry provider calls internally and return `FAILED`/`PARTIAL` instead of throwing, and `runJob` catches whatever still escapes. So pg-boss's own `retryLimit: 1` is reached only when _logging_ the failure also fails — the database is unreachable — which is exactly when a retry is right. A provider auth failure and an exhausted budget never loop (PRD §17).

**Schedules.** `jobs/schedules.ts` holds the cron table with **exactly one entry per job**, asserted at module load: pg-boss keys schedules on `(name, key)` with `key` defaulting to `''`, so a second entry for one job silently replaces the first. `app_settings.job_schedules` overrides a cron or disables a job with `null`. Daily and weekly jobs use `missed: 'once'` so a deployment window does not skip a day; the frequent ones use `'skip'`. A freshly created schedule does not backfill occurrences from before it existed, so `db:reset` does not make the next start fire a spurious EOD.

**Process model.** `worker.ts` exports `startWorker(container)` and stays importable, so tests start and stop it without a process; `workerMain.ts` is the entrypoint that loads env and installs signal handlers. The worker is a single instance (PRD §18). When Phase 9 gives the API its own `JobQueue`, that instance must be constructed with `schedule: false` and `supervise: false` — the API enqueues and must never run crons or maintenance.

## API (Phase 9)

The request pipeline, in order:

```
helmet -> CORS -> [public: /api/health]
                   └─ authenticated scope:
                        auth (preHandler)   -> request.user from the JWT + user_profiles
                        rate limit (preHandler) -> keyed on request.user.id
                        zod validate        -> params / query / body
                        route handler       -> a service or repository call
                        envelope            -> { data, meta }
```

**Why the limiter runs on `preHandler`.** Measured against `@fastify/rate-limit` 11.2.0: on its default `onRequest` hook the `keyGenerator` runs _before_ auth and sees no user, so every caller shares one IP bucket and PRD §12's per-route limits become meaningless. Registering the limiter with `hook: 'preHandler'`, after the auth hook in the same phase, is what makes the key the user. There is a test with two users on one IP; reverting the hook fails it.

**Why hooks live in a scope.** Fastify encapsulates hooks per plugin scope, so a route registered on the root instance does **not** inherit the auth `preHandler`. `buildApp` registers `/api/health` publicly and everything else inside an authenticated `register` callback; `buildApp(c, { extraRoutes })` exists so tests can add probe routes _inside_ that scope.

**Authorization is the profile row, not the token.** A Supabase token's `role` claim is always `authenticated`. The app role comes from `user_profiles`, cached 30 s. A token that verifies but has no row gets 403 — defaulting it to VIEWER would let anyone who can sign up read the whole desk.

**No GET route may spend money.** `StockAggregateService` reads stored rows only and never touches `StockContextService` or `Retriever`, both of which embed their query and bill for it. `readsNeverSpend.test.ts` builds the app with an LLM provider that throws, hits every registered GET route expecting 200, and asserts zero calls. Its companion derives the route list from Fastify's router, so a new read route that nobody adds to the sweep fails the suite.

**Aggregate sections fail independently.** Each is `T | null`, resolved through a `safe()` wrapper that logs and yields null. That covers both "no rows yet" and "the query errored" — PRD §17 lists both as normal states, and one broken panel must not blank the page. An unavailable performance window is `null`, never `0`, because 0 % reads as a flat year rather than as missing data.

**Caching is TTL-only** (quotes 30 s, aggregates 60 s). PRD §14 says caches are "invalidated on job completion", but the worker and the API are separate processes with their own `MemoryCache`, so the worker cannot reach the API's cache. A TTL is the mechanism that actually runs; a shared Redis behind the existing `Cache` interface would make §14's wording literally true later.

**The API's job queue never runs crons.** `services.jobs` is a `PgBossQueue` built with `schedule: false, supervise: false` — the worker is the single instance that fires schedules (PRD §18) — and it connects lazily on first use. It never calls `work()` or `applySchedules()`.

**Worker liveness is a filtered query, not a row count.** Measured: an API-style instance registers itself in `pgboss.instance` with a live heartbeat, so counting rows would report a worker that does not exist; and a crashed worker leaves its row behind, so presence is not liveness. The query asks for `schedule = true AND stopped_on IS NULL AND heartbeat_on > now() - 120s`, and any failure reports `unknown` rather than taking `/system-status` down. It is a `PgBossQueue` method, deliberately not part of `JobQueue`, so Phase 8's queue fakes still typecheck.

**`/system-status` keys on the service, not the job name.** `last_market_sync` comes from the newest `MarketDataService` row with status SUCCESS or PARTIAL, so a CLI run (`cli.sync-market`) counts and a gate SKIP never does — reporting a market-closed skip as a sync would tell the owner the data is current when nothing was fetched.

**Manual triggers use `manual`, not `force`.** `POST /sync/*` and `POST /jobs/:name/run` send `manual: true`, which `runJob` honours by skipping a **calendar** refusal only. `force` is a different lever: handlers pass it to the AI services where it bypasses the hash cache and min-interval, so only `POST /ai/regenerate` sets it. `GateResult` tags each refusal `calendar` or `availability` — the kind lives on the refusal rather than the gate because `allGates` composes gates of different kinds, but a refusal always comes from exactly one.

## Time

- **Storage:** `timestamptz` in UTC. Postgres `date` columns are read as `YYYY-MM-DD` strings (never `Date`, which would shift by host timezone).
- **Market logic:** Asia/Kolkata, a fixed +05:30 offset (no DST). Regular session `[09:15, 15:30)` IST, Monday–Friday, minus `exchange_holidays`. Holiday rows with `special_open/close` are special sessions (e.g. Muhurat trading).
- **Bars:** `ts` is the bar's **open** time. Daily bars are stamped at the session open.
- **`MarketCalendarService`** is canonical. The SQL functions `is_market_open` / `next_market_open` mirror it, and a parity test runs the same cases through both.

## Numbers

`pg` returns `numeric` and `int8` as strings. Repositories convert them with `toNumber` / `requireNumber` at the boundary, and the generated types keep them as strings so a missing conversion is a type error. INR prices and volumes fit comfortably within JavaScript's exact integer range.

## Testing strategy

| Kind        | Where                       | Notes                                                                               |
| ----------- | --------------------------- | ----------------------------------------------------------------------------------- |
| Unit        | `backend/tests/unit`        | No I/O except a local `node:http` test server for the HTTP client                   |
| Integration | `backend/tests/integration` | Real local Postgres, each test inside a rolled-back transaction, files run serially |
| Database    | `supabase/tests/database`   | pgTAP: constraints, functions, RLS, seeds                                           |

All backend tests run under `TZ=UTC`. Every task's gate is typecheck + tests + lint, because vitest strips types and doesn't check them.
