# Database

Supabase Postgres is the foundation of the platform. The SQL files in `supabase/migrations/` are the schema of record. Application code, generated types and documentation all follow them. The full rationale lives in [PRD.md §7](../PRD.md).

## Running it

```bash
pnpm db:start   # local stack in Docker (first run pulls images)
pnpm db:reset   # drop + reapply all migrations + seeds (supabase/seeds/*.sql, lexical order)
pnpm db:test    # pgTAP suite in supabase/tests/database/
pnpm db:stop
```

Local connection: `postgresql://postgres:postgres@127.0.0.1:54322/postgres`. `pnpm exec supabase status` prints the API URL and keys.

## Conventions

| Concern            | Rule                                                                                                                                                                                                                                         |
| ------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Keys               | `uuid` primary keys (`gen_random_uuid()`)                                                                                                                                                                                                    |
| Time               | `timestamptz`, stored in UTC. Market logic converts to `Asia/Kolkata`                                                                                                                                                                        |
| Money / prices     | `numeric(18,4)`. The `public.price` domain enforces `> 0`                                                                                                                                                                                    |
| Scores             | The `public.score` domain, 0–100 (sentiment: 50 = neutral)                                                                                                                                                                                   |
| Closed sets        | Postgres enums (mirrored in `packages/shared` from Phase 2)                                                                                                                                                                                  |
| Mock vs live       | Every data-bearing table has `data_mode` (`MOCK`/`LIVE`) inside its unique keys. Queries always filter by it                                                                                                                                 |
| Bar timestamps     | `market_data.ts` = the bar's **open** time (UTC instant). Daily bars are stamped at that day's session open (09:15 IST, or the special session's open). Required so `v_latest_quotes` never ranks a daily bar ahead of fresher intraday bars |
| Missing data       | Stored as `NULL` and shown as "unavailable". Never estimated                                                                                                                                                                                 |
| Polymorphic owners | `stock_id` / `market_id` pairs use `CHECK (num_nonnulls(stock_id, market_id) = 1)` plus **partial** unique indexes. A plain `UNIQUE` over nullable columns would not deduplicate                                                             |
| `updated_at`       | Maintained by the `set_updated_at()` trigger                                                                                                                                                                                                 |

## Relationships

```
markets ─< market_data >─ stocks            stocks ─< provider_symbols >─ markets
stocks ─< stock_market_links >─ markets     stocks ─< technical_indicators
stocks ─< fundamental_snapshots, financial_statements
news ─< news_mentions >─ stocks|markets     news ─< news_ai_analysis
document_embeddings → stocks (and polymorphic source_type/source_id)
stocks ─< stock_evaluations ─< stock_ai_analysis ─< ai_trade_signals
markets ─< market_ai_summary                stocks ─< ai_qa_log
auth.users ─ user_profiles ─< paper_accounts ─< paper_positions, paper_orders ─< paper_trades
paper_orders >─ ai_trade_signals (optional)
```

## Migrations

| File                     | Contents                                                                                                                                                                                                            | Key constraints                                                                                                                                                              |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `…0100_extensions_types` | `vector`, `pg_trgm`; 22 enums; `score`, `price` domains                                                                                                                                                             | pgvector ≥ 0.8 required (iterative HNSW scan)                                                                                                                                |
| `…0200_reference`        | `markets`, `stocks`, `provider_symbols`, `stock_market_links`, `exchange_holidays`                                                                                                                                  | `UNIQUE(exchange, symbol)`; Indian ISIN format; verified ISIN must be present; one owner per provider symbol; special sessions need open < close                             |
| `…0300_market_calendar`  | `is_market_open`, `next_market_open`                                                                                                                                                                                | See contracts below                                                                                                                                                          |
| `…0400_market_data`      | `market_data`, `technical_indicators`                                                                                                                                                                               | OHLC consistency; volume ≥ 0; dedupe per (owner, mode, timeframe, ts, source); RSI/ADX/Stoch within 0–100. The bar-size column is `timeframe` (`interval` is an SQL keyword) |
| `…0500_fundamentals`     | `fundamental_snapshots`, `financial_statements`                                                                                                                                                                     | One snapshot per (stock, mode, day, source); one statement per period. All metrics nullable                                                                                  |
| `…0600_news_rag`         | `news`, `news_mentions`, `news_ai_analysis`, `document_embeddings` (`vector(1536)`, HNSW cosine), `match_documents`                                                                                                 | `content_hash` (sha256) and `source_url` unique per mode; one AI analysis per (news, stock, prompt version), NULL stock included                                             |
| `…0700_config_ops`       | `app_settings`, `scoring_configs`, `system_logs`, `llm_calls`                                                                                                                                                       | At most one active scoring config                                                                                                                                            |
| `…0800_evaluation_ai`    | `stock_evaluations`, `stock_ai_analysis`, `market_ai_summary`, `ai_trade_signals`, `ai_qa_log`                                                                                                                      | `input_hash` uniqueness is the main LLM-cost guard: identical inputs are never re-analysed. `entry_low ≤ entry_high`                                                         |
| `…0900_paper_trading`    | `user_profiles`, `paper_fee_schedules`, `paper_accounts`, `paper_positions`, `paper_orders`, `paper_trades`, `handle_new_user`, `execute_paper_order`                                                               | Cash ≥ 0; qty > 0; one position per (account, stock); REJECTED ⇔ reject reason; one active fee schedule                                                                      |
| `…1000_views_security`   | `v_latest_quotes`, `v_latest_stock_evaluation`, `v_latest_stock_ai_analysis`; RLS + privilege lockdown                                                                                                              | See security model                                                                                                                                                           |
| `…1100_review_hardening` | Fixes from the Phase 1 review: global EXECUTE-default revoke; index-backed `v_latest_quotes` (LATERAL, one bar per instrument); exact stock-filtered `match_documents`; price/fee rounding in `execute_paper_order` | Latest-quote ties break on timeframe, then source                                                                                                                            |

## Function contracts

**`is_market_open(exchange, ts) → boolean`.** True when `ts` (converted to IST) falls in `[09:15, 15:30)` on a weekday that is not in `exchange_holidays` for that exchange. A holiday row with `special_open/special_close` is a special session (e.g. Muhurat trading) and is open only inside that window, even on a weekend. The holiday is matched on the **IST** date. The TypeScript `MarketCalendarService` (Phase 2) is canonical and must agree with this function on every case in `03_market_calendar.test.sql`.

**`next_market_open(exchange, ts) → timestamptz`.** The first session start strictly after `ts`, searching 30 days ahead. Returns `NULL` if none is found.

**`match_documents(query_embedding, data_mode, stock_id?, since?, k = 8, source_types?) → (id, source_type, source_id, stock_id, content, metadata, published_at, similarity)`.** Cosine search, most similar first, always filtered by `data_mode`. With `stock_id` it does an **exact** scan of that stock's documents (small corpus), so it always returns `k` rows when that many exist. Without `stock_id` it uses the HNSW index with `iterative_scan = strict_order`. That path is approximate and stops after `hnsw.max_scan_tuples`, so a selective `since`/`source_types` filter on a very large corpus can return fewer than `k`. The Phase 6 retriever must treat a short result as possible.

**`execute_paper_order(account_id, stock_id, side, quantity, price, fees = 0, source = 'MANUAL', signal_id?, price_as_of = now()) → paper_orders`.** A single transaction that row-locks the account and position.

- Quantity ≤ 0, price ≤ 0 or fees < 0 raise SQLSTATE `22023`. An unknown account raises `P0002`.
- **BUY:** if `qty × price + fees > available_cash`, the order is stored as `REJECTED / INSUFFICIENT_FUNDS` and nothing else changes. Otherwise it writes the order, the trade, and the position (average cost **includes buy fees**), and debits cash.
- **SELL** (long-only): if qty exceeds holdings, the order is stored as `REJECTED / INSUFFICIENT_QUANTITY`. Otherwise realised P&L = `(price − avg cost) × qty − fees`, cash is credited, and a fully exited position is deleted, so re-entry starts a fresh average.
- Market-hours, stale-price and fee calculation are the caller's job (`PaperTradingService`, Phase 11).

**`handle_new_user()` trigger on `auth.users`.** Creates a `user_profiles` row (the first user becomes `OWNER`, later ones `VIEWER`) and one `MOCK` plus one `LIVE` paper account funded from `app_settings.paper_initial_balance` (₹10,00,000).

## Security model

- RLS is enabled on every `public` table, with no policies.
- `anon` and `authenticated` have **no** privileges on tables, sequences, views or functions. Default privileges extend this to future tables, sequences and functions created by the migration role (`postgres`). This includes revoking PostgreSQL's global EXECUTE-to-PUBLIC default, which a per-schema rule cannot remove. Objects created by `supabase_admin` are not covered. `11_hardening.test.sql` checks that a newly created function is not executable by browser roles. The browser therefore cannot read or write data directly; the only thing it uses Supabase for is login.
- The backend and worker connect with the privileged `DATABASE_URL` role. Authorization (OWNER/ADMIN for admin actions) is enforced in the API layer (Phase 9).
- `handle_new_user` is `security definer`, so sign-up provisioning works under the auth service role. This was verified with a real sign-up against local GoTrue.

## News and fundamentals (Phase 4)

| Table                   | Write rule                                                                                                                                                                                                                                                                                       |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `news`                  | Insert-only. Deduplicated by `content_hash` **and** by `source_url` (per `data_mode`). `content_hash = sha256(normalised title \| publisher host \| IST publish date)`; `source` is the publisher host (e.g. `business-standard.com`) so a Google News copy and the publisher's own copy collide |
| `news_mentions`         | Upsert: an existing mention keeps the **higher** `relevance_score` (and its `matched_by`)                                                                                                                                                                                                        |
| `fundamental_snapshots` | Upsert: one row per stock per IST day per source; a same-day re-run refreshes it                                                                                                                                                                                                                 |
| `financial_statements`  | Upsert per `(stock, mode, period_type, period_end, source)`: companies restate results                                                                                                                                                                                                           |

`stocks.aliases` / `markets.aliases` (`text[]`, never null, no empty strings) hold extra names for mention matching.

**Fundamentals units** (as stored; the decision engine reads them this way):

| Columns                                                                                                      | Unit                                   |
| ------------------------------------------------------------------------------------------------------------ | -------------------------------------- |
| `roe`, `roce`, `dividend_yield`, `operating_margin`, `net_margin`, `revenue_growth_yoy`, `profit_growth_yoy` | percent: `13.8` = 13.8 %               |
| `debt_to_equity`                                                                                             | ratio: `0.46` = debt is 46 % of equity |
| `market_cap`, `free_cash_flow`, `revenue_ttm`, `net_profit_ttm`, statement amounts                           | absolute INR                           |
| `eps_ttm`, `book_value_per_share`, `eps`                                                                     | INR per share                          |
| `capex`                                                                                                      | as reported: an outflow is negative    |

`NULL` = unavailable from the source. Absolute amounts are stored only when the company reports in INR. A value that would overflow its column is stored as `NULL` with a note in the run log.

## Analytics (Phase 5)

| Table                  | Write rule                                                                                                                                                                                                                                                                                                             |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `technical_indicators` | Upsert of the full daily series per stock on every evaluation run (self-healing). Values stay `NULL` until the indicator has enough history. `pivots` = classic floor pivots (P, R1, S1, R2, S2) from the previous bar                                                                                                 |
| `stock_evaluations`    | One row per `(stock, data_mode, input_hash)`. `input_hash` = sha256 of canonical JSON of `inputs` (engine version, config version + thresholds, last bar, indicators, fundamentals, valuation, peers, news, position flag, factor components). Unchanged inputs create no row. `evaluated_at` uses `clock_timestamp()` |
| `scoring_configs`      | Exactly one active. `thresholds` keys added after v1 have code defaults: `vix_risk_on_max` 20, `vix_risk_off_min` 25, `weak_quality_max` 40, `max_stale_sessions` 3                                                                                                                                                    |

`stock_evaluations.factors_available` records which factors had data plus `coverage` (share of weight available). Levels (entry, stop, targets, R:R, size) are `NULL` for `INSUFFICIENT_DATA` and when no valid trade could be built.

## Retrieval (Phase 6)

Migration `…20261006000100_rag_retrieval`:

- `document_embeddings` unique key is now `(source_type, source_id, chunk_index, embedding_model, stock_id)` with `NULLS NOT DISTINCT`: an article mentioning several stocks has one row per stock (same vector), plus at most one market-level row (`stock_id` null).
- `document_embeddings_hash_idx (data_mode, embedding_model, content_hash)` serves vector reuse: the same text is never embedded twice.
- `match_documents(...)` gained two trailing optional parameters: `p_embedding_model` (only that model's vectors) and `p_market_only` (only `stock_id IS NULL`; mutually exclusive with `p_stock_id`, error `22023`). Old positional calls still work. Execute is revoked from browser roles.
- Apply with `pnpm db:migrate` (`supabase migration up`), which keeps existing data. The migration loads pgvector first because `migration up` runs as a non-superuser.

`llm_calls` now receives a row per embedding batch (`purpose = 'embeddings'`) and per uncached query embedding (`'query_embedding'`).

## AI outputs (Phase 7)

No migration; the Phase 1 tables are written as follows.

| Table               | Write rule                                                                                                                                                                                      |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `news_ai_analysis`  | One row per `(news, stock or NULL = market, prompt_version)`; only for mentions ≥ `news_relevance_threshold` (market-level only when no stock mention qualifies). Feeds the Phase 5 news factor |
| `stock_ai_analysis` | One row per `(stock, mode, input_hash, prompt_version)`. Status `OK`, `INSUFFICIENT_DATA` (no model call; `model = 'none'`) or `FAILED`. A `FAILED` row is overwritten by the next attempt      |
| `market_ai_summary` | One row per input hash for NIFTY 50; regime, trend and risk level are code-owned                                                                                                                |
| `ai_trade_signals`  | BUY/SELL only, one ACTIVE per evaluation; `INVALIDATED` when a newer evaluation exists, `EXPIRED` after `valid_until` (close of the next session). Never creates orders                         |
| `ai_qa_log`         | Q&A cache keyed by `(stock, mode, normalised question hash, context hash, prompt_version)`; `user_id` is null until the API adds auth (Phase 9)                                                 |
| `llm_calls`         | One row per attempt. `purpose`: news_sentiment, stock_analysis, market_summary, trade_signal, stock_qa, embeddings, query_embedding. `status`: OK, INVALID_OUTPUT, FAILED, BUDGET_EXCEEDED      |

The daily budget sums `llm_calls.est_cost_inr` from IST midnight against `app_settings.llm_daily_budget_inr`.

## Job queue (Phase 8)

The pg-boss job queue lives in its **own `pgboss` schema** (`WORKER_QUEUE_SCHEMA`), and it is deliberately **not** part of our migrations:

- pg-boss owns and versions that schema itself (`schemaVersion()` reports 45 for 12.37.x). Putting it in `supabase/migrations/` would mean maintaining someone else's DDL by hand.
- `pnpm db:reset` drops it along with everything else. The worker recreates it on start (`migrate: true, createSchema: true`), so a reset needs no extra step.
- No pgTAP test asserts over it — our tests name tables explicitly rather than iterating schemas, so the queue's presence or absence never changes `pnpm db:test`.
- A freshly created schedule does not backfill occurrences from before it existed, so a reset does not make the next worker start fire a spurious EOD or daily summary.

What jobs write into **our** schema is ordinary data: `system_logs` gets exactly one row per run (see "Jobs (Phase 8)" in [architecture.md](architecture.md)), and the handlers write through the same services and repositories as the CLIs. `app_settings.job_schedules`, if present, overrides the cron table: a JSON object of job name → cron string, with `null` disabling a job.

Integration tests that touch the queue each use a throwaway schema (`pgboss_test_*`) and drop it afterwards, so they never disturb a worker running locally.

## Seed data and its provenance

| Seed file                   | Source                                                                                                                                                                                                                                  |
| --------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `01_markets.sql`            | 10 indices from the brief + NIFTY ENERGY (sector context for RELIANCE) + INDIA VIX                                                                                                                                                      |
| `02_stocks.sql`             | 20 NSE listings with sector/industry (typed from NSE classification; **owner verification pending**)                                                                                                                                    |
| `03_stock_isins.sql`        | **Generated** by `scripts/nse/isin-lookup.mjs` from NSE's official `EQUITY_L.csv`. Sets ISIN, official company name and `isin_verified`                                                                                                 |
| `04_provider_symbols.sql`   | `mock` = internal symbol (verified). `yahoo` = `SYMBOL.NS` / index tickers, **unverified until Phase 3's live lookup**                                                                                                                  |
| `05_stock_market_links.sql` | Every stock → NIFTY 50 benchmark, plus sector indices where one exists                                                                                                                                                                  |
| `06_holidays_2026.sql`      | **Generated** by `scripts/nse/holidays-to-sql.mjs` from NSE's holiday-master API (capital-market segment), applied to NSE and BSE. Muhurat sessions are added as special sessions once the exchange publishes timings                   |
| `08_aliases.sql`            | Alternative names for news matching (`RIL`, `L&T`, `SBI`, `Bank Nifty`, …). Hand-written; **owner verification pending**. Precision beats recall: a wrong alias attaches unrelated news. Acronyms (no lowercase) match case-sensitively |
| `07_config.sql`             | Scoring config `v1` (weights 30/10/10/20/15/15), app settings, fee schedules: `zero` (active) and `india_delivery_estimate` (inactive until verified against a broker contract note)                                                    |

To regenerate the NSE-derived files, see the usage lines at the top of each script. Files go in `.cache/nse/` (git-ignored).

## Adding a stock (no code change)

1. Insert into `stocks` (symbol, company_name, exchange, sector, industry). Add its ISIN via the lookup script.
2. Insert `provider_symbols` rows for each provider (`mock`, `yahoo`, …).
3. Insert `stock_market_links` (a `BENCHMARK` row, plus `SECTOR_INDEX` if applicable).

## Tests

`supabase/tests/database/` holds one pgTAP file per migration area: foundation, reference, market calendar, market data, fundamentals, news/RAG, evaluation/AI, paper trading, security and seed. Each runs inside a transaction and rolls back.
