# Phase 2: Backend Foundation — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (Native, as chosen for Phase 1) or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

## Context

Phase 1 (database) is merged into `main`: 12 migrations, seeds and 113 passing pgTAP tests. Phase 2 builds the **backend foundation** that every later phase plugs into:
- a typed, validated config
- structured logging with secret redaction
- the error taxonomy and retry policy from PRD §6.4
- an HTTP client with timeouts
- a cache
- a typed Kysely database layer with repositories
- the canonical TypeScript `MarketCalendarService`
- a DI container
- a Fastify app exposing `GET /api/health` in the PRD §12 envelope

There are no providers, AI or UI yet (Phases 3+).

Outcome: `pnpm dev` starts the API in mock mode with an empty `.env`, `curl http://127.0.0.1:4000/api/health` reports DB, providers and NSE market status, and `pnpm test` (TZ=UTC) is green.

**Goal:** A tested backend skeleton (config, logging, errors, retry, HTTP, cache, DB, repositories, market calendar, DI, health API) ready for provider work in Phase 3.

**Architecture:** `backend/` pnpm workspace package, ESM + TypeScript (NodeNext). Layers: `config → utils → database → repositories → services → container → app/routes`. Each layer depends only on the ones before it. Repositories accept a `Kysely` instance (or a transaction), map DB rows to domain types, and convert `numeric`/`bigint` strings to numbers explicitly. Integration tests run against the local Supabase DB inside rolled-back transactions.

**Tech Stack (pinned, APIs verified in a scratch install):** fastify 5.12.5, kysely 0.29.6, kysely-codegen 0.20.0, pg 8.23.1, zod 4.6.5 (`z.stringbool`, `z.prettifyError`), pino 10.4.0 (`redact`), vitest 5.0.3, tsx 4.23.15, @types/node 22, @types/pg 8.23.1. TypeScript ~6.0 (root).

**Spec:** `PRD.md` (repo root) §4, §5, §6.4, §12 (envelope), §15, §16. Phase 1 contracts: `docs/database.md`.

## Deviations from the approved Phase 2 outline (need your OK)

1. **`packages/shared` is deferred to Phase 9/10.** Nothing outside `backend/` consumes types yet, and a cross-package TS build adds friction now. Enums live in `backend/src/domain/enums.ts`, with an integration test asserting they match the Postgres enums exactly.
2. **Repositories are created in the phase that first uses them.** Phase 2 builds the six that are needed now: Stock, Market, Holiday, AppSettings, MarketData and SystemLog. News, Embedding, Evaluation, AIAnalysis, PaperTrade, Portfolio, Technical and Fundamentals arrive with Phases 4–11.
3. **Bar timestamp convention is decided here** (the Phase 1 review asked for this before Phase 3): `ts` = the bar's **open** time as a UTC instant. Daily bars are stamped at that day's session open (09:15 IST, or a special session's open).

## Global Constraints

- Node ≥ 22.9 (uses `process.loadEnvFile`), pnpm 11, TypeScript `~6.0`. ESM with `.js` import suffixes (NodeNext).
- `tsconfig.base.json` strictness (`noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`) applies. No `any`, and no non-null assertions (`!`) in `src/`.
- **Every task's gate:** `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`. Vitest strips types, so typecheck is mandatory.
- Tests always run with `TZ=UTC` (set in the `test` script) so host-timezone bugs surface on an IST laptop.
- Postgres `date` (OID 1082) is returned as a `YYYY-MM-DD` string. `numeric`/`int8` stay strings in generated types and are converted to `number` in repositories.
- Market time: Asia/Kolkata, fixed +05:30 (no DST). Regular session `[09:15, 15:30)`. `MarketCalendarService` must agree with SQL `is_market_open`/`next_market_open` on every shared case.
- Mock vs live: `MOCK_DATA=true` forces every provider to `mock` and `data_mode=MOCK`. With `MOCK_DATA=false`, any provider set to `mock` is a startup error.
- Secrets never appear in logs, error details or API responses. Provider URLs are logged without query strings.
- API responses use `{ data, meta: { data_mode, generated_at } }`, and errors use `{ error: { code, message, details? } }`. Fields are snake_case.
- The server binds to `127.0.0.1:4000` by default.
- Commits end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`. Work happens on branch `phase-2-backend`.

## Review Focus

1. **Host timezone ≠ IST:** on a UTC server, holiday dates must not shift by a day and calendar answers must not change. Covered by the `TZ=UTC` test script, the Task 5 date-parser test and the Task 8 parity tests.
2. **`.env` with blank values** (`OPENAI_API_KEY=`) and a fresh clone with no `.env`: must start in mock mode with no error. Covered in Task 1.
3. **Live mode with a leftover mock provider:** must refuse to start, otherwise mock data would be stored as LIVE. Covered in Task 1.
4. **Provider URL with an API key in its query string:** the key must not appear in the thrown error, logs or response. Covered in Task 3.
5. **Database down:** `/api/health` answers quickly with 503 `degraded` (no hang, no crash) and still reports config. Covered in Task 9.
6. **Year boundary:** `nextOpen` from 31 Dec after close finds the next year's first session. Covered in Task 8.

## File structure

```
backend/
├── package.json  tsconfig.json  tsconfig.build.json  vitest.config.ts
├── src/
│   ├── config/{env.ts, dotenv.ts}
│   ├── utils/{errors.ts, retry.ts, http.ts, cache.ts, logger.ts, ist.ts}
│   ├── domain/{enums.ts, types.ts}
│   ├── database/{db.ts, convert.ts, types.generated.ts}
│   ├── repositories/{StockRepository.ts, MarketRepository.ts, HolidayRepository.ts,
│   │                 AppSettingsRepository.ts, MarketDataRepository.ts, SystemLogRepository.ts}
│   ├── services/MarketCalendarService.ts
│   ├── http/{envelope.ts, errorHandler.ts}
│   ├── routes/health.ts
│   ├── container.ts  app.ts  server.ts
└── tests/
    ├── fixtures/calendarCases.ts
    ├── unit/*.test.ts
    └── integration/{globalSetup.ts, helpers.ts, *.test.ts}
```

---

### Task 1: Backend package scaffold + validated config

**Files:**
- Create: `backend/package.json`, `backend/tsconfig.json`, `backend/tsconfig.build.json`, `backend/vitest.config.ts`, `backend/src/config/env.ts`, `backend/src/config/dotenv.ts`
- Modify: `.env.example` (comments on their own lines), root `package.json` (`dev` script)
- Test: `backend/tests/unit/config.test.ts`, `backend/tests/unit/dotenv.test.ts`

**Interfaces:**
- Produces: `loadConfig(env: Record<string, string | undefined>): AppConfig` (throws `ConfigError`); `AppConfig` (below); `loadDotEnv(path?: string): boolean`; `REPO_ROOT: string`.

- [ ] **Step 1: Branch and scaffold the package**

```bash
git checkout -b phase-2-backend
mkdir -p backend/src/config backend/tests/unit backend/tests/integration backend/tests/fixtures
```
`backend/package.json`:
```json
{
  "name": "@learning-stocks/backend",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "tsx watch src/server.ts",
    "build": "tsc -p tsconfig.build.json",
    "start": "node dist/server.js",
    "typecheck": "tsc -p tsconfig.json --noEmit",
    "test": "TZ=UTC vitest run",
    "test:unit": "TZ=UTC vitest run --project unit",
    "db:types": "kysely-codegen --dialect postgres --url postgresql://postgres:postgres@127.0.0.1:54322/postgres --include-pattern 'public.*' --date-parser string --numeric-parser string --out-file src/database/types.generated.ts"
  }
}
```
Install:
```bash
pnpm --filter @learning-stocks/backend add fastify@5.12.5 kysely@0.29.6 pg@8.23.1 zod@4.6.5 pino@10.4.0
pnpm --filter @learning-stocks/backend add -D vitest@5.0.3 tsx@4.23.15 kysely-codegen@0.20.0 @types/pg@8.23.1 @types/node@22 pino-pretty@13.2.0
```
`backend/tsconfig.json`:
```json
{
  "extends": "../tsconfig.base.json",
  "compilerOptions": { "types": ["node"], "noEmit": true },
  "include": ["src", "tests", "vitest.config.ts"]
}
```
`backend/tsconfig.build.json`:
```json
{
  "extends": "./tsconfig.json",
  "compilerOptions": { "noEmit": false, "rootDir": "src", "outDir": "dist" },
  "include": ["src"]
}
```
`backend/vitest.config.ts` (`projects` with `extends: true` is the vitest ≥3.2 API; if vitest 5 rejects it, record a ruling and use two config files):
```ts
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    testTimeout: 15_000,
    projects: [
      { extends: true, test: { name: 'unit', include: ['tests/unit/**/*.test.ts'] } },
      {
        extends: true,
        test: {
          name: 'integration',
          include: ['tests/integration/**/*.test.ts'],
          globalSetup: ['tests/integration/globalSetup.ts'],
          fileParallelism: false,
        },
      },
    ],
  },
});
```
Root `package.json` scripts: add `"dev": "pnpm --filter @learning-stocks/backend dev"`.
Rewrite `.env.example` so every comment sits on its own line, because inline `# …` after a value is not reliably stripped by Node's env-file parser. Keep the same keys, and add `HOST=127.0.0.1` and `FUNDAMENTALS_PROVIDER=mock`.

- [ ] **Step 2: Write the failing tests** `backend/tests/unit/config.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { ConfigError, loadConfig } from '../../src/config/env.js';

const DB = { DATABASE_URL: 'postgresql://postgres:postgres@127.0.0.1:54322/postgres' };

describe('loadConfig', () => {
  it('starts in mock mode with only DATABASE_URL set', () => {
    const c = loadConfig({ ...DB });
    expect(c.dataMode).toBe('MOCK');
    expect(c.providers).toEqual({ marketData: 'mock', news: 'mock', fundamentals: 'mock', llm: 'mock' });
    expect(c.host).toBe('127.0.0.1');
    expect(c.port).toBe(4000);
    expect(c.autoPaperTrade).toBe(false);
  });

  it('treats blank values as unset', () => {
    const c = loadConfig({ ...DB, OPENAI_API_KEY: '', PORT: '', MOCK_DATA: '' });
    expect(c.secrets.openaiApiKey).toBeNull();
    expect(c.port).toBe(4000);
    expect(c.dataMode).toBe('MOCK');
  });

  it('forces every provider to mock when MOCK_DATA=true', () => {
    const c = loadConfig({ ...DB, MOCK_DATA: 'true', MARKET_DATA_PROVIDER: 'yahoo', LLM_PROVIDER: 'openai' });
    expect(c.providers.marketData).toBe('mock');
    expect(c.providers.llm).toBe('mock');
  });

  it('refuses live mode with a mock provider (would label mock data LIVE)', () => {
    expect(() =>
      loadConfig({ ...DB, MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo', NEWS_PROVIDER: 'rss', FUNDAMENTALS_PROVIDER: 'mock', LLM_PROVIDER: 'mock' }),
    ).toThrow(/FUNDAMENTALS_PROVIDER=mock requires MOCK_DATA=true/);
  });

  it('requires OPENAI_API_KEY and LLM_MODEL only when the OpenAI provider is selected', () => {
    const live = { ...DB, MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo', NEWS_PROVIDER: 'rss', FUNDAMENTALS_PROVIDER: 'yahoo', LLM_PROVIDER: 'openai' };
    expect(() => loadConfig(live)).toThrow(/OPENAI_API_KEY/);
    const c = loadConfig({ ...live, OPENAI_API_KEY: 'sk-test', LLM_MODEL: 'some-model' });
    expect(c.dataMode).toBe('LIVE');
    expect(c.providers).toEqual({ marketData: 'yahoo', news: 'rss', fundamentals: 'yahoo', llm: 'openai' });
  });

  it('requires NEWS_API_KEY only for the newsapi provider', () => {
    const live = { ...DB, MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo', NEWS_PROVIDER: 'newsapi', FUNDAMENTALS_PROVIDER: 'yahoo', LLM_PROVIDER: 'openai', OPENAI_API_KEY: 'k', LLM_MODEL: 'm' };
    expect(() => loadConfig(live)).toThrow(/NEWS_API_KEY/);
  });

  it('rejects an embedding dimension that does not match the vector(1536) column', () => {
    expect(() => loadConfig({ ...DB, EMBEDDING_DIMENSIONS: '768' })).toThrow(/EMBEDDING_DIMENSIONS/);
  });

  it('reports invalid and missing values readably', () => {
    expect(() => loadConfig({ ...DB, PORT: 'abc' })).toThrow(ConfigError);
    expect(() => loadConfig({ ...DB, PORT: 'abc' })).toThrow(/PORT/);
    expect(() => loadConfig({})).toThrow(/DATABASE_URL/);
  });
});
```
`backend/tests/unit/dotenv.test.ts`:
```ts
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { loadDotEnv } from '../../src/config/dotenv.js';

describe('loadDotEnv', () => {
  afterEach(() => {
    delete process.env.LS_DOTENV_PROBE;
  });

  it('returns false when the file does not exist (fresh clone)', () => {
    expect(loadDotEnv(join(tmpdir(), 'definitely-missing.env'))).toBe(false);
  });

  it('loads variables from the given file', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ls-env-'));
    const file = join(dir, '.env');
    writeFileSync(file, '# comment line\nLS_DOTENV_PROBE=hello\n');
    expect(loadDotEnv(file)).toBe(true);
    expect(process.env.LS_DOTENV_PROBE).toBe('hello');
  });
});
```

- [ ] **Step 3: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL. Cannot find module `../../src/config/env.js` / `dotenv.js`.

- [ ] **Step 4: Implement** `backend/src/config/env.ts`

```ts
import { z } from 'zod';

export class ConfigError extends Error {
  override readonly name = 'ConfigError';
}

const flag = z.stringbool();

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  HOST: z.string().min(1).default('127.0.0.1'),
  PORT: z.coerce.number().int().min(1).max(65_535).default(4000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  DATABASE_URL: z.string().regex(/^postgres(ql)?:\/\//, 'must be a postgres:// URL'),
  SUPABASE_URL: z.url().optional(),
  SUPABASE_ANON_KEY: z.string().optional(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().optional(),
  JWT_SECRET: z.string().optional(),
  MOCK_DATA: flag.default(true),
  MARKET_DATA_PROVIDER: z.enum(['mock', 'yahoo']).default('mock'),
  NEWS_PROVIDER: z.enum(['mock', 'rss', 'newsapi']).default('mock'),
  FUNDAMENTALS_PROVIDER: z.enum(['mock', 'yahoo']).default('mock'),
  LLM_PROVIDER: z.enum(['mock', 'openai']).default('mock'),
  NEWS_API_KEY: z.string().optional(),
  OPENAI_API_KEY: z.string().optional(),
  LLM_MODEL: z.string().optional(),
  EMBEDDING_MODEL: z.string().default('text-embedding-3-small'),
  EMBEDDING_DIMENSIONS: z.coerce.number().int().refine((d) => d === 1536, {
    message: 'must be 1536 to match document_embeddings.embedding vector(1536)',
  }).default(1536),
  LLM_DAILY_BUDGET_INR: z.coerce.number().nonnegative().default(100),
  AUTO_PAPER_TRADE: flag.default(false),
});

type Env = z.infer<typeof EnvSchema>;

export interface AppConfig {
  env: Env['NODE_ENV'];
  host: string;
  port: number;
  logLevel: Env['LOG_LEVEL'];
  databaseUrl: string;
  dataMode: 'MOCK' | 'LIVE';
  providers: {
    marketData: Env['MARKET_DATA_PROVIDER'];
    news: Env['NEWS_PROVIDER'];
    fundamentals: Env['FUNDAMENTALS_PROVIDER'];
    llm: Env['LLM_PROVIDER'];
  };
  supabase: { url: string | null; anonKey: string | null };
  secrets: {
    openaiApiKey: string | null;
    newsApiKey: string | null;
    supabaseServiceRoleKey: string | null;
    jwtSecret: string | null;
  };
  llm: { model: string | null; embeddingModel: string; embeddingDimensions: number; dailyBudgetInr: number };
  autoPaperTrade: boolean;
}

function withoutBlanks(env: Record<string, string | undefined>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(env)) {
    if (value !== undefined && value.trim() !== '') out[key] = value.trim();
  }
  return out;
}

function liveModeProblems(e: Env): string[] {
  const problems: string[] = [];
  const selected = {
    MARKET_DATA_PROVIDER: e.MARKET_DATA_PROVIDER,
    NEWS_PROVIDER: e.NEWS_PROVIDER,
    FUNDAMENTALS_PROVIDER: e.FUNDAMENTALS_PROVIDER,
    LLM_PROVIDER: e.LLM_PROVIDER,
  };
  for (const [key, value] of Object.entries(selected)) {
    if (value === 'mock') problems.push(`${key}=mock requires MOCK_DATA=true`);
  }
  if (e.LLM_PROVIDER === 'openai' && !e.OPENAI_API_KEY) problems.push('OPENAI_API_KEY is required when LLM_PROVIDER=openai');
  if (e.LLM_PROVIDER === 'openai' && !e.LLM_MODEL) problems.push('LLM_MODEL is required when LLM_PROVIDER=openai');
  if (e.NEWS_PROVIDER === 'newsapi' && !e.NEWS_API_KEY) problems.push('NEWS_API_KEY is required when NEWS_PROVIDER=newsapi');
  return problems;
}

export function loadConfig(rawEnv: Record<string, string | undefined>): AppConfig {
  const parsed = EnvSchema.safeParse(withoutBlanks(rawEnv));
  if (!parsed.success) {
    throw new ConfigError(`Invalid configuration:\n${z.prettifyError(parsed.error)}`);
  }
  const e = parsed.data;
  if (!e.MOCK_DATA) {
    const problems = liveModeProblems(e);
    if (problems.length > 0) throw new ConfigError(`Invalid configuration:\n- ${problems.join('\n- ')}`);
  }
  const mock = e.MOCK_DATA;
  return {
    env: e.NODE_ENV,
    host: e.HOST,
    port: e.PORT,
    logLevel: e.LOG_LEVEL,
    databaseUrl: e.DATABASE_URL,
    dataMode: mock ? 'MOCK' : 'LIVE',
    providers: {
      marketData: mock ? 'mock' : e.MARKET_DATA_PROVIDER,
      news: mock ? 'mock' : e.NEWS_PROVIDER,
      fundamentals: mock ? 'mock' : e.FUNDAMENTALS_PROVIDER,
      llm: mock ? 'mock' : e.LLM_PROVIDER,
    },
    supabase: { url: e.SUPABASE_URL ?? null, anonKey: e.SUPABASE_ANON_KEY ?? null },
    secrets: {
      openaiApiKey: e.OPENAI_API_KEY ?? null,
      newsApiKey: e.NEWS_API_KEY ?? null,
      supabaseServiceRoleKey: e.SUPABASE_SERVICE_ROLE_KEY ?? null,
      jwtSecret: e.JWT_SECRET ?? null,
    },
    llm: {
      model: e.LLM_MODEL ?? null,
      embeddingModel: e.EMBEDDING_MODEL,
      embeddingDimensions: e.EMBEDDING_DIMENSIONS,
      dailyBudgetInr: e.LLM_DAILY_BUDGET_INR,
    },
    autoPaperTrade: e.AUTO_PAPER_TRADE,
  };
}
```
`backend/src/config/dotenv.ts`:
```ts
import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

/** Repo root, valid from both src/config and dist/config. */
export const REPO_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');

/** Loads the repo-root .env (if present). Existing process.env values win. */
export function loadDotEnv(path: string = resolve(REPO_ROOT, '.env')): boolean {
  if (!existsSync(path)) return false;
  process.loadEnvFile(path);
  return true;
}
```

- [ ] **Step 5: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test:unit && pnpm lint`
Expected: PASS (10 tests).

- [ ] **Step 6: Commit**

```bash
git add backend .env.example package.json pnpm-lock.yaml
git commit -m "feat(backend): package scaffold and validated config" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 2: Error taxonomy and retry with backoff

**Files:**
- Create: `backend/src/utils/errors.ts`, `backend/src/utils/retry.ts`
- Test: `backend/tests/unit/errors.test.ts`, `backend/tests/unit/retry.test.ts`

**Interfaces:**
- Produces:
  - `ErrorCode` = `'TIMEOUT'|'RATE_LIMITED'|'AUTH_FAILED'|'INVALID_RESPONSE'|'EMPTY_RESPONSE'|'NETWORK'|'PROVIDER_DOWN'|'UNSUPPORTED'|'VALIDATION'|'NOT_FOUND'|'CONFLICT'|'INTERNAL'`
  - `class AppError(code, message, {cause?, details?, retryAfterMs?})` with `.retryable` and `.httpStatus`
  - `isAppError(e)`
  - `withRetry<T>(fn: (attempt) => Promise<T>, opts?: RetryOptions): Promise<T>`

- [ ] **Step 1: Write the failing tests** `backend/tests/unit/errors.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { AppError, isAppError } from '../../src/utils/errors.js';

describe('AppError', () => {
  it('marks only transient failures as retryable (auth failures never retry)', () => {
    for (const code of ['TIMEOUT', 'RATE_LIMITED', 'NETWORK', 'PROVIDER_DOWN'] as const) {
      expect(new AppError(code, 'x').retryable).toBe(true);
    }
    for (const code of ['AUTH_FAILED', 'INVALID_RESPONSE', 'EMPTY_RESPONSE', 'UNSUPPORTED', 'VALIDATION', 'NOT_FOUND'] as const) {
      expect(new AppError(code, 'x').retryable).toBe(false);
    }
  });

  it('maps codes to HTTP statuses', () => {
    expect(new AppError('VALIDATION', 'x').httpStatus).toBe(400);
    expect(new AppError('NOT_FOUND', 'x').httpStatus).toBe(404);
    expect(new AppError('PROVIDER_DOWN', 'x').httpStatus).toBe(503);
    expect(new AppError('INTERNAL', 'x').httpStatus).toBe(500);
  });

  it('keeps cause, details and retryAfterMs', () => {
    const cause = new Error('root');
    const e = new AppError('RATE_LIMITED', 'slow down', { cause, details: { provider: 'yahoo' }, retryAfterMs: 2000 });
    expect(e.cause).toBe(cause);
    expect(e.details).toEqual({ provider: 'yahoo' });
    expect(e.retryAfterMs).toBe(2000);
    expect(isAppError(e)).toBe(true);
    expect(isAppError(new Error('plain'))).toBe(false);
  });
});
```
`backend/tests/unit/retry.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { AppError } from '../../src/utils/errors.js';
import { withRetry } from '../../src/utils/retry.js';

function harness() {
  const sleeps: number[] = [];
  return { sleeps, opts: { sleep: async (ms: number) => void sleeps.push(ms), random: () => 1 } };
}

describe('withRetry', () => {
  it('retries retryable errors with exponential backoff and then succeeds', async () => {
    const h = harness();
    let calls = 0;
    const result = await withRetry(async () => {
      calls += 1;
      if (calls < 3) throw new AppError('TIMEOUT', 'slow');
      return 'ok';
    }, h.opts);
    expect(result).toBe('ok');
    expect(calls).toBe(3);
    expect(h.sleeps).toEqual([500, 1000]);
  });

  it('never retries AUTH_FAILED', async () => {
    const h = harness();
    let calls = 0;
    await expect(withRetry(async () => { calls += 1; throw new AppError('AUTH_FAILED', 'bad key'); }, h.opts))
      .rejects.toMatchObject({ code: 'AUTH_FAILED' });
    expect(calls).toBe(1);
  });

  it('does not retry unknown (non-AppError) errors', async () => {
    let calls = 0;
    await expect(withRetry(async () => { calls += 1; throw new Error('bug'); }, harness().opts)).rejects.toThrow('bug');
    expect(calls).toBe(1);
  });

  it('gives up after the attempt limit and rethrows the last error', async () => {
    const h = harness();
    let calls = 0;
    await expect(withRetry(async () => { calls += 1; throw new AppError('NETWORK', `fail ${calls}`); }, { ...h.opts, attempts: 3 }))
      .rejects.toThrow('fail 3');
    expect(calls).toBe(3);
  });

  it('honours a provider Retry-After longer than the backoff', async () => {
    const h = harness();
    let calls = 0;
    await withRetry(async () => {
      calls += 1;
      if (calls === 1) throw new AppError('RATE_LIMITED', 'wait', { retryAfterMs: 7000 });
      return 1;
    }, h.opts);
    expect(h.sleeps).toEqual([7000]);
  });

  it('caps the delay at maxDelayMs', async () => {
    const h = harness();
    let calls = 0;
    await withRetry(async () => {
      calls += 1;
      if (calls < 5) throw new AppError('PROVIDER_DOWN', 'down');
      return 1;
    }, { ...h.opts, attempts: 5, baseDelayMs: 1000, maxDelayMs: 3000 });
    expect(h.sleeps).toEqual([1000, 2000, 3000, 3000]);
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/utils/errors.ts`

```ts
export const ERROR_CODES = [
  'TIMEOUT', 'RATE_LIMITED', 'AUTH_FAILED', 'INVALID_RESPONSE', 'EMPTY_RESPONSE', 'NETWORK',
  'PROVIDER_DOWN', 'UNSUPPORTED', 'VALIDATION', 'NOT_FOUND', 'CONFLICT', 'INTERNAL',
] as const;
export type ErrorCode = (typeof ERROR_CODES)[number];

const RETRYABLE: ReadonlySet<ErrorCode> = new Set<ErrorCode>(['TIMEOUT', 'RATE_LIMITED', 'NETWORK', 'PROVIDER_DOWN']);

// Upstream (provider) failures surface as 5xx: the fault is not the API caller's.
const HTTP_STATUS: Readonly<Record<ErrorCode, number>> = {
  TIMEOUT: 504, RATE_LIMITED: 429, AUTH_FAILED: 502, INVALID_RESPONSE: 502, EMPTY_RESPONSE: 502,
  NETWORK: 502, PROVIDER_DOWN: 503, UNSUPPORTED: 501, VALIDATION: 400, NOT_FOUND: 404,
  CONFLICT: 409, INTERNAL: 500,
};

export interface AppErrorOptions {
  cause?: unknown;
  details?: Record<string, unknown>;
  retryAfterMs?: number;
}

export class AppError extends Error {
  override readonly name = 'AppError';
  readonly code: ErrorCode;
  readonly details: Record<string, unknown> | undefined;
  readonly retryAfterMs: number | undefined;

  constructor(code: ErrorCode, message: string, options: AppErrorOptions = {}) {
    super(message, { cause: options.cause });
    this.code = code;
    this.details = options.details;
    this.retryAfterMs = options.retryAfterMs;
  }

  get retryable(): boolean {
    return RETRYABLE.has(this.code);
  }

  get httpStatus(): number {
    return HTTP_STATUS[this.code];
  }
}

export function isAppError(error: unknown): error is AppError {
  return error instanceof AppError;
}
```
`backend/src/utils/retry.ts`:
```ts
import { type AppError, isAppError } from './errors.js';

export interface RetryOptions {
  attempts?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  random?: () => number;
  sleep?: (ms: number) => Promise<void>;
  onRetry?: (info: { attempt: number; delayMs: number; error: AppError }) => void;
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Retries only retryable AppErrors, with exponential backoff + equal jitter; honours retryAfterMs. */
export async function withRetry<T>(fn: (attempt: number) => Promise<T>, options: RetryOptions = {}): Promise<T> {
  const attempts = options.attempts ?? 3;
  const baseDelayMs = options.baseDelayMs ?? 500;
  const maxDelayMs = options.maxDelayMs ?? 8000;
  const random = options.random ?? Math.random;
  const sleep = options.sleep ?? defaultSleep;

  for (let attempt = 1; ; attempt += 1) {
    try {
      return await fn(attempt);
    } catch (error) {
      if (!isAppError(error) || !error.retryable || attempt >= attempts) throw error;
      const backoff = Math.min(maxDelayMs, baseDelayMs * 2 ** (attempt - 1));
      const jittered = backoff / 2 + random() * (backoff / 2);
      const delayMs = Math.max(jittered, error.retryAfterMs ?? 0);
      options.onRetry?.({ attempt, delayMs, error });
      await sleep(delayMs);
    }
  }
}
```

- [ ] **Step 4: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test:unit && pnpm lint`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "feat(backend): error taxonomy and retry with exponential backoff" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 3: HTTP client with timeouts and error mapping

**Files:**
- Create: `backend/src/utils/http.ts`
- Test: `backend/tests/unit/http.test.ts` (a real local `node:http` server, no mocks)

**Interfaces:**
- Consumes: `AppError` (Task 2).
- Produces:
  - `httpRequest(req: HttpRequest): Promise<HttpTextResponse>`
  - `httpJson<T = unknown>(req): Promise<{ status; headers; data: T }>`
  - `HttpRequest = { url; method?: 'GET'|'POST'; headers?; body?: unknown; timeoutMs? }`
  - `redactUrl(url): string` (origin + path, no query)

- [ ] **Step 1: Write the failing test** `backend/tests/unit/http.test.ts`

```ts
import { createServer, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { AppError } from '../../src/utils/errors.js';
import { httpJson, redactUrl } from '../../src/utils/http.js';

let server: Server;
let base = '';

beforeAll(async () => {
  server = createServer((req, res) => {
    const path = (req.url ?? '').split('?')[0];
    const send = (status: number, body: string, headers: Record<string, string> = {}) => {
      res.writeHead(status, { 'content-type': 'application/json', ...headers });
      res.end(body);
    };
    if (path === '/ok') return send(200, '{"price":101.5}');
    if (path === '/slow') return void setTimeout(() => send(200, '{}'), 300);
    if (path === '/401') return send(401, '{}');
    if (path === '/429') return send(429, '{}', { 'retry-after': '2' });
    if (path === '/503') return send(503, '{}');
    if (path === '/404') return send(404, '{}');
    if (path === '/bad-json') return send(200, '{not json');
    if (path === '/empty') return send(200, '');
    return send(500, '{}');
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(() => new Promise<void>((resolve) => server.close(() => resolve())));

async function codeOf(p: Promise<unknown>): Promise<AppError> {
  try {
    await p;
  } catch (e) {
    if (e instanceof AppError) return e;
    throw e;
  }
  throw new Error('expected rejection');
}

describe('httpJson', () => {
  it('parses JSON on success', async () => {
    const res = await httpJson<{ price: number }>({ url: `${base}/ok` });
    expect(res.status).toBe(200);
    expect(res.data.price).toBe(101.5);
  });

  it('maps a slow response to TIMEOUT', async () => {
    expect((await codeOf(httpJson({ url: `${base}/slow`, timeoutMs: 50 }))).code).toBe('TIMEOUT');
  });

  it('maps 401 to AUTH_FAILED, 503 to PROVIDER_DOWN, 404 to INVALID_RESPONSE', async () => {
    expect((await codeOf(httpJson({ url: `${base}/401` }))).code).toBe('AUTH_FAILED');
    expect((await codeOf(httpJson({ url: `${base}/503` }))).code).toBe('PROVIDER_DOWN');
    const notFound = await codeOf(httpJson({ url: `${base}/404` }));
    expect(notFound.code).toBe('INVALID_RESPONSE');
    expect(notFound.details).toMatchObject({ status: 404 });
  });

  it('maps 429 to RATE_LIMITED with Retry-After in ms', async () => {
    const e = await codeOf(httpJson({ url: `${base}/429` }));
    expect(e.code).toBe('RATE_LIMITED');
    expect(e.retryAfterMs).toBe(2000);
  });

  it('maps malformed and empty bodies', async () => {
    expect((await codeOf(httpJson({ url: `${base}/bad-json` }))).code).toBe('INVALID_RESPONSE');
    expect((await codeOf(httpJson({ url: `${base}/empty` }))).code).toBe('EMPTY_RESPONSE');
  });

  it('maps a refused connection to NETWORK', async () => {
    const closed = createServer();
    await new Promise<void>((resolve) => closed.listen(0, '127.0.0.1', resolve));
    const port = (closed.address() as AddressInfo).port;
    await new Promise<void>((resolve) => closed.close(() => resolve()));
    expect((await codeOf(httpJson({ url: `http://127.0.0.1:${port}/x` }))).code).toBe('NETWORK');
  });

  it('never leaks query-string secrets into errors', async () => {
    const e = await codeOf(httpJson({ url: `${base}/401?apikey=SUPER_SECRET_KEY` }));
    expect(JSON.stringify({ message: e.message, details: e.details })).not.toContain('SUPER_SECRET_KEY');
    expect(redactUrl('https://api.example.com/v1/q?apikey=abc&s=1')).toBe('https://api.example.com/v1/q');
  });
});
```

- [ ] **Step 2: Run to verify it fails**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/utils/http.ts`

```ts
import { AppError } from './errors.js';

export interface HttpRequest {
  url: string;
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  body?: unknown;
  timeoutMs?: number;
}

export interface HttpTextResponse {
  status: number;
  headers: Headers;
  text: string;
}

const DEFAULT_TIMEOUT_MS = 10_000;

/** origin + path only: query strings often carry API keys. */
export function redactUrl(url: string): string {
  try {
    const u = new URL(url);
    return `${u.origin}${u.pathname}`;
  } catch {
    return '[invalid-url]';
  }
}

function parseRetryAfter(value: string | null): number | undefined {
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
  const at = Date.parse(value);
  return Number.isNaN(at) ? undefined : Math.max(0, at - Date.now());
}

export async function httpRequest(req: HttpRequest): Promise<HttpTextResponse> {
  const target = redactUrl(req.url);
  const timeoutMs = req.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  let response: Response;
  try {
    const init: RequestInit = {
      method: req.method ?? 'GET',
      headers: { accept: 'application/json', ...req.headers },
      signal: AbortSignal.timeout(timeoutMs),
    };
    if (req.body !== undefined) {
      init.body = JSON.stringify(req.body);
      init.headers = { ...init.headers, 'content-type': 'application/json' };
    }
    response = await fetch(req.url, init);
  } catch (cause) {
    if (cause instanceof DOMException && cause.name === 'TimeoutError') {
      throw new AppError('TIMEOUT', `Request to ${target} timed out after ${timeoutMs} ms`, { details: { url: target, timeoutMs } });
    }
    throw new AppError('NETWORK', `Network error calling ${target}`, { cause, details: { url: target } });
  }

  const details = { url: target, status: response.status };
  if (response.status === 401 || response.status === 403) {
    throw new AppError('AUTH_FAILED', `Authentication failed calling ${target}`, { details });
  }
  if (response.status === 429) {
    const retryAfterMs = parseRetryAfter(response.headers.get('retry-after'));
    throw new AppError('RATE_LIMITED', `Rate limited by ${target}`, retryAfterMs === undefined ? { details } : { details, retryAfterMs });
  }
  if (response.status >= 500) {
    throw new AppError('PROVIDER_DOWN', `Provider error ${response.status} from ${target}`, { details });
  }
  if (response.status >= 400) {
    throw new AppError('INVALID_RESPONSE', `Unexpected status ${response.status} from ${target}`, { details });
  }
  return { status: response.status, headers: response.headers, text: await response.text() };
}

export async function httpJson<T = unknown>(req: HttpRequest): Promise<{ status: number; headers: Headers; data: T }> {
  const res = await httpRequest(req);
  const target = redactUrl(req.url);
  if (res.text.trim() === '') {
    throw new AppError('EMPTY_RESPONSE', `Empty response from ${target}`, { details: { url: target, status: res.status } });
  }
  try {
    return { status: res.status, headers: res.headers, data: JSON.parse(res.text) as T };
  } catch (cause) {
    throw new AppError('INVALID_RESPONSE', `Malformed JSON from ${target}`, { cause, details: { url: target } });
  }
}
```

- [ ] **Step 4: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test:unit && pnpm lint`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "feat(backend): HTTP client with timeouts, error mapping and URL redaction" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 4: In-memory TTL/LRU cache and redacting logger

**Files:**
- Create: `backend/src/utils/cache.ts`, `backend/src/utils/logger.ts`
- Test: `backend/tests/unit/cache.test.ts`, `backend/tests/unit/logger.test.ts`

**Interfaces:**
- Produces:
  - `interface Cache { get<T>(key): T | undefined; set<T>(key, value, ttlMs): void; delete(key): void; deleteByPrefix(prefix): number; getOrSet<T>(key, ttlMs, load: () => Promise<T>): Promise<T> }`
  - `class MemoryCache implements Cache` with constructor `(maxEntries = 1000, now: () => number = Date.now)`
  - `createLogger({ level, destination? }): Logger` (pino)
  - `REDACT_PATHS`

- [ ] **Step 1: Write the failing tests** `backend/tests/unit/cache.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { MemoryCache } from '../../src/utils/cache.js';

describe('MemoryCache', () => {
  it('expires entries after their TTL', () => {
    let now = 1_000;
    const cache = new MemoryCache(10, () => now);
    cache.set('quote:RELIANCE', 2500, 30_000);
    expect(cache.get<number>('quote:RELIANCE')).toBe(2500);
    now += 30_001;
    expect(cache.get('quote:RELIANCE')).toBeUndefined();
  });

  it('evicts the least recently used entry beyond capacity', () => {
    const cache = new MemoryCache(2);
    cache.set('a', 1, 60_000);
    cache.set('b', 2, 60_000);
    cache.get('a');
    cache.set('c', 3, 60_000);
    expect(cache.get('a')).toBe(1);
    expect(cache.get('b')).toBeUndefined();
    expect(cache.get('c')).toBe(3);
  });

  it('deletes by prefix', () => {
    const cache = new MemoryCache();
    cache.set('quote:A', 1, 60_000);
    cache.set('quote:B', 2, 60_000);
    cache.set('summary', 3, 60_000);
    expect(cache.deleteByPrefix('quote:')).toBe(2);
    expect(cache.get('summary')).toBe(3);
  });

  it('getOrSet loads once for concurrent callers and does not cache failures', async () => {
    const cache = new MemoryCache();
    let loads = 0;
    const load = async () => { loads += 1; return 'v'; };
    const [x, y] = await Promise.all([cache.getOrSet('k', 1000, load), cache.getOrSet('k', 1000, load)]);
    expect([x, y, loads]).toEqual(['v', 'v', 1]);

    let attempts = 0;
    const failing = async (): Promise<string> => { attempts += 1; throw new Error('db down'); };
    await expect(cache.getOrSet('f', 1000, failing)).rejects.toThrow('db down');
    await expect(cache.getOrSet('f', 1000, failing)).rejects.toThrow('db down');
    expect(attempts).toBe(2);
  });
});
```
`backend/tests/unit/logger.test.ts`:
```ts
import { Writable } from 'node:stream';
import { describe, expect, it } from 'vitest';
import { createLogger } from '../../src/utils/logger.js';

function capture() {
  const lines: string[] = [];
  const destination = new Writable({ write(chunk, _enc, cb) { lines.push(String(chunk)); cb(); } });
  return { lines, destination };
}

describe('createLogger', () => {
  it('writes structured JSON and redacts secrets', () => {
    const { lines, destination } = capture();
    const logger = createLogger({ level: 'info', destination });
    logger.info({ apiKey: 'k-123', config: { secrets: { openaiApiKey: 'sk-abc' } }, req: { headers: { authorization: 'Bearer t' } } }, 'hello');
    const out = lines.join('');
    expect(out).toContain('"msg":"hello"');
    expect(out).not.toContain('k-123');
    expect(out).not.toContain('sk-abc');
    expect(out).not.toContain('Bearer t');
    expect(out).toContain('[REDACTED]');
  });

  it('respects the level', () => {
    const { lines, destination } = capture();
    createLogger({ level: 'warn', destination }).info('quiet');
    expect(lines).toHaveLength(0);
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/utils/cache.ts`

```ts
export interface Cache {
  get<T>(key: string): T | undefined;
  set<T>(key: string, value: T, ttlMs: number): void;
  delete(key: string): void;
  deleteByPrefix(prefix: string): number;
  getOrSet<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T>;
}

interface Entry {
  value: unknown;
  expiresAt: number;
}

/** Process-local TTL + LRU cache. Swappable for Redis behind the Cache interface. */
export class MemoryCache implements Cache {
  private readonly entries = new Map<string, Entry>();
  private readonly inFlight = new Map<string, Promise<unknown>>();

  constructor(
    private readonly maxEntries = 1000,
    private readonly now: () => number = Date.now,
  ) {}

  get<T>(key: string): T | undefined {
    const entry = this.entries.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt <= this.now()) {
      this.entries.delete(key);
      return undefined;
    }
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry.value as T;
  }

  set<T>(key: string, value: T, ttlMs: number): void {
    this.entries.delete(key);
    this.entries.set(key, { value, expiresAt: this.now() + ttlMs });
    while (this.entries.size > this.maxEntries) {
      const oldest = this.entries.keys().next();
      if (oldest.done) break;
      this.entries.delete(oldest.value);
    }
  }

  delete(key: string): void {
    this.entries.delete(key);
  }

  deleteByPrefix(prefix: string): number {
    let removed = 0;
    for (const key of [...this.entries.keys()]) {
      if (key.startsWith(prefix)) {
        this.entries.delete(key);
        removed += 1;
      }
    }
    return removed;
  }

  async getOrSet<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
    const cached = this.get<T>(key);
    if (cached !== undefined) return cached;
    const pending = this.inFlight.get(key);
    if (pending) return pending as Promise<T>;
    const promise = load()
      .then((value) => {
        this.set(key, value, ttlMs);
        return value;
      })
      .finally(() => this.inFlight.delete(key));
    this.inFlight.set(key, promise);
    return promise;
  }
}
```
`backend/src/utils/logger.ts`:
```ts
import pino, { type DestinationStream, type Logger } from 'pino';

export const REDACT_PATHS = [
  'apiKey', '*.apiKey', 'password', '*.password', 'token', '*.token',
  'authorization', '*.authorization', 'req.headers.authorization', 'req.headers.cookie',
  'secrets', '*.secrets',
  'OPENAI_API_KEY', 'NEWS_API_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'JWT_SECRET',
];

export interface LoggerOptions {
  level: string;
  destination?: DestinationStream;
}

export function createLogger(options: LoggerOptions): Logger {
  const config = {
    level: options.level,
    base: { service: 'backend' },
    redact: { paths: REDACT_PATHS, censor: '[REDACTED]' },
    timestamp: pino.stdTimeFunctions.isoTime,
  };
  return options.destination ? pino(config, options.destination) : pino(config);
}
```

- [ ] **Step 4: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test:unit && pnpm lint`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "feat(backend): TTL/LRU cache with stampede protection and redacting logger" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 5: Database layer, generated types, domain enums and integration-test harness

**Files:**
- Create:
  - `backend/src/database/db.ts`
  - `backend/src/database/convert.ts`
  - `backend/src/database/types.generated.ts` (generated)
  - `backend/src/domain/enums.ts`
  - `backend/tests/integration/globalSetup.ts`
  - `backend/tests/integration/helpers.ts`
- Test: `backend/tests/integration/database.test.ts`, `backend/tests/unit/convert.test.ts`

**Interfaces:**
- Produces:
  - `type Database = Kysely<DB>`
  - `createDatabase(url, { max? }): Database`
  - `pingDatabase(db, timeoutMs = 2000): Promise<boolean>`
  - `toNumber(v: string | number | bigint | null | undefined): number | null`
  - `requireNumber(v, field): number`
  - enum const arrays + types (`EXCHANGES`, `Exchange`, `DATA_MODES`, `DataMode`, `BAR_INTERVALS`, `BarInterval`, `MARKET_TYPES`, `MarketType`, `JOB_STATUSES`, `JobStatus`, and the rest), plus `DB_ENUMS` (pg enum name → labels)
  - test helpers: `LOCAL_DATABASE_URL`, `createTestDb()`, `withRollback(db, fn)`

- [ ] **Step 1: Generate DB types** (the local DB must be running: `pnpm db:start && pnpm db:reset`)

Run: `pnpm --filter @learning-stocks/backend db:types`
Expected: `backend/src/database/types.generated.ts` exists, contains `export interface DB` with keys `stocks`, `market_data`, `v_latest_quotes`, and has no `auth.` tables. If view types are absent, record a ruling and query the view with `sql` in Task 7.

- [ ] **Step 2: Write the failing tests** `backend/tests/unit/convert.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { requireNumber, toNumber } from '../../src/database/convert.js';

describe('numeric conversion', () => {
  it('converts pg numeric/int8 strings to numbers and keeps null', () => {
    expect(toNumber('2510.4500')).toBe(2510.45);
    expect(toNumber('9007199254')).toBe(9007199254);
    expect(toNumber(null)).toBeNull();
    expect(toNumber(undefined)).toBeNull();
  });
  it('rejects non-numeric strings and missing required values', () => {
    expect(() => toNumber('abc')).toThrow(/not a number/);
    expect(() => requireNumber(null, 'close')).toThrow(/close/);
  });
});
```
`backend/tests/integration/globalSetup.ts`:
```ts
import pg from 'pg';
import { LOCAL_DATABASE_URL } from './helpers.js';

export default async function setup(): Promise<void> {
  const url = process.env.DATABASE_URL ?? LOCAL_DATABASE_URL;
  const client = new pg.Client({ connectionString: url, connectionTimeoutMillis: 3000 });
  try {
    await client.connect();
    await client.query('select 1');
  } catch {
    throw new Error(`Integration tests need the local database at ${url}. Run: pnpm db:start && pnpm db:reset`);
  } finally {
    await client.end().catch(() => undefined);
  }
}
```
`backend/tests/integration/helpers.ts`:
```ts
import { createDatabase, type Database } from '../../src/database/db.js';

export const LOCAL_DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:54322/postgres';

export function createTestDb(): Database {
  return createDatabase(process.env.DATABASE_URL ?? LOCAL_DATABASE_URL, { max: 2 });
}

const ROLLBACK = Symbol('rollback');

/** Runs fn inside a transaction that is always rolled back: tests never leave data behind. */
export async function withRollback(db: Database, fn: (trx: Database) => Promise<void>): Promise<void> {
  try {
    await db.transaction().execute(async (trx) => {
      await fn(trx);
      throw ROLLBACK;
    });
  } catch (error) {
    if (error !== ROLLBACK) throw error;
  }
}
```
`backend/tests/integration/database.test.ts`:
```ts
import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { createDatabase, pingDatabase } from '../../src/database/db.js';
import { DB_ENUMS } from '../../src/domain/enums.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('database layer', () => {
  it('pings a live database and reports a dead one without hanging', async () => {
    expect(await pingDatabase(db)).toBe(true);
    const dead = createDatabase('postgresql://postgres:postgres@127.0.0.1:1/postgres', { max: 1 });
    const started = Date.now();
    expect(await pingDatabase(dead, 1500)).toBe(false);
    expect(Date.now() - started).toBeLessThan(3000);
    await dead.destroy();
  });

  it('returns DATE columns as YYYY-MM-DD strings regardless of host timezone', async () => {
    const row = await db.selectFrom('exchange_holidays').select('holiday_date').where('exchange', '=', 'NSE').orderBy('holiday_date').executeTakeFirstOrThrow();
    expect(row.holiday_date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(row.holiday_date).toBe('2026-01-15');
  });

  it('mirrors every Postgres enum exactly (labels and order)', async () => {
    for (const [name, labels] of Object.entries(DB_ENUMS)) {
      const result = await sql<{ label: string }>`
        select e.enumlabel as label from pg_enum e join pg_type t on t.oid = e.enumtypid
        join pg_namespace n on n.oid = t.typnamespace
        where n.nspname = 'public' and t.typname = ${name} order by e.enumsortorder`.execute(db);
      expect(result.rows.map((r) => r.label), name).toEqual([...labels]);
    }
  });

  it('withRollback leaves no data behind', async () => {
    await withRollback(db, async (trx) => {
      await trx.insertInto('app_settings').values({ key: 'zz_probe', value: sql`'1'::jsonb` }).execute();
    });
    const left = await db.selectFrom('app_settings').select('key').where('key', '=', 'zz_probe').execute();
    expect(left).toHaveLength(0);
  });
});
```

- [ ] **Step 3: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test`
Expected: FAIL (modules `db.js`, `convert.js`, `enums.js` not found).

- [ ] **Step 4: Implement** `backend/src/database/db.ts`

```ts
import { Kysely, PostgresDialect, sql } from 'kysely';
import pg from 'pg';
import type { DB } from './types.generated.js';

// DATE -> 'YYYY-MM-DD' string. The default parser builds a local-midnight Date, which shifts
// the day on hosts west of UTC. Matches kysely-codegen --date-parser string.
const PG_DATE_OID = 1082;
pg.types.setTypeParser(PG_DATE_OID, (value: string) => value);

export type Database = Kysely<DB>;

export function createDatabase(connectionString: string, options: { max?: number } = {}): Database {
  const pool = new pg.Pool({ connectionString, max: options.max ?? 10, connectionTimeoutMillis: 5000 });
  return new Kysely<DB>({ dialect: new PostgresDialect({ pool }) });
}

export async function pingDatabase(db: Database, timeoutMs = 2000): Promise<boolean> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<false>((resolve) => {
    timer = setTimeout(() => resolve(false), timeoutMs);
  });
  const probe = sql`select 1`.execute(db).then(() => true as const, () => false as const);
  try {
    return await Promise.race([probe, timeout]);
  } finally {
    clearTimeout(timer);
  }
}
```
`backend/src/database/convert.ts`:
```ts
/** pg returns numeric and int8 as strings; repositories convert explicitly at the boundary. */
export function toNumber(value: string | number | bigint | null | undefined): number | null {
  if (value === null || value === undefined) return null;
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n)) throw new TypeError(`Value ${String(value)} is not a number`);
  return n;
}

export function requireNumber(value: string | number | bigint | null | undefined, field: string): number {
  const n = toNumber(value);
  if (n === null) throw new TypeError(`Expected a number for ${field}, got null`);
  return n;
}
```
`backend/src/domain/enums.ts` (labels and order copied from `supabase/migrations/20261005000100_extensions_types.sql`):
```ts
export const EXCHANGES = ['NSE', 'BSE'] as const;
export type Exchange = (typeof EXCHANGES)[number];
export const MARKET_TYPES = ['BROAD_INDEX', 'SECTOR_INDEX', 'VOLATILITY'] as const;
export type MarketType = (typeof MARKET_TYPES)[number];
export const DATA_MODES = ['MOCK', 'LIVE'] as const;
export type DataMode = (typeof DATA_MODES)[number];
export const BAR_INTERVALS = ['1m', '5m', '15m', '1d'] as const;
export type BarInterval = (typeof BAR_INTERVALS)[number];
export const SENTIMENTS = ['BULLISH', 'NEUTRAL', 'BEARISH'] as const;
export type Sentiment = (typeof SENTIMENTS)[number];
export const IMPACT_LEVELS = ['LOW', 'MEDIUM', 'HIGH'] as const;
export const TRENDS = ['UPTREND', 'SIDEWAYS', 'DOWNTREND'] as const;
export const RISK_LEVELS = ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'] as const;
export const RECOMMENDATION_BIASES = ['STRONG_BUY_BIAS', 'BUY_BIAS', 'HOLD_BIAS', 'SELL_BIAS', 'STRONG_SELL_BIAS'] as const;
export const ACTION_STATES = ['BUY_ZONE', 'WAIT_FOR_PULLBACK', 'WAIT_FOR_CONFIRMATION', 'HOLD', 'REDUCE', 'AVOID', 'INSUFFICIENT_DATA'] as const;
export const VALUATION_LABELS = ['UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA'] as const;
export const MARKET_REGIMES = ['RISK_ON', 'NEUTRAL', 'RISK_OFF'] as const;
export const TRADE_SIDES = ['BUY', 'SELL'] as const;
export const ORDER_STATUSES = ['PENDING', 'EXECUTED', 'REJECTED', 'CANCELLED'] as const;
export const ORDER_SOURCES = ['MANUAL', 'AI_SIGNAL'] as const;
export const SIGNAL_TYPES = ['BUY', 'SELL', 'HOLD'] as const;
export const SIGNAL_STATUSES = ['ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED'] as const;
export const PERIOD_TYPES = ['QUARTERLY', 'ANNUAL', 'TTM'] as const;
export const LINK_TYPES = ['BENCHMARK', 'SECTOR_INDEX', 'CONSTITUENT'] as const;
export const USER_ROLES = ['OWNER', 'ADMIN', 'VIEWER'] as const;
export const JOB_STATUSES = ['STARTED', 'SUCCESS', 'PARTIAL', 'FAILED', 'SKIPPED'] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];
export const ANALYSIS_STATUSES = ['OK', 'FAILED', 'INSUFFICIENT_DATA'] as const;

/** Postgres enum name -> labels. The integration test asserts an exact match with the DB. */
export const DB_ENUMS = {
  exchange_code: EXCHANGES, market_type: MARKET_TYPES, data_mode: DATA_MODES, bar_interval: BAR_INTERVALS,
  sentiment: SENTIMENTS, impact_level: IMPACT_LEVELS, trend: TRENDS, risk_level: RISK_LEVELS,
  recommendation_bias: RECOMMENDATION_BIASES, action_state: ACTION_STATES, valuation_label: VALUATION_LABELS,
  market_regime: MARKET_REGIMES, trade_side: TRADE_SIDES, order_status: ORDER_STATUSES, order_source: ORDER_SOURCES,
  signal_type: SIGNAL_TYPES, signal_status: SIGNAL_STATUSES, period_type: PERIOD_TYPES, link_type: LINK_TYPES,
  user_role: USER_ROLES, job_status: JOB_STATUSES, analysis_status: ANALYSIS_STATUSES,
} as const;
```
Exclude `backend/src/database/types.generated.ts` from ESLint and Prettier (add it to `.prettierignore` and to the `ignores` in `eslint.config.js`).

- [ ] **Step 5: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
Expected: PASS (unit + integration). The date test passes under `TZ=UTC`.

- [ ] **Step 6: Commit**

```bash
git add backend .prettierignore eslint.config.js pnpm-lock.yaml
git commit -m "feat(backend): Kysely database layer, generated types, enum mirror and rollback test harness" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 6: Reference repositories (stocks, markets, holidays, app settings)

**Files:**
- Create:
  - `backend/src/domain/types.ts`
  - `backend/src/repositories/StockRepository.ts`
  - `backend/src/repositories/MarketRepository.ts`
  - `backend/src/repositories/HolidayRepository.ts`
  - `backend/src/repositories/AppSettingsRepository.ts`
- Test: `backend/tests/integration/referenceRepositories.test.ts`

**Interfaces:**
- Consumes: `Database`, `toNumber`, enums (Task 5); `AppError` (Task 2).
- Produces (domain types in `types.ts`):
  - `Stock { id; symbol; companyName; exchange; isin: string|null; isinVerified; sector: string|null; industry: string|null; marketCap: number|null; currency; isActive }`
  - `Market { id; symbol; name; exchange; marketType; sector: string|null; isActive }`
  - `InstrumentRef = { kind: 'stock'; id: string } | { kind: 'market'; id: string }`
  - `ProviderInstrument<T> { instrument: T; providerSymbol: string; verified: boolean }`
  - `Holiday { exchange; date: string; description; specialOpen: string|null; specialClose: string|null }`
- Produces (repositories):
  - `StockRepository(db)`: `listActive()`, `findBySymbol(symbol, exchange = 'NSE')`, `search(query, limit = 10)`, `listWithProviderSymbol(provider)`
  - `MarketRepository(db)`: `listActive()`, `findBySymbol(symbol)`, `listWithProviderSymbol(provider)`
  - `HolidayRepository(db)`: `listBetween(exchange, from, to): Promise<Holiday[]>` (EQUITY segment, inclusive)
  - `AppSettingsRepository(db)`: `get<T>(key, schema: z.ZodType<T>): Promise<T | null>`

- [ ] **Step 1: Write the failing test** `backend/tests/integration/referenceRepositories.test.ts`

```ts
import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { z } from 'zod';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('StockRepository', () => {
  const repo = new StockRepository(db);

  it('lists the 20 seeded active stocks ordered by symbol', async () => {
    const stocks = await repo.listActive();
    expect(stocks).toHaveLength(20);
    expect(stocks[0]?.symbol).toBe('ADANIENT');
    expect(stocks.every((s) => s.currency === 'INR')).toBe(true);
  });

  it('finds by symbol case-insensitively and returns null for unknown symbols', async () => {
    const rel = await repo.findBySymbol('reliance');
    expect(rel).toMatchObject({ symbol: 'RELIANCE', exchange: 'NSE', isin: 'INE002A01018', isinVerified: true });
    expect(await repo.findBySymbol('NOSUCH')).toBeNull();
  });

  it('searches by symbol prefix, company name and ISIN with exact symbol first', async () => {
    expect((await repo.search('TCS'))[0]?.symbol).toBe('TCS');
    expect((await repo.search('mahindra')).map((s) => s.symbol)).toContain('KOTAKBANK');
    expect((await repo.search('INE009A01021')).map((s) => s.symbol)).toEqual(['INFY']);
    expect(await repo.search('%')).toEqual([]);
  });

  it('lists stocks with their provider symbol', async () => {
    const yahoo = await repo.listWithProviderSymbol('yahoo');
    expect(yahoo).toHaveLength(20);
    expect(yahoo.find((p) => p.instrument.symbol === 'RELIANCE')).toMatchObject({ providerSymbol: 'RELIANCE.NS', verified: false });
  });

  it('excludes inactive stocks', async () => {
    await withRollback(db, async (trx) => {
      await trx.updateTable('stocks').set({ is_active: false }).where('symbol', '=', 'ITC').execute();
      const scoped = new StockRepository(trx);
      expect((await scoped.listActive()).map((s) => s.symbol)).not.toContain('ITC');
      expect(await scoped.listWithProviderSymbol('mock')).toHaveLength(19);
    });
  });
});

describe('MarketRepository', () => {
  const repo = new MarketRepository(db);
  it('lists the 12 markets and maps yahoo index symbols', async () => {
    expect(await repo.listActive()).toHaveLength(12);
    expect(await repo.findBySymbol('NIFTY50')).toMatchObject({ name: 'NIFTY 50', marketType: 'BROAD_INDEX' });
    const yahoo = await repo.listWithProviderSymbol('yahoo');
    expect(yahoo.find((p) => p.instrument.symbol === 'INDIAVIX')?.providerSymbol).toBe('^INDIAVIX');
  });
});

describe('HolidayRepository', () => {
  it('returns EQUITY holidays in an inclusive date window as plain dates', async () => {
    const list = await new HolidayRepository(db).listBetween('NSE', '2026-10-01', '2026-10-31');
    expect(list.map((h) => h.date)).toEqual(['2026-10-02', '2026-10-20']);
    expect(list[0]).toMatchObject({ exchange: 'NSE', specialOpen: null, specialClose: null });
  });
});

describe('AppSettingsRepository', () => {
  const repo = new AppSettingsRepository(db);
  it('returns typed values, null for missing keys, and rejects malformed values', async () => {
    expect(await repo.get('paper_initial_balance', z.number())).toBe(1_000_000);
    expect(await repo.get('auto_paper_trade', z.boolean())).toBe(false);
    expect(await repo.get('no_such_key', z.number())).toBeNull();
    await withRollback(db, async (trx) => {
      await trx.insertInto('app_settings').values({ key: 'zz_bad', value: sql`'"text"'::jsonb` }).execute();
      await expect(new AppSettingsRepository(trx).get('zz_bad', z.number())).rejects.toMatchObject({ code: 'INTERNAL' });
    });
  });
});
```

- [ ] **Step 2: Run to verify it fails**

Run: `pnpm --filter @learning-stocks/backend test`
Expected: FAIL (repository modules not found).

- [ ] **Step 3: Implement** `backend/src/domain/types.ts`

```ts
import type { BarInterval, DataMode, Exchange, MarketType } from './enums.js';

export interface Stock {
  id: string;
  symbol: string;
  companyName: string;
  exchange: Exchange;
  isin: string | null;
  isinVerified: boolean;
  sector: string | null;
  industry: string | null;
  marketCap: number | null;
  currency: string;
  isActive: boolean;
}

export interface Market {
  id: string;
  symbol: string;
  name: string;
  exchange: Exchange;
  marketType: MarketType;
  sector: string | null;
  isActive: boolean;
}

export type InstrumentRef = { kind: 'stock'; id: string } | { kind: 'market'; id: string };

export interface ProviderInstrument<T> {
  instrument: T;
  providerSymbol: string;
  verified: boolean;
}

/** One trading-calendar exception. date is the IST calendar date (YYYY-MM-DD). */
export interface Holiday {
  exchange: Exchange;
  date: string;
  description: string;
  specialOpen: string | null;
  specialClose: string | null;
}

/**
 * OHLCV bar. Convention: ts = the bar's OPEN time as a UTC instant.
 * Daily bars are stamped at that day's session open (09:15 IST, or a special session's open).
 */
export interface Bar {
  instrument: InstrumentRef;
  dataMode: DataMode;
  timeframe: BarInterval;
  ts: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  adjustedClose: number | null;
  volume: number;
  change: number | null;
  changePercent: number | null;
  vwap: number | null;
  source: string;
}

export interface LatestQuote {
  instrument: InstrumentRef;
  dataMode: DataMode;
  timeframe: BarInterval;
  ts: Date;
  price: number;
  change: number | null;
  changePercent: number | null;
  volume: number;
  source: string;
}
```
`backend/src/repositories/StockRepository.ts`:
```ts
import { sql } from 'kysely';
import type { Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type { Exchange } from '../domain/enums.js';
import type { ProviderInstrument, Stock } from '../domain/types.js';

type StockRow = Selectable<DB['stocks']>;

export function mapStock(row: StockRow): Stock {
  return {
    id: row.id,
    symbol: row.symbol,
    companyName: row.company_name,
    exchange: row.exchange,
    isin: row.isin,
    isinVerified: row.isin_verified,
    sector: row.sector,
    industry: row.industry,
    marketCap: toNumber(row.market_cap),
    currency: row.currency,
    isActive: row.is_active,
  };
}

const escapeLike = (value: string) => value.replace(/[\\%_]/g, (c) => `\\${c}`);

export class StockRepository {
  constructor(private readonly db: Database) {}

  async listActive(): Promise<Stock[]> {
    const rows = await this.db.selectFrom('stocks').selectAll().where('is_active', '=', true).orderBy('symbol').execute();
    return rows.map(mapStock);
  }

  async findBySymbol(symbol: string, exchange: Exchange = 'NSE'): Promise<Stock | null> {
    const row = await this.db.selectFrom('stocks').selectAll()
      .where('exchange', '=', exchange).where('symbol', '=', symbol.trim().toUpperCase()).executeTakeFirst();
    return row ? mapStock(row) : null;
  }

  async search(query: string, limit = 10): Promise<Stock[]> {
    const q = query.trim();
    if (q.replace(/[%_\\]/g, '') === '') return [];
    const upper = q.toUpperCase();
    const prefix = `${escapeLike(upper)}%`;
    const contains = `%${escapeLike(q)}%`;
    const rows = await this.db.selectFrom('stocks').selectAll()
      .where('is_active', '=', true)
      .where((eb) => eb.or([eb('symbol', 'like', prefix), eb('company_name', 'ilike', contains), eb('isin', '=', upper)]))
      .orderBy(sql`case when symbol = ${upper} then 0 when symbol like ${prefix} then 1 else 2 end`)
      .orderBy('symbol')
      .limit(Math.min(Math.max(limit, 1), 50))
      .execute();
    return rows.map(mapStock);
  }

  async listWithProviderSymbol(provider: string): Promise<ProviderInstrument<Stock>[]> {
    const rows = await this.db.selectFrom('stocks as s')
      .innerJoin('provider_symbols as p', 'p.stock_id', 's.id')
      .selectAll('s')
      .select(['p.provider_symbol', 'p.verified'])
      .where('p.provider', '=', provider).where('s.is_active', '=', true)
      .orderBy('s.symbol').execute();
    return rows.map((r) => ({ instrument: mapStock(r), providerSymbol: r.provider_symbol, verified: r.verified }));
  }
}
```
`backend/src/repositories/MarketRepository.ts`:
```ts
import type { Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import type { DB } from '../database/types.generated.js';
import type { Market, ProviderInstrument } from '../domain/types.js';

type MarketRow = Selectable<DB['markets']>;

export function mapMarket(row: MarketRow): Market {
  return {
    id: row.id, symbol: row.symbol, name: row.name, exchange: row.exchange,
    marketType: row.market_type, sector: row.sector, isActive: row.is_active,
  };
}

export class MarketRepository {
  constructor(private readonly db: Database) {}

  async listActive(): Promise<Market[]> {
    const rows = await this.db.selectFrom('markets').selectAll().where('is_active', '=', true).orderBy('symbol').execute();
    return rows.map(mapMarket);
  }

  async findBySymbol(symbol: string): Promise<Market | null> {
    const row = await this.db.selectFrom('markets').selectAll().where('symbol', '=', symbol.trim().toUpperCase()).executeTakeFirst();
    return row ? mapMarket(row) : null;
  }

  async listWithProviderSymbol(provider: string): Promise<ProviderInstrument<Market>[]> {
    const rows = await this.db.selectFrom('markets as m')
      .innerJoin('provider_symbols as p', 'p.market_id', 'm.id')
      .selectAll('m')
      .select(['p.provider_symbol', 'p.verified'])
      .where('p.provider', '=', provider).where('m.is_active', '=', true)
      .orderBy('m.symbol').execute();
    return rows.map((r) => ({ instrument: mapMarket(r), providerSymbol: r.provider_symbol, verified: r.verified }));
  }
}
```
`backend/src/repositories/HolidayRepository.ts`:
```ts
import type { Database } from '../database/db.js';
import type { Exchange } from '../domain/enums.js';
import type { Holiday } from '../domain/types.js';

export class HolidayRepository {
  constructor(private readonly db: Database) {}

  /** Inclusive [from, to] on IST calendar dates (YYYY-MM-DD). */
  async listBetween(exchange: Exchange, from: string, to: string): Promise<Holiday[]> {
    const rows = await this.db.selectFrom('exchange_holidays')
      .select(['exchange', 'holiday_date', 'description', 'special_open', 'special_close'])
      .where('exchange', '=', exchange).where('segment', '=', 'EQUITY')
      .where('holiday_date', '>=', from).where('holiday_date', '<=', to)
      .orderBy('holiday_date').execute();
    return rows.map((r) => ({
      exchange: r.exchange, date: r.holiday_date, description: r.description,
      specialOpen: r.special_open, specialClose: r.special_close,
    }));
  }
}
```
`backend/src/repositories/AppSettingsRepository.ts`:
```ts
import type { z } from 'zod';
import type { Database } from '../database/db.js';
import { AppError } from '../utils/errors.js';

export class AppSettingsRepository {
  constructor(private readonly db: Database) {}

  async get<T>(key: string, schema: z.ZodType<T>): Promise<T | null> {
    const row = await this.db.selectFrom('app_settings').select('value').where('key', '=', key).executeTakeFirst();
    if (!row) return null;
    const parsed = schema.safeParse(row.value);
    if (!parsed.success) {
      throw new AppError('INTERNAL', `app_settings.${key} has an invalid value`, { details: { key } });
    }
    return parsed.data;
  }
}
```

- [ ] **Step 4: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
Expected: PASS. If generated column types differ from what the mappers assume (for example `time` columns typed other than `string`), adjust the mapper and record a ruling.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "feat(backend): stock, market, holiday and app-settings repositories" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 7: Market-data and system-log repositories

**Files:**
- Create: `backend/src/repositories/MarketDataRepository.ts`, `backend/src/repositories/SystemLogRepository.ts`
- Test: `backend/tests/integration/marketDataRepository.test.ts`, `backend/tests/integration/systemLogRepository.test.ts`

**Interfaces:**
- Consumes: `Bar`, `LatestQuote`, `InstrumentRef` (Task 6); `toNumber`, `requireNumber` (Task 5).
- Produces:
  - `MarketDataRepository(db)`:
    - `insertBars(bars: Bar[]): Promise<{ inserted: number; skipped: number }>` (duplicates skipped via ON CONFLICT DO NOTHING; 500 rows per statement)
    - `latestQuote(ref, mode): Promise<LatestQuote | null>`
    - `getBars(ref, mode, timeframe, from: Date, to: Date): Promise<Bar[]>` (ascending ts, inclusive)
  - `SystemLogRepository(db)`:
    - `startRun({ service, jobName, operation }): Promise<string>`
    - `finishRun(runId, { status: Exclude<JobStatus, 'STARTED'>; counts: { fetched; inserted; skipped; failed }; message?: string; error?: unknown }): Promise<void>` (throws `NOT_FOUND`)
    - `recentRuns(limit = 20): Promise<JobRun[]>`
    - `JobRun { id; service; jobName: string|null; operation; status; message: string|null; recordsFetched; recordsInserted; recordsSkipped; recordsFailed; recordsProcessed; startedAt: Date|null; finishedAt: Date|null; executionTimeMs: number|null; errorDetails: unknown }`

- [ ] **Step 1: Write the failing tests** `backend/tests/integration/marketDataRepository.test.ts`

```ts
import { afterAll, describe, expect, it } from 'vitest';
import type { Bar } from '../../src/domain/types.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

function bar(instrumentId: string, kind: 'stock' | 'market', ts: string, close: number, overrides: Partial<Bar> = {}): Bar {
  return {
    instrument: kind === 'stock' ? { kind: 'stock', id: instrumentId } : { kind: 'market', id: instrumentId },
    dataMode: 'MOCK', timeframe: '5m', ts: new Date(ts), open: close - 1, high: close + 2, low: close - 2, close,
    adjustedClose: null, volume: 12_345, change: null, changePercent: null, vwap: null, source: 'mock', ...overrides,
  };
}

describe('MarketDataRepository', () => {
  it('inserts bars, skips duplicates, and returns numbers (not strings)', async () => {
    await withRollback(db, async (trx) => {
      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      if (!stock) throw new Error('seed missing');
      const repo = new MarketDataRepository(trx);
      const bars = [bar(stock.id, 'stock', '2026-10-05T03:45:00Z', 2500.25), bar(stock.id, 'stock', '2026-10-05T03:50:00Z', 2501.5)];
      expect(await repo.insertBars(bars)).toEqual({ inserted: 2, skipped: 0 });
      expect(await repo.insertBars(bars)).toEqual({ inserted: 0, skipped: 2 });
      expect(await repo.insertBars([])).toEqual({ inserted: 0, skipped: 0 });

      const quote = await repo.latestQuote({ kind: 'stock', id: stock.id }, 'MOCK');
      expect(quote).toMatchObject({ price: 2501.5, volume: 12_345, timeframe: '5m', source: 'mock' });
      expect(typeof quote?.price).toBe('number');
      expect(quote?.ts.toISOString()).toBe('2026-10-05T03:50:00.000Z');

      const range = await repo.getBars({ kind: 'stock', id: stock.id }, 'MOCK', '5m', new Date('2026-10-05T03:45:00Z'), new Date('2026-10-05T03:50:00Z'));
      expect(range.map((b) => b.close)).toEqual([2500.25, 2501.5]);
    });
  });

  it('keeps MOCK and LIVE apart', async () => {
    await withRollback(db, async (trx) => {
      const stock = await new StockRepository(trx).findBySymbol('TCS');
      if (!stock) throw new Error('seed missing');
      const repo = new MarketDataRepository(trx);
      await repo.insertBars([bar(stock.id, 'stock', '2026-10-05T04:00:00Z', 4000)]);
      expect(await repo.latestQuote({ kind: 'stock', id: stock.id }, 'LIVE')).toBeNull();
      expect(await repo.getBars({ kind: 'stock', id: stock.id }, 'LIVE', '5m', new Date('2026-10-01'), new Date('2026-10-31'))).toEqual([]);
    });
  });

  it('stores and reads index bars', async () => {
    await withRollback(db, async (trx) => {
      const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
      if (!nifty) throw new Error('seed missing');
      const repo = new MarketDataRepository(trx);
      await repo.insertBars([bar(nifty.id, 'market', '2026-10-05T03:45:00Z', 25_100.5)]);
      expect((await repo.latestQuote({ kind: 'market', id: nifty.id }, 'MOCK'))?.price).toBe(25_100.5);
    });
  });
});
```
`backend/tests/integration/systemLogRepository.test.ts`:
```ts
import { afterAll, describe, expect, it } from 'vitest';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { AppError } from '../../src/utils/errors.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('SystemLogRepository', () => {
  it('records a job run from start to finish with counts', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const runId = await repo.startRun({ service: 'MarketDataService', jobName: 'market.sync.intraday', operation: 'sync' });
      expect((await repo.recentRuns(1))[0]).toMatchObject({ id: runId, status: 'STARTED' });

      await repo.finishRun(runId, { status: 'PARTIAL', counts: { fetched: 100, inserted: 95, skipped: 2, failed: 3 }, message: '3 symbols failed' });
      const [run] = await repo.recentRuns(1);
      expect(run).toMatchObject({
        status: 'PARTIAL', recordsFetched: 100, recordsInserted: 95, recordsSkipped: 2, recordsFailed: 3,
        recordsProcessed: 100, message: '3 symbols failed',
      });
      expect(run?.finishedAt).toBeInstanceOf(Date);
      expect(run?.executionTimeMs).toBeGreaterThanOrEqual(0);
    });
  });

  it('stores structured error details without secrets-bearing URLs', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const runId = await repo.startRun({ service: 'NewsService', jobName: 'news.sync', operation: 'sync' });
      const error = new AppError('AUTH_FAILED', 'Authentication failed calling https://newsapi.org/v2/everything', { details: { status: 401 } });
      await repo.finishRun(runId, { status: 'FAILED', counts: { fetched: 0, inserted: 0, skipped: 0, failed: 1 }, error });
      const [run] = await repo.recentRuns(1);
      expect(run?.errorDetails).toMatchObject({ code: 'AUTH_FAILED', details: { status: 401 } });
    });
  });

  it('rejects finishing an unknown run', async () => {
    await withRollback(db, async (trx) => {
      await expect(
        new SystemLogRepository(trx).finishRun('00000000-0000-0000-0000-000000000000', { status: 'SUCCESS', counts: { fetched: 0, inserted: 0, skipped: 0, failed: 0 } }),
      ).rejects.toMatchObject({ code: 'NOT_FOUND' });
    });
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test`
Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/repositories/MarketDataRepository.ts`

```ts
import type { Database } from '../database/db.js';
import { requireNumber, toNumber } from '../database/convert.js';
import type { BarInterval, DataMode } from '../domain/enums.js';
import type { Bar, InstrumentRef, LatestQuote } from '../domain/types.js';
import { AppError } from '../utils/errors.js';

const CHUNK = 500;

const ownerColumns = (ref: InstrumentRef) =>
  ref.kind === 'stock' ? { stock_id: ref.id, market_id: null } : { stock_id: null, market_id: ref.id };

export class MarketDataRepository {
  constructor(private readonly db: Database) {}

  async insertBars(bars: Bar[]): Promise<{ inserted: number; skipped: number }> {
    let inserted = 0;
    for (let i = 0; i < bars.length; i += CHUNK) {
      const chunk = bars.slice(i, i + CHUNK);
      const rows = await this.db.insertInto('market_data')
        .values(chunk.map((b) => ({
          ...ownerColumns(b.instrument), data_mode: b.dataMode, timeframe: b.timeframe, ts: b.ts,
          open: b.open, high: b.high, low: b.low, close: b.close, adjusted_close: b.adjustedClose,
          volume: b.volume, change: b.change, change_percent: b.changePercent, vwap: b.vwap, source: b.source,
        })))
        .onConflict((oc) => oc.doNothing())
        .returning('id')
        .execute();
      inserted += rows.length;
    }
    return { inserted, skipped: bars.length - inserted };
  }

  async latestQuote(ref: InstrumentRef, mode: DataMode): Promise<LatestQuote | null> {
    const column = ref.kind === 'stock' ? 'stock_id' : 'market_id';
    const row = await this.db.selectFrom('v_latest_quotes').selectAll()
      .where(column, '=', ref.id).where('data_mode', '=', mode).executeTakeFirst();
    if (!row) return null;
    if (row.ts === null || row.timeframe === null || row.source === null || row.data_mode === null) {
      throw new AppError('INTERNAL', 'v_latest_quotes returned an incomplete row', { details: { ref } });
    }
    return {
      instrument: ref, dataMode: row.data_mode, timeframe: row.timeframe, ts: row.ts,
      price: requireNumber(row.price, 'price'), change: toNumber(row.change), changePercent: toNumber(row.change_percent),
      volume: requireNumber(row.volume, 'volume'), source: row.source,
    };
  }

  async getBars(ref: InstrumentRef, mode: DataMode, timeframe: BarInterval, from: Date, to: Date): Promise<Bar[]> {
    const column = ref.kind === 'stock' ? 'stock_id' : 'market_id';
    const rows = await this.db.selectFrom('market_data').selectAll()
      .where(column, '=', ref.id).where('data_mode', '=', mode).where('timeframe', '=', timeframe)
      .where('ts', '>=', from).where('ts', '<=', to)
      .orderBy('ts').execute();
    return rows.map((r) => ({
      instrument: ref, dataMode: r.data_mode, timeframe: r.timeframe, ts: r.ts,
      open: requireNumber(r.open, 'open'), high: requireNumber(r.high, 'high'), low: requireNumber(r.low, 'low'),
      close: requireNumber(r.close, 'close'), adjustedClose: toNumber(r.adjusted_close),
      volume: requireNumber(r.volume, 'volume'), change: toNumber(r.change), changePercent: toNumber(r.change_percent),
      vwap: toNumber(r.vwap), source: r.source,
    }));
  }
}
```
`backend/src/repositories/SystemLogRepository.ts`:
```ts
import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import type { JobStatus } from '../domain/enums.js';
import { AppError, isAppError } from '../utils/errors.js';

export interface JobRun {
  id: string;
  service: string;
  jobName: string | null;
  operation: string;
  status: JobStatus;
  message: string | null;
  recordsFetched: number;
  recordsInserted: number;
  recordsSkipped: number;
  recordsFailed: number;
  recordsProcessed: number;
  startedAt: Date | null;
  finishedAt: Date | null;
  executionTimeMs: number | null;
  errorDetails: unknown;
}

export interface RunCounts {
  fetched: number;
  inserted: number;
  skipped: number;
  failed: number;
}

function serializeError(error: unknown): Record<string, unknown> {
  if (isAppError(error)) return { code: error.code, message: error.message, details: error.details ?? null };
  if (error instanceof Error) return { code: 'INTERNAL', message: error.message };
  return { code: 'INTERNAL', message: String(error) };
}

export class SystemLogRepository {
  constructor(private readonly db: Database) {}

  async startRun(input: { service: string; jobName: string; operation: string }): Promise<string> {
    const id = randomUUID();
    await this.db.insertInto('system_logs').values({
      id, job_run_id: id, service: input.service, job_name: input.jobName, operation: input.operation,
      status: 'STARTED', started_at: sql`now()`,
    }).execute();
    return id;
  }

  async finishRun(
    runId: string,
    result: { status: Exclude<JobStatus, 'STARTED'>; counts: RunCounts; message?: string; error?: unknown },
  ): Promise<void> {
    const { counts } = result;
    const updated = await this.db.updateTable('system_logs').set({
      status: result.status,
      message: result.message ?? null,
      records_fetched: counts.fetched,
      records_inserted: counts.inserted,
      records_skipped: counts.skipped,
      records_failed: counts.failed,
      records_processed: counts.inserted + counts.skipped + counts.failed,
      finished_at: sql`now()`,
      execution_time_ms: sql`greatest(0, (extract(epoch from (now() - started_at)) * 1000)::int)`,
      error_details: result.error === undefined ? null : sql`${JSON.stringify(serializeError(result.error))}::jsonb`,
    }).where('id', '=', runId).executeTakeFirst();
    if (Number(updated.numUpdatedRows) === 0) {
      throw new AppError('NOT_FOUND', `Job run ${runId} not found`, { details: { runId } });
    }
  }

  async recentRuns(limit = 20): Promise<JobRun[]> {
    const rows = await this.db.selectFrom('system_logs').selectAll()
      .orderBy('created_at', 'desc').orderBy('started_at', 'desc').limit(limit).execute();
    return rows.map((r) => ({
      id: r.id, service: r.service, jobName: r.job_name, operation: r.operation, status: r.status, message: r.message,
      recordsFetched: r.records_fetched, recordsInserted: r.records_inserted, recordsSkipped: r.records_skipped,
      recordsFailed: r.records_failed, recordsProcessed: r.records_processed, startedAt: r.started_at,
      finishedAt: r.finished_at, executionTimeMs: r.execution_time_ms, errorDetails: r.error_details,
    }));
  }
}
```
Note: within one transaction `now()` is constant, so both test runs share `created_at`. `recentRuns(1)` returning the newest relies on the second sort key. If ordering is ambiguous in the test, order by `clock_timestamp()`-based `started_at`: set `started_at: sql\`clock_timestamp()\`` in `startRun` and record a ruling.

- [ ] **Step 4: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "feat(backend): market-data and system-log repositories" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 8: IST time utilities and MarketCalendarService (canonical, SQL-parity tested)

**Files:**
- Create: `backend/src/utils/ist.ts`, `backend/src/services/MarketCalendarService.ts`, `backend/tests/fixtures/calendarCases.ts`
- Test: `backend/tests/unit/marketCalendar.test.ts`, `backend/tests/integration/marketCalendarParity.test.ts`

**Interfaces:**
- Consumes: `Holiday` (Task 6), `Cache`/`MemoryCache` (Task 4), `HolidayRepository` (Task 6, parity test only).
- Produces:
  - from `ist.ts`:
    - `toIst(at: Date): { date: string; msOfDay: number; isoWeekday: number }`
    - `istToUtc(date: string, time: string): Date`
    - `addDays(date, n): string`
    - `isoWeekdayOf(date): number`
  - `interface HolidayLookup { listBetween(exchange, from, to): Promise<Holiday[]> }`
  - `type MarketPhase = 'OPEN'|'CLOSED'|'WEEKEND'|'HOLIDAY'`
  - `MarketStatus { exchange; isOpen; phase; holiday: string|null; nextOpen: Date|null; asOf: Date }`
  - `MarketCalendarService(holidays: HolidayLookup, cache: Cache)` with methods:
    - `isOpen(exchange, at): Promise<boolean>`
    - `nextOpen(exchange, at): Promise<Date|null>`
    - `isTradingDay(exchange, date): Promise<boolean>`
    - `status(exchange, at): Promise<MarketStatus>`
  - `REGULAR_SESSION = { open: '09:15:00', close: '15:30:00' }`

- [ ] **Step 1: Write the shared cases** `backend/tests/fixtures/calendarCases.ts` (the same cases as `supabase/tests/database/03_market_calendar.test.sql`)

```ts
import type { Holiday } from '../../src/domain/types.js';

export const CASE_WINDOW = { from: '2026-10-05', to: '2026-10-12' } as const;

export const CASE_HOLIDAYS: Holiday[] = [
  { exchange: 'NSE', date: '2026-10-07', description: 'TEST HOLIDAY (Wed)', specialOpen: null, specialClose: null },
  { exchange: 'NSE', date: '2026-10-11', description: 'TEST SPECIAL SESSION (Sun)', specialOpen: '18:00:00', specialClose: '19:00:00' },
];

export const OPEN_CASES: ReadonlyArray<{ exchange: 'NSE' | 'BSE'; at: string; open: boolean; label: string }> = [
  { exchange: 'NSE', at: '2026-10-05T09:14:59+05:30', open: false, label: '09:14:59 IST closed' },
  { exchange: 'NSE', at: '2026-10-05T09:15:00+05:30', open: true, label: '09:15 IST open' },
  { exchange: 'NSE', at: '2026-10-05T15:29:59+05:30', open: true, label: '15:29:59 IST open' },
  { exchange: 'NSE', at: '2026-10-05T15:30:00+05:30', open: false, label: '15:30 IST closed' },
  { exchange: 'NSE', at: '2026-10-05T03:45:00Z', open: true, label: '03:45 UTC = 09:15 IST open' },
  { exchange: 'NSE', at: '2026-10-05T22:00:00Z', open: false, label: '22:00 UTC = 03:30 IST next day closed' },
  { exchange: 'NSE', at: '2026-10-10T11:00:00+05:30', open: false, label: 'Saturday closed' },
  { exchange: 'NSE', at: '2026-10-07T11:00:00+05:30', open: false, label: 'holiday closed' },
  { exchange: 'BSE', at: '2026-10-07T11:00:00+05:30', open: true, label: 'holiday is per-exchange' },
  { exchange: 'NSE', at: '2026-10-11T18:30:00+05:30', open: true, label: 'special session open' },
  { exchange: 'NSE', at: '2026-10-11T17:59:00+05:30', open: false, label: 'before special session closed' },
];

export const NEXT_OPEN_CASES: ReadonlyArray<{ at: string; next: string; label: string }> = [
  { at: '2026-10-05T09:00:00+05:30', next: '2026-10-05T09:15:00+05:30', label: 'pre-open -> same day' },
  { at: '2026-10-05T16:00:00+05:30', next: '2026-10-06T09:15:00+05:30', label: 'after close -> next day' },
  { at: '2026-10-06T16:00:00+05:30', next: '2026-10-08T09:15:00+05:30', label: 'skips holiday' },
  { at: '2026-10-09T16:00:00+05:30', next: '2026-10-11T18:00:00+05:30', label: 'weekend special session' },
];
```

- [ ] **Step 2: Write the failing tests** `backend/tests/unit/marketCalendar.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import type { Holiday } from '../../src/domain/types.js';
import { MarketCalendarService, type HolidayLookup } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { istToUtc, toIst } from '../../src/utils/ist.js';
import { CASE_HOLIDAYS, NEXT_OPEN_CASES, OPEN_CASES } from '../fixtures/calendarCases.js';

class InMemoryHolidays implements HolidayLookup {
  calls = 0;
  constructor(private readonly holidays: Holiday[]) {}
  async listBetween(exchange: Holiday['exchange'], from: string, to: string): Promise<Holiday[]> {
    this.calls += 1;
    return this.holidays.filter((h) => h.exchange === exchange && h.date >= from && h.date <= to);
  }
}

const service = (holidays: Holiday[] = CASE_HOLIDAYS) => new MarketCalendarService(new InMemoryHolidays(holidays), new MemoryCache());

describe('ist utils', () => {
  it('converts across the UTC/IST date boundary', () => {
    expect(toIst(new Date('2026-10-05T22:00:00Z'))).toMatchObject({ date: '2026-10-06', isoWeekday: 2 });
    expect(istToUtc('2026-10-05', '09:15:00').toISOString()).toBe('2026-10-05T03:45:00.000Z');
  });
});

describe('MarketCalendarService', () => {
  it.each(OPEN_CASES)('isOpen: $label', async ({ exchange, at, open }) => {
    expect(await service().isOpen(exchange, new Date(at))).toBe(open);
  });

  it.each(NEXT_OPEN_CASES)('nextOpen: $label', async ({ at, next }) => {
    expect((await service().nextOpen('NSE', new Date(at)))?.toISOString()).toBe(new Date(next).toISOString());
  });

  it('finds the next session across a year boundary', async () => {
    const next = await service([]).nextOpen('NSE', new Date('2026-12-31T16:00:00+05:30'));
    expect(next?.toISOString()).toBe('2027-01-01T03:45:00.000Z');
  });

  it('reports status phases with holiday names and next open', async () => {
    const s = service();
    expect(await s.status('NSE', new Date('2026-10-05T10:00:00+05:30'))).toMatchObject({ isOpen: true, phase: 'OPEN', holiday: null });
    expect(await s.status('NSE', new Date('2026-10-05T16:00:00+05:30'))).toMatchObject({ isOpen: false, phase: 'CLOSED' });
    expect(await s.status('NSE', new Date('2026-10-10T11:00:00+05:30'))).toMatchObject({ phase: 'WEEKEND' });
    const holiday = await s.status('NSE', new Date('2026-10-07T11:00:00+05:30'));
    expect(holiday).toMatchObject({ phase: 'HOLIDAY', holiday: 'TEST HOLIDAY (Wed)' });
    expect(holiday.nextOpen?.toISOString()).toBe('2026-10-08T03:45:00.000Z');
  });

  it('knows trading days (special sessions count)', async () => {
    const s = service();
    expect(await s.isTradingDay('NSE', '2026-10-05')).toBe(true);
    expect(await s.isTradingDay('NSE', '2026-10-07')).toBe(false);
    expect(await s.isTradingDay('NSE', '2026-10-10')).toBe(false);
    expect(await s.isTradingDay('NSE', '2026-10-11')).toBe(true);
  });

  it('caches holiday lookups per exchange and year', async () => {
    const lookup = new InMemoryHolidays(CASE_HOLIDAYS);
    const s = new MarketCalendarService(lookup, new MemoryCache());
    await s.isOpen('NSE', new Date('2026-10-05T10:00:00+05:30'));
    await s.isOpen('NSE', new Date('2026-10-06T10:00:00+05:30'));
    expect(lookup.calls).toBe(1);
  });
});
```
`backend/tests/integration/marketCalendarParity.test.ts`:
```ts
import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { CASE_HOLIDAYS, CASE_WINDOW, NEXT_OPEN_CASES, OPEN_CASES } from '../fixtures/calendarCases.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('MarketCalendarService ↔ SQL parity', () => {
  it('agrees with is_market_open and next_market_open on every shared case', async () => {
    await withRollback(db, async (trx) => {
      await trx.deleteFrom('exchange_holidays').where('holiday_date', '>=', CASE_WINDOW.from).where('holiday_date', '<=', CASE_WINDOW.to).execute();
      await trx.insertInto('exchange_holidays').values(CASE_HOLIDAYS.map((h) => ({
        exchange: h.exchange, holiday_date: h.date, description: h.description, special_open: h.specialOpen, special_close: h.specialClose,
      }))).execute();
      const ts = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());

      for (const c of OPEN_CASES) {
        const { rows } = await sql<{ open: boolean }>`select public.is_market_open(${c.exchange}::public.exchange_code, ${c.at}::timestamptz) as open`.execute(trx);
        expect(rows[0]?.open, `SQL: ${c.label}`).toBe(c.open);
        expect(await ts.isOpen(c.exchange, new Date(c.at)), `TS: ${c.label}`).toBe(c.open);
      }
      for (const c of NEXT_OPEN_CASES) {
        const { rows } = await sql<{ next: Date }>`select public.next_market_open('NSE', ${c.at}::timestamptz) as next`.execute(trx);
        const expected = new Date(c.next).toISOString();
        expect(rows[0]?.next.toISOString(), `SQL: ${c.label}`).toBe(expected);
        expect((await ts.nextOpen('NSE', new Date(c.at)))?.toISOString(), `TS: ${c.label}`).toBe(expected);
      }
    });
  });
});
```

- [ ] **Step 3: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test`
Expected: FAIL (modules not found).

- [ ] **Step 4: Implement** `backend/src/utils/ist.ts`

```ts
/** Asia/Kolkata is a fixed +05:30 offset (no DST), so arithmetic is exact. */
export const IST_OFFSET_MS = 330 * 60 * 1000;
const DAY_MS = 86_400_000;

export function toIst(at: Date): { date: string; msOfDay: number; isoWeekday: number } {
  const shifted = new Date(at.getTime() + IST_OFFSET_MS);
  const msOfDay = shifted.getTime() - Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate());
  return { date: shifted.toISOString().slice(0, 10), msOfDay, isoWeekday: ((shifted.getUTCDay() + 6) % 7) + 1 };
}

function parseDate(date: string): [number, number, number] {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  if (!m) throw new TypeError(`Invalid date ${date}, expected YYYY-MM-DD`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}

function parseTime(time: string): number {
  const m = /^(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(time);
  if (!m) throw new TypeError(`Invalid time ${time}, expected HH:MM[:SS]`);
  return (Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3] ?? 0)) * 1000;
}

/** IST wall-clock date + time -> UTC instant. */
export function istToUtc(date: string, time: string): Date {
  const [y, mo, d] = parseDate(date);
  return new Date(Date.UTC(y, mo - 1, d) + parseTime(time) - IST_OFFSET_MS);
}

export function addDays(date: string, days: number): string {
  const [y, mo, d] = parseDate(date);
  return new Date(Date.UTC(y, mo - 1, d) + days * DAY_MS).toISOString().slice(0, 10);
}

export function isoWeekdayOf(date: string): number {
  const [y, mo, d] = parseDate(date);
  return ((new Date(Date.UTC(y, mo - 1, d)).getUTCDay() + 6) % 7) + 1;
}
```
`backend/src/services/MarketCalendarService.ts`:
```ts
import type { Exchange } from '../domain/enums.js';
import type { Holiday } from '../domain/types.js';
import type { Cache } from '../utils/cache.js';
import { addDays, isoWeekdayOf, istToUtc, toIst } from '../utils/ist.js';

export interface HolidayLookup {
  listBetween(exchange: Exchange, from: string, to: string): Promise<Holiday[]>;
}

export const REGULAR_SESSION = { open: '09:15:00', close: '15:30:00' } as const;
const SEARCH_DAYS = 30;
const HOLIDAY_TTL_MS = 60 * 60 * 1000;

export type MarketPhase = 'OPEN' | 'CLOSED' | 'WEEKEND' | 'HOLIDAY';

export interface MarketStatus {
  exchange: Exchange;
  isOpen: boolean;
  phase: MarketPhase;
  holiday: string | null;
  nextOpen: Date | null;
  asOf: Date;
}

interface Session {
  open: Date;
  close: Date;
}

/** Canonical market calendar (SQL is_market_open / next_market_open mirror it; parity-tested). */
export class MarketCalendarService {
  constructor(
    private readonly holidays: HolidayLookup,
    private readonly cache: Cache,
  ) {}

  private async holidayOn(exchange: Exchange, date: string): Promise<Holiday | undefined> {
    const year = date.slice(0, 4);
    const list = await this.cache.getOrSet(`calendar:holidays:${exchange}:${year}`, HOLIDAY_TTL_MS, () =>
      this.holidays.listBetween(exchange, `${year}-01-01`, `${year}-12-31`),
    );
    return list.find((h) => h.date === date);
  }

  private async sessionOn(exchange: Exchange, date: string): Promise<Session | null> {
    const holiday = await this.holidayOn(exchange, date);
    if (holiday) {
      if (holiday.specialOpen === null || holiday.specialClose === null) return null;
      return { open: istToUtc(date, holiday.specialOpen), close: istToUtc(date, holiday.specialClose) };
    }
    if (isoWeekdayOf(date) >= 6) return null;
    return { open: istToUtc(date, REGULAR_SESSION.open), close: istToUtc(date, REGULAR_SESSION.close) };
  }

  async isOpen(exchange: Exchange, at: Date): Promise<boolean> {
    const session = await this.sessionOn(exchange, toIst(at).date);
    return session !== null && at >= session.open && at < session.close;
  }

  async nextOpen(exchange: Exchange, at: Date): Promise<Date | null> {
    const start = toIst(at).date;
    for (let i = 0; i <= SEARCH_DAYS; i += 1) {
      const session = await this.sessionOn(exchange, addDays(start, i));
      if (session && session.open > at) return session.open;
    }
    return null;
  }

  async isTradingDay(exchange: Exchange, date: string): Promise<boolean> {
    return (await this.sessionOn(exchange, date)) !== null;
  }

  async status(exchange: Exchange, at: Date): Promise<MarketStatus> {
    const { date, isoWeekday } = toIst(at);
    const isOpen = await this.isOpen(exchange, at);
    const holiday = await this.holidayOn(exchange, date);
    let phase: MarketPhase = 'CLOSED';
    if (isOpen) phase = 'OPEN';
    else if (holiday && holiday.specialOpen === null) phase = 'HOLIDAY';
    else if (!holiday && isoWeekday >= 6) phase = 'WEEKEND';
    return {
      exchange,
      isOpen,
      phase,
      holiday: holiday?.description ?? null,
      nextOpen: isOpen ? null : await this.nextOpen(exchange, at),
      asOf: at,
    };
  }
}
```

- [ ] **Step 5: Run the gate**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
Expected: PASS, including the parity test under `TZ=UTC`.

- [ ] **Step 6: Commit**

```bash
git add backend
git commit -m "feat(backend): IST utilities and MarketCalendarService with SQL parity tests" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 9: DI container, Fastify app, `/api/health`, server entrypoint

**Files:**
- Create: `backend/src/container.ts`, `backend/src/http/envelope.ts`, `backend/src/http/errorHandler.ts`, `backend/src/routes/health.ts`, `backend/src/app.ts`, `backend/src/server.ts`
- Test: `backend/tests/integration/app.test.ts`

**Interfaces:**
- Consumes: everything above.
- Produces:
  - `Container { config; logger; db; cache; repositories: { stocks; markets; holidays; settings; marketData; systemLogs }; services: { calendar }; close(): Promise<void> }`
  - `createContainer(config, overrides?: Partial<Pick<Container, 'logger'|'db'|'cache'>>): Container`
  - `buildApp(container): Promise<FastifyInstance>`
  - `ok(data, meta)`, `errorBody(code, message, details?)`
  - `GET /api/health` returns `{ data: { status, database, data_mode, providers, market, version }, meta: { data_mode, generated_at } }`: 200 when the DB is up, 503 when it is down

- [ ] **Step 1: Write the failing test** `backend/tests/integration/app.test.ts`

```ts
import { Writable } from 'node:stream';
import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createDatabase } from '../../src/database/db.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { LOCAL_DATABASE_URL } from './helpers.js';

const silent = createLogger({ level: 'silent', destination: new Writable({ write(_c, _e, cb) { cb(); } }) });
const config = loadConfig({ DATABASE_URL: process.env.DATABASE_URL ?? LOCAL_DATABASE_URL, OPENAI_API_KEY: 'sk-should-never-leak' });

describe('app', () => {
  const container = createContainer(config, { logger: silent });
  let app: FastifyInstance;
  beforeAll(async () => {
    app = await buildApp(container);
    app.get('/api/__boom/app-error', async () => { throw new AppError('NOT_FOUND', 'Stock XYZ not found'); });
    app.get('/api/__boom/bug', async () => { throw new Error('internal stack detail'); });
  });
  afterAll(async () => { await app.close(); await container.close(); });

  it('GET /api/health reports DB, config and NSE status in the envelope', async () => {
    const res = await app.inject({ method: 'GET', url: '/api/health' });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.data).toMatchObject({
      status: 'ok', database: 'up', data_mode: 'MOCK',
      providers: { market_data: 'mock', news: 'mock', fundamentals: 'mock', llm: 'mock' },
      market: { exchange: 'NSE' },
    });
    expect(['OPEN', 'CLOSED', 'WEEKEND', 'HOLIDAY']).toContain(body.data.market.phase);
    expect(body.meta).toMatchObject({ data_mode: 'MOCK' });
    expect(Number.isNaN(Date.parse(body.meta.generated_at))).toBe(false);
    expect(res.body).not.toContain('sk-should-never-leak');
  });

  it('maps AppError to its status and envelope, hides internal errors, and 404s unknown routes', async () => {
    const notFound = await app.inject({ method: 'GET', url: '/api/__boom/app-error' });
    expect(notFound.statusCode).toBe(404);
    expect(notFound.json()).toEqual({ error: { code: 'NOT_FOUND', message: 'Stock XYZ not found' } });

    const bug = await app.inject({ method: 'GET', url: '/api/__boom/bug' });
    expect(bug.statusCode).toBe(500);
    expect(bug.json()).toEqual({ error: { code: 'INTERNAL', message: 'Internal server error' } });

    const missing = await app.inject({ method: 'GET', url: '/api/nope' });
    expect(missing.statusCode).toBe(404);
    expect(missing.json().error.code).toBe('NOT_FOUND');
  });
});

describe('app with the database down', () => {
  it('answers /api/health quickly with 503 degraded', async () => {
    const db = createDatabase('postgresql://postgres:postgres@127.0.0.1:1/postgres', { max: 1 });
    const container = createContainer(config, { logger: silent, db });
    const app = await buildApp(container);
    const started = Date.now();
    const res = await app.inject({ method: 'GET', url: '/api/health' });
    expect(res.statusCode).toBe(503);
    expect(res.json().data).toMatchObject({ status: 'degraded', database: 'down', market: null, data_mode: 'MOCK' });
    expect(Date.now() - started).toBeLessThan(5000);
    await app.close();
    await container.close();
  });
});
```

- [ ] **Step 2: Run to verify it fails**

Run: `pnpm --filter @learning-stocks/backend test`
Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/container.ts`

```ts
import type { Logger } from 'pino';
import type { AppConfig } from './config/env.js';
import { createDatabase, type Database } from './database/db.js';
import { AppSettingsRepository } from './repositories/AppSettingsRepository.js';
import { HolidayRepository } from './repositories/HolidayRepository.js';
import { MarketDataRepository } from './repositories/MarketDataRepository.js';
import { MarketRepository } from './repositories/MarketRepository.js';
import { StockRepository } from './repositories/StockRepository.js';
import { SystemLogRepository } from './repositories/SystemLogRepository.js';
import { MarketCalendarService } from './services/MarketCalendarService.js';
import { type Cache, MemoryCache } from './utils/cache.js';
import { createLogger } from './utils/logger.js';

export interface Container {
  config: AppConfig;
  logger: Logger;
  db: Database;
  cache: Cache;
  repositories: {
    stocks: StockRepository;
    markets: MarketRepository;
    holidays: HolidayRepository;
    settings: AppSettingsRepository;
    marketData: MarketDataRepository;
    systemLogs: SystemLogRepository;
  };
  services: { calendar: MarketCalendarService };
  close(): Promise<void>;
}

/** Composition root: the only place concrete implementations are chosen. */
export function createContainer(
  config: AppConfig,
  overrides: Partial<Pick<Container, 'logger' | 'db' | 'cache'>> = {},
): Container {
  const logger = overrides.logger ?? createLogger({ level: config.logLevel });
  const db = overrides.db ?? createDatabase(config.databaseUrl);
  const cache = overrides.cache ?? new MemoryCache();
  const holidays = new HolidayRepository(db);
  return {
    config,
    logger,
    db,
    cache,
    repositories: {
      stocks: new StockRepository(db),
      markets: new MarketRepository(db),
      holidays,
      settings: new AppSettingsRepository(db),
      marketData: new MarketDataRepository(db),
      systemLogs: new SystemLogRepository(db),
    },
    services: { calendar: new MarketCalendarService(holidays, cache) },
    close: () => db.destroy(),
  };
}
```
`backend/src/http/envelope.ts`:
```ts
import type { DataMode } from '../domain/enums.js';
import type { ErrorCode } from '../utils/errors.js';

export interface Meta {
  data_mode: DataMode;
  generated_at: string;
}

export function meta(dataMode: DataMode, now: Date = new Date()): Meta {
  return { data_mode: dataMode, generated_at: now.toISOString() };
}

export function ok<T>(data: T, m: Meta): { data: T; meta: Meta } {
  return { data, meta: m };
}

export function errorBody(code: ErrorCode, message: string, details?: Record<string, unknown>) {
  return { error: details ? { code, message, details } : { code, message } };
}
```
`backend/src/http/errorHandler.ts`:
```ts
import type { FastifyError, FastifyInstance } from 'fastify';
import { isAppError } from '../utils/errors.js';
import { errorBody } from './envelope.js';

export function registerErrorHandling(app: FastifyInstance): void {
  app.setErrorHandler((error: FastifyError, request, reply) => {
    if (isAppError(error)) {
      if (error.httpStatus >= 500) request.log.error({ err: error }, error.message);
      return reply.code(error.httpStatus).send(errorBody(error.code, error.message, error.details));
    }
    if (error.validation) {
      return reply.code(400).send(errorBody('VALIDATION', error.message));
    }
    request.log.error({ err: error }, 'unhandled error');
    return reply.code(500).send(errorBody('INTERNAL', 'Internal server error'));
  });

  app.setNotFoundHandler((request, reply) =>
    reply.code(404).send(errorBody('NOT_FOUND', `Route ${request.method} ${request.url.split('?')[0]} not found`)),
  );
}
```
Note: the AppError branch sends `details` when present, so the test route must throw without details to match `toEqual`. It does.
`backend/src/routes/health.ts`:
```ts
import type { FastifyInstance } from 'fastify';
import type { Container } from '../container.js';
import { pingDatabase } from '../database/db.js';
import { meta, ok } from '../http/envelope.js';

const VERSION = '0.2.0';

export async function healthRoutes(app: FastifyInstance, c: Container): Promise<void> {
  app.get('/health', async (_request, reply) => {
    const now = new Date();
    const dbUp = await pingDatabase(c.db);
    let market: Record<string, unknown> | null = null;
    if (dbUp) {
      const s = await c.services.calendar.status('NSE', now);
      market = {
        exchange: s.exchange, is_open: s.isOpen, phase: s.phase, holiday: s.holiday,
        next_open: s.nextOpen ? s.nextOpen.toISOString() : null,
      };
    }
    const body = ok(
      {
        status: dbUp ? 'ok' : 'degraded',
        database: dbUp ? 'up' : 'down',
        data_mode: c.config.dataMode,
        providers: {
          market_data: c.config.providers.marketData,
          news: c.config.providers.news,
          fundamentals: c.config.providers.fundamentals,
          llm: c.config.providers.llm,
        },
        market,
        version: VERSION,
      },
      meta(c.config.dataMode, now),
    );
    return reply.code(dbUp ? 200 : 503).send(body);
  });
}
```
`backend/src/app.ts`:
```ts
import { randomUUID } from 'node:crypto';
import Fastify, { type FastifyInstance } from 'fastify';
import type { Container } from './container.js';
import { registerErrorHandling } from './http/errorHandler.js';
import { healthRoutes } from './routes/health.js';

export async function buildApp(c: Container): Promise<FastifyInstance> {
  const app = Fastify({ loggerInstance: c.logger, genReqId: () => randomUUID() });
  registerErrorHandling(app);
  await app.register(async (api) => healthRoutes(api, c), { prefix: '/api' });
  return app;
}
```
`backend/src/server.ts`:
```ts
import { buildApp } from './app.js';
import { type AppConfig, ConfigError, loadConfig } from './config/env.js';
import { loadDotEnv } from './config/dotenv.js';
import { createContainer } from './container.js';

function readConfig(): AppConfig {
  try {
    return loadConfig(process.env);
  } catch (error) {
    if (error instanceof ConfigError) {
      console.error(error.message);
      process.exit(1);
    }
    throw error;
  }
}

loadDotEnv();
const config = readConfig();
const container = createContainer(config);
const app = await buildApp(container);
await app.listen({ host: config.host, port: config.port });
container.logger.info({ dataMode: config.dataMode, providers: config.providers }, 'backend started');

const shutdown = async (signal: string) => {
  container.logger.info({ signal }, 'shutting down');
  await app.close();
  await container.close();
  process.exit(0);
};
process.once('SIGINT', () => void shutdown('SIGINT'));
process.once('SIGTERM', () => void shutdown('SIGTERM'));
```
If `loggerInstance` with a pino `Logger` fails Fastify's types, record a ruling and cast via `FastifyBaseLogger`. Do not fall back to `logger: true`, because that would lose redaction.

- [ ] **Step 4: Run the gate, then a real start**

Run: `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
Expected: PASS.
Then: `pnpm dev` (in the background) and `curl -s http://127.0.0.1:4000/api/health`.
Expected: `{"data":{"status":"ok","database":"up","data_mode":"MOCK",...},"meta":{...}}`. Stop the server.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "feat(backend): DI container, Fastify app, error envelope and /api/health" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 10: Docs, housekeeping and Phase 2 verification

**Files:**
- Create: `README.md`, `docs/architecture.md`
- Modify: `docs/database.md` (bar `ts` convention), `PRD.md` (§7.10 and §11: `INVALID_QUANTITY` is raised as SQLSTATE 22023, not stored), `.gitignore` (`supabase/snippets/`), `IMPLEMENTATION_PLAN.md` (append this phase's tasks and mark Phase 2 ✅)

- [ ] **Step 1: Write `README.md`.** Cover:
  - an overview with the disclaimer
  - prerequisites (Node ≥ 22.9, pnpm, Docker)
  - setup: `pnpm install`, `cp .env.example .env`
  - running the database: `db:start`, `db:reset`, `db:test`, Studio URL
  - running the backend: `pnpm dev`, then `curl http://127.0.0.1:4000/api/health`
  - testing: `pnpm test` (needs DB) and `pnpm --filter @learning-stocks/backend test:unit` (no DB)
  - regenerating DB types: `pnpm --filter @learning-stocks/backend db:types`
  - mock mode
  - a phase status table
  - troubleshooting: Docker not running, port 54322 busy, config errors

- [ ] **Step 2: Write `docs/architecture.md`.** Cover:
  - the layer diagram (config → utils → database → repositories → services → container → app/routes)
  - the DI rule (only `container.ts` instantiates concrete classes)
  - the error taxonomy table and retry policy
  - the API envelope
  - logging and redaction rules
  - time conventions (UTC storage, IST logic, the bar `ts` = open-time convention, date strings)
  - the testing strategy (unit vs rolled-back integration, TZ=UTC, the parity tests)

- [ ] **Step 3: Apply the doc corrections and housekeeping** listed under Files. In `docs/database.md`, add the bar convention under Conventions:

| Bar timestamps | `market_data.ts` = the bar's **open** time (UTC instant). Daily bars are stamped at that day's session open (09:15 IST, or the special session's open) |

- [ ] **Step 4: Full verification**

```bash
pnpm install --frozen-lockfile
pnpm db:reset && pnpm db:test
pnpm --filter @learning-stocks/backend db:types && git diff --exit-code backend/src/database/types.generated.ts
pnpm typecheck && pnpm test && pnpm lint && pnpm format:check
pnpm --filter @learning-stocks/backend build
```
Expected: pgTAP 113/113, `types.generated.ts` unchanged, every backend test PASS, lint and format clean, and the build emits `backend/dist/server.js`. Then start it with `pnpm dev` and `curl` `/api/health` → 200 envelope.

- [ ] **Step 5: Commit**

```bash
git add README.md docs PRD.md .gitignore IMPLEMENTATION_PLAN.md
git commit -m "docs: README, architecture guide, bar timestamp convention; mark Phase 2 complete" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```
Then run the final whole-branch review (a fresh reviewer on the most capable model), do one fix pass, and **stop for approval before Phase 3**.

---

## Verification (end of phase)

- `pnpm test` runs unit and integration tests under TZ=UTC, all green: config, errors, retry, HTTP, cache, logger, conversion, DB layer, enum parity, repositories, calendar (including SQL parity) and app/health.
- `pnpm typecheck`, `pnpm lint` and `pnpm format:check` are clean. `pnpm --filter @learning-stocks/backend build` succeeds.
- `pnpm dev` starts with an empty `.env`, and `curl http://127.0.0.1:4000/api/health` returns 200 `{ data: { status: "ok", database: "up", data_mode: "MOCK", market: { phase … } }, meta }`.
- With the DB stopped (`pnpm db:stop`), `/api/health` returns 503 `degraded` within about 2 s.
- The pgTAP suite still passes 113/113 (no DB changes in this phase).
