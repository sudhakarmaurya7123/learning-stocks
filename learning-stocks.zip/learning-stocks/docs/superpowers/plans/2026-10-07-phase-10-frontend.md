# Phase 10: Frontend Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (Native, as in Phases 2–9) to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A Next.js research desk over the Phase 9 API — dashboard, stock page, admin — where every number is a stored fact with a visible age, no page load spends money, and nothing trades without a click.

**Architecture:** `packages/shared` holds zod response schemas, which are the contract: the frontend parses every response through them and a backend test parses real `inject` responses against the same schemas, so drift breaks a test rather than a page. The frontend is a client-rendered App Router app (`lib/api.ts` → typed fetch + parse, `lib/format.ts` → `en-IN`/IST, `lib/auth.ts` → supabase-js bearer token). Five small additive backend read routes close the PRD §3 gaps the API does not yet cover. Server components render shells; data fetching is client-side so the browser's own token is the only credential and no secret ever reaches the server bundle.

**Tech Stack:** Next 16.4.0 (App Router), React 19.3.0, Tailwind 4.3.3 (`@import 'tailwindcss'` + `@theme`), lightweight-charts 5.2.1, `@supabase/supabase-js` 2.117.2, zod 4.6.5, Vitest 5.0.3 + React Testing Library 16.3.3 + jsdom 30.1.2, Playwright (separate `test:e2e` script). Backend additions: none beyond existing deps.

**Spec:** [PRD.md](../../../PRD.md) §3 (features), §5 (₹ `en-IN`, IST), §12 (API), §14 (no LLM on page load), §15 (no secrets in the bundle), §20 (success criteria 1–26); [docs/api.md](../../api.md).

## Measured facts that shape this plan

Probed on 2026-10-07 against this repo and a live local Supabase. These replace assumptions; do not re-derive them.

1. **lightweight-charts 5 dropped `addCandlestickSeries()`, and renders every axis in UTC.** The library has no timezone option, so an intraday axis labels the NSE session `03:45–10:00` unless `localization.timeFormatter` and `timeScale.tickMarkFormatter` are supplied. It is `chart.addSeries(CandlestickSeries, opts, paneIndex?)`, with series definitions imported as values (`CandlestickSeries`, `LineSeries`, `HistogramSeries`). Verified by compiling real usage under TS 6 strict + `exactOptionalPropertyTypes`: clean. `createPriceLine` on the series draws the entry/SL/target lines. The package is **ESM-only** (`exports` has `import` but no `require`); `require()` throws `ERR_PACKAGE_PATH_NOT_EXPORTED`.
2. **`next build` rewrites `tsconfig.json`.** It forces `jsx: react-jsx` and appends `.next/dev/types/**/*.ts` to `include`. Write the file expecting that, and do not fight it in review.
3. **Tailwind 4 has no JS config in this setup.** `postcss.config.mjs` with `@tailwindcss/postcss`, and CSS-first `@import 'tailwindcss'; @theme { --color-bull: … }`. Verified by a clean `next build`.
4. **`Intl.NumberFormat.format(null)` returns `₹0.00`.** A missing value renders as a real price unless the formatter rejects null first. Same class of hazard: `Number(null) === 0`, `null ?? 0 === 0`.
5. **IST bugs are invisible on an IST machine.** Formatting `2026-10-07T09:50:00Z` without `timeZone: 'Asia/Kolkata'` gives `5:50 am` under `TZ=America/New_York` and the correct `3:20 pm` only by luck of the host. Tests run `TZ=UTC`; the IST test must therefore assert the IST string.
6. **Market cap needs Cr/L.** `₹1,63,28,39,13,46,312.20` is correct `en-IN` grouping and unreadable; the UI shows `₹16,32,839.13 Cr` (16,328,391,346,312 / 10⁷ = 16,32,839.13 — verify the arithmetic, do not copy a remembered figure). The `en-IN` short time contains **no** U+202F narrow space (checked by codepoint), so `toBe('… 3:20 pm')` is a safe assertion.
7. **Local GoTrue signs ES256 via JWKS, and the backend already accepts it.** JWKS at `/auth/v1/.well-known/jwks.json` serves one ES256 EC key; a real password-grant token verified against the backend's exact settings (`algorithms: ['HS256','RS256','ES256']`, `issuer: <SUPABASE_URL>/auth/v1`, `audience: 'authenticated'`) — **verify OK**. So a browser login works with `JWT_SECRET` blank, which is how `.env` ships. **No backend auth test covers this path** (every existing one passes `jwksUrl: null`), which is why Task 9 adds one.
8. **`auth.users` and `user_profiles` are both empty (0 rows).** The first signup becomes OWNER via Phase 1's `handle_new_user()`. The owner must perform that signup; no task may create a user.
9. **`site_url` in `supabase/config.toml` is already `http://127.0.0.1:3000`** and `CORS_ORIGIN` defaults to the same. Two separate reasons to use `127.0.0.1` everywhere, and they are different mechanisms — do not conflate them in the README:
   - **The page origin** must equal `CORS_ORIGIN` byte-for-byte, so the dev server binds `127.0.0.1` (`next dev -H 127.0.0.1`). A page served from `localhost:3000` is a different origin and the API refuses it.
   - **The API URL** should also say `127.0.0.1` because `localhost` may resolve to `::1` while the API binds `127.0.0.1` — a connection failure, not a CORS failure. `.env` currently says `localhost`.

13. **`packages/shared` cannot use `.js`-suffixed relative imports.** The backend's NodeNext resolution *requires* them (`TS2835`), and Next 16's Turbopack *rejects* them (`Module not found: './envelope.js'`) — `transpilePackages` does not help, and the `webpack` config hook is ignored because Turbopack is the default. **Measured resolution:** give every module its own `exports` subpath and have modules reference each other **by the package name**, never by a relative path. Both toolchains then compile clean. Also verified in the same probe: an async `params` dynamic route (`params: Promise<{symbol: string}>`) builds, and the `eslint` key is still valid in `NextConfig`.
10. **The data is there.** With mock data and a live worker, 12 of 13 aggregate sections are populated for RELIANCE (only `signal` is null), `/markets` returns 12 indices, `/stocks` 20 rows, `/history?range=6M` 126 bars.
11. **The PRD §3 gaps are API surface, not missing data.** `news_ai_analysis` holds sentiment/impact/summary per article, `llm_calls` holds tokens and `est_cost_inr`, `system_logs` holds `records_*` and `execution_time_ms`. None is exposed. `NewsRepository` has only `listForInstrument` — no market-wide feed.
12. **`ai_analysis.sources[]` uses camelCase `asOf`** inside an otherwise snake_case payload (it is jsonb passed through). Task 1 fixes it to `as_of`.

## Global Constraints

- The gate, unchanged, run from the repo root: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`. Every task ends green.
- `TZ=UTC` for tests. No `any`, no `!` non-null assertions. `exactOptionalPropertyTypes` and `noUncheckedIndexedAccess` stay on.
- Backend imports keep the `.js` ESM suffix. Frontend uses bundler resolution (no suffix).
- **No secrets in the frontend.** Only `NEXT_PUBLIC_API_BASE_URL`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Task 11 scans the built bundle.
- **No page load calls the LLM** (PRD §14). Every route added here reads stored rows only; Task 2 extends Phase 9's `readsNeverSpend` proof to cover them.
- **Nothing trades.** No Phase 10 code places an order; the signal card is read-only and says so. `/portfolio` and the order box are Phase 11.
- **A missing value renders "unavailable" or "—", never `0`, `₹0.00`, `NaN` or a blank.**
- Branch `phase-10-frontend`. Commits end with `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>`.
- Mock mode stays the default: the MockBanner and the §19 disclaimer are always visible.
- New backend routes are **additive**. No existing response shape changes except `sources[].asOf → as_of` (fact 12), which is covered by a test.

## Review Focus

The five input classes the spec implies, no existing test exercises, and which would bite the owner first. Each has its test pinned to the task that owns the code.

1. **A null that reaches a formatter renders as a real number.** `Intl.format(null)` is `₹0.00` (fact 4), so an unavailable P/E would read as a ₹0 price and an absent 1-day return as a flat day. Pinned in Task 3 (`format.test.ts`): every formatter is asserted against `null` and `undefined`, and `formatInr(null)` must return the unavailable marker, not `₹0.00`.
2. **IST rendered as host-local time, including on the chart axis.** Invisible on an IST machine (fact 5); the owner's laptop is IST, so only a non-IST test catches it. lightweight-charts additionally renders UTC with no timezone option (fact 1), so an intraday axis reads `03:45` for the 09:15 open. Pinned in Task 3 (`TZ=UTC` tests assert `3:20 pm` IST for a `09:50Z` input) and Task 7 (a `03:45Z` bar labels as `09:15` through the chart's own formatters).
3. **A stale-looking page that is actually current, and a 0.00% that means "no session".** PRD §12's freshness is judged against the 20-minute quote threshold for daily facts, so indicators read "stale" all session; `performance['1d']` reads `0.00%` on a Sunday. Pinned in Task 2 (per-section cadence + null-on-no-session, with tests) — the two findings Phase 9 deferred to this phase.
4. **An action fires without a click, or a VIEWER sees admin buttons.** PRD §1 forbids auto-execution and §12 restricts the † routes. Pinned in Task 10: a test asserts the admin page renders no POST on mount, every button needs a click, and a VIEWER is shown a refusal rather than a button.
5. **A secret or a service-role key in the shipped bundle.** Success criterion 24. Both anon and service-role keys start with `eyJ`, so a prefix scan is not enough. Pinned in Task 11: the scan decodes every JWT-shaped string in `.next/` and fails on `role: service_role`, and greps for `JWT_SECRET`, `OPENAI_API_KEY`, `SERVICE_ROLE` and the live DB password.

## File structure

```
packages/shared/                              (Task 1)
├── package.json, tsconfig.json
└── src/{index.ts, envelope.ts, market.ts, stock.ts, admin.ts}   zod schemas = the contract

backend/src/
├── dto/news.ts, dto/admin.ts                 (Tasks 2, 5)
├── http/envelope.ts                          + per-section freshness cadence (Task 2)
├── repositories/NewsRepository.ts            + listRecent (market-wide)        (Task 2)
├── repositories/{SystemLogRepository,LlmCallRepository}.ts  + admin reads      (Task 2)
├── repositories/StockRepository.ts           + listWithFilters enrichment      (Task 2)
├── routes/{stocks,markets,systemStatus}.ts   + 5 additive reads               (Task 2)
└── services/StockAggregateService.ts         1d null on no session            (Task 2)

frontend/
├── package.json, tsconfig.json, next.config.ts, postcss.config.mjs, vitest.config.ts
├── .env.example, .env.local (gitignored)
├── app/{layout.tsx, globals.css, page.tsx, error.tsx, not-found.tsx}
├── app/login/page.tsx                                                         (Task 4)
├── app/stocks/[symbol]/page.tsx                                               (Task 7)
├── app/admin/page.tsx                                                         (Task 10)
├── lib/{api.ts, auth.ts, format.ts, hooks.ts}                            (Tasks 3, 4)
├── components/ui/{Card,Badge,Table,Skeleton,Button,Stat}.tsx                  (Task 5)
├── components/{MockBanner,Disclaimer,FreshnessBadge,MarketStatus,Header}.tsx  (Task 5)
├── components/{IndexCard,MarketSentimentPanel,WorthConsideringTable,NewsFeed}.tsx (Task 6)
├── components/{DecisionCard,PriceChart,TechnicalPanel,FundamentalsPanel}.tsx  (Tasks 7, 8)
├── components/{AIAnalysisPanel,NewsPanel,SignalCard,QAChat}.tsx               (Tasks 8, 9)
└── tests/{unit,components}/*.test.tsx, e2e/*.spec.ts                          (Task 11)
```

---

### Task 1: The shared contract (`packages/shared`)

**Files:**
- Create: `packages/shared/{package.json,tsconfig.json}`, `packages/shared/src/{index.ts,envelope.ts,market.ts,stock.ts,admin.ts}`
- Modify: `backend/src/services/StockAggregateService.ts` (`sources[].asOf` → `as_of`), `backend/package.json` (add the workspace dep), `backend/tsconfig.json` if a path mapping is needed
- Test: `backend/tests/integration/contract.test.ts`

**Interfaces — Produces:**
- `EnvelopeSchema<T>(data: ZodType<T>)`, `FreshnessSchema`, `MetaSchema`, `ApiErrorSchema`
- `MarketCardSchema`, `MarketStatusSchema`, `MarketSummarySchema` (`NewsItemSchema` lands in Task 2 with the route it describes)
- `StockListRowSchema`, `StockAggregateSchema` (13 sections), `QuoteSchema`, `HistorySchema`, `TechnicalSchema`, `FundamentalsSchema`, `EvaluationSchema`, `AnalysisSchema`, `SignalSchema`, `SentimentSchema`
- `SystemStatusSchema`, `JobRunSchema`, `LlmSpendSchema`
- `ActionAcceptedSchema` (`{job, job_id, already_queued}`), `QaAnswerSchema`
- Inferred types exported alongside each (`export type StockAggregate = z.infer<typeof StockAggregateSchema>`)

The schemas are **tolerant where the API is honest and strict where it is not**: every nullable section is `.nullable()`, numbers that pg returns as numeric are `z.number()`, and unknown extra keys are allowed (`.loose()` on objects that wrap jsonb) so a backend addition never breaks the browser. Required keys are required.

- [ ] **Step 1: Branch and write the failing contract test**

```bash
git checkout -b phase-10-frontend
```

`backend/tests/integration/contract.test.ts` — this is the test that makes the schemas a contract rather than a second opinion. It parses **real responses from the real app**, not fixtures.

```ts
import { describe, expect, it } from 'vitest';
import {
  ActionAcceptedSchema, EnvelopeSchema, HistorySchema, MarketCardSchema, MarketStatusSchema,
  MarketSummarySchema, StockAggregateSchema, StockListRowSchema, SystemStatusSchema,
} from '@learning-stocks/shared';
import { z } from 'zod';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();

/**
 * Parses a live response through the shared schema the browser will use.
 *
 * `jobQueue: null` is load-bearing: /system-status resolves worker liveness, which calls
 * `queue.start()` on a real PgBossQueue (the Phase 9 T8 fix). Without the override every call
 * here would boot pg-boss against the test schema and leak a pool that SIGTERM cannot close —
 * the Phase 9 C1 defect, re-created in a helper. `close()` in the finally is the other half.
 */
async function parsed<T>(url: string, schema: z.ZodType<T>): Promise<T> {
  return withRollback(db, async (trx) => {
    const c = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
      db: trx,
      logger: silentLogger,
      jobQueue: null,
    });
    const app = await buildApp(c);
    await app.ready();
    try {
      const res = await app.inject({ method: 'GET', url });
      expect(res.statusCode).toBe(200);
      const result = schema.safeParse(res.json());
      // The failure message must name the field, or a drift takes an hour to find.
      if (!result.success) throw new Error(`${url} violates its contract: ${JSON.stringify(z.treeifyError(result.error), null, 2)}`);
      return result.data;
    } finally {
      await app.close();
      await c.close();
    }
  });
}

describe('API responses satisfy the shared contract', () => {
  it('parses every read route the frontend calls', async () => {
    await parsed('/api/markets', EnvelopeSchema(z.array(MarketCardSchema)));
    await parsed('/api/market-status', EnvelopeSchema(MarketStatusSchema));
    await parsed('/api/market-summary', EnvelopeSchema(MarketSummarySchema.nullable()));
    await parsed('/api/stocks', EnvelopeSchema(z.array(StockListRowSchema)));
    await parsed('/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
    await parsed('/api/stocks/RELIANCE/history?range=6M&interval=1d', EnvelopeSchema(HistorySchema));
    await parsed('/api/system-status', EnvelopeSchema(SystemStatusSchema));
    // /api/news is Task 2's; its contract line is added there, so this task's gate can pass.
  });

  it('parses an aggregate whose every section is empty, which is a fresh database', async () => {
    // Deliberately NOT "12 of 13 sections are populated": that passes only because this dev
    // database has a worker filling it, and Task 11 runs `pnpm db:reset` before `pnpm test`.
    // The contract must hold on an empty database, which is the state a new checkout is in.
    const { data } = await parsed('/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
    expect(data.stock.symbol).toBe('RELIANCE');
    expect(Array.isArray(data.news)).toBe(true);
    for (const k of ['1d', '1w', '1m', '3m', '1y'] as const) expect(k in data.performance).toBe(true);
  });

  it('emits snake_case throughout, including inside jsonb passthroughs', async () => {
    // sources[] came back as camelCase `asOf` while every sibling key was snake_case: a jsonb
    // column passed straight through. One inconsistent key is a bug the browser inherits.
    // Seeded here rather than read from ambient data: an analysis row must exist for this to
    // assert anything, and `expect(length).toBeGreaterThan(0)` on an empty table is a pass
    // that proves nothing.
    await withRollback(db, async (trx) => {
      await seedAnalysisWithSources(trx, 'RELIANCE');
      const { data } = await parsedOn(trx, '/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
      const sources = data.ai_analysis?.sources ?? [];
      expect(sources.length).toBeGreaterThan(0);
      for (const src of sources) {
        expect(src).toHaveProperty('as_of');
        expect(src).not.toHaveProperty('asOf');
      }
    });
  });
});
```

- [ ] **Step 2: Run to verify it fails**

Run: `pnpm --filter @learning-stocks/backend test -- contract`
Expected: FAIL — `Cannot find module '@learning-stocks/shared'`.

- [ ] **Step 3: Create the package**

`packages/shared/package.json`:
```json
{
  "name": "@learning-stocks/shared",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "exports": { ".": "./src/index.ts" },
  "scripts": { "typecheck": "tsc -p tsconfig.json --noEmit" },
  "dependencies": { "zod": "4.6.5" }
}
```
`exports` points at the TypeScript source: both consumers compile it (backend via tsx/tsc, frontend via Next), so there is no build step and no stale `dist` to go out of sync.

**Every module gets its own subpath, and modules import each other by the package name** — this is
forced, not stylistic (measured fact 13): NodeNext requires `./envelope.js` and Turbopack rejects it,
so a relative import cannot satisfy both. Self-referencing package imports satisfy both:

```json
  "exports": {
    ".": "./src/index.ts",
    "./envelope": "./src/envelope.ts",
    "./market": "./src/market.ts",
    "./stock": "./src/stock.ts",
    "./admin": "./src/admin.ts"
  }
```
```ts
// packages/shared/src/stock.ts — by package name, never './envelope.js' or './envelope'
import { FreshnessSchema } from '@learning-stocks/shared/envelope';
```
A relative import added later breaks `pnpm build:web` and not `pnpm typecheck`, so the Task 3 build
step is what catches a regression here.

`packages/shared/tsconfig.json`:
```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": { "noEmit": true, "module": "preserve", "moduleResolution": "bundler" },
  "include": ["src"]
}
```

`packages/shared/src/envelope.ts`:
```ts
import { z } from 'zod';

/** PRD §12's freshness block: how old the newest stored fact is, and whether that is a problem. */
export const FreshnessSchema = z.object({
  as_of: z.string().nullable(),
  age_seconds: z.number().nullable(),
  stale: z.boolean(),
  market_open: z.boolean(),
  /** Which cadence judged `stale` (Task 2). Optional: older responses omit it. */
  cadence: z.enum(['quote', 'daily']).optional(),
});
export type Freshness = z.infer<typeof FreshnessSchema>;

export const MetaSchema = z.object({
  data_mode: z.enum(['MOCK', 'LIVE']),
  generated_at: z.string(),
  freshness: FreshnessSchema.optional(),
});
export type Meta = z.infer<typeof MetaSchema>;

/** Every successful response. Generic so each route states its own payload. */
export const EnvelopeSchema = <T extends z.ZodTypeAny>(data: T) =>
  z.object({ data, meta: MetaSchema });

export const ApiErrorSchema = z.object({
  error: z.object({
    code: z.enum([
      'VALIDATION', 'UNAUTHORIZED', 'FORBIDDEN', 'NOT_FOUND',
      'RATE_LIMITED', 'BUDGET_EXCEEDED', 'UNSUPPORTED', 'INTERNAL',
    ]),
    message: z.string(),
    details: z.record(z.string(), z.unknown()).optional(),
  }),
});
export type ApiError = z.infer<typeof ApiErrorSchema>;

/** A 202 from a sync or job route. `job_id: null` + `already_queued` is the queue deduplicating. */
export const ActionAcceptedSchema = z.object({
  job: z.string(),
  job_id: z.string().nullable(),
  already_queued: z.boolean(),
});
```

`packages/shared/src/market.ts`, `stock.ts` and `admin.ts` mirror the measured payloads exactly. Write them from the shapes in **docs/api.md** plus the live captures; the enums come from `backend/src/domain/enums.ts` (import them there? No — **restate them**, because `packages/shared` must not depend on the backend; the contract test is what keeps the two in step).

`packages/shared/src/stock.ts` (the longest; the rest follow the same style):
```ts
import { z } from 'zod';
import { FreshnessSchema } from '@learning-stocks/shared/envelope';

const num = z.number();
const nnum = z.number().nullable();

// Copied VERBATIM from backend/src/domain/enums.ts on 2026-10-07. Do not retype these from
// memory: an invented value that today's mock data never produces would pass the contract test
// and then throw ApiFailure('CONTRACT') on a live row, blanking the page. Step 4 adds a test
// asserting each array equals the backend's.
export const ACTION_STATES = [
  'BUY_ZONE', 'WAIT_FOR_PULLBACK', 'WAIT_FOR_CONFIRMATION', 'HOLD',
  'REDUCE', 'AVOID', 'INSUFFICIENT_DATA',
] as const;
export const RECOMMENDATION_BIASES = [
  'STRONG_BUY_BIAS', 'BUY_BIAS', 'HOLD_BIAS', 'SELL_BIAS', 'STRONG_SELL_BIAS',
] as const;
export const RISK_LEVELS = ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'] as const;
export const SENTIMENTS = ['BULLISH', 'NEUTRAL', 'BEARISH'] as const;
export const TRENDS = ['UPTREND', 'SIDEWAYS', 'DOWNTREND'] as const;
export const IMPACT_LEVELS = ['LOW', 'MEDIUM', 'HIGH'] as const;
export const VALUATION_LABELS = ['UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA'] as const;
export const MARKET_REGIMES = ['RISK_ON', 'NEUTRAL', 'RISK_OFF'] as const;
export const SIGNAL_STATUSES = ['ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED'] as const;

export const StockSchema = z.object({
  symbol: z.string(), company_name: z.string(), exchange: z.enum(['NSE', 'BSE']),
  isin: z.string().nullable(), isin_verified: z.boolean(),
  sector: z.string().nullable(), industry: z.string().nullable(),
  market_cap: nnum, currency: z.string(),
});

export const QuoteSchema = z.object({
  ts: z.string(), timeframe: z.string(), price: num,
  change: nnum, change_percent: nnum, volume: nnum, source: z.string(),
});

export const PerformanceSchema = z.object({
  // null, never 0: "we cannot measure it" and "it did not move" are different facts.
  '1d': nnum, '1w': nnum, '1m': nnum, '3m': nnum, '1y': nnum,
});

export const DecisionSchema = z.object({
  evaluated_at: z.string(), data_as_of: z.string(), scoring_config_version: z.string(),
  action_state: z.enum(ACTION_STATES), recommendation_bias: z.enum(RECOMMENDATION_BIASES),
  trend: z.enum(TRENDS), risk_level: z.enum(RISK_LEVELS),
  market_regime: z.enum(MARKET_REGIMES).nullable(),
  overall_score: nnum, risk_score: nnum, coverage: nnum,
  entry_low: nnum, entry_high: nnum, stop_loss: nnum, target_1: nnum, target_2: nnum,
  risk_reward: nnum, position_size_hint: nnum, invalidation: z.string().nullable(),
});

export const SourceSchema = z.object({
  id: z.string(), url: z.string().nullable(), as_of: z.string().nullable(),
  kind: z.string(), title: z.string().nullable(),
});

export const AnalysisSchema = z.looseObject({
  analysis_time: z.string(), status: z.string(),
  sentiment: z.enum(SENTIMENTS), sentiment_score: nnum, confidence: nnum,
  trend: z.enum(TRENDS).nullable(), risk_level: z.enum(RISK_LEVELS).nullable(),
  recommendation: z.enum(RECOMMENDATION_BIASES).nullable(), summary: z.string(),
  reasoning: z.array(z.string()),
  key_positive_factors: z.array(z.string()), key_negative_factors: z.array(z.string()),
  key_risks: z.array(z.string()), catalysts: z.array(z.string()),
  facts: z.array(z.looseObject({ statement: z.string(), source_ids: z.array(z.string()) })),
  interpretation: z.array(z.string()), insufficient_data: z.array(z.string()),
  sources: z.array(SourceSchema), model: z.string().nullable(),
});

export const SignalSchema = z.object({
  id: z.string(), signal: z.string(), confidence: nnum,
  entry_low: nnum, entry_high: nnum, stop_loss: nnum, target_price: nnum, target_2: nnum,
  suggested_quantity: nnum, valid_until: z.string(), status: z.string(),
  /** Always true: no job or route places an order (PRD §1, §11). */
  requires_manual_action: z.literal(true),
});

export const StockAggregateSchema = z.object({
  stock: StockSchema,
  quote: QuoteSchema.nullable(),
  performance: PerformanceSchema,
  technical: z.looseObject({ ts: z.string(), technical_score: nnum }).nullable(),
  fundamental: z.looseObject({ as_of: z.string(), source: z.string() }).nullable(),
  valuation: z.object({ label: z.enum(VALUATION_LABELS), valuation_score: nnum, quality_score: nnum }).nullable(),
  decision: DecisionSchema.nullable(),
  news: z.array(z.looseObject({ title: z.string(), source: z.string(), source_url: z.string().nullable(), published_at: z.string(), relevance: nnum })),
  sentiment: z.object({ window_days: num, article_count: num, average_sentiment_score: nnum }).nullable(),
  ai_analysis: AnalysisSchema.nullable(),
  signal: SignalSchema.nullable(),
  market_context: z.looseObject({ market: z.string(), sentiment: z.enum(SENTIMENTS) }).nullable(),
  data_freshness: z.record(z.string(), FreshnessSchema),
});
export type StockAggregate = z.infer<typeof StockAggregateSchema>;
```

`packages/shared/src/index.ts` re-exports all four modules.

Then: add `"@learning-stocks/shared": "workspace:*"` to `backend/package.json` dependencies and run `pnpm install`.

- [ ] **Step 4: Assert the shared enums match the backend's, then fix the camelCase leak**

`packages/shared` must not import from the backend (it is the dependency-free layer), so the two
copies are kept in step by a test rather than by the type system:

```ts
// backend/tests/unit/sharedEnums.test.ts
import { describe, expect, it } from 'vitest';
import * as shared from '@learning-stocks/shared';
import * as domain from '../../src/domain/enums.js';

describe('the shared contract enums match the domain enums', () => {
  // A value present in the domain but missing from the schema throws ApiFailure('CONTRACT') in
  // the browser and blanks the panel — and only for the rows that happen to carry it, so mock
  // data would never reveal it. RISK_LEVELS really has four values, not three.
  it.each([
    ['ACTION_STATES', shared.ACTION_STATES, domain.ACTION_STATES],
    ['RECOMMENDATION_BIASES', shared.RECOMMENDATION_BIASES, domain.RECOMMENDATION_BIASES],
    ['RISK_LEVELS', shared.RISK_LEVELS, domain.RISK_LEVELS],
    ['SENTIMENTS', shared.SENTIMENTS, domain.SENTIMENTS],
    ['TRENDS', shared.TRENDS, domain.TRENDS],
    ['IMPACT_LEVELS', shared.IMPACT_LEVELS, domain.IMPACT_LEVELS],
    ['VALUATION_LABELS', shared.VALUATION_LABELS, domain.VALUATION_LABELS],
    ['MARKET_REGIMES', shared.MARKET_REGIMES, domain.MARKET_REGIMES],
    ['SIGNAL_STATUSES', shared.SIGNAL_STATUSES, domain.SIGNAL_STATUSES],
  ])('%s', (_name, a, b) => {
    expect([...a]).toEqual([...b]);
  });
});
```

- [ ] **Step 5: Fix the camelCase leak**

In `StockAggregateService.ts`, the `ai_analysis.sources` passthrough maps the stored jsonb straight out. Map it explicitly:
```ts
              sources: analysis.sources.map((s) => ({
                id: s.id,
                url: s.url ?? null,
                // The stored jsonb uses camelCase; the wire is snake_case everywhere else.
                as_of: s.asOf ?? null,
                kind: s.kind,
                title: s.title ?? null,
              })),
```
Apply the same explicit mapping in `routes/stocks.ts`'s `analysisHandler`, which exposes `sources` too. Grep for other passthroughs before declaring this done: `rg -n 'sources|facts:|coverage' backend/src/routes backend/src/services`.

- [ ] **Step 6: Run the gate**

Run: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`
Expected: PASS, with `contract.test.ts` green. If a schema rejects a real response, **the schema is wrong unless the API is** — read the failure, decide which, and record a ruling.

Factor the helper into `parsedOn(trx, url, schema)` (used inside an existing transaction) with
`parsed(url, schema)` wrapping it in its own `withRollback`, so a seeding test and a bare test
share one code path. Write `seedAnalysisWithSources` against the real `stock_analyses` columns —
read the repository, do not guess the shape.

- [ ] **Step 7: Commit** `feat(shared): zod response contract parsed by both sides`

---

### Task 2: The five additive backend reads, and the two deferred freshness findings

**Files:**
- Create: `backend/src/dto/news.ts`, `backend/src/dto/admin.ts`, `backend/src/repositories/LlmCallRepository.ts`
- Modify: `backend/src/http/envelope.ts`, `backend/src/repositories/{NewsRepository,StockRepository,SystemLogRepository}.ts`, `backend/src/routes/{stocks,markets,systemStatus}.ts`, `backend/src/services/StockAggregateService.ts`, `backend/src/container.ts`, `docs/api.md`
- Test: `backend/tests/unit/freshnessCadence.test.ts`, `backend/tests/integration/phase10Reads.test.ts`, and extend `backend/tests/integration/readsNeverSpend.test.ts`

**Interfaces — Produces:**
- `freshness(asOf, { ..., cadence })` where `cadence: 'quote' | 'daily' | 'news'` picks the threshold; `CADENCES` exported
- `GET /news?limit=` — market-wide feed (PRD §3.1 "Latest News")
- `GET /stocks` enriched: each row gains `quote`, `valuation_label`, `scores`, `risk_reward`, `sentiment_score`
- `GET /stocks/:symbol/news` articles gain `sentiment`, `sentiment_score`, `impact_level`, `ai_summary`
- `GET /stocks/:symbol/history` gains `indicators: { sma_20, sma_50, sma_200 }` aligned to the bars
- `GET /system-status` gains `jobs[]` (per-job last run: status, records, duration) and `llm_spend` (today's calls, tokens, ₹)

**Why these five and no more:** each closes a PRD §3 bullet that otherwise cannot be rendered (advisor's coverage matrix). All are reads of stored rows; none calls a provider or the LLM.

- [ ] **Step 1: Write the failing tests**

`backend/tests/unit/freshnessCadence.test.ts` — the two deferred findings, as tests.

**A fixed 24-hour threshold does not work, and the test below is why.** Daily bars are stored only
after the close plus a 30-minute settle (Phase 3 deviation 3), so mid-session the newest daily fact
is the *previous* session's bar — measured: on Oct 7 the stored `technical.as_of` is
`2026-10-06T03:45Z`. That bar is already more than 24h old at today's open, and on a Monday it is
72h old. A fixed window would therefore report "stale" exactly as often as the bug it replaces.
A daily fact is fresh iff it is at or after the open of the most recent **completed** session, which
needs the calendar.

```ts
import { describe, expect, it } from 'vitest';
import { freshness } from '../../src/http/envelope.js';

// 11:30 IST on Tuesday 2026-10-06, mid-session.
const NOW = new Date('2026-10-06T06:00:00Z');
// The open of the most recent COMPLETED session (Monday 2026-10-05, 09:15 IST), from the calendar.
const LAST_COMPLETE_OPEN = new Date('2026-10-05T03:45:00Z');
const open = { now: NOW, marketOpen: true, stalenessMinutes: 20, lastCompleteSessionOpen: LAST_COMPLETE_OPEN };

describe('freshness cadence (Phase 9 finding I4)', () => {
  it('treats the previous session\'s daily bar as fresh mid-session', () => {
    // THE finding: daily facts were judged against the 20-minute quote threshold, so every
    // indicator, evaluation and fundamentals panel read "stale" from 09:35 onward — while being
    // as current as a daily fact can be, because today's bar is not written until after close.
    const mondaysBar = new Date('2026-10-05T03:45:00Z');
    expect(freshness(mondaysBar, { ...open, cadence: 'quote' }).stale).toBe(true);
    expect(freshness(mondaysBar, { ...open, cadence: 'daily' }).stale).toBe(false);
  });

  it('is fresh across a weekend, where a 24-hour window would not be', () => {
    // Monday 11:30 IST with Friday's bar: 72h old and perfectly current. This case is the reason
    // the cadence is session-based rather than a fixed duration.
    const monday = new Date('2026-10-12T06:00:00Z');
    const fridaysBar = new Date('2026-10-09T03:45:00Z');
    expect(
      freshness(fridaysBar, { now: monday, marketOpen: true, stalenessMinutes: 20, lastCompleteSessionOpen: fridaysBar }).stale,
    ).toBe(false);
  });

  it('still calls a skipped session stale', () => {
    // Tuesday with Thursday's bar: a session was missed, which is a real problem worth flagging.
    const thursdaysBar = new Date('2026-10-01T03:45:00Z');
    expect(freshness(thursdaysBar, { ...open, cadence: 'daily' }).stale).toBe(true);
  });

  it('judges a quote on the quote threshold, unchanged', () => {
    expect(freshness(new Date('2026-10-06T05:50:00Z'), { ...open, cadence: 'quote' }).stale).toBe(false);
    expect(freshness(new Date('2026-10-06T05:20:00Z'), { ...open, cadence: 'quote' }).stale).toBe(true);
  });

  it('reports which cadence judged it, so the UI can explain the badge', () => {
    expect(freshness(NOW, { ...open, cadence: 'daily' }).cadence).toBe('daily');
  });

  it('never marks anything stale while the market is closed, whatever the cadence', () => {
    const closed = { ...open, marketOpen: false };
    const ancient = new Date('2026-01-01T03:45:00Z');
    for (const cadence of ['quote', 'daily'] as const) {
      expect(freshness(ancient, { ...closed, cadence }).stale).toBe(false);
    }
  });

  it('falls back to the quote threshold when the caller cannot supply a session', () => {
    // A CLI or a degraded calendar read has no session to compare against. Fall back rather than
    // throw: a freshness badge must never be the thing that fails a page.
    const { lastCompleteSessionOpen: _drop, ...noSession } = open;
    expect(freshness(new Date('2026-10-06T05:59:00Z'), { ...noSession, cadence: 'daily' }).stale).toBe(false);
  });
});
```

`backend/tests/integration/phase10Reads.test.ts` — the new routes, plus finding I2:

```ts
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();

/** jobQueue: null and close() for the same reason as the contract test — see the note there. */
const get = async (url: string, seed?: (trx: Database) => Promise<void>) =>
  withRollback(db, async (trx) => {
    await seed?.(trx);
    const c = createContainer(loadConfig({ AUTH_MODE: 'none' }), { db: trx, logger: silentLogger, jobQueue: null });
    const app = await buildApp(c);
    await app.ready();
    try {
      const res = await app.inject({ method: 'GET', url });
      return { status: res.statusCode, body: res.json() as { data: unknown } };
    } finally {
      await app.close();
      await c.close();
    }
  });

describe('GET /news (market-wide)', () => {
  it('returns the newest articles across every stock, newest first', async () => {
    // Seeded, not ambient: `length > 0` against whatever the dev worker last wrote is a pass
    // that proves nothing, and Task 11 resets the database before running the suite.
    const { status, body } = await get('/api/news?limit=5', (trx) => seedNews(trx, 6));
    expect(status).toBe(200);
    const items = body.data as Array<{ published_at: string; linked_symbols: string[] }>;
    expect(items).toHaveLength(5);
    expect(items.length).toBeLessThanOrEqual(5);
    const times = items.map((i) => Date.parse(i.published_at));
    expect([...times].sort((a, b) => b - a)).toEqual(times);
    // PRD §3.1 wants the linked stocks on each headline.
    expect(Array.isArray(items[0]?.linked_symbols)).toBe(true);
  });

  it('rejects an absurd limit rather than scanning the table', async () => {
    expect((await get('/api/news?limit=5000')).status).toBe(400);
  });
});

describe('GET /stocks (enriched for the Worth Considering table)', () => {
  it('carries price, valuation and scores, so the table needs one request not twenty', async () => {
    const { body } = await get('/api/stocks');
    const rows = body.data as Array<Record<string, unknown>>;
    const row = rows.find((r) => r['symbol'] === 'RELIANCE');
    expect(row).toBeDefined();
    // PRD §3.1's columns: price, change %, action, valuation, scores, R:R, sentiment, risk.
    expect(row).toHaveProperty('quote');
    expect(row).toHaveProperty('valuation_label');
    expect(row).toHaveProperty('risk_reward');
    expect(row).toHaveProperty('sentiment_score');
    const scores = row?.['scores'] as Record<string, unknown>;
    expect(scores).toHaveProperty('technical');
    expect(scores).toHaveProperty('news');
  });

  it('still returns a stock with no evaluation, with nulls not omissions', async () => {
    const { body } = await get('/api/stocks?query=RELIANCE');
    const rows = body.data as Array<Record<string, unknown>>;
    expect(rows).toHaveLength(1);
    for (const k of ['quote', 'valuation_label', 'risk_reward', 'sentiment_score']) {
      expect(k in (rows[0] ?? {})).toBe(true);
    }
  });
});

describe('GET /stocks/:symbol/news (per-article AI sentiment)', () => {
  it('exposes the stored sentiment, impact and AI summary per article', async () => {
    const { body } = await get('/api/stocks/RELIANCE/news', (trx) => seedNewsWithSentiment(trx, 'RELIANCE'));
    const articles = (body.data as { articles: Array<Record<string, unknown>> }).articles;
    expect(articles.length).toBeGreaterThan(0);
    // news_ai_analysis holds these; Phase 9 deliberately did not expose them. PRD §3.2 needs them.
    for (const k of ['sentiment', 'sentiment_score', 'impact_level', 'ai_summary']) {
      expect(k in (articles[0] ?? {})).toBe(true);
    }
  });
});

describe('GET /stocks/:symbol/history (chart overlays)', () => {
  it('returns SMA series aligned to the bars, so the chart does not recompute them', async () => {
    const { body } = await get('/api/stocks/RELIANCE/history?range=1Y&interval=1d', (trx) => seedBarsAndIndicators(trx, 'RELIANCE', 300));
    const d = body.data as { bars: unknown[]; indicators: Record<string, Array<{ ts: string; value: number | null }>> };
    expect(d.bars.length).toBeGreaterThan(0);
    // One point per bar, aligned 1:1: the chart binds them directly without re-keying.
    for (const key of ['sma_20', 'sma_50', 'sma_200']) {
      expect(d.indicators[key]).toHaveLength(d.bars.length);
    }
    // Measured: indicators are backfilled 5 years, so a 1Y window starts INSIDE the warm-up
    // period and sma_20[0] is NOT null. Do not assert null on the first point of a trailing
    // window — assert the shape, and assert null only where the series genuinely has no value.
    const sma20 = d.indicators['sma_20'] ?? [];
    expect(sma20.every((pt) => pt.value === null || pt.value > 0)).toBe(true);
    expect(sma20.at(-1)?.value).toBeGreaterThan(0);
    // A bar with no stored indicator row yields null, never 0 — a 0 would draw the line on the axis.
    expect(sma20.some((pt) => pt.value === null) || sma20.length > 0).toBe(true);
  });
});

describe('GET /system-status (admin detail)', () => {
  it('reports per-job last run with records and duration, and today\'s LLM spend', async () => {
    const { body } = await get('/api/system-status');
    const d = body.data as { jobs: Array<Record<string, unknown>>; llm_spend: Record<string, unknown> };
    expect(Array.isArray(d.jobs)).toBe(true);
    const job = d.jobs[0];
    for (const k of ['job_name', 'status', 'records_processed', 'duration_ms', 'finished_at']) {
      expect(k in (job ?? {})).toBe(true);
    }
    // PRD §3.4: "LLM calls and spend vs daily budget".
    for (const k of ['calls_today', 'input_tokens', 'output_tokens', 'spent_inr', 'budget_inr']) {
      expect(k in d.llm_spend).toBe(true);
    }
  });
});

describe('performance (Phase 9 finding I2)', () => {
  it('keeps 1d measurable and equal to the quote move when a session is running', async () => {
    // The fix must not over-correct: during a session today's 1d return is real, and it must
    // agree with the quote the header shows, or the two panels contradict each other.
    // Measured 2026-10-07: 1d = 2.12 and quote.change_percent = 2.1201.
    const { body } = await get('/api/stocks/RELIANCE');
    const d = body.data as { performance: Record<string, number | null>; quote: { change_percent: number | null } | null };
    expect('1d' in d.performance).toBe(true);
    if (d.quote?.change_percent != null && d.performance['1d'] != null) {
      expect(d.performance['1d']).toBeCloseTo(d.quote.change_percent, 1);
    }
  });
});
```

The `1d`-on-a-Sunday case needs a fixed clock, so it belongs in a unit test over `StockAggregateService` with `now` injected (the deps already accept `now`). Add it to the existing `stockAggregateService.test.ts`:
```ts
  it('reports 1d as null on a day with no session, and keeps it measurable mid-session', async () => {
    // Sunday 2026-10-11, 12:00 IST. The newest quote IS Friday's close, so it is not newer than
    // the base bar's session and the arithmetic would give exactly 0 — which reads "flat today"
    // rather than "the market did not open".
    const sunday = buildService({ now: () => new Date('2026-10-11T06:30:00Z') });
    expect((await sunday.build('RELIANCE'))?.performance['1d']).toBeNull();
    // Longer windows still span real sessions and stay measurable.
    expect((await sunday.build('RELIANCE'))?.performance['1y']).not.toBeNull();

    // Pre-open Monday: a session is "today" but no tick has happened yet. Still null.
    const preOpen = buildService({ now: () => new Date('2026-10-12T02:30:00Z') });
    expect((await preOpen.build('RELIANCE'))?.performance['1d']).toBeNull();

    // Mid-session with an intraday quote newer than the last daily bar: measurable, and it must
    // agree with the quote's own change_percent.
    const midSession = buildService({ now: () => new Date('2026-10-12T06:00:00Z') });
    const agg = await midSession.build('RELIANCE');
    expect(agg?.performance['1d']).not.toBeNull();
  });
```
The mid-session case needs a seeded intraday bar newer than the newest daily bar; seed it in the
fixture rather than relying on whatever the dev worker last wrote.

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test -- freshnessCadence phase10Reads`
Expected: FAIL — `cadence` is not an option, the routes 404, the fields are absent.

- [ ] **Step 3: Implement the cadence**

In `backend/src/http/envelope.ts`:
```ts
/**
 * How long a fact of each kind stays current.
 *
 * A quote goes stale in minutes. A daily fact cannot be judged by a duration at all: daily bars
 * are written only after the close plus a settle, so mid-session the newest one is yesterday's —
 * 24h+ old at today's open and 72h old on a Monday. It is fresh iff it is at or after the open of
 * the most recent COMPLETED session (Phase 9 finding I4).
 */
export type Cadence = 'quote' | 'daily';

export interface FreshnessOptions {
  now: Date;
  marketOpen: boolean;
  /** app_settings.quote_staleness_minutes (PRD §11); the threshold for `cadence: 'quote'`. */
  stalenessMinutes: number;
  /** Which kind of fact this is. Defaults to 'quote' so existing callers are unchanged. */
  cadence?: Cadence;
  /**
   * The open of the most recent completed session, from MarketCalendarService.
   *
   * Optional: a caller that cannot resolve it (a CLI, or a calendar read that degraded) falls
   * back to the quote threshold rather than throwing. A freshness badge must never be the
   * reason a page fails.
   */
  lastCompleteSessionOpen?: Date;
}

export function freshness(asOf: Date | null, o: FreshnessOptions): Freshness {
  const cadence = o.cadence ?? 'quote';
  if (asOf === null) {
    return { as_of: null, age_seconds: null, stale: true, market_open: o.marketOpen, cadence };
  }
  const ageSeconds = Math.max(0, Math.round((o.now.getTime() - asOf.getTime()) / 1000));
  const stale =
    cadence === 'daily' && o.lastCompleteSessionOpen !== undefined
      ? asOf.getTime() < o.lastCompleteSessionOpen.getTime()
      : ageSeconds > o.stalenessMinutes * 60;
  return {
    as_of: asOf.toISOString(),
    age_seconds: ageSeconds,
    // Still only ever stale while the market is open: Friday's close is not stale on a Sunday.
    stale: o.marketOpen && stale,
    market_open: o.marketOpen,
    cadence,
  };
}
```
`MarketCalendarService` needs `lastCompleteSessionOpen(exchange, at)`: the open of the newest session
whose close plus the daily settle is at or before `at`. Add it there with its own unit test
(mid-session → yesterday's open; Monday → Friday's open; after today's settle → today's open).

Then in `StockAggregateService.build`, pass the cadence per section: `quote` → `'quote'`;
`evaluation`, `technical`, `fundamental` **and `ai_analysis`** → `'daily'` (the analysis's freshness
is judged on `dataAsOf`, which is itself a daily-bar timestamp, so the news cadence would misjudge
it); `news` → `'quote'` with a generous threshold, since an article has no session. Do the same in
`routes/stocks.ts`'s `freshnessFor` (add a cadence parameter).

For finding I2, in `StockAggregateService.performance`, a window whose range contains no session is unmeasurable:
```ts
      // A window that contains no price movement cannot be measured: with the market shut, the
      // "current" price IS the base close, so the arithmetic yields exactly 0 and renders as a
      // flat trading day (Phase 9 finding I2). null says "no session in this window".
      //
      // The test is whether the CURRENT price is newer than the base bar's session, not whether
      // another daily bar exists after the cutoff: mid-session no daily bar has been written yet
      // (they land after close + settle), but the live 5m quote is genuinely newer, and today's
      // 1d return is real. Measured: 1d = 2.12 matches quote.change_percent exactly.
      const moved = currentAsOf !== null && baseBar !== null && currentAsOf.getTime() > baseBar.ts.getTime();
      out[key] = current === null || base === null || base === 0 || !moved
        ? null
        : Math.round(((current - base) / base) * 10_000) / 100;
```

- [ ] **Step 4: Implement the five reads**

Keep each one small and stored-rows-only.

- **`NewsRepository.listRecent(mode, limit)`** — newest articles across all instruments with their linked symbols (join `news_stocks` → `stocks`, aggregate symbols). Route `GET /news` in `markets.ts` with `limit` validated `z.coerce.number().int().min(1).max(100).default(20)`.
- **`StockRepository.listWithFilters`** — extend the existing `distinctOn('stock_id')` evaluation join to also select `valuation_label`, `risk_reward`, the factor `scores` jsonb and `risk_level`; left-join the latest daily bar per stock for `quote`, and the 30-day mean news sentiment. Prefer **one query with lateral joins** over N+1; if a lateral proves awkward in Kysely, two queries joined in memory is acceptable — record a ruling either way.
- **`NewsRepository.listForInstrument`** — left-join `news_ai_analysis` on `(news_id, stock_id)` and surface `sentiment`, `sentiment_score`, `impact_level`, `summary` as `ai_summary`. Null when the sentiment job has not run.
- **`/history` indicators** — read `technical_indicators` over the same window and emit `sma_20/50/200` as `{ts, value}` arrays aligned 1:1 with the bars (null where no stored indicator for that bar's `ts`). Do **not** compute them in the route: the stored series is the one the decision engine used.
- **`/system-status`** — `SystemLogRepository.lastRunPerJob()` (one row per `job_name`, newest, with `records_processed`/`execution_time_ms`) and a new `LlmCallRepository.spendToday()` (count, token sums, `sum(est_cost_inr)`), wired through `container.ts`. Both inside the existing `soft()` degradation so an unreachable DB still returns 200.

- [ ] **Step 5: Extend the no-spend proof**

In `backend/tests/integration/readsNeverSpend.test.ts`, add the new routes to the list it sweeps. That test builds a container whose LLM provider throws on any call; it is the standing proof of PRD §14's first rule, and a new read route that is not in its list is unproven.

- [ ] **Step 6: Run the gate**

Run: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`
Expected: PASS. Then update `docs/api.md` with the five additions and the cadence change, and extend the Task 1 schemas to cover the new fields (the contract test will fail until you do — that is the contract working).

- [ ] **Step 7: Commit** `feat(backend): market news, enriched list, chart overlays, admin detail; per-section freshness`

---

### Task 3: Frontend scaffold, the formatting layer, and the API client

**Files:**
- Create: `frontend/{package.json,tsconfig.json,next.config.ts,postcss.config.mjs,vitest.config.ts,.env.example,.gitignore}`, `frontend/app/{layout.tsx,globals.css,page.tsx}`, `frontend/lib/{format.ts,api.ts}`
- Modify: root `package.json` (scripts), `.env.example` (fix the API URL origin), `.gitignore`
- Test: `frontend/tests/unit/{format.test.ts,api.test.ts}`

**Interfaces — Produces:**
- `formatInr(v: number | null | undefined, opts?): string`, `formatCompactInr` (Cr/L), `formatPercent`, `formatSignedPercent`, `formatNumber`, `formatQuantity`
- `formatIstDateTime(iso: string | null)`, `formatIstDate`, `formatIstTime`, `relativeAge(iso, now)`
- `UNAVAILABLE = '—'`
- `apiGet<T>(path, schema, token): Promise<T>`, `apiPost<T>(...)`, `ApiFailure` (carries `code`, `status`, `message`)
- `Consumes`: `@learning-stocks/shared` schemas from Task 1

**Why formatting is its own task with its own tests:** Review Focus 1 and 2 both live here. `Intl.format(null)` returns `₹0.00` and an omitted `timeZone` silently renders host-local time (measured facts 4 and 5). Every number and date on every page goes through this module, so one bug here is a wrong number everywhere.

- [ ] **Step 1: Write the failing tests**

`frontend/tests/unit/format.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import {
  UNAVAILABLE, formatCompactInr, formatInr, formatIstDateTime, formatPercent,
  formatSignedPercent, relativeAge,
} from '../../lib/format';

describe('formatInr', () => {
  it('uses Indian digit grouping', () => {
    // PRD §5: ₹10,00,000 — not ₹1,000,000. A Western grouping is a wrong number to the reader.
    expect(formatInr(1_000_000)).toBe('₹10,00,000.00');
    expect(formatInr(1639.7805)).toBe('₹1,639.78');
  });

  it('renders a missing value as unavailable, never ₹0.00', () => {
    // Intl.NumberFormat.format(null) returns "₹0.00" (measured). A missing P/E would then read
    // as a real price of zero, and an absent metric as a free company.
    expect(formatInr(null)).toBe(UNAVAILABLE);
    expect(formatInr(undefined)).toBe(UNAVAILABLE);
    expect(formatInr(Number.NaN)).toBe(UNAVAILABLE);
    expect(formatInr(Number.POSITIVE_INFINITY)).toBe(UNAVAILABLE);
    // A real zero is still a real zero.
    expect(formatInr(0)).toBe('₹0.00');
  });

  it('keeps the sign on a negative', () => {
    expect(formatInr(-34.0428)).toBe('-₹34.04');
  });
});

describe('formatCompactInr', () => {
  it('uses crore and lakh, because a 16-digit market cap is unreadable', () => {
    // ₹1,63,28,39,13,46,312.20 is correct grouping and useless on a card.
    expect(formatCompactInr(16_328_391_346_312)).toBe('₹16,32,839.13 Cr');
    expect(formatCompactInr(5_00_000)).toBe('₹5.00 L');
    expect(formatCompactInr(1234)).toBe('₹1,234.00');
    expect(formatCompactInr(null)).toBe(UNAVAILABLE);
  });
});

describe('formatPercent', () => {
  it('distinguishes a null window from a flat one', () => {
    // The backend returns null when a window spans no session and 0 when it genuinely did not
    // move. Rendering both as "0.00%" destroys that distinction (Phase 9 finding I2).
    expect(formatPercent(null)).toBe(UNAVAILABLE);
    expect(formatPercent(0)).toBe('0.00%');
    expect(formatSignedPercent(2.1201)).toBe('+2.12%');
    expect(formatSignedPercent(-1.5)).toBe('-1.50%');
    expect(formatSignedPercent(0)).toBe('0.00%');
  });
});

describe('IST rendering', () => {
  it('renders an instant in IST regardless of the host timezone', () => {
    // Tests run TZ=UTC and the owner's laptop is IST, so an omitted timeZone looks right on
    // their machine and is wrong everywhere else. 09:50Z is 15:20 IST.
    expect(formatIstDateTime('2026-10-07T09:50:00.000Z')).toBe('7 Oct 2026, 3:20 pm');
  });

  it('marks the timezone so a reader never has to guess', () => {
    expect(formatIstDateTime('2026-10-07T09:50:00.000Z', { suffix: true })).toMatch(/IST$/);
  });

  it('renders a missing timestamp as unavailable', () => {
    expect(formatIstDateTime(null)).toBe(UNAVAILABLE);
    expect(formatIstDateTime('not-a-date')).toBe(UNAVAILABLE);
  });
});

describe('relativeAge', () => {
  it('reads as a human age, for "Data updated X ago"', () => {
    const now = new Date('2026-10-07T10:00:00Z');
    expect(relativeAge('2026-10-07T09:58:00Z', now)).toBe('2 min ago');
    expect(relativeAge('2026-10-07T09:00:00Z', now)).toBe('1 hr ago');
    expect(relativeAge('2026-10-05T09:00:00Z', now)).toBe('2 days ago');
    expect(relativeAge('2026-10-07T09:59:50Z', now)).toBe('just now');
    expect(relativeAge(null, now)).toBe(UNAVAILABLE);
  });
});
```

`frontend/tests/unit/api.test.ts`:
```ts
import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import { ApiFailure, apiGet } from '../../lib/api';

const schema = z.object({ data: z.object({ ok: z.boolean() }), meta: z.object({ data_mode: z.string(), generated_at: z.string() }) });
const body = (b: unknown, status = 200) =>
  vi.fn().mockResolvedValue(new Response(JSON.stringify(b), { status, headers: { 'content-type': 'application/json' } }));

describe('apiGet', () => {
  it('sends the bearer token and parses through the schema', async () => {
    const fetchMock = body({ data: { ok: true }, meta: { data_mode: 'MOCK', generated_at: 'x' } });
    const out = await apiGet('/health', schema, { token: 'tok-123', fetchImpl: fetchMock });
    expect(out.data.ok).toBe(true);
    const init = fetchMock.mock.calls[0]?.[1] as RequestInit;
    expect(new Headers(init.headers).get('authorization')).toBe('Bearer tok-123');
  });

  it('omits the header entirely when there is no token, so AUTH_MODE=none works', async () => {
    const fetchMock = body({ data: { ok: true }, meta: { data_mode: 'MOCK', generated_at: 'x' } });
    await apiGet('/health', schema, { token: null, fetchImpl: fetchMock });
    const init = fetchMock.mock.calls[0]?.[1] as RequestInit;
    // "Bearer null" would be a 401 on a server that would otherwise have served the request.
    expect(new Headers(init.headers).has('authorization')).toBe(false);
  });

  it('turns an error envelope into a typed failure, keeping the code', async () => {
    const fetchMock = body({ error: { code: 'NOT_FOUND', message: 'No stock NOPE' } }, 404);
    await expect(apiGet('/stocks/NOPE', schema, { fetchImpl: fetchMock })).rejects.toMatchObject({
      code: 'NOT_FOUND', status: 404,
    });
  });

  it('reports a contract violation as such, not as a render crash', async () => {
    // A backend rename must surface as a named failure here, not as undefined on screen.
    const fetchMock = body({ data: { ok: 'yes' }, meta: { data_mode: 'MOCK', generated_at: 'x' } });
    const err = await apiGet('/health', schema, { fetchImpl: fetchMock }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ApiFailure);
    expect((err as ApiFailure).code).toBe('CONTRACT');
  });

  it('survives a non-JSON body (a proxy error page) without throwing a parse error', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response('<html>502</html>', { status: 502 }));
    await expect(apiGet('/health', schema, { fetchImpl: fetchMock })).rejects.toMatchObject({ status: 502 });
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/frontend test`
Expected: FAIL — the package does not exist yet.

- [ ] **Step 3: Scaffold the app by hand**

Do **not** run `create-next-app`: it writes its own lint, prettier and tsconfig choices over the repo's. Write the files.

`frontend/package.json`:
```json
{
  "name": "@learning-stocks/frontend",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "next dev -H 127.0.0.1 -p 3000",
    "build": "next build",
    "start": "next start -H 127.0.0.1 -p 3000",
    "typecheck": "tsc -p tsconfig.json --noEmit",
    "test": "TZ=UTC vitest run",
    "test:e2e": "playwright test"
  },
  "dependencies": {
    "@learning-stocks/shared": "workspace:*",
    "@supabase/supabase-js": "2.117.2",
    "lightweight-charts": "5.2.1",
    "next": "16.4.0",
    "react": "19.3.0",
    "react-dom": "19.3.0",
    "zod": "4.6.5"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "4.3.3",
    "@testing-library/jest-dom": "7.0.1",
    "@testing-library/react": "16.3.3",
    "@testing-library/user-event": "14.7.0",
    "@types/node": "22.20.5",
    "@types/react": "19.2.2",
    "@types/react-dom": "19.2.2",
    "@vitejs/plugin-react": "6.1.2",
    "jsdom": "30.1.2",
    "tailwindcss": "4.3.3",
    "vitest": "5.0.3"
  }
}
```
`-H 127.0.0.1` is load-bearing: `CORS_ORIGIN` is `http://127.0.0.1:3000`, and a page served from `localhost:3000` is a **different origin** that the API refuses (measured fact 9).

`frontend/tsconfig.json` — Next rewrites parts of this on first build (measured fact 2); write it in the shape it will settle into:
```json
{
  "compilerOptions": {
    "target": "ES2023",
    "lib": ["ES2023", "DOM", "DOM.Iterable"],
    "module": "preserve",
    "moduleResolution": "bundler",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "exactOptionalPropertyTypes": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "allowJs": true,
    "skipLibCheck": true,
    "incremental": true,
    "isolatedModules": true,
    "esModuleInterop": true,
    "resolveJsonModule": true,
    "plugins": [{ "name": "next" }],
    "paths": { "@/*": ["./*"] }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts", ".next/dev/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```
It deliberately does **not** extend `tsconfig.base.json`: that sets `module: NodeNext`, which Next rejects for app code. Strictness is restated instead.

`frontend/next.config.ts`:
```ts
import type { NextConfig } from 'next';

const config: NextConfig = {
  reactStrictMode: true,
  // The repo's root `eslint .` already lints this directory; Next's own run would duplicate it
  // with different rules.
  eslint: { ignoreDuringBuilds: true },
  // Fail the build on a type error rather than shipping it.
  typescript: { ignoreBuildErrors: false },
};
export default config;
```

`frontend/postcss.config.mjs`, `frontend/app/globals.css` (Tailwind 4, CSS-first — measured fact 3):
```css
@import 'tailwindcss';

@theme {
  --color-bull: #16a34a;
  --color-bear: #dc2626;
  --color-flat: #64748b;
  --color-warn: #d97706;
}

/* A research desk is read for long stretches; dark is the default and light is honoured. */
:root { color-scheme: dark light; }
```

`frontend/vitest.config.ts` with `@vitejs/plugin-react`, `environment: 'jsdom'`, `setupFiles` importing
`@testing-library/jest-dom/vitest`, and `projects` for `unit` and `components` — each with an
**explicit `include`**. Vitest's default include matches `**/*.spec.ts`, which would pull in
`e2e/*.spec.ts` and run Playwright specs under jsdom:
```ts
  projects: [
    { extends: true, test: { name: 'unit', include: ['tests/unit/**/*.test.ts'], environment: 'node' } },
    { extends: true, test: { name: 'components', include: ['tests/components/**/*.test.tsx'], environment: 'jsdom', setupFiles: ['./tests/setup.ts'] } },
  ],
```
Add `@playwright/test` to devDependencies in **this** task even though the specs arrive in Task 11:
`tsconfig.json` includes `**/*.ts`, so `pnpm typecheck` fails on a missing `@playwright/test` the
moment those files exist. Alternatively exclude `e2e` from the tsconfig — pick one, and record it.

`frontend/.env.example` (and a gitignored `.env.local` the owner fills):
```
# Next reads .env* from THIS directory, not the repo root.
# The origin must match the backend's CORS_ORIGIN exactly: 127.0.0.1, not localhost.
NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:4000/api
NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
# The anon/publishable key only. NEVER the service-role key: this file ships to the browser.
NEXT_PUBLIC_SUPABASE_ANON_KEY=
```
Add `frontend/.env.local` and `frontend/.next/` to `.gitignore`. Fix the root `.env.example`'s `NEXT_PUBLIC_API_BASE_URL` to `http://127.0.0.1:4000/api` (it currently says `localhost`, which CORS refuses), and note in a comment that the frontend reads its own `frontend/.env.local`.

- [ ] **Step 4: Implement `lib/format.ts`**

The null guard is the whole point of the module:
```ts
export const UNAVAILABLE = '—';

/** A value we can render. null, undefined, NaN and ±Infinity are all "we do not have it". */
const usable = (v: number | null | undefined): v is number => typeof v === 'number' && Number.isFinite(v);

const inr = new Intl.NumberFormat('en-IN', {
  style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2,
});

/**
 * ₹ with Indian digit grouping, or the unavailable marker.
 *
 * The guard is not defensive programming: Intl.NumberFormat.format(null) returns "₹0.00", so
 * without it a metric the provider never supplied renders as a real price of zero.
 */
export function formatInr(v: number | null | undefined): string {
  return usable(v) ? inr.format(v) : UNAVAILABLE;
}

const CRORE = 10_000_000;
const LAKH = 100_000;

/** Market caps in crore/lakh: correct en-IN grouping of a 16-digit number is unreadable. */
export function formatCompactInr(v: number | null | undefined): string {
  if (!usable(v)) return UNAVAILABLE;
  const abs = Math.abs(v);
  if (abs >= CRORE) return `${inr.format(v / CRORE)} Cr`;
  if (abs >= LAKH) return `${inr.format(v / LAKH)} L`;
  return inr.format(v);
}
```
Dates take an explicit `timeZone: 'Asia/Kolkata'` on every formatter — never the host default (measured fact 5) — and `relativeAge` takes `now` as a parameter so it is deterministic in tests and can be rendered without a hydration mismatch (Task 5 owns the client-only mount).

- [ ] **Step 5: Implement `lib/api.ts`**

```ts
export class ApiFailure extends Error {
  constructor(
    readonly code: string,
    readonly status: number,
    message: string,
    readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'ApiFailure';
  }
}
```
`apiGet` builds the URL from `NEXT_PUBLIC_API_BASE_URL`, sets `Authorization` **only when a token exists** (so `AUTH_MODE=none` works untokened), reads the body once as text and `JSON.parse`es defensively (a proxy's HTML error page must not throw a parse error), maps an `{error}` envelope to `ApiFailure` with its code, and parses success through the caller's schema — a `safeParse` failure becomes `ApiFailure('CONTRACT', …)`. `fetchImpl` is injectable for tests. Reads use `cache: 'no-store'`: a research desk must never show a cached price.

- [ ] **Step 6: Root scripts and install**

Root `package.json`: `"dev:web": "pnpm --filter @learning-stocks/frontend dev"`, `"build:web": "pnpm --filter @learning-stocks/frontend build"`, `"test:e2e": "pnpm --filter @learning-stocks/frontend test:e2e"`. `pnpm typecheck` and `pnpm test` already recurse with `--if-present`, so the new package joins the gate automatically.

Run `pnpm install`. If pnpm 11 blocks a postinstall build (`sharp`, `@swc/core`), add it to the root `allowBuilds` rather than disabling the check, and record a ruling.

- [ ] **Step 7: Run the gate**

Run: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`
Expected: PASS. Then `pnpm --filter @learning-stocks/frontend build` once to let Next settle `tsconfig.json`, and re-run `pnpm typecheck` to confirm the settled file still passes.

- [ ] **Step 8: Commit** `feat(frontend): Next 16 scaffold, en-IN/IST formatting, typed API client`

---

### Task 4: Auth — login, the bearer token, and the dev bypass

**Files:**
- Create: `frontend/lib/auth.ts`, `frontend/lib/hooks.ts`, `frontend/app/login/page.tsx`, `frontend/components/AuthGate.tsx`
- Modify: `frontend/app/layout.tsx`
- Test: `frontend/tests/unit/auth.test.ts`, `frontend/tests/components/authGate.test.tsx`, `backend/tests/integration/jwksAuth.test.ts`

**Interfaces — Produces:**
- `supabase()` — a lazily created browser client, or `null` when the env vars are absent
- `useSession()` — `{ session, token, role, loading }`, subscribed to `onAuthStateChange`
- `signIn(email, password)`, `signUp(email, password)`, `signOut()`
- `<AuthGate>` — renders children when authenticated or when the API is in `AUTH_MODE=none`, otherwise redirects to `/login`

**Ruling (made, not asked):** the browser holds the token and calls the API directly. No Next route handler proxies the API, because a proxy would need the token server-side and invites a service-role key into the server bundle. `@supabase/ssr` is not used for the same reason — there is no server-rendered authenticated data.

**Measured fact this task rests on (7):** local GoTrue signs **ES256** via JWKS and the backend already verifies it against issuer and audience. So login works with `JWT_SECRET` blank. **No existing backend test covers that path** — every one passes `jwksUrl: null` with a shared secret — so a regression there would only surface as "login is broken" in a browser. Step 1 closes that.

- [ ] **Step 1: Write the failing backend JWKS test**

`backend/tests/integration/jwksAuth.test.ts`. It must not depend on a running GoTrue, so it serves its own JWKS over loopback and signs with a matching ES256 key — proving the verifier accepts the algorithm, issuer and audience that the real token carries.

```ts
import { createServer, type Server } from 'node:http';
import { exportJWK, generateKeyPair, SignJWT } from 'jose';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { verifyToken, keyFor, type VerifyOptions } from '../../src/http/auth.js';

/**
 * The browser login path, which no other test covers.
 *
 * Measured against the real local stack on 2026-10-07: GoTrue signs ES256 and publishes one EC
 * key at /auth/v1/.well-known/jwks.json, so a browser token verifies with JWT_SECRET unset —
 * which is how .env ships. Every other auth test passes `jwksUrl: null` and a shared secret, so
 * an ES256 regression would reach the owner as "login is broken" with nothing red.
 */
describe('JWKS verification (the real browser login path)', () => {
  let server: Server;
  let origin: string;
  let signWith: (claims: Record<string, unknown>, over?: { issuer?: string; audience?: string }) => Promise<string>;
  let jwksHits = 0;
  let options: VerifyOptions;

  beforeAll(async () => {
    const { privateKey, publicKey } = await generateKeyPair('ES256');
    const jwk = { ...(await exportJWK(publicKey)), kid: 'test-key', alg: 'ES256', use: 'sig' };
    server = createServer((_req, res) => {
      jwksHits += 1;
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ keys: [jwk] }));
    });
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
    const address = server.address();
    const port = typeof address === 'object' && address !== null ? address.port : 0;
    origin = `http://127.0.0.1:${port}`;
    options = {
      secret: null,
      jwksUrl: `${origin}/auth/v1/.well-known/jwks.json`,
      issuer: `${origin}/auth/v1`,
      audience: 'authenticated',
    };
    // One signer, one key: every negative case changes exactly ONE claim, so a refusal can only
    // be the pin under test and never an incidental signature failure.
    signWith = (claims, over = {}) =>
      new SignJWT(claims)
        .setProtectedHeader({ alg: 'ES256', kid: 'test-key' })
        .setIssuer(over.issuer ?? `${origin}/auth/v1`)
        .setAudience(over.audience ?? 'authenticated')
        .setIssuedAt()
        .setExpirationTime('1h')
        .sign(privateKey);
  });

  afterAll(() => new Promise<void>((r) => server.close(() => r())));

  it('accepts an ES256 token fetched from JWKS, with no shared secret configured', async () => {
    const token = await signWith({ sub: 'user-1', role: 'authenticated', email: 'a@b.test' });
    const result = await verifyToken(token, options, keyFor(options));
    expect(result).toEqual({ sub: 'user-1', email: 'a@b.test' });
  });

  it('refuses a wrong issuer on an OTHERWISE VALID token', async () => {
    // Signed with THE SAME key the JWKS serves, so the signature verifies and the only thing
    // wrong is `iss`. Signing with a fresh key would fail on the signature instead, and the
    // test would pass with the issuer pin removed — proving nothing about the pin.
    const foreign = await signWith({ sub: 'user-1' }, { issuer: 'https://evil.example/auth/v1' });
    await expect(verifyToken(foreign, options, keyFor(options))).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
    // Control: the same claims with the right issuer DO verify, so the refusal above is the pin.
    await expect(verifyToken(await signWith({ sub: 'user-1' }), options, keyFor(options))).resolves.toMatchObject({ sub: 'user-1' });
  });

  it('refuses a wrong audience on an otherwise valid token', async () => {
    const wrongAud = await signWith({ sub: 'user-1' }, { audience: 'anon' });
    await expect(verifyToken(wrongAud, options, keyFor(options))).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });

  it('fetches JWKS once across many authenticated requests, not once per request', async () => {
    // Auth runs before the rate limiter, so a per-request JWKS fetch is an unthrottled outbound
    // loop an attacker can drive. Measured with VALID tokens through the real app: a malformed
    // token never reaches key lookup, so asserting 0 fetches on garbage proves nothing.
    jwksHits = 0;
    await withRollback(db, async (trx) => {
      const c = createContainer(
        loadConfig({ AUTH_MODE: 'jwt', SUPABASE_URL: origin.replace('/auth/v1', '') }),
        { db: trx, logger: silentLogger, jobQueue: null },
      );
      const userId = await seedUser(trx, 'OWNER');
      const app = await buildApp(c);
      await app.ready();
      try {
        for (let i = 0; i < 3; i += 1) {
          const res = await app.inject({
            method: 'GET',
            url: '/api/market-status',
            headers: { authorization: `Bearer ${await signWith({ sub: userId, role: 'authenticated' })}` },
          });
          expect(res.statusCode).toBe(200);
        }
      } finally {
        await app.close();
        await c.close();
      }
    });
    // jose caches the key set in closure state; registerAuth builds it once per server.
    expect(jwksHits).toBe(1);
  });
});
```

`frontend/tests/unit/auth.test.ts` asserts `useSession` reads the token from a session, clears it on sign-out, and that `supabase()` returns `null` (rather than throwing) when the env vars are blank — because `AUTH_MODE=none` must work before the owner has configured Supabase at all.

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test -- jwksAuth` and `pnpm --filter @learning-stocks/frontend test -- auth`
Expected: FAIL (module missing; the JWKS test may already pass — if it does, say so and keep it as the regression guard rather than deleting it).

- [ ] **Step 3: Implement**

`lib/auth.ts` creates the client once with `createClient(url, anonKey, { auth: { persistSession: true, autoRefreshToken: true } })`, returning `null` if either env var is empty. `useSession` holds `{session, loading}`, calls `getSession()` on mount and subscribes to `onAuthStateChange`, unsubscribing on unmount.

The role comes from the **API**, not the token (PRD §12: the token's `role` is always `authenticated`). `useSession` therefore exposes `role: null` and the admin page learns the real role by calling `/system-status` and handling a 403 — the server stays the authority.

`app/login/page.tsx`: email + password, sign in and sign up, and a plain-language note that **the first account created becomes OWNER** and the rest are VIEWER. On success, redirect to `/`. On failure, show the message. If `supabase()` is null, the page explains which two env vars to set instead of rendering a dead form.

`<AuthGate>`: while `loading`, a skeleton. If there is a session, children. If not, it probes `/api/health` — public — and then one authenticated read; a 200 means the API is in `AUTH_MODE=none` and children render untokened. Otherwise it redirects to `/login`. This is what makes the dashboard usable before the owner sets up auth, which was the point of the Phase 9 decision.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(frontend): Supabase login, bearer token plumbing, dev-bypass gate`

---

### Task 5: UI primitives, the freshness badge, the mock banner and the disclaimer

**Files:**
- Create: `frontend/components/ui/{Card,Badge,Button,Stat,Table,Skeleton,EmptyPanel}.tsx`, `frontend/components/{MockBanner,Disclaimer,FreshnessBadge,MarketStatus,Header,ErrorNotice}.tsx`
- Modify: `frontend/app/layout.tsx`
- Test: `frontend/tests/components/{freshnessBadge,mockBanner,emptyPanel}.test.tsx`

**Interfaces — Produces:**
- `<Card title? actions? footer?>`, `<Badge tone="bull|bear|flat|warn|neutral">`, `<Button variant intent onClick>`, `<Stat label value hint?>`, `<Table columns rows sort?>`, `<Skeleton>`, `<EmptyPanel reason>`
- `<FreshnessBadge freshness={Freshness} label?>` — "Updated 3 min ago", stale styling, IST tooltip
- `<MockBanner dataMode>`, `<Disclaimer>`, `<MarketStatus status>`, `<Header>`
- `Consumes`: `lib/format` (Task 3), `Freshness` from `@learning-stocks/shared` (Task 1)

**No shadcn/ui CLI.** The PRD names shadcn, but its CLI writes its own `components.json`, Tailwind config and path aliases, and this repo already has opinions about all three. These seven primitives are what the pages actually use; hand-writing them is less code than reconciling the generator. **Record this as a ruling** against PRD §4.3.

- [ ] **Step 1: Write the failing tests**

`frontend/tests/components/freshnessBadge.test.tsx`:
```tsx
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { FreshnessBadge } from '../../components/FreshnessBadge';

const at = (iso: string, over: Partial<{ stale: boolean; market_open: boolean; age_seconds: number }> = {}) => ({
  as_of: iso, age_seconds: over.age_seconds ?? 120, stale: over.stale ?? false,
  market_open: over.market_open ?? true, cadence: 'quote' as const,
});

describe('FreshnessBadge', () => {
  it('states the age and the exact IST instant, so a number is never undated', () => {
    render(<FreshnessBadge freshness={at('2026-10-07T09:50:00.000Z')} now={new Date('2026-10-07T09:52:00.000Z')} />);
    expect(screen.getByText(/2 min ago/)).toBeInTheDocument();
    // The precise time is available on hover: "3 min ago" is useless when reconciling two panels.
    expect(screen.getByTitle(/7 Oct 2026, 3:20 pm IST/)).toBeInTheDocument();
  });

  it('flags stale data loudly, because a wrong price is worse than no price', () => {
    render(<FreshnessBadge freshness={at('2026-10-07T06:00:00.000Z', { stale: true, age_seconds: 14_400 })} now={new Date('2026-10-07T10:00:00.000Z')} />);
    expect(screen.getByRole('status')).toHaveAttribute('data-stale', 'true');
    expect(screen.getByText(/stale/i)).toBeInTheDocument();
  });

  it('says "no data" rather than rendering an empty badge', () => {
    render(<FreshnessBadge freshness={{ as_of: null, age_seconds: null, stale: true, market_open: false }} now={new Date()} />);
    expect(screen.getByText(/no data/i)).toBeInTheDocument();
  });

  it('does not cry stale while the market is closed', () => {
    // Friday's close on a Sunday is final, not stale. The API already encodes this; the badge
    // must not re-derive it from age and contradict the API.
    render(<FreshnessBadge freshness={at('2026-10-02T10:00:00.000Z', { stale: false, market_open: false, age_seconds: 400_000 })} now={new Date('2026-10-07T10:00:00.000Z')} />);
    expect(screen.getByRole('status')).toHaveAttribute('data-stale', 'false');
  });
});
```

`frontend/tests/components/mockBanner.test.tsx`:
```tsx
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { Disclaimer } from '../../components/Disclaimer';
import { MockBanner } from '../../components/MockBanner';

describe('MockBanner', () => {
  it('says the data is simulated, so a mock price is never mistaken for a real one', () => {
    render(<MockBanner dataMode="MOCK" />);
    expect(screen.getByRole('alert')).toHaveTextContent(/simulated|mock/i);
  });

  it('renders nothing in LIVE mode', () => {
    const { container } = render(<MockBanner dataMode="LIVE" />);
    expect(container).toBeEmptyDOMElement();
  });
});

describe('Disclaimer', () => {
  it('is always present and never claims a prediction', () => {
    render(<Disclaimer />);
    const text = screen.getByRole('contentinfo').textContent ?? '';
    expect(text).toMatch(/not investment advice/i);
    expect(text).toMatch(/personal use/i);
    // PRD §1's banned vocabulary must not appear anywhere in our own copy.
    for (const banned of ['guaranteed', 'will definitely', 'sure-shot', 'risk-free', 'certain to']) {
      expect(text.toLowerCase()).not.toContain(banned);
    }
  });
});
```

`frontend/tests/components/emptyPanel.test.tsx` asserts a panel with no data renders a stated reason ("Fundamental data unavailable", per PRD §3.2) rather than an empty box or a zero.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (modules missing).

- [ ] **Step 3: Implement**

`FreshnessBadge` renders `relativeAge` with `title={formatIstDateTime(as_of, {suffix: true})}`, `role="status"`, `data-stale`, and takes `now` as a prop defaulted by a client-only effect — **computing `Date.now()` during render would hydrate differently than it rendered** and React would warn. The `stale` flag comes from the API; the badge never recomputes it.

`MockBanner` is `role="alert"` and always visible in mock mode. `Disclaimer` is `role="contentinfo"`, sits in the layout footer on every page, and states: personal use, not investment advice, biases with confidence rather than predictions, paper trading only.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(frontend): UI primitives, freshness badge, mock banner, disclaimer`

---

### Task 6: The dashboard (`/`)

**Files:**
- Create: `frontend/components/{IndexCard,MarketSentimentPanel,WorthConsideringTable,NewsFeed,StockSearch}.tsx`, `frontend/app/page.tsx`
- Test: `frontend/tests/components/{indexCard,worthConsidering,newsFeed}.test.tsx`

**Interfaces — Consumes:** `/markets`, `/market-status`, `/market-summary`, `/stocks` (enriched by Task 2), `/news` (Task 2). **Produces:** the PRD §3.1 dashboard.

- [ ] **Step 1: Write the failing tests**

`frontend/tests/components/worthConsidering.test.tsx`:
```tsx
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { WorthConsideringTable } from '../../components/WorthConsideringTable';

const row = (over: Record<string, unknown> = {}) => ({
  symbol: 'RELIANCE', company_name: 'Reliance Industries Ltd', sector: 'Energy',
  quote: { price: 1639.78, change_percent: 2.12 },
  evaluation: { action_state: 'WAIT_FOR_PULLBACK', recommendation_bias: 'HOLD_BIAS', overall_score: 70.85, risk_level: 'MEDIUM' },  // states from domain/enums.ts, not invented
  valuation_label: 'OVERVALUED', risk_reward: 2, sentiment_score: 45,
  scores: { technical: 86.69, news: 50 },
  ...over,
});

describe('WorthConsideringTable', () => {
  it('shows every PRD §3.1 column for a fully evaluated stock', async () => {
    render(<WorthConsideringTable rows={[row()]} />);
    const r = screen.getByRole('row', { name: /RELIANCE/ });
    expect(within(r).getByText('₹1,639.78')).toBeInTheDocument();
    expect(within(r).getByText('+2.12%')).toBeInTheDocument();
    expect(within(r).getByText(/wait for pullback/i)).toBeInTheDocument();
    expect(within(r).getByText(/overvalued/i)).toBeInTheDocument();
    expect(within(r).getByText('2.0')).toBeInTheDocument(); // R:R
  });

  it('renders an unevaluated stock as unavailable, not as zeros', async () => {
    // A stock the evaluation job has not reached yet must not look like a 0-score AVOID.
    render(<WorthConsideringTable rows={[row({ evaluation: null, quote: null, valuation_label: null, risk_reward: null, sentiment_score: null, scores: null })]} />);
    const r = screen.getByRole('row', { name: /RELIANCE/ });
    expect(within(r).queryByText('0')).not.toBeInTheDocument();
    expect(within(r).queryByText('₹0.00')).not.toBeInTheDocument();
    expect(within(r).getAllByText('—').length).toBeGreaterThan(3);
  });

  it('sorts by a numeric column without putting unavailable rows on top', async () => {
    const rows = [row({ symbol: 'AAA', evaluation: { ...row().evaluation, overall_score: 40 } }), row({ symbol: 'BBB', evaluation: null }), row({ symbol: 'CCC', evaluation: { ...row().evaluation, overall_score: 90 } })];
    render(<WorthConsideringTable rows={rows} />);
    await userEvent.click(screen.getByRole('button', { name: /overall/i }));
    const order = screen.getAllByRole('row').slice(1).map((r) => r.getAttribute('data-symbol'));
    // Descending by score, with the unmeasurable row last rather than ranked as a zero.
    expect(order).toEqual(['CCC', 'AAA', 'BBB']);
  });

  it('filters by action state', async () => {
    const rows = [row({ symbol: 'AAA', evaluation: { ...row().evaluation, action_state: 'BUY_ZONE' } }), row({ symbol: 'BBB' })];
    render(<WorthConsideringTable rows={rows} />);
    await userEvent.selectOptions(screen.getByLabelText(/action/i), 'BUY_ZONE');
    expect(screen.getByRole('row', { name: /AAA/ })).toBeInTheDocument();
    expect(screen.queryByRole('row', { name: /BBB/ })).not.toBeInTheDocument();
  });
});
```

`indexCard.test.tsx` asserts an index card shows price, change, change % with bull/bear tone, and a freshness badge — and that a card whose quote is null says so instead of showing ₹0.00. `newsFeed.test.tsx` asserts headline, source, IST published time, linked symbols and sentiment, and that it renders without sentiment (the job may not have run).

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.

- [ ] **Step 3: Implement**

`app/page.tsx` is a client component inside `<AuthGate>`. One `Promise.all` of the five reads, each independently failable — a dead `/market-summary` must not blank the index cards, mirroring the backend's own per-section isolation. Each panel gets `loading`, `error` and `empty` states.

`StockSearch` filters the already-fetched `/stocks` rows client-side by symbol, company name and ISIN (success criterion 3) and navigates to `/stocks/[symbol]`. No extra request per keystroke.

`MarketSentimentPanel` renders PRD §3.1's full set: sentiment, confidence, score, risk level, regime, summary, key drivers, key risks, positive and negative sectors — each list absent-safe.

- [ ] **Step 4: Verify by hand**

Start the API (`pnpm dev`) and the web app (`pnpm dev:web`), open `http://127.0.0.1:3000`, and confirm: 12 index cards with real mock prices, market status "Closed · next open …" in IST, the sentiment panel populated, 20 stocks in the table with prices and valuations, the news feed, the mock banner and the disclaimer. **Confirm in the browser console that there is no CORS error** — curl cannot prove this (it ignores CORS), and a mismatch between the page origin and `CORS_ORIGIN` is the single most likely setup failure (measured fact 9).

- [ ] **Step 5: Commit** `feat(frontend): dashboard with index cards, sentiment, worth-considering table, news`

---

### Task 7: The stock page shell, decision card and chart

**Files:**
- Create: `frontend/app/stocks/[symbol]/page.tsx`, `frontend/components/{StockHeader,DecisionCard,PriceChart}.tsx`
- Test: `frontend/tests/components/{decisionCard,priceChart}.test.tsx`

**Interfaces — Consumes:** `/stocks/:symbol` (the aggregate), `/stocks/:symbol/history` with indicators (Task 2).

- [ ] **Step 1: Write the failing tests**

`frontend/tests/components/decisionCard.test.tsx`:
```tsx
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { DecisionCard } from '../../components/DecisionCard';

const decision = {
  evaluated_at: '2026-10-07T05:35:15.862Z', data_as_of: '2026-10-06T03:45:00.000Z',
  scoring_config_version: 'v1', action_state: 'WAIT_FOR_PULLBACK', recommendation_bias: 'HOLD_BIAS',
  trend: 'UPTREND', risk_level: 'MEDIUM', market_regime: 'RISK_ON', overall_score: 70.85,
  risk_score: 37.29, coverage: 1, entry_low: 1366.93, entry_high: 1494.08, stop_loss: 1319.58,
  target_1: 1652.35, target_2: 1763.28, risk_reward: 2, position_size_hint: 90,
  invalidation: 'Re-evaluate on a pullback into ₹1,366.93–₹1,494.08; the setup fails below ₹1,319.58.',
} as const;
const fresh = { as_of: '2026-10-06T03:45:00.000Z', age_seconds: 110_226, stale: false, market_open: false, cadence: 'daily' as const };

describe('DecisionCard', () => {
  it('shows every PRD §3.2 field, including the invalidation condition', () => {
    render(<DecisionCard decision={decision} valuation={{ label: 'OVERVALUED', valuation_score: 1.07, quality_score: 57.07 }} analysisFreshness={fresh} now={new Date('2026-10-07T10:00:00Z')} />);
    expect(screen.getByText(/wait for pullback/i)).toBeInTheDocument();
    expect(screen.getByText('₹1,366.93 – ₹1,494.08')).toBeInTheDocument();
    expect(screen.getByText('₹1,319.58')).toBeInTheDocument();
    expect(screen.getByText('₹1,652.35')).toBeInTheDocument();
    expect(screen.getByText('₹1,763.28')).toBeInTheDocument();
    expect(screen.getByText('2.0')).toBeInTheDocument();
    expect(screen.getByText(/overvalued/i)).toBeInTheDocument();
    expect(screen.getByText(/medium/i)).toBeInTheDocument();
    // Success criterion 26: the invalidation is shown, not just computed.
    expect(screen.getByText(/setup fails below/i)).toBeInTheDocument();
  });

  it('never states a prediction, only a bias', () => {
    render(<DecisionCard decision={decision} valuation={null} analysisFreshness={fresh} now={new Date()} />);
    const text = document.body.textContent?.toLowerCase() ?? '';
    for (const banned of ['guaranteed', 'will rise', 'will fall', 'will definitely', 'sure-shot', 'risk-free', 'certain to']) {
      expect(text).not.toContain(banned);
    }
    expect(text).toMatch(/bias/);
  });

  it('renders levels as unavailable when the engine could not compute them', () => {
    // A low-coverage stock gets an action state but no levels. "₹0.00" would read as a free stock.
    render(<DecisionCard decision={{ ...decision, entry_low: null, entry_high: null, stop_loss: null, target_1: null, target_2: null, risk_reward: null }} valuation={null} analysisFreshness={fresh} now={new Date()} />);
    expect(screen.queryByText('₹0.00')).not.toBeInTheDocument();
    expect(screen.getAllByText('—').length).toBeGreaterThan(2);
  });

  it('says when the decision was computed, so a day-old call is not read as live', () => {
    render(<DecisionCard decision={decision} valuation={null} analysisFreshness={fresh} now={new Date('2026-10-07T10:00:00Z')} />);
    expect(screen.getByText(/1 day ago|30 hr ago/)).toBeInTheDocument();
  });
});
```

`priceChart.test.tsx` runs in jsdom, where lightweight-charts cannot paint. The test asserts the **binding**, which is where bugs live: that the component maps bars to `{time, open, high, low, close}` with second-resolution UTC timestamps, maps the three SMA series skipping nulls, and requests `createPriceLine` once per non-null level. Inject a fake chart factory:
```tsx
  it('binds bars, SMA overlays and decision levels to the chart API', () => {
    const series: Array<{ type: string; data: unknown[]; lines: unknown[] }> = [];
    const fakeChart = {
      addSeries: (definition: { type?: string }) => {
        const entry = { type: String(definition.type ?? 'unknown'), data: [] as unknown[], lines: [] as unknown[] };
        series.push(entry);
        return {
          setData: (d: unknown[]) => { entry.data = d; },
          createPriceLine: (l: unknown) => { entry.lines.push(l); return {}; },
          priceScale: () => ({ applyOptions: () => undefined }),
        };
      },
      timeScale: () => ({ fitContent: () => undefined, applyOptions: () => undefined }),
      applyOptions: () => undefined,
      remove: () => undefined,
      panes: () => [],
    };
    render(<PriceChart bars={BARS} indicators={INDICATORS} decision={decision} createChartImpl={() => fakeChart} />);
    // candles + 3 SMAs + volume
    expect(series).toHaveLength(5);
    const candles = series[0];
    expect(candles?.data).toHaveLength(BARS.length);
    // lightweight-charts wants seconds, not milliseconds: passing ms puts every bar in year 57000.
    expect((candles?.data[0] as { time: number }).time).toBe(Date.parse(BARS[0].ts) / 1000);
    // 5 price lines: entry low/high, SL, T1, T2 — and none for a null level.
    expect(candles?.lines).toHaveLength(5);
  });

  it('labels the time axis in IST, not UTC', () => {
    // lightweight-charts has no timezone option and renders UTC, so the 09:15 IST open would
    // read 03:45 on the axis — a chart that disagrees with every other panel on the page.
    let formatter: ((t: number) => string) | undefined;
    render(
      <PriceChart
        bars={BARS}
        indicators={INDICATORS}
        decision={decision}
        createChartImpl={(_el, opts) => {
          formatter = opts?.localization?.timeFormatter;
          return fakeChart;
        }}
      />,
    );
    expect(formatter?.(Date.parse('2026-10-07T03:45:00Z') / 1000)).toBe('9:15 am');
  });
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.

- [ ] **Step 3: Implement**

`PriceChart` uses the v5 API from measured fact 1: `createChart(el, opts)`, then `addSeries(CandlestickSeries)`, `addSeries(LineSeries)` ×3, `addSeries(HistogramSeries, {}, 1)` for volume on its own pane.

**The axis must be told about IST.** The library renders UTC and offers no timezone option, so the
NSE session would label `03:45–10:00` instead of `09:15–15:30`:
```ts
  createChart(el, {
    localization: { timeFormatter: (t: number) => formatIstTime(new Date(t * 1000).toISOString()) },
    timeScale: { tickMarkFormatter: (t: number) => formatIstTime(new Date(t * 1000).toISOString()) },
  });
``` Timeframe buttons 1D/1W/1M/3M/6M/1Y/5Y map to the API's `range`, and **only offer intervals the range allows** (`docs/api.md`'s table) so the UI cannot ask for a 400. `createPriceLine` draws entry/SL/targets, skipping nulls. Cleanup calls `chart.remove()` on unmount. Import the module dynamically (`await import('lightweight-charts')`) inside the mount effect — it is ESM-only and touches `window`, so a server-side import would break the build.

`StockHeader` shows company, symbol, exchange, price, change, change %, market status and "Data updated X min ago · source" (PRD §3.2).

- [ ] **Step 4: Run the gate, then verify by hand.** Load `/stocks/RELIANCE`: candles render, SMA 20/50/200 overlay, volume pane, the five horizontal level lines, timeframe switching works and never 400s.
- [ ] **Step 5: Commit** `feat(frontend): stock page shell, decision card, candlestick chart with overlays`

---

### Task 8: Technical, fundamentals, AI analysis and news panels

**Files:**
- Create: `frontend/components/{TechnicalPanel,FundamentalsPanel,AIAnalysisPanel,NewsPanel}.tsx`
- Modify: `frontend/app/stocks/[symbol]/page.tsx`
- Test: `frontend/tests/components/{technicalPanel,fundamentalsPanel,aiAnalysisPanel,newsPanel}.test.tsx`

**Interfaces — Consumes:** `/stocks/:symbol/technical`, `/fundamentals`, `/analysis`, `/news` (enriched in Task 2).

These four panels use the **dedicated endpoints**, not the aggregate's trimmed sections: the aggregate omits EMA, Stochastic, VWAP, volume-vs-average, the quarterly statements, the per-score breakdown and `invalidation_conditions`, all of which PRD §3.2 asks for.

- [ ] **Step 1: Write the failing tests**

`fundamentalsPanel.test.tsx` carries the PRD's exact wording requirement:
```tsx
  it('labels each missing metric "unavailable" rather than hiding the row', () => {
    render(<FundamentalsPanel snapshot={{ ...SNAPSHOT, roce: null, debt_to_equity: null }} statements={[]} />);
    expect(screen.getByText(/ROCE/)).toBeInTheDocument();
    // PRD §3.2: "A missing value shows 'unavailable'". Hiding the row hides the gap in coverage.
    expect(screen.getAllByText(/unavailable/i).length).toBeGreaterThanOrEqual(2);
  });

  it('says "Fundamental data unavailable" when there is nothing at all', () => {
    render(<FundamentalsPanel snapshot={null} statements={[]} />);
    expect(screen.getByText('Fundamental data unavailable')).toBeInTheDocument();
  });

  it('shows the quarterly series with revenue and profit', () => {
    render(<FundamentalsPanel snapshot={SNAPSHOT} statements={STATEMENTS} />);
    expect(screen.getByRole('table', { name: /quarterly/i })).toBeInTheDocument();
  });
```

`technicalPanel.test.tsx` asserts every PRD §3.2 indicator is present, each with a plain-language interpretation that contains **no predictive claim**:
```tsx
  it('interprets each indicator without predicting a price', () => {
    render(<TechnicalPanel data={TECHNICAL} />);
    expect(screen.getByText(/RSI/)).toBeInTheDocument();
    // RSI 75.8 is overbought territory — stated as a condition, not a forecast.
    expect(screen.getByText(/overbought/i)).toBeInTheDocument();
    const text = document.body.textContent?.toLowerCase() ?? '';
    for (const banned of ['will rise', 'will fall', 'guaranteed', 'expect a drop', 'certain to']) {
      expect(text).not.toContain(banned);
    }
  });

  it('omits no indicator, marking the ones not yet computed', () => {
    render(<TechnicalPanel data={{ ...TECHNICAL, indicators: { ...TECHNICAL.indicators, stoch_k: null, vwap: null } }} />);
    expect(screen.getByText(/stochastic/i)).toBeInTheDocument();
    expect(screen.queryByText('0.00')).not.toBeInTheDocument();
  });
```

`aiAnalysisPanel.test.tsx` pins the explainability contract (PRD §9.4, success criteria 11–15):
```tsx
  it('separates FACT from AI INTERPRETATION, and cites sources', () => {
    render(<AIAnalysisPanel analysis={ANALYSIS} />);
    expect(screen.getByRole('heading', { name: /facts/i })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /interpretation/i })).toBeInTheDocument();
    // Each fact names the evidence it rests on; a citation nobody can follow is not explainability.
    expect(screen.getByText('E1')).toBeInTheDocument();
    const link = screen.getByRole('link', { name: /annual general meeting/i });
    expect(link).toHaveAttribute('href', ANALYSIS.sources[1].url);
    expect(link).toHaveAttribute('rel', expect.stringContaining('noopener'));
  });

  it('shows confidence, risk and what the model lacked', () => {
    render(<AIAnalysisPanel analysis={ANALYSIS} />);
    expect(screen.getByText(/50%/)).toBeInTheDocument();          // confidence
    expect(screen.getByText(/medium/i)).toBeInTheDocument();      // risk level
    expect(screen.getByText(/insufficient data/i)).toBeInTheDocument();
    expect(screen.getByText(/mock-chat-v1/)).toBeInTheDocument(); // which model said this
  });

  it('renders an empty analysis as "not analysed yet", not as a neutral verdict', () => {
    // A stock the AI job has not reached must not display as a confident NEUTRAL.
    render(<AIAnalysisPanel analysis={null} />);
    expect(screen.getByText(/no AI analysis yet/i)).toBeInTheDocument();
    expect(screen.queryByText(/neutral/i)).not.toBeInTheDocument();
  });
```

`newsPanel.test.tsx` asserts headline, source, IST time, sentiment, impact, AI summary and an external link; and that an article without sentiment renders without one.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.
- [ ] **Step 3: Implement.** Each panel takes its data plus a `Freshness` and renders `<EmptyPanel>` when null. Indicator interpretation is a pure function in `lib/interpret.ts` — thresholds only (RSI > 70 "overbought", price above SMA 200 "above its long-term average"), stated as present conditions. No panel infers a direction.
- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(frontend): technical, fundamentals, AI analysis and news panels`

---

### Task 9: Q&A chat and the read-only signal card

**Files:**
- Create: `frontend/components/{QAChat,SignalCard}.tsx`
- Modify: `frontend/app/stocks/[symbol]/page.tsx`
- Test: `frontend/tests/components/{qaChat,signalCard}.test.tsx`

**Interfaces — Consumes:** `POST /stocks/:symbol/qa` (`{question}`, ≤ 500 chars, 30/hour), the aggregate's `signal` section.

**Scope ruling (owner's Phase 9 decision, carried forward):** the signal card is **read-only** in Phase 10. The order box, `/portfolio` and `/paper-trade/*` are Phase 11, where `PaperTradingService` makes them real. The card therefore states that acting on it requires Phase 11's paper-trade controls, rather than rendering a button that cannot work.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('QAChat', () => {
  it('asks only on submit — never on mount, because a question costs money', async () => {
    // PRD §14: the LLM is never called on page load. /qa is the one route on this page that
    // spends, so mounting the component must not call it.
    const post = vi.fn();
    render(<QAChat symbol="RELIANCE" post={post} />);
    expect(post).not.toHaveBeenCalled();
    await userEvent.type(screen.getByRole('textbox'), 'What is the trend?');
    await userEvent.click(screen.getByRole('button', { name: /ask/i }));
    expect(post).toHaveBeenCalledOnce();
  });

  it('shows the answer with its sources', async () => {
    const post = vi.fn().mockResolvedValue({ data: { answer: 'The stored evaluation shows an uptrend.', sources: [{ id: 'E1', title: 'EVALUATION', url: null, as_of: null, kind: 'EVALUATION' }], insufficient_data: [] } });
    render(<QAChat symbol="RELIANCE" post={post} />);
    await userEvent.type(screen.getByRole('textbox'), 'Trend?');
    await userEvent.click(screen.getByRole('button', { name: /ask/i }));
    expect(await screen.findByText(/stored evaluation shows an uptrend/)).toBeInTheDocument();
    expect(screen.getByText('E1')).toBeInTheDocument();
  });

  it('enforces the 500-character limit before spending a request', async () => {
    const post = vi.fn();
    render(<QAChat symbol="RELIANCE" post={post} />);
    await userEvent.type(screen.getByRole('textbox'), 'x'.repeat(501));
    await userEvent.click(screen.getByRole('button', { name: /ask/i }));
    // The server would 400; refusing locally keeps one of 30 hourly requests.
    expect(post).not.toHaveBeenCalled();
    expect(screen.getByText(/500/)).toBeInTheDocument();
  });

  it('explains a budget refusal in plain language rather than showing a 429', async () => {
    const post = vi.fn().mockRejectedValue(new ApiFailure('BUDGET_EXCEEDED', 429, 'spent'));
    render(<QAChat symbol="RELIANCE" post={post} />);
    await userEvent.type(screen.getByRole('textbox'), 'Trend?');
    await userEvent.click(screen.getByRole('button', { name: /ask/i }));
    expect(await screen.findByText(/daily AI budget/i)).toBeInTheDocument();
  });

  it('says so when AI is switched off (501) instead of looking broken', async () => {
    const post = vi.fn().mockRejectedValue(new ApiFailure('UNSUPPORTED', 501, 'disabled'));
    render(<QAChat symbol="RELIANCE" post={post} />);
    await userEvent.type(screen.getByRole('textbox'), 'Trend?');
    await userEvent.click(screen.getByRole('button', { name: /ask/i }));
    expect(await screen.findByText(/AI features are switched off/i)).toBeInTheDocument();
  });
});

describe('SignalCard', () => {
  it('shows the signal and states that acting on it is manual', () => {
    render(<SignalCard signal={SIGNAL} />);
    expect(screen.getByText(/entry/i)).toBeInTheDocument();
    // PRD §1/§11: nothing auto-trades, ever.
    expect(screen.getByText(/manual/i)).toBeInTheDocument();
  });

  it('renders no buy or sell control in Phase 10', () => {
    render(<SignalCard signal={SIGNAL} />);
    expect(screen.queryByRole('button', { name: /buy|sell|place order/i })).not.toBeInTheDocument();
  });
});
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.
- [ ] **Step 3: Implement.** `QAChat` keeps a local transcript (not persisted), disables the button while in flight to prevent a double-spend, and maps `BUDGET_EXCEEDED`, `RATE_LIMITED`, `UNSUPPORTED` and `INSUFFICIENT_DATA` to plain sentences. Check the live `/qa` response shape before writing the schema — read `backend/src/routes/actions.ts`'s qa handler rather than guessing.
- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(frontend): RAG Q&A chat and read-only signal card`

---

### Task 10: The admin page (`/admin`)

**Files:**
- Create: `frontend/app/admin/page.tsx`, `frontend/components/{HealthGrid,JobRunsTable,BudgetMeter,ActionButtons}.tsx`
- Test: `frontend/tests/components/{actionButtons,healthGrid}.test.tsx`

**Interfaces — Consumes:** `/system-status` (with Task 2's `jobs[]` and `llm_spend`), and the seven POST actions.

**Button mapping** — each maps to a real route or job name; none is invented:

| PRD §3.4 button | Call |
| --- | --- |
| Sync Market | `POST /sync/market` |
| Sync News | `POST /sync/news` |
| Sync Fundamentals | `POST /sync/fundamentals` |
| Run Technical + Run Evaluation | `POST /jobs/evaluation.compute/run` — one button for both, because the handler computes indicators in the same run (verified: its outcome message reports `${r.indicatorRows} indicator rows`). Label it "Run Technical + Evaluation" so the single button is not mistaken for half the work. |
| Run AI Analysis | `POST /jobs/ai.stock.analyze/run` |
| Generate Market Summary | `POST /jobs/ai.market.summary/run` |
| Purge Mock Data | **not built** — see below |

**Ruling: "Purge Mock Data" is not implemented.** No route or job exists, and it is destructive. Inventing a delete endpoint in a UI phase is exactly the kind of irreversible surface that should be designed deliberately, not as a button. The page states that mock data is cleared with `pnpm db:reset`. Flag it for the owner.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('ActionButtons', () => {
  it('fires nothing on mount — a page load must never trigger a job', async () => {
    const post = vi.fn();
    render(<ActionButtons post={post} role="OWNER" />);
    expect(post).not.toHaveBeenCalled();
  });

  it('runs a sync only on an explicit click, and reports the queued job', async () => {
    const post = vi.fn().mockResolvedValue({ data: { job: 'market.sync.eod', job_id: 'abc', already_queued: false } });
    render(<ActionButtons post={post} role="OWNER" />);
    await userEvent.click(screen.getByRole('button', { name: /sync market/i }));
    expect(post).toHaveBeenCalledWith('/sync/market', expect.anything());
    expect(await screen.findByText(/queued/i)).toBeInTheDocument();
  });

  it('says a job was already queued rather than looking like a lost click', async () => {
    const post = vi.fn().mockResolvedValue({ data: { job: 'market.sync.eod', job_id: null, already_queued: true } });
    render(<ActionButtons post={post} role="OWNER" />);
    await userEvent.click(screen.getByRole('button', { name: /sync market/i }));
    expect(await screen.findByText(/already queued/i)).toBeInTheDocument();
  });

  it('warns that a 202 does nothing without a running worker', async () => {
    const post = vi.fn().mockResolvedValue({ data: { job: 'news.sync', job_id: 'x', already_queued: false } });
    render(<ActionButtons post={post} role="OWNER" worker={{ status: 'unknown', live: 0, last_heartbeat: null }} />);
    await userEvent.click(screen.getByRole('button', { name: /sync news/i }));
    // docs/api.md: "a 202 promises nothing if no worker is running".
    expect(await screen.findByText(/no worker/i)).toBeInTheDocument();
  });

  it('shows a VIEWER why they cannot run actions, instead of a button that 403s', async () => {
    render(<ActionButtons post={vi.fn()} role="VIEWER" />);
    expect(screen.queryByRole('button', { name: /sync market/i })).not.toBeInTheDocument();
    expect(screen.getByText(/OWNER or ADMIN/i)).toBeInTheDocument();
  });

  it('offers no destructive purge control', () => {
    // No route exists and none is invented here.
    render(<ActionButtons post={vi.fn()} role="OWNER" />);
    expect(screen.queryByRole('button', { name: /purge|delete|wipe/i })).not.toBeInTheDocument();
  });

  it('disables a button while its request is in flight', async () => {
    let resolve: (v: unknown) => void = () => undefined;
    const post = vi.fn().mockReturnValue(new Promise((r) => { resolve = r; }));
    render(<ActionButtons post={post} role="OWNER" />);
    const button = screen.getByRole('button', { name: /sync market/i });
    await userEvent.click(button);
    expect(button).toBeDisabled();
    resolve({ data: { job: 'market.sync.eod', job_id: 'a', already_queued: false } });
  });
});
```

`healthGrid.test.tsx` asserts DB/market/news/LLM status, per-job last run with records and duration, the failures list, and a budget meter that reads "₹0.00 of ₹100.00 spent" and flags exhaustion — plus that a `database_status: 'down'` renders as a visible outage rather than a blank grid.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.
- [ ] **Step 3: Implement.** The page polls `/system-status` on an interval (30 s) with the tab-visibility check, so a backgrounded tab does not burn the rate limit. A 403 from `/system-status` means VIEWER: render the read-only view. Every action asks for confirmation before firing.
- [ ] **Step 4: Run the gate, then verify by hand** against the running API: click Sync Market, see the 202 and the job id, then watch `/system-status` show the run.
- [ ] **Step 5: Commit** `feat(frontend): admin page with health, job runs, budget and manual actions`

---

### Task 11: Bundle secret scan, Playwright E2E, docs, and Phase 10 verification

**Files:**
- Create: `frontend/playwright.config.ts`, `frontend/e2e/{dashboard,stock,admin}.spec.ts`, `scripts/scan-bundle.mjs`
- Modify: `README.md`, `docs/architecture.md`, `IMPLEMENTATION_PLAN.md`, `docs/api.md`, root `package.json`
- Test: `frontend/tests/unit/scanBundle.test.ts`

**Interfaces — Produces:** `pnpm scan:bundle` (success criterion 24), `pnpm test:e2e` (criteria 1–17, 21–23, 26).

E2E is **not in the main gate** (owner's decision): it needs Docker, a live API and a browser binary. It is written and run in this phase, then available on demand, exactly like `test:live`.

- [ ] **Step 1: Write the failing secret-scan test**

The scan is itself code that can be wrong, so it gets a test. A prefix check is not enough: the anon key and the service-role key **both start with `eyJ`** (measured), so the scan must decode and inspect the `role` claim.

`frontend/tests/unit/scanBundle.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { findSecrets } from '../../../scripts/scan-bundle.mjs';

const anon = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0';
const serviceRole = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU';

describe('findSecrets', () => {
  it('passes the anon key, which is meant to ship', () => {
    expect(findSecrets(`const k="${anon}";`, 'chunk.js')).toEqual([]);
  });

  it('catches a service-role key, which looks identical at a glance', () => {
    // Both start with eyJ and are the same length class. Only the decoded role tells them apart,
    // so a prefix or length check would wave this through.
    const found = findSecrets(`const k="${serviceRole}";`, 'chunk.js');
    expect(found).toHaveLength(1);
    expect(found[0]).toMatchObject({ kind: 'service_role_jwt' });
  });

  it('catches an OpenAI key, a DB URL with a password, and the JWT signing secret', () => {
    expect(findSecrets('sk-proj-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA', 'a.js')).toHaveLength(1);
    expect(findSecrets('postgresql://postgres:postgres@127.0.0.1:54322/postgres', 'a.js')).toHaveLength(1);
    expect(findSecrets('super-secret-jwt-token-with-at-least-32-characters-long', 'a.js')).toHaveLength(1);
  });

  it('does not fire on the words themselves, so the scan stays usable', () => {
    // A false positive that nobody can silence gets the whole scan disabled.
    expect(findSecrets('// set OPENAI_API_KEY in the backend env', 'a.js')).toEqual([]);
    expect(findSecrets('const label = "service_role";', 'a.js')).toEqual([]);
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module missing).

- [ ] **Step 3: Implement the scan**

`scripts/scan-bundle.mjs` exports `findSecrets(text, file)` and, run as a CLI, walks `frontend/.next/` (plus `frontend/out/` if present), reads every `.js`, `.json` and `.html`, and exits non-zero listing `{file, kind, excerpt}`. Detectors: JWT-shaped strings whose decoded payload has `role` other than `anon`/`authenticated`; `sk-` OpenAI keys; `postgres(ql)?://user:password@`; the literal `JWT_SECRET` value if `.env` is readable; `SUPABASE_SERVICE_ROLE_KEY` assignments. Add `"scan:bundle": "node scripts/scan-bundle.mjs"` to the root scripts.

- [ ] **Step 4: Write the Playwright specs**

`playwright.config.ts`: `baseURL: 'http://127.0.0.1:3000'`, one chromium project, `webServer` starting `pnpm dev` (frontend only — the API and DB must already be up, which the spec states), `TZ=UTC`.

The specs cover PRD §20 as **observable behaviour**, not implementation:
```ts
// e2e/dashboard.spec.ts
test('the dashboard opens with indices, search and a mock banner (criteria 1, 2, 3, 22)', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('alert')).toContainText(/simulated|mock/i);   // 22
  await expect(page.getByText('NIFTY 50')).toBeVisible();                   // 2
  await expect(page.getByText('SENSEX')).toBeVisible();                     // 2
  await page.getByRole('searchbox').fill('RELI');                           // 3
  await page.getByRole('link', { name: /RELIANCE/ }).first().click();
  await expect(page).toHaveURL(/\/stocks\/RELIANCE/);                       // 4
});

// e2e/stock.spec.ts — criteria 5-15, 26
test('the stock page shows a dated price, a chart, indicators, news and an explained decision', async ({ page }) => {
  await page.goto('/stocks/RELIANCE');
  await expect(page.getByText(/updated .* ago/i)).toBeVisible();            // 5
  await expect(page.locator('canvas')).toBeVisible();                       // 6
  await expect(page.getByText('RSI')).toBeVisible();                        // 7
  await expect(page.getByRole('heading', { name: /news/i })).toBeVisible(); // 8
  await expect(page.getByRole('heading', { name: /facts/i })).toBeVisible();        // 11, 12
  await expect(page.getByRole('heading', { name: /interpretation/i })).toBeVisible();
  await expect(page.getByText(/confidence/i)).toBeVisible();                // 13
  await expect(page.getByText(/risk/i)).toBeVisible();                      // 14
  await expect(page.getByText(/entry/i)).toBeVisible();                     // 26
  // No page load spends: the one route that costs money is only called on submit.
  const qa = page.waitForRequest((r) => r.url().includes('/qa'), { timeout: 2000 }).catch(() => null);
  expect(await qa).toBeNull();
});

test('a stock with no data renders rather than erroring', async ({ page }) => {
  await page.goto('/stocks/NOSUCHSYMBOL');
  await expect(page.getByText(/not found|unknown symbol/i)).toBeVisible();
  // Not a stack trace, not a blank page.
  await expect(page.locator('body')).not.toContainText('Application error');
});
```
Plus `admin.spec.ts`: health is visible (criterion 21), nothing fires on load, and a Sync Market click reports a queued job (criterion 17).

- [ ] **Step 5: Docs**

- **README:** a "Run the dashboard" section — `pnpm db:start`, `pnpm dev`, `pnpm worker`, `pnpm dev:web`, open `http://127.0.0.1:3000` (**127.0.0.1, not localhost**, and why), `frontend/.env.local` setup, the first-signup-becomes-OWNER rule, `AUTH_MODE=none` for local use, `pnpm scan:bundle`, `pnpm test:e2e`. Update the phase status table.
- **docs/architecture.md:** a "Frontend (Phase 10)" section — the shared zod contract as the boundary, client-side fetching and why no server proxy, per-section freshness cadence, the null-renders-unavailable rule, and the no-trade boundary.
- **docs/api.md:** the five new reads, the `cadence` field, and the `sources[].as_of` fix.
- **IMPLEMENTATION_PLAN.md:** Phase 10 ✅ with a link to this plan and its deviations.

- [ ] **Step 6: Full verification**

```bash
# db:reset first, deliberately: every test added in this phase seeds the rows it asserts on, so
# the suite must pass on an empty database. A green run that depends on what the dev worker
# happened to leave behind is not a green run.
pnpm db:reset && pnpm db:test
pnpm format:check && pnpm typecheck && pnpm test && pnpm lint
pnpm --filter @learning-stocks/backend build
pnpm --filter @learning-stocks/frontend build
pnpm scan:bundle                      # must find nothing
# with the API and worker running:
pnpm test:e2e
```
Expected: pgTAP green; the whole Vitest suite green (backend ~570+ and the new frontend tests); both builds clean; the scan silent; E2E green.

Then **by hand, in a real browser** — the only way to catch what no test can:
- `http://127.0.0.1:3000` renders with no CORS error in the console (curl cannot prove this).
- Hard-refresh the stock page: no hydration warning in the console.
- With `AUTH_MODE=jwt` set, the dashboard redirects to `/login`; sign up once; confirm the first account gets OWNER and admin actions work.
- Set `MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo` (news/fundamentals/llm `none`) and confirm the mock banner disappears and real prices render.

- [ ] **Step 7: Commit** `feat(frontend): bundle secret scan, Playwright E2E, docs; mark Phase 10 complete`

Then run the final fresh review, do one fix pass, and **stop for approval before Phase 11**.

---

## Deviations from the PRD (need your OK)

1. **No shadcn/ui.** PRD §4.3 names it; its CLI would rewrite this repo's Tailwind, tsconfig and path-alias decisions. Seven hand-written primitives cover what the pages use. Recharts is also dropped: lightweight-charts covers the price chart and nothing else needs a second chart library.
2. **Five additive backend read routes in a frontend phase.** PRD §3 asks for columns and panels the Phase 9 API cannot serve (market-wide news, enriched list, per-article sentiment, chart overlays, admin job detail). All are reads of stored rows. Approved by the owner before planning.
3. **Per-section freshness cadence, and `1d` returns null with no session.** Phase 9's deferred findings I4 and I2, fixed in the backend so every consumer benefits. Changes `/api` freshness semantics for daily sections — a visible behaviour change, hence listed here.
4. **`ai_analysis.sources[].asOf` → `as_of`.** A camelCase key in a snake_case payload. Breaking, but it is a Phase 9 bug and nothing consumes it yet.
5. **"Purge Mock Data" is not built.** PRD §3.4 lists the button; no route or job exists and it destroys data. The page points at `pnpm db:reset`. Needs your call.
6. **`/portfolio` is not built**, carrying forward the Phase 9 decision: it belongs with Phase 11's `PaperTradingService`. The nav shows it as "Phase 11" rather than linking to a dead page.
7. **E2E outside the gate**, as a `test:e2e` script. Your decision.
8. **Next 16 / React 19 / Tailwind 4 / lightweight-charts 5**, all majors ahead of what the PRD assumed, each probed under this repo's TS 6 strict settings before planning.
9. **`packages/shared` modules import each other by package name, not by relative path.** Unusual, and forced by a genuine toolchain conflict: NodeNext requires a `.js` suffix that Turbopack rejects (measured fact 13). The alternative — two copies of the schemas — is worse.

## Verification (end of phase)

- **Automated:** typecheck, lint, format, both builds; backend contract tests parsing real responses through the shared schemas; the cadence and `1d`-null tests; frontend unit tests for formatting (null, IST under `TZ=UTC`, Cr/L) and the API client; component tests for every panel's empty state, the freshness badge, the disclaimer's banned vocabulary, the admin buttons' no-fire-on-mount and VIEWER refusal; the bundle scan's own tests.
- **Not automated, run once:** `pnpm test:e2e` for success criteria 1–17, 21–23 and 26.
- **By hand:** no CORS error, no hydration warning, a real login against local Supabase, and one live-mode page load.
