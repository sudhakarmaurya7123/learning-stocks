# Phase 4: News + Fundamentals — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (Native, as in Phases 1–3) or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Real (RSS / NewsAPI / Yahoo) or mock news and fundamentals flow into `news`, `news_mentions`, `fundamental_snapshots` and `financial_statements` through provider-agnostic, validated, idempotent, logged pipelines. Each article is linked to the instruments it is about, with an explainable relevance score.

**Architecture:**
- `providers/news/` holds the `NewsProvider` contract plus Mock, RSS and NewsAPI adapters.
- `providers/fundamentals/` holds the `FundamentalsProvider` contract plus Mock and Yahoo adapters.
- Pure services sit in between:
  - `services/news/text.ts`: cleaning, URL canonicalisation, hashing.
  - `articleNormalizer.ts`: validation and in-batch dedupe.
  - `mentionMatcher.ts`: symbol/name/alias matching with relevance.
  - `services/fundamentals/numeric.ts`: column-range guard.
- Orchestration (resolve → fetch with retry → normalise → store → log the run) lives in `NewsService` and `FundamentalsService`.
- The factory picks adapters from config, and the DI container wires them. CLIs `pnpm sync:news` and `pnpm sync:fundamentals` run them now; cron jobs come in Phase 8.

**Tech Stack:** the existing Phase 2–3 stack + `fast-xml-parser@5.11.2` (RSS) + existing `yahoo-finance2@4.0.3` (`quoteSummary`, `fundamentalsTimeSeries`).

**Spec:** `PRD.md` §6 (providers, resilience), §7.4–7.5, §7.11, §10 (corpus), §13 (`news.sync`, `fundamentals.sync`); `IMPLEMENTATION_PLAN.md` Phase 4; `docs/architecture.md`.

## Live findings that shape the design (probed 2026-10-05)

- **Yahoo fundamentals work for NSE** (`quoteSummary` + `fundamentalsTimeSeries`), but the units are mixed:
  - ROE, margins, growth and `dividendYield` come as **fractions** (0.138).
  - `debtToEquity` comes as a **percent** (46.278 means 0.46).
  - Some fields are missing per stock (RELIANCE has no ROE).
  - Yahoo has no ROCE.
- **INFY reports its financials in USD** (`financialCurrency: 'USD'`). Its `totalRevenue`, `netIncomeToCommon` and every `fundamentalsTimeSeries` row (EPS 0.8) are USD. Its per-share and price-based fields are INR-consistent (1020.5 / 73.4 = 13.9 = `trailingPE`). Time-series rows carry no currency field.
- **Unknown symbols:**
  - `quoteSummary` throws `Error('Quote not found for symbol: X')`, which the existing `mapYahooError` maps to UNSUPPORTED.
  - `fundamentalsTimeSeries` returns `[]`.
- **HDFC Bank quarterly time-series rows are sparse** (balance-sheet fields only).
- **Feeds:**
  - Live: Google News search RSS (`hl=en-IN&gl=IN&ceid=IN:en`), Economic Times markets, Mint markets, Business Standard markets.
  - **Moneycontrol's feed is stale** (last build 2024), so it is excluded.
- **Google News feed details:**
  - Titles end in ` - Publisher`.
  - Links are `news.google.com` redirects.
  - `<source url="https://www.business-standard.com">` names the publisher.
  - The description is just the title plus the publisher, as HTML.
- **Other feed quirks:**
  - ET wraps titles in CDATA with trailing whitespace.
  - Mint wraps `link` and `pubDate` in CDATA.
- **`rss-parser` is unmaintained** (last release April 2023, built on xml2js, no timeout control).
- **NewsAPI free tier** (pricing page): 100 requests/day, articles delayed 24 h, search up to one month back. The key goes in the `x-api-key` header.

## Deviations from the PRD / outline (need your OK)

1. **`fast-xml-parser` instead of `rss-parser`.** Fetching uses our `httpRequest` (timeouts, URL redaction, error taxonomy).
2. **`NewsProvider.fetchForInstruments(group)` instead of `fetchForInstrument(one)`.** `capabilities().maxInstrumentsPerQuery` lets NewsAPI batch 10 companies per request (3 requests per run instead of 21). Both fetch methods return `{ articles, failures }`, so one dead RSS feed doesn't hide the others.
3. **New migration `20261005001200_aliases.sql`:** `aliases text[]` on `stocks` and `markets` (the schema had nowhere to keep them). Seeded in `seeds/08_aliases.sql`. **Owner to verify the list.**
4. **`content_hash = sha256(normalised title | publisher host | IST publish date)`.** The date is added because recurring column titles from the same publisher ("Ahead of Market: 10 things that will decide stock market action on Tuesday") would otherwise collide forever.
5. **`news.source` = the publisher's host** (`business-standard.com`), so a Google News copy and the publisher's own feed copy produce the same hash.
6. **Google News links are stored as-is** (redirect URLs). Resolving them needs an extra request per article, and Google obfuscates them.
7. **Units convention (documented in `docs/database.md`):**
   - Percent fields are percentages (13.8 = 13.8 %).
   - `debt_to_equity` is a ratio.
   - Money is absolute INR.
   - Capex is as reported (an outflow is negative).
8. **Fundamentals upsert, unlike market data:**
   - One snapshot per stock per IST day; a re-run that day refreshes it.
   - Statements upsert too, because companies restate.
   - `market_data` stays insert-only.
9. **Non-INR reporters (e.g. INFY):** absolute amounts (`revenue_ttm`, `net_profit_ttm`, `free_cash_flow`) are stored as null and statements are skipped. This is recorded as a **note, not a failure**, so runs aren't PARTIAL forever.
10. **ROCE stays null for Yahoo** (not provided, never derived). `revenue_growth_yoy` and `profit_growth_yoy` from Yahoo are latest-quarter YoY.
11. **NewsAPI is fixture-tested only** (no key yet). Because of the free tier, Phase 8 must schedule NewsAPI runs ≤ ~30/day.
12. **Mock news is clearly synthetic:**
    - `[MOCK] ` title prefix.
    - Qualitative headlines with no numbers.
    - URLs on the reserved `.invalid` TLD.

## Global Constraints

- Everything from Phases 2–3 still applies:
  - the gate `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`, preceded by `pnpm format` before each commit (the plan's snippets are not prettier-formatted)
  - `TZ=UTC` tests
  - no `any` or `!`
  - ESM `.js` imports
  - commits end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`
  - branch `phase-4-news-fundamentals`
- Stored rows: `data_mode` = `config.dataMode`, and `source` = `provider.name` (fundamentals) or the publisher host (news). Mock and live never mix.
- Never invent data:
  - Unavailable → `null`.
  - An article with no parseable date is dropped, never stamped with fetch time.
  - No metric is derived from other metrics in live mode.
- No LLM calls in this phase (sentiment is Phase 7, embeddings Phase 6).
- One feed, query or stock failing never aborts a run. `AUTH_FAILED` and `UNSUPPORTED` are not retried.
- API keys never appear in URLs or logs (NewsAPI key in the `x-api-key` header, which is redacted).
- Integration tests call `isolateTables` for the tables they assert on, so locally synced data can't break them.

## Review Focus

1. **Non-INR reporting currency (INFY):** absolute amounts are null, statements are skipped, a note is written and the run stays SUCCESS. Covered in Task 11.
2. **The same article arriving by two routes** (instrument query + market feed; Google copy + publisher feed): one `news` row, mentions attach to the existing id, and the best relevance wins. A URL conflict with an edited title still resolves the id. Covered in Tasks 7–8.
3. **Ambiguous names:**
   - "Nifty Bank" must not also mention NIFTY 50.
   - "SBI Life", "L&T Finance", "ITC Hotels" and "Nifty Midcap" must not mention SBIN, LT, ITC or NIFTY 50.
   - Lowercase "ril" and "April" must not mention RELIANCE.
   - A query-only hit or a body mention in a roundup article must land below the seeded `news_relevance_threshold` (0.5).
   - Covered in Task 3.
4. **Feed quirks:**
   - A single-item feed is parsed as an array.
   - CDATA links and dates work.
   - A numeric-looking title stays a string.
   - An HTML bot-block page is INVALID_RESPONSE.
   - A missing or garbled `pubDate` drops the item.
   - Covered in Tasks 2 and 5.
5. **Partial failure:** one feed 403s, one query times out, one stock is delisted. The others are stored and the run is PARTIAL, with failures listed in `system_logs.error_details`. Covered in Tasks 8 and 11.

## File structure

```
supabase/migrations/20261005001200_aliases.sql; supabase/seeds/08_aliases.sql; supabase/tests/database/12_aliases.test.sql (Task 1)
backend/src/
├── domain/types.ts (+aliases), domain/news.ts, domain/fundamentals.ts                     (Tasks 1, 2, 9)
├── utils/errors.ts (+toAppError), utils/logger.ts (+x-api-key redaction)                   (Tasks 2, 6)
├── providers/news/types.ts                                                                  (Task 2)
├── providers/news/mock/MockNewsProvider.ts                                                  (Task 4)
├── providers/news/rss/{feedParser.ts, RssNewsProvider.ts}                                   (Task 5)
├── providers/news/newsapi/NewsApiProvider.ts                                                (Task 6)
├── providers/fundamentals/types.ts, providers/fundamentals/mock/MockFundamentalsProvider.ts (Task 9)
├── providers/yahoo/instance.ts; providers/fundamentals/yahoo/{yahooFundamentalsClient.ts, YahooFundamentalsProvider.ts} (Task 10)
├── services/news/{text.ts, articleNormalizer.ts}  (Task 2), mentionMatcher.ts (Task 3), NewsService.ts (Task 8)
├── services/fundamentals/{numeric.ts (Task 9), FundamentalsService.ts (Task 11)}
├── repositories/{NewsRepository.ts (Task 7), FundamentalsRepository.ts (Task 11)}
└── providers/factory.ts, container.ts, cli/{sync-news.ts, sync-fundamentals.ts}            (Task 12)
backend/tests/{unit,integration,live,fixtures/news}/…
```

Task order: 1 aliases → 2 news contract and text → 3 matcher → 4 mock news → 5 RSS → 6 NewsAPI → 7 news repository → 8 NewsService → 9 fundamentals contract and mock → 10 Yahoo fundamentals → 11 fundamentals repository and service → 12 wiring and CLIs → 13 docs and verification.

---

### Task 1: Instrument aliases (migration, seed, pgTAP, domain)

**Files:**
- Create:
  - `supabase/migrations/20261005001200_aliases.sql`
  - `supabase/seeds/08_aliases.sql`
  - `supabase/tests/database/12_aliases.test.sql`
- Modify:
  - `backend/src/domain/types.ts` (`aliases: string[]` on `Stock` and `Market`)
  - `backend/src/repositories/StockRepository.ts` (`mapStock`)
  - `backend/src/repositories/MarketRepository.ts` (`mapMarket`)
  - `backend/src/database/types.generated.ts` (regenerated)
- Test: `backend/tests/integration/referenceRepositories.test.ts` (new case)

**Interfaces — Produces:** `Stock.aliases: string[]`, `Market.aliases: string[]` (never null; may be empty).

- [ ] **Step 1: Branch, commit the plan, write the failing tests**

```bash
git checkout -b phase-4-news-fundamentals
git add docs/superpowers/plans/2026-10-05-phase-4-news-fundamentals.md
git commit -m "docs: Phase 4 implementation plan (news + fundamentals)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```
`supabase/tests/database/12_aliases.test.sql`:
```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(5);

select has_column('public', 'stocks', 'aliases', 'stocks.aliases exists');
select has_column('public', 'markets', 'aliases', 'markets.aliases exists');
select throws_ok($$update public.stocks set aliases = array['RIL', ''] where symbol = 'RELIANCE'$$,
  '23514', null, 'empty alias rejected');
select ok((select 'RIL' = any (aliases) from public.stocks where symbol = 'RELIANCE' and exchange = 'NSE'),
  'RELIANCE alias RIL seeded');
select ok((select 'Bank Nifty' = any (aliases) from public.markets where symbol = 'BANKNIFTY'),
  'BANKNIFTY alias seeded');

select * from finish();
rollback;
```
Append to the `StockRepository` describe in `backend/tests/integration/referenceRepositories.test.ts`:
```ts
  it('exposes aliases for news matching (empty array when none)', async () => {
    expect((await repo.findBySymbol('LT'))?.aliases).toEqual(['L&T', 'Larsen and Toubro']);
    expect((await repo.findBySymbol('INFY'))?.aliases).toEqual([]);
    expect((await new MarketRepository(db).findBySymbol('NIFTY50'))?.aliases).toContain('Nifty');
  });
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm db:test`. Expected: FAIL (12_aliases: column missing).
Run: `pnpm --filter @learning-stocks/backend typecheck`. Expected: FAIL (`aliases` not on `Stock`).

- [ ] **Step 3: Implement**

`supabase/migrations/20261005001200_aliases.sql`:
```sql
-- Alternative names used by news mention matching (e.g. 'RIL', 'L&T', 'Bank Nifty').
-- Data, not code: adding an alias is an UPDATE. Matching rules: docs/architecture.md (News).
alter table public.stocks
  add column aliases text[] not null default '{}',
  add constraint stocks_aliases_valid
    check (array_position(aliases, null) is null and array_position(aliases, '') is null);

alter table public.markets
  add column aliases text[] not null default '{}',
  add constraint markets_aliases_valid
    check (array_position(aliases, null) is null and array_position(aliases, '') is null);
```
`supabase/seeds/08_aliases.sql`:
```sql
-- News-matching aliases. OWNER: verify. Precision beats recall: a wrong alias attaches unrelated news.
-- The company name (minus "Limited") and the symbol (3+ chars) are matched automatically; list only extra names.
-- An alias with no lowercase letters (RIL, SBI, L&T) matches case-sensitively; others ignore case.
update public.stocks s set aliases = v.aliases
  from (values
    ('RELIANCE',   array['RIL']),
    ('TCS',        array['Tata Consultancy']),
    ('SBIN',       array['SBI']),
    ('BHARTIARTL', array['Airtel']),
    ('LT',         array['L&T', 'Larsen and Toubro']),
    ('KOTAKBANK',  array['Kotak Bank']),
    ('MARUTI',     array['Maruti Suzuki', 'Maruti']),
    ('SUNPHARMA',  array['Sun Pharma']),
    ('HINDUNILVR', array['HUL']),
    ('ADANIPORTS', array['Adani Ports', 'APSEZ']),
    ('HCLTECH',    array['HCLTech', 'HCL Tech'])
  ) as v(symbol, aliases)
 where s.symbol = v.symbol and s.exchange = 'NSE';

update public.markets m set aliases = v.aliases
  from (values
    ('NIFTY50',         array['Nifty 50', 'Nifty50', 'Nifty']),
    ('SENSEX',          array['Sensex', 'BSE Sensex']),
    ('BANKNIFTY',       array['Nifty Bank', 'Bank Nifty']),
    ('NIFTYIT',         array['Nifty IT']),
    ('NIFTYPHARMA',     array['Nifty Pharma']),
    ('NIFTYAUTO',       array['Nifty Auto']),
    ('NIFTYFMCG',       array['Nifty FMCG']),
    ('NIFTYMETAL',      array['Nifty Metal']),
    ('NIFTYREALTY',     array['Nifty Realty']),
    ('NIFTYFINSERVICE', array['Nifty Financial Services', 'Nifty Fin Service', 'FinNifty', 'Fin Nifty']),
    ('NIFTYENERGY',     array['Nifty Energy']),
    ('INDIAVIX',        array['India VIX', 'VIX'])
  ) as v(symbol, aliases)
 where m.symbol = v.symbol;
```
In `backend/src/domain/types.ts`, add `aliases: string[];` to `Stock` (after `isActive`) and to `Market` (after `isActive`). In `mapStock` add `aliases: row.aliases,`; in `mapMarket` add `aliases: row.aliases,`.

Regenerate the types and fix any test literal that builds a `Stock`/`Market` (add `aliases: []`):
```bash
pnpm db:reset && pnpm --filter @learning-stocks/backend db:types
grep -rn "companyName:" backend/tests backend/src | grep -v repositories/
```

- [ ] **Step 4: Run the gate**

```bash
pnpm db:test     # expect 118 tests PASS (113 + 5)
pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint
```
Expected: PASS. `db:reset` wiped synced data. Re-run `pnpm sync:market` later if you want it back (Task 13 does).

- [ ] **Step 5: Commit** `feat(db): instrument aliases for news mention matching`.

---

### Task 2: News contract, text utilities, article normalizer

**Files:**
- Create:
  - `backend/src/providers/news/types.ts`
  - `backend/src/domain/news.ts`
  - `backend/src/services/news/text.ts`
  - `backend/src/services/news/articleNormalizer.ts`
- Modify: `backend/src/utils/errors.ts` (`toAppError`)
- Test: `backend/tests/unit/newsText.test.ts`, `backend/tests/unit/articleNormalizer.test.ts`, plus a new case in `backend/tests/unit/errors.test.ts`

**Interfaces — Produces:**
- `providers/news/types.ts`: `NewsSubject`, `NewsCapabilities`, `InstrumentNewsQuery`, `MarketNewsQuery`, `RawArticle`, `SourceFailure`, `NewsFetchResult`, `NewsProvider` (code below).
- `domain/news.ts`:
  - `NewsArticle { dataMode; title; description: string|null; content: string|null; source; sourceUrl; author: string|null; publishedAt: Date; language; contentHash }`
  - `NewsMention { newsId; ref: InstrumentRef; relevance; matchedBy }`
  - `NewsItem { id; title; description; source; sourceUrl; publishedAt; relevance; matchedBy }`
- `text.ts`: `decodeEntities`, `stripHtml`, `cleanText(value, maxLength)`, `canonicalizeUrl(url): string|null`, `sourceKey(url): string|null`, `normalizeForHash`, `contentHash(title, source, publishedAt: Date)`.
- `articleNormalizer.ts`:
  - `ArticleDropReason`
  - `TaggedRawArticle { article: RawArticle; queriedFor: readonly string[] }`
  - `NormalizedArticle extends NewsArticle { queriedFor: string[] }`
  - `normalizeArticles(raw, { dataMode, now, since }): { articles; dropped }` (newest first)
  - `ARTICLE_LIMITS`
- `errors.ts`: `toAppError(error: unknown): AppError` (`AppError` passes through; anything else becomes `INTERNAL` with the message).

- [ ] **Step 1: Write the failing tests**

Append to `backend/tests/unit/errors.test.ts` (inside the top-level describe or as a new one; add `toAppError` to the import):
```ts
describe('toAppError', () => {
  it('passes AppErrors through and wraps anything else as INTERNAL', () => {
    const e = new AppError('TIMEOUT', 'slow');
    expect(toAppError(e)).toBe(e);
    expect(toAppError(new Error('boom'))).toMatchObject({ code: 'INTERNAL', message: 'boom' });
    expect(toAppError('text')).toMatchObject({ code: 'INTERNAL', message: 'text' });
  });
});
```
`backend/tests/unit/newsText.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import {
  canonicalizeUrl, cleanText, contentHash, decodeEntities, sourceKey, stripHtml,
} from '../../src/services/news/text.js';

describe('news text utilities', () => {
  it('decodes named and numeric entities, leaving unknown ones', () => {
    expect(decodeEntities('Tom &amp; Jerry&#39;s &#x20B9;5 &nbsp;x &bogus;')).toBe("Tom & Jerry's ₹5  x &bogus;");
  });

  it('strips HTML (Google News description) to plain text', () => {
    const html = '<a href="https://news.google.com/x" target="_blank">HDFC Bank Q2 update</a>&nbsp;&nbsp;<font color="#6f6f6f">Sahi</font>';
    expect(stripHtml(html)).toBe('HDFC Bank Q2 update Sahi');
    expect(stripHtml('a<script>alert(1)</script>b<br/>c')).toBe('a b c');
  });

  it('cleans and truncates text, returning null for blanks', () => {
    expect(cleanText('  <p>Hello</p>  ', 100)).toBe('Hello');
    expect(cleanText('a'.repeat(10), 5)).toBe('aaaa…');
    expect(cleanText('   ', 10)).toBeNull();
    expect(cleanText(null, 10)).toBeNull();
  });

  it('canonicalises URLs: lowercase host, no fragment or tracking params, sorted query, no trailing slash', () => {
    expect(canonicalizeUrl('HTTPS://Example.COM/a/b/?utm_source=x&id=2&oc=5&b=1#frag')).toBe('https://example.com/a/b?b=1&id=2');
    expect(canonicalizeUrl('https://example.com/')).toBe('https://example.com/');
    expect(canonicalizeUrl('javascript:alert(1)')).toBeNull();
    expect(canonicalizeUrl('not a url')).toBeNull();
  });

  it('derives the publisher key from a URL host', () => {
    expect(sourceKey('https://www.Business-Standard.com/markets/x')).toBe('business-standard.com');
    expect(sourceKey('nope')).toBeNull();
  });

  it('hashes title + source + IST publish date, ignoring case and punctuation', () => {
    const at = new Date('2026-10-05T10:00:00Z');
    const a = contentHash('Reliance Q2: profit rises!', 'example.com', at);
    expect(a).toMatch(/^[a-f0-9]{64}$/);
    expect(contentHash('reliance q2   profit rises', 'EXAMPLE.com', new Date('2026-10-05T17:00:00Z'))).toBe(a);
    expect(contentHash('Reliance Q2: profit rises!', 'other.com', at)).not.toBe(a);
    // 2026-10-05T19:00Z is 2026-10-06 00:30 IST: a different IST day.
    expect(contentHash('Reliance Q2: profit rises!', 'example.com', new Date('2026-10-05T19:00:00Z'))).not.toBe(a);
  });
});
```
`backend/tests/unit/articleNormalizer.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import type { RawArticle } from '../../src/providers/news/types.js';
import { normalizeArticles, type TaggedRawArticle } from '../../src/services/news/articleNormalizer.js';

const NOW = new Date('2026-10-05T12:00:00Z');
const ctx = { dataMode: 'LIVE' as const, now: NOW, since: new Date('2026-09-28T00:00:00Z') };
const raw = (over: Partial<RawArticle> = {}): RawArticle => ({
  title: 'Reliance Industries raises funds via bonds',
  url: 'https://www.business-standard.com/markets/news/reliance-bonds-1.html',
  description: null, content: null, author: null,
  publishedAt: new Date('2026-10-05T06:00:00Z'), publisherUrl: null, language: null, ...over,
});
const tag = (article: RawArticle, queriedFor: string[] = []): TaggedRawArticle => ({ article, queriedFor });

describe('normalizeArticles', () => {
  it('keeps a valid article, deriving source from the link host and defaulting language', () => {
    const r = normalizeArticles([tag(raw())], ctx);
    expect(r.articles).toHaveLength(1);
    expect(r.articles[0]).toMatchObject({
      dataMode: 'LIVE', title: 'Reliance Industries raises funds via bonds', source: 'business-standard.com',
      sourceUrl: 'https://www.business-standard.com/markets/news/reliance-bonds-1.html', language: 'en', queriedFor: [],
    });
    expect(r.articles[0]?.contentHash).toMatch(/^[a-f0-9]{64}$/);
  });

  it('drops (never repairs) missing titles, bad URLs, missing/garbled dates, future and stale items', () => {
    const r = normalizeArticles([
      tag(raw({ title: '  ' })),
      tag(raw({ url: 'ftp://x.example/a' })),
      tag(raw({ publishedAt: null })),
      tag(raw({ publishedAt: new Date('garbage') })),
      tag(raw({ publishedAt: new Date(NOW.getTime() + 10 * 60_000) })),
      tag(raw({ publishedAt: new Date('2026-09-01T00:00:00Z') })),
      tag(raw({ title: 'Within tolerance', url: 'https://x.example/ok', publishedAt: new Date(NOW.getTime() + 2 * 60_000) })),
    ], ctx);
    expect(r.articles.map((a) => a.title)).toEqual(['Within tolerance']);
    expect(r.dropped).toEqual({ MISSING_TITLE: 1, INVALID_URL: 1, INVALID_DATE: 2, FUTURE_DATE: 1, TOO_OLD: 1 });
  });

  it('prefers the publisher URL (Google News) for source and drops a description that only repeats the title', () => {
    const r = normalizeArticles([tag(raw({
      url: 'https://news.google.com/rss/articles/CBMi123?oc=5',
      publisherUrl: 'https://www.business-standard.com',
      description: '<a href="https://news.google.com/rss/articles/CBMi123">Reliance Industries raises funds via bonds</a>&nbsp;&nbsp;<font>Business Standard</font>',
    }))], ctx);
    expect(r.articles[0]).toMatchObject({ source: 'business-standard.com', sourceUrl: 'https://news.google.com/rss/articles/CBMi123', description: null });
    const kept = normalizeArticles([tag(raw({ description: '<p>The company raised &#8377;13,000 crore through 10-year bonds.</p>' }))], ctx);
    expect(kept.articles[0]?.description).toBe('The company raised ₹13,000 crore through 10-year bonds.');
  });

  it('merges the same story from two routes (same title + publisher + day, or same URL) and unions queriedFor', () => {
    const google = raw({ url: 'https://news.google.com/rss/articles/A?oc=5', publisherUrl: 'https://www.business-standard.com' });
    const direct = raw({ publishedAt: new Date('2026-10-05T06:03:00Z') });
    const editedTitle = raw({ title: 'Reliance Industries raises ₹13,000 crore via bonds' });
    const r = normalizeArticles([tag(google, ['RELIANCE']), tag(direct), tag(editedTitle, ['TCS'])], ctx);
    expect(r.articles).toHaveLength(1);
    expect(r.articles[0]?.queriedFor).toEqual(['RELIANCE', 'TCS']);
    expect(r.dropped).toEqual({ DUPLICATE_IN_BATCH: 2 });
  });

  it('sorts newest first and normalises language tags', () => {
    const r = normalizeArticles([
      tag(raw({ title: 'Older', url: 'https://x.example/1', publishedAt: new Date('2026-10-04T06:00:00Z'), language: 'en-IN' })),
      tag(raw({ title: 'Newer', url: 'https://x.example/2', publishedAt: new Date('2026-10-05T06:00:00Z') })),
    ], ctx);
    expect(r.articles.map((a) => [a.title, a.language])).toEqual([['Newer', 'en'], ['Older', 'en']]);
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`. Expected: FAIL (modules and `toAppError` missing).

- [ ] **Step 3: Implement**

Append to `backend/src/utils/errors.ts`:
```ts
/** Normalises any thrown value: AppErrors pass through, anything else is an INTERNAL error (a bug). */
export function toAppError(error: unknown): AppError {
  if (isAppError(error)) return error;
  return new AppError('INTERNAL', error instanceof Error ? error.message : String(error), { cause: error });
}
```
`backend/src/providers/news/types.ts`:
```ts
import type { ErrorCode } from '../../utils/errors.js';

/** What a provider needs to search news for one instrument. name = company name without "Limited". */
export interface NewsSubject {
  symbol: string;
  name: string;
  aliases: readonly string[];
}

export interface NewsCapabilities {
  /** Instruments one fetchForInstruments call may cover (NewsAPI batches to save its daily quota). */
  maxInstrumentsPerQuery: number;
  /** Free NewsAPI delays articles by 24 h. */
  latency: 'realtime' | 'delayed';
}

export interface InstrumentNewsQuery {
  subjects: readonly NewsSubject[];
  since: Date;
  limit: number;
}

export interface MarketNewsQuery {
  since: Date;
  limit: number;
}

/** An article exactly as the provider reported it. The normalizer decides what is stored. */
export interface RawArticle {
  title: string | null;
  url: string | null;
  /** May contain HTML. */
  description: string | null;
  content: string | null;
  author: string | null;
  publishedAt: Date | null;
  /** Publisher home page (Google News <source url>); falls back to the article URL's host. */
  publisherUrl: string | null;
  language: string | null;
}

export interface SourceFailure {
  source: string;
  code: ErrorCode;
  message: string;
}

/** Partial results are normal for multi-feed providers: one dead feed must not hide the others. */
export interface NewsFetchResult {
  articles: RawArticle[];
  failures: SourceFailure[];
}

/** All news enters the system through this interface. Providers never touch the database. */
export interface NewsProvider {
  readonly name: string;
  capabilities(): NewsCapabilities;
  fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult>;
  fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult>;
}
```
`backend/src/domain/news.ts`:
```ts
import type { DataMode } from './enums.js';
import type { InstrumentRef } from './types.js';

/** A validated article ready to store. source = publisher host, e.g. 'business-standard.com'. */
export interface NewsArticle {
  dataMode: DataMode;
  title: string;
  description: string | null;
  content: string | null;
  source: string;
  sourceUrl: string;
  author: string | null;
  publishedAt: Date;
  language: string;
  contentHash: string;
}

/** matchedBy explains the score, e.g. 'name:title', 'alias:description', 'query'. */
export interface NewsMention {
  newsId: string;
  ref: InstrumentRef;
  relevance: number;
  matchedBy: string;
}

export interface NewsItem {
  id: string;
  title: string;
  description: string | null;
  source: string;
  sourceUrl: string;
  publishedAt: Date;
  relevance: number;
  matchedBy: string;
}
```
`backend/src/services/news/text.ts`:
```ts
import { createHash } from 'node:crypto';
import { toIst } from '../../utils/ist.js';

const NAMED_ENTITIES: Readonly<Record<string, string>> = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
  ndash: '–', mdash: '—', lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”', hellip: '…',
};

export function decodeEntities(text: string): string {
  return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, body: string) => {
    if (body.startsWith('#')) {
      const hex = body[1] === 'x' || body[1] === 'X';
      const code = Number.parseInt(body.slice(hex ? 2 : 1), hex ? 16 : 10);
      return Number.isFinite(code) && code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : whole;
    }
    return NAMED_ENTITIES[body.toLowerCase()] ?? whole;
  });
}

/** Plain text from an HTML fragment: scripts/styles and tags removed, entities decoded, whitespace collapsed. */
export function stripHtml(html: string): string {
  const noTags = html
    .replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<[^>]*>/g, ' ');
  return decodeEntities(noTags).replace(/\s+/g, ' ').trim();
}

export function cleanText(value: string | null | undefined, maxLength: number): string | null {
  if (value === null || value === undefined) return null;
  const text = stripHtml(value);
  if (text === '') return null;
  return text.length <= maxLength ? text : `${text.slice(0, maxLength - 1).trimEnd()}…`;
}

const TRACKING_PARAM = /^(utm_[a-z]+|fbclid|gclid|dclid|mc_cid|mc_eid|ref|ref_src|cmpid|oc)$/i;

/** Stable form of an article URL so the same link is stored once. null = not an http(s) URL. */
export function canonicalizeUrl(raw: string): string | null {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return null;
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
  url.hash = '';
  url.username = '';
  url.password = '';
  for (const key of [...url.searchParams.keys()]) {
    if (TRACKING_PARAM.test(key)) url.searchParams.delete(key);
  }
  url.searchParams.sort();
  if (url.pathname.length > 1) url.pathname = url.pathname.replace(/\/+$/, '');
  return url.toString();
}

/** Publisher key: lowercase host without "www.". */
export function sourceKey(url: string): string | null {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^www\./, '');
    return host === '' ? null : host;
  } catch {
    return null;
  }
}

export function normalizeForHash(text: string): string {
  return text.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

/**
 * Duplicate key for one story: normalised title + publisher + IST publish date.
 * The date keeps recurring column titles ("Ahead of Market: …") from colliding across weeks.
 */
export function contentHash(title: string, source: string, publishedAt: Date): string {
  const key = `${normalizeForHash(title)}|${source.toLowerCase()}|${toIst(publishedAt).date}`;
  return createHash('sha256').update(key).digest('hex');
}
```
`backend/src/services/news/articleNormalizer.ts`:
```ts
import type { DataMode } from '../../domain/enums.js';
import type { NewsArticle } from '../../domain/news.js';
import type { RawArticle } from '../../providers/news/types.js';
import { canonicalizeUrl, cleanText, contentHash, normalizeForHash, sourceKey } from './text.js';

/** title matches the DB check; the rest keep rows and LLM context bounded. */
export const ARTICLE_LIMITS = { title: 1000, description: 2000, content: 20_000, author: 200 } as const;
const FUTURE_TOLERANCE_MS = 5 * 60_000;
/** A description that is the title plus at most this many characters (e.g. a publisher name) adds nothing. */
const REDUNDANT_SUFFIX_MAX = 40;

export type ArticleDropReason =
  | 'MISSING_TITLE' | 'INVALID_URL' | 'INVALID_DATE' | 'FUTURE_DATE' | 'TOO_OLD' | 'DUPLICATE_IN_BATCH';

/** queriedFor: internal symbols whose single-instrument query returned the article. */
export interface TaggedRawArticle {
  article: RawArticle;
  queriedFor: readonly string[];
}

export interface NormalizedArticle extends NewsArticle {
  queriedFor: string[];
}

export interface NormalizeArticlesContext {
  dataMode: DataMode;
  now: Date;
  since: Date;
}

export interface NormalizeArticlesResult {
  articles: NormalizedArticle[];
  dropped: Partial<Record<ArticleDropReason, number>>;
}

function bump(counts: Partial<Record<ArticleDropReason, number>>, key: ArticleDropReason): void {
  counts[key] = (counts[key] ?? 0) + 1;
}

function redundant(title: string, description: string): boolean {
  const t = normalizeForHash(title);
  const d = normalizeForHash(description);
  return d === t || (d.startsWith(t) && d.length - t.length <= REDUNDANT_SUFFIX_MAX);
}

/**
 * Validates provider articles. Never repairs: an article without a usable title, URL or
 * publish date is dropped (a missing date is never replaced by the fetch time).
 */
export function normalizeArticles(raw: readonly TaggedRawArticle[], ctx: NormalizeArticlesContext): NormalizeArticlesResult {
  const dropped: NormalizeArticlesResult['dropped'] = {};
  const articles: NormalizedArticle[] = [];
  const byHash = new Map<string, NormalizedArticle>();
  const byUrl = new Map<string, NormalizedArticle>();

  for (const { article: a, queriedFor } of raw) {
    const title = cleanText(a.title, ARTICLE_LIMITS.title);
    if (!title) {
      bump(dropped, 'MISSING_TITLE');
      continue;
    }
    const sourceUrl = a.url ? canonicalizeUrl(a.url) : null;
    const source = sourceUrl ? ((a.publisherUrl ? sourceKey(a.publisherUrl) : null) ?? sourceKey(sourceUrl)) : null;
    if (!sourceUrl || !source) {
      bump(dropped, 'INVALID_URL');
      continue;
    }
    const publishedAt = a.publishedAt;
    if (!publishedAt || Number.isNaN(publishedAt.getTime())) {
      bump(dropped, 'INVALID_DATE');
      continue;
    }
    if (publishedAt.getTime() > ctx.now.getTime() + FUTURE_TOLERANCE_MS) {
      bump(dropped, 'FUTURE_DATE');
      continue;
    }
    if (publishedAt < ctx.since) {
      bump(dropped, 'TOO_OLD');
      continue;
    }

    const hash = contentHash(title, source, publishedAt);
    const existing = byHash.get(hash) ?? byUrl.get(sourceUrl);
    if (existing) {
      bump(dropped, 'DUPLICATE_IN_BATCH');
      for (const symbol of queriedFor) if (!existing.queriedFor.includes(symbol)) existing.queriedFor.push(symbol);
      continue;
    }
    const description = cleanText(a.description, ARTICLE_LIMITS.description);
    const article: NormalizedArticle = {
      dataMode: ctx.dataMode,
      title,
      description: description && !redundant(title, description) ? description : null,
      content: cleanText(a.content, ARTICLE_LIMITS.content),
      source,
      sourceUrl,
      author: cleanText(a.author, ARTICLE_LIMITS.author),
      publishedAt,
      language: a.language?.split('-')[0]?.toLowerCase() || 'en',
      contentHash: hash,
      queriedFor: [...new Set(queriedFor)],
    };
    byHash.set(hash, article);
    byUrl.set(sourceUrl, article);
    articles.push(article);
  }

  articles.sort((x, y) => y.publishedAt.getTime() - x.publishedAt.getTime());
  return { articles, dropped };
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): news provider contract, text utilities and article normalizer`.

---

### Task 3: Mention matcher (pure)

**Files:** Create `backend/src/services/news/mentionMatcher.ts`. Test: `backend/tests/unit/mentionMatcher.test.ts`.

**Interfaces:**
- Consumes: `Stock`, `Market`, `InstrumentRef` (domain).
- Produces:
  - `MatchSubject { ref; symbol; name; aliases }`
  - `MentionMatch { ref; symbol; relevance; matchedBy }`
  - `MatchableArticle { title; description: string|null; content: string|null }`
  - `coreCompanyName(name)`
  - `subjectsFromInstruments(stocks, markets): MatchSubject[]`
  - `class MentionMatcher { constructor(subjects); match(article, queriedFor?): MentionMatch[] }`
  - constants `QUERY_ONLY_RELEVANCE = 0.4`, `ROUNDUP_BODY_CAP = 0.45`, `ROUNDUP_MIN_STOCKS = 4`, `EXCLUDED_NEXT_WORDS`

**Rules (document in `docs/architecture.md` in Task 13):**
- **Terms.** Each instrument contributes up to three kinds of term:
  - its name: the company name minus "Limited"/"Ltd", or the index name;
  - its aliases;
  - its symbol, if it is 3+ characters long.
- **Case.** A term with no lowercase letters matches case-sensitively (RIL, SBI, L&T, TCS); the others ignore case.
- **Boundaries.** Unicode letter/number lookarounds, not `\b`, so `L&T` works.
- **Exclusions.** A match followed by an `EXCLUDED_NEXT_WORDS` entry is dropped (Life, Finance, Hotels, Midcap…). The comparison is **case-sensitive**, so "Nifty next week" and "RIL oil…" still count. "Nifty 500" is excluded; "Sensex 500 points" is kept.
- **Overlaps.** When matches overlap, the longest span wins ("Nifty Bank" beats "Nifty").
- **Score.** `field weight` (title 1, description 0.75, content 0.6) × `kind weight` (name 1, alias 0.9, symbol 0.85), plus 0.05 per extra occurrence (at most 2), capped at 1.
- **Roundups.** If an article mentions ≥ 4 stocks, a stock not named in the title is capped at 0.45.
- **Query-only.** An instrument whose single-instrument query returned the article, but which the text never names, gets 0.4 (`'query'`).
- Both 0.45 and 0.4 sit below the seeded `news_relevance_threshold` 0.5, so Phase 7 never pays for sentiment on them.

- [ ] **Step 1: Write the failing test** `backend/tests/unit/mentionMatcher.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import {
  coreCompanyName, type MatchSubject, MentionMatcher, QUERY_ONLY_RELEVANCE, ROUNDUP_BODY_CAP,
} from '../../src/services/news/mentionMatcher.js';

const stock = (symbol: string, name: string, aliases: string[] = []): MatchSubject =>
  ({ ref: { kind: 'stock', id: `s-${symbol}` }, symbol, name: coreCompanyName(name), aliases });
const market = (symbol: string, name: string, aliases: string[]): MatchSubject =>
  ({ ref: { kind: 'market', id: `m-${symbol}` }, symbol, name, aliases });

const matcher = new MentionMatcher([
  stock('RELIANCE', 'Reliance Industries Limited', ['RIL']),
  stock('TCS', 'Tata Consultancy Services Limited', ['Tata Consultancy']),
  stock('INFY', 'Infosys Limited'),
  stock('WIPRO', 'Wipro Limited'),
  stock('HCLTECH', 'HCL Technologies Limited', ['HCLTech', 'HCL Tech']),
  stock('SBIN', 'State Bank of India', ['SBI']),
  stock('LT', 'Larsen & Toubro Limited', ['L&T', 'Larsen and Toubro']),
  stock('ITC', 'ITC Limited'),
  market('NIFTY50', 'NIFTY 50', ['Nifty 50', 'Nifty50', 'Nifty']),
  market('BANKNIFTY', 'NIFTY BANK', ['Nifty Bank', 'Bank Nifty']),
  market('SENSEX', 'SENSEX', ['Sensex', 'BSE Sensex']),
]);
const title = (t: string) => ({ title: t, description: null, content: null });
const brief = (r: ReturnType<MentionMatcher['match']>) => r.map((m) => [m.symbol, m.relevance, m.matchedBy]);

describe('coreCompanyName', () => {
  it('strips legal suffixes only', () => {
    expect(coreCompanyName('Reliance Industries Limited')).toBe('Reliance Industries');
    expect(coreCompanyName('Foo Ltd.')).toBe('Foo');
    expect(coreCompanyName('State Bank of India')).toBe('State Bank of India');
  });
});

describe('MentionMatcher', () => {
  it('scores a company name in the title highest', () => {
    expect(brief(matcher.match(title('Reliance Industries Q2 profit rises')))).toEqual([['RELIANCE', 1, 'name:title']]);
    expect(brief(matcher.match(title('RELIANCE INDUSTRIES shares climb')))).toEqual([['RELIANCE', 1, 'name:title']]);
  });

  it('matches acronyms case-sensitively and only as whole words', () => {
    expect(brief(matcher.match(title('RIL shares gain')))).toEqual([['RELIANCE', 0.9, 'alias:title']]);
    expect(matcher.match(title('ril and April outlook'))).toEqual([]);
    expect(brief(matcher.match(title("Infosys's guidance disappoints")))).toEqual([['INFY', 1, 'name:title']]);
  });

  it('handles L&T and excludes group companies named by a following word', () => {
    expect(brief(matcher.match(title('L&T bags mega order')))).toEqual([['LT', 0.9, 'alias:title']]);
    expect(brief(matcher.match(title('Larsen & Toubro wins contract')))).toEqual([['LT', 1, 'name:title']]);
    expect(matcher.match(title('L&T Finance raises funds'))).toEqual([]);
    expect(matcher.match(title('SBI Life shares fall'))).toEqual([]);
    expect(matcher.match(title('ITC Hotels lists on exchanges'))).toEqual([]);
    expect(brief(matcher.match(title('SBI raises lending rates')))).toEqual([['SBIN', 0.9, 'alias:title']]);
  });

  it('lets the longest overlapping name win and ignores other index names', () => {
    expect(brief(matcher.match(title('Nifty Bank hits record high')))).toEqual([['BANKNIFTY', 0.9, 'alias:title']]);
    expect(brief(matcher.match(title('Nifty, Sensex end higher')))).toEqual([['NIFTY50', 0.9, 'alias:title'], ['SENSEX', 0.9, 'alias:title']]);
    expect(matcher.match(title('Nifty Midcap index slips'))).toEqual([]);
    expect(matcher.match(title('Nifty 500 index rebalanced'))).toEqual([]);
  });

  it('does not let everyday words after a name suppress a real mention (recall)', () => {
    expect(brief(matcher.match(title('Nifty next week: support seen near key level')))).toEqual([['NIFTY50', 0.9, 'alias:title']]);
    expect(brief(matcher.match(title('Sensex 500 points higher in early trade')))).toEqual([['SENSEX', 0.9, 'alias:title']]);
    expect(brief(matcher.match(title('RIL oil-to-chemicals unit expands')))).toEqual([['RELIANCE', 0.9, 'alias:title']]);
    expect(brief(matcher.match(title('Reliance Industries capital expenditure to rise')))).toEqual([['RELIANCE', 1, 'name:title']]);
    expect(brief(matcher.match(title('Larsen & Toubro Finance arm unaffected; L&T order book grows')))).toEqual([['LT', 0.9, 'alias:title']]);
  });

  it('weights description and content lower, with a small bonus for repeats', () => {
    expect(brief(matcher.match({ title: 'Tech stocks rally', description: 'Infosys led gains.', content: null }))).toEqual([['INFY', 0.75, 'name:description']]);
    expect(brief(matcher.match({ title: 'Tech stocks rally', description: null, content: 'Wipro rose.' }))).toEqual([['WIPRO', 0.6, 'name:content']]);
    expect(brief(matcher.match({ title: 'Tech stocks rally', description: 'Infosys rose. Analysts like Infosys.', content: null }))).toEqual([['INFY', 0.8, 'name:description']]);
  });

  it('caps body-only mentions in roundup articles below the sentiment threshold', () => {
    const roundup = matcher.match({ title: 'Top IT gainers today', description: 'Infosys, Wipro, HCLTech and TCS led gains.', content: null });
    expect(roundup.map((m) => m.relevance)).toEqual([ROUNDUP_BODY_CAP, ROUNDUP_BODY_CAP, ROUNDUP_BODY_CAP, ROUNDUP_BODY_CAP]);
    const led = matcher.match({ title: 'TCS leads IT rally', description: 'Infosys, Wipro and HCLTech also rose.', content: null });
    expect(brief(led)[0]).toEqual(['TCS', 0.85, 'symbol:title']);
    expect(led.slice(1).every((m) => m.relevance === ROUNDUP_BODY_CAP)).toBe(true);
    expect(ROUNDUP_BODY_CAP).toBeLessThan(0.5);
  });

  it('adds a low query-only mention when the instrument query returned an article that never names it', () => {
    expect(brief(matcher.match(title('IT services demand slows'), ['TCS']))).toEqual([['TCS', QUERY_ONLY_RELEVANCE, 'query']]);
    expect(brief(matcher.match(title('TCS wins deal'), ['TCS']))).toEqual([['TCS', 0.85, 'symbol:title']]);
    expect(QUERY_ONLY_RELEVANCE).toBeLessThan(0.5);
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/services/news/mentionMatcher.ts`

```ts
import type { InstrumentRef, Market, Stock } from '../../domain/types.js';

export interface MatchSubject {
  ref: InstrumentRef;
  symbol: string;
  name: string;
  aliases: readonly string[];
}

export interface MentionMatch {
  ref: InstrumentRef;
  symbol: string;
  relevance: number;
  matchedBy: string;
}

export interface MatchableArticle {
  title: string;
  description: string | null;
  content: string | null;
}

type Field = 'title' | 'description' | 'content';
type TermKind = 'name' | 'alias' | 'symbol';

const FIELD_WEIGHT: Readonly<Record<Field, number>> = { title: 1, description: 0.75, content: 0.6 };
const KIND_WEIGHT: Readonly<Record<TermKind, number>> = { name: 1, alias: 0.9, symbol: 0.85 };
const REPEAT_BONUS = 0.05;
const MAX_REPEAT_BONUSES = 2;
const MIN_SYMBOL_LENGTH = 3;

/** Both sit below the seeded news_relevance_threshold (0.5): stored, but never sent for LLM sentiment. */
export const QUERY_ONLY_RELEVANCE = 0.4;
export const ROUNDUP_BODY_CAP = 0.45;
export const ROUNDUP_MIN_STOCKS = 4;

/**
 * A match followed by one of these names a different entity (SBI Life, L&T Finance, ITC Hotels, Nifty Midcap).
 * Matched CASE-SENSITIVELY: entity names are Title Case, while everyday words ("Nifty next week",
 * "RIL oil-to-chemicals", "HDFC Bank capital adequacy") must not suppress a real mention.
 */
export const EXCLUDED_NEXT_WORDS = [
  'Life', 'Card', 'Cards', 'General Insurance', 'Mutual Fund', 'MF', 'AMC', 'Securities', 'Insurance', 'Pension',
  'Hotels', 'Finance', 'Housing Finance', 'Capital Markets', 'Ventures', 'Africa',
  'Midcap', 'Smallcap', 'Microcap', 'Next 50', 'PSU Bank', 'Private Bank', 'Media', 'Oil & Gas', 'Infra',
  'Healthcare', 'Consumption', 'Commodities', 'CPSE', 'MNC',
] as const;

const escapeRegex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const NEXT_WORD = new RegExp(
  `^\\s+(?:${EXCLUDED_NEXT_WORDS.map((w) => w.split(' ').map(escapeRegex).join('\\s+')).join('|')})(?![\\p{L}\\p{N}])`,
  'u',
);
/** "Nifty 500" is another index, but "Sensex 500 points higher" is a real Sensex mention. */
const NEXT_INDEX_NUMBER = /^\s+(?:100|200|500)(?![\p{L}\p{N}])(?!\s*(?:points?|pts)\b)/iu;
const LEGAL_SUFFIX = /[\s,]+(limited|ltd\.?)$/i;
const hasLowercase = (s: string) => /\p{Ll}/u.test(s);

export function coreCompanyName(name: string): string {
  return name.trim().replace(LEGAL_SUFFIX, '').trim();
}

export function subjectsFromInstruments(stocks: readonly Stock[], markets: readonly Market[]): MatchSubject[] {
  const fromStock = (s: Stock): MatchSubject => ({ ref: { kind: 'stock', id: s.id }, symbol: s.symbol, name: coreCompanyName(s.companyName), aliases: s.aliases });
  const fromMarket = (m: Market): MatchSubject => ({ ref: { kind: 'market', id: m.id }, symbol: m.symbol, name: m.name, aliases: m.aliases });
  return [...stocks.map(fromStock), ...markets.map(fromMarket)];
}

interface Term {
  subject: number;
  kind: TermKind;
  pattern: RegExp;
}

interface Span {
  subject: number;
  kind: TermKind;
  field: Field;
  start: number;
  end: number;
}

function termPattern(text: string): RegExp {
  const body = text.trim().split(/\s+/).map(escapeRegex).join('\\s+');
  return new RegExp(`(?<![\\p{L}\\p{N}&])${body}(?![\\p{L}\\p{N}&])`, hasLowercase(text) ? 'giu' : 'gu');
}

const round3 = (n: number) => Math.round(n * 1000) / 1000;

/** Deterministic, explainable instrument detection for news articles. */
export class MentionMatcher {
  private readonly terms: Term[] = [];

  constructor(private readonly subjects: readonly MatchSubject[]) {
    subjects.forEach((s, subject) => {
      const add = (text: string, kind: TermKind) => {
        if (text.trim() !== '') this.terms.push({ subject, kind, pattern: termPattern(text) });
      };
      add(s.name, 'name');
      for (const alias of s.aliases) add(alias, 'alias');
      if (s.symbol.length >= MIN_SYMBOL_LENGTH) add(s.symbol, 'symbol');
    });
  }

  match(article: MatchableArticle, queriedFor: readonly string[] = []): MentionMatch[] {
    const spans: Span[] = [];
    const fields: Array<[Field, string | null]> = [
      ['title', article.title], ['description', article.description], ['content', article.content],
    ];
    for (const [field, text] of fields) {
      if (!text) continue;
      const found: Span[] = [];
      for (const term of this.terms) {
        for (const m of text.matchAll(term.pattern)) {
          const start = m.index ?? 0;
          const end = start + m[0].length;
          const rest = text.slice(end);
          if (NEXT_WORD.test(rest) || NEXT_INDEX_NUMBER.test(rest)) continue;
          found.push({ subject: term.subject, kind: term.kind, field, start, end });
        }
      }
      // Longest span wins where matches overlap ("Nifty Bank" beats "Nifty").
      found.sort((a, b) => b.end - b.start - (a.end - a.start) || a.start - b.start);
      const kept: Span[] = [];
      for (const s of found) if (kept.every((k) => s.end <= k.start || s.start >= k.end)) kept.push(s);
      spans.push(...kept);
    }

    const bySubject = new Map<number, { best: number; matchedBy: string; count: number; inTitle: boolean }>();
    for (const s of spans) {
      const score = FIELD_WEIGHT[s.field] * KIND_WEIGHT[s.kind];
      const current = bySubject.get(s.subject);
      if (!current) {
        bySubject.set(s.subject, { best: score, matchedBy: `${s.kind}:${s.field}`, count: 1, inTitle: s.field === 'title' });
        continue;
      }
      current.count += 1;
      current.inTitle ||= s.field === 'title';
      if (score > current.best) {
        current.best = score;
        current.matchedBy = `${s.kind}:${s.field}`;
      }
    }

    const stockCount = [...bySubject.keys()].filter((i) => this.subjects[i]?.ref.kind === 'stock').length;
    const out: MentionMatch[] = [];
    for (const [i, m] of bySubject) {
      const subject = this.subjects[i];
      if (!subject) continue;
      let relevance = Math.min(1, m.best + REPEAT_BONUS * Math.min(m.count - 1, MAX_REPEAT_BONUSES));
      if (subject.ref.kind === 'stock' && stockCount >= ROUNDUP_MIN_STOCKS && !m.inTitle) {
        relevance = Math.min(relevance, ROUNDUP_BODY_CAP);
      }
      out.push({ ref: subject.ref, symbol: subject.symbol, relevance: round3(relevance), matchedBy: m.matchedBy });
    }

    const named = new Set(out.map((o) => o.symbol));
    for (const symbol of new Set(queriedFor)) {
      if (named.has(symbol)) continue;
      const subject = this.subjects.find((s) => s.symbol === symbol && s.ref.kind === 'stock');
      if (subject) out.push({ ref: subject.ref, symbol, relevance: QUERY_ONLY_RELEVANCE, matchedBy: 'query' });
    }
    return out.sort((a, b) => b.relevance - a.relevance || a.symbol.localeCompare(b.symbol));
  }
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS. If a case fails, fix the matcher, not the expectation. Every expectation above is a deliberate rule.
- [ ] **Step 5: Commit** `feat(backend): deterministic news mention matcher with explainable relevance`.

---

### Task 4: Mock news provider

**Files:** Create `backend/src/providers/news/mock/MockNewsProvider.ts`. Test: `backend/tests/unit/mockNewsProvider.test.ts`.

**Interfaces:**
- Consumes: the news contract (Task 2), `rngFor` and `hashString` (`providers/market/mock/random.ts`), `toIst`, `istToUtc` and `addDays` (`utils/ist.ts`).
- Produces: `new MockNewsProvider(now?: () => Date)`, with `name 'mock'` and `capabilities { maxInstrumentsPerQuery: 1, latency: 'realtime' }`.

- [ ] **Step 1: Write the failing test** `backend/tests/unit/mockNewsProvider.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { MockNewsProvider } from '../../src/providers/news/mock/MockNewsProvider.js';

const NOW = () => new Date('2026-10-05T06:30:00Z'); // 12:00 IST
const RELIANCE = { symbol: 'RELIANCE', name: 'Reliance Industries', aliases: ['RIL'] };
const SINCE = new Date('2026-09-05T00:00:00Z');

describe('MockNewsProvider', () => {
  it('is deterministic and clearly labelled synthetic', async () => {
    const a = await new MockNewsProvider(NOW).fetchForInstruments({ subjects: [RELIANCE], since: SINCE, limit: 100 });
    const b = await new MockNewsProvider(NOW).fetchForInstruments({ subjects: [RELIANCE], since: SINCE, limit: 100 });
    expect(a).toEqual(b);
    expect(a.failures).toEqual([]);
    expect(a.articles.length).toBeGreaterThan(5);
    for (const art of a.articles) {
      expect(art.title).toMatch(/^\[MOCK\] Reliance Industries /);
      expect(art.url).toMatch(/^https:\/\/mock-news\.invalid\//);
      expect(art.title).not.toMatch(/\d/);
    }
  });

  it('never returns articles after now or before since, newest first, within the limit', async () => {
    const r = await new MockNewsProvider(NOW).fetchForInstruments({ subjects: [RELIANCE], since: SINCE, limit: 3 });
    expect(r.articles).toHaveLength(3);
    const times = r.articles.map((x) => x.publishedAt?.getTime() ?? 0);
    expect(times).toEqual([...times].sort((x, y) => y - x));
    expect(times.every((t) => t <= NOW().getTime() && t >= SINCE.getTime())).toBe(true);
  });

  it('produces market news that names indices', async () => {
    const r = await new MockNewsProvider(NOW).fetchMarketNews({ since: SINCE, limit: 100 });
    expect(r.articles.length).toBeGreaterThan(10);
    expect(r.articles.some((x) => /Nifty|Sensex|VIX/.test(x.title ?? ''))).toBe(true);
  });

  it('declares one instrument per query', () => {
    expect(new MockNewsProvider(NOW).capabilities()).toEqual({ maxInstrumentsPerQuery: 1, latency: 'realtime' });
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/providers/news/mock/MockNewsProvider.ts`

```ts
import { addDays, istToUtc, toIst } from '../../../utils/ist.js';
import { hashString, rngFor } from '../../market/mock/random.js';
import type {
  InstrumentNewsQuery, MarketNewsQuery, NewsCapabilities, NewsFetchResult, NewsProvider, RawArticle,
} from '../types.js';

const MOCK_HOST = 'https://mock-news.invalid';
const INSTRUMENT_DAILY_PROBABILITY = 0.5;
const MARKET_ARTICLES_PER_DAY = 2;

/** MOCK DATA ONLY: qualitative synthetic headlines. No numbers, no real events. */
const INSTRUMENT_TEMPLATES = [
  'shares gain after an upbeat business update',
  'wins a large new order, says company',
  'rises as brokerages turn more positive',
  'shares slip as margins come under pressure',
  'falls after a regulatory query',
  'declines on cautious demand commentary',
  'to announce quarterly results next week',
  'board to consider fundraising proposal',
  'holds annual general meeting',
] as const;

const MARKET_TEMPLATES = [
  'Sensex and Nifty end higher led by banks',
  'Nifty slips as IT stocks drag',
  'India VIX rises as markets turn cautious',
  'Nifty Bank outperforms as lenders gain',
  'Markets end flat ahead of RBI policy',
  'Sensex falls as metal stocks weaken',
] as const;

const pick = <T>(items: readonly [T, ...T[]], rng: () => number): T =>
  items[Math.floor(rng() * items.length)] ?? items[0];

/** MOCK provider: deterministic per (symbol, IST date); every title starts with "[MOCK]". */
export class MockNewsProvider implements NewsProvider {
  readonly name = 'mock';

  constructor(private readonly now: () => Date = () => new Date()) {}

  capabilities(): NewsCapabilities {
    return { maxInstrumentsPerQuery: 1, latency: 'realtime' };
  }

  async fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult> {
    const out: RawArticle[] = [];
    for (const subject of query.subjects) {
      for (const date of this.dates(query.since)) {
        const rng = rngFor('news', subject.symbol, date);
        if (rng() >= INSTRUMENT_DAILY_PROBABILITY) continue;
        out.push(this.article(`${subject.name} ${pick(INSTRUMENT_TEMPLATES, rng)}`, subject.symbol.toLowerCase(), date, rng));
      }
    }
    return { articles: this.window(out, query.since, query.limit), failures: [] };
  }

  async fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult> {
    const out: RawArticle[] = [];
    for (const date of this.dates(query.since)) {
      for (let i = 0; i < MARKET_ARTICLES_PER_DAY; i += 1) {
        const rng = rngFor('market-news', date, String(i));
        out.push(this.article(pick(MARKET_TEMPLATES, rng), 'markets', date, rng));
      }
    }
    return { articles: this.window(out, query.since, query.limit), failures: [] };
  }

  private dates(since: Date): string[] {
    const last = toIst(this.now()).date;
    const out: string[] = [];
    for (let d = toIst(since).date; d <= last; d = addDays(d, 1)) out.push(d);
    return out;
  }

  private article(headline: string, section: string, date: string, rng: () => number): RawArticle {
    const minute = 8 * 60 + Math.floor(rng() * 13 * 60); // 08:00–20:59 IST
    const time = `${String(Math.floor(minute / 60)).padStart(2, '0')}:${String(minute % 60).padStart(2, '0')}`;
    const title = `[MOCK] ${headline}`;
    return {
      title,
      url: `${MOCK_HOST}/${section}/${date}/${hashString(`${title}|${date}`).toString(16)}`,
      description: '[MOCK] Synthetic article generated for testing. It is not real news.',
      content: null,
      author: null,
      publishedAt: istToUtc(date, time),
      publisherUrl: MOCK_HOST,
      language: 'en',
    };
  }

  private window(articles: RawArticle[], since: Date, limit: number): RawArticle[] {
    const now = this.now();
    return articles
      .filter((a) => a.publishedAt !== null && a.publishedAt >= since && a.publishedAt <= now)
      .sort((a, b) => (b.publishedAt?.getTime() ?? 0) - (a.publishedAt?.getTime() ?? 0))
      .slice(0, limit);
  }
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): deterministic mock news provider (labelled [MOCK])`.

---

### Task 5: RSS provider (Google News search + Indian market feeds)

**Files:**
- Create:
  - `backend/src/providers/news/rss/feedParser.ts`
  - `backend/src/providers/news/rss/RssNewsProvider.ts`
  - `backend/tests/fixtures/news/feeds.ts`
- Modify: `backend/package.json` (dependency `fast-xml-parser@5.11.2`; the `test:live` script adds `LIVE_NEWS=1`)
- Test: `backend/tests/unit/rssNewsProvider.test.ts`, `backend/tests/live/news.live.test.ts`

**Interfaces:**
- Consumes: the news contract (Task 2), `RateLimiter`, `httpRequest`, `AppError`, `toAppError`.
- Produces:
  - `parseRssFeed(xml, feedName): FeedItem[]`
  - `FeedItem { title; link; description; pubDate; author; sourceName; sourceUrl }` (all `string|null`)
  - `RssFeed { name; url }`
  - `DEFAULT_MARKET_FEEDS`
  - `googleNewsSearchUrl(query, days)`
  - `new RssNewsProvider(limiter, { fetchText?, marketFeeds?, now? })`, with `name 'rss'` and `maxInstrumentsPerQuery 1`

- [ ] **Step 1: Install and write the failing tests**

```bash
pnpm --filter @learning-stocks/backend add fast-xml-parser@5.11.2
```
`backend/tests/fixtures/news/feeds.ts` (hand-written to mirror the structures probed on 2026-10-05; the content is fictional):
```ts
export const GOOGLE_NEWS_XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/"><channel><title>"Reliance Industries" - Google News</title>
<item><title>Reliance Industries raises funds through bonds - Business Standard</title><link>https://news.google.com/rss/articles/CBMiAAA?oc=5</link><guid isPermaLink="false">CBMiAAA</guid><pubDate>Mon, 05 Oct 2026 15:06:07 GMT</pubDate><description>&lt;a href="https://news.google.com/rss/articles/CBMiAAA?oc=5" target="_blank"&gt;Reliance Industries raises funds through bonds&lt;/a&gt;&amp;nbsp;&amp;nbsp;&lt;font color="#6f6f6f"&gt;Business Standard&lt;/font&gt;</description><source url="https://www.business-standard.com">Business Standard</source></item>
<item><title>RIL shares in focus - Example Wire</title><link>https://news.google.com/rss/articles/CBMiBBB?oc=5</link><pubDate>not a date</pubDate><source url="https://example.com">Example Wire</source></item>
</channel></rss>`;

export const ET_XML = `<?xml version="1.0" encoding="UTF-8"?><rss xmlns:atom="http://www.w3.org/2005/Atom" version="2.0"><channel><title>Markets-Economic Times</title>
<item><title><![CDATA[Ahead of Market: things that will decide stock market action on Tuesday]]> </title><description><![CDATA[Indian equities rebounded on Monday, with Sensex and Nifty rising.]]> </description><link>https://economictimes.indiatimes.com/markets/stocks/news/ahead-of-market/articleshow/1.cms</link><enclosure type="image/jpeg" url="https://img.example/1.jpg" length="0"/><guid>https://economictimes.indiatimes.com/markets/stocks/news/ahead-of-market/articleshow/1.cms</guid><pubDate>Mon, 05 Oct 2026 21:27:49 +0530</pubDate></item>
<item><title>2026</title><link>https://economictimes.indiatimes.com/markets/2026.cms</link><pubDate>Mon, 05 Oct 2026 20:00:00 +0530</pubDate></item>
</channel></rss>`;

export const MINT_SINGLE_ITEM_XML = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>mint - markets</title>
<item><title><![CDATA[Nifty prediction: momentum stays weak]]></title><link><![CDATA[https://www.livemint.com/market/stock-market-news/nifty-prediction-1.html]]></link><description><![CDATA[The Nifty closed above a key level.]]></description><pubDate><![CDATA[Mon, 05 Oct 2026 23:17:54 +0530]]></pubDate></item>
</channel></rss>`;

export const EMPTY_CHANNEL_XML = `<?xml version="1.0"?><rss version="2.0"><channel><title>empty</title></channel></rss>`;
export const BOT_BLOCK_HTML = `<!doctype html><html><head><title>Access denied</title></head><body>Blocked</body></html>`;
```
`backend/tests/unit/rssNewsProvider.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { parseRssFeed } from '../../src/providers/news/rss/feedParser.js';
import { googleNewsSearchUrl, RssNewsProvider } from '../../src/providers/news/rss/RssNewsProvider.js';
import { AppError } from '../../src/utils/errors.js';
import { BOT_BLOCK_HTML, EMPTY_CHANNEL_XML, ET_XML, GOOGLE_NEWS_XML, MINT_SINGLE_ITEM_XML } from '../fixtures/news/feeds.js';

const NOW = () => new Date('2026-10-05T18:00:00Z');
const RELIANCE = { symbol: 'RELIANCE', name: 'Reliance Industries', aliases: ['RIL'] };

function provider(responses: Record<string, string | Error>, feeds = [{ name: 'ET', url: 'https://et.example/rss' }, { name: 'Mint', url: 'https://mint.example/rss' }]) {
  const fetched: string[] = [];
  let acquired = 0;
  const p = new RssNewsProvider({ acquire: async () => { acquired += 1; } }, {
    now: NOW,
    marketFeeds: feeds,
    fetchText: async (url) => {
      fetched.push(url);
      const key = Object.keys(responses).find((k) => url.startsWith(k));
      const r = key === undefined ? undefined : responses[key];
      if (r === undefined) throw new Error(`unexpected fetch ${url}`);
      if (r instanceof Error) throw r;
      return r;
    },
  });
  return { p, fetched, acquired: () => acquired };
}

describe('parseRssFeed', () => {
  it('reads RSS items including CDATA, attributes and escaped HTML', () => {
    const [g] = parseRssFeed(GOOGLE_NEWS_XML, 'google');
    expect(g).toMatchObject({ title: 'Reliance Industries raises funds through bonds - Business Standard', sourceName: 'Business Standard', sourceUrl: 'https://www.business-standard.com', link: 'https://news.google.com/rss/articles/CBMiAAA?oc=5' });
    expect(g?.description).toContain('<a href=');
    const et = parseRssFeed(ET_XML, 'et');
    expect(et[0]?.title).toBe('Ahead of Market: things that will decide stock market action on Tuesday');
    expect(et[1]?.title).toBe('2026');
  });

  it('treats a single item as a list, and an empty channel as no items', () => {
    const mint = parseRssFeed(MINT_SINGLE_ITEM_XML, 'mint');
    expect(mint).toHaveLength(1);
    expect(mint[0]).toMatchObject({ link: 'https://www.livemint.com/market/stock-market-news/nifty-prediction-1.html', pubDate: 'Mon, 05 Oct 2026 23:17:54 +0530' });
    expect(parseRssFeed(EMPTY_CHANNEL_XML, 'empty')).toEqual([]);
  });

  it('rejects non-RSS bodies (bot-block pages) as INVALID_RESPONSE', () => {
    expect(() => parseRssFeed(BOT_BLOCK_HTML, 'blocked')).toThrow(expect.objectContaining({ code: 'INVALID_RESPONSE' }));
  });
});

describe('RssNewsProvider', () => {
  it('searches Google News for the quoted company name in India English, stripping the publisher suffix', async () => {
    const { p, fetched, acquired } = provider({ 'https://news.google.com/': GOOGLE_NEWS_XML });
    const r = await p.fetchForInstruments({ subjects: [RELIANCE], since: new Date('2026-09-28T18:00:00Z'), limit: 10 });
    expect(fetched[0]).toBe(googleNewsSearchUrl('"Reliance Industries"', 7));
    expect(fetched[0]).toContain('q=%22Reliance+Industries%22+when%3A7d');
    expect(fetched[0]).toContain('ceid=IN%3Aen');
    expect(r.articles[0]).toMatchObject({ title: 'Reliance Industries raises funds through bonds', publisherUrl: 'https://www.business-standard.com', publishedAt: new Date('2026-10-05T15:06:07Z') });
    expect(r.articles.find((a) => a.title === 'RIL shares in focus')?.publishedAt).toBeNull();
    expect(acquired()).toBe(1);
  });

  it('refuses more than one instrument per query', async () => {
    const { p } = provider({});
    await expect(p.fetchForInstruments({ subjects: [RELIANCE, RELIANCE], since: new Date(), limit: 5 })).rejects.toMatchObject({ code: 'INTERNAL' });
  });

  it('isolates a failing market feed and reports it; throws only when every feed fails', async () => {
    const partial = provider({ 'https://et.example/': ET_XML, 'https://mint.example/': new AppError('AUTH_FAILED', 'Authentication failed calling https://mint.example/rss') });
    const r = await partial.p.fetchMarketNews({ since: new Date('2026-10-01T00:00:00Z'), limit: 50 });
    expect(r.articles.map((a) => a.title)).toContain('Ahead of Market: things that will decide stock market action on Tuesday');
    expect(r.failures).toEqual([{ source: 'Mint', code: 'PROVIDER_DOWN', message: 'Mint blocked the request' }]);

    const dead = provider({ 'https://et.example/': new AppError('TIMEOUT', 'slow'), 'https://mint.example/': BOT_BLOCK_HTML });
    await expect(dead.p.fetchMarketNews({ since: new Date(), limit: 5 })).rejects.toMatchObject({ code: 'TIMEOUT' });
  });
});
```
`backend/tests/live/news.live.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { DEFAULT_MARKET_FEEDS, RssNewsProvider } from '../../src/providers/news/rss/RssNewsProvider.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

// Network test against real feeds. Runs only via: pnpm --filter @learning-stocks/backend test:live
describe.skipIf(!process.env.LIVE_NEWS)('RSS live smoke', () => {
  const p = new RssNewsProvider(createRateLimiter({ ratePerSecond: 1, burst: 1 }));
  const weekAgo = () => new Date(Date.now() - 7 * 86_400_000);

  it('finds recent Google News results for an NSE company with publisher and date', async () => {
    const r = await p.fetchForInstruments({ subjects: [{ symbol: 'RELIANCE', name: 'Reliance Industries', aliases: [] }], since: weekAgo(), limit: 20 });
    expect(r.articles.length).toBeGreaterThan(0);
    expect(r.articles.every((a) => a.publisherUrl !== null && a.publishedAt !== null)).toBe(true);
  });

  it('reads every default market feed', async () => {
    const r = await p.fetchMarketNews({ since: weekAgo(), limit: 50 });
    expect(r.failures).toEqual([]);
    expect(r.articles.length).toBeGreaterThanOrEqual(DEFAULT_MARKET_FEEDS.length * 5);
  });
});
```
Change the backend `test:live` script to `"LIVE_YAHOO=1 LIVE_NEWS=1 TZ=UTC vitest run --project live"`.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/providers/news/rss/feedParser.ts`

```ts
import { XMLParser } from 'fast-xml-parser';
import { AppError } from '../../../utils/errors.js';

export interface FeedItem {
  title: string | null;
  link: string | null;
  description: string | null;
  pubDate: string | null;
  author: string | null;
  /** Google News <source>: publisher name and home page. */
  sourceName: string | null;
  sourceUrl: string | null;
}

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  // Keep every value a string: a title like "2026" must not become a number.
  parseTagValue: false,
  parseAttributeValue: false,
  trimValues: true,
  processEntities: true,
  htmlEntities: true,
  // A feed with one item must still yield an array.
  isArray: (_name: string, jpath: unknown) => jpath === 'rss.channel.item',
});

type XmlNode = Record<string, unknown>;
const isNode = (v: unknown): v is XmlNode => typeof v === 'object' && v !== null && !Array.isArray(v);

function text(value: unknown): string | null {
  if (typeof value === 'string') return value.trim() === '' ? null : value.trim();
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (isNode(value)) return text(value['#text']);
  return null;
}

const attr = (value: unknown, name: string): string | null => (isNode(value) ? text(value[`@_${name}`]) : null);

/** Parses an RSS 2.0 document. Anything else (e.g. an HTML bot-block page) is INVALID_RESPONSE. */
export function parseRssFeed(xml: string, feedName: string): FeedItem[] {
  let doc: unknown;
  try {
    doc = parser.parse(xml);
  } catch (cause) {
    throw new AppError('INVALID_RESPONSE', `${feedName} returned malformed XML`, { cause, details: { feed: feedName } });
  }
  const rss = isNode(doc) ? doc.rss : undefined;
  if (!isNode(rss) || !('channel' in rss)) {
    throw new AppError('INVALID_RESPONSE', `${feedName} did not return an RSS 2.0 feed`, { details: { feed: feedName } });
  }
  const channel = rss.channel;
  const items = isNode(channel) && Array.isArray(channel.item) ? channel.item : [];
  return items.filter(isNode).map((item) => ({
    title: text(item.title),
    link: text(item.link),
    description: text(item.description),
    pubDate: text(item.pubDate),
    author: text(item.author) ?? text(item['dc:creator']),
    sourceName: text(item.source),
    sourceUrl: attr(item.source, 'url'),
  }));
}
```
Before relying on it, check the `isArray` callback signature in `node_modules/fast-xml-parser/src/fxp.d.ts`. If 5.x passes `jPath` as an object, compare its string form instead, and record a ruling.

`backend/src/providers/news/rss/RssNewsProvider.ts`:
```ts
import { AppError, isAppError, toAppError } from '../../../utils/errors.js';
import { httpRequest } from '../../../utils/http.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import type {
  InstrumentNewsQuery, MarketNewsQuery, NewsCapabilities, NewsFetchResult, NewsProvider, RawArticle, SourceFailure,
} from '../types.js';
import { type FeedItem, parseRssFeed } from './feedParser.js';

export interface RssFeed {
  name: string;
  url: string;
}

/** Live and India-focused as of 2026-10-05. Moneycontrol's feed is excluded: stale since 2024. Personal use only. */
export const DEFAULT_MARKET_FEEDS: readonly RssFeed[] = [
  { name: 'Economic Times Markets', url: 'https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms' },
  { name: 'Mint Markets', url: 'https://www.livemint.com/rss/markets' },
  { name: 'Business Standard Markets', url: 'https://www.business-standard.com/rss/markets-106.rss' },
];

export const RSS_USER_AGENT = 'Mozilla/5.0 (compatible; learning-stocks/1.0; personal research)';
const ACCEPT = 'application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.1';
const DAY_MS = 86_400_000;
const MAX_SEARCH_DAYS = 30;

export function googleNewsSearchUrl(query: string, days: number): string {
  const params = new URLSearchParams({ q: `${query} when:${days}d`, hl: 'en-IN', gl: 'IN', ceid: 'IN:en' });
  return `https://news.google.com/rss/search?${params.toString()}`;
}

function toRaw(item: FeedItem): RawArticle {
  let title = item.title;
  // Google News appends " - Publisher" to every title; strip it so copies hash alike.
  const suffix = item.sourceName ? ` - ${item.sourceName}` : null;
  if (title && suffix && title.endsWith(suffix)) title = title.slice(0, -suffix.length).trim();
  const ts = item.pubDate ? Date.parse(item.pubDate) : Number.NaN;
  return {
    title,
    url: item.link,
    description: item.description,
    content: null,
    author: item.author,
    publishedAt: Number.isNaN(ts) ? null : new Date(ts),
    publisherUrl: item.sourceUrl,
    language: null,
  };
}

const newest = (articles: RawArticle[], limit: number) =>
  [...articles].sort((a, b) => (b.publishedAt?.getTime() ?? 0) - (a.publishedAt?.getTime() ?? 0)).slice(0, limit);

export interface RssNewsProviderOptions {
  fetchText?: (url: string) => Promise<string>;
  marketFeeds?: readonly RssFeed[];
  now?: () => Date;
}

/** Google News search per company + Indian market feeds. Personal, non-commercial use. */
export class RssNewsProvider implements NewsProvider {
  readonly name = 'rss';
  private readonly fetchText: (url: string) => Promise<string>;
  private readonly feeds: readonly RssFeed[];
  private readonly now: () => Date;

  constructor(private readonly limiter: RateLimiter, options: RssNewsProviderOptions = {}) {
    this.fetchText = options.fetchText ?? (async (url) =>
      (await httpRequest({ url, headers: { accept: ACCEPT, 'user-agent': RSS_USER_AGENT } })).text);
    this.feeds = options.marketFeeds ?? DEFAULT_MARKET_FEEDS;
    this.now = options.now ?? (() => new Date());
  }

  capabilities(): NewsCapabilities {
    return { maxInstrumentsPerQuery: 1, latency: 'realtime' };
  }

  async fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult> {
    const [subject, ...rest] = query.subjects;
    if (!subject || rest.length > 0) throw new AppError('INTERNAL', 'RSS search takes exactly one instrument per query');
    const days = Math.min(MAX_SEARCH_DAYS, Math.max(1, Math.ceil((this.now().getTime() - query.since.getTime()) / DAY_MS)));
    const items = await this.read({ name: `Google News ${subject.symbol}`, url: googleNewsSearchUrl(`"${subject.name}"`, days) });
    return { articles: newest(items.map(toRaw), query.limit), failures: [] };
  }

  async fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult> {
    const articles: RawArticle[] = [];
    const failures: SourceFailure[] = [];
    for (const feed of this.feeds) {
      try {
        articles.push(...newest((await this.read(feed)).map(toRaw), query.limit));
      } catch (error) {
        const e = toAppError(error);
        failures.push({ source: feed.name, code: e.code, message: e.message });
      }
    }
    const [first] = failures;
    if (first && failures.length === this.feeds.length) {
      throw new AppError(first.code, `All ${failures.length} market feeds failed`, { details: { failures } });
    }
    return { articles, failures };
  }

  private async read(feed: RssFeed): Promise<FeedItem[]> {
    await this.limiter.acquire();
    let body: string;
    try {
      body = await this.fetchText(feed.url);
    } catch (error) {
      // Feeds need no key: a 401/403 means the site blocked us, not that a credential is wrong.
      if (isAppError(error) && error.code === 'AUTH_FAILED') {
        throw new AppError('PROVIDER_DOWN', `${feed.name} blocked the request`, { details: { feed: feed.name } });
      }
      throw error;
    }
    return parseRssFeed(body, feed.name);
  }
}
```

- [ ] **Step 4: Run the gate, then the live smoke test**

Run the gate. Expected: PASS (the live tests are skipped).
Run: `pnpm --filter @learning-stocks/backend test:live`. Expected: all pass (needs network). If a feed returns 403 or HTML, record which one, and either switch `RSS_USER_AGENT` to a browser string or drop that feed, and record a ruling.

- [ ] **Step 5: Commit** `feat(backend): RSS news provider (Google News search + ET/Mint/Business Standard feeds)`.

---

### Task 6: NewsAPI provider + API-key log redaction

**Files:**
- Create: `backend/src/providers/news/newsapi/NewsApiProvider.ts`
- Modify: `backend/src/utils/logger.ts` (`REDACT_PATHS`)
- Test: `backend/tests/unit/newsApiProvider.test.ts`, plus a new case in `backend/tests/unit/logger.test.ts`

**Interfaces:**
- Consumes: the news contract, `httpJson`, `HttpRequest`, `RateLimiter`, `AppError`.
- Produces:
  - `new NewsApiProvider(apiKey, limiter, { fetchJson? })`, with `name 'newsapi'` and `capabilities { maxInstrumentsPerQuery: 10, latency: 'delayed' }`
  - `buildInstrumentQuery(subjects)`
  - `NEWSAPI_MARKET_QUERY`

- [ ] **Step 1: Write the failing tests**

Append to `backend/tests/unit/logger.test.ts` (inside `describe('createLogger')`):
```ts
  it('redacts API-key headers', () => {
    const { lines, destination } = capture();
    createLogger({ level: 'info', destination }).info(
      { headers: { 'x-api-key': 'nk-1' }, request: { headers: { 'x-api-key': 'nk-2' } } },
      'outbound',
    );
    const out = lines.join('');
    expect(out).not.toContain('nk-1');
    expect(out).not.toContain('nk-2');
  });
```
`backend/tests/unit/newsApiProvider.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { buildInstrumentQuery, NEWSAPI_MARKET_QUERY, NewsApiProvider } from '../../src/providers/news/newsapi/NewsApiProvider.js';
import { AppError } from '../../src/utils/errors.js';
import type { HttpRequest } from '../../src/utils/http.js';

const KEY = 'test-key-123';
const article = (over: Record<string, unknown> = {}) => ({
  source: { id: null, name: 'Example' }, author: 'A. Writer', title: 'Infosys wins large deal',
  description: 'Infosys signed a multi-year contract.', url: 'https://example.com/infosys-deal',
  urlToImage: null, publishedAt: '2026-10-04T09:00:00Z', content: 'Infosys signed a contract with a client… [+1234 chars]', ...over,
});

function provider(body: unknown) {
  const requests: HttpRequest[] = [];
  let acquired = 0;
  const p = new NewsApiProvider(KEY, { acquire: async () => { acquired += 1; } }, {
    fetchJson: async (req) => { requests.push(req); return { data: body }; },
  });
  return { p, requests, acquired: () => acquired };
}

describe('NewsApiProvider', () => {
  it('batches instruments into one OR query, sends the key only in a header', async () => {
    const { p, requests, acquired } = provider({ status: 'ok', totalResults: 1, articles: [article()] });
    const since = new Date('2026-10-01T00:00:00Z');
    await p.fetchForInstruments({ subjects: [{ symbol: 'RELIANCE', name: 'Reliance Industries', aliases: [] }, { symbol: 'INFY', name: 'Infosys', aliases: [] }], since, limit: 30 });
    const req = requests[0];
    const url = new URL(req?.url ?? '');
    expect(url.origin + url.pathname).toBe('https://newsapi.org/v2/everything');
    expect(url.searchParams.get('q')).toBe('"Reliance Industries" OR "Infosys"');
    expect(Object.fromEntries(url.searchParams)).toMatchObject({ searchIn: 'title,description', language: 'en', sortBy: 'publishedAt', from: since.toISOString(), pageSize: '30' });
    expect(req?.url).not.toContain(KEY);
    expect(req?.headers?.['x-api-key']).toBe(KEY);
    expect(acquired()).toBe(1);
  });

  it('maps articles, drops [Removed] placeholders, strips the truncation marker', async () => {
    const { p } = provider({ status: 'ok', totalResults: 3, articles: [
      article(),
      article({ title: '[Removed]', url: 'https://removed.com' }),
      article({ title: 'No date', url: 'https://example.com/2', publishedAt: 'garbage' }),
    ] });
    const r = await p.fetchMarketNews({ since: new Date('2026-10-01T00:00:00Z'), limit: 10 });
    expect(r.failures).toEqual([]);
    expect(r.articles).toHaveLength(2);
    expect(r.articles[0]).toEqual({
      title: 'Infosys wins large deal', url: 'https://example.com/infosys-deal', description: 'Infosys signed a multi-year contract.',
      content: 'Infosys signed a contract with a client', author: 'A. Writer', publishedAt: new Date('2026-10-04T09:00:00Z'), publisherUrl: null, language: 'en',
    });
    expect(r.articles[1]?.publishedAt).toBeNull();
  });

  it('uses a market query and caps the page size at 100', async () => {
    const { p, requests } = provider({ status: 'ok', totalResults: 0, articles: [] });
    await p.fetchMarketNews({ since: new Date(), limit: 500 });
    const url = new URL(requests[0]?.url ?? '');
    expect(url.searchParams.get('q')).toBe(NEWSAPI_MARKET_QUERY);
    expect(url.searchParams.get('pageSize')).toBe('100');
  });

  it.each([
    [{ status: 'error', code: 'apiKeyInvalid', message: 'bad' }, 'AUTH_FAILED'],
    [{ status: 'error', code: 'rateLimited', message: 'slow down' }, 'RATE_LIMITED'],
    [{ status: 'error', code: 'parameterInvalid', message: 'x' }, 'INVALID_RESPONSE'],
    [{ unexpected: true }, 'INVALID_RESPONSE'],
  ])('maps error body %j to %s', async (body, code) => {
    await expect(provider(body).p.fetchMarketNews({ since: new Date(), limit: 5 })).rejects.toMatchObject({ code });
  });

  it('fails fast on any rate limit (quota body or HTTP 429) so retries never burn the daily quota', async () => {
    await expect(provider({ status: 'error', code: 'apiKeyExhausted', message: 'quota' }).p.fetchMarketNews({ since: new Date(), limit: 5 }))
      .rejects.toMatchObject({ code: 'RATE_LIMITED', retryAfterMs: 3_600_000 });
    const http429 = new NewsApiProvider(KEY, { acquire: async () => undefined }, {
      fetchJson: async () => { throw new AppError('RATE_LIMITED', 'Rate limited by https://newsapi.org/v2/everything'); },
    });
    await expect(http429.fetchMarketNews({ since: new Date(), limit: 5 })).rejects.toMatchObject({ code: 'RATE_LIMITED', retryAfterMs: 3_600_000 });
  });

  it('refuses a query longer than NewsAPI allows', () => {
    const many = Array.from({ length: 40 }, (_, i) => ({ symbol: `S${i}`, name: `Very Long Company Name Number ${i}`, aliases: [] }));
    expect(() => buildInstrumentQuery(many)).toThrow(/too long/);
  });
});
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (module missing; the key is not redacted).

- [ ] **Step 3: Implement.** Append to `REDACT_PATHS` in `backend/src/utils/logger.ts`:

```ts
  'headers["x-api-key"]',
  '*.headers["x-api-key"]',
  'req.headers["x-api-key"]',
```
`backend/src/providers/news/newsapi/NewsApiProvider.ts`:
```ts
import { z } from 'zod';
import { AppError, isAppError } from '../../../utils/errors.js';
import { type HttpRequest, httpJson } from '../../../utils/http.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import type {
  InstrumentNewsQuery, MarketNewsQuery, NewsCapabilities, NewsFetchResult, NewsProvider, NewsSubject, RawArticle,
} from '../types.js';

const ENDPOINT = 'https://newsapi.org/v2/everything';
const MAX_QUERY_LENGTH = 500;
const MAX_PAGE_SIZE = 100;
const QUOTA_RETRY_AFTER_MS = 3_600_000;
export const NEWSAPI_MARKET_QUERY = 'Sensex OR Nifty';

const ArticleSchema = z.object({
  author: z.string().nullish(),
  title: z.string().nullish(),
  description: z.string().nullish(),
  url: z.string().nullish(),
  publishedAt: z.string().nullish(),
  content: z.string().nullish(),
});
const ResponseSchema = z.discriminatedUnion('status', [
  z.object({ status: z.literal('ok'), articles: z.array(ArticleSchema) }),
  z.object({ status: z.literal('error'), code: z.string(), message: z.string().optional() }),
]);

const AUTH_CODES = new Set(['apiKeyDisabled', 'apiKeyInvalid', 'apiKeyMissing']);

/** On the free tier any rate limit is the daily quota: a long Retry-After makes withRetry fail fast instead of burning requests. */
const quotaError = (details: Record<string, unknown>) =>
  new AppError('RATE_LIMITED', 'NewsAPI rate limit or daily quota reached', { details, retryAfterMs: QUOTA_RETRY_AFTER_MS });

function errorFor(code: string): AppError {
  const details = { provider: 'newsapi', upstreamCode: code };
  if (AUTH_CODES.has(code)) return new AppError('AUTH_FAILED', `NewsAPI rejected the API key (${code})`, { details });
  if (code === 'apiKeyExhausted' || code === 'rateLimited') return quotaError(details);
  return new AppError('INVALID_RESPONSE', `NewsAPI error ${code}`, { details });
}

export function buildInstrumentQuery(subjects: readonly NewsSubject[]): string {
  const q = subjects.map((s) => `"${s.name.replace(/"/g, '')}"`).join(' OR ');
  if (q.length > MAX_QUERY_LENGTH) {
    throw new AppError('INTERNAL', `NewsAPI query too long (${q.length} > ${MAX_QUERY_LENGTH}); lower maxInstrumentsPerQuery`);
  }
  return q;
}

const TRUNCATION_MARKER = /\s*…?\s*\[\+\d+ chars\]\s*$/;

function toRaw(a: z.infer<typeof ArticleSchema>): RawArticle {
  const ts = a.publishedAt ? Date.parse(a.publishedAt) : Number.NaN;
  return {
    title: a.title ?? null,
    url: a.url ?? null,
    description: a.description ?? null,
    content: a.content ? a.content.replace(TRUNCATION_MARKER, '') : null,
    author: a.author ?? null,
    publishedAt: Number.isNaN(ts) ? null : new Date(ts),
    publisherUrl: null,
    language: 'en',
  };
}

export interface NewsApiProviderOptions {
  fetchJson?: (req: HttpRequest) => Promise<{ data: unknown }>;
}

/** newsapi.org. Free tier: 100 requests/day, articles delayed 24 h, one month of search. Key sent as a header. */
export class NewsApiProvider implements NewsProvider {
  readonly name = 'newsapi';
  private readonly fetchJson: (req: HttpRequest) => Promise<{ data: unknown }>;

  constructor(private readonly apiKey: string, private readonly limiter: RateLimiter, options: NewsApiProviderOptions = {}) {
    this.fetchJson = options.fetchJson ?? httpJson;
  }

  capabilities(): NewsCapabilities {
    return { maxInstrumentsPerQuery: 10, latency: 'delayed' };
  }

  fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult> {
    return this.search(buildInstrumentQuery(query.subjects), query.since, query.limit);
  }

  fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult> {
    return this.search(NEWSAPI_MARKET_QUERY, query.since, query.limit);
  }

  private async search(q: string, since: Date, limit: number): Promise<NewsFetchResult> {
    await this.limiter.acquire();
    const params = new URLSearchParams({
      q, searchIn: 'title,description', language: 'en', sortBy: 'publishedAt',
      from: since.toISOString(), pageSize: String(Math.min(Math.max(limit, 1), MAX_PAGE_SIZE)),
    });
    let data: unknown;
    try {
      ({ data } = await this.fetchJson({ url: `${ENDPOINT}?${params.toString()}`, headers: { 'x-api-key': this.apiKey } }));
    } catch (error) {
      if (isAppError(error) && error.code === 'RATE_LIMITED') throw quotaError({ provider: 'newsapi', status: 429 });
      throw error;
    }
    const parsed = ResponseSchema.safeParse(data);
    if (!parsed.success) {
      throw new AppError('INVALID_RESPONSE', 'NewsAPI returned an unexpected body', { details: { provider: 'newsapi' } });
    }
    if (parsed.data.status === 'error') throw errorFor(parsed.data.code);
    const articles = parsed.data.articles
      .filter((a) => a.title !== '[Removed]' && a.url !== 'https://removed.com')
      .map(toRaw);
    return { articles, failures: [] };
  }
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): NewsAPI provider (batched queries, header key) and API-key log redaction`.

---
### Task 7: NewsRepository (two-key dedupe, mention upsert, reads)

**Files:** Create `backend/src/repositories/NewsRepository.ts`. Test: `backend/tests/integration/newsRepository.test.ts`.

**Interfaces:**
- Consumes: `NewsArticle`, `NewsMention`, `NewsItem` (`domain/news.ts`); `Database`; `requireNumber`.
- Produces:
  - `saveArticles(articles): Promise<{ ids: string[]; inserted: number }>`: `ids[i]` is the stored id for `articles[i]`, new or existing.
  - `saveMentions(mentions): Promise<number>`: upsert that keeps the higher relevance; returns rows written.
  - `listForInstrument(ref, mode, { since?, limit?, minRelevance? }): Promise<NewsItem[]>`: newest first.

- [ ] **Step 1: Write the failing test** `backend/tests/integration/newsRepository.test.ts`

```ts
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import type { NewsArticle } from '../../src/domain/news.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

const article = (over: Partial<NewsArticle> = {}): NewsArticle => ({
  dataMode: 'MOCK', title: 'Reliance Industries wins order', description: null, content: null,
  source: 'example.com', sourceUrl: 'https://example.com/a1', author: null,
  publishedAt: new Date('2026-10-05T06:00:00Z'), language: 'en', contentHash: 'a'.repeat(64), ...over,
});

async function ids(trx: Database) {
  const reliance = await new StockRepository(trx).findBySymbol('RELIANCE');
  const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
  return { reliance: { kind: 'stock' as const, id: reliance?.id ?? '' }, nifty: { kind: 'market' as const, id: nifty?.id ?? '' } };
}

describe('NewsRepository', () => {
  it('inserts new articles and resolves existing ones by content hash or by URL', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      const first = await repo.saveArticles([article(), article({ sourceUrl: 'https://example.com/a2', contentHash: 'b'.repeat(64) })]);
      expect(first.inserted).toBe(2);
      expect(new Set(first.ids).size).toBe(2);

      const again = await repo.saveArticles([
        article({ sourceUrl: 'https://news.google.com/rss/articles/X' }),        // same hash, different URL
        article({ title: 'Edited headline', contentHash: 'c'.repeat(64) }),   // same URL, different hash
        article({ sourceUrl: 'https://example.com/a3', contentHash: 'd'.repeat(64) }),
      ]);
      expect(again.inserted).toBe(1);
      expect(again.ids[0]).toBe(first.ids[0]);
      expect(again.ids[1]).toBe(first.ids[0]);
      expect(again.ids[2]).not.toBe(first.ids[0]);
    });
  });

  it('keeps MOCK and LIVE copies apart and refuses mixed batches', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      expect((await repo.saveArticles([article()])).inserted).toBe(1);
      expect((await repo.saveArticles([article({ dataMode: 'LIVE' })])).inserted).toBe(1);
      await expect(repo.saveArticles([article(), article({ dataMode: 'LIVE', contentHash: 'e'.repeat(64) })])).rejects.toMatchObject({ code: 'INTERNAL' });
    });
  });

  it('upserts mentions keeping the strongest relevance, tolerating duplicates in one call', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      const { reliance, nifty } = await ids(trx);
      const [newsId = ''] = (await repo.saveArticles([article()])).ids;
      expect(await repo.saveMentions([
        { newsId, ref: reliance, relevance: 0.4, matchedBy: 'query' },
        { newsId, ref: reliance, relevance: 0.6, matchedBy: 'name:content' },
        { newsId, ref: nifty, relevance: 0.9, matchedBy: 'alias:title' },
      ])).toBe(2);
      await repo.saveMentions([{ newsId, ref: reliance, relevance: 1, matchedBy: 'name:title' }]);
      await repo.saveMentions([{ newsId, ref: reliance, relevance: 0.4, matchedBy: 'query' }]);
      const [item] = await repo.listForInstrument(reliance, 'MOCK');
      expect(item).toMatchObject({ id: newsId, title: 'Reliance Industries wins order', relevance: 1, matchedBy: 'name:title' });
      expect((await repo.listForInstrument(nifty, 'MOCK'))[0]?.relevance).toBe(0.9);
    });
  });

  it('lists an instrument\'s news newest first, filtered by mode, date and relevance', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      const { reliance } = await ids(trx);
      const saved = await repo.saveArticles([
        article({ title: 'Old', sourceUrl: 'https://example.com/old', contentHash: '1'.repeat(64), publishedAt: new Date('2026-09-01T06:00:00Z') }),
        article({ title: 'New', sourceUrl: 'https://example.com/new', contentHash: '2'.repeat(64) }),
        article({ title: 'Weak', sourceUrl: 'https://example.com/weak', contentHash: '3'.repeat(64), publishedAt: new Date('2026-10-04T06:00:00Z') }),
      ]);
      const [oldId = '', newId = '', weakId = ''] = saved.ids;
      await repo.saveMentions([
        { newsId: oldId, ref: reliance, relevance: 1, matchedBy: 'name:title' },
        { newsId: newId, ref: reliance, relevance: 1, matchedBy: 'name:title' },
        { newsId: weakId, ref: reliance, relevance: 0.4, matchedBy: 'query' },
      ]);
      expect((await repo.listForInstrument(reliance, 'MOCK')).map((n) => n.title)).toEqual(['New', 'Weak', 'Old']);
      expect((await repo.listForInstrument(reliance, 'MOCK', { since: new Date('2026-10-01T00:00:00Z'), minRelevance: 0.5 })).map((n) => n.title)).toEqual(['New']);
      expect(await repo.listForInstrument(reliance, 'LIVE')).toEqual([]);
    });
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/repositories/NewsRepository.ts`

```ts
import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { requireNumber } from '../database/convert.js';
import type { DataMode } from '../domain/enums.js';
import type { NewsArticle, NewsItem, NewsMention } from '../domain/news.js';
import type { InstrumentRef } from '../domain/types.js';
import { AppError } from '../utils/errors.js';

const CHUNK = 200;

function chunks<T>(items: readonly T[]): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += CHUNK) out.push(items.slice(i, i + CHUNK));
  return out;
}

export class NewsRepository {
  constructor(private readonly db: Database) {}

  /**
   * Inserts new articles; existing ones (same content_hash OR same source_url within the data mode)
   * are left untouched. Returns the stored id for every input, so mentions can attach to either.
   */
  async saveArticles(articles: readonly NewsArticle[]): Promise<{ ids: string[]; inserted: number }> {
    const [first] = articles;
    if (!first) return { ids: [], inserted: 0 };
    const mode = first.dataMode;
    if (articles.some((a) => a.dataMode !== mode)) throw new AppError('INTERNAL', 'saveArticles needs a single data mode per call');

    const byHash = new Map<string, string>();
    const byUrl = new Map<string, string>();
    const remember = (r: { id: string; content_hash: string; source_url: string }) => {
      byHash.set(r.content_hash, r.id);
      byUrl.set(r.source_url, r.id);
    };
    let inserted = 0;
    for (const chunk of chunks(articles)) {
      const rows = await this.db
        .insertInto('news')
        .values(chunk.map((a) => ({
          data_mode: a.dataMode, title: a.title, description: a.description, content: a.content,
          source: a.source, source_url: a.sourceUrl, author: a.author, published_at: a.publishedAt,
          language: a.language, content_hash: a.contentHash,
        })))
        .onConflict((oc) => oc.doNothing())
        .returning(['id', 'content_hash', 'source_url'])
        .execute();
      inserted += rows.length;
      rows.forEach(remember);
    }

    const unresolved = articles.filter((a) => !byHash.has(a.contentHash) && !byUrl.has(a.sourceUrl));
    for (const chunk of chunks(unresolved)) {
      const rows = await this.db
        .selectFrom('news')
        .select(['id', 'content_hash', 'source_url'])
        .where('data_mode', '=', mode)
        .where((eb) => eb.or([
          eb('content_hash', 'in', chunk.map((a) => a.contentHash)),
          eb('source_url', 'in', chunk.map((a) => a.sourceUrl)),
        ]))
        .execute();
      rows.forEach(remember);
    }

    const ids = articles.map((a) => byHash.get(a.contentHash) ?? byUrl.get(a.sourceUrl));
    const resolved = ids.filter((id): id is string => id !== undefined);
    if (resolved.length !== articles.length) throw new AppError('INTERNAL', 'Could not resolve stored ids for every article');
    return { ids: resolved, inserted };
  }

  /** Upserts mentions; an existing mention keeps the higher relevance (and its matched_by). */
  async saveMentions(mentions: readonly NewsMention[]): Promise<number> {
    const best = new Map<string, NewsMention>();
    for (const m of mentions) {
      const key = `${m.newsId}|${m.ref.kind}|${m.ref.id}`;
      const current = best.get(key);
      if (!current || m.relevance > current.relevance) best.set(key, m);
    }
    let saved = 0;
    for (const kind of ['stock', 'market'] as const) {
      const column = kind === 'stock' ? 'stock_id' : 'market_id';
      const rows = [...best.values()].filter((m) => m.ref.kind === kind);
      for (const chunk of chunks(rows)) {
        const result = await this.db
          .insertInto('news_mentions')
          .values(chunk.map((m) => ({
            news_id: m.newsId,
            stock_id: kind === 'stock' ? m.ref.id : null,
            market_id: kind === 'market' ? m.ref.id : null,
            relevance_score: m.relevance,
            matched_by: m.matchedBy,
          })))
          .onConflict((oc) => oc
            .columns(['news_id', column])
            .where(column, 'is not', null)
            .doUpdateSet({
              relevance_score: sql`greatest(news_mentions.relevance_score, excluded.relevance_score)`,
              matched_by: sql`case when excluded.relevance_score > news_mentions.relevance_score
                                   then excluded.matched_by else news_mentions.matched_by end`,
            }))
          .returning('id')
          .execute();
        saved += result.length;
      }
    }
    return saved;
  }

  async listForInstrument(
    ref: InstrumentRef,
    mode: DataMode,
    options: { since?: Date; limit?: number; minRelevance?: number } = {},
  ): Promise<NewsItem[]> {
    let query = this.db
      .selectFrom('news_mentions as m')
      .innerJoin('news as n', 'n.id', 'm.news_id')
      .select(['n.id', 'n.title', 'n.description', 'n.source', 'n.source_url', 'n.published_at', 'm.relevance_score', 'm.matched_by'])
      .where(ref.kind === 'stock' ? 'm.stock_id' : 'm.market_id', '=', ref.id)
      .where('n.data_mode', '=', mode)
      .where('m.relevance_score', '>=', options.minRelevance ?? 0);
    if (options.since) query = query.where('n.published_at', '>=', options.since);
    const rows = await query
      .orderBy('n.published_at', 'desc')
      .limit(Math.min(Math.max(options.limit ?? 20, 1), 100))
      .execute();
    return rows.map((r) => ({
      id: r.id, title: r.title, description: r.description, source: r.source, sourceUrl: r.source_url,
      publishedAt: r.published_at, relevance: requireNumber(r.relevance_score, 'relevance_score'), matchedBy: r.matched_by,
    }));
  }
}
```
If Kysely rejects `.where()` on the conflict builder (index predicate) or the `'n.published_at'` type, adapt with `sql` fragments and record a ruling. The partial unique indexes need the `where stock_id is not null` predicate.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): news repository with two-key dedupe and best-relevance mention upsert`.

---

### Task 8: NewsService (orchestration, failure isolation, mentions, run logging)

**Files:** Create `backend/src/services/news/NewsService.ts`. Test: `backend/tests/integration/newsService.test.ts`.

**Interfaces:**
- Consumes:
  - the news contract (Task 2), `normalizeArticles` (Task 2), `MentionMatcher`, `subjectsFromInstruments`, `coreCompanyName` (Task 3)
  - `NewsRepository` (Task 7), `StockRepository.listActive`, `MarketRepository.listActive`, `SystemLogRepository`
  - `withRetry`, `mapWithConcurrency`, `toAppError`
- Produces:
  - `NewsSyncRequest { jobName; since; symbols?; includeMarket?; perQueryLimit? }`
  - `NewsSyncResult` (fields below)
  - `NewsServiceDeps`
  - `class NewsService { sync(request) }`

Run semantics:
- **Status:** `FAILED` if no query succeeded; `PARTIAL` if any query failed or any feed reported a failure; otherwise `SUCCESS`. Dropped articles are normal and don't affect status.
- **`system_logs` counts:**
  - `fetched` = raw articles
  - `inserted` = new articles
  - `skipped` = already stored + dropped
  - `failed` = failed queries
  - Mentions, failures and drop reasons go in `error_details`.

- [ ] **Step 1: Write the failing test** `backend/tests/integration/newsService.test.ts`

```ts
import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { MockNewsProvider } from '../../src/providers/news/mock/MockNewsProvider.js';
import type { InstrumentNewsQuery, NewsFetchResult, NewsProvider, RawArticle } from '../../src/providers/news/types.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { NewsService } from '../../src/services/news/NewsService.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({ level: 'silent', destination: new Writable({ write(_c, _e, cb) { cb(); } }) });
const NOW = new Date('2026-10-05T12:00:00Z');
const SINCE = new Date('2026-09-28T12:00:00Z');
const ok = (articles: RawArticle[] = []): NewsFetchResult => ({ articles, failures: [] });
const raw = (over: Partial<RawArticle>): RawArticle => ({
  title: 'x', url: 'https://example.com/x', description: null, content: null, author: null,
  publishedAt: new Date('2026-10-05T06:00:00Z'), publisherUrl: null, language: 'en', ...over,
});

/** Scripted provider: per query key ('market' or 'SYM1,SYM2') a result or an error. */
class ScriptedNews implements NewsProvider {
  readonly name = 'mock';
  calls: string[] = [];
  constructor(private readonly script: Record<string, NewsFetchResult | AppError>, private readonly size = 1) {}
  capabilities() { return { maxInstrumentsPerQuery: this.size, latency: 'realtime' as const }; }
  async fetchForInstruments(q: InstrumentNewsQuery) { return this.answer(q.subjects.map((s) => s.symbol).join(',')); }
  async fetchMarketNews() { return this.answer('market'); }
  private async answer(key: string): Promise<NewsFetchResult> {
    this.calls.push(key);
    const r = this.script[key];
    if (r instanceof AppError) throw r;
    return r ?? ok();
  }
}

function build(trx: Database, provider: NewsProvider) {
  return new NewsService({
    provider, dataMode: 'MOCK', logger: silent, now: () => NOW, retry: { sleep: async () => undefined },
    stocks: new StockRepository(trx), markets: new MarketRepository(trx), news: new NewsRepository(trx), systemLogs: new SystemLogRepository(trx),
  });
}

async function stockRef(trx: Database, symbol: string) {
  return { kind: 'stock' as const, id: (await new StockRepository(trx).findBySymbol(symbol))?.id ?? '' };
}

describe('NewsService', () => {
  it('syncs mock news idempotently, linking articles to stocks and indices', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const service = build(trx, new MockNewsProvider(() => NOW));
      const first = await service.sync({ jobName: 'test', since: SINCE, symbols: ['RELIANCE', 'TCS'] });
      expect(first).toMatchObject({ status: 'SUCCESS', queries: { total: 3, succeeded: 3, failed: 0 } });
      expect(first.articles.new).toBeGreaterThan(0);
      expect(first.articles.existing).toBe(0);

      const news = new NewsRepository(trx);
      const reliance = await news.listForInstrument(await stockRef(trx, 'RELIANCE'), 'MOCK');
      expect(reliance.length).toBeGreaterThan(0);
      expect(reliance.every((n) => n.title.startsWith('[MOCK] Reliance Industries') && n.relevance === 1 && n.matchedBy === 'name:title')).toBe(true);
      const markets = new MarketRepository(trx);
      const indexMentions = await Promise.all(['NIFTY50', 'SENSEX', 'BANKNIFTY', 'INDIAVIX'].map(async (s) =>
        (await news.listForInstrument({ kind: 'market', id: (await markets.findBySymbol(s))?.id ?? '' }, 'MOCK')).length));
      expect(indexMentions.reduce((a, b) => a + b, 0)).toBeGreaterThan(0);

      const again = await service.sync({ jobName: 'test', since: SINCE, symbols: ['RELIANCE', 'TCS'] });
      expect(again.articles).toMatchObject({ new: 0, existing: first.articles.new });
      expect(again.mentions).toBe(first.mentions);
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({ id: again.runId, status: 'SUCCESS', operation: 'sync:news', recordsInserted: 0 });
    });
  });

  it('isolates a failing query and a failing feed, and reports PARTIAL', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const provider = new ScriptedNews({
        market: { articles: [], failures: [{ source: 'Mint Markets', code: 'AUTH_FAILED', message: 'blocked' }] },
        RELIANCE: ok([raw({ title: 'Reliance Industries wins order', url: 'https://example.com/ril-order' })]),
        TCS: new AppError('TIMEOUT', 'slow'),
      });
      const r = await build(trx, provider).sync({ jobName: 'test', since: SINCE, symbols: ['RELIANCE', 'TCS'] });
      expect(r.status).toBe('PARTIAL');
      expect(r.queries).toEqual({ total: 3, succeeded: 2, failed: 1 });
      expect(r.failures.map((f) => [f.source, f.code]).sort()).toEqual([['Mint Markets', 'AUTH_FAILED'], ['TCS', 'TIMEOUT']]);
      expect(provider.calls.filter((c) => c === 'TCS')).toHaveLength(3);
      expect(r.articles.new).toBe(1);
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run?.errorDetails).toMatchObject({ failures: expect.arrayContaining([expect.objectContaining({ source: 'TCS', code: 'TIMEOUT' })]) });
    });
  });

  it('stores one row for a story seen by two routes and adds a low query-only mention', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const title = 'Reliance Industries raises funds via bonds';
      const r = await build(trx, new ScriptedNews({
        RELIANCE: ok([raw({ title, url: 'https://news.google.com/rss/articles/A?oc=5', publisherUrl: 'https://www.business-standard.com' })]),
        market: ok([raw({ title, url: 'https://www.business-standard.com/markets/news/ril-bonds.html', publishedAt: new Date('2026-10-05T06:04:00Z') })]),
        TCS: ok([raw({ title: 'IT services demand slows', url: 'https://example.com/it-demand' })]),
      })).sync({ jobName: 'test', since: SINCE, symbols: ['RELIANCE', 'TCS'] });
      expect(r.articles).toMatchObject({ fetched: 3, new: 2, dropped: 1 });
      expect(r.droppedByReason).toEqual({ DUPLICATE_IN_BATCH: 1 });
      const news = new NewsRepository(trx);
      expect(await news.listForInstrument(await stockRef(trx, 'RELIANCE'), 'MOCK')).toEqual([expect.objectContaining({ title, relevance: 1, matchedBy: 'name:title' })]);
      expect(await news.listForInstrument(await stockRef(trx, 'TCS'), 'MOCK')).toEqual([expect.objectContaining({ relevance: 0.4, matchedBy: 'query' })]);
    });
  });

  it('batches instruments when the provider allows it (no query-only mentions for batches)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const provider = new ScriptedNews({ 'INFY,RELIANCE,TCS': ok([raw({ title: 'Markets await RBI policy', url: 'https://example.com/rbi' })]) }, 10);
      const r = await build(trx, provider).sync({ jobName: 'test', since: SINCE, symbols: ['RELIANCE', 'TCS', 'INFY'], includeMarket: false });
      expect(provider.calls).toEqual(['INFY,RELIANCE,TCS']);
      expect(r).toMatchObject({ status: 'SUCCESS', mentions: 0 });
    });
  });

  it('reports FAILED when nothing succeeds and notes unknown symbols; counts undated articles as dropped', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const failed = await build(trx, new ScriptedNews({ TCS: new AppError('AUTH_FAILED', 'bad key') }))
        .sync({ jobName: 'test', since: SINCE, symbols: ['TCS', 'NOSUCH'], includeMarket: false });
      expect(failed.status).toBe('FAILED');
      expect(failed.notes.join(' ')).toMatch(/NOSUCH/);

      const undated = await build(trx, new ScriptedNews({ market: ok([raw({ publishedAt: null })]) }))
        .sync({ jobName: 'test', since: SINCE, symbols: [] });
      expect(undated).toMatchObject({ status: 'SUCCESS', droppedByReason: { INVALID_DATE: 1 } });
    });
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/services/news/NewsService.ts`

```ts
import type { Logger } from 'pino';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import type { NewsMention } from '../../domain/news.js';
import type { Stock } from '../../domain/types.js';
import type { NewsFetchResult, NewsProvider, NewsSubject, SourceFailure } from '../../providers/news/types.js';
import type { MarketRepository } from '../../repositories/MarketRepository.js';
import type { NewsRepository } from '../../repositories/NewsRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { mapWithConcurrency } from '../../utils/concurrency.js';
import { toAppError } from '../../utils/errors.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import { type ArticleDropReason, normalizeArticles, type TaggedRawArticle } from './articleNormalizer.js';
import { coreCompanyName, MentionMatcher, subjectsFromInstruments } from './mentionMatcher.js';

const DEFAULT_PER_QUERY_LIMIT = 50;

export interface NewsSyncRequest {
  jobName: string;
  since: Date;
  /** Stocks to query by name. Omit for all active stocks; [] for market feeds only. */
  symbols?: readonly string[];
  includeMarket?: boolean;
  perQueryLimit?: number;
}

export interface NewsSyncResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  dataMode: DataMode;
  since: Date;
  queries: { total: number; succeeded: number; failed: number };
  articles: { fetched: number; new: number; existing: number; dropped: number };
  mentions: number;
  droppedByReason: Partial<Record<ArticleDropReason, number>>;
  failures: SourceFailure[];
  notes: string[];
}

export interface NewsServiceDeps {
  provider: NewsProvider;
  stocks: StockRepository;
  markets: MarketRepository;
  news: NewsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  retry?: RetryOptions;
  concurrency?: number;
}

interface Query {
  label: string;
  queriedFor: string[];
  run: () => Promise<NewsFetchResult>;
}

const toSubject = (s: Stock): NewsSubject => ({ symbol: s.symbol, name: coreCompanyName(s.companyName), aliases: s.aliases });
const sum = (rec: Partial<Record<string, number>>) => Object.values(rec).reduce<number>((a, v) => a + (v ?? 0), 0);

export class NewsService {
  private readonly now: () => Date;

  constructor(private readonly deps: NewsServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async sync(request: NewsSyncRequest): Promise<NewsSyncResult> {
    const { provider, systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({ service: 'NewsService', jobName: request.jobName, operation: 'sync:news' });
    const result: NewsSyncResult = {
      runId, status: 'SUCCESS', provider: provider.name, dataMode: this.deps.dataMode, since: request.since,
      queries: { total: 0, succeeded: 0, failed: 0 },
      articles: { fetched: 0, new: 0, existing: 0, dropped: 0 },
      mentions: 0, droppedByReason: {}, failures: [], notes: [],
    };
    let runError: unknown;

    try {
      const [stocks, markets] = await Promise.all([this.deps.stocks.listActive(), this.deps.markets.listActive()]);
      const matcher = new MentionMatcher(subjectsFromInstruments(stocks, markets));
      const targets = this.targets(stocks, request, result);
      const queries = this.queries(targets, request);
      result.queries.total = queries.length;

      const tagged: TaggedRawArticle[] = [];
      await mapWithConcurrency(queries, this.deps.concurrency ?? 2, async (query) => {
        try {
          const fetched = await withRetry(query.run, this.deps.retry);
          for (const article of fetched.articles) tagged.push({ article, queriedFor: query.queriedFor });
          result.failures.push(...fetched.failures);
          result.queries.succeeded += 1;
        } catch (error) {
          const e = toAppError(error);
          result.failures.push({ source: query.label, code: e.code, message: e.message });
          result.queries.failed += 1;
          logger.warn({ query: query.label, code: e.code }, 'news query failed');
        }
      });

      result.articles.fetched = tagged.length;
      const normalized = normalizeArticles(tagged, { dataMode: this.deps.dataMode, now, since: request.since });
      result.droppedByReason = normalized.dropped;
      result.articles.dropped = sum(normalized.dropped);
      if (normalized.articles.length > 0) {
        const { ids, inserted } = await this.deps.news.saveArticles(normalized.articles);
        result.articles.new = inserted;
        result.articles.existing = ids.length - inserted;
        const mentions: NewsMention[] = [];
        normalized.articles.forEach((article, i) => {
          const newsId = ids[i];
          if (!newsId) return;
          for (const m of matcher.match(article, article.queriedFor)) {
            mentions.push({ newsId, ref: m.ref, relevance: m.relevance, matchedBy: m.matchedBy });
          }
        });
        result.mentions = await this.deps.news.saveMentions(mentions);
      }
      result.status =
        result.queries.succeeded === 0 ? 'FAILED' : result.failures.length > 0 ? 'PARTIAL' : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.articles.fetched,
          inserted: result.articles.new,
          skipped: result.articles.existing + result.articles.dropped,
          failed: result.queries.failed,
        },
        message: this.summary(result),
        ...(runError === undefined ? {} : { error: runError }),
        details: { failures: result.failures, dropped: result.droppedByReason, mentions: result.mentions, notes: result.notes, provider: provider.name },
      });
    }
    logger.info({ runId, status: result.status, new: result.articles.new, mentions: result.mentions }, 'news sync finished');
    return result;
  }

  private targets(stocks: Stock[], request: NewsSyncRequest, result: NewsSyncResult): Stock[] {
    if (!request.symbols) return stocks;
    const wanted = new Set(request.symbols.map((s) => s.trim().toUpperCase()).filter(Boolean));
    const targets = stocks.filter((s) => wanted.has(s.symbol));
    const missing = [...wanted].filter((s) => !targets.some((t) => t.symbol === s));
    if (missing.length > 0) result.notes.push(`unknown or inactive stock symbols: ${missing.join(', ')}`);
    return targets;
  }

  private queries(targets: Stock[], request: NewsSyncRequest): Query[] {
    const { provider } = this.deps;
    const limit = request.perQueryLimit ?? DEFAULT_PER_QUERY_LIMIT;
    const queries: Query[] = [];
    if (request.includeMarket !== false) {
      queries.push({ label: 'market', queriedFor: [], run: () => provider.fetchMarketNews({ since: request.since, limit }) });
    }
    const size = Math.max(1, provider.capabilities().maxInstrumentsPerQuery);
    for (let i = 0; i < targets.length; i += size) {
      const group = targets.slice(i, i + size);
      const [only] = group;
      queries.push({
        label: group.map((s) => s.symbol).join(','),
        // Only a single-instrument query proves the article was "about" that instrument.
        queriedFor: group.length === 1 && only ? [only.symbol] : [],
        run: () => provider.fetchForInstruments({ subjects: group.map(toSubject), since: request.since, limit }),
      });
    }
    return queries;
  }

  private summary(r: NewsSyncResult): string {
    const failed = r.failures.map((f) => `${f.source} (${f.code})`).join(', ');
    return `${r.queries.succeeded}/${r.queries.total} queries ok; ${r.articles.new} new, ${r.articles.existing} already stored, ` +
      `${r.articles.dropped} dropped; ${r.mentions} mentions${failed ? `; failed: ${failed}` : ''}`;
  }
}
```
Note: `StockRepository.listActive()` orders by symbol, so a batched query key is alphabetical (`INFY,RELIANCE,TCS`), as the batching test expects. With no queries at all (`symbols: []` plus `includeMarket: false`), `succeeded === 0` gives FAILED, which is correct: nothing was fetched.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): NewsService with per-query isolation, mention linking and run logging`.

---

### Task 9: Fundamentals contract, units, numeric guard, mock provider

**Files:**
- Create:
  - `backend/src/domain/fundamentals.ts`
  - `backend/src/providers/fundamentals/types.ts`
  - `backend/src/services/fundamentals/numeric.ts`
  - `backend/src/providers/fundamentals/mock/MockFundamentalsProvider.ts`
- Test: `backend/tests/unit/fundamentalsNumeric.test.ts`, `backend/tests/unit/mockFundamentalsProvider.test.ts`

**Interfaces — Produces:**
- `domain/fundamentals.ts`:
  - `SNAPSHOT_FIELDS`, `SnapshotField`, `SnapshotMetrics`
  - `REPORTING_CURRENCY_FIELDS`
  - `STATEMENT_FIELDS`, `StatementField`, `StatementMetrics`
  - `StatementPeriod`
  - `FundamentalSnapshotRecord`, `FinancialStatementRecord`
- `providers/fundamentals/types.ts`:
  - `FundamentalsCapabilities { fields; statementPeriods }`
  - `ProviderFundamentalSnapshot { asOf: Date; reportingCurrency: string|null; metrics: SnapshotMetrics; raw }`
  - `ProviderStatement { periodType; periodEnd: 'YYYY-MM-DD'; metrics; raw }`
  - `ProviderStatements { reportingCurrency; statements }`
  - `FundamentalsProvider { name; capabilities(); getSnapshot(ref); getStatements(ref, period) }`, where `ref` is `ProviderInstrumentRef` from `providers/market/types.ts`
- `numeric.ts`: `fitNumeric(value, precision, scale)`, `fitMetrics(metrics, columns)`, `SNAPSHOT_COLUMNS`, `STATEMENT_COLUMNS`
- `new MockFundamentalsProvider(price?: (ref) => Promise<number|null>, now?: () => Date)` with `name 'mock'`

- [ ] **Step 1: Write the failing tests**

`backend/tests/unit/fundamentalsNumeric.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { fitMetrics, fitNumeric, SNAPSHOT_COLUMNS } from '../../src/services/fundamentals/numeric.js';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';

describe('fitNumeric', () => {
  it('rounds to the column scale and nulls what would overflow or is not finite', () => {
    expect(fitNumeric(21.48497, 10, 2)).toBe(21.48);
    expect(fitNumeric(99_999_999.99, 10, 2)).toBe(99_999_999.99);
    expect(fitNumeric(100_000_000, 10, 2)).toBeNull();
    expect(fitNumeric(-1e12, 10, 2)).toBeNull();
    expect(fitNumeric(Number.NaN, 8, 2)).toBeNull();
    expect(fitNumeric(Number.POSITIVE_INFINITY, 8, 2)).toBeNull();
    expect(fitNumeric(null, 8, 2)).toBeNull();
  });

  it('fits every snapshot field and reports which ones were out of range', () => {
    const r = fitMetrics({ ...emptySnapshotMetrics(), pe: 1e12, beta: Number.NaN, roe: 13.838 }, SNAPSHOT_COLUMNS);
    expect(r.metrics).toMatchObject({ pe: null, beta: null, roe: 13.84 });
    expect(r.outOfRange.sort()).toEqual(['beta', 'pe']);
  });
});
```
`backend/tests/unit/mockFundamentalsProvider.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';

const NOW = () => new Date('2026-10-05T20:00:00Z'); // IST 2026-10-06
const ref = (symbol: string) => ({ providerSymbol: symbol, exchange: 'NSE' as const, kind: 'stock' as const });
const priced = () => new MockFundamentalsProvider(async () => 1000, NOW);

describe('MockFundamentalsProvider', () => {
  it('is deterministic and labelled mock', async () => {
    const a = await priced().getSnapshot(ref('RELIANCE'));
    expect(await priced().getSnapshot(ref('RELIANCE'))).toEqual(a);
    expect(a).toMatchObject({ reportingCurrency: 'INR', raw: { mock: true } });
  });

  it('reports 8 quarters (45-day results lag) and 5 fiscal years ending 31 March', async () => {
    const q = await priced().getStatements(ref('RELIANCE'), 'QUARTERLY');
    expect(q.statements.map((s) => s.periodEnd)).toEqual([
      '2024-09-30', '2024-12-31', '2025-03-31', '2025-06-30', '2025-09-30', '2025-12-31', '2026-03-31', '2026-06-30',
    ]);
    const a = await priced().getStatements(ref('RELIANCE'), 'ANNUAL');
    expect(a.statements.map((s) => s.periodEnd)).toEqual(['2022-03-31', '2023-03-31', '2024-03-31', '2025-03-31', '2026-03-31']);
  });

  it('keeps snapshot, quarters and years internally consistent', async () => {
    const p = priced();
    const snap = await p.getSnapshot(ref('RELIANCE'));
    const quarters = (await p.getStatements(ref('RELIANCE'), 'QUARTERLY')).statements;
    const years = (await p.getStatements(ref('RELIANCE'), 'ANNUAL')).statements;
    const last4 = quarters.slice(-4);
    const total = (rows: typeof quarters, f: 'revenue' | 'eps') => rows.reduce((s, r) => s + (r.metrics[f] ?? 0), 0);
    expect(snap.metrics.revenueTtm).toBeCloseTo(total(last4, 'revenue'), 0);
    expect((snap.metrics.pe ?? 0) * (snap.metrics.epsTtm ?? 0)).toBeCloseTo(1000, 6);
    const fy26Quarters = quarters.filter((s) => s.periodEnd > '2025-03-31' && s.periodEnd <= '2026-03-31');
    expect(years.at(-1)?.metrics.revenue).toBeCloseTo(total(fy26Quarters, 'revenue'), 0);
  });

  it('leaves leverage ratios empty for banks and price ratios empty without a price', async () => {
    const bank = await priced().getSnapshot(ref('HDFCBANK'));
    expect(bank.metrics).toMatchObject({ debtToEquity: null, roce: null });
    expect((await priced().getSnapshot(ref('RELIANCE'))).metrics.debtToEquity).toBeGreaterThan(0);
    const unpriced = await new MockFundamentalsProvider(async () => null, NOW).getSnapshot(ref('RELIANCE'));
    expect(unpriced.metrics).toMatchObject({ pe: null, pb: null, marketCap: null });
  });
});
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/domain/fundamentals.ts`

```ts
import type { DataMode } from './enums.js';

/**
 * Units, as stored (Phase 5 reads them this way):
 * - percentages: 13.8 = 13.8 % (roe, roce, dividendYield, operatingMargin, netMargin, revenueGrowthYoy, profitGrowthYoy)
 * - debtToEquity is a ratio: 0.46 = debt is 46 % of equity
 * - money is absolute INR (marketCap, freeCashFlow, revenueTtm, netProfitTtm, statement amounts); per-share values in INR
 * - capex is as reported: an outflow is negative
 * null = unavailable from the source. Never estimated.
 */
export const SNAPSHOT_FIELDS = [
  'marketCap', 'pe', 'pb', 'epsTtm', 'roe', 'roce', 'debtToEquity', 'dividendYield', 'operatingMargin', 'netMargin',
  'freeCashFlow', 'revenueTtm', 'netProfitTtm', 'revenueGrowthYoy', 'profitGrowthYoy', 'bookValuePerShare', 'beta',
] as const;
export type SnapshotField = (typeof SNAPSHOT_FIELDS)[number];
export type SnapshotMetrics = Record<SnapshotField, number | null>;

/** Absolute amounts in the company's reporting currency. Stored only when that currency is INR. */
export const REPORTING_CURRENCY_FIELDS: readonly SnapshotField[] = ['freeCashFlow', 'revenueTtm', 'netProfitTtm'];

export const STATEMENT_FIELDS = [
  'revenue', 'operatingProfit', 'netProfit', 'eps', 'totalDebt', 'totalEquity', 'cashFromOperations', 'capex',
] as const;
export type StatementField = (typeof STATEMENT_FIELDS)[number];
export type StatementMetrics = Record<StatementField, number | null>;

export type StatementPeriod = 'QUARTERLY' | 'ANNUAL';

export interface FundamentalSnapshotRecord {
  stockId: string;
  dataMode: DataMode;
  /** IST calendar date (YYYY-MM-DD). One snapshot per stock per day per source. */
  asOf: string;
  source: string;
  metrics: SnapshotMetrics;
  raw: Record<string, unknown>;
}

export interface FinancialStatementRecord {
  stockId: string;
  dataMode: DataMode;
  periodType: StatementPeriod;
  periodEnd: string;
  source: string;
  metrics: StatementMetrics;
  raw: Record<string, unknown>;
}

export const emptySnapshotMetrics = (): SnapshotMetrics =>
  Object.fromEntries(SNAPSHOT_FIELDS.map((f) => [f, null])) as SnapshotMetrics;
export const emptyStatementMetrics = (): StatementMetrics =>
  Object.fromEntries(STATEMENT_FIELDS.map((f) => [f, null])) as StatementMetrics;
```
`backend/src/providers/fundamentals/types.ts`:
```ts
import type { SnapshotField, SnapshotMetrics, StatementMetrics, StatementPeriod } from '../../domain/fundamentals.js';
import type { ProviderInstrumentRef } from '../market/types.js';

export interface FundamentalsCapabilities {
  /** Fields the source can supply at all; other fields are always null ("not provided by source"). */
  fields: readonly SnapshotField[];
  statementPeriods: readonly StatementPeriod[];
}

export interface ProviderFundamentalSnapshot {
  asOf: Date;
  /** Currency of the company's financial statements (INFY on Yahoo: USD). Per-share/price fields are in INR. */
  reportingCurrency: string | null;
  metrics: SnapshotMetrics;
  raw: Record<string, unknown>;
}

export interface ProviderStatement {
  periodType: StatementPeriod;
  /** YYYY-MM-DD */
  periodEnd: string;
  metrics: StatementMetrics;
  raw: Record<string, unknown>;
}

export interface ProviderStatements {
  reportingCurrency: string | null;
  statements: ProviderStatement[];
}

/** All fundamentals enter the system through this interface. Units: see domain/fundamentals.ts. */
export interface FundamentalsProvider {
  readonly name: string;
  capabilities(): FundamentalsCapabilities;
  getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot>;
  getStatements(ref: ProviderInstrumentRef, period: StatementPeriod): Promise<ProviderStatements>;
}
```
`backend/src/services/fundamentals/numeric.ts`:
```ts
import type { SnapshotField, StatementField } from '../../domain/fundamentals.js';

type Column = readonly [precision: number, scale: number];

/** numeric(p,s) of each column (migration 20261005000500). */
export const SNAPSHOT_COLUMNS: Readonly<Record<SnapshotField, Column>> = {
  marketCap: [20, 2], pe: [10, 2], pb: [10, 2], epsTtm: [18, 4], roe: [8, 2], roce: [8, 2],
  debtToEquity: [10, 4], dividendYield: [8, 4], operatingMargin: [8, 2], netMargin: [8, 2],
  freeCashFlow: [20, 2], revenueTtm: [20, 2], netProfitTtm: [20, 2], revenueGrowthYoy: [8, 2],
  profitGrowthYoy: [8, 2], bookValuePerShare: [18, 4], beta: [8, 4],
};

export const STATEMENT_COLUMNS: Readonly<Record<StatementField, Column>> = {
  revenue: [20, 2], operatingProfit: [20, 2], netProfit: [20, 2], eps: [18, 4],
  totalDebt: [20, 2], totalEquity: [20, 2], cashFromOperations: [20, 2], capex: [20, 2],
};

/** A value that is not finite or would overflow numeric(p,s) becomes null instead of failing the whole insert. */
export function fitNumeric(value: number | null | undefined, precision: number, scale: number): number | null {
  if (value === null || value === undefined || !Number.isFinite(value)) return null;
  const factor = 10 ** scale;
  const rounded = Math.round(value * factor) / factor;
  return Math.abs(rounded) < 10 ** (precision - scale) ? rounded : null;
}

export function fitMetrics<F extends string>(
  metrics: Readonly<Record<F, number | null>>,
  columns: Readonly<Record<F, Column>>,
): { metrics: Record<F, number | null>; outOfRange: F[] } {
  const out = { ...metrics } as Record<F, number | null>;
  const outOfRange: F[] = [];
  for (const field of Object.keys(columns) as F[]) {
    const value = metrics[field];
    const [precision, scale] = columns[field];
    const fitted = fitNumeric(value, precision, scale);
    if (value !== null && fitted === null) outOfRange.push(field);
    out[field] = fitted;
  }
  return { metrics: out, outOfRange };
}
```
`backend/src/providers/fundamentals/mock/MockFundamentalsProvider.ts`:
```ts
import {
  SNAPSHOT_FIELDS, type SnapshotMetrics, type StatementMetrics, type StatementPeriod,
} from '../../../domain/fundamentals.js';
import { addDays, toIst } from '../../../utils/ist.js';
import { profileFor } from '../../market/mock/fixtures.js';
import { rngFor } from '../../market/mock/random.js';
import type { ProviderInstrumentRef } from '../../market/types.js';
import type {
  FundamentalsCapabilities, FundamentalsProvider, ProviderFundamentalSnapshot, ProviderStatement, ProviderStatements,
} from '../types.js';

const QUARTER_ENDS = ['03-31', '06-30', '09-30', '12-31'] as const;
const QUARTERS = 8;
const YEARS = 5;
const QUARTER_LAG_DAYS = 45;
const ANNUAL_LAG_DAYS = 60;
const ANCHOR_YEAR = 2015;
/** Banks/NBFCs: leverage is their business, so D/E and ROCE are not meaningful (PRD §8.2). */
const FINANCIAL_SECTORS = new Set(['banks', 'financials']);

export type PriceLookup = (ref: ProviderInstrumentRef) => Promise<number | null>;

interface Params {
  financial: boolean;
  shares: number;
  baseRevenue: number;
  growth: number;
  opMargin: number;
  leverage: number;
  equityMultiple: number;
  capexRatio: number;
  dividendYield: number;
  beta: number;
}

function recentQuarterEnds(last: string, count: number): string[] {
  const out: string[] = [];
  for (let y = Number(last.slice(0, 4)); out.length < count; y -= 1) {
    for (const end of [...QUARTER_ENDS].reverse()) {
      const d = `${y}-${end}`;
      if (d <= last && out.length < count) out.push(d);
    }
  }
  return out.reverse();
}

const quarterIndex = (end: string) =>
  (Number(end.slice(0, 4)) - ANCHOR_YEAR) * 4 + QUARTER_ENDS.indexOf(end.slice(5) as (typeof QUARTER_ENDS)[number]);

/**
 * MOCK fundamentals: deterministic per symbol, internally consistent (TTM = sum of the last 4 quarters,
 * a fiscal year = its 4 quarters, P/E = price / TTM EPS). Synthetic; stored only with data_mode = MOCK.
 */
export class MockFundamentalsProvider implements FundamentalsProvider {
  readonly name = 'mock';

  constructor(
    private readonly price: PriceLookup = async () => null,
    private readonly now: () => Date = () => new Date(),
  ) {}

  capabilities(): FundamentalsCapabilities {
    return { fields: SNAPSHOT_FIELDS, statementPeriods: ['QUARTERLY', 'ANNUAL'] };
  }

  async getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot> {
    const symbol = ref.providerSymbol;
    const p = this.params(symbol);
    const quarters = this.quarters(symbol);
    const years = this.years(symbol);
    const last4 = quarters.slice(-4);
    const ttm = (f: keyof StatementMetrics) => last4.reduce((s, q) => s + (q.metrics[f] ?? 0), 0);
    const revenueTtm = ttm('revenue');
    const netProfitTtm = ttm('netProfit');
    const epsTtm = ttm('eps');
    const latest = quarters.at(-1)?.metrics;
    const equity = latest?.totalEquity ?? 0;
    const debt = latest?.totalDebt ?? 0;
    const bookValuePerShare = equity / p.shares;
    const [previous, current] = years.slice(-2);
    const growth = (f: 'revenue' | 'netProfit') => {
      const a = previous?.metrics[f];
      const b = current?.metrics[f];
      return a && b ? (b / a - 1) * 100 : null;
    };
    const price = await this.price(ref);
    const metrics: SnapshotMetrics = {
      marketCap: price === null ? null : price * p.shares,
      pe: price !== null && epsTtm > 0 ? price / epsTtm : null,
      pb: price !== null && bookValuePerShare > 0 ? price / bookValuePerShare : null,
      epsTtm,
      roe: (netProfitTtm / equity) * 100,
      roce: p.financial ? null : (ttm('operatingProfit') / (equity + debt)) * 100,
      debtToEquity: p.financial ? null : debt / equity,
      dividendYield: p.dividendYield,
      operatingMargin: (ttm('operatingProfit') / revenueTtm) * 100,
      netMargin: (netProfitTtm / revenueTtm) * 100,
      freeCashFlow: ttm('cashFromOperations') + ttm('capex'),
      revenueTtm,
      netProfitTtm,
      revenueGrowthYoy: growth('revenue'),
      profitGrowthYoy: growth('netProfit'),
      bookValuePerShare,
      beta: p.beta,
    };
    return { asOf: this.now(), reportingCurrency: 'INR', metrics, raw: { mock: true } };
  }

  async getStatements(ref: ProviderInstrumentRef, period: StatementPeriod): Promise<ProviderStatements> {
    const statements = period === 'QUARTERLY' ? this.quarters(ref.providerSymbol) : this.years(ref.providerSymbol);
    return { reportingCurrency: 'INR', statements };
  }

  private quarters(symbol: string): ProviderStatement[] {
    const last = addDays(toIst(this.now()).date, -QUARTER_LAG_DAYS);
    return recentQuarterEnds(last, QUARTERS).map((end) => this.quarter(symbol, end));
  }

  private years(symbol: string): ProviderStatement[] {
    const last = addDays(toIst(this.now()).date, -ANNUAL_LAG_DAYS);
    const fyEnds = recentQuarterEnds(last, QUARTERS * 3).filter((d) => d.endsWith('-03-31')).slice(-YEARS);
    return fyEnds.map((fyEnd) => {
      const year = Number(fyEnd.slice(0, 4));
      const qs = [`${year - 1}-06-30`, `${year - 1}-09-30`, `${year - 1}-12-31`, fyEnd].map((e) => this.quarter(symbol, e).metrics);
      const flow = (f: keyof StatementMetrics) => qs.reduce((s, q) => s + (q[f] ?? 0), 0);
      const close = qs[3];
      const metrics: StatementMetrics = {
        revenue: flow('revenue'), operatingProfit: flow('operatingProfit'), netProfit: flow('netProfit'), eps: flow('eps'),
        totalDebt: close?.totalDebt ?? null, totalEquity: close?.totalEquity ?? null,
        cashFromOperations: flow('cashFromOperations'), capex: flow('capex'),
      };
      return { periodType: 'ANNUAL' as const, periodEnd: fyEnd, metrics, raw: { mock: true } };
    });
  }

  private quarter(symbol: string, end: string): ProviderStatement {
    const p = this.params(symbol);
    const rng = rngFor('fundamentals', symbol, end);
    const scale = (1 + p.growth) ** quarterIndex(end);
    const revenue = p.baseRevenue * scale * (0.96 + 0.08 * rng());
    const operatingProfit = revenue * (p.opMargin + 0.02 * (rng() - 0.5));
    const netProfit = operatingProfit * 0.72;
    const totalEquity = p.baseRevenue * p.equityMultiple * scale;
    const metrics: StatementMetrics = {
      revenue, operatingProfit, netProfit, eps: netProfit / p.shares,
      totalDebt: totalEquity * p.leverage, totalEquity,
      cashFromOperations: netProfit * (1.1 + 0.2 * rng()), capex: -revenue * p.capexRatio,
    };
    return { periodType: 'QUARTERLY', periodEnd: end, metrics, raw: { mock: true } };
  }

  private params(symbol: string): Params {
    const rng = rngFor('fundamentals-params', symbol);
    const financial = FINANCIAL_SECTORS.has(profileFor(symbol).sector);
    return {
      financial,
      shares: Math.round(5e8 + rng() * 1e10),
      baseRevenue: 5e9 + rng() * 2e11,
      growth: 0.01 + rng() * 0.03,
      opMargin: financial ? 0.3 + 0.1 * rng() : 0.1 + 0.2 * rng(),
      leverage: financial ? 1 : 0.1 + 1.2 * rng(),
      equityMultiple: 2 + 4 * rng(),
      capexRatio: 0.03 + 0.1 * rng(),
      dividendYield: 0.2 + 2.8 * rng(),
      beta: 0.5 + 0.9 * rng(),
    };
  }
}
```
Check the expected periods: NOW is IST 2026-10-06. The quarterly cut-off 2026-08-22 gives a last quarter of 2026-06-30, so the eight quarters run 2024-09-30 … 2026-06-30. The annual cut-off 2026-08-07 gives FY ends 2022–2026.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): fundamentals contract, units convention, numeric guard and mock provider`.

---

### Task 10: Yahoo fundamentals provider (shared Yahoo instance) + live smoke test

**Files:**
- Create:
  - `backend/src/providers/yahoo/instance.ts`
  - `backend/src/providers/fundamentals/yahoo/yahooFundamentalsClient.ts`
  - `backend/src/providers/fundamentals/yahoo/YahooFundamentalsProvider.ts`
- Modify:
  - `backend/src/providers/market/yahoo/yahooClient.ts` (`createYahooClient(yf = createYahooFinance())`)
  - `backend/src/providers/market/yahoo/errors.ts` (move `assertIndianListing` here and export it)
  - `backend/src/providers/market/yahoo/YahooMarketDataProvider.ts` (import it)
- Test: `backend/tests/unit/yahooFundamentalsProvider.test.ts`, `backend/tests/live/yahooFundamentals.live.test.ts`

**Interfaces:**
- Consumes: the Task 9 contract, `mapYahooError`, `RateLimiter`.
- Produces:
  - `createYahooFinance()`, `YahooFinanceInstance`
  - `YahooSummary`, `YahooStatementRow`, `YahooFundamentalsClient`, `createYahooFundamentalsClient(yf)`
  - `new YahooFundamentalsProvider(client, limiter, now?)` with `name 'yahoo'`; capabilities `fields` = all except `roce`

Conversions (probe-verified):

| Our field | Yahoo source |
| --- | --- |
| roe | `returnOnEquity × 100` |
| debtToEquity | `debtToEquity ÷ 100` |
| dividendYield | `dividendYield × 100` |
| operatingMargin | `operatingMargins × 100` |
| netMargin | `profitMargins × 100` |
| revenueGrowthYoy | `revenueGrowth × 100` |
| profitGrowthYoy | `earningsGrowth × 100` |
| netProfitTtm | `netIncomeToCommon` |
| bookValuePerShare | `bookValue` |
| roce | always null |

Statements come from `fundamentalsTimeSeries`:
- `periodType` `12M` is ANNUAL; `3M` is QUARTERLY.
- `netProfit` = `netIncomeCommonStockholders ?? netIncome`.
- Rows where every metric is null are dropped.
- The reporting currency comes from `financialData.financialCurrency`, cached from the snapshot for 6 h.

- [ ] **Step 1: Write the failing tests**

`backend/tests/unit/yahooFundamentalsProvider.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import type { YahooFundamentalsClient, YahooStatementRow, YahooSummary } from '../../src/providers/fundamentals/yahoo/yahooFundamentalsClient.js';
import { YahooFundamentalsProvider } from '../../src/providers/fundamentals/yahoo/YahooFundamentalsProvider.js';

const REF = { providerSymbol: 'RELIANCE.NS', exchange: 'NSE', kind: 'stock' } as const;
const NOW = () => new Date('2026-10-05T12:00:00Z');
const summary = (over: Partial<YahooSummary> = {}): YahooSummary => ({
  exchange: 'NSI', financialCurrency: 'INR', marketCap: 16_054_925_393_920, trailingPE: 21.48497, priceToBook: 1.7759284,
  trailingEps: 55.22, returnOnEquity: 0.13838, debtToEquity: 46.278, dividendYield: 0.0051, operatingMargins: 0.12331,
  profitMargins: 0.066149995, freeCashflow: null, totalRevenue: 11_296_050_249_728, netIncomeToCommon: 747_000_000_000,
  revenueGrowth: 0.297, earningsGrowth: -0.224, bookValue: 668.045, beta: 0.194, ...over,
});
const row = (date: string, periodType: string, values: Record<string, number>): YahooStatementRow => ({ date: new Date(`${date}T00:00:00Z`), periodType, values });

class FakeClient implements YahooFundamentalsClient {
  calls: string[] = [];
  constructor(private readonly s: YahooSummary | Error, private readonly rows: YahooStatementRow[] = []) {}
  async summary(symbol: string) { this.calls.push(`summary:${symbol}`); if (this.s instanceof Error) throw this.s; return this.s; }
  async timeSeries(symbol: string, type: string) { this.calls.push(`ts:${type}`); return this.rows; }
}

function provider(client: FakeClient) {
  let acquired = 0;
  return { p: new YahooFundamentalsProvider(client, { acquire: async () => { acquired += 1; } }, NOW), acquired: () => acquired };
}

describe('YahooFundamentalsProvider', () => {
  it('converts Yahoo fractions to percent and D/E percent to a ratio; ROCE is never provided', async () => {
    const { p } = provider(new FakeClient(summary()));
    const s = await p.getSnapshot(REF);
    expect(s.reportingCurrency).toBe('INR');
    expect(s.asOf).toEqual(NOW());
    expect(s.metrics.roe).toBeCloseTo(13.838, 6);
    expect(s.metrics.debtToEquity).toBeCloseTo(0.46278, 6);
    expect(s.metrics.dividendYield).toBeCloseTo(0.51, 6);
    expect(s.metrics.operatingMargin).toBeCloseTo(12.331, 6);
    expect(s.metrics.netMargin).toBeCloseTo(6.6149995, 6);
    expect(s.metrics.revenueGrowthYoy).toBeCloseTo(29.7, 6);
    expect(s.metrics.profitGrowthYoy).toBeCloseTo(-22.4, 6);
    expect(s.metrics).toMatchObject({ pe: 21.48497, pb: 1.7759284, epsTtm: 55.22, bookValuePerShare: 668.045, beta: 0.194, freeCashFlow: null, roce: null, netProfitTtm: 747_000_000_000 });
    expect(p.capabilities().fields).not.toContain('roce');
  });

  it('keeps missing values null and passes the reporting currency through', async () => {
    const { p } = provider(new FakeClient(summary({ returnOnEquity: null, debtToEquity: null, financialCurrency: 'USD' })));
    const s = await p.getSnapshot(REF);
    expect(s.metrics).toMatchObject({ roe: null, debtToEquity: null });
    expect(s.reportingCurrency).toBe('USD');
  });

  it('refuses non-Indian listings and maps unknown symbols to UNSUPPORTED', async () => {
    await expect(provider(new FakeClient(summary({ exchange: 'NMS' }))).p.getSnapshot(REF)).rejects.toMatchObject({ code: 'UNSUPPORTED' });
    await expect(provider(new FakeClient(summary({ exchange: null }))).p.getSnapshot(REF)).rejects.toMatchObject({ code: 'INVALID_RESPONSE' });
    await expect(provider(new FakeClient(new Error('Quote not found for symbol: NOPE.NS'))).p.getSnapshot(REF)).rejects.toMatchObject({ code: 'UNSUPPORTED' });
  });

  it('maps statements for the requested period, drops empty rows, reuses the cached currency', async () => {
    const client = new FakeClient(summary(), [
      row('2025-03-31', '12M', { totalRevenue: 9.64693e12, operatingIncome: 1.12462e12, netIncome: 6.9648e11, dilutedEPS: 51.47, totalDebt: 3.69575e12, stockholdersEquity: 8.432e12, operatingCashFlow: 1.78703e12, capitalExpenditure: -1.39967e12 }),
      row('2026-03-31', '12M', { totalRevenue: 1.057219e13, netIncomeCommonStockholders: 8.0775e11, netIncome: 1e9 }),
      row('2026-06-30', '3M', { totalRevenue: 3.09468e12 }),
      row('2024-03-31', '12M', { someOtherField: 5 }),
    ]);
    const { p, acquired } = provider(client);
    await p.getSnapshot(REF);
    const annual = await p.getStatements(REF, 'ANNUAL');
    expect(annual.reportingCurrency).toBe('INR');
    expect(annual.statements.map((s) => s.periodEnd)).toEqual(['2025-03-31', '2026-03-31']);
    expect(annual.statements[0]?.metrics).toEqual({ revenue: 9.64693e12, operatingProfit: 1.12462e12, netProfit: 6.9648e11, eps: 51.47, totalDebt: 3.69575e12, totalEquity: 8.432e12, cashFromOperations: 1.78703e12, capex: -1.39967e12 });
    expect(annual.statements[1]?.metrics.netProfit).toBe(8.0775e11);
    expect(client.calls.filter((c) => c.startsWith('summary'))).toHaveLength(1);
    expect(acquired()).toBe(2);
  });

  it('fetches the currency first when statements are requested without a snapshot', async () => {
    const client = new FakeClient(summary({ financialCurrency: 'USD' }), [row('2026-03-31', '12M', { totalRevenue: 2.0158e10 })]);
    const r = await provider(client).p.getStatements(REF, 'ANNUAL');
    expect(r.reportingCurrency).toBe('USD');
    expect(client.calls).toEqual(['summary:RELIANCE.NS', 'ts:annual']);
  });
});
```
`backend/tests/live/yahooFundamentals.live.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { createYahooFundamentalsClient } from '../../src/providers/fundamentals/yahoo/yahooFundamentalsClient.js';
import { YahooFundamentalsProvider } from '../../src/providers/fundamentals/yahoo/YahooFundamentalsProvider.js';
import { createYahooFinance } from '../../src/providers/yahoo/instance.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

// Network test against real Yahoo. Runs only via: pnpm --filter @learning-stocks/backend test:live
describe.skipIf(!process.env.LIVE_YAHOO)('Yahoo fundamentals live smoke', () => {
  const p = new YahooFundamentalsProvider(createYahooFundamentalsClient(createYahooFinance()), createRateLimiter({ ratePerSecond: 1, burst: 1 }));
  const ref = (s: string) => ({ providerSymbol: s, exchange: 'NSE' as const, kind: 'stock' as const });

  it('returns INR fundamentals for RELIANCE with percent units', async () => {
    const s = await p.getSnapshot(ref('RELIANCE.NS'));
    expect(s.reportingCurrency).toBe('INR');
    expect(s.metrics.pe).toBeGreaterThan(0);
    expect(s.metrics.marketCap).toBeGreaterThan(1e12);
    expect(s.metrics.dividendYield).toBeGreaterThan(0);
    expect(s.metrics.dividendYield).toBeLessThan(10);
    const annual = await p.getStatements(ref('RELIANCE.NS'), 'ANNUAL');
    expect(annual.statements.length).toBeGreaterThanOrEqual(3);
    expect(annual.statements.every((x) => x.periodEnd.endsWith('-03-31') && (x.metrics.revenue ?? 0) > 0)).toBe(true);
  });

  it('reports INFY statements in a non-INR currency (the reason for currency gating)', async () => {
    expect((await p.getSnapshot(ref('INFY.NS'))).reportingCurrency).not.toBe('INR');
  });
});
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (modules not found).

- [ ] **Step 3: Implement**

`backend/src/providers/yahoo/instance.ts`:
```ts
import YahooFinance from 'yahoo-finance2';

export type YahooFinanceInstance = InstanceType<typeof YahooFinance>;

/** One instance per process: market and fundamentals adapters share its session (cookie/crumb). */
export function createYahooFinance(): YahooFinanceInstance {
  return new YahooFinance({ suppressNotices: ['yahooSurvey'] });
}
```
In `yahooClient.ts`:
- replace `import YahooFinance from 'yahoo-finance2'` with `import { createYahooFinance, type YahooFinanceInstance } from '../../yahoo/instance.js'`
- change the signature to `export function createYahooClient(yf: YahooFinanceInstance = createYahooFinance()): YahooClient`
- delete the inner `new YahooFinance(...)`

Move `INDIAN_EXCHANGES` and `assertIndianListing` from `YahooMarketDataProvider.ts` into `market/yahoo/errors.ts` as `export function assertIndianListing(...)`, and import them in `YahooMarketDataProvider.ts`. The behaviour is unchanged; the existing tests keep passing.

`backend/src/providers/fundamentals/yahoo/yahooFundamentalsClient.ts`:
```ts
import type { YahooFinanceInstance } from '../../yahoo/instance.js';

/** Our narrow view of yahoo-finance2 fundamentals. Units exactly as Yahoo sends them (fractions, D/E in %). */
export interface YahooSummary {
  exchange: string | null;
  financialCurrency: string | null;
  marketCap: number | null;
  trailingPE: number | null;
  priceToBook: number | null;
  trailingEps: number | null;
  returnOnEquity: number | null;
  debtToEquity: number | null;
  dividendYield: number | null;
  operatingMargins: number | null;
  profitMargins: number | null;
  freeCashflow: number | null;
  totalRevenue: number | null;
  netIncomeToCommon: number | null;
  revenueGrowth: number | null;
  earningsGrowth: number | null;
  bookValue: number | null;
  beta: number | null;
}

export interface YahooStatementRow {
  date: Date;
  periodType: string | null;
  /** Every finite numeric field of the row (totalRevenue, dilutedEPS, …). */
  values: Record<string, number>;
}

export interface YahooFundamentalsClient {
  summary(symbol: string): Promise<YahooSummary>;
  timeSeries(symbol: string, type: 'annual' | 'quarterly', period1: Date): Promise<YahooStatementRow[]>;
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

export function createYahooFundamentalsClient(yf: YahooFinanceInstance): YahooFundamentalsClient {
  return {
    async summary(symbol) {
      const q = await yf.quoteSummary(symbol, { modules: ['price', 'summaryDetail', 'defaultKeyStatistics', 'financialData'] });
      const sd = q.summaryDetail;
      const ks = q.defaultKeyStatistics;
      const fd = q.financialData;
      return {
        exchange: q.price?.exchange ?? null,
        financialCurrency: fd?.financialCurrency ?? null,
        marketCap: num(q.price?.marketCap ?? sd?.marketCap),
        trailingPE: num(sd?.trailingPE),
        priceToBook: num(ks?.priceToBook),
        trailingEps: num(ks?.trailingEps),
        returnOnEquity: num(fd?.returnOnEquity),
        debtToEquity: num(fd?.debtToEquity),
        dividendYield: num(sd?.dividendYield),
        operatingMargins: num(fd?.operatingMargins),
        profitMargins: num(fd?.profitMargins ?? ks?.profitMargins),
        freeCashflow: num(fd?.freeCashflow),
        totalRevenue: num(fd?.totalRevenue),
        netIncomeToCommon: num(ks?.netIncomeToCommon),
        revenueGrowth: num(fd?.revenueGrowth),
        earningsGrowth: num(fd?.earningsGrowth),
        bookValue: num(ks?.bookValue),
        beta: num(sd?.beta ?? ks?.beta),
      };
    },
    async timeSeries(symbol, type, period1) {
      const rows = await yf.fundamentalsTimeSeries(symbol, { period1, type, module: 'all' });
      return rows.map((r) => {
        const record = r as Record<string, unknown>;
        const values: Record<string, number> = {};
        for (const [key, value] of Object.entries(record)) {
          const n = num(value);
          if (n !== null) values[key] = n;
        }
        const date = record.date instanceof Date ? record.date : new Date(String(record.date));
        return { date, periodType: typeof record.periodType === 'string' ? record.periodType : null, values };
      });
    },
  };
}
```
If yahoo-finance2's result types reject a property access, narrow inside this file only (`(q.financialData as Record<string, unknown> | undefined)?.…` through `num`) and record a ruling.

`backend/src/providers/fundamentals/yahoo/YahooFundamentalsProvider.ts`:
```ts
import {
  SNAPSHOT_FIELDS, type SnapshotMetrics, type StatementMetrics, type StatementPeriod,
} from '../../../domain/fundamentals.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import { assertIndianListing, mapYahooError } from '../../market/yahoo/errors.js';
import type { ProviderInstrumentRef } from '../../market/types.js';
import type {
  FundamentalsCapabilities, FundamentalsProvider, ProviderFundamentalSnapshot, ProviderStatements,
} from '../types.js';
import type { YahooFundamentalsClient, YahooSummary } from './yahooFundamentalsClient.js';

const DAY_MS = 86_400_000;
const CURRENCY_TTL_MS = 6 * 3_600_000;
const HISTORY_DAYS: Readonly<Record<StatementPeriod, number>> = { ANNUAL: 6 * 366, QUARTERLY: 3 * 366 };
const PERIOD_TYPE: Readonly<Record<StatementPeriod, string>> = { ANNUAL: '12M', QUARTERLY: '3M' };
const pct = (v: number | null): number | null => (v === null ? null : v * 100);

/** Unofficial Yahoo Finance fundamentals. Converts to our units (domain/fundamentals.ts); ROCE not provided. */
export class YahooFundamentalsProvider implements FundamentalsProvider {
  readonly name = 'yahoo';
  private readonly currencies = new Map<string, { currency: string | null; at: number }>();

  constructor(
    private readonly client: YahooFundamentalsClient,
    private readonly limiter: RateLimiter,
    private readonly now: () => Date = () => new Date(),
  ) {}

  capabilities(): FundamentalsCapabilities {
    return { fields: SNAPSHOT_FIELDS.filter((f) => f !== 'roce'), statementPeriods: ['QUARTERLY', 'ANNUAL'] };
  }

  async getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot> {
    const s = await this.summary(ref.providerSymbol);
    const metrics: SnapshotMetrics = {
      marketCap: s.marketCap,
      pe: s.trailingPE,
      pb: s.priceToBook,
      epsTtm: s.trailingEps,
      roe: pct(s.returnOnEquity),
      roce: null,
      debtToEquity: s.debtToEquity === null ? null : s.debtToEquity / 100,
      dividendYield: pct(s.dividendYield),
      operatingMargin: pct(s.operatingMargins),
      netMargin: pct(s.profitMargins),
      freeCashFlow: s.freeCashflow,
      revenueTtm: s.totalRevenue,
      netProfitTtm: s.netIncomeToCommon,
      revenueGrowthYoy: pct(s.revenueGrowth),
      profitGrowthYoy: pct(s.earningsGrowth),
      bookValuePerShare: s.bookValue,
      beta: s.beta,
    };
    return { asOf: this.now(), reportingCurrency: s.financialCurrency, metrics, raw: { ...s } };
  }

  async getStatements(ref: ProviderInstrumentRef, period: StatementPeriod): Promise<ProviderStatements> {
    const symbol = ref.providerSymbol;
    const reportingCurrency = await this.reportingCurrency(symbol);
    await this.limiter.acquire();
    let rows;
    try {
      rows = await this.client.timeSeries(
        symbol,
        period === 'ANNUAL' ? 'annual' : 'quarterly',
        new Date(this.now().getTime() - HISTORY_DAYS[period] * DAY_MS),
      );
    } catch (error) {
      throw mapYahooError(error, symbol);
    }
    const statements = rows
      .filter((r) => r.periodType === PERIOD_TYPE[period])
      .map((r) => {
        const v = r.values;
        const metrics: StatementMetrics = {
          revenue: v.totalRevenue ?? null,
          operatingProfit: v.operatingIncome ?? null,
          netProfit: v.netIncomeCommonStockholders ?? v.netIncome ?? null,
          eps: v.dilutedEPS ?? null,
          totalDebt: v.totalDebt ?? null,
          totalEquity: v.stockholdersEquity ?? null,
          cashFromOperations: v.operatingCashFlow ?? null,
          capex: v.capitalExpenditure ?? null,
        };
        return { periodType: period, periodEnd: r.date.toISOString().slice(0, 10), metrics, raw: { ...v } };
      })
      .filter((s) => Object.values(s.metrics).some((x) => x !== null));
    return { reportingCurrency, statements };
  }

  private async summary(symbol: string): Promise<YahooSummary> {
    await this.limiter.acquire();
    let s: YahooSummary;
    try {
      s = await this.client.summary(symbol);
    } catch (error) {
      throw mapYahooError(error, symbol);
    }
    assertIndianListing(s.exchange, symbol);
    this.currencies.set(symbol, { currency: s.financialCurrency, at: this.now().getTime() });
    return s;
  }

  private async reportingCurrency(symbol: string): Promise<string | null> {
    const cached = this.currencies.get(symbol);
    if (cached && this.now().getTime() - cached.at < CURRENCY_TTL_MS) return cached.currency;
    return (await this.summary(symbol)).financialCurrency;
  }
}
```

- [ ] **Step 4: Run the gate, then the live smoke test.** Expected: PASS; `test:live` all green (network).
- [ ] **Step 5: Commit** `feat(backend): Yahoo fundamentals provider with unit conversion and shared Yahoo instance`.

---

### Task 11: FundamentalsRepository + FundamentalsService (currency gating, upserts, run logging)

**Files:**
- Create: `backend/src/repositories/FundamentalsRepository.ts`, `backend/src/services/fundamentals/FundamentalsService.ts`
- Test: `backend/tests/integration/fundamentalsService.test.ts`

**Interfaces:**
- Consumes:
  - Task 9: domain records, contract, `fitMetrics`, `SNAPSHOT_COLUMNS`, `STATEMENT_COLUMNS`, `REPORTING_CURRENCY_FIELDS`
  - `ProviderSymbolRepository.listByProvider`, `StockRepository.findBySymbol`, `SystemLogRepository`
  - `withRetry`, `mapWithConcurrency`, `toAppError`, `toIst`
  - `InstrumentFailure` (from `MarketDataService.ts`)
- Produces:
  - `FundamentalsRepository`:
    - `upsertSnapshot(record): Promise<'inserted'|'updated'>`
    - `upsertStatements(records): Promise<{ inserted; updated }>`
    - `latestSnapshot(stockId, mode): Promise<FundamentalSnapshotRecord|null>`
    - `listStatements(stockId, mode, periodType, limit = 12): Promise<FinancialStatementRecord[]>` (newest first)
  - `FundamentalsSyncRequest { jobName; symbols?; includeStatements? }`
  - `FundamentalsSyncResult`
  - `class FundamentalsService { sync(request) }`

Run semantics:
- **Status:** `FAILED` if no stock succeeded; `PARTIAL` if any stock failed; else `SUCCESS`. Currency gating and out-of-range nulls are **notes**.
- **Counts:**
  - `fetched` = snapshots + statement rows received
  - `inserted` = new rows
  - `skipped` = refreshed rows + statement rows skipped as non-INR
  - `failed` = failed stocks
- **Only stocks are synced.** Requested index symbols are noted.

- [ ] **Step 1: Write the failing test** `backend/tests/integration/fundamentalsService.test.ts`

```ts
import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import type { StatementPeriod } from '../../src/domain/fundamentals.js';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';
import type { FundamentalsProvider, ProviderFundamentalSnapshot, ProviderStatements } from '../../src/providers/fundamentals/types.js';
import type { ProviderInstrumentRef } from '../../src/providers/market/types.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { FundamentalsService } from '../../src/services/fundamentals/FundamentalsService.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({ level: 'silent', destination: new Writable({ write(_c, _e, cb) { cb(); } }) });
const NOW = new Date('2026-10-05T20:00:00Z'); // IST 2026-10-06 01:30

/** Wraps the mock; per symbol it can throw, report another currency, or patch snapshot metrics. */
class StubFundamentals implements FundamentalsProvider {
  readonly name = 'mock';
  constructor(private readonly inner: FundamentalsProvider, private readonly over: {
    fail?: Record<string, AppError>; currency?: Record<string, string>; patch?: Record<string, Partial<ProviderFundamentalSnapshot['metrics']>>;
  }) {}
  capabilities() { return this.inner.capabilities(); }
  async getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot> {
    const f = this.over.fail?.[ref.providerSymbol];
    if (f) throw f;
    const s = await this.inner.getSnapshot(ref);
    return { ...s, reportingCurrency: this.over.currency?.[ref.providerSymbol] ?? s.reportingCurrency, metrics: { ...s.metrics, ...this.over.patch?.[ref.providerSymbol] } };
  }
  async getStatements(ref: ProviderInstrumentRef, period: StatementPeriod): Promise<ProviderStatements> {
    const s = await this.inner.getStatements(ref, period);
    return { ...s, reportingCurrency: this.over.currency?.[ref.providerSymbol] ?? s.reportingCurrency };
  }
}

function build(trx: Database, wrap: (m: FundamentalsProvider) => FundamentalsProvider = (m) => m) {
  const provider = wrap(new MockFundamentalsProvider(async () => 1000, () => NOW));
  return new FundamentalsService({
    provider, dataMode: 'MOCK', logger: silent, now: () => NOW, retry: { sleep: async () => undefined },
    providerSymbols: new ProviderSymbolRepository(trx), stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx), systemLogs: new SystemLogRepository(trx),
  });
}
const idOf = async (trx: Database, symbol: string) => (await new StockRepository(trx).findBySymbol(symbol))?.id ?? '';

describe('FundamentalsService', () => {
  it('stores snapshots (IST as_of) and statements, and refreshes them on a same-day re-run', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const first = await build(trx).sync({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'] });
      expect(first).toMatchObject({ status: 'SUCCESS', asOf: '2026-10-06', stocks: { total: 2, succeeded: 2, failed: 0 }, snapshots: { inserted: 2, updated: 0 }, statements: { inserted: 26, updated: 0, skipped: 0 } });

      const repo = new FundamentalsRepository(trx);
      const reliance = await repo.latestSnapshot(await idOf(trx, 'RELIANCE'), 'MOCK');
      expect(reliance).toMatchObject({ asOf: '2026-10-06', source: 'mock', raw: { mock: true } });
      expect((reliance?.metrics.pe ?? 0) * (reliance?.metrics.epsTtm ?? 0)).toBeCloseTo(1000, -1);
      expect((await repo.latestSnapshot(await idOf(trx, 'HDFCBANK'), 'MOCK'))?.metrics.debtToEquity).toBeNull();
      const annual = await repo.listStatements(await idOf(trx, 'RELIANCE'), 'MOCK', 'ANNUAL');
      expect(annual.map((s) => s.periodEnd)).toEqual(['2026-03-31', '2025-03-31', '2024-03-31', '2023-03-31', '2022-03-31']);

      const again = await build(trx).sync({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'] });
      expect(again).toMatchObject({ snapshots: { inserted: 0, updated: 2 }, statements: { inserted: 0, updated: 26 } });
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({ id: again.runId, status: 'SUCCESS', operation: 'sync:fundamentals', recordsInserted: 0, recordsSkipped: 28 });
    });
  });

  it('leaves absolute amounts empty and skips statements for a non-INR reporter, without failing', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const r = await build(trx, (m) => new StubFundamentals(m, { currency: { INFY: 'USD' } })).sync({ jobName: 'test', symbols: ['INFY'] });
      expect(r).toMatchObject({ status: 'SUCCESS', statements: { inserted: 0, skipped: 13 } });
      expect(r.notes.join(' ')).toMatch(/INFY.*USD/);
      const snap = await new FundamentalsRepository(trx).latestSnapshot(await idOf(trx, 'INFY'), 'MOCK');
      expect(snap?.metrics).toMatchObject({ revenueTtm: null, netProfitTtm: null, freeCashFlow: null });
      expect(snap?.metrics.pe).toBeGreaterThan(0);
      expect(await new FundamentalsRepository(trx).listStatements(await idOf(trx, 'INFY'), 'MOCK', 'ANNUAL')).toEqual([]);
    });
  });

  it('stores out-of-range and non-finite values as null with a note', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const r = await build(trx, (m) => new StubFundamentals(m, { patch: { TCS: { pe: 1e12, beta: Number.NaN } } })).sync({ jobName: 'test', symbols: ['TCS'], includeStatements: false });
      expect(r.status).toBe('SUCCESS');
      expect(r.notes.join(' ')).toMatch(/TCS.*pe.*beta|TCS.*beta.*pe/);
      expect((await new FundamentalsRepository(trx).latestSnapshot(await idOf(trx, 'TCS'), 'MOCK'))?.metrics).toMatchObject({ pe: null, beta: null });
    });
  });

  it('isolates a failing stock (PARTIAL) and ignores index symbols with a note', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const r = await build(trx, (m) => new StubFundamentals(m, { fail: { TCS: new AppError('UNSUPPORTED', 'no data') } }))
        .sync({ jobName: 'test', symbols: ['RELIANCE', 'TCS', 'NIFTY50'], includeStatements: false });
      expect(r.status).toBe('PARTIAL');
      expect(r.stocks).toEqual({ total: 2, succeeded: 1, failed: 1 });
      expect(r.failures).toEqual([expect.objectContaining({ symbol: 'TCS', code: 'UNSUPPORTED' })]);
      expect(r.notes.join(' ')).toMatch(/NIFTY50/);
    });
  });
});
```
Check the statement count: each stock gets 8 quarters plus 5 years, so two stocks give 26 rows.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/repositories/FundamentalsRepository.ts`

```ts
import { sql } from 'kysely';
import type { Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type { DataMode } from '../domain/enums.js';
import type {
  FinancialStatementRecord, FundamentalSnapshotRecord, SnapshotMetrics, StatementMetrics, StatementPeriod,
} from '../domain/fundamentals.js';

const CHUNK = 200;

const snapshotColumns = (m: SnapshotMetrics) => ({
  market_cap: m.marketCap, pe: m.pe, pb: m.pb, eps_ttm: m.epsTtm, roe: m.roe, roce: m.roce,
  debt_to_equity: m.debtToEquity, dividend_yield: m.dividendYield, operating_margin: m.operatingMargin,
  net_margin: m.netMargin, free_cash_flow: m.freeCashFlow, revenue_ttm: m.revenueTtm, net_profit_ttm: m.netProfitTtm,
  revenue_growth_yoy: m.revenueGrowthYoy, profit_growth_yoy: m.profitGrowthYoy,
  book_value_per_share: m.bookValuePerShare, beta: m.beta,
});

const statementColumns = (m: StatementMetrics) => ({
  revenue: m.revenue, operating_profit: m.operatingProfit, net_profit: m.netProfit, eps: m.eps,
  total_debt: m.totalDebt, total_equity: m.totalEquity, cash_from_operations: m.cashFromOperations, capex: m.capex,
});

const jsonb = (value: Record<string, unknown>) => sql<string>`${JSON.stringify(value)}::jsonb`;
const asRecord = (value: unknown): Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

function mapSnapshot(r: Selectable<DB['fundamental_snapshots']>): FundamentalSnapshotRecord {
  return {
    stockId: r.stock_id, dataMode: r.data_mode, asOf: r.as_of, source: r.source, raw: asRecord(r.raw),
    metrics: {
      marketCap: toNumber(r.market_cap), pe: toNumber(r.pe), pb: toNumber(r.pb), epsTtm: toNumber(r.eps_ttm),
      roe: toNumber(r.roe), roce: toNumber(r.roce), debtToEquity: toNumber(r.debt_to_equity),
      dividendYield: toNumber(r.dividend_yield), operatingMargin: toNumber(r.operating_margin),
      netMargin: toNumber(r.net_margin), freeCashFlow: toNumber(r.free_cash_flow), revenueTtm: toNumber(r.revenue_ttm),
      netProfitTtm: toNumber(r.net_profit_ttm), revenueGrowthYoy: toNumber(r.revenue_growth_yoy),
      profitGrowthYoy: toNumber(r.profit_growth_yoy), bookValuePerShare: toNumber(r.book_value_per_share), beta: toNumber(r.beta),
    },
  };
}

function mapStatement(r: Selectable<DB['financial_statements']>): FinancialStatementRecord {
  return {
    stockId: r.stock_id, dataMode: r.data_mode, periodType: r.period_type as StatementPeriod, periodEnd: r.period_end,
    source: r.source, raw: asRecord(r.raw),
    metrics: {
      revenue: toNumber(r.revenue), operatingProfit: toNumber(r.operating_profit), netProfit: toNumber(r.net_profit),
      eps: toNumber(r.eps), totalDebt: toNumber(r.total_debt), totalEquity: toNumber(r.total_equity),
      cashFromOperations: toNumber(r.cash_from_operations), capex: toNumber(r.capex),
    },
  };
}

/** Fundamentals are refreshed in place: one snapshot per stock per IST day; statements are restated. */
export class FundamentalsRepository {
  constructor(private readonly db: Database) {}

  async upsertSnapshot(r: FundamentalSnapshotRecord): Promise<'inserted' | 'updated'> {
    const columns = snapshotColumns(r.metrics);
    const row = await this.db
      .insertInto('fundamental_snapshots')
      .values({ stock_id: r.stockId, data_mode: r.dataMode, as_of: r.asOf, source: r.source, ...columns, raw: jsonb(r.raw) })
      .onConflict((oc) => oc.columns(['stock_id', 'data_mode', 'as_of', 'source']).doUpdateSet({ ...columns, raw: jsonb(r.raw) }))
      .returning(sql<boolean>`(xmax = 0)`.as('inserted'))
      .executeTakeFirstOrThrow();
    return row.inserted ? 'inserted' : 'updated';
  }

  async upsertStatements(records: readonly FinancialStatementRecord[]): Promise<{ inserted: number; updated: number }> {
    // ON CONFLICT DO UPDATE cannot touch one row twice in a statement: last record per key wins.
    const unique = new Map<string, FinancialStatementRecord>();
    for (const r of records) unique.set(`${r.stockId}|${r.dataMode}|${r.periodType}|${r.periodEnd}|${r.source}`, r);
    const rows = [...unique.values()];
    let inserted = 0;
    let updated = 0;
    for (let i = 0; i < rows.length; i += CHUNK) {
      const result = await this.db
        .insertInto('financial_statements')
        .values(rows.slice(i, i + CHUNK).map((r) => ({
          stock_id: r.stockId, data_mode: r.dataMode, period_type: r.periodType, period_end: r.periodEnd,
          source: r.source, ...statementColumns(r.metrics), raw: jsonb(r.raw),
        })))
        .onConflict((oc) => oc.columns(['stock_id', 'data_mode', 'period_type', 'period_end', 'source']).doUpdateSet((eb) => ({
          revenue: eb.ref('excluded.revenue'),
          operating_profit: eb.ref('excluded.operating_profit'),
          net_profit: eb.ref('excluded.net_profit'),
          eps: eb.ref('excluded.eps'),
          total_debt: eb.ref('excluded.total_debt'),
          total_equity: eb.ref('excluded.total_equity'),
          cash_from_operations: eb.ref('excluded.cash_from_operations'),
          capex: eb.ref('excluded.capex'),
          raw: eb.ref('excluded.raw'),
        })))
        .returning(sql<boolean>`(xmax = 0)`.as('inserted'))
        .execute();
      for (const r of result) {
        if (r.inserted) inserted += 1;
        else updated += 1;
      }
    }
    return { inserted, updated };
  }

  async latestSnapshot(stockId: string, mode: DataMode): Promise<FundamentalSnapshotRecord | null> {
    const row = await this.db.selectFrom('fundamental_snapshots').selectAll()
      .where('stock_id', '=', stockId).where('data_mode', '=', mode)
      .orderBy('as_of', 'desc').orderBy('created_at', 'desc').limit(1).executeTakeFirst();
    return row ? mapSnapshot(row) : null;
  }

  async listStatements(stockId: string, mode: DataMode, periodType: StatementPeriod, limit = 12): Promise<FinancialStatementRecord[]> {
    const rows = await this.db.selectFrom('financial_statements').selectAll()
      .where('stock_id', '=', stockId).where('data_mode', '=', mode).where('period_type', '=', periodType)
      .orderBy('period_end', 'desc').limit(Math.min(Math.max(limit, 1), 40)).execute();
    return rows.map(mapStatement);
  }
}
```
`backend/src/services/fundamentals/FundamentalsService.ts`:
```ts
import type { Logger } from 'pino';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import { REPORTING_CURRENCY_FIELDS, type SnapshotMetrics } from '../../domain/fundamentals.js';
import type { FundamentalsProvider } from '../../providers/fundamentals/types.js';
import type { ProviderInstrumentRef } from '../../providers/market/types.js';
import type { FundamentalsRepository } from '../../repositories/FundamentalsRepository.js';
import type { ProviderSymbolEntry, ProviderSymbolRepository } from '../../repositories/ProviderSymbolRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { mapWithConcurrency } from '../../utils/concurrency.js';
import { AppError, toAppError } from '../../utils/errors.js';
import { toIst } from '../../utils/ist.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import type { InstrumentFailure } from '../marketData/MarketDataService.js';
import { fitMetrics, SNAPSHOT_COLUMNS, STATEMENT_COLUMNS } from './numeric.js';

const HOME_CURRENCY = 'INR';

export interface FundamentalsSyncRequest {
  jobName: string;
  symbols?: readonly string[];
  includeStatements?: boolean;
}

export interface FundamentalsSyncResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  dataMode: DataMode;
  asOf: string;
  stocks: { total: number; succeeded: number; failed: number };
  snapshots: { inserted: number; updated: number };
  /** skipped = statement rows not stored because they were reported in a non-INR currency. */
  statements: { inserted: number; updated: number; skipped: number };
  failures: InstrumentFailure[];
  notes: string[];
}

export interface FundamentalsServiceDeps {
  provider: FundamentalsProvider;
  providerSymbols: ProviderSymbolRepository;
  stocks: StockRepository;
  fundamentals: FundamentalsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  retry?: RetryOptions;
  concurrency?: number;
}

export class FundamentalsService {
  private readonly now: () => Date;

  constructor(private readonly deps: FundamentalsServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async sync(request: FundamentalsSyncRequest): Promise<FundamentalsSyncResult> {
    const { provider, systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({ service: 'FundamentalsService', jobName: request.jobName, operation: 'sync:fundamentals' });
    const result: FundamentalsSyncResult = {
      runId, status: 'SUCCESS', provider: provider.name, dataMode: this.deps.dataMode, asOf: toIst(now).date,
      stocks: { total: 0, succeeded: 0, failed: 0 }, snapshots: { inserted: 0, updated: 0 },
      statements: { inserted: 0, updated: 0, skipped: 0 }, failures: [], notes: [],
    };
    let fetched = 0;
    let runError: unknown;

    try {
      const entries = (await this.deps.providerSymbols.listByProvider(provider.name, request.symbols)).filter((e) => e.kind === 'stock');
      if (request.symbols) {
        const found = new Set(entries.map((e) => e.symbol));
        const missing = request.symbols.map((s) => s.trim().toUpperCase()).filter((s) => s && !found.has(s));
        if (missing.length > 0) result.notes.push(`no fundamentals for indices or unknown symbols: ${missing.join(', ')}`);
      }
      result.stocks.total = entries.length;
      if (entries.length === 0) throw new AppError('VALIDATION', 'No stocks to sync');

      await mapWithConcurrency(entries, this.deps.concurrency ?? 2, async (entry) => {
        try {
          fetched += await this.syncStock(entry, request, result);
          result.stocks.succeeded += 1;
        } catch (error) {
          const e = toAppError(error);
          result.failures.push({ symbol: entry.symbol, providerSymbol: entry.providerSymbol, code: e.code, message: e.message });
          logger.warn({ symbol: entry.symbol, code: e.code }, 'fundamentals sync failed for stock');
        }
      });
      result.stocks.failed = result.failures.length;
      result.status = result.stocks.succeeded === 0 ? 'FAILED' : result.failures.length > 0 ? 'PARTIAL' : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched,
          inserted: result.snapshots.inserted + result.statements.inserted,
          skipped: result.snapshots.updated + result.statements.updated + result.statements.skipped,
          failed: result.stocks.failed,
        },
        message: this.summary(result),
        ...(runError === undefined ? {} : { error: runError }),
        details: { failures: result.failures, notes: result.notes, provider: provider.name, snapshots: result.snapshots, statements: result.statements },
      });
    }
    logger.info({ runId, status: result.status, stocks: result.stocks }, 'fundamentals sync finished');
    return result;
  }

  /** Returns the number of records fetched for this stock. */
  private async syncStock(entry: ProviderSymbolEntry, request: FundamentalsSyncRequest, result: FundamentalsSyncResult): Promise<number> {
    const { provider, fundamentals, dataMode } = this.deps;
    const stock = await this.deps.stocks.findBySymbol(entry.symbol, entry.exchange);
    if (!stock) throw new AppError('NOT_FOUND', `Stock ${entry.symbol} not found`);
    const ref: ProviderInstrumentRef = { providerSymbol: entry.providerSymbol, exchange: entry.exchange, kind: 'stock' };

    const snapshot = await withRetry(() => provider.getSnapshot(ref), this.deps.retry);
    let fetched = 1;
    const metrics: SnapshotMetrics = { ...snapshot.metrics };
    if (snapshot.reportingCurrency !== HOME_CURRENCY) {
      for (const field of REPORTING_CURRENCY_FIELDS) metrics[field] = null;
      result.notes.push(`${entry.symbol}: financials reported in ${snapshot.reportingCurrency ?? 'an unknown currency'}; revenue, profit and cash-flow amounts left empty`);
    }
    const fitted = fitMetrics(metrics, SNAPSHOT_COLUMNS);
    if (fitted.outOfRange.length > 0) result.notes.push(`${entry.symbol}: out-of-range values stored as null: ${fitted.outOfRange.join(', ')}`);
    const outcome = await fundamentals.upsertSnapshot({
      stockId: stock.id, dataMode, asOf: toIst(snapshot.asOf).date, source: provider.name, metrics: fitted.metrics, raw: snapshot.raw,
    });
    result.snapshots[outcome] += 1;

    if (request.includeStatements === false) return fetched;
    for (const period of provider.capabilities().statementPeriods) {
      const res = await withRetry(() => provider.getStatements(ref, period), this.deps.retry);
      fetched += res.statements.length;
      if (res.reportingCurrency !== HOME_CURRENCY) {
        result.statements.skipped += res.statements.length;
        if (res.statements.length > 0) result.notes.push(`${entry.symbol}: ${res.statements.length} ${period.toLowerCase()} statements in ${res.reportingCurrency ?? 'an unknown currency'} skipped`);
        continue;
      }
      const records = res.statements.map((s) => {
        const f = fitMetrics(s.metrics, STATEMENT_COLUMNS);
        if (f.outOfRange.length > 0) result.notes.push(`${entry.symbol} ${s.periodEnd}: out-of-range values stored as null: ${f.outOfRange.join(', ')}`);
        return { stockId: stock.id, dataMode, periodType: s.periodType, periodEnd: s.periodEnd, source: provider.name, metrics: f.metrics, raw: s.raw };
      });
      const { inserted, updated } = await fundamentals.upsertStatements(records);
      result.statements.inserted += inserted;
      result.statements.updated += updated;
    }
    return fetched;
  }

  private summary(r: FundamentalsSyncResult): string {
    const failed = r.failures.map((f) => `${f.symbol} (${f.code})`).join(', ');
    return `${r.stocks.succeeded}/${r.stocks.total} stocks ok; snapshots ${r.snapshots.inserted} new, ${r.snapshots.updated} refreshed; ` +
      `statements ${r.statements.inserted} new, ${r.statements.updated} refreshed, ${r.statements.skipped} skipped (non-INR)` +
      (failed ? `; failed: ${failed}` : '');
  }
}
```
Note: the INFY test expects `skipped: 13`. That holds because the stub keeps returning all 13 mock statements while reporting them as USD.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): fundamentals repository and service with INR gating, upserts and run logging`.

---

### Task 12: Provider factory, container wiring, CLIs

**Files:**
- Create: `backend/src/cli/sync-news.ts`, `backend/src/cli/sync-fundamentals.ts`
- Modify:
  - `backend/src/providers/factory.ts` (`createProviders`)
  - `backend/src/container.ts`
  - `backend/package.json` and root `package.json` (scripts)
  - `.env.example` (provider comments)
- Test: `backend/tests/integration/container.test.ts` (new cases)

**Interfaces:**
- Produces:
  - `Providers { marketData; news: NewsProvider | null; fundamentals: FundamentalsProvider | null }`
  - `createProviders(config, { sessions }): Providers`, which replaces `createMarketDataProvider`. Yahoo adapters share one instance and one 2 req/s limiter.
  - `Container.repositories.news` and `.fundamentals`
  - `Container.providers: Providers`
  - `Container.services.news: NewsService | null` and `.fundamentals: FundamentalsService | null`
  - `ContainerOverrides.newsProvider?` and `.fundamentalsProvider?` (`… | null`)

- [ ] **Step 1: Write the failing tests.** Append to `backend/tests/integration/container.test.ts`:

```ts
  const live = (over: Record<string, string>) =>
    loadConfig({ MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo', NEWS_PROVIDER: 'none', FUNDAMENTALS_PROVIDER: 'none', LLM_PROVIDER: 'none', ...over });

  it('wires mock news and fundamentals in mock mode', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.providers.news?.name).toBe('mock');
    expect(c.providers.fundamentals?.name).toBe('mock');
    expect(c.services.news).not.toBeNull();
    expect(c.services.fundamentals).not.toBeNull();
    await c.close();
  });

  it("disables news and fundamentals with 'none'", async () => {
    const c = createContainer(live({}), { logger: silent });
    expect(c.providers.news).toBeNull();
    expect(c.services.news).toBeNull();
    expect(c.services.fundamentals).toBeNull();
    await c.close();
  });

  it('wires real adapters in live mode (no network at construction)', async () => {
    const rss = createContainer(live({ NEWS_PROVIDER: 'rss', FUNDAMENTALS_PROVIDER: 'yahoo' }), { logger: silent });
    expect(rss.providers.news?.name).toBe('rss');
    expect(rss.providers.fundamentals?.name).toBe('yahoo');
    await rss.close();
    const newsapi = createContainer(live({ NEWS_PROVIDER: 'newsapi', NEWS_API_KEY: 'k' }), { logger: silent });
    expect(newsapi.providers.news?.capabilities()).toEqual({ maxInstrumentsPerQuery: 10, latency: 'delayed' });
    await newsapi.close();
  });
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (`providers.news` undefined).

- [ ] **Step 3: Implement** `backend/src/providers/factory.ts` (replace the file)

```ts
import type { AppConfig } from '../config/env.js';
import type { TradingSessions } from '../domain/types.js';
import { AppError } from '../utils/errors.js';
import { createRateLimiter, type RateLimiter } from '../utils/rateLimiter.js';
import { MockFundamentalsProvider } from './fundamentals/mock/MockFundamentalsProvider.js';
import type { FundamentalsProvider } from './fundamentals/types.js';
import { createYahooFundamentalsClient } from './fundamentals/yahoo/yahooFundamentalsClient.js';
import { YahooFundamentalsProvider } from './fundamentals/yahoo/YahooFundamentalsProvider.js';
import { MockMarketDataProvider } from './market/mock/MockMarketDataProvider.js';
import type { MarketDataProvider } from './market/types.js';
import { createYahooClient } from './market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from './market/yahoo/YahooMarketDataProvider.js';
import { MockNewsProvider } from './news/mock/MockNewsProvider.js';
import { NewsApiProvider } from './news/newsapi/NewsApiProvider.js';
import { RssNewsProvider } from './news/rss/RssNewsProvider.js';
import type { NewsProvider } from './news/types.js';
import { createYahooFinance, type YahooFinanceInstance } from './yahoo/instance.js';

export interface Providers {
  marketData: MarketDataProvider;
  /** null = feature disabled (NEWS_PROVIDER=none). */
  news: NewsProvider | null;
  fundamentals: FundamentalsProvider | null;
}

/** The only place adapters are chosen. Yahoo adapters share one client session and one 2 req/s budget. */
export function createProviders(config: AppConfig, deps: { sessions: TradingSessions }): Providers {
  let yahoo: { yf: YahooFinanceInstance; limiter: RateLimiter } | undefined;
  const sharedYahoo = () => (yahoo ??= { yf: createYahooFinance(), limiter: createRateLimiter({ ratePerSecond: 2, burst: 2 }) });

  let marketData: MarketDataProvider;
  switch (config.providers.marketData) {
    case 'mock':
      marketData = new MockMarketDataProvider(deps.sessions);
      break;
    case 'yahoo':
      marketData = new YahooMarketDataProvider(createYahooClient(sharedYahoo().yf), sharedYahoo().limiter);
      break;
  }

  let news: NewsProvider | null;
  switch (config.providers.news) {
    case 'mock':
      news = new MockNewsProvider();
      break;
    case 'rss':
      news = new RssNewsProvider(createRateLimiter({ ratePerSecond: 1, burst: 2 }));
      break;
    case 'newsapi': {
      const key = config.secrets.newsApiKey;
      if (!key) throw new AppError('INTERNAL', 'NEWS_API_KEY is required for NEWS_PROVIDER=newsapi');
      news = new NewsApiProvider(key, createRateLimiter({ ratePerSecond: 1, burst: 1 }));
      break;
    }
    case 'none':
      news = null;
      break;
  }

  let fundamentals: FundamentalsProvider | null;
  switch (config.providers.fundamentals) {
    case 'mock':
      // Mock P/E and P/B use the mock market price, so MOCK valuation stays internally consistent.
      fundamentals = new MockFundamentalsProvider(async (ref) => {
        try {
          return (await marketData.getQuote(ref)).price;
        } catch {
          return null;
        }
      });
      break;
    case 'yahoo':
      fundamentals = new YahooFundamentalsProvider(createYahooFundamentalsClient(sharedYahoo().yf), sharedYahoo().limiter);
      break;
    case 'none':
      fundamentals = null;
      break;
  }

  return { marketData, news, fundamentals };
}
```
In `backend/src/container.ts`:
- Import `createProviders`/`Providers` (in place of `createMarketDataProvider`), `NewsProvider`, `FundamentalsProvider`, `NewsRepository`, `FundamentalsRepository`, `NewsService` and `FundamentalsService`.
- Change the `Container` interface:
  - `providers: Providers;`
  - `repositories` gains `news: NewsRepository; fundamentals: FundamentalsRepository;`
  - `services` gains `news: NewsService | null; fundamentals: FundamentalsService | null;`
- `ContainerOverrides` gains `newsProvider?: NewsProvider | null; fundamentalsProvider?: FundamentalsProvider | null;`
- In `createContainer`, add `news: new NewsRepository(db), fundamentals: new FundamentalsRepository(db)` to `repositories`, and replace the provider block:
```ts
  const built = createProviders(config, { sessions: calendar });
  const providers: Providers = {
    marketData: overrides.marketDataProvider ?? built.marketData,
    news: overrides.newsProvider !== undefined ? overrides.newsProvider : built.news,
    fundamentals: overrides.fundamentalsProvider !== undefined ? overrides.fundamentalsProvider : built.fundamentals,
  };
  const marketDataProvider = providers.marketData;
```
- Return `providers`, and in `services` add:
```ts
      news: providers.news
        ? new NewsService({
            provider: providers.news, stocks: repositories.stocks, markets: repositories.markets,
            news: repositories.news, systemLogs: repositories.systemLogs, dataMode: config.dataMode, logger,
          })
        : null,
      fundamentals: providers.fundamentals
        ? new FundamentalsService({
            provider: providers.fundamentals, providerSymbols: repositories.providerSymbols, stocks: repositories.stocks,
            fundamentals: repositories.fundamentals, systemLogs: repositories.systemLogs, dataMode: config.dataMode, logger,
          })
        : null,
```
`FundamentalsService` resolves instruments through `provider_symbols` rows for `provider.name`. Seeds have `mock` and `yahoo` rows, so both adapters resolve.

`backend/src/cli/sync-news.ts`:
```ts
import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

const DAY_MS = 86_400_000;

function usage(message: string): never {
  console.error(`${message}\nUsage: pnpm sync:news [--days 1-30] [--symbols RELIANCE,TCS] [--no-market] [--limit 1-100]`);
  process.exit(2);
}

loadDotEnv();
const { values } = parseArgs({
  options: {
    days: { type: 'string', default: '2' },
    symbols: { type: 'string' },
    'no-market': { type: 'boolean', default: false },
    limit: { type: 'string', default: '50' },
  },
});
const days = Number(values.days);
if (!Number.isInteger(days) || days < 1 || days > 30) usage('--days must be a whole number from 1 to 30');
const limit = Number(values.limit);
if (!Number.isInteger(limit) || limit < 1 || limit > 100) usage('--limit must be a whole number from 1 to 100');

const container = createContainer(readConfigOrExit(process.env));
try {
  const service = container.services.news;
  if (!service) {
    console.log('News is disabled (NEWS_PROVIDER=none). Nothing to do.');
  } else {
    const r = await service.sync({
      jobName: 'cli.sync-news',
      since: new Date(Date.now() - days * DAY_MS),
      ...(values.symbols ? { symbols: values.symbols.split(',').map((s) => s.trim()).filter(Boolean) } : {}),
      includeMarket: !values['no-market'],
      perQueryLimit: limit,
    });
    console.log(`[${r.dataMode}] ${r.provider} news sync: ${r.status}`);
    console.log(`  queries: ${r.queries.succeeded}/${r.queries.total} ok`);
    console.log(`  articles: fetched ${r.articles.fetched}, new ${r.articles.new}, already stored ${r.articles.existing}, dropped ${r.articles.dropped}`);
    console.log(`  mentions saved: ${r.mentions}`);
    for (const f of r.failures) console.log(`  FAILED ${f.source}: ${f.code} ${f.message}`);
    for (const n of r.notes) console.log(`  note: ${n}`);
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
```
`backend/src/cli/sync-fundamentals.ts`:
```ts
import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const { values } = parseArgs({
  options: { symbols: { type: 'string' }, 'no-statements': { type: 'boolean', default: false } },
});

const container = createContainer(readConfigOrExit(process.env));
try {
  const service = container.services.fundamentals;
  if (!service) {
    console.log('Fundamentals are disabled (FUNDAMENTALS_PROVIDER=none). Nothing to do.');
  } else {
    const r = await service.sync({
      jobName: 'cli.sync-fundamentals',
      ...(values.symbols ? { symbols: values.symbols.split(',').map((s) => s.trim()).filter(Boolean) } : {}),
      includeStatements: !values['no-statements'],
    });
    console.log(`[${r.dataMode}] ${r.provider} fundamentals sync (as of ${r.asOf} IST): ${r.status}`);
    console.log(`  stocks: ${r.stocks.succeeded}/${r.stocks.total} ok`);
    console.log(`  snapshots: new ${r.snapshots.inserted}, refreshed ${r.snapshots.updated}`);
    console.log(`  statements: new ${r.statements.inserted}, refreshed ${r.statements.updated}, skipped (non-INR) ${r.statements.skipped}`);
    for (const f of r.failures) console.log(`  FAILED ${f.symbol} (${f.providerSymbol}): ${f.code} ${f.message}`);
    for (const n of r.notes) console.log(`  note: ${n}`);
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
```
Scripts:
- backend: `"sync:news": "tsx src/cli/sync-news.ts"` and `"sync:fundamentals": "tsx src/cli/sync-fundamentals.ts"`
- root: `"sync:news": "pnpm --filter @learning-stocks/backend sync:news"` and `"sync:fundamentals": "pnpm --filter @learning-stocks/backend sync:fundamentals"`

In `.env.example`, replace the two provider comments:
```
# mock | rss (Google News search + ET/Mint/Business Standard feeds; personal use) | newsapi (free tier: 100 req/day, 24 h delay) | none
NEWS_PROVIDER=mock
# mock | yahoo (unofficial; ROCE not provided) | none
FUNDAMENTALS_PROVIDER=mock
```

- [ ] **Step 4: Run the gate, then real mock runs**

Run the gate. Expected: PASS.
```bash
pnpm sync:news --days 7          # [MOCK] mock news sync: SUCCESS, 21/21 queries ok
pnpm sync:news --days 7          # new 0, all already stored
pnpm sync:fundamentals           # [MOCK] … SUCCESS, 20/20 stocks, 20 snapshots, 260 statements
```

- [ ] **Step 5: Commit** `feat(backend): wire news and fundamentals providers; sync:news and sync:fundamentals CLIs`.

---

### Task 13: Docs + Phase 4 verification

**Files:** Modify `README.md`, `docs/architecture.md`, `docs/database.md`, `IMPLEMENTATION_PLAN.md`.

- [ ] **Step 1: Docs**
  - **README:**
    - Update the status table (Phase 4 ✅).
    - Add a "Load news and fundamentals" section:
      - mock commands
      - live `MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=rss FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm sync:news --days 3 --symbols RELIANCE,HDFCBANK`
      - `pnpm sync:fundamentals --symbols RELIANCE,HDFCBANK,INFY`
    - Known limitations:
      - INFY-style USD reporters
      - no ROCE from Yahoo
      - Google redirect links
      - NewsAPI free-tier quota and delay
      - RSS for personal use only
    - Two SQL queries for Studio: latest news per stock with relevance, and the latest snapshot per stock.
  - **`docs/architecture.md`:** a "News and fundamentals providers" section covering:
    - the contracts
    - the normalizer drop reasons table
    - the dedupe key (deviation 4)
    - the mention matching rules and weights from Task 3
    - per-query/per-feed isolation and run counts
    - the units convention and currency gating
  - **`docs/database.md`:**
    - the aliases columns and seed (owner to verify)
    - units per fundamentals column
    - upsert semantics (snapshots one per IST day, statements restated, news insert-only with two-key dedupe, mentions keep the max relevance)
  - **IMPLEMENTATION_PLAN.md:** Phase 4 ✅ with a link to this plan.

- [ ] **Step 2: Full verification**

```bash
pnpm db:reset && pnpm db:test                         # 118/118
pnpm typecheck && pnpm test && pnpm lint && pnpm format:check && pnpm --filter @learning-stocks/backend build
pnpm --filter @learning-stocks/backend test:live      # Yahoo market + fundamentals + RSS (network)
pnpm sync:market && pnpm sync:news --days 7 && pnpm sync:news --days 7 && pnpm sync:fundamentals
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=rss FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none \
  pnpm sync:news --days 3 --symbols RELIANCE,HDFCBANK,INFY
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=rss FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none \
  pnpm sync:fundamentals --symbols RELIANCE,HDFCBANK,INFY
```
Expected:
- **Mock:** both syncs succeed, and the second news run inserts nothing.
- **Live news:** `[LIVE] rss news sync: SUCCESS` (or PARTIAL naming a blocked feed). RELIANCE and HDFCBANK mentions at relevance ≥ 0.9.
- **Live fundamentals:** SUCCESS, with a note that INFY reports in USD and its statements were skipped. RELIANCE P/E is roughly 20; ROE and ROCE are null.
- **SQL spot checks:**
  - `select data_mode, source, count(*) from news group by 1, 2` (MOCK `mock-news.invalid`; LIVE publisher hosts)
  - `select s.symbol, n.title, m.relevance_score, m.matched_by from news_mentions m join news n on n.id = m.news_id join stocks s on s.id = m.stock_id where n.data_mode = 'LIVE' order by n.published_at desc limit 20`
  - Eyeball the live mentions for false matches, and record any alias fix as a seed change.

- [ ] **Step 3: Commit** `docs: news and fundamentals usage, matching rules, units; mark Phase 4 complete`. Then run the final fresh review, do one fix pass, and **stop for approval before Phase 5**.

---

## Verification (end of phase)

- **Automated:** typecheck, lint, format, build, plus unit and integration tests under TZ=UTC:
  - text utilities, normalizer, matcher
  - mock, RSS and NewsAPI providers
  - news repository and service
  - numeric guard, mock and Yahoo fundamentals
  - fundamentals repository and service
  - container wiring
  - pgTAP 118/118
- **Live (`test:live`):**
  - Yahoo market data
  - Yahoo fundamentals: RELIANCE is INR with percent units; INFY is non-INR
  - Google News and every default feed
- **End to end:**
  - mock news and fundamentals idempotent
  - live RSS news linked to the right stocks
  - live Yahoo fundamentals stored with INR gating
  - MOCK and LIVE rows never mixed
  - one `system_logs` row per run with counts and failure details
