# Phase 9: REST API — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (Native, as in Phases 2–8) to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

## Context

Phases 1–8 are merged on `main`. Every number the platform can show already exists in the database, and a pg-boss worker keeps it fresh. What is missing is the way out: there is one route, `/api/health`.

Phase 9 adds the **read and action API** of PRD §12: 16 GET routes over stored data, 7 POST actions, JWT auth with roles, per-route rate limits, zod validation, CORS and Helmet, and `/system-status`. It introduces **no new analysis** — every GET reads rows that Phases 3–8 already wrote.

**Goal:** the Phase 10 dashboard can be built against a complete, authenticated, rate-limited API, and `GET /api/stocks/RELIANCE` returns the whole decision in one call.

**Architecture:** `routes/*.ts` hold thin Fastify handlers (validate → call a service or repository → envelope). `services/StockAggregateService.ts` assembles the PRD §12 aggregate **from stored rows only**. `services/SystemHealthService.ts` answers `/system-status`. `http/auth.ts` verifies the Supabase JWT and loads the role from `user_profiles`; `http/rateLimit.ts` configures per-route limits. DTOs are snake_case, matching `/health` and the PRD. Tests use Fastify `inject`.

**Tech Stack:** existing Phase 8 stack + `jose@6.2.12` (JWT), `@fastify/rate-limit@11.2.0`, `@fastify/cors@11.3.0`, `@fastify/helmet@13.1.1`.

**Spec:** `PRD.md` §12 (the route table and the envelope), §14 (caching and cost control), §15 (security), §16 (`/system-status` fields), §17 (required edge cases).

### Live findings that shape the design

Probed on 2026-10-07 against the installed packages and the local database:

- **`@fastify/rate-limit`'s `keyGenerator` runs before auth by default.** Measured: with the limiter on its default `onRequest` hook and auth as a `preHandler`, the key generator saw `NO-USER`; with `hook: 'preHandler'` it saw `user-42`. Without this, every caller would share one IP bucket. **The limiter must be registered with `hook: 'preHandler'`.**
- **Parallel `app.inject` corrupts rate-limit counting.** Measured on `max: 3`: 5 sequential injects gave `200,200,200,429,429`, but 5 *concurrent* injects gave `429,429,429,429,429` — while 5 concurrent requests over **real HTTP** gave the correct `200,200,200,429,429`. The plugin is fine (so Phase 10's parallel page loads are safe); the artefact is `inject` sharing request state. **Rate-limit tests must call `inject` sequentially**, never inside `Promise.all`.
- **`jose@6.2.12` rejects what it must**, with distinct codes: expired → `ERR_JWT_EXPIRED`, wrong secret → `ERR_JWS_SIGNATURE_VERIFICATION_FAILED`, and the `alg: none` confusion attack → `ERR_JOSE_NOT_SUPPORTED`. `createRemoteJWKSet` exists for the cloud path.
- **A Supabase token's `role` claim is `authenticated`, not an app role.** The app role must come from `user_profiles`.
- **Phase 1 already solved the first-OWNER problem.** `public.handle_new_user()` fires on `auth.users` insert: the first signup becomes `OWNER`, everyone after `VIEWER`, and both paper accounts are created. **No role-granting CLI is needed** — signing up once is enough.
- **The local stack signs tokens with a symmetric secret** (`super-secret-jwt-token-with-at-least-32-characters-long`), so HS256 + `JWT_SECRET` is the local path and JWKS the cloud one.
- **`ai_qa_log.user_id` has no foreign key** (only `stock_id` does), so `AUTH_MODE=none` can log a synthetic user id without violating a constraint.
- **`UNSUPPORTED` already maps to 501**, which is the right answer for "AI is disabled", and `errorHandler` already passes framework 4xx through — a rate-limit 429 came out as `{"error":{"code":"RATE_LIMITED",...}}` with `Retry-After: 60` preserved.
- **`packages/shared` is an empty directory.** Nothing to consume; DTOs live in the backend and Phase 10 imports from there (or the package gets populated then).

## Deviations from the PRD (need your OK)

Two were settled by your answers before planning:

1. **`AUTH_MODE=none` exists for local development** (your choice: "build it, allow dev bypass"). Full JWT verification and OWNER/ADMIN role checks are implemented and tested as PRD §15 describes; `AUTH_MODE=none` additionally lets a local run answer as OWNER without a Supabase user, so the Phase 10 dashboard works immediately. It is **refused** when `MOCK_DATA=false`, **refused** when `HOST` is not loopback, requires an explicit `.env` line (never a silent default), and logs a warning on every startup.
2. **`/portfolio` and `/paper-trade/*` are not in this phase** (your choice: "skip them"). No `PaperTradingService` exists — that is Phase 11, which adds those 5 routes next to the engine that makes them work. Phase 9 delivers the other 16 reads and 7 actions.

Four more need your OK:

3. **A deduplicated sync returns `202 {job_id: null, already_queued: true}`.** `JobQueue.enqueue` resolves to `null` when a run of that job is already queued (Phase 8's `stately` policy). That is the queue working, not a failure, so it is still 202 — but the body says so, because a caller that got `job_id: null` silently would think its request vanished.
4. **Manual sync and job triggers bypass *calendar* gates through a new `manual` flag — never `force`.** Pressing "Sync Market" on a Saturday currently enqueues `market.sync.eod`, whose trading-day gate SKIPs it, so the owner sees a 202 and nothing happens. `POST /sync/*` and `POST /jobs/:name/run` therefore send `manual: true`, and `runJob` skips a **calendar** refusal when it sees that flag.

   **It must not be `force`.** Phase 8's `stockAnalysisJob` and `marketSummaryJob` pass `payload.force` straight through to the AI services, where it bypasses the hash cache and the min-interval (verified in `handlers/ai.ts:31,60`). Reusing `force` for the calendar bypass would make one click on `POST /jobs/ai.stock.analyze/run` force-regenerate all 20 stocks — precisely the "unnecessary LLM calls" the brief forbids. So:
   - `manual` only ever bypasses a **calendar** refusal, and chains never propagate it (a chained follow-up is not a manual action).
   - `force` reaches the AI services from exactly one route, `POST /ai/regenerate`, which is what the PRD gives a 5/hour limit for.
   - `ai.daily.summary`'s freshness gate (Phase 8's fix for the stale forced summary) is **not** bypassable by `manual`, or a mid-day click would recreate the bug it fixed.
   - The budget is not a gate at all — it lives inside the LLM gateway and throws `BUDGET_EXCEEDED` — so neither flag can reach past it.
5. **`meta.freshness` is market-aware.** PRD §12 requires the field and the envelope does not have it yet. One shape everywhere: `{ as_of, age_seconds, stale, market_open }`, where `stale` is false while the market is closed and `as_of` is the last session's close — a Sunday price is not "stale", it is final. The threshold is `app_settings.quote_staleness_minutes` (20). The aggregate's `data_freshness` reuses the same shape per section.
6. **Caching is TTL-only.** PRD §14 says caches are "invalidated on job completion", but the worker and the API are separate processes with separate `MemoryCache` instances, so the worker cannot invalidate the API's cache. Quotes get 30 s and aggregates 60 s, as §14 specifies, and nothing claims an invalidation path that cannot run. (A shared Redis later would make §14's wording literally true; the `Cache` interface already allows it.)

## Global Constraints

Everything from Phases 2–8 still applies:

- The gate for every task: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`.
- `TZ=UTC` tests; no `any`, no non-null `!`; ESM `.js` imports; `exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`.
- Branch `phase-9-rest-api`. Commits end with `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>`.
- The envelope is `{ data, meta }` and errors are `{ error: { code, message, details? } }`. **Wire format is snake_case**, like `/health` and the PRD.
- `data_mode` comes from config; mock and live rows never mix.
- **No GET route may cost money.** Every read serves stored rows. Only `POST /ai/*` and `POST /stocks/:symbol/qa` may reach the LLM gateway (Task 7 pins this with a provider that throws if called).
- **No secrets in logs**: the `Authorization` header must never be serialized.
- Never auto-execute trades. This phase places no orders at all.
- Secrets stay in backend env; the frontend gets only `NEXT_PUBLIC_*`.
- zod validates every param, query and body. Symbols resolve through a DB lookup, never string-interpolated.

## Review Focus

1. **A page load must never spend money.** `StockContextService.build` embeds the query through the retriever — `ai:budget` already shows 108 `query_embedding` calls — so an aggregate built on it would charge for every dashboard refresh and break PRD §14's first rule. Covered in Task 7 by a test that builds the app with an LLM provider which throws on any call and then hits every GET route.
2. **Rate limits must key on the user, not the IP.** Measured: with the limiter's default hook the key generator sees no user, so one caller could exhaust everyone's quota — and a shared bucket silently makes the per-route limits in PRD §12 meaningless. Covered in Task 3.
3. **A valid token is not an authorization.** A token that verifies but has no `user_profiles` row must get 403, not an implied VIEWER; a VIEWER must get 403 on every admin route; and `alg: none`, an expired token and a wrong-signature token must each get 401. Covered in Task 2.
4. **Missing data is a 200 with nulls, not a 500.** PRD §17 requires missing market data, missing news, no AI analysis and `LLM_PROVIDER=none` to degrade gracefully. Every aggregate section fails independently. Covered in Tasks 6 and 7.
5. **A 202 must not promise work nobody will do.** Sync endpoints enqueue and return immediately, so with no worker running the owner sees success and nothing happens. `/system-status` reports worker liveness from the `pgboss.instance` heartbeat. Covered in Task 8.

## File structure

```
backend/src/
├── http/
│   ├── envelope.ts         + freshness() and Meta.freshness                  (Task 1)
│   ├── auth.ts             verifyToken, loadRole, authPlugin, requireAdmin   (Task 2)
│   ├── rateLimit.ts        per-route limit table from PRD §12                (Task 3)
│   └── validate.ts         zod helpers: params, query, body → AppError       (Task 1)
├── routes/
│   ├── markets.ts          /markets, /market-summary, /market-status         (Task 5)
│   ├── stocks.ts           /stocks, /stocks/:symbol/* (9 routes)             (Task 5)
│   ├── aggregate.ts        /stocks/:symbol                                   (Task 7)
│   ├── actions.ts          /sync/*, /jobs/:name/run, /ai/*, /qa              (Task 8)
│   └── systemStatus.ts     /system-status                                    (Task 8)
├── services/
│   ├── StockAggregateService.ts   stored rows only; sections fail apart      (Task 6)
│   └── SystemHealthService.ts     PRD §16 fields + worker liveness           (Task 8)
├── dto/                    snake_case shapes + mappers (Phase 10 consumes)   (Task 4)
├── repositories/           + filtered run queries, listLatestEvaluations     (Tasks 4, 8)
├── config/env.ts           + AUTH_MODE, CORS_ORIGIN, rate-limit toggle       (Task 2)
├── container.ts            + jobs queue, aggregate, systemHealth; overrides  (Task 8)
└── app.ts                  register helmet, cors, rate-limit, auth, routes   (Task 3)
backend/tests/{unit,integration}/…
```

## Route inventory (what this phase ships)

**Reads** (JWT; 120/min shared bucket unless noted):

| Route | Source | Notes |
| --- | --- | --- |
| `GET /markets` | `markets` + latest `market_data` | indices with quote and status |
| `GET /market-summary` | `market_ai_summary` | latest stored; null when none |
| `GET /market-status` | `MarketCalendarService.status` | IST, with next open |
| `GET /stocks` | `stocks` + latest `stock_evaluations` | `?query=&sector=&action=` |
| `GET /stocks/:symbol` | **aggregate** (Task 7) | the whole decision in one call |
| `GET /stocks/:symbol/quote` | `market_data` | 30 s cache |
| `GET /stocks/:symbol/history` | `market_data` | `?range=1D..5Y&interval=` |
| `GET /stocks/:symbol/technical` | `technical_indicators` | + interpretations, technical score |
| `GET /stocks/:symbol/fundamentals` | `fundamental_snapshots` + `financial_statements` | nulls = unavailable |
| `GET /stocks/:symbol/evaluation` | `stock_evaluations` | scores, levels, action state |
| `GET /stocks/:symbol/news` | `news` + `news_ai_analysis` | articles with per-stock sentiment |
| `GET /stocks/:symbol/sentiment` | `news_ai_analysis` | aggregated |
| `GET /stocks/:symbol/analysis` | `stock_ai_analysis` | latest stored |
| `GET /stocks/:symbol/ai-summary` | `stock_ai_analysis` | compact card view |
| `GET /system-status` | `system_logs`, `LlmBudget`, `pgboss.instance` | PRD §16 |

**Actions** (JWT; † = OWNER/ADMIN):

| Route | Limit | Effect |
| --- | --- | --- |
| `POST /sync/market` † | 6/hour | enqueue, `202 {job_id}` |
| `POST /sync/news` † | 6/hour | enqueue |
| `POST /sync/fundamentals` † | 4/day | enqueue |
| `POST /jobs/:name/run` † | 10/hour | enqueue any of the 13 jobs |
| `POST /ai/analyze` † | 20/hour | cached when the input hash matches |
| `POST /ai/regenerate` † | 5/hour | `force: true`; budget still enforced |
| `POST /stocks/:symbol/qa` | 30/hour | cited answer; ≤ 500 chars |

---

### Task 1: Freshness in the envelope, and zod request validation

**Files:**
- Modify: `backend/src/http/envelope.ts`
- Create: `backend/src/http/validate.ts`
- Test: `backend/tests/unit/envelope.test.ts`, `backend/tests/unit/validate.test.ts`

**Interfaces — Produces:**
- `Freshness { as_of: string | null; age_seconds: number | null; stale: boolean; market_open: boolean }`
- `freshness(asOf: Date | null, opts: { now: Date; marketOpen: boolean; stalenessMinutes: number }): Freshness`
- `meta(dataMode, now, freshness?)` — `Meta` gains an optional `freshness`
- `parseParams/parseQuery/parseBody<T>(schema, value): T` — throwing `AppError('VALIDATION', …)` with the field path in `details`

**Why market-aware** (Deviation 5): a price from Friday's close is not stale on Sunday; it is the most recent fact there is. Marking it stale would make the dashboard cry wolf every weekend and every holiday.

- [ ] **Step 1: Branch and write the failing tests**

```bash
git checkout -b phase-9-rest-api
```

`backend/tests/unit/envelope.test.ts`:

```ts
import { describe, expect, it } from 'vitest';
import { freshness, meta, ok } from '../../src/http/envelope.js';

const NOW = new Date('2026-10-06T06:00:00Z'); // 11:30 IST, mid-session

describe('freshness', () => {
  it('reports a fresh quote inside the session', () => {
    const f = freshness(new Date('2026-10-06T05:55:00Z'), {
      now: NOW, marketOpen: true, stalenessMinutes: 20,
    });
    expect(f).toEqual({
      as_of: '2026-10-06T05:55:00.000Z', age_seconds: 300, stale: false, market_open: true,
    });
  });

  it('marks a quote stale once it passes the threshold while the market is open', () => {
    const f = freshness(new Date('2026-10-06T05:30:00Z'), {
      now: NOW, marketOpen: true, stalenessMinutes: 20,
    });
    expect(f).toMatchObject({ age_seconds: 1800, stale: true });
  });

  it('never calls the last close stale while the market is closed', () => {
    // Sunday 11:30 IST, holding Friday's close: old, but it is the newest fact there is.
    const f = freshness(new Date('2026-10-02T10:00:00Z'), {
      now: new Date('2026-10-04T06:00:00Z'), marketOpen: false, stalenessMinutes: 20,
    });
    expect(f.stale).toBe(false);
    expect(f.market_open).toBe(false);
    expect(f.age_seconds).toBeGreaterThan(20 * 60);
  });

  it('treats missing data as stale with a null age', () => {
    expect(freshness(null, { now: NOW, marketOpen: true, stalenessMinutes: 20 })).toEqual({
      as_of: null, age_seconds: null, stale: true, market_open: true,
    });
  });
});

describe('meta', () => {
  it('omits freshness when not supplied, and carries it when it is', () => {
    expect(meta('MOCK', NOW)).toEqual({
      data_mode: 'MOCK', generated_at: '2026-10-06T06:00:00.000Z',
    });
    const f = freshness(NOW, { now: NOW, marketOpen: true, stalenessMinutes: 20 });
    expect(meta('MOCK', NOW, f).freshness).toEqual(f);
    expect(ok({ x: 1 }, meta('MOCK', NOW))).toEqual({
      data: { x: 1 }, meta: { data_mode: 'MOCK', generated_at: '2026-10-06T06:00:00.000Z' },
    });
  });
});
```

`backend/tests/unit/validate.test.ts`:

```ts
import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { parseBody, parseQuery } from '../../src/http/validate.js';

describe('request validation', () => {
  it('returns typed values on success, coercing query strings', () => {
    const q = parseQuery(z.object({ limit: z.coerce.number().int().min(1).max(100).default(20) }), {
      limit: '50',
    });
    expect(q).toEqual({ limit: 50 });
  });

  it('rejects a bad value as VALIDATION with the field path in details', () => {
    try {
      parseBody(z.object({ question: z.string().min(1).max(500) }), { question: '' });
      throw new Error('expected parseBody to throw');
    } catch (error) {
      expect(error).toMatchObject({ code: 'VALIDATION', httpStatus: 400 });
      expect(JSON.stringify((error as { details?: unknown }).details)).toMatch(/question/);
    }
  });

  it('rejects an unknown key rather than ignoring it', () => {
    // Silently dropping a misspelled filter would make the API lie about what it applied.
    expect(() => parseQuery(z.object({ sector: z.string() }).strict(), { secter: 'it' })).toThrow();
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit -- envelope validate`
Expected: FAIL (`freshness` and `validate.js` do not exist).

- [ ] **Step 3: Implement.** In `envelope.ts`:

```ts
export interface Freshness {
  as_of: string | null;
  age_seconds: number | null;
  stale: boolean;
  market_open: boolean;
}

export interface FreshnessOptions {
  now: Date;
  marketOpen: boolean;
  /** app_settings.quote_staleness_minutes (PRD §11). */
  stalenessMinutes: number;
}

/**
 * How old the newest stored fact is, and whether that is a problem.
 *
 * `stale` is only ever true while the market is open: Friday's close on a Sunday is not stale, it
 * is final, and flagging it would make every weekend look like an outage.
 */
export function freshness(asOf: Date | null, o: FreshnessOptions): Freshness {
  if (asOf === null) {
    return { as_of: null, age_seconds: null, stale: true, market_open: o.marketOpen };
  }
  const ageSeconds = Math.max(0, Math.round((o.now.getTime() - asOf.getTime()) / 1000));
  return {
    as_of: asOf.toISOString(),
    age_seconds: ageSeconds,
    stale: o.marketOpen && ageSeconds > o.stalenessMinutes * 60,
    market_open: o.marketOpen,
  };
}
```

and `Meta` gains `freshness?: Freshness`, with `meta(dataMode, now, f?)` setting it only when given (`exactOptionalPropertyTypes` means spreading a conditional, not assigning `undefined`).

`backend/src/http/validate.ts` wraps `schema.safeParse` and throws `AppError('VALIDATION', …)` carrying `z.treeifyError(result.error)` (zod 4) in `details`, with one function per request part so the message names it (`'Invalid query parameters'`, etc.).

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): market-aware freshness in the envelope and zod request validation`.

---

### Task 2: JWT auth, roles, and the guarded dev bypass

**Files:**
- Create: `backend/src/http/auth.ts`
- Modify: `backend/src/utils/errors.ts` (`UNAUTHORIZED`, `FORBIDDEN`), `backend/src/http/errorHandler.ts` (`codeForStatus`), `backend/src/config/env.ts`, `backend/package.json` (`jose`), `.env.example`
- Create: `backend/src/repositories/UserProfileRepository.ts`
- Test: `backend/tests/unit/auth.test.ts`, `backend/tests/integration/authRoutes.test.ts`

**Interfaces — Produces:**
- `AuthenticatedUser { id: string; role: UserRole; email: string | null }`
- `verifyToken(token, opts): Promise<{ sub: string; email: string | null }>` — HS256 secret or JWKS
- `authPlugin(app, { config, profiles, logger })` — a `preHandler` that sets `request.user`
- `requireAdmin(request)` — throws `FORBIDDEN` unless OWNER/ADMIN
- `config.auth: { mode: 'jwt' | 'none'; issuer: string | null; audience: string }`

**Why new error codes** (advisor's point): `AUTH_FAILED` already means "the *provider* rejected us" and maps to 502. Reusing it would turn a missing token into a 502, and `codeForStatus` currently labels every unlisted 4xx `VALIDATION`, so a 401 would be reported as a validation error.

**Why no role CLI:** Phase 1's `handle_new_user()` trigger makes the first signup OWNER (verified). Signing up once through Supabase Auth is the whole setup.

- [ ] **Step 1: Install and write the failing tests**

```bash
pnpm --filter @learning-stocks/backend add jose@6.2.12
```

`backend/tests/unit/auth.test.ts` — token handling, no server:

```ts
import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { verifyToken } from '../../src/http/auth.js';

const SECRET_TEXT = 'super-secret-jwt-token-with-at-least-32-characters-long';
const SECRET = new TextEncoder().encode(SECRET_TEXT);
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const opts = { secret: SECRET_TEXT, issuer: ISSUER, audience: 'authenticated', jwksUrl: null };

const sign = (claims: Record<string, unknown>, exp = '1h') =>
  new SignJWT(claims)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(ISSUER)
    .setAudience('authenticated')
    .setIssuedAt()
    .setExpirationTime(exp)
    .sign(SECRET);

describe('verifyToken', () => {
  it('accepts a Supabase-shaped token and returns the subject', async () => {
    const token = await sign({ sub: 'u-1', role: 'authenticated', email: 'owner@example.com' });
    await expect(verifyToken(token, opts)).resolves.toEqual({
      sub: 'u-1', email: 'owner@example.com',
    });
  });

  it('rejects an expired token, a forged signature, and alg=none', async () => {
    const expired = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER).setAudience('authenticated')
      .setIssuedAt(0).setExpirationTime(1).sign(SECRET);
    await expect(verifyToken(expired, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });

    const forged = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER).setAudience('authenticated')
      .setIssuedAt().setExpirationTime('1h')
      .sign(new TextEncoder().encode('x'.repeat(48)));
    await expect(verifyToken(forged, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });

    // alg: none is the classic confusion attack: a token with no signature at all.
    const none = 'eyJhbGciOiJub25lIn0.eyJzdWIiOiJoYWNrZXIifQ.';
    await expect(verifyToken(none, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });

  it('rejects a token issued by someone else, or for another audience', async () => {
    const otherIssuer = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer('https://evil.example.com').setAudience('authenticated')
      .setIssuedAt().setExpirationTime('1h').sign(SECRET);
    await expect(verifyToken(otherIssuer, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });

    const otherAudience = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER).setAudience('anon')
      .setIssuedAt().setExpirationTime('1h').sign(SECRET);
    await expect(verifyToken(otherAudience, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });

  it('rejects a token with no subject', async () => {
    const noSub = await sign({ role: 'authenticated' });
    await expect(verifyToken(noSub, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });
});
```

`backend/tests/integration/authRoutes.test.ts` — the role rules, against the real database.

**These routes do not exist yet** (`/market-status` is Task 5, `/sync/market` is Task 8), so this file registers its own throwaway routes after `buildApp`. That keeps each task's own gate passing, and it tests the auth plugin rather than any particular route. The real-route role assertions (VIEWER 403 / OWNER 202 on `/sync/market`) belong to Task 8.

```ts
import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { requireAdmin } from '../../src/http/auth.js';
import type { Database } from '../../src/database/db.js';
import { capturingLogger, createTestDb, silentLogger, withRollback } from './helpers.js';

const SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long';
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const db = createTestDb();
const jwtEnv = { AUTH_MODE: 'jwt', JWT_SECRET: SECRET, SUPABASE_URL: 'http://127.0.0.1:54321' };

const sign = (sub: string) =>
  new SignJWT({ sub, role: 'authenticated', email: `${sub}@example.com` })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(ISSUER).setAudience('authenticated')
    .setIssuedAt().setExpirationTime('1h')
    .sign(new TextEncoder().encode(SECRET));

/**
 * Inserts a real auth.users row so handle_new_user() creates the profile, then sets the role.
 * Measured: this works as `postgres` inside a transaction, and the trigger assigns OWNER to the
 * first user in a clean user_profiles.
 */
async function seedUser(trx: Database, role: 'OWNER' | 'ADMIN' | 'VIEWER' | null): Promise<string> {
  const id = randomUUID();
  await sql`
    insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)
    values (${id}::uuid, '00000000-0000-0000-0000-000000000000'::uuid, 'authenticated',
            'authenticated', ${`${id}@example.com`}, 'x', now(), now())
  `.execute(trx);
  if (role === null) {
    // A token that verifies but has no profile row: identity without authorization.
    await trx.deleteFrom('user_profiles').where('user_id', '=', id).execute();
  } else {
    await trx.updateTable('user_profiles').set({ role }).where('user_id', '=', id).execute();
  }
  return id;
}

/** buildApp plus two throwaway routes, so this file does not depend on Tasks 5 and 8. */
async function appOver(trx: Database, env: Record<string, string>, logger = silentLogger) {
  const container = createContainer(loadConfig(env), { db: trx, logger });
  const app = await buildApp(container);
  app.get('/api/_probe/read', async () => ({ data: 'ok' }));
  app.post('/api/_probe/admin', async (request) => {
    requireAdmin(request);
    return { data: 'ok' };
  });
  await app.ready();
  return app;
}

describe('auth', () => {
  it('refuses a request with no token, and leaves /api/health public', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, jwtEnv);
      const denied = await app.inject({ method: 'GET', url: '/api/_probe/read' });
      expect(denied.statusCode).toBe(401);
      expect(denied.json()).toMatchObject({ error: { code: 'UNAUTHORIZED' } });
      // A load balancer cannot present a token, and Phase 2's app.test.ts calls this untokened.
      expect((await app.inject({ method: 'GET', url: '/api/health' })).statusCode).toBeLessThan(500);
    });
  });

  it('refuses a valid token with no user_profiles row (403, not an implied role)', async () => {
    // A token proves identity; the profile row is the authorization. Defaulting to VIEWER would
    // let anyone who can sign up read the whole research desk.
    await withRollback(db, async (trx) => {
      const id = await seedUser(trx, null);
      const app = await appOver(trx, jwtEnv);
      const r = await app.inject({
        method: 'GET', url: '/api/_probe/read',
        headers: { authorization: `Bearer ${await sign(id)}` },
      });
      expect(r.statusCode).toBe(403);
      expect(r.json()).toMatchObject({ error: { code: 'FORBIDDEN' } });
    });
  });

  it('lets a VIEWER read but not run an admin action, and lets an OWNER do both', async () => {
    await withRollback(db, async (trx) => {
      const viewer = await seedUser(trx, 'VIEWER');
      const owner = await seedUser(trx, 'OWNER');
      const app = await appOver(trx, jwtEnv);
      const asUser = async (id: string) => ({ authorization: `Bearer ${await sign(id)}` });

      expect((await app.inject({ method: 'GET', url: '/api/_probe/read', headers: await asUser(viewer) })).statusCode).toBe(200);
      expect((await app.inject({ method: 'POST', url: '/api/_probe/admin', headers: await asUser(viewer), payload: {} })).statusCode).toBe(403);
      expect((await app.inject({ method: 'POST', url: '/api/_probe/admin', headers: await asUser(owner), payload: {} })).statusCode).toBe(200);
    });
  });

  it('never logs the Authorization header', async () => {
    // PRD §15: a bearer token in a log file is a leaked credential. Phase 2 already redacts
    // req.headers.authorization; this is the regression test for a future log call that
    // serializes headers around the redaction.
    await withRollback(db, async (trx) => {
      const { logger, lines } = capturingLogger();
      const id = await seedUser(trx, 'OWNER');
      const token = await sign(id);
      const app = await appOver(trx, jwtEnv, logger);
      await app.inject({
        method: 'GET', url: '/api/_probe/read', headers: { authorization: `Bearer ${token}` },
      });
      expect(lines.length).toBeGreaterThan(0);
      expect(lines.join('\n')).not.toContain(token);
      expect(lines.join('\n')).not.toMatch(/Bearer /);
    });
  });
});

describe('AUTH_MODE=none', () => {
  it('answers as OWNER without a token, in mock mode on loopback', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none' });
      expect((await app.inject({ method: 'GET', url: '/api/_probe/read' })).statusCode).toBe(200);
      // The bypass user is OWNER, so admin routes work locally without a Supabase user.
      expect((await app.inject({ method: 'POST', url: '/api/_probe/admin', payload: {} })).statusCode).toBe(200);
    });
  });

  it('is refused in live mode and when not bound to loopback', () => {
    expect(() => loadConfig({ AUTH_MODE: 'none', MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'none', FUNDAMENTALS_PROVIDER: 'none', LLM_PROVIDER: 'none' }))
      .toThrow(/AUTH_MODE=none/);
    expect(() => loadConfig({ AUTH_MODE: 'none', HOST: '0.0.0.0' })).toThrow(/AUTH_MODE=none/);
  });

  it('refuses jwt mode with no secret and no Supabase URL, at buildApp not loadConfig', async () => {
    // loadConfig({}) is called by config.test.ts, container.test.ts, jobHandlers.test.ts, every
    // CLI and the worker — none of which has JWT material. Failing there breaks the suite.
    expect(() => loadConfig({})).not.toThrow();
    await withRollback(db, async (trx) => {
      const container = createContainer(loadConfig({ AUTH_MODE: 'jwt' }), { db: trx, logger: silentLogger });
      await expect(buildApp(container)).rejects.toThrow(/JWT_SECRET|SUPABASE_URL/);
    });
  });
});
```

Three things to settle while writing this file:

- **Seeding a user works, and the trigger does the work.** Measured: as `postgres`, inside a transaction, `insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)` succeeds, `handle_new_user()` fires, and the profile row appears with role `OWNER` (the first user in a clean `user_profiles`). So the test seeds a real user and rolls it back; to test VIEWER, insert a second user, or update the role after the trigger runs.
- **Every route test runs inside `withRollback` with `{ db: trx }`.** `POST /ai/regenerate` writes an analysis row; outside a transaction that lands in the developer's database, which is the leak Phase 7 and Phase 8 each had to fix.
- **`container.close()` must not destroy a `db` it did not create.** `container.ts:312` is `close: () => db.destroy()`, so a test that passes the shared pool and then calls `close()` leaves the next test with a destroyed driver. Change the container to remember whether it created the pool and destroy only then; the Phase 8 tests that pass `{ db: trx }` and never call `close()` keep working either way.
- **`capturingLogger`** belongs next to `silentLogger` in `helpers.ts`: a pino logger writing to an array, so the no-leak assertion is real rather than vacuous.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (module missing; `AUTH_MODE` unknown).

- [ ] **Step 3: Implement.**

In `utils/errors.ts`: add `'UNAUTHORIZED'` and `'FORBIDDEN'` to `ERROR_CODES`, with `UNAUTHORIZED: 401` and `FORBIDDEN: 403` in `HTTP_STATUS`, neither retryable. In `errorHandler.ts`, extend `codeForStatus` with 401 → `UNAUTHORIZED` and 403 → `FORBIDDEN`.

`backend/src/http/auth.ts`:

```ts
import { createRemoteJWKSet, type JWTVerifyGetKey, jwtVerify } from 'jose';
import { AppError } from '../utils/errors.js';

/** Supabase signs access tokens HS256 with the project secret; the cloud path is JWKS (RS256/ES256). */
const ALGORITHMS = ['HS256', 'RS256', 'ES256'] as const;

export interface VerifyOptions {
  secret: string | null;
  jwksUrl: string | null;
  issuer: string | null;
  audience: string;
}

export async function verifyToken(
  token: string,
  o: VerifyOptions,
): Promise<{ sub: string; email: string | null }> {
  const key = keyFor(o);
  try {
    const { payload } = await jwtVerify(token, key, {
      algorithms: [...ALGORITHMS],
      audience: o.audience,
      // Pinning the issuer stops a token minted by another project from being accepted.
      ...(o.issuer === null ? {} : { issuer: o.issuer }),
    });
    if (typeof payload.sub !== 'string' || payload.sub === '') {
      throw new AppError('UNAUTHORIZED', 'Token has no subject');
    }
    return { sub: payload.sub, email: typeof payload.email === 'string' ? payload.email : null };
  } catch (error) {
    if (error instanceof AppError) throw error;
    // The reason never reaches the caller: "expired" vs "bad signature" is an oracle.
    throw new AppError('UNAUTHORIZED', 'Invalid or expired token', {
      details: { reason: error instanceof Error ? error.name : 'unknown' },
    });
  }
}
```

plus `authPlugin`, registered as a **`preHandler`** so `request.user` exists before the rate limiter's key generator runs (Task 3), which:
- in `mode: 'none'`, sets `{ id: DEV_USER_ID, role: 'OWNER', email: null }` and does nothing else;
- otherwise reads `Authorization: Bearer <token>`, 401s when absent or malformed, verifies it, then loads the role through `UserProfileRepository.findRole(sub)` and **403s when there is no row**;
- exposes `requireAdmin(request)` throwing `FORBIDDEN` unless the role is OWNER or ADMIN.

`UserProfileRepository.findRole(userId): Promise<UserRole | null>` is a single indexed lookup, cached for 30 s through the existing `Cache` (a role change then takes effect within 30 s, which is documented).

In `config/env.ts`: `AUTH_MODE: z.enum(['jwt', 'none']).default('jwt')`, `CORS_ORIGIN` (default `http://127.0.0.1:3000`), and a `config.auth` block. Add to the live-mode problems list: `AUTH_MODE=none` is refused when `MOCK_DATA=false`, and refused when `HOST` is not `127.0.0.1`/`localhost`/`::1`.

**Do not make missing JWT material a `loadConfig` error.** `AUTH_MODE` defaults to `jwt`, and `loadConfig({})` is called by `config.test.ts`, `container.test.ts` and `jobHandlers.test.ts` (verified), plus every CLI and the worker — none of which has a `JWT_SECRET`. Failing there would break the whole suite and the worker. Instead:
- `loadConfig` only validates the *shape*.
- `authPlugin` checks at construction that `jwt` mode has usable material (`JWT_SECRET` or `SUPABASE_URL`), throwing with a message naming both. Only `buildApp` reaches it, so CLIs and the worker are unaffected.
- When both are set, **the secret wins**: a local HS256 token cannot verify against JWKS, and the local stack signs with the secret.
- Log `warn` at startup whenever `mode === 'none'`.

**`/api/health` stays public.** Phase 2's `app.test.ts` calls it without a token (verified), and a load balancer cannot send one. Register the auth `preHandler` on the authenticated route scope, not globally — which `app.ts` already does by registering routes inside a `register` callback.

**The logger already redacts the header.** Phase 2's `REDACT_PATHS` includes `req.headers.authorization`, `authorization`, `token` and `cookie` (verified in `utils/logger.ts:3-15`), so no change is needed — but keep the test, because it is the thing that would catch a future `request.log.info({ headers })` call that serializes around the redaction.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): Supabase JWT verification, user roles and a guarded dev bypass`.

---

### Task 3: Rate limits, CORS, Helmet, and the app wiring

**Files:**
- Create: `backend/src/http/rateLimit.ts`
- Modify: `backend/src/app.ts`, `backend/package.json`
- Test: `backend/tests/integration/httpPlugins.test.ts`

**Interfaces — Produces:**
- `RATE_LIMITS: Readonly<Record<string, { max: number; timeWindow: string }>>` — the PRD §12 table, keyed by route id
- `registerHttpPlugins(app, c)` — helmet, CORS, rate-limit (`hook: 'preHandler'`, `global: false`)
- `limit(id)` — the per-route `config.rateLimit` object a route spreads

**Measured facts this task depends on:** the limiter must use `hook: 'preHandler'` or `keyGenerator` sees no user (so every caller shares the IP bucket); and rate-limit assertions must use **sequential** `inject` calls, because parallel `inject` miscounts while real HTTP does not.

- [ ] **Step 1: Install and write the failing test**

```bash
pnpm --filter @learning-stocks/backend add @fastify/rate-limit@11.2.0 @fastify/cors@11.3.0 @fastify/helmet@13.1.1
```

`backend/tests/integration/httpPlugins.test.ts`. Like Task 2's file, it registers throwaway routes, because the real ones arrive in Tasks 5 and 8:

```ts
import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { limit } from '../../src/http/rateLimit.js';
import type { Database } from '../../src/database/db.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long';
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const db = createTestDb();

const sign = (sub: string) =>
  new SignJWT({ sub, role: 'authenticated' })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(ISSUER).setAudience('authenticated')
    .setIssuedAt().setExpirationTime('1h')
    .sign(new TextEncoder().encode(SECRET));

async function seedOwner(trx: Database): Promise<string> {
  const id = randomUUID();
  await sql`
    insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)
    values (${id}::uuid, '00000000-0000-0000-0000-000000000000'::uuid, 'authenticated',
            'authenticated', ${`${id}@example.com`}, 'x', now(), now())
  `.execute(trx);
  await trx.updateTable('user_profiles').set({ role: 'OWNER' }).where('user_id', '=', id).execute();
  return id;
}

async function appOver(trx: Database, env: Record<string, string>) {
  const container = createContainer(loadConfig(env), { db: trx, logger: silentLogger });
  const app = await buildApp(container);
  app.get('/api/_probe/read', { config: { rateLimit: limit('reads') } }, async () => ({ data: 'ok' }));
  app.post('/api/_probe/tight', { config: { rateLimit: limit('ai.regenerate') } }, async () => ({ data: 'ok' }));
  await app.ready();
  return app;
}

describe('http plugins', () => {
  it('sets security headers and restricts CORS to the configured origin', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none', CORS_ORIGIN: 'http://127.0.0.1:3000' });
      const r = await app.inject({ method: 'GET', url: '/api/_probe/read' });
      expect(r.headers['x-content-type-options']).toBe('nosniff');

      const allowed = await app.inject({
        method: 'OPTIONS', url: '/api/_probe/read',
        headers: { origin: 'http://127.0.0.1:3000', 'access-control-request-method': 'GET' },
      });
      expect(allowed.headers['access-control-allow-origin']).toBe('http://127.0.0.1:3000');

      const refused = await app.inject({
        method: 'OPTIONS', url: '/api/_probe/read',
        headers: { origin: 'https://evil.example.com', 'access-control-request-method': 'GET' },
      });
      expect(refused.headers['access-control-allow-origin']).toBeUndefined();
    });
  });

  it('enforces a per-route limit and returns our error envelope with Retry-After', async () => {
    // Sequential, never Promise.all: parallel inject miscounts the limiter (measured — 5
    // concurrent injects against max 3 gave five 429s, while real HTTP gave 200,200,200,429,429),
    // so a parallel assertion here would test the harness, not the limit.
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none' });
      const hit = () => app.inject({ method: 'POST', url: '/api/_probe/tight', payload: {} });
      const codes: number[] = [];
      for (let i = 0; i < 6; i += 1) codes.push((await hit()).statusCode);
      // ai.regenerate is 5/hour, so the first five pass and the sixth is refused.
      expect(codes.slice(0, 5)).toEqual([200, 200, 200, 200, 200]);
      const last = codes.at(-1);
      expect(last).toBe(429);
      const refused = await hit();
      expect(refused.json()).toMatchObject({ error: { code: 'RATE_LIMITED' } });
      expect(refused.headers['retry-after']).toBeDefined();
    });
  });

  it('keys the limit on the user, so one caller cannot exhaust another from the same IP', async () => {
    // THE regression test for Review Focus 2. Measured against 11.2.0: with the limiter on its
    // default onRequest hook the keyGenerator sees no user, so both tokens share the IP bucket
    // and user B gets 429. Two real users are required — under AUTH_MODE=none there is only one,
    // and inject always reports the same IP, so a single-user version of this test is vacuous.
    await withRollback(db, async (trx) => {
      const a = await seedOwner(trx);
      const b = await seedOwner(trx);
      const app = await appOver(trx, {
        AUTH_MODE: 'jwt', JWT_SECRET: SECRET, SUPABASE_URL: 'http://127.0.0.1:54321',
      });
      const hit = async (id: string) =>
        (await app.inject({
          method: 'POST', url: '/api/_probe/tight', payload: {},
          headers: { authorization: `Bearer ${await sign(id)}` },
        })).statusCode;

      for (let i = 0; i < 5; i += 1) expect(await hit(a)).toBe(200);
      expect(await hit(a)).toBe(429);          // user A is spent
      expect(await hit(b)).toBe(200);          // user B is untouched
    });
  });

  it('leaves an unknown route as a 404 in our envelope', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none' });
      const r = await app.inject({ method: 'GET', url: '/api/nope' });
      expect(r.statusCode).toBe(404);
      expect(r.json()).toMatchObject({ error: { code: 'NOT_FOUND' } });
    });
  });
});
```

**Verify the keying test is load-bearing** before moving on: temporarily change the limiter to `hook: 'onRequest'` and confirm "keys the limit on the user" fails (user B should get 429). A test that passes either way proves nothing, and this one is the only thing standing between the PRD's per-route limits and a single shared IP bucket.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (plugins not registered).

- [ ] **Step 3: Implement** `backend/src/http/rateLimit.ts` with the PRD §12 table:

```ts
/**
 * PRD §12, keyed per user (see registerHttpPlugins).
 *
 * Whether two routes sharing `limit('reads')` share one counter or get one each is a plugin
 * detail: @fastify/rate-limit keys on (key, route) by default. Confirm which it is while
 * implementing and correct this comment — "reads share one bucket" is a claim about behaviour the
 * owner will notice if it is wrong, and 120/min per route is a much weaker limit than 120/min
 * overall.
 */
export const RATE_LIMITS = {
  reads: { max: 120, timeWindow: '1 minute' },
  'sync.market': { max: 6, timeWindow: '1 hour' },
  'sync.news': { max: 6, timeWindow: '1 hour' },
  'sync.fundamentals': { max: 4, timeWindow: '1 day' },
  'jobs.run': { max: 10, timeWindow: '1 hour' },
  'ai.analyze': { max: 20, timeWindow: '1 hour' },
  'ai.regenerate': { max: 5, timeWindow: '1 hour' },
  qa: { max: 30, timeWindow: '1 hour' },
} as const;
```

and `registerHttpPlugins`:

```ts
await app.register(helmet, { contentSecurityPolicy: false }); // API serves JSON, not documents
await app.register(cors, { origin: [c.config.corsOrigin], credentials: true });
await app.register(rateLimit, {
  global: false,
  // preHandler, not the default onRequest: the key generator must run AFTER auth, or it sees no
  // user and every caller shares one IP bucket (measured against 11.2.0).
  hook: 'preHandler',
  keyGenerator: (request) => (request as { user?: { id: string } }).user?.id ?? request.ip,
});
```

In `app.ts`, the order is: error handling → plugins → auth `preHandler` → routes. Auth must be registered so it runs before the limiter's `preHandler`; verify with the "keys on the user" test rather than by reading the docs.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): per-route rate limits keyed on the user, CORS and Helmet`.

---

### Task 4: Read DTOs and the repository queries the routes need

**Files:**
- Create: `backend/src/dto/{stock,market,technical,fundamentals,evaluation,news,ai}.ts`
- Modify: `backend/src/repositories/{StockRepository,EvaluationRepository,MarketDataRepository,NewsRepository}.ts`
- Test: `backend/tests/unit/dto.test.ts`, `backend/tests/integration/readQueries.test.ts`

**Interfaces — Produces:**
- One mapper per DTO, e.g. `toQuoteDto(bar)`, `toEvaluationDto(detail)`, `toTechnicalDto(ts, values, score)`, `toNewsDto(article, sentiment)`, `toAnalysisDto(stored)`, `toAiSummaryDto(stored)`.
- `StockRepository.listWithFilters({ query?, sector?, action?, mode })` — stocks with their latest evaluation, filtered in SQL.
- `MarketDataRepository.latestQuotesForMarkets(mode)` — one query for all index cards.
- `NewsRepository.listForStockWithSentiment(stockId, mode, limit)` — articles joined to per-stock sentiment.

**The rule for every DTO:** snake_case keys, `null` for "we do not have this" (never 0, never omitted), ISO-8601 UTC strings for timestamps, and **no derived analysis** — a DTO renames and shapes, it never computes a score. Numbers come out as numbers, not numeric strings (the `toNumber` convention from Phase 2).

- [ ] **Step 1: Write the failing tests.** `readQueries.test.ts` asserts the new repository queries against the seeded database: the filter combinations (`query` matches symbol *and* company name; `sector`; `action`), that only the latest evaluation per stock is returned, and that a MOCK query never sees LIVE rows.

`dto.test.ts` asserts the **exact key set** of each mapper from a hand-built row — `expect(Object.keys(dto).sort()).toEqual([...])` — plus three properties that hold for every DTO in this phase:

```ts
  it('keeps a missing metric as null rather than 0 or absent', () => {
    // 0 and null mean different things on a research desk: "the ratio is zero" versus "we do
    // not know it". A dropped key would render as undefined and silently blank a panel.
    const dto = toFundamentalsDto({ ...row, pe: null, roe: null });
    expect(dto.pe).toBeNull();
    expect(dto.roe).toBeNull();
    expect('pe' in dto).toBe(true);
  });

  it('converts numeric columns to numbers, not strings', () => {
    // pg returns numeric as a string; a JSON string here would break every chart in Phase 10.
    expect(toQuoteDto({ ...bar, close: '1186.4000' })).toMatchObject({ close: 1186.4 });
  });

  it('renders every timestamp as an ISO-8601 UTC string', () => {
    expect(toQuoteDto({ ...bar, ts: new Date('2026-10-06T03:45:00Z') }).ts)
      .toBe('2026-10-06T03:45:00.000Z');
  });
```

The executor writes the key list for each DTO from the PRD section it serves and **ledgers that key set as a ruling**, because Phase 10 is built against it and a later rename is a breaking change.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.

- [ ] **Step 3: Implement.** Keep each DTO file small and pure: input types from the repositories, output types declared as interfaces so Phase 10 can import them. `listWithFilters` uses `distinctOn('stock_id')` like `latestForAll`, with the filters applied before the join so a 2,000-row table stays one query.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): snake_case read DTOs and the queries the API routes need`.

---

### Task 5: Market and per-stock read routes

**Files:**
- Create: `backend/src/routes/{markets,stocks}.ts`
- Modify: `backend/src/app.ts`
- Test: `backend/tests/integration/readRoutes.test.ts`

**Routes:** `/markets`, `/market-summary`, `/market-status`, `/stocks`, and the 8 per-stock reads (`/quote`, `/history`, `/technical`, `/fundamentals`, `/evaluation`, `/news`, `/sentiment`, `/analysis`, `/ai-summary`).

**Interfaces — Consumes:** the DTOs and queries from Task 4, `freshness` from Task 1, `limit('reads')` from Task 3.

- [ ] **Step 1: Write the failing test** `readRoutes.test.ts`. It builds the app once over a transaction with `AUTH_MODE=none` and covers:

```ts
  it('resolves a symbol case-insensitively and 404s an unknown one', async () => {
    expect((await get('/api/stocks/reliance/quote')).statusCode).toBe(200);
    const missing = await get('/api/stocks/NOSUCHSTOCK/quote');
    expect(missing.statusCode).toBe(404);
    expect(missing.json()).toMatchObject({ error: { code: 'NOT_FOUND' } });
  });

  it('carries freshness in meta on every quote', async () => {
    const r = await get('/api/stocks/RELIANCE/quote');
    expect(r.json().meta.freshness).toMatchObject({ market_open: expect.any(Boolean) });
  });

  it('filters the stock list by query, sector and action state', async () => {
    expect((await get('/api/stocks?query=RELI')).json().data.map((s) => s.symbol)).toContain('RELIANCE');
    // Sectors are NSE's own names, from the Phase 1 seed: 'Financial Services',
    // 'Information Technology', 'Automobile and Auto Components', ... (verified against the DB).
    const fin = await get('/api/stocks?sector=Financial%20Services');
    expect(fin.json().data.length).toBeGreaterThan(0);
    expect(fin.json().data.every((s) => s.sector === 'Financial Services')).toBe(true);
    // action filters on the deterministic action_state enum (HOLD, AVOID, WAIT_FOR_PULLBACK, ...).
    expect((await get('/api/stocks?action=HOLD')).statusCode).toBe(200);
    expect((await get('/api/stocks?action=NOT_A_STATE')).statusCode).toBe(400);
  });

  it('validates range and interval together on /history', async () => {
    expect((await get('/api/stocks/RELIANCE/history?range=1Y&interval=1d')).statusCode).toBe(200);
    // 5m bars only exist for the last ~60 days; a 5Y request for them cannot be served honestly.
    expect((await get('/api/stocks/RELIANCE/history?range=5Y&interval=5m')).statusCode).toBe(400);
    expect((await get('/api/stocks/RELIANCE/history?range=10Y')).statusCode).toBe(400);
  });

  it('returns 200 with null sections when a stock has no fundamentals, news or analysis', async () => {
    // PRD §17: missing data is a normal state, not an error. A 500 here would blank the dashboard.
    await isolateTables(trx, 'fundamental_snapshots', 'news', 'stock_ai_analysis');
    for (const path of ['fundamentals', 'news', 'analysis', 'ai-summary', 'sentiment']) {
      const r = await get(`/api/stocks/RELIANCE/${path}`);
      expect(r.statusCode, path).toBe(200);
    }
  });

  it('lists index cards with quotes and the market status', async () => {
    const r = await get('/api/markets');
    expect(r.statusCode).toBe(200);
    expect(r.json().data.map((m) => m.symbol)).toContain('NIFTY50');
    const status = await get('/api/market-status');
    expect(status.json().data).toMatchObject({ exchange: 'NSE', is_open: expect.any(Boolean) });
  });
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (routes not registered).

- [ ] **Step 3: Implement.** Each handler is: `parseParams` → resolve the symbol through `StockRepository.findBySymbol` (404 if absent) → one repository call → DTO → `ok(data, meta(mode, now, freshness))`. The quote route caches 30 s per `(symbol, mode)`; nothing else caches yet. `/history` validates `range` against `interval` from a small table (`1D→5m|15m`, `1W|1M→15m|1d`, `3M..5Y→1d`), which is where the Phase 3 provider lookback limits become an API contract.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): market and per-stock read routes with freshness`.

---

### Task 6: `StockAggregateService` — the whole decision, from stored rows

**Files:** Create `backend/src/services/StockAggregateService.ts`. Test: `backend/tests/integration/stockAggregateService.test.ts`.

**Interfaces — Produces:** `StockAggregateService.build(symbol): Promise<StockAggregate | null>` returning the PRD §12 shape: `{ stock, quote, performance, technical, fundamental, valuation, decision, news[], sentiment, ai_analysis, signal, market_context, data_freshness }`.

**The hard constraint** (Review Focus 1): this service **must not** use `StockContextService` or `Retriever`. Both embed the query, which costs money on every call — `ai:budget` already records 108 `query_embedding` calls from CLI use. The aggregate reads: `stocks`, latest `market_data`, `technical_indicators`, `fundamental_snapshots`, `stock_evaluations` (which already carries valuation, levels and action state), `news` + `news_ai_analysis`, `stock_ai_analysis`, `ai_trade_signals`, and the NIFTY `market_ai_summary` for `market_context`.

**Sections fail independently.** Every section is `T | null`; one missing input never fails the request. `insufficient_data` style reporting stays inside the AI analysis row where Phase 7 put it.

- [ ] **Step 1: Write the failing test.** Key cases:

```ts
  it('assembles every section for a fully loaded stock', async () => {
    const a = await service.build('RELIANCE');
    // The PRD §12 aggregate keys, all 13 of them. Phase 10 renders exactly this shape, so the
    // key set is the contract — a renamed or dropped section must fail here, not in the browser.
    expect(Object.keys(a ?? {}).sort()).toEqual([
      'ai_analysis', 'data_freshness', 'decision', 'fundamental', 'market_context', 'news',
      'performance', 'quote', 'sentiment', 'signal', 'stock', 'technical', 'valuation',
    ]);
    expect(a?.stock).toMatchObject({ symbol: 'RELIANCE', exchange: 'NSE' });
    expect(a?.quote).toMatchObject({ close: expect.any(Number), ts: expect.any(String) });
    expect(a?.decision).toMatchObject({ action_state: expect.any(String) });
  });

  it('returns null for an unknown symbol, so the route can 404', async () => {
    expect(await service.build('NOSUCHSTOCK')).toBeNull();
  });

  it('keeps the other sections when fundamentals, news, analysis and signals are absent', async () => {
    await isolateTables(trx, 'fundamental_snapshots', 'financial_statements', 'news',
      'news_ai_analysis', 'stock_ai_analysis', 'ai_trade_signals');
    const a = await service.build('RELIANCE');
    expect(a?.stock.symbol).toBe('RELIANCE');
    expect(a?.quote).not.toBeNull();
    expect(a?.fundamental).toBeNull();
    expect(a?.ai_analysis).toBeNull();
    expect(a?.signal).toBeNull();
    expect(a?.news).toEqual([]);
  });

  it('never calls the LLM provider', async () => {
    // The whole point: this is a page-load path. Phase 7's budget exists because these calls
    // cost money; an aggregate that embedded a query would charge for every dashboard refresh.
    const throwing = {
      name: 'throwing', chatModel: 'x', embeddingModel: 'y', embeddingDimensions: 1536,
      embed: async () => { throw new Error('LLM called'); },
      completeStructured: async () => { throw new Error('LLM called'); },
    };
    const c = createContainer(config, { db: trx, logger: silentLogger, llmProvider: throwing });
    await expect(new StockAggregateService(/* from c */).build('RELIANCE')).resolves.not.toBeNull();
  });

  it('reports per-section freshness', async () => {
    const a = await service.build('RELIANCE');
    expect(a?.data_freshness).toMatchObject({
      quote: expect.objectContaining({ market_open: expect.any(Boolean) }),
      evaluation: expect.anything(),
    });
  });

  it('computes performance windows from stored bars only', async () => {
    // 1D/1W/1M/3M/1Y returns against the earliest bar at or before each cutoff; null when the
    // history does not reach back that far, never a fabricated 0%.
    const a = await service.build('RELIANCE');
    expect(a?.performance).toMatchObject({ '1d': expect.anything(), '1y': expect.anything() });
  });
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL.

- [ ] **Step 3: Implement.** Fetch the sections with `Promise.all`, each wrapped so a rejection becomes `null` plus a logged warning — a single slow or broken section must not take the page down. `performance` is the one computation here, and it is arithmetic over stored closes (no indicator maths: that is Phase 5's and already stored).

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): StockAggregateService over stored rows, sections failing independently`.

---

### Task 7: `GET /stocks/:symbol`, and the no-spend proof for every read

**Files:**
- Create: `backend/src/routes/aggregate.ts`
- Modify: `backend/src/app.ts`, `backend/src/container.ts`
- Test: `backend/tests/integration/aggregateRoute.test.ts`, `backend/tests/integration/readsNeverSpend.test.ts`

- [ ] **Step 1: Write the failing tests.** `aggregateRoute.test.ts` checks the route returns the full shape, 404s an unknown symbol, caches for 60 s (a second call within the window does not re-query — assert through a counting repository or a spy on the service), and carries `data_freshness`.

`readsNeverSpend.test.ts` is the Review Focus 1 gate, and it covers the whole surface rather than one route:

```ts
it('no GET route calls the LLM provider', async () => {
  // PRD §14's first rule: the LLM is never called on page load. This is the regression test —
  // any future read route that reaches for the retriever fails here rather than on your bill.
  let calls = 0;
  // The real interface (providers/llm/types.ts): name, chatModel, embeddingModel,
  // embeddingDimensions, completeStructured(), embed().
  const throwing: LLMProvider = {
    name: 'throwing',
    chatModel: 'throwing-chat',
    embeddingModel: 'throwing-embed',
    embeddingDimensions: 1536,
    embed: async () => { calls += 1; throw new Error('embed called from a GET route'); },
    completeStructured: async () => { calls += 1; throw new Error('completeStructured called from a GET route'); },
  };
  const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
    db: trx, logger: silentLogger, llmProvider: throwing,
  });
  const app = await buildApp(container);
  const paths = [
    '/api/markets', '/api/market-summary', '/api/market-status', '/api/stocks',
    '/api/stocks/RELIANCE', '/api/stocks/RELIANCE/quote',
    '/api/stocks/RELIANCE/history?range=1M&interval=1d',
    '/api/stocks/RELIANCE/technical', '/api/stocks/RELIANCE/fundamentals',
    '/api/stocks/RELIANCE/evaluation', '/api/stocks/RELIANCE/news',
    '/api/stocks/RELIANCE/sentiment', '/api/stocks/RELIANCE/analysis',
    '/api/stocks/RELIANCE/ai-summary', '/api/system-status', '/api/health',
  ];
  for (const path of paths) {
    const r = await app.inject({ method: 'GET', url: path });
    // 200, not "< 500": a mistyped path would 404 and prove nothing about spending.
    expect(r.statusCode, path).toBe(200);
  }
  expect(calls).toBe(0);
});
```

Two things this test needs to be real:

- **Assert 200, never `< 500`.** A 404 from a mistyped path would otherwise satisfy the assertion while exercising nothing. `/system-status` therefore needs the recording `jobQueue` override here too (and its liveness check must degrade to `unknown` rather than throwing, see Task 8), and the transaction must have the seeded data the reads expect.
- **Derive the path list from the router**, not by hand: a new GET route that nobody adds to `paths` is a route this test does not cover. Read the registered routes (`app.printRoutes({ commonPrefix: false })` or Fastify's route table) and fail when a registered `GET /api/*` is absent from `paths`, so the gap is a test failure rather than a silent hole.

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.
- [ ] **Step 3: Implement** the route (thin: service → 404 or envelope) and wire `services.aggregate` into the container.
- [ ] **Step 4: Run the gate.** Expected: PASS, with `calls` 0.
- [ ] **Step 5: Commit** `feat(backend): aggregate stock route, and a test that no read route can spend money`.

---

### Task 8: Actions, `/system-status`, and the API-side job queue

**Files:**
- Create: `backend/src/routes/{actions,systemStatus}.ts`, `backend/src/services/SystemHealthService.ts`
- Modify: `backend/src/jobs/PgBossQueue.ts` (`schedule`/`supervise` options, `workerLiveness`), `backend/src/container.ts` (`services.jobs`, `ContainerOverrides.jobQueue`), `backend/src/jobs/runJob.ts` (honour `force` on calendar gates), `backend/src/repositories/SystemLogRepository.ts` (filtered queries)
- Test: `backend/tests/integration/{actionRoutes,systemStatus}.test.ts`, `backend/tests/unit/runJobForce.test.ts`

**Interfaces — Produces:**
- `PgBossQueueOptions` gains `schedule?: boolean; supervise?: boolean` (the API passes `false` for both). `PgBossQueue.workerLiveness(): Promise<{ status: 'live' | 'down' | 'unknown'; live: number; last_heartbeat: string | null }>` is a class method, **not** part of `JobQueue`.
- `Container.services.jobs: JobQueue | null`, plus `ContainerOverrides.jobQueue` so route tests use a recording fake instead of a real queue.
- `SystemHealthService.status()` → every PRD §16 field.
- `SystemLogRepository.lastSuccessful(service)` / `recentFailures(limit)` — `recentRuns` is unfiltered, so these are new.

**Five Phase 8 gaps this task closes** (all found in review of the plan, none of them visible from Phase 8's own tests):

1. **The API must never run crons.** `PgBossQueue` currently always constructs pg-boss with scheduling and maintenance on. The API gets `schedule: false, supervise: false` and never calls `work()` or `applySchedules()`; the worker keeps both. Phase 8's architecture note already promised this.
2. **A deduplicated send needs a defined response** (Deviation 3): `202 {job_id: null, already_queued: true}`.
3. **`symbols` must not be silently dropped.** `intradaySyncJob`/`eodSyncJob` take `_payload`, so `POST /sync/market {symbols}` would accept and ignore it. Pass it through to `marketData.sync`, since the service already supports `symbols`.
4. **Manual triggers bypass calendar gates** (Deviation 4), so pressing "Sync Market" on a Saturday does something. `runJob` skips a **calendar** refusal when `payload.manual` is true, and never skips an availability one.

   **Put the kind on the refusal, not on the gate.** `Gate` is `(at) => Promise<GateResult>` and `allGates` composes gates of different kinds, so a composed gate has no single kind — but a *refusal* always comes from exactly one gate. So `GateResult`'s refusal branch gains `kind: 'calendar' | 'availability'`:

   ```ts
   export type GateResult =
     | { run: true }
     | { run: false; kind: 'calendar' | 'availability'; reason: string };
   ```

   `tradingDayGate` and `intradayWindowGate` return `kind: 'calendar'`; `enabledGate` returns `'availability'`; `allGates` passes the first refusal through unchanged. **`afterTodaysCloseGate` returns `'availability'` deliberately**, even though it reads the calendar: its job is to stop a forced end-of-day summary being generated at the wrong time, and that must survive a manual click (Phase 8 fixed exactly that bug). Then `runJob` needs one condition — `if (!gate.run && !(payload.manual === true && gate.kind === 'calendar'))` — and nothing else in Phase 8 changes shape.

   `JobPayload` gains `manual?: boolean`. Chains never set it: `runJob` passes only what a handler puts in `next[].data`, and no handler sets `manual`.
5. **A 202 must not promise work nobody will do** (Review Focus 5): `/system-status` reports worker liveness so the dashboard can say "queued, but no worker is running".

   **Counting rows in `pgboss.instance` would be wrong.** Measured: an API-style instance (`schedule: false, supervise: false`) registers itself there with a live heartbeat, so a naive count reports 1 with no worker running — defeating the whole point. And a crashed worker leaves its row behind, so presence is not liveness. The query must therefore filter:

   ```sql
   select count(*)::int as live, max(heartbeat_on) as last_heartbeat
   from <schema>.instance
   where schedule = true                                  -- a worker, not this API process
     and stopped_on is null                               -- not a clean shutdown
     and heartbeat_on > now() - interval '2 minutes'       -- not a crash
   ```

   (Verified: with an API and a worker both running, `schedule = true` selected exactly the worker; after a clean worker stop its row had `stopped_on` set.) The check is wrapped so a failure reports `status: 'unknown'` rather than 500 — worker liveness is a nicety, and it must not be able to take `/system-status` down. **Liveness stays off the `JobQueue` interface** and lives on `PgBossQueue` only; adding it to the interface would break Phase 8's `fakeQueue`, `recordingQueue` and the dry queue in `cli/job.ts`.

- [ ] **Step 1: Write the failing tests.**

`runJobForce.test.ts` (unit) pins gate semantics:

```ts
it('force skips a calendar gate but never an availability gate', async () => {
  // A manual "Sync Market" on a Saturday must do something; a manual AI run with the provider
  // switched off must still refuse, and must never bypass the budget.
  const calendar: Gate = async () => ({ run: false, kind: 'calendar', reason: 'closed' });
  const availability: Gate = async () => ({ run: false, kind: 'availability', reason: 'news provider is disabled' });
  await expect(run({ gate: calendar, payload: { manual: true } })).resolves.toMatchObject({ status: 'SUCCESS' });
  await expect(run({ gate: calendar, payload: {} })).resolves.toMatchObject({ status: 'SKIPPED' });
  await expect(run({ gate: availability, payload: { manual: true } })).resolves.toMatchObject({ status: 'SKIPPED' });
  // force is for the AI services' hash cache, never the calendar: it must not bypass a gate.
  await expect(run({ gate: calendar, payload: { force: true } })).resolves.toMatchObject({ status: 'SKIPPED' });
});
```

`actionRoutes.test.ts` (integration, with a recording `jobQueue` fake):

```ts
  it('enqueues a market sync and returns 202 with the job id', async () => {
    const r = await post('/api/sync/market', { symbols: ['RELIANCE'] });
    expect(r.statusCode).toBe(202);
    expect(r.json().data).toMatchObject({ job_id: expect.any(String), already_queued: false });
    expect(queue.sent).toEqual([
      {
        name: 'market.sync.eod',
        data: { origin: 'api', manual: true, symbols: ['RELIANCE'] },
        singletonKey: 'manual',
      },
    ]);
  });

  it('reports a deduplicated send as 202 already_queued, not as a failure', async () => {
    queue.nextReturnsNull = true;
    const r = await post('/api/sync/news', {});
    expect(r.statusCode).toBe(202);
    expect(r.json().data).toMatchObject({ job_id: null, already_queued: true });
  });

  it('rejects an unknown job name and accepts a known one', async () => {
    expect((await post('/api/jobs/not.a.job/run', {})).statusCode).toBe(400);
    expect((await post('/api/jobs/signals.expire/run', {})).statusCode).toBe(202);
  });

  it('never sends force when running an AI job manually', async () => {
    // One click on "Run AI analysis" must not force-regenerate all 20 stocks past the hash
    // cache. Only POST /ai/regenerate may set force, and it has its own 5/hour limit.
    await post('/api/jobs/ai.stock.analyze/run', {});
    expect(queue.sent.at(-1)?.data).toEqual({ origin: 'api', manual: true });
    expect(queue.sent.at(-1)?.data).not.toHaveProperty('force');
  });

  it('gives a manual send its own singleton key, so it cannot dedup into a queued cron job', async () => {
    // Cron sends use key '' (Phase 8). A keyless manual send would collapse into a queued cron
    // job, silently dropping the caller's symbols and the manual flag while reporting 202.
    await post('/api/sync/market', { symbols: ['TCS'] });
    expect(queue.sent.at(-1)?.singletonKey).toBe('manual');
  });

  it('validates the QA question length and returns a cited answer', async () => {
    expect((await post('/api/stocks/RELIANCE/qa', { question: '' })).statusCode).toBe(400);
    expect((await post('/api/stocks/RELIANCE/qa', { question: 'x'.repeat(501) })).statusCode).toBe(400);
    const r = await post('/api/stocks/RELIANCE/qa', { question: 'What is driving this stock?' });
    expect(r.statusCode).toBe(200);
    expect(r.json().data).toMatchObject({ answer: expect.any(String), sources: expect.any(Array) });
  });

  it('returns 501, not 500, when AI is disabled', async () => {
    // LLM_PROVIDER=none is a configuration, not a crash.
    const off = await buildWith({ LLM_PROVIDER: 'none' });
    expect((await off.post('/api/ai/analyze', { symbol: 'RELIANCE' })).statusCode).toBe(501);
    expect((await off.post('/api/stocks/RELIANCE/qa', { question: 'why?' })).statusCode).toBe(501);
  });

  it('never places a paper order', async () => {
    // This phase has no trading routes at all; assert the surface rather than trusting the plan.
    const routes = app.printRoutes();
    expect(routes).not.toMatch(/paper-trade|portfolio/);
  });
```

`systemStatus.test.ts`:

```ts
  it('reports providers, data mode, last syncs, failures, market status and budget', async () => {
    const d = (await get('/api/system-status')).json().data;
    expect(d).toMatchObject({
      data_mode: 'MOCK', database_status: 'up',
      market_data_provider: 'mock', news_provider: 'mock',
      fundamentals_provider: 'mock', llm_provider: 'mock',
      market_status: expect.objectContaining({ is_open: expect.any(Boolean) }),
      llm_budget: expect.objectContaining({ daily_budget_inr: expect.any(Number) }),
      worker: expect.objectContaining({ status: expect.stringMatching(/^(live|down|unknown)$/) }),
    });
  });

  it('counts only a real run as the last sync, never a SKIPPED one', async () => {
    // A market-closed SKIP is not a sync. Reporting it as last_market_sync would tell the owner
    // the data is current when nothing was fetched.
    await isolateTables(trx, 'system_logs');
    const logs = new SystemLogRepository(trx);
    const skipped = await logs.startRun({ service: 'JobRunner', jobName: 'market.sync.intraday', operation: 'x' });
    await logs.finishRun(skipped, { status: 'SKIPPED', counts: ZERO, message: 'closed' });
    expect((await get('/api/system-status')).json().data.last_market_sync).toBeNull();

    const real = await logs.startRun({ service: 'MarketDataService', jobName: 'market.sync.eod', operation: 'x' });
    await logs.finishRun(real, { status: 'SUCCESS', counts: { ...ZERO, inserted: 32 }, message: 'ok' });
    expect((await get('/api/system-status')).json().data.last_market_sync).not.toBeNull();
  });

  it('matches a CLI run too, because it keys on the service not the job name', async () => {
    // `pnpm sync:market` logs jobName 'cli.sync-market'; it is still a market sync.
    await isolateTables(trx, 'system_logs');
    const logs = new SystemLogRepository(trx);
    const cli = await logs.startRun({ service: 'MarketDataService', jobName: 'cli.sync-market', operation: 'x' });
    await logs.finishRun(cli, { status: 'PARTIAL', counts: { ...ZERO, inserted: 1 }, message: 'ok' });
    expect((await get('/api/system-status')).json().data.last_market_sync).not.toBeNull();
  });
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL.

- [ ] **Step 3: Implement.** The action handlers are each: `requireAdmin` (except QA) → validate → `enqueue` or call the AI service → envelope. `POST /ai/analyze` and `/ai/regenerate` call `AIAnalysisService.run` directly (synchronously, since the caller wants the answer) with `force` only on `regenerate`; both surface `BUDGET_EXCEEDED` as its existing 429. `SystemHealthService` assembles §16's fields, taking `llm_budget` from `LlmBudget.status()` and worker liveness from the queue.

- [ ] **Step 4: Run the gate, then exercise the API by hand**

```bash
pnpm db:reset && pnpm sync:market && pnpm sync:news && pnpm sync:fundamentals && pnpm evaluate
pnpm embed && pnpm ai:sentiment && pnpm ai:analyze && pnpm ai:market
AUTH_MODE=none pnpm dev &
curl -s localhost:4000/api/market-status | jq .data
curl -s localhost:4000/api/stocks/RELIANCE | jq '.data | keys'
curl -s localhost:4000/api/system-status | jq .data
curl -s -X POST localhost:4000/api/sync/market -H 'content-type: application/json' -d '{}' | jq .
curl -s localhost:4000/api/stocks/NOSUCHSTOCK | jq .
```

Expected: the aggregate returns all 13 sections; `/system-status` shows mock providers, the last syncs, `llm_budget` and `worker.status: "down"` with no worker running — which is the point; start `pnpm worker` and it becomes `"live"`; the sync returns 202; the unknown symbol returns a 404 envelope. Then re-run with `AUTH_MODE=jwt` and no token to confirm 401.

- [ ] **Step 5: Commit** `feat(backend): action routes, /system-status, and the API-side job queue`.

---

### Task 9: Docs and Phase 9 verification

**Files:** Modify `README.md`, `docs/architecture.md`, `docs/api.md` (new), `IMPLEMENTATION_PLAN.md`, `.env.example`.

- [ ] **Step 1: `docs/api.md`** — the full route table with request/response examples, the envelope, the error codes and their statuses, the rate limits, and how to get a token (sign up once through Supabase Auth; the first user becomes OWNER automatically).

- [ ] **Step 2: README** — a "Use the API" section: `pnpm dev`, the `AUTH_MODE=none` line for local work **with its guards stated plainly** (refused in live mode, refused off loopback, warns at startup), how to sign up for a real token, and a worked `curl` of the aggregate. Update the phase table.

- [ ] **Step 3: `docs/architecture.md`** — an "API (Phase 9)" section: the request pipeline (helmet → CORS → auth `preHandler` → rate limit `preHandler` → validate → service → envelope), why the limiter runs on `preHandler` (measured: otherwise no per-user keying), why no GET route may touch the LLM, the TTL-only caching decision, and the API-side queue's `schedule: false, supervise: false`.

- [ ] **Step 4: `IMPLEMENTATION_PLAN.md`** — Phase 9 → ✅ done with a plan link, and record the six deviations so Phase 10 and 11 do not re-litigate them (especially: paper routes belong to Phase 11).

- [ ] **Step 5: Full verification**

```bash
pnpm db:reset && pnpm db:test
pnpm format:check && pnpm typecheck && pnpm test && pnpm lint
pnpm --filter @learning-stocks/backend build
```

Expected: pgTAP PASS; the whole backend suite green; `readsNeverSpend` green with zero LLM calls.

- [ ] **Step 6: Commit** `feat(backend): API docs; mark Phase 9 complete`. Then run the final fresh review, do one fix pass, and **stop for approval before Phase 10**.

---

## Verification (end of phase)

- **Automated:** typecheck, lint, format, build; unit tests for freshness (fresh, stale, closed-market, missing), zod validation, JWT verification (expired, forged, `alg: none`, wrong issuer, wrong audience, no subject), the rate-limit table, the DTO mappers, and `force` vs gate kind; integration tests for auth and roles (no token → 401, no profile → 403, VIEWER → 403 on admin, OWNER → 202), the dev bypass and its refusals, security headers and CORS, per-route limits keyed on the user, every read route (including missing-data 200s and symbol 404s), the aggregate (all sections, independent failure, per-section freshness), the action routes (enqueue, dedup 202, unknown job 400, QA validation, 501 when AI is off, no trading routes), and `/system-status` (PRD §16 fields, SKIPPED excluded, CLI runs counted, worker liveness).
- **The money test:** `readsNeverSpend` builds the app with an LLM provider that throws on any call, hits every registered GET route, and asserts zero calls — so a future read route that reaches for the retriever fails in CI rather than on your OpenAI bill.
- **By hand:** the aggregate for RELIANCE with all 13 sections; `/system-status` reporting `worker.status: "down"` with no worker running and `"live"` once `pnpm worker` is up; a 401 in `jwt` mode without a token.
- **Not covered, by design:** no paper-trading routes (Phase 11); no live-mode run (no OpenAI key, and spending was never approved); no browser CORS check (asserted through headers, not a real browser).
