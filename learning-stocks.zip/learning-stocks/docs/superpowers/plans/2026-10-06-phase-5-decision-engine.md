# Phase 5: Technical + Decision Engine — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (Native, as in Phases 1–4) or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** For every stock, compute indicators from stored daily bars, then derive:
- trend and market regime
- support and resistance zones
- valuation
- six factor scores plus an overall score and a risk score
- entry zone, stop-loss, targets, risk/reward and a position-size hint
- an action state (BUY_ZONE / WAIT_FOR_PULLBACK / WAIT_FOR_CONFIRMATION / HOLD / REDUCE / AVOID / INSUFFICIENT_DATA) with a bias, a paper signal and a priced invalidation sentence

Everything is deterministic and explainable. Results are stored in `technical_indicators` and `stock_evaluations`, and printed by `pnpm evaluate`.

**Architecture:**
- **Pure engines** take typed inputs and do no I/O:
  - `technical/indicators.ts` wraps `trading-signals`
  - `technical/stats.ts`: date-aligned returns, beta, drawdown, percentile, interpolation
  - `technical/trend.ts`: trend and regime
  - `technical/levels.ts`: swing pivots → zones → trade levels
  - `scoring/ValuationEngine.ts`, `scoring/ScoringEngine.ts`, `scoring/DecisionEngine.ts`
- **`scoring/evaluate.ts`** (`buildEvaluation`) composes the engines into one evaluation record with a canonical `input_hash`.
- **`EvaluationService`** gathers inputs from the database, calls `buildEvaluation`, persists the result and logs the run. Market context (NIFTY 50, India VIX, sector indices) is computed once per run.

**Tech Stack:** existing Phase 2–4 stack + `trading-signals@8.3.0` (MIT, TypeScript, ESM, maintained; updated 2026-08).

**Spec:** `PRD.md` §8 (8.1 indicators, 8.2 factors, 8.3 valuation, 8.4 levels, 8.5 decision), §7.6 `stock_evaluations`/`scoring_configs`, §1 language rules; `IMPLEMENTATION_PLAN.md` Phase 5.

## Findings that shape the design (probed 2026-10-06)

- **`trading-signals@8.3.0` is accurate:**
  - It reproduces the StockCharts textbook RSI(14) series exactly: 70.53, 66.32, 66.55, 69.41, 66.36, 57.97, 62.93, 63.26, 56.06, 62.38.
  - On a 300-bar series it agrees with `technicalindicators@3.1.0` to ≥ 4 decimals for SMA, EMA, RSI, ATR, ADX, MACD, Bollinger(20,2) and Stochastic.
- **`technicalindicators` is unmaintained** (last release July 2023) and pins `@types/node@^6`.
- **First stable bar index** (0-based):

  | Indicator | First stable index |
  |---|---|
  | SMA20 | 19 |
  | SMA200 | 199 |
  | EMA20 | 19 (but **EMA returns values from bar 0**, so we gate on `isStable`) |
  | EMA200 | 199 |
  | RSI14 | 14 |
  | MACD line | 25 |
  | MACD signal/histogram | 33 |
  | Bollinger | 19 |
  | ATR14 | 13 |
  | ADX14 | 26 |
  | Stochastic (fast %K 14, %D 3) | 15 |
- **`technical_indicators` holds stocks only** (`stock_id not null`). Index context (NIFTY 50, India VIX, sector indices) is computed in memory from stored bars.
- **No LLM news sentiment exists until Phase 7** (`news_ai_analysis` is empty). The news factor is therefore null, and the null-aware weighting drops it.
- **In LIVE mode:**
  - six sector indices have no Yahoo history, so their sector-trend and relative-strength components are null;
  - IT has only 3 peers besides the stock itself, so it never gets a sector-relative valuation;
  - INFY has no INR statements, so its current P/E comes from the snapshot only.

## Deviations (need your OK)

1. **`trading-signals` instead of `technicalindicators`.** Reasons: maintained, TypeScript, ESM. It is verified in tests against textbook values and reference values computed once with `technicalindicators`. Those values are stored as constants; `technicalindicators` is not a dependency.
2. **Rubric breakpoints live in code** (`scoring/rubrics.ts`), versioned by `ENGINE_VERSION = 'engine-1'`. That version is part of `inputs` and `input_hash`, so a rubric change produces new evaluations rather than silently reusing old hashes. `scoring_configs` v1 keeps the PRD weights and thresholds.
3. **New thresholds with defaults** (read from `scoring_configs.thresholds` when present):

   | Threshold | Default |
   |---|---|
   | `vix_risk_on_max` | 20 |
   | `vix_risk_off_min` | 25 |
   | `weak_quality_max` | 40 |
   | `max_stale_sessions` | 3 |
4. **Peers = other active stocks in the same `sector`** with a positive snapshot P/E. Sector-relative valuation needs ≥ `min_sector_peers` (4) peers, excluding the stock itself.
5. **Stochastic = fast %K(14) with %D = SMA(3)** of %K, the PRD's "Stochastic (14, 3)".
6. **Position-size hint uses `app_settings.paper_initial_balance`** (₹10,00,000) as capital. It is capped so the position never costs more than that capital.
7. **News factor is null until Phase 7.** The reader (`news_ai_analysis`) is implemented now, so Phase 7 needs no change here.
8. **Each run recomputes and upserts the full daily indicator series per stock.** The series is self-healing and cheap: about 1,250 rows per stock.
9. **The decision price is the latest stored daily close.** `data_as_of` = that bar's time. If the last daily bar is more than `max_stale_sessions` completed sessions old, the state is INSUFFICIENT_DATA, so a BUY_ZONE never comes from stale data. A fresher intraday quote is a Phase 9 API concern.
10. **The P/E history trusts EPS only from its availability date:**
    - quarterly results count from period end + 45 days; annual results from period end + 60 days
    - it is dropped (with a note) when its latest P/E disagrees with the provider's P/E by more than 25%, which guards against bonus or split basis mismatches such as RELIANCE's 2024 1:1 bonus

## Global Constraints

- Everything from earlier phases still applies:
  - the gate `pnpm format && pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
  - `TZ=UTC` tests
  - no `any` or `!`
  - ESM `.js` imports
  - commits end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`
  - branch `phase-5-decision-engine`
- **Engines are pure:** no I/O, no `Date.now()`. Time arrives as an input.
- **Insufficient history leaves an indicator `null`, never extrapolated** (PRD §8.1).
- **Every stored evaluation satisfies the DB constraints:**
  - scores within 0–100
  - prices > 0
  - `entry_low ≤ entry_high`
  - `0 ≤ risk_reward < 1,000,000`
  - `position_size_hint ≥ 0`

  An invalid level set means all levels are null; the evaluation itself is never dropped.
- **Series are joined by IST trading date, never by array index** (beta, relative strength, P/E history).
- **Language:** stored text (invalidation sentences) speaks of a *bias*. It never says "guaranteed", "will definitely", "sure-shot", "certain to" or "risk-free" (PRD §1).
- **Determinism:** `input_hash` = sha256 of canonical JSON (sorted keys, numbers rounded to 6 decimals) of the evaluation inputs plus `ENGINE_VERSION` and the config version. `evaluated_at` is never part of it. Same inputs mean no new row.

## Review Focus

1. **Degenerate levels:**
   - a wide ATR pushes the stop to ≤ 0
   - no support below price
   - resistance at or below the entry zone
   - a tiny risk overflows R:R

   Expected: levels are null and the evaluation is still stored. Covered in Task 3.
2. **Misaligned series:** a stock and an index with different missing days. Beta and relative strength must compare the same dates. Covered in Task 2.
3. **Stale or short history:** fewer than 200 daily bars, no bars at all, or a last bar older than 3 sessions. Expected: INSUFFICIENT_DATA with an explanatory invalidation, never BUY_ZONE. Covered in Tasks 6 and 9.
4. **P/E history traps:**
   - look-ahead: EPS used before its results were published
   - a bonus basis mismatch
   - negative EPS
   - INFY with no statements

   Expected: no look-ahead; mismatched history dropped with a note; a negative-EPS stock is INSUFFICIENT_DATA for valuation; INFY uses snapshot P/E plus sector peers. Covered in Task 4.
5. **Rule ordering:** inputs that match two decision rules. The first rule in PRD order wins, and a held position turns AVOID into REDUCE. Covered in Task 6.

## File structure

```
backend/src/
├── domain/enums.ts (+ Trend, RiskLevel, … types)            (Task 1)
├── utils/format.ts (formatInr)                               (Task 1)
├── technical/indicators.ts                                   (Task 1)
├── technical/stats.ts, technical/trend.ts                    (Task 2)
├── technical/levels.ts                                       (Task 3)
├── scoring/ValuationEngine.ts                                (Task 4)
├── scoring/config.ts, scoring/rubrics.ts, scoring/ScoringEngine.ts (Task 5)
├── scoring/DecisionEngine.ts                                 (Task 6)
├── scoring/evaluate.ts (buildEvaluation, canonical hash)     (Task 7)
├── repositories/{ScoringConfigRepository, TechnicalIndicatorRepository, EvaluationRepository, PaperPositionRepository}.ts
│   + MarketRepository.linksForStock, FundamentalsRepository.sectorPeerPes, NewsRepository.sentimentsForStock (Task 8)
├── services/EvaluationService.ts                             (Task 9)
└── container.ts, cli/evaluate.ts                             (Task 10)
```

---

### Task 1: Indicator series (trading-signals) + enum types + INR formatting

**Files:**
- Create:
  - `backend/src/technical/indicators.ts`
  - `backend/src/utils/format.ts`
- Modify:
  - `backend/src/domain/enums.ts` (type aliases)
  - `backend/package.json` (dependency `trading-signals@8.3.0`)
- Test: `backend/tests/unit/indicators.test.ts`, `backend/tests/unit/format.test.ts`

**Interfaces — Produces:**
- `enums.ts`: `Trend`, `RiskLevel`, `RecommendationBias`, `ActionState`, `ValuationLabel`, `MarketRegime`, `SignalType`
- `formatInr(value: number): string`, e.g. `₹12,34,567.50`
- `OhlcvBar { ts: Date; open; high; low; close; volume }`
- `IndicatorValues` (camelCase, every field `number | null`): `sma20, sma50, sma200, ema20, ema50, ema200, rsi14, macd, macdSignal, macdHistogram, bollingerUpper, bollingerMiddle, bollingerLower, atr14, adx14, stochK, stochD, volumeSma20`
- `ClassicPivots { p; r1; s1; r2; s2 }`
- `IndicatorPoint { ts: Date; values: IndicatorValues; pivots: ClassicPivots | null; vwap: number | null }`
- `computeIndicatorSeries(bars: readonly OhlcvBar[], options?: { sessionKey?: (ts: Date) => string }): IndicatorPoint[]`. `vwap` is computed only when `sessionKey` is given (intraday), resetting per session key.

- [ ] **Step 1: Branch, install, write the failing tests**

```bash
git checkout -b phase-5-decision-engine
git add docs/superpowers/plans/2026-10-06-phase-5-decision-engine.md
git commit -m "docs: Phase 5 implementation plan (technical + decision engine)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
pnpm --filter @learning-stocks/backend add trading-signals@8.3.0
```
`backend/tests/unit/format.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { formatInr } from '../../src/utils/format.js';

describe('formatInr', () => {
  it('uses Indian digit grouping with two decimals', () => {
    expect(formatInr(1234567.5)).toBe('₹12,34,567.50');
    expect(formatInr(99.999)).toBe('₹100.00');
    expect(formatInr(0.5)).toBe('₹0.50');
  });
});
```
`backend/tests/unit/indicators.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { computeIndicatorSeries, type OhlcvBar } from '../../src/technical/indicators.js';

const day = (i: number) => new Date(Date.UTC(2025, 0, 1) + i * 86_400_000);

/** Deterministic 300-bar series (Park–Miller LCG). Same generator the reference values were computed on. */
function referenceBars(): OhlcvBar[] {
  let s = 1;
  const rnd = () => {
    s = (s * 16807) % 2147483647;
    return s / 2147483647;
  };
  const bars: OhlcvBar[] = [];
  let p = 100;
  for (let i = 0; i < 300; i += 1) {
    const open = p;
    p = p * (1 + (rnd() - 0.48) * 0.04);
    const close = p;
    const high = Math.max(open, close) * (1 + rnd() * 0.01);
    const low = Math.min(open, close) * (1 - rnd() * 0.01);
    bars.push({ ts: day(i), open, high, low, close, volume: Math.round(1e5 + rnd() * 1e5) });
  }
  return bars;
}

const closesOnly = (closes: number[]): OhlcvBar[] =>
  closes.map((c, i) => ({ ts: day(i), open: c, high: c, low: c, close: c, volume: 1000 }));

describe('computeIndicatorSeries', () => {
  it('matches the StockCharts textbook RSI(14) (Wilder smoothing)', () => {
    const closes = [44.3389, 44.0902, 44.1497, 43.6124, 44.3278, 44.8264, 45.0955, 45.4245, 45.8433, 46.0826, 45.8931, 46.0328,
      45.614, 46.282, 46.282, 46.0028, 46.0328, 46.4116, 46.2222, 45.6439, 46.2122, 46.2521, 45.7137, 46.4515];
    const rsi = computeIndicatorSeries(closesOnly(closes)).map((p) => p.values.rsi14);
    expect(rsi.slice(0, 14).every((v) => v === null)).toBe(true);
    expect(rsi.slice(14).map((v) => Number(v?.toFixed(2)))).toEqual([70.53, 66.32, 66.55, 69.41, 66.36, 57.97, 62.93, 63.26, 56.06, 62.38]);
  });

  it('matches reference values (computed once with technicalindicators@3.1.0) on the last bar', () => {
    const last = computeIndicatorSeries(referenceBars()).at(-1)?.values;
    expect(last?.sma50).toBeCloseTo(117.5694, 3);
    expect(last?.ema50).toBeCloseTo(117.3485, 3);
    expect(last?.rsi14).toBeCloseTo(59.88, 1);
    expect(last?.atr14).toBeCloseTo(2.4522, 3);
    expect(last?.adx14).toBeCloseTo(28.9059, 3);
    expect(last?.macd).toBeCloseTo(2.082053, 5);
    expect(last?.macdSignal).toBeCloseTo(2.203009, 5);
    expect(last?.macdHistogram).toBeCloseTo(-0.120956, 5);
    expect(last?.bollingerUpper).toBeCloseTo(127.306685, 4);
    expect(last?.bollingerMiddle).toBeCloseTo(121.208378, 4);
    expect(last?.bollingerLower).toBeCloseTo(115.110071, 4);
    expect(last?.stochK).toBeCloseTo(74.450752, 4);
    expect(last?.stochD).toBeCloseTo(70.456158, 4);
  });

  it('leaves every indicator null until it has enough history (never extrapolated)', () => {
    const series = computeIndicatorSeries(referenceBars());
    const firstNonNull = (key: keyof (typeof series)[number]['values']) => series.findIndex((p) => p.values[key] !== null);
    expect(firstNonNull('sma20')).toBe(19);
    expect(firstNonNull('sma200')).toBe(199);
    expect(firstNonNull('ema20')).toBe(19);
    expect(firstNonNull('ema200')).toBe(199);
    expect(firstNonNull('rsi14')).toBe(14);
    expect(firstNonNull('macd')).toBe(25);
    expect(firstNonNull('macdSignal')).toBe(33);
    expect(firstNonNull('macdHistogram')).toBe(33);
    expect(firstNonNull('bollingerUpper')).toBe(19);
    expect(firstNonNull('atr14')).toBe(13);
    expect(firstNonNull('adx14')).toBe(26);
    expect(firstNonNull('stochK')).toBe(15);
    expect(firstNonNull('volumeSma20')).toBe(19);
    expect(computeIndicatorSeries(referenceBars().slice(0, 150)).at(-1)?.values.sma200).toBeNull();
  });

  it('never emits NaN: flat, circuit-locked bars give null instead of a non-finite value', () => {
    const flat = Array.from({ length: 60 }, (_, i) => ({ ts: day(i), open: 100, high: 100, low: 100, close: 100, volume: 0 }));
    for (const p of computeIndicatorSeries(flat)) {
      for (const v of Object.values(p.values)) expect(v === null || Number.isFinite(v)).toBe(true);
    }
  });

  it('computes classic floor pivots from the previous bar', () => {
    const bars: OhlcvBar[] = [
      { ts: day(0), open: 100, high: 110, low: 90, close: 105, volume: 1 },
      { ts: day(1), open: 105, high: 108, low: 101, close: 107, volume: 1 },
    ];
    const [first, second] = computeIndicatorSeries(bars);
    expect(first?.pivots).toBeNull();
    expect(second?.pivots).toEqual({ p: 101.6667, r1: 113.3333, s1: 93.3333, r2: 121.6667, s2: 81.6667 });
  });

  it('computes session VWAP only when a session key is given, resetting each session', () => {
    const bar = (i: number, price: number, volume: number): OhlcvBar => ({ ts: new Date(Date.UTC(2026, 9, 5, 4, i * 5)), open: price, high: price, low: price, close: price, volume });
    const bars = [bar(0, 100, 10), bar(1, 110, 30), { ...bar(2, 200, 10), ts: new Date(Date.UTC(2026, 9, 6, 4, 0)) }];
    expect(computeIndicatorSeries(bars).map((p) => p.vwap)).toEqual([null, null, null]);
    const vwap = computeIndicatorSeries(bars, { sessionKey: (ts) => ts.toISOString().slice(0, 10) }).map((p) => p.vwap);
    expect(vwap).toEqual([100, 107.5, 200]);
    const indexBars = bars.map((b) => ({ ...b, volume: 0 }));
    expect(computeIndicatorSeries(indexBars, { sessionKey: (ts) => ts.toISOString().slice(0, 10) }).map((p) => p.vwap)).toEqual([null, null, null]);
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`. Expected: FAIL (modules not found).

- [ ] **Step 3: Implement**

Append to `backend/src/domain/enums.ts`:
```ts
export type Trend = (typeof TRENDS)[number];
export type RiskLevel = (typeof RISK_LEVELS)[number];
export type RecommendationBias = (typeof RECOMMENDATION_BIASES)[number];
export type ActionState = (typeof ACTION_STATES)[number];
export type ValuationLabel = (typeof VALUATION_LABELS)[number];
export type MarketRegime = (typeof MARKET_REGIMES)[number];
export type SignalType = (typeof SIGNAL_TYPES)[number];
```
`backend/src/utils/format.ts`:
```ts
const INR = new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** ₹ with Indian digit grouping: 1234567.5 → ₹12,34,567.50. */
export function formatInr(value: number): string {
  return `₹${INR.format(value)}`;
}
```
`backend/src/technical/indicators.ts`:
```ts
import { ADX, ATR, BollingerBands, EMA, MACD, RSI, SMA, StochasticOscillator } from 'trading-signals';

export interface OhlcvBar {
  ts: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IndicatorValues {
  sma20: number | null;
  sma50: number | null;
  sma200: number | null;
  ema20: number | null;
  ema50: number | null;
  ema200: number | null;
  rsi14: number | null;
  macd: number | null;
  macdSignal: number | null;
  macdHistogram: number | null;
  bollingerUpper: number | null;
  bollingerMiddle: number | null;
  bollingerLower: number | null;
  atr14: number | null;
  adx14: number | null;
  stochK: number | null;
  stochD: number | null;
  volumeSma20: number | null;
}

/** Classic floor pivots from the previous bar. */
export interface ClassicPivots {
  p: number;
  r1: number;
  s1: number;
  r2: number;
  s2: number;
}

export interface IndicatorPoint {
  ts: Date;
  values: IndicatorValues;
  pivots: ClassicPivots | null;
  /** Session VWAP (intraday only); null for daily bars and zero-volume instruments. */
  vwap: number | null;
}

const r4 = (n: number) => Math.round(n * 10_000) / 10_000;

function pivotsFrom(prev: OhlcvBar): ClassicPivots {
  const p = (prev.high + prev.low + prev.close) / 3;
  const range = prev.high - prev.low;
  return { p: r4(p), r1: r4(2 * p - prev.low), s1: r4(2 * p - prev.high), r2: r4(p + range), s2: r4(p - range) };
}

interface Stable {
  readonly isStable: boolean;
}
const finite = (value: number | null | undefined): number | null =>
  typeof value === 'number' && Number.isFinite(value) ? value : null;
/**
 * trading-signals returns values before an indicator is stable (EMA from bar 0); we never use those.
 * Non-finite values (e.g. NaN from zero-range, circuit-locked bars) become null: Postgres would reject them.
 */
const stable = (indicator: Stable, value: number | null | undefined): number | null => (indicator.isStable ? finite(value) : null);

/**
 * PRD §8.1 indicators for every bar (oldest first). An indicator is null until it has enough
 * history — never extrapolated. Verified against textbook and reference values in tests.
 */
export function computeIndicatorSeries(
  bars: readonly OhlcvBar[],
  options: { sessionKey?: (ts: Date) => string } = {},
): IndicatorPoint[] {
  const sma20 = new SMA(20);
  const sma50 = new SMA(50);
  const sma200 = new SMA(200);
  const ema20 = new EMA(20);
  const ema50 = new EMA(50);
  const ema200 = new EMA(200);
  const rsi14 = new RSI(14);
  const macd = new MACD(new EMA(12), new EMA(26), new EMA(9));
  const bollinger = new BollingerBands(20, 2);
  const atr14 = new ATR(14);
  const adx14 = new ADX(14);
  const stoch = new StochasticOscillator({ kPeriod: 14, kSlowingPeriod: 1, dPeriod: 3 });
  const volumeSma20 = new SMA(20);

  let session: string | null = null;
  let cumPv = 0;
  let cumVolume = 0;

  return bars.map((bar, i) => {
    const candle = { high: bar.high, low: bar.low, close: bar.close };
    const m = macd.update(bar.close, false);
    const bb = bollinger.update(bar.close, false);
    const st = stoch.update(candle, false);
    const signalReady = macd.isStable && macd.signal.isStable;
    const values: IndicatorValues = {
      sma20: stable(sma20, sma20.update(bar.close, false)),
      sma50: stable(sma50, sma50.update(bar.close, false)),
      sma200: stable(sma200, sma200.update(bar.close, false)),
      ema20: stable(ema20, ema20.update(bar.close, false)),
      ema50: stable(ema50, ema50.update(bar.close, false)),
      ema200: stable(ema200, ema200.update(bar.close, false)),
      rsi14: stable(rsi14, rsi14.update(bar.close, false)),
      macd: stable(macd, m?.macd),
      macdSignal: signalReady ? finite(m?.signal) : null,
      macdHistogram: signalReady ? finite(m?.histogram) : null,
      bollingerUpper: stable(bollinger, bb?.upper),
      bollingerMiddle: stable(bollinger, bb?.middle),
      bollingerLower: stable(bollinger, bb?.lower),
      atr14: stable(atr14, atr14.update(candle, false)),
      adx14: stable(adx14, adx14.update(candle, false)),
      stochK: stable(stoch, st?.stochK),
      stochD: stable(stoch, st?.stochD),
      volumeSma20: stable(volumeSma20, volumeSma20.update(bar.volume, false)),
    };

    let vwap: number | null = null;
    if (options.sessionKey) {
      const key = options.sessionKey(bar.ts);
      if (key !== session) {
        session = key;
        cumPv = 0;
        cumVolume = 0;
      }
      cumPv += ((bar.high + bar.low + bar.close) / 3) * bar.volume;
      cumVolume += bar.volume;
      vwap = cumVolume > 0 ? r4(cumPv / cumVolume) : null;
    }
    const prev = bars[i - 1];
    return { ts: bar.ts, values, pivots: prev ? pivotsFrom(prev) : null, vwap };
  });
}
```
If `trading-signals`' types reject `macd.signal.isStable` (the property is `EMA | DEMA`, both of which have `isStable`) or the `update(..., false)` arity, adapt within this file and record a ruling.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): indicator series via trading-signals, verified against textbook and reference values`.

---

### Task 2: Date-aligned statistics, trend and market regime

**Files:**
- Create: `backend/src/technical/stats.ts`, `backend/src/technical/trend.ts`
- Test: `backend/tests/unit/stats.test.ts`, `backend/tests/unit/trend.test.ts`

**Interfaces — Produces:**
- `stats.ts`:
  - `DatedClose { date: string; close: number }` (IST date, ascending)
  - `interpolate(x, points)`: piecewise-linear, clamped at both ends
  - `round(x, decimals)`
  - `clampScore(x)`: 0–100, 2 decimals
  - `percentileRank(values, x)`: % of values ≤ x, or null if empty
  - `returnPct(series, sessionsBack)`
  - `returnSince(series, fromDate)`: last close vs the close on or before `fromDate`
  - `relativeStrength(stock, index, sessionsBack)`: the stock's return minus the index's return over the same dates
  - `beta(stock, index, sessions = 250)`: on common dates only; needs ≥ 120 paired returns
  - `maxDrawdownPct(closes)`: positive percent
  - `weightedMean(parts)`: weighted mean of the non-null parts, or null
- `trend.ts`:
  - `SMA200_SLOPE_LOOKBACK = 20`
  - `classifyTrend({ close, sma50, sma200, sma200Prev }): Trend | null`
  - `classifyRegime({ niftyTrend, vix }, { vixRiskOnMax, vixRiskOffMin }): MarketRegime | null`

- [ ] **Step 1: Write the failing tests**

`backend/tests/unit/stats.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import {
  beta, clampScore, type DatedClose, interpolate, maxDrawdownPct, percentileRank, relativeStrength, returnPct, returnSince, weightedMean,
} from '../../src/technical/stats.js';

const dated = (closes: number[], start = 0, skip: number[] = []): DatedClose[] =>
  closes
    .map((close, i) => ({ date: new Date(Date.UTC(2025, 0, 1) + (start + i) * 86_400_000).toISOString().slice(0, 10), close }))
    .filter((_, i) => !skip.includes(i));

describe('stats', () => {
  it('interpolates piecewise-linearly and clamps at the ends', () => {
    const pts = [[0, 0], [10, 100]] as const;
    expect(interpolate(5, pts)).toBe(50);
    expect(interpolate(-5, pts)).toBe(0);
    expect(interpolate(50, pts)).toBe(100);
    expect(interpolate(15, [[10, 0], [20, 100], [30, 0]])).toBe(50);
  });

  it('clamps and rounds scores; ranks percentiles; drops null parts in weighted means', () => {
    expect(clampScore(104.123)).toBe(100);
    expect(clampScore(-3)).toBe(0);
    expect(clampScore(33.3333)).toBe(33.33);
    expect(percentileRank([10, 20, 30, 40], 20)).toBe(50);
    expect(percentileRank([], 20)).toBeNull();
    expect(weightedMean([[80, 1], [null, 5], [40, 3]])).toBe(50);
    expect(weightedMean([[null, 1]])).toBeNull();
  });

  it('computes returns over sessions and since a date', () => {
    const s = dated([100, 110, 121]);
    expect(returnPct(s, 2)).toBeCloseTo(21, 9);
    expect(returnPct(s, 5)).toBeNull();
    expect(returnSince(s, s[1]?.date ?? '')).toBeCloseTo(10, 9);
  });

  it('aligns stock and index by date, not array position (index missing a day)', () => {
    const closes = Array.from({ length: 200 }, (_, i) => 100 * (1 + 0.01 * Math.sin(i / 3)) * (1 + i / 1000));
    const stock = dated(closes);
    const index = dated(closes, 0, [57]); // the index lacks day 57
    expect(beta(stock, index)).toBeCloseTo(1, 9);
    expect(relativeStrength(stock, index, 100)).toBeCloseTo(0, 9);
  });

  it('needs enough paired returns for beta and measures max drawdown', () => {
    expect(beta(dated([1, 2, 3]), dated([1, 2, 3]))).toBeNull();
    expect(maxDrawdownPct([100, 120, 90, 130, 104])).toBeCloseTo(25, 9);
    expect(maxDrawdownPct([])).toBeNull();
  });
});
```
`backend/tests/unit/trend.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { classifyRegime, classifyTrend } from '../../src/technical/trend.js';

const T = { vixRiskOnMax: 20, vixRiskOffMin: 25 };

describe('classifyTrend', () => {
  it('needs close > SMA50 > SMA200 with a rising SMA200 for an uptrend (and the mirror for a downtrend)', () => {
    expect(classifyTrend({ close: 120, sma50: 110, sma200: 100, sma200Prev: 98 })).toBe('UPTREND');
    expect(classifyTrend({ close: 120, sma50: 110, sma200: 100, sma200Prev: 101 })).toBe('SIDEWAYS');
    expect(classifyTrend({ close: 80, sma50: 90, sma200: 100, sma200Prev: 102 })).toBe('DOWNTREND');
    expect(classifyTrend({ close: 95, sma50: 105, sma200: 100, sma200Prev: 99 })).toBe('SIDEWAYS');
    expect(classifyTrend({ close: 95, sma50: 105, sma200: null, sma200Prev: null })).toBeNull();
  });
});

describe('classifyRegime', () => {
  it('is RISK_OFF on a NIFTY downtrend or high VIX, RISK_ON on an uptrend with calm VIX', () => {
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: 14 }, T)).toBe('RISK_ON');
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: 22 }, T)).toBe('NEUTRAL');
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: 27 }, T)).toBe('RISK_OFF');
    expect(classifyRegime({ niftyTrend: 'DOWNTREND', vix: 12 }, T)).toBe('RISK_OFF');
    expect(classifyRegime({ niftyTrend: 'SIDEWAYS', vix: null }, T)).toBe('NEUTRAL');
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: null }, T)).toBe('RISK_ON');
    expect(classifyRegime({ niftyTrend: null, vix: null }, T)).toBeNull();
  });
});
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/technical/stats.ts`

```ts
/** One daily close keyed by its IST trading date (YYYY-MM-DD). Series are ascending by date. */
export interface DatedClose {
  date: string;
  close: number;
}

export const round = (x: number, decimals: number): number => {
  const f = 10 ** decimals;
  return Math.round(x * f) / f;
};

export const clampScore = (x: number): number => round(Math.min(100, Math.max(0, x)), 2);

/** Piecewise-linear interpolation through ascending (x, y) points, clamped beyond the ends. */
export function interpolate(x: number, points: ReadonlyArray<readonly [number, number]>): number {
  const first = points[0];
  const last = points[points.length - 1];
  if (!first || !last) throw new RangeError('interpolate needs at least one point');
  if (x <= first[0]) return first[1];
  if (x >= last[0]) return last[1];
  for (let i = 1; i < points.length; i += 1) {
    const a = points[i - 1];
    const b = points[i];
    if (a && b && x <= b[0]) return a[1] + ((x - a[0]) / (b[0] - a[0])) * (b[1] - a[1]);
  }
  return last[1];
}

/** Share of values ≤ x, in percent. */
export function percentileRank(values: readonly number[], x: number): number | null {
  if (values.length === 0) return null;
  return (values.filter((v) => v <= x).length / values.length) * 100;
}

/** Weighted mean of the parts that are present; null when none are. */
export function weightedMean(parts: ReadonlyArray<readonly [number | null, number]>): number | null {
  let sum = 0;
  let weights = 0;
  for (const [value, weight] of parts) {
    if (value === null || weight <= 0) continue;
    sum += value * weight;
    weights += weight;
  }
  return weights > 0 ? sum / weights : null;
}

export function returnPct(series: readonly DatedClose[], sessionsBack: number): number | null {
  const last = series[series.length - 1];
  const base = series[series.length - 1 - sessionsBack];
  if (!last || !base || base.close <= 0) return null;
  return (last.close / base.close - 1) * 100;
}

/** Return from the close on (or the last one before) fromDate to the latest close. */
export function returnSince(series: readonly DatedClose[], fromDate: string): number | null {
  const last = series[series.length - 1];
  let base: DatedClose | undefined;
  for (const point of series) {
    if (point.date > fromDate) break;
    base = point;
  }
  if (!last || !base || base.close <= 0) return null;
  return (last.close / base.close - 1) * 100;
}

/** Stock return minus index return over the same calendar window (date-aligned). */
export function relativeStrength(stock: readonly DatedClose[], index: readonly DatedClose[], sessionsBack: number): number | null {
  const from = stock[stock.length - 1 - sessionsBack];
  if (!from) return null;
  const s = returnSince(stock, from.date);
  const i = returnSince(index, from.date);
  return s === null || i === null ? null : s - i;
}

function commonCloses(a: readonly DatedClose[], b: readonly DatedClose[]): Array<[number, number]> {
  const byDate = new Map(b.map((p) => [p.date, p.close]));
  const out: Array<[number, number]> = [];
  for (const p of a) {
    const other = byDate.get(p.date);
    if (other !== undefined) out.push([p.close, other]);
  }
  return out;
}

const MIN_BETA_RETURNS = 120;

/** Beta of stock vs index from daily returns on dates both series traded. */
export function beta(stock: readonly DatedClose[], index: readonly DatedClose[], sessions = 250): number | null {
  const pairs = commonCloses(stock, index).slice(-(sessions + 1));
  const rs: number[] = [];
  const ri: number[] = [];
  for (let k = 1; k < pairs.length; k += 1) {
    const prev = pairs[k - 1];
    const cur = pairs[k];
    if (!prev || !cur || prev[0] <= 0 || prev[1] <= 0) continue;
    rs.push(cur[0] / prev[0] - 1);
    ri.push(cur[1] / prev[1] - 1);
  }
  if (rs.length < MIN_BETA_RETURNS) return null;
  const mean = (xs: number[]) => xs.reduce((s, x) => s + x, 0) / xs.length;
  const ms = mean(rs);
  const mi = mean(ri);
  let cov = 0;
  let varI = 0;
  for (let k = 0; k < rs.length; k += 1) {
    const di = (ri[k] ?? 0) - mi;
    cov += ((rs[k] ?? 0) - ms) * di;
    varI += di * di;
  }
  return varI > 0 ? cov / varI : null;
}

/** Largest peak-to-trough fall, in percent (positive). */
export function maxDrawdownPct(closes: readonly number[]): number | null {
  if (closes.length === 0) return null;
  let peak = closes[0] ?? 0;
  let worst = 0;
  for (const c of closes) {
    peak = Math.max(peak, c);
    if (peak > 0) worst = Math.max(worst, (peak - c) / peak);
  }
  return worst * 100;
}
```
`backend/src/technical/trend.ts`:
```ts
import type { MarketRegime, Trend } from '../domain/enums.js';

/** SMA200 slope = SMA200 now vs this many sessions earlier. */
export const SMA200_SLOPE_LOOKBACK = 20;

export interface TrendInputs {
  close: number | null;
  sma50: number | null;
  sma200: number | null;
  sma200Prev: number | null;
}

/** UPTREND: close > SMA50 > SMA200 with SMA200 rising; DOWNTREND: the mirror; otherwise SIDEWAYS. */
export function classifyTrend(i: TrendInputs): Trend | null {
  const { close, sma50, sma200, sma200Prev } = i;
  if (close === null || sma50 === null || sma200 === null || sma200Prev === null) return null;
  if (close > sma50 && sma50 > sma200 && sma200 > sma200Prev) return 'UPTREND';
  if (close < sma50 && sma50 < sma200 && sma200 < sma200Prev) return 'DOWNTREND';
  return 'SIDEWAYS';
}

export interface RegimeThresholds {
  vixRiskOnMax: number;
  vixRiskOffMin: number;
}

/** Market regime from the NIFTY 50 trend and India VIX. */
export function classifyRegime(i: { niftyTrend: Trend | null; vix: number | null }, t: RegimeThresholds): MarketRegime | null {
  if (i.niftyTrend === null && i.vix === null) return null;
  if (i.niftyTrend === 'DOWNTREND' || (i.vix !== null && i.vix >= t.vixRiskOffMin)) return 'RISK_OFF';
  if (i.niftyTrend === 'UPTREND' && (i.vix === null || i.vix < t.vixRiskOnMax)) return 'RISK_ON';
  return 'NEUTRAL';
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): date-aligned return statistics, trend and market regime`.

---

### Task 3: Support/resistance levels and trade levels

**Files:** Create `backend/src/technical/levels.ts`. Test: `backend/tests/unit/levels.test.ts`.

**Interfaces:**
- Consumes: `Trend`, `round`.
- Produces:
  - `LevelBar { high; low; close }`
  - `Zone { low; high; mid; touches; sources: string[] }`
  - `TradeLevels { entryLow; entryHigh; stop; target1; target2; riskReward; positionSizeHint; basis: 'SUPPORT' | 'PULLBACK_BAND' }`
  - `LevelsInput { bars; price; atr; sma20; sma50; sma200; trend; capital; riskPct; stopAtrMultiple; entryAtrWidth }`
  - `LevelsResult { supports: Zone[]; resistances: Zone[]; trade: TradeLevels | null; reason: string | null }`
  - `swingPivots(bars, n)`, `clusterZones(levels, width)`, `computeLevels(input)`
  - `PIVOT_LOOKBACK = 5`, `LEVEL_WINDOW = 250`, `MAX_RISK_REWARD = 999_999.99`

PRD §8.4 rules, as implemented:
- **Zones.** Swing highs and lows (strict extremes within ±5 bars) from the last 250 bars, plus SMA50, SMA200, the 52-week high and the 52-week low. These are clustered within 0.5 × ATR. A zone whose `mid ≤ price` is support; one whose `mid > price` is resistance.
- **Entry zone.** In an UPTREND with SMA20 and SMA50 available, use the pullback band [min, max] of SMA20 and SMA50. Otherwise use the nearest support S (highest mid) → [S, S + 0.5 × ATR].
- **Stop.** The entry's base (band low or S) − 1.5 × ATR.
- **Targets.** T1 = the low of the first resistance whose low > entry high. T2 = the next resistance whose low > T1. If there is no T1: T1 = mid + 2R and T2 = mid + 3R. If there is a T1 but no T2: T2 = max(mid + 3R, T1 + R). R = mid − stop.
- **Position size.** floor(risk% × capital ÷ R), capped at floor(capital ÷ entry high).

Any invalid result (stop ≤ 0, entry ≤ 0, R:R ≥ 1,000,000) gives `trade: null` with a reason.

- [ ] **Step 1: Write the failing test** `backend/tests/unit/levels.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { clusterZones, computeLevels, type LevelBar, type LevelsInput, swingPivots } from '../../src/technical/levels.js';

/** Triangle wave between 100 and 120 (step 2, period 20); high/low = close ± 1. 60 bars, last close 102. */
function wave(): LevelBar[] {
  return Array.from({ length: 60 }, (_, i) => {
    const k = i % 20;
    const close = k <= 10 ? 100 + 2 * k : 120 - 2 * (k - 10);
    return { high: close + 1, low: close - 1, close };
  });
}

const base = (over: Partial<LevelsInput> = {}): LevelsInput => ({
  bars: wave(), price: 102, atr: 3, sma20: null, sma50: null, sma200: null, trend: 'SIDEWAYS',
  capital: 1_000_000, riskPct: 1, stopAtrMultiple: 1.5, entryAtrWidth: 0.5, ...over,
});

describe('swingPivots / clusterZones', () => {
  it('finds strict local extremes with n bars on each side', () => {
    const p = swingPivots(wave(), 5);
    expect(p.highs).toEqual([121, 121, 121]);
    expect(p.lows).toEqual([99, 99]);
  });

  it('clusters levels within the width and counts touches', () => {
    expect(clusterZones([100, 100.5, 110, 99.8], 1)).toEqual([
      { low: 99.8, high: 100.5, mid: 100.15, touches: 3, sources: [] },
      { low: 110, high: 110, mid: 110, touches: 1, sources: [] },
    ]);
  });
});

describe('computeLevels', () => {
  it('builds entry, stop, targets, R:R and size from the nearest support (PRD §8.4)', () => {
    const r = computeLevels(base());
    expect(r.reason).toBeNull();
    expect(r.trade).toEqual({
      basis: 'SUPPORT', entryLow: 99, entryHigh: 100.5, stop: 94.5,
      target1: 121, target2: 126.25, riskReward: 4.05, positionSizeHint: 1904,
    });
    expect(r.supports[0]?.mid).toBe(99);
    expect(r.resistances[0]?.low).toBe(121);
  });

  it('uses the SMA20–SMA50 pullback band in a confirmed uptrend', () => {
    const r = computeLevels(base({ trend: 'UPTREND', sma20: 105, sma50: 101 }));
    expect(r.trade).toMatchObject({ basis: 'PULLBACK_BAND', entryLow: 101, entryHigh: 105, stop: 96.5 });
  });

  it('falls back to 2R/3R targets when nothing resists above the entry', () => {
    const flat = Array.from({ length: 40 }, (_, i) => ({ high: 100 + i + 1, low: 100 + i - 1, close: 100 + i }));
    const r = computeLevels(base({ bars: flat, price: 150, trend: 'UPTREND', sma20: 139, sma50: 135 }));
    const t = r.trade;
    expect(t?.basis).toBe('PULLBACK_BAND');
    const mid = (135 + 139) / 2;
    const risk = mid - (135 - 4.5);
    expect(t?.target1).toBeCloseTo(mid + 2 * risk, 2);
    expect(t?.target2).toBeCloseTo(mid + 3 * risk, 2);
    expect(t?.riskReward).toBe(2);
  });

  it('caps the size so the position never costs more than the capital', () => {
    const r = computeLevels(base({ capital: 10_000, riskPct: 100 }));
    expect(r.trade?.positionSizeHint).toBe(Math.floor(10_000 / 100.5));
  });

  it('returns no trade (with a reason) for degenerate inputs instead of invalid prices', () => {
    expect(computeLevels(base({ atr: null })).reason).toMatch(/ATR/);
    expect(computeLevels(base({ atr: 0 })).trade).toBeNull();
    expect(computeLevels(base({ price: 50 })).reason).toMatch(/no support/);
    // ATR 80 merges every level into one zone (mid 110); at price 130 it is support, and 110 − 1.5×80 < 0.
    const wide = computeLevels(base({ atr: 80, price: 130 }));
    expect(wide.trade).toBeNull();
    expect(wide.reason).toMatch(/stop/);
    expect(computeLevels(base({ bars: wave().slice(0, 8) })).reason).toMatch(/history/);
  });
});
```
Check the first case. Swing lows: lows at i = 20 and 40 (99); swing highs at i = 10, 30, 50 (121); the 52-week low is 99 and the 52-week high 121. With width 1.5 (0.5 × ATR 3), all the 99s cluster into one zone (mid 99) and all the 121s into another. Price 102 → support 99, so entry [99, 100.5], stop 99 − 4.5 = 94.5, mid 99.75, R = 5.25. T1 = 121; there is no further resistance, so T2 = max(99.75 + 15.75, 121 + 5.25) = 126.25. R:R = 21.25 / 5.25 = 4.0476 → 4.05. Size = floor(10,000 / 5.25) = 1904. With ATR 80 every level clusters into one zone (mid 110); at price 130 that is support and the stop = 110 − 120 < 0 → no trade.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/technical/levels.ts`

```ts
import type { Trend } from '../domain/enums.js';
import { round } from './stats.js';

export const PIVOT_LOOKBACK = 5;
export const LEVEL_WINDOW = 250;
/** stock_evaluations.risk_reward is numeric(8,2). */
export const MAX_RISK_REWARD = 999_999.99;

export interface LevelBar {
  high: number;
  low: number;
  close: number;
}

export interface Zone {
  low: number;
  high: number;
  mid: number;
  touches: number;
  sources: string[];
}

export interface TradeLevels {
  basis: 'SUPPORT' | 'PULLBACK_BAND';
  entryLow: number;
  entryHigh: number;
  stop: number;
  target1: number;
  target2: number;
  riskReward: number;
  positionSizeHint: number;
}

export interface LevelsInput {
  /** Daily bars, oldest first. */
  bars: readonly LevelBar[];
  price: number;
  atr: number | null;
  sma20: number | null;
  sma50: number | null;
  sma200: number | null;
  trend: Trend | null;
  capital: number;
  riskPct: number;
  stopAtrMultiple: number;
  entryAtrWidth: number;
}

export interface LevelsResult {
  supports: Zone[];
  resistances: Zone[];
  trade: TradeLevels | null;
  reason: string | null;
}

/** Strict local extremes with n bars on each side (the last n bars cannot be confirmed yet). */
export function swingPivots(bars: readonly LevelBar[], n: number): { highs: number[]; lows: number[] } {
  const highs: number[] = [];
  const lows: number[] = [];
  for (let i = n; i < bars.length - n; i += 1) {
    const bar = bars[i];
    if (!bar) continue;
    let isHigh = true;
    let isLow = true;
    for (let j = i - n; j <= i + n; j += 1) {
      const other = bars[j];
      if (j === i || !other) continue;
      if (other.high >= bar.high) isHigh = false;
      if (other.low <= bar.low) isLow = false;
    }
    if (isHigh) highs.push(bar.high);
    if (isLow) lows.push(bar.low);
  }
  return { highs, lows };
}

/** Groups sorted levels whose gap to the previous level is within `width`. */
export function clusterZones(levels: readonly number[], width: number, sources: readonly string[] = []): Zone[] {
  const tagged = levels.map((price, i) => ({ price, source: sources[i] }));
  tagged.sort((a, b) => a.price - b.price);
  const zones: Zone[] = [];
  let current: { prices: number[]; sources: Set<string> } | null = null;
  const flush = () => {
    if (!current) return;
    const low = Math.min(...current.prices);
    const high = Math.max(...current.prices);
    zones.push({ low: round(low, 4), high: round(high, 4), mid: round((low + high) / 2, 4), touches: current.prices.length, sources: [...current.sources] });
  };
  for (const t of tagged) {
    const last = current?.prices[current.prices.length - 1];
    if (current && last !== undefined && t.price - last <= width) {
      current.prices.push(t.price);
    } else {
      flush();
      current = { prices: [t.price], sources: new Set() };
    }
    if (t.source) current.sources.add(t.source);
  }
  flush();
  return zones;
}

const none = (supports: Zone[], resistances: Zone[], reason: string): LevelsResult => ({ supports, resistances, trade: null, reason });

/** PRD §8.4: zones → entry zone, stop, targets, R:R and a position-size hint. */
export function computeLevels(input: LevelsInput): LevelsResult {
  const { atr, price } = input;
  if (atr === null || !(atr > 0)) return none([], [], 'ATR unavailable');
  const window = input.bars.slice(-LEVEL_WINDOW);
  if (window.length < 2 * PIVOT_LOOKBACK + 1) return none([], [], 'not enough history for swing levels');

  const pivots = swingPivots(window, PIVOT_LOOKBACK);
  const levels: number[] = [];
  const sources: string[] = [];
  const add = (value: number | null, source: string) => {
    if (value !== null && value > 0) {
      levels.push(value);
      sources.push(source);
    }
  };
  for (const h of pivots.highs) add(h, 'SWING_HIGH');
  for (const l of pivots.lows) add(l, 'SWING_LOW');
  add(input.sma50, 'SMA50');
  add(input.sma200, 'SMA200');
  add(Math.max(...window.map((b) => b.high)), '52W_HIGH');
  add(Math.min(...window.map((b) => b.low)), '52W_LOW');

  const zones = clusterZones(levels, 0.5 * atr, sources);
  const supports = zones.filter((z) => z.mid <= price).sort((a, b) => b.mid - a.mid);
  const resistances = zones.filter((z) => z.mid > price).sort((a, b) => a.low - b.low);

  let basis: TradeLevels['basis'];
  let entryLow: number;
  let entryHigh: number;
  if (input.trend === 'UPTREND' && input.sma20 !== null && input.sma50 !== null) {
    basis = 'PULLBACK_BAND';
    entryLow = Math.min(input.sma20, input.sma50);
    entryHigh = Math.max(input.sma20, input.sma50);
  } else {
    const nearest = supports[0];
    if (!nearest) return none(supports, resistances, 'no support below price');
    basis = 'SUPPORT';
    entryLow = nearest.mid;
    entryHigh = nearest.mid + input.entryAtrWidth * atr;
  }

  const stop = entryLow - input.stopAtrMultiple * atr;
  if (!(entryLow > 0) || !(stop > 0)) return none(supports, resistances, 'stop would be at or below zero (ATR too wide for this price)');
  const mid = (entryLow + entryHigh) / 2;
  const risk = mid - stop;

  const above = resistances.filter((z) => z.low > entryHigh);
  const t1Zone = above[0];
  const target1 = t1Zone ? t1Zone.low : mid + 2 * risk;
  const t2Zone = above.find((z) => z.low > target1);
  const target2 = t2Zone ? t2Zone.low : t1Zone ? Math.max(mid + 3 * risk, target1 + risk) : mid + 3 * risk;
  const riskReward = round((target1 - mid) / risk, 2);
  if (!(riskReward >= 0) || riskReward > MAX_RISK_REWARD) return none(supports, resistances, 'risk too small to size a trade');

  const bySize = Math.floor(((input.riskPct / 100) * input.capital) / risk);
  const affordable = Math.floor(input.capital / entryHigh);
  return {
    supports,
    resistances,
    reason: null,
    trade: {
      basis,
      entryLow: round(entryLow, 2),
      entryHigh: round(entryHigh, 2),
      stop: round(stop, 2),
      target1: round(target1, 2),
      target2: round(target2, 2),
      riskReward,
      positionSizeHint: Math.max(0, Math.min(bySize, affordable)),
    },
  };
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS. If an expected number differs, recompute it by hand from the rules above before touching code, and record a ruling if the plan's arithmetic was wrong.
- [ ] **Step 5: Commit** `feat(backend): support/resistance zones and trade levels (entry, stop, targets, R:R, size)`.

---

### Task 4: Valuation engine (own P/E history + sector peers)

**Files:** Create `backend/src/scoring/ValuationEngine.ts`. Test: `backend/tests/unit/valuationEngine.test.ts`.

**Interfaces:**
- Consumes: `DatedClose`, `percentileRank` (Task 2); `ValuationLabel`; `addDays` (`utils/ist.ts`).
- Produces:
  - `EpsPoint { availableOn: string; epsTtm: number }`
  - `StatementEps { periodEnd: string; eps: number | null }`
  - `epsHistoryFromStatements(quarterly, annual): EpsPoint[]`
  - `ValuationInput { closes; epsHistory; snapshotPe; peerPes; thresholds: { lowPctile; highPctile; minSectorPeers } }`
  - `ValuationResult { label; currentPe; ownPercentile; sectorPercentile; peersUsed; historyPoints; notes: string[] }`
  - `valuate(input)`
  - `QUARTER_RESULTS_LAG_DAYS = 45`, `ANNUAL_RESULTS_LAG_DAYS = 60`, `MIN_PE_HISTORY = 250`, `PE_CROSSCHECK_TOLERANCE = 0.25`
  - `hasEpsBasisBreak(eps)`: a jump of ±10% around 2, 3, 1.5 or their inverses between consecutive EPS points

- [ ] **Step 1: Write the failing test** `backend/tests/unit/valuationEngine.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { epsHistoryFromStatements, valuate, type ValuationInput } from '../../src/scoring/ValuationEngine.js';
import type { DatedClose } from '../../src/technical/stats.js';

const T = { lowPctile: 30, highPctile: 70, minSectorPeers: 4 };
const days = (n: number, close: (i: number) => number, start = '2024-01-01'): DatedClose[] =>
  Array.from({ length: n }, (_, i) => ({ date: new Date(Date.parse(`${start}T00:00:00Z`) + i * 86_400_000).toISOString().slice(0, 10), close: close(i) }));
const input = (over: Partial<ValuationInput>): ValuationInput => ({ closes: [], epsHistory: [], snapshotPe: null, peerPes: [], thresholds: T, ...over });

describe('epsHistoryFromStatements', () => {
  it('builds TTM EPS from 4 consecutive quarters and annual EPS, each from its results date (no look-ahead)', () => {
    const quarterly = [
      { periodEnd: '2025-03-31', eps: 10 }, { periodEnd: '2025-06-30', eps: 11 },
      { periodEnd: '2025-09-30', eps: 12 }, { periodEnd: '2025-12-31', eps: 13 }, { periodEnd: '2026-03-31', eps: 14 },
    ];
    const annual = [{ periodEnd: '2025-03-31', eps: 40 }, { periodEnd: '2024-03-31', eps: null }];
    expect(epsHistoryFromStatements(quarterly, annual)).toEqual([
      { availableOn: '2025-05-30', epsTtm: 40 },
      { availableOn: '2026-02-14', epsTtm: 46 },
      { availableOn: '2026-05-15', epsTtm: 50 },
    ]);
  });

  it('skips TTM windows with a missing quarter', () => {
    const gap = [{ periodEnd: '2025-03-31', eps: 1 }, { periodEnd: '2025-06-30', eps: 1 }, { periodEnd: '2025-12-31', eps: 1 }, { periodEnd: '2026-03-31', eps: 1 }];
    expect(epsHistoryFromStatements(gap, [])).toEqual([]);
  });
});

describe('valuate', () => {
  const eps = [{ availableOn: '2024-01-01', epsTtm: 10 }];

  it('labels from the percentile of the current P/E in its own history', () => {
    const cheapNow = valuate(input({ closes: days(300, (i) => (i < 299 ? 200 + (i % 50) : 205)), epsHistory: eps, snapshotPe: 20.5 }));
    expect(cheapNow).toMatchObject({ currentPe: 20.5, historyPoints: 300, sectorPercentile: null });
    expect(cheapNow.ownPercentile).toBeLessThanOrEqual(30);
    expect(cheapNow.label).toBe('UNDERVALUED');
    const richNow = valuate(input({ closes: days(300, (i) => (i < 299 ? 200 + (i % 50) : 248)), epsHistory: eps, snapshotPe: 24.8 }));
    expect(richNow.label).toBe('OVERVALUED');
  });

  it('never uses EPS before it was published', () => {
    const late = [{ availableOn: '2024-06-01', epsTtm: 10 }];
    const r = valuate(input({ closes: days(300, () => 200), epsHistory: late, snapshotPe: 20 }));
    expect(r.historyPoints).toBe(300 - 152);
    expect(r.ownPercentile).toBeNull();
    expect(r.notes.join(' ')).toMatch(/history/);
  });

  it('drops own history that disagrees with the provider P/E (bonus/split basis) and says so', () => {
    const r = valuate(input({ closes: days(300, (i) => 200 + (i % 50)), epsHistory: eps, snapshotPe: 10 }));
    expect(r.ownPercentile).toBeNull();
    expect(r.notes.join(' ')).toMatch(/disagrees/);
    expect(r.label).toBe('INSUFFICIENT_DATA');
  });

  it('drops own history when EPS jumps by a bonus/split ratio mid-series (basis change)', () => {
    const halved = [{ availableOn: '2024-01-01', epsTtm: 20 }, { availableOn: '2024-06-01', epsTtm: 10.4 }];
    const r = valuate(input({ closes: days(300, (i) => 200 + (i % 50)), epsHistory: halved, snapshotPe: 24 }));
    expect(r.ownPercentile).toBeNull();
    expect(r.notes.join(' ')).toMatch(/bonus\/split/);
    const organic = [{ availableOn: '2024-01-01', epsTtm: 10 }, { availableOn: '2024-06-01', epsTtm: 11.5 }];
    expect(valuate(input({ closes: days(300, (i) => 200 + (i % 50)), epsHistory: organic, snapshotPe: 21.6 })).ownPercentile).not.toBeNull();
  });

  it('uses sector peers only with at least 4 of them, and averages both views', () => {
    const closes = days(300, (i) => (i < 299 ? 200 + (i % 50) : 205));
    const three = valuate(input({ closes: days(10, () => 200), snapshotPe: 20, peerPes: [30, 40, 50] }));
    expect(three).toMatchObject({ sectorPercentile: null, peersUsed: 3, label: 'INSUFFICIENT_DATA' });
    const both = valuate(input({ closes, epsHistory: eps, snapshotPe: 20.5, peerPes: [10, 15, 30, 40] }));
    expect(both.sectorPercentile).toBe(50);
    expect(both.ownPercentile).not.toBeNull();
  });

  it('falls back to the snapshot P/E without statements (INFY) and refuses non-positive earnings', () => {
    const infy = valuate(input({ closes: days(5, () => 1000), snapshotPe: 13.9, peerPes: [20, 25, 28, 30] }));
    expect(infy).toMatchObject({ currentPe: 13.9, sectorPercentile: 0, label: 'UNDERVALUED' });
    const loss = valuate(input({ closes: days(300, () => 100), epsHistory: [{ availableOn: '2024-01-01', epsTtm: -5 }], snapshotPe: null, peerPes: [10, 20, 30, 40] }));
    expect(loss).toMatchObject({ currentPe: null, label: 'INSUFFICIENT_DATA' });
    expect(loss.notes.join(' ')).toMatch(/positive earnings/);
  });
});
```
Check the numbers. `days(300)` starts 2024-01-01. EPS from 2024-06-01 = day index 152 (2024 is a leap year: Jan 31 + Feb 29 + Mar 31 + Apr 30 + May 31 = 152), so history = 148 points, which is < 250 → no own percentile.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/scoring/ValuationEngine.ts`

```ts
import type { ValuationLabel } from '../domain/enums.js';
import { addDays } from '../utils/ist.js';
import { type DatedClose, percentileRank } from '../technical/stats.js';

/** Results are published after the period ends; EPS is usable only from then on (no look-ahead). */
export const QUARTER_RESULTS_LAG_DAYS = 45;
export const ANNUAL_RESULTS_LAG_DAYS = 60;
/** About one trading year of P/E observations before own history is trusted. */
export const MIN_PE_HISTORY = 250;
/** Own-history P/E must agree with the provider's P/E within this fraction (bonus/split basis check). */
export const PE_CROSSCHECK_TOLERANCE = 0.25;
/** A jump between consecutive EPS points this close to a bonus/split ratio suggests a basis change. */
export const CORPORATE_ACTION_RATIOS = [2, 3, 1.5, 1 / 2, 1 / 3, 2 / 3] as const;
export const CORPORATE_ACTION_TOLERANCE = 0.1;

/** True when consecutive EPS points jump by ~a bonus/split ratio (statements may be on the pre-bonus basis). */
export function hasEpsBasisBreak(eps: readonly EpsPoint[]): boolean {
  const sorted = [...eps].sort((a, b) => a.availableOn.localeCompare(b.availableOn));
  for (let k = 1; k < sorted.length; k += 1) {
    const prev = sorted[k - 1]?.epsTtm ?? 0;
    const cur = sorted[k]?.epsTtm ?? 0;
    if (prev <= 0 || cur <= 0) continue;
    const ratio = cur / prev;
    if (CORPORATE_ACTION_RATIOS.some((r) => Math.abs(ratio / r - 1) <= CORPORATE_ACTION_TOLERANCE)) return true;
  }
  return false;
}
const MAX_QUARTER_GAP_DAYS = 100;

export interface EpsPoint {
  /** IST date from which this trailing-twelve-month EPS was public. */
  availableOn: string;
  epsTtm: number;
}

export interface StatementEps {
  periodEnd: string;
  eps: number | null;
}

const dayGap = (a: string, b: string) => (Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000;

/** TTM EPS points: rolling sums of 4 consecutive quarters, plus annual EPS (fiscal-year TTM). */
export function epsHistoryFromStatements(quarterly: readonly StatementEps[], annual: readonly StatementEps[]): EpsPoint[] {
  const q = quarterly.filter((s): s is { periodEnd: string; eps: number } => s.eps !== null).sort((a, b) => a.periodEnd.localeCompare(b.periodEnd));
  const points: EpsPoint[] = [];
  for (let i = 3; i < q.length; i += 1) {
    const window = q.slice(i - 3, i + 1);
    const consecutive = window.every((s, k) => k === 0 || dayGap(window[k - 1]?.periodEnd ?? s.periodEnd, s.periodEnd) <= MAX_QUARTER_GAP_DAYS);
    const last = window[3];
    if (consecutive && last) {
      points.push({ availableOn: addDays(last.periodEnd, QUARTER_RESULTS_LAG_DAYS), epsTtm: window.reduce((s, x) => s + x.eps, 0) });
    }
  }
  for (const a of annual) {
    if (a.eps !== null) points.push({ availableOn: addDays(a.periodEnd, ANNUAL_RESULTS_LAG_DAYS), epsTtm: a.eps });
  }
  return points.sort((a, b) => a.availableOn.localeCompare(b.availableOn));
}

export interface ValuationThresholds {
  lowPctile: number;
  highPctile: number;
  minSectorPeers: number;
}

export interface ValuationInput {
  closes: readonly DatedClose[];
  epsHistory: readonly EpsPoint[];
  /** Provider's current P/E (snapshot); used as the current P/E when no EPS history exists. */
  snapshotPe: number | null;
  /** Current P/E of other companies in the same sector (positive values only). */
  peerPes: readonly number[];
  thresholds: ValuationThresholds;
}

export interface ValuationResult {
  label: ValuationLabel;
  currentPe: number | null;
  ownPercentile: number | null;
  sectorPercentile: number | null;
  peersUsed: number;
  historyPoints: number;
  notes: string[];
}

/** P/E series: each close ÷ the latest TTM EPS public on that date (positive EPS only). */
function peSeries(closes: readonly DatedClose[], eps: readonly EpsPoint[]): number[] {
  const sorted = [...eps].sort((a, b) => a.availableOn.localeCompare(b.availableOn));
  const out: number[] = [];
  let k = -1;
  for (const c of closes) {
    while (k + 1 < sorted.length && (sorted[k + 1]?.availableOn ?? '') <= c.date) k += 1;
    const e = sorted[k]?.epsTtm;
    if (e !== undefined && e > 0) out.push(c.close / e);
  }
  return out;
}

/** PRD §8.3. The LLM never estimates fair value; neither does this engine. */
export function valuate(input: ValuationInput): ValuationResult {
  const notes: string[] = [];
  const series = peSeries(input.closes, input.epsHistory);
  const seriesPe = series.length > 0 ? (series[series.length - 1] ?? null) : null;
  const lastEps = [...input.epsHistory].sort((a, b) => a.availableOn.localeCompare(b.availableOn)).at(-1);
  const currentPe = seriesPe ?? (lastEps === undefined && input.snapshotPe !== null && input.snapshotPe > 0 ? input.snapshotPe : null);
  const peers = input.peerPes.filter((p) => p > 0);

  if (currentPe === null) {
    notes.push('no positive earnings: P/E is undefined');
    return { label: 'INSUFFICIENT_DATA', currentPe: null, ownPercentile: null, sectorPercentile: null, peersUsed: peers.length, historyPoints: series.length, notes };
  }

  let ownPercentile: number | null = null;
  if (series.length < MIN_PE_HISTORY) {
    notes.push(`own P/E history too short (${series.length} of ${MIN_PE_HISTORY} days)`);
  } else if (hasEpsBasisBreak(input.epsHistory)) {
    notes.push('EPS history jumps by a bonus/split-like ratio; possible basis change, own P/E history not used');
  } else if (input.snapshotPe !== null && input.snapshotPe > 0 && Math.abs(currentPe - input.snapshotPe) / input.snapshotPe > PE_CROSSCHECK_TOLERANCE) {
    notes.push(`own P/E history (${currentPe.toFixed(1)}) disagrees with provider P/E (${input.snapshotPe.toFixed(1)}); possible bonus/split basis mismatch, history not used`);
  } else {
    ownPercentile = percentileRank(series, currentPe);
  }

  let sectorPercentile: number | null = null;
  if (peers.length >= input.thresholds.minSectorPeers) {
    sectorPercentile = percentileRank(peers, currentPe);
  } else {
    notes.push(`sector comparison needs ${input.thresholds.minSectorPeers} peers with P/E (have ${peers.length})`);
  }

  const views = [ownPercentile, sectorPercentile].filter((v): v is number => v !== null);
  const combined = views.length > 0 ? views.reduce((s, v) => s + v, 0) / views.length : null;
  const label: ValuationLabel =
    combined === null ? 'INSUFFICIENT_DATA'
    : combined <= input.thresholds.lowPctile ? 'UNDERVALUED'
    : combined >= input.thresholds.highPctile ? 'OVERVALUED'
    : 'FAIR';
  return { label, currentPe, ownPercentile, sectorPercentile, peersUsed: peers.length, historyPoints: series.length, notes };
}
```
The current P/E comes from the series when EPS history exists. Otherwise (INFY) it comes from the snapshot. When EPS history exists but its latest EPS is ≤ 0, the current P/E is null (loss-making): the snapshot is not used to paper over losses.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): valuation engine (own P/E history without look-ahead, sector peers, basis cross-check)`.

---
### Task 5: Scoring config, rubrics and factor scores

**Files:**
- Create:
  - `backend/src/scoring/config.ts`
  - `backend/src/scoring/rubrics.ts`
  - `backend/src/scoring/ScoringEngine.ts`
  - `backend/tests/fixtures/scoringConfig.ts`
- Test: `backend/tests/unit/scoringConfig.test.ts`, `backend/tests/unit/scoringEngine.test.ts`

**Interfaces:**
- Consumes: `interpolate`, `weightedMean`, `clampScore` (Task 2); `Trend`, `MarketRegime`, `RiskLevel`.
- Produces:
  - **`scoring/config.ts`:**
    - `FACTOR_NAMES`, `FactorName`, `FactorWeights`
    - `ScoringThresholds`: camelCase fields `buyOverallMin, strongBuyOverallMin, avoidOverallMax, strongSellOverallMax, extendedAboveSma50Pct, rsiOverbought, minRiskReward, stopAtrMultiple, entryAtrWidth, riskPerTradePct, minDailyBars, valuationLowPctile, valuationHighPctile, minSectorPeers, newsHalfLifeDays, vixRiskOnMax, vixRiskOffMin, weakQualityMax, maxStaleSessions`
    - `ScoringConfig { version; weights; thresholds }`
    - `parseScoringConfig({ version, weights, thresholds }): ScoringConfig`, which throws `AppError('INTERNAL')` on an invalid row
  - **`rubrics.ts`:** `ENGINE_VERSION = 'engine-1'` and every breakpoint table and component weight
  - **`ScoringEngine.ts`:**
    - `FactorResult { score: number | null; components: Record<string, number | null> }`
    - `technicalScore`, `qualityScore`, `valuationScore`, `newsScore`, `momentumScore`, `marketContextScore`
    - `overallScore(factors, weights): { overall; available: FactorName[]; coverage }`
    - `riskScore(inputs): FactorResult & { level: RiskLevel | null }`
    - input types `TechnicalInputs`, `QualityInputs`, `ValuationScoreInputs`, `NewsSentimentPoint`, `MomentumInputs`, `MarketContextInputs`, `RiskInputs`
  - **Test fixture:** `SEED_CONFIG: ScoringConfig` (v1 seed values)

- [ ] **Step 1: Write the failing tests**

`backend/tests/fixtures/scoringConfig.ts`:
```ts
import { parseScoringConfig } from '../../src/scoring/config.js';

/** Mirrors supabase/seeds/07_config.sql (scoring config v1). */
export const SEED_CONFIG = parseScoringConfig({
  version: 'v1',
  weights: { technical: 30, quality: 10, valuation: 10, news: 20, momentum: 15, market_context: 15 },
  thresholds: {
    buy_overall_min: 65, strong_buy_overall_min: 80, avoid_overall_max: 35, strong_sell_overall_max: 25,
    extended_above_sma50_pct: 8, rsi_overbought: 70, min_risk_reward: 2, stop_atr_multiple: 1.5,
    entry_atr_width: 0.5, risk_per_trade_pct: 1, min_daily_bars: 200, valuation_low_pctile: 30,
    valuation_high_pctile: 70, min_sector_peers: 4, news_half_life_days: 7,
  },
});
```
`backend/tests/unit/scoringConfig.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { parseScoringConfig } from '../../src/scoring/config.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

describe('parseScoringConfig', () => {
  it('maps seeded thresholds to camelCase and fills defaults for newer keys', () => {
    expect(SEED_CONFIG.version).toBe('v1');
    expect(SEED_CONFIG.weights.market_context).toBe(15);
    expect(SEED_CONFIG.thresholds).toMatchObject({
      buyOverallMin: 65, minDailyBars: 200, stopAtrMultiple: 1.5,
      vixRiskOnMax: 20, vixRiskOffMin: 25, weakQualityMax: 40, maxStaleSessions: 3,
    });
  });

  it('rejects a malformed config row', () => {
    expect(() => parseScoringConfig({ version: 'bad', weights: { technical: 'x' }, thresholds: {} }))
      .toThrow(expect.objectContaining({ code: 'INTERNAL' }));
  });
});
```
`backend/tests/unit/scoringEngine.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import {
  marketContextScore, momentumScore, newsScore, overallScore, qualityScore, riskScore, technicalScore, valuationScore,
} from '../../src/scoring/ScoringEngine.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

const tech = { close: 110, prevClose: 108, volume: 2000, volumeSma20: 1000, trend: 'UPTREND' as const, rsi14: 65, macd: 2, macdSignal: 1.5, adx14: 30 };

describe('ScoringEngine', () => {
  it('technical: a strong confirmed uptrend scores 100; missing parts are dropped, not zeroed', () => {
    expect(technicalScore(tech).score).toBe(100);
    const mixed = technicalScore({ ...tech, trend: 'SIDEWAYS', macd: 1, macdSignal: 1.5, rsi14: 50, adx14: null, volumeSma20: null });
    expect(mixed.score).toBe(52);
    expect(mixed.components).toMatchObject({ trend: 50, macd: 35, rsi: 72.5, adx: null, volume: null });
    expect(technicalScore({ ...tech, trend: null, macd: null, macdSignal: null, rsi14: null, adx14: null, volumeSma20: null }).score).toBeNull();
  });

  it('quality: ROE, leverage, margin trend and growth consistency; banks are exempt from D/E', () => {
    const q = { roe: 18, roce: null, debtToEquity: 0.5, isFinancial: false, netMargins: [10, 12], revenueGrowth: [5, 10, -2, 8], profitGrowth: [3, 12, 5, 9] };
    expect(qualityScore(q).score).toBe(83.82);
    expect(qualityScore({ ...q, isFinancial: true }).components.debtToEquity).toBeNull();
  });

  it('valuation: cheaper vs history and peers scores higher; earnings yield counts', () => {
    expect(valuationScore({ ownPercentile: 20, sectorPercentile: null, currentPe: 20 }).score).toBe(70);
    expect(valuationScore({ ownPercentile: null, sectorPercentile: null, currentPe: null }).score).toBeNull();
  });

  it('news: relevance-weighted, recency-decayed mean sentiment (half-life)', () => {
    const now = new Date('2026-10-06T00:00:00Z');
    const pts = [
      { sentimentScore: 80, relevance: 1, publishedAt: now },
      { sentimentScore: 20, relevance: 1, publishedAt: new Date(now.getTime() - 7 * 86_400_000) },
    ];
    expect(newsScore(pts, now, 7).score).toBe(60);
    expect(newsScore([], now, 7).score).toBeNull();
  });

  it('momentum and market context map returns, relative strength, regime and VIX', () => {
    expect(momentumScore({ return1m: 7.5, return3m: 0, return6m: -35, rsVsNifty: 10, rsVsSector: null }).score).toBe(45.59);
    expect(marketContextScore({ regime: 'RISK_ON', sectorTrend: null, vix: 15 }).score).toBe(91.67);
  });

  it('overall: renormalises weights over available factors and reports coverage', () => {
    const r = overallScore({ technical: 80, quality: null, valuation: 60, news: null, momentum: 40, market_context: 100 }, SEED_CONFIG.weights);
    expect(r).toEqual({ overall: 72.86, available: ['technical', 'valuation', 'momentum', 'market_context'], coverage: 0.7 });
    expect(overallScore({ technical: null, quality: null, valuation: null, news: null, momentum: null, market_context: null }, SEED_CONFIG.weights).overall).toBeNull();
  });

  it('risk: volatility, beta, drawdown and stop distance map to a level', () => {
    const calm = riskScore({ atrPct: 2, beta: 1, maxDrawdownPct: 20, stopDistancePct: null });
    expect(calm).toMatchObject({ score: 38.13, level: 'MEDIUM' });
    expect(riskScore({ atrPct: 5, beta: 2, maxDrawdownPct: 50, stopDistancePct: 15 })).toMatchObject({ score: 91.25, level: 'VERY_HIGH' });
    expect(riskScore({ atrPct: null, beta: null, maxDrawdownPct: null, stopDistancePct: null })).toMatchObject({ score: null, level: null });
  });
});
```
Check the numbers:

- **Mixed technical:**
  - trend SIDEWAYS → 50
  - MACD 1 < 1.5 and > 0 → 35
  - RSI 50 → between (45, 55) and (55, 90) → 72.5
  - weighted: (50·.35 + 35·.2 + 72.5·.2) / .75 = 52
- **Quality:**
  - ROE 18 → 85
  - D/E 0.5 → 90
  - margin +2pp → 85
  - growth: 3 of 4 years with both positive → 75
  - weighted: (25.5 + 18 + 12.75 + 15) / .85 = 83.82
- **Valuation:** own 20 → 80; earnings yield 5% → 50. (32 + 10) / .6 = 70.
- **News:** weights 1 and 0.5 → (80 + 10) / 1.5 = 60.
- **Momentum:**
  - 7.5% → 75; 0 → 50; −35% → 0; RS +10 → 75
  - weighted: (15 + 12.5 + 0 + 11.25) / .85 = 45.59
- **Market context:** (50 + 18.75) / .75 = 91.67.
- **Overall:** 5100 / 70 = 72.86, coverage 70/100.
- **Risk:**
  - (10.5 + 10 + 10) / .8 = 38.125 → 38.13, MEDIUM
  - (27 + 22.5 + 23.75 + 18) = 91.25, VERY_HIGH

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/scoring/config.ts`

```ts
import { z } from 'zod';
import { AppError } from '../utils/errors.js';

export const FACTOR_NAMES = ['technical', 'quality', 'valuation', 'news', 'momentum', 'market_context'] as const;
export type FactorName = (typeof FACTOR_NAMES)[number];
export type FactorWeights = Record<FactorName, number>;

const weight = z.number().nonnegative();
const WeightsSchema = z.object({
  technical: weight, quality: weight, valuation: weight, news: weight, momentum: weight, market_context: weight,
});

/** scoring_configs.thresholds. Keys added after v1 have defaults so older configs stay valid. */
const ThresholdsSchema = z.object({
  buy_overall_min: z.number(),
  strong_buy_overall_min: z.number(),
  avoid_overall_max: z.number(),
  strong_sell_overall_max: z.number(),
  extended_above_sma50_pct: z.number(),
  rsi_overbought: z.number(),
  min_risk_reward: z.number(),
  stop_atr_multiple: z.number().positive(),
  entry_atr_width: z.number().nonnegative(),
  risk_per_trade_pct: z.number().positive(),
  min_daily_bars: z.number().int().positive(),
  valuation_low_pctile: z.number(),
  valuation_high_pctile: z.number(),
  min_sector_peers: z.number().int().positive(),
  news_half_life_days: z.number().positive(),
  vix_risk_on_max: z.number().default(20),
  vix_risk_off_min: z.number().default(25),
  weak_quality_max: z.number().default(40),
  max_stale_sessions: z.number().int().nonnegative().default(3),
});

export interface ScoringThresholds {
  buyOverallMin: number;
  strongBuyOverallMin: number;
  avoidOverallMax: number;
  strongSellOverallMax: number;
  extendedAboveSma50Pct: number;
  rsiOverbought: number;
  minRiskReward: number;
  stopAtrMultiple: number;
  entryAtrWidth: number;
  riskPerTradePct: number;
  minDailyBars: number;
  valuationLowPctile: number;
  valuationHighPctile: number;
  minSectorPeers: number;
  newsHalfLifeDays: number;
  vixRiskOnMax: number;
  vixRiskOffMin: number;
  weakQualityMax: number;
  maxStaleSessions: number;
}

export interface ScoringConfig {
  version: string;
  weights: FactorWeights;
  thresholds: ScoringThresholds;
}

export function parseScoringConfig(row: { version: string; weights: unknown; thresholds: unknown }): ScoringConfig {
  const weights = WeightsSchema.safeParse(row.weights);
  const thresholds = ThresholdsSchema.safeParse(row.thresholds);
  if (!weights.success || !thresholds.success) {
    const error = weights.success ? thresholds.error : weights.error;
    throw new AppError('INTERNAL', `scoring_configs ${row.version} is invalid:\n${z.prettifyError(error ?? new z.ZodError([]))}`, {
      details: { version: row.version },
    });
  }
  const t = thresholds.data;
  return {
    version: row.version,
    weights: weights.data,
    thresholds: {
      buyOverallMin: t.buy_overall_min,
      strongBuyOverallMin: t.strong_buy_overall_min,
      avoidOverallMax: t.avoid_overall_max,
      strongSellOverallMax: t.strong_sell_overall_max,
      extendedAboveSma50Pct: t.extended_above_sma50_pct,
      rsiOverbought: t.rsi_overbought,
      minRiskReward: t.min_risk_reward,
      stopAtrMultiple: t.stop_atr_multiple,
      entryAtrWidth: t.entry_atr_width,
      riskPerTradePct: t.risk_per_trade_pct,
      minDailyBars: t.min_daily_bars,
      valuationLowPctile: t.valuation_low_pctile,
      valuationHighPctile: t.valuation_high_pctile,
      minSectorPeers: t.min_sector_peers,
      newsHalfLifeDays: t.news_half_life_days,
      vixRiskOnMax: t.vix_risk_on_max,
      vixRiskOffMin: t.vix_risk_off_min,
      weakQualityMax: t.weak_quality_max,
      maxStaleSessions: t.max_stale_sessions,
    },
  };
}
```
If the `z.ZodError([])` fallback does not typecheck under zod 4, use `(weights.success ? thresholds : weights).error` with a type guard. It is purely a type-narrowing aid.

`backend/src/scoring/rubrics.ts`:
```ts
/**
 * Scoring rubrics (PRD §8.2). Breakpoints are (input, score) pairs joined piecewise-linearly and clamped.
 * Changing anything here changes evaluations: bump ENGINE_VERSION so input hashes change too.
 */
export const ENGINE_VERSION = 'engine-1';

type Points = ReadonlyArray<readonly [number, number]>;

export const TECHNICAL = {
  weights: { trend: 0.35, macd: 0.2, rsi: 0.2, adx: 0.15, volume: 0.1 },
  trend: { UPTREND: 100, SIDEWAYS: 50, DOWNTREND: 0 },
  /** RSI 55–65 is healthy momentum; above 75 is stretched, below 30 is weak. */
  rsi: [[0, 10], [30, 25], [45, 55], [55, 90], [65, 100], [75, 60], [85, 20], [100, 10]] as Points,
  /** ADX below 15 = no trend; at 25+ the trend direction counts fully. */
  adxStrength: [[15, 0], [25, 1]] as Points,
  volumeUp: [[0.5, 50], [1, 60], [1.5, 85], [2, 100]] as Points,
  volumeDown: [[0.5, 50], [1, 40], [1.5, 15], [2, 0]] as Points,
} as const;

export const QUALITY = {
  weights: { roe: 0.3, roce: 0.15, debtToEquity: 0.2, marginTrend: 0.15, growthConsistency: 0.2 },
  returnOnCapital: [[0, 0], [8, 30], [12, 55], [18, 85], [25, 100]] as Points,
  debtToEquity: [[0, 100], [0.5, 90], [1, 65], [2, 30], [3, 10]] as Points,
  /** Change in net margin, percentage points, latest year vs the year before. */
  marginTrend: [[-3, 10], [0, 55], [3, 100]] as Points,
  growthYears: 4,
} as const;

export const VALUATION = {
  weights: { ownHistory: 0.4, sector: 0.4, earningsYield: 0.2 },
  /** Earnings yield (100 / P/E) in percent. */
  earningsYield: [[2, 0], [5, 50], [8, 100]] as Points,
} as const;

export const MOMENTUM = {
  weights: { return1m: 0.2, return3m: 0.25, return6m: 0.25, rsVsNifty: 0.15, rsVsSector: 0.15 },
  return1m: [[-15, 0], [0, 50], [15, 100]] as Points,
  return3m: [[-25, 0], [0, 50], [25, 100]] as Points,
  return6m: [[-35, 0], [0, 50], [35, 100]] as Points,
  relativeStrength: [[-20, 0], [0, 50], [20, 100]] as Points,
  sessions: { m1: 21, m3: 63, m6: 126 },
} as const;

export const MARKET_CONTEXT = {
  weights: { regime: 0.5, sectorTrend: 0.25, vix: 0.25 },
  regime: { RISK_ON: 100, NEUTRAL: 50, RISK_OFF: 0 },
  /** India VIX: ~11–15 calm, 20+ nervous, 25+ stressed. */
  vix: [[11, 100], [15, 75], [20, 45], [25, 20], [35, 0]] as Points,
} as const;

export const RISK = {
  weights: { atrPct: 0.3, beta: 0.25, maxDrawdown: 0.25, stopDistance: 0.2 },
  atrPct: [[1, 10], [2, 35], [3, 60], [5, 90]] as Points,
  beta: [[0.5, 15], [1, 40], [1.5, 70], [2, 90]] as Points,
  maxDrawdown: [[10, 15], [20, 40], [35, 70], [50, 95]] as Points,
  stopDistance: [[3, 20], [6, 45], [10, 70], [15, 90]] as Points,
  /** Upper bounds (exclusive) for LOW, MEDIUM, HIGH; anything above is VERY_HIGH. */
  levels: { LOW: 35, MEDIUM: 55, HIGH: 75 },
} as const;
```
`backend/src/scoring/ScoringEngine.ts`:
```ts
import type { MarketRegime, RiskLevel, Trend } from '../domain/enums.js';
import { FACTOR_NAMES, type FactorName, type FactorWeights } from './config.js';
import { clampScore, interpolate, round, weightedMean } from '../technical/stats.js';
import { MARKET_CONTEXT, MOMENTUM, QUALITY, RISK, TECHNICAL, VALUATION } from './rubrics.js';

export interface FactorResult {
  score: number | null;
  /** Each component's 0–100 score (null = unavailable), for explainability. */
  components: Record<string, number | null>;
}

const DAY_MS = 86_400_000;
const pt = (x: number | null, points: Parameters<typeof interpolate>[1]): number | null => (x === null ? null : interpolate(x, points));
const finish = (components: Record<string, number | null>, weights: Record<string, number>): FactorResult => {
  const mean = weightedMean(Object.entries(weights).map(([k, w]) => [components[k] ?? null, w] as const));
  const rounded = Object.fromEntries(Object.entries(components).map(([k, v]) => [k, v === null ? null : round(v, 2)]));
  return { score: mean === null ? null : clampScore(mean), components: rounded };
};
const trendScore = (t: Trend | null) => (t === null ? null : TECHNICAL.trend[t]);

export interface TechnicalInputs {
  close: number | null;
  prevClose: number | null;
  volume: number | null;
  volumeSma20: number | null;
  trend: Trend | null;
  rsi14: number | null;
  macd: number | null;
  macdSignal: number | null;
  adx14: number | null;
}

export function technicalScore(i: TechnicalInputs): FactorResult {
  const macd =
    i.macd === null || i.macdSignal === null ? null
    : i.macd > i.macdSignal ? (i.macd >= 0 ? 100 : 65)
    : i.macd <= 0 ? 0 : 35;
  const direction = i.trend === 'UPTREND' ? 1 : i.trend === 'DOWNTREND' ? -1 : 0;
  const adx = i.adx14 === null || i.trend === null ? null : 50 + 50 * direction * interpolate(i.adx14, TECHNICAL.adxStrength);
  let volume: number | null = null;
  if (i.volume !== null && i.volumeSma20 !== null && i.volumeSma20 > 0 && i.close !== null && i.prevClose !== null) {
    const ratio = i.volume / i.volumeSma20;
    volume = interpolate(ratio, i.close > i.prevClose ? TECHNICAL.volumeUp : TECHNICAL.volumeDown);
  }
  return finish({ trend: trendScore(i.trend), macd, rsi: pt(i.rsi14, TECHNICAL.rsi), adx, volume }, TECHNICAL.weights);
}

export interface QualityInputs {
  roe: number | null;
  roce: number | null;
  debtToEquity: number | null;
  /** Banks/NBFCs: leverage is the business, so D/E is not scored (PRD §8.2). */
  isFinancial: boolean;
  /** Annual net margins in percent, oldest first. */
  netMargins: readonly number[];
  /** Annual YoY growth in percent, oldest first. */
  revenueGrowth: readonly number[];
  profitGrowth: readonly number[];
}

export function qualityScore(i: QualityInputs): FactorResult {
  const margins = i.netMargins;
  const lastMargin = margins[margins.length - 1];
  const prevMargin = margins[margins.length - 2];
  const marginTrend = lastMargin !== undefined && prevMargin !== undefined ? interpolate(lastMargin - prevMargin, QUALITY.marginTrend) : null;
  const years = Math.min(QUALITY.growthYears, i.revenueGrowth.length);
  let growthConsistency: number | null = null;
  if (years >= 2) {
    const rev = i.revenueGrowth.slice(-years);
    const offset = i.profitGrowth.length - years;
    let good = 0;
    rev.forEach((g, k) => {
      const profit = i.profitGrowth[offset + k];
      if (g > 0 && (profit === undefined || profit > 0)) good += 1;
    });
    growthConsistency = (good / years) * 100;
  }
  return finish(
    {
      roe: pt(i.roe, QUALITY.returnOnCapital),
      roce: pt(i.roce, QUALITY.returnOnCapital),
      debtToEquity: i.isFinancial ? null : pt(i.debtToEquity, QUALITY.debtToEquity),
      marginTrend,
      growthConsistency,
    },
    QUALITY.weights,
  );
}

export interface ValuationScoreInputs {
  ownPercentile: number | null;
  sectorPercentile: number | null;
  currentPe: number | null;
}

export function valuationScore(i: ValuationScoreInputs): FactorResult {
  return finish(
    {
      ownHistory: i.ownPercentile === null ? null : 100 - i.ownPercentile,
      sector: i.sectorPercentile === null ? null : 100 - i.sectorPercentile,
      earningsYield: i.currentPe !== null && i.currentPe > 0 ? interpolate(100 / i.currentPe, VALUATION.earningsYield) : null,
    },
    VALUATION.weights,
  );
}

export interface NewsSentimentPoint {
  /** 0–100, 50 = neutral (news_ai_analysis.sentiment_score). */
  sentimentScore: number;
  relevance: number;
  publishedAt: Date;
}

export function newsScore(points: readonly NewsSentimentPoint[], now: Date, halfLifeDays: number): FactorResult {
  const parts = points.map((p) => {
    const ageDays = Math.max(0, (now.getTime() - p.publishedAt.getTime()) / DAY_MS);
    return [p.sentimentScore, p.relevance * 0.5 ** (ageDays / halfLifeDays)] as const;
  });
  const mean = weightedMean(parts);
  return { score: mean === null ? null : clampScore(mean), components: { articles: points.length } };
}

export interface MomentumInputs {
  return1m: number | null;
  return3m: number | null;
  return6m: number | null;
  rsVsNifty: number | null;
  rsVsSector: number | null;
}

export function momentumScore(i: MomentumInputs): FactorResult {
  return finish(
    {
      return1m: pt(i.return1m, MOMENTUM.return1m),
      return3m: pt(i.return3m, MOMENTUM.return3m),
      return6m: pt(i.return6m, MOMENTUM.return6m),
      rsVsNifty: pt(i.rsVsNifty, MOMENTUM.relativeStrength),
      rsVsSector: pt(i.rsVsSector, MOMENTUM.relativeStrength),
    },
    MOMENTUM.weights,
  );
}

export interface MarketContextInputs {
  regime: MarketRegime | null;
  sectorTrend: Trend | null;
  vix: number | null;
}

export function marketContextScore(i: MarketContextInputs): FactorResult {
  return finish(
    {
      regime: i.regime === null ? null : MARKET_CONTEXT.regime[i.regime],
      sectorTrend: trendScore(i.sectorTrend),
      vix: pt(i.vix, MARKET_CONTEXT.vix),
    },
    MARKET_CONTEXT.weights,
  );
}

/** PRD §8.2: missing factors are dropped and the weights renormalised; coverage = share of weight available. */
export function overallScore(factors: Record<FactorName, number | null>, weights: FactorWeights): { overall: number | null; available: FactorName[]; coverage: number } {
  const available = FACTOR_NAMES.filter((f) => factors[f] !== null && weights[f] > 0);
  const total = FACTOR_NAMES.reduce((s, f) => s + weights[f], 0);
  const covered = available.reduce((s, f) => s + weights[f], 0);
  const mean = weightedMean(FACTOR_NAMES.map((f) => [factors[f], weights[f]] as const));
  return { overall: mean === null ? null : clampScore(mean), available, coverage: total > 0 ? round(covered / total, 4) : 0 };
}

export interface RiskInputs {
  atrPct: number | null;
  beta: number | null;
  maxDrawdownPct: number | null;
  stopDistancePct: number | null;
}

/** Separate from the factors: higher = riskier (PRD §8.2). */
export function riskScore(i: RiskInputs): FactorResult & { level: RiskLevel | null } {
  const result = finish(
    {
      atrPct: pt(i.atrPct, RISK.atrPct),
      beta: pt(i.beta, RISK.beta),
      maxDrawdown: pt(i.maxDrawdownPct, RISK.maxDrawdown),
      stopDistance: pt(i.stopDistancePct, RISK.stopDistance),
    },
    RISK.weights,
  );
  const s = result.score;
  const level: RiskLevel | null =
    s === null ? null : s < RISK.levels.LOW ? 'LOW' : s < RISK.levels.MEDIUM ? 'MEDIUM' : s < RISK.levels.HIGH ? 'HIGH' : 'VERY_HIGH';
  return { ...result, level };
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS. If an expected score differs only in the last decimal, recompute the weighted mean by hand before changing anything, and record a ruling.
- [ ] **Step 5: Commit** `feat(backend): scoring config parsing, versioned rubrics and factor/overall/risk scores`.

---

### Task 6: Decision engine (rule table, bias, paper signal, invalidation)

**Files:** Create `backend/src/scoring/DecisionEngine.ts`. Test: `backend/tests/unit/decisionEngine.test.ts`.

**Interfaces:**
- Consumes: `ScoringThresholds` (Task 5), `TradeLevels` (Task 3), `formatInr` (Task 1), enum types.
- Produces:
  - `DecisionInput { dailyBars; price; stale; lastBarDate; overall; qualityScore; trend; regime; valuationLabel; sma50; sma200; rsi14; atr14; trade; holdsPosition }`
  - `Decision { actionState; bias: RecommendationBias | null; paperSignal: SignalType; rule: 1|2|3|4|5|6; reason; invalidation }`
  - `decide(input, thresholds): Decision`

PRD §8.5 rules (first match wins):

| # | Condition | Result |
|---|---|---|
| 1 | fewer than `minDailyBars` bars, no price, stale data, or no overall score | `INSUFFICIENT_DATA` |
| 2 | overall < `avoidOverallMax`, or (DOWNTREND ∧ RISK_OFF ∧ quality < `weakQualityMax`) | `AVOID`, or `REDUCE` if a position is held |
| 3 | DOWNTREND, or price < SMA200 | `WAIT_FOR_CONFIRMATION` |
| 4 | price > SMA50 × (1 + x%), or RSI > `rsiOverbought`, or price > entry high + ATR | `WAIT_FOR_PULLBACK` |
| 5 | overall ≥ `buyOverallMin` ∧ valuation ≠ OVERVALUED ∧ price within the entry zone ∧ regime ≠ RISK_OFF ∧ R:R ≥ `minRiskReward` | `BUY_ZONE` |
| 6 | otherwise | `HOLD` |

Mappings:

| State | Bias | Paper signal |
|---|---|---|
| BUY_ZONE | STRONG_BUY_BIAS if overall ≥ `strongBuyOverallMin`, else BUY_BIAS | BUY |
| WAIT_* / HOLD | HOLD_BIAS | HOLD |
| REDUCE | SELL_BIAS | SELL |
| AVOID | STRONG_SELL_BIAS if overall < `strongSellOverallMax`, else SELL_BIAS | HOLD (AVOID implies no position) |
| INSUFFICIENT_DATA | null | HOLD |

- [ ] **Step 1: Write the failing test** `backend/tests/unit/decisionEngine.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { type DecisionInput, decide } from '../../src/scoring/DecisionEngine.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

const T = SEED_CONFIG.thresholds;
/** A clean BUY_ZONE setup; each test changes one thing. */
const ready = (over: Partial<DecisionInput> = {}): DecisionInput => ({
  dailyBars: 500, price: 100.2, stale: false, lastBarDate: '2026-10-05', overall: 70, qualityScore: 60,
  trend: 'UPTREND', regime: 'RISK_ON', valuationLabel: 'FAIR', sma50: 100, sma200: 90, rsi14: 55, atr14: 2,
  trade: { basis: 'SUPPORT', entryLow: 99, entryHigh: 101, stop: 96, target1: 110, target2: 115, riskReward: 2.2, positionSizeHint: 100 },
  holdsPosition: false, ...over,
});
const BANNED = /guarantee|definitely|sure-shot|certain to|risk-free/i;

describe('decide (PRD §8.5)', () => {
  it('rule 5: BUY_ZONE with a priced invalidation; strong bias at overall ≥ 80', () => {
    const d = decide(ready(), T);
    expect(d).toMatchObject({ actionState: 'BUY_ZONE', bias: 'BUY_BIAS', paperSignal: 'BUY', rule: 5 });
    expect(d.invalidation).toContain('₹96.00');
    expect(decide(ready({ overall: 85 }), T).bias).toBe('STRONG_BUY_BIAS');
  });

  it('rule 1: insufficient bars, no price, stale data or no score → INSUFFICIENT_DATA', () => {
    for (const over of [{ dailyBars: 150 }, { price: null }, { overall: null }] as Partial<DecisionInput>[]) {
      expect(decide(ready(over), T)).toMatchObject({ actionState: 'INSUFFICIENT_DATA', bias: null, paperSignal: 'HOLD', rule: 1 });
    }
    const stale = decide(ready({ stale: true, lastBarDate: '2026-09-20' }), T);
    expect(stale.actionState).toBe('INSUFFICIENT_DATA');
    expect(stale.invalidation).toMatch(/2026-09-20/);
  });

  it('rule 2: AVOID on a weak overall score; REDUCE when a paper position is held', () => {
    expect(decide(ready({ overall: 30 }), T)).toMatchObject({ actionState: 'AVOID', bias: 'SELL_BIAS', paperSignal: 'HOLD', rule: 2 });
    expect(decide(ready({ overall: 20 }), T).bias).toBe('STRONG_SELL_BIAS');
    expect(decide(ready({ overall: 30, holdsPosition: true }), T)).toMatchObject({ actionState: 'REDUCE', bias: 'SELL_BIAS', paperSignal: 'SELL' });
    const weakAll = ready({ overall: 50, trend: 'DOWNTREND', regime: 'RISK_OFF', qualityScore: 30, price: 85 });
    expect(decide(weakAll, T)).toMatchObject({ actionState: 'AVOID', rule: 2 });
    expect(decide(weakAll, T).invalidation).toContain('₹90.00');
  });

  it('rule 3: below SMA200 or in a downtrend → WAIT_FOR_CONFIRMATION (quality acceptable)', () => {
    const below = decide(ready({ price: 85 }), T);
    expect(below).toMatchObject({ actionState: 'WAIT_FOR_CONFIRMATION', bias: 'HOLD_BIAS', rule: 3 });
    expect(below.invalidation).toContain('₹90.00');
    expect(decide(ready({ overall: 50, trend: 'DOWNTREND', regime: 'RISK_OFF', qualityScore: 60, price: 85 }), T).actionState).toBe('WAIT_FOR_CONFIRMATION');
  });

  it('rule 4: extended above SMA50, overbought RSI or above entry + ATR → WAIT_FOR_PULLBACK', () => {
    const extended = decide(ready({ price: 109 }), T);
    expect(extended).toMatchObject({ actionState: 'WAIT_FOR_PULLBACK', rule: 4 });
    expect(extended.invalidation).toContain('₹99.00–₹101.00');
    expect(decide(ready({ rsi14: 75 }), T).actionState).toBe('WAIT_FOR_PULLBACK');
    expect(decide(ready({ price: 103.5 }), T).actionState).toBe('WAIT_FOR_PULLBACK');
  });

  it('first matching rule wins', () => {
    expect(decide(ready({ overall: 30, price: 85 }), T).rule).toBe(2);
    expect(decide(ready({ price: 85, rsi14: 80 }), T).rule).toBe(3);
    expect(decide(ready({ rsi14: 75, valuationLabel: 'OVERVALUED' }), T).rule).toBe(4);
  });

  it('rule 6: HOLD when any BUY_ZONE condition fails', () => {
    for (const over of [
      { valuationLabel: 'OVERVALUED' }, { trade: { ...ready().trade!, riskReward: 1.5 } }, { regime: 'RISK_OFF' },
      { price: 102 }, { overall: 60 }, { trade: null },
    ] as Partial<DecisionInput>[]) {
      expect(decide(ready(over), T)).toMatchObject({ actionState: 'HOLD', bias: 'HOLD_BIAS', paperSignal: 'HOLD', rule: 6 });
    }
    expect(decide(ready({ overall: 60 }), T).invalidation).toContain('₹96.00');
  });

  it('never uses banned certainty language', () => {
    const states = [ready(), ready({ dailyBars: 10 }), ready({ overall: 30 }), ready({ price: 85 }), ready({ price: 109 }), ready({ overall: 60 }), ready({ trade: null, overall: 60 })];
    for (const s of states) expect(decide(s, T).invalidation).not.toMatch(BANNED);
  });
});
```
The `ready().trade!` non-null assertion is inside a test only. If lint forbids `!` in tests too, use `const trade = ready().trade; if (!trade) throw new Error('fixture');` and spread `trade`.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/scoring/DecisionEngine.ts`

```ts
import type { ActionState, MarketRegime, RecommendationBias, SignalType, Trend, ValuationLabel } from '../domain/enums.js';
import type { ScoringThresholds } from './config.js';
import type { TradeLevels } from '../technical/levels.js';
import { formatInr } from '../utils/format.js';

export interface DecisionInput {
  dailyBars: number;
  price: number | null;
  /** True when the last daily bar is older than thresholds.maxStaleSessions completed sessions. */
  stale: boolean;
  lastBarDate: string | null;
  overall: number | null;
  qualityScore: number | null;
  trend: Trend | null;
  regime: MarketRegime | null;
  valuationLabel: ValuationLabel;
  sma50: number | null;
  sma200: number | null;
  rsi14: number | null;
  atr14: number | null;
  trade: TradeLevels | null;
  holdsPosition: boolean;
}

export interface Decision {
  actionState: ActionState;
  bias: RecommendationBias | null;
  paperSignal: SignalType;
  rule: 1 | 2 | 3 | 4 | 5 | 6;
  reason: string;
  /** What would make this view wrong, with a computed price. Bias language only (PRD §1). */
  invalidation: string;
}

const make = (
  actionState: ActionState, bias: RecommendationBias | null, paperSignal: SignalType, rule: Decision['rule'], reason: string, invalidation: string,
): Decision => ({ actionState, bias, paperSignal, rule, reason, invalidation });

/** PRD §8.5 ordered rule table: the first matching rule wins. */
export function decide(i: DecisionInput, t: ScoringThresholds): Decision {
  const { price, overall, trade } = i;

  // Rule 1: not enough trustworthy data to hold any view.
  if (i.dailyBars < t.minDailyBars || price === null || overall === null || i.stale) {
    const why =
      i.stale ? `price data is stale (last daily bar ${i.lastBarDate ?? 'unknown'})`
      : price === null ? 'no current price'
      : i.dailyBars < t.minDailyBars ? `only ${i.dailyBars} of ${t.minDailyBars} daily bars`
      : 'no factor scores available';
    return make('INSUFFICIENT_DATA', null, 'HOLD', 1, why, `No bias: ${why}. Re-evaluate after fresh data is synced.`);
  }

  // Rule 2: weak overall, or a downtrend in a risk-off market with weak quality.
  const weakQuality = i.qualityScore !== null && i.qualityScore < t.weakQualityMax;
  if (overall < t.avoidOverallMax || (i.trend === 'DOWNTREND' && i.regime === 'RISK_OFF' && weakQuality)) {
    const level = i.sma200 ?? i.sma50 ?? price;
    const invalidation = `Reconsider only after a daily close above ${formatInr(level)}${i.sma200 !== null ? ' (200-day average)' : ''}.`;
    if (i.holdsPosition) return make('REDUCE', 'SELL_BIAS', 'SELL', 2, 'weak setup while a paper position is held', invalidation);
    return make('AVOID', overall < t.strongSellOverallMax ? 'STRONG_SELL_BIAS' : 'SELL_BIAS', 'HOLD', 2, 'weak overall setup', invalidation);
  }

  // Rule 3: trend not confirmed.
  if (i.trend === 'DOWNTREND' || (i.sma200 !== null && price < i.sma200)) {
    const below200 = i.sma200 !== null && price < i.sma200;
    const level = below200 ? i.sma200 : (i.sma50 ?? i.sma200);
    const invalidation = level === null
      ? 'Needs a confirmed uptrend before a buy bias.'
      : `Needs a daily close above ${formatInr(level)} (${below200 ? '200' : '50'}-day average) to confirm the trend.`;
    return make('WAIT_FOR_CONFIRMATION', 'HOLD_BIAS', 'HOLD', 3, 'trend not confirmed', invalidation);
  }

  // Rule 4: price extended.
  const extended =
    (i.sma50 !== null && price > i.sma50 * (1 + t.extendedAboveSma50Pct / 100)) ||
    (i.rsi14 !== null && i.rsi14 > t.rsiOverbought) ||
    (trade !== null && i.atr14 !== null && price > trade.entryHigh + i.atr14);
  if (extended) {
    const invalidation = trade
      ? `Re-evaluate on a pullback into ${formatInr(trade.entryLow)}–${formatInr(trade.entryHigh)}; the setup fails below ${formatInr(trade.stop)}.`
      : `Re-evaluate on a pullback toward the 50-day average near ${formatInr(i.sma50 ?? price)}.`;
    return make('WAIT_FOR_PULLBACK', 'HOLD_BIAS', 'HOLD', 4, 'price extended', invalidation);
  }

  // Rule 5: buy zone.
  if (
    overall >= t.buyOverallMin && i.valuationLabel !== 'OVERVALUED' && trade !== null &&
    price >= trade.entryLow && price <= trade.entryHigh && i.regime !== 'RISK_OFF' && trade.riskReward >= t.minRiskReward
  ) {
    return make(
      'BUY_ZONE', overall >= t.strongBuyOverallMin ? 'STRONG_BUY_BIAS' : 'BUY_BIAS', 'BUY', 5, 'all buy-zone conditions met',
      `Bias invalid on a daily close below ${formatInr(trade.stop)} (stop-loss).`,
    );
  }

  // Rule 6: hold.
  const invalidation = trade
    ? `Reassess on a daily close below ${formatInr(trade.stop)}.`
    : i.sma50 !== null
      ? `Reassess on a daily close below the 50-day average near ${formatInr(i.sma50)}.`
      : 'Reassess when more data is available.';
  return make('HOLD', 'HOLD_BIAS', 'HOLD', 6, 'no rule triggered a change', invalidation);
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): decision engine (PRD rule table, bias, paper signal, priced invalidation)`.

---

### Task 7: `buildEvaluation`, composing the engines with a canonical input hash

**Files:** Create `backend/src/scoring/evaluate.ts`. Test: `backend/tests/unit/evaluate.test.ts`.

**Interfaces:**
- Consumes everything from Tasks 1–6, plus `SnapshotMetrics` (`domain/fundamentals.ts`) and `toIst`.
- Produces:
  - `StatementRow { periodEnd; revenue; netProfit; eps }` (all `number | null` except `periodEnd`)
  - `MarketContext { nifty: DatedClose[]; niftyTrend; regime; vix }`
  - `SectorContext { closes: DatedClose[]; trend } | null`
  - `EvaluationInputs { stock: { id; symbol; sector }; dataMode; bars; stale; market; sector; fundamentals: { asOf; snapshot; quarterly; annual }; peerPes; news; holdsPosition; capital; config; now }`
  - `EvaluationRecord { stockId; dataMode; dataAsOf; scoringConfigVersion; scores: { technical; quality; valuation; news; momentum; marketContext; overall; risk }; riskLevel; trend; valuationLabel; marketRegime; actionState; recommendationBias; paperSignal; trade; invalidation; factorsAvailable; inputs; inputHash }`
  - `EvaluationBuild { record; indicatorSeries: IndicatorPoint[]; decision }`
  - `canonicalJson(value)`, `buildEvaluation(inputs)`, `FINANCIAL_SECTORS`
  - `datedCloses(bars)`: the IST-dated closes
  - `trendOf(bars)`: the trend of an instrument's daily bars, used for NIFTY and sector indices

- [ ] **Step 1: Write the failing test** `backend/tests/unit/evaluate.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';
import { buildEvaluation, canonicalJson, type EvaluationInputs, trendOf } from '../../src/scoring/evaluate.js';
import { ENGINE_VERSION } from '../../src/scoring/rubrics.js';
import type { OhlcvBar } from '../../src/technical/indicators.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

const NOW = new Date('2026-10-06T12:00:00Z');
function bars(n: number, drift = 0.0008): OhlcvBar[] {
  let s = 7;
  const rnd = () => ((s = (s * 16807) % 2147483647), s / 2147483647);
  let p = 1000;
  return Array.from({ length: n }, (_, i) => {
    const open = p;
    p = p * (1 + drift + (rnd() - 0.5) * 0.03);
    return { ts: new Date(NOW.getTime() - (n - i) * 86_400_000), open, high: Math.max(open, p) * 1.005, low: Math.min(open, p) * 0.995, close: p, volume: 100_000 };
  });
}
const inputs = (over: Partial<EvaluationInputs> = {}): EvaluationInputs => {
  const b = bars(420);
  const nifty = b.map((x) => ({ date: x.ts.toISOString().slice(0, 10), close: x.close / 10 }));
  return {
    stock: { id: 'stock-1', symbol: 'TEST', sector: 'Information Technology' }, dataMode: 'MOCK', bars: b, stale: false,
    market: { nifty, niftyTrend: 'UPTREND', regime: 'RISK_ON', vix: 14 }, sector: null,
    fundamentals: { asOf: '2026-10-06', snapshot: { ...emptySnapshotMetrics(), pe: 25, roe: 20, debtToEquity: 0.3 }, quarterly: [], annual: [] },
    peerPes: [], news: [], holdsPosition: false, capital: 1_000_000, config: SEED_CONFIG, now: NOW, ...over,
  };
};

describe('canonicalJson', () => {
  it('sorts keys at every level and rounds numbers so equal inputs hash equally', () => {
    expect(canonicalJson({ b: 1.123456789, a: { d: [3, { z: 1, y: 2 }], c: null } })).toBe('{"a":{"c":null,"d":[3,{"y":2,"z":1}]},"b":1.123457}');
    expect(canonicalJson({ t: new Date('2026-01-01T00:00:00Z'), u: undefined })).toBe('{"t":"2026-01-01T00:00:00.000Z"}');
  });
});

describe('buildEvaluation', () => {
  it('produces a complete, DB-safe record and the full indicator series', () => {
    const { record, indicatorSeries, decision } = buildEvaluation(inputs());
    expect(indicatorSeries).toHaveLength(420);
    expect(record).toMatchObject({ stockId: 'stock-1', dataMode: 'MOCK', scoringConfigVersion: 'v1', actionState: decision.actionState });
    expect(record.dataAsOf).toEqual(inputs().bars.at(-1)?.ts);
    for (const v of Object.values(record.scores)) if (v !== null) expect(v >= 0 && v <= 100).toBe(true);
    expect(record.scores.news).toBeNull();
    expect(record.scores.technical).not.toBeNull();
    expect(record.factorsAvailable).toMatchObject({ news: false, technical: true });
    if (record.trade) {
      expect(record.trade.stop).toBeGreaterThan(0);
      expect(record.trade.entryLow).toBeLessThanOrEqual(record.trade.entryHigh);
      expect(record.trade.riskReward).toBeGreaterThanOrEqual(0);
    }
    expect(record.invalidation.length).toBeGreaterThan(10);
    expect(record.inputs).toMatchObject({ engineVersion: ENGINE_VERSION, configVersion: 'v1' });
    expect(JSON.stringify(record.inputs)).not.toMatch(/evaluatedAt|"now"/);
  });

  it('is deterministic, and the hash changes when any input that matters changes', () => {
    const a = buildEvaluation(inputs()).record.inputHash;
    expect(buildEvaluation(inputs()).record.inputHash).toBe(a);
    expect(a).toMatch(/^[a-f0-9]{64}$/);
    expect(buildEvaluation(inputs({ holdsPosition: true })).record.inputHash).not.toBe(a);
    expect(buildEvaluation(inputs({ market: { ...inputs().market, vix: 30 } })).record.inputHash).not.toBe(a);
    expect(buildEvaluation(inputs({ now: new Date(NOW.getTime() + 3_600_000) })).record.inputHash).toBe(a);
  });

  it('marks no bars, short history and stale data as INSUFFICIENT_DATA', () => {
    const empty = buildEvaluation(inputs({ bars: [] })).record;
    expect(empty).toMatchObject({ actionState: 'INSUFFICIENT_DATA', trade: null, dataAsOf: NOW });
    const short = buildEvaluation(inputs({ bars: bars(150) })).record;
    expect(short).toMatchObject({ actionState: 'INSUFFICIENT_DATA', trade: null });
    const stale = buildEvaluation(inputs({ stale: true })).record;
    expect(stale).toMatchObject({ actionState: 'INSUFFICIENT_DATA', trade: null });
  });

  it('exempts financials from D/E and uses peers for valuation when available', () => {
    const bank = buildEvaluation(inputs({ stock: { id: 's', symbol: 'BANK', sector: 'Financial Services' } })).record;
    expect((bank.inputs as { factors: { quality: { components: { debtToEquity: unknown } } } }).factors.quality.components.debtToEquity).toBeNull();
    const peers = buildEvaluation(inputs({ peerPes: [10, 12, 14, 16] })).record;
    expect(peers.valuationLabel).toBe('OVERVALUED');
  });

  it('classifies an index series trend from its bars', () => {
    expect(trendOf(bars(420, 0.003))).toBe('UPTREND');
    expect(trendOf(bars(100))).toBeNull();
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/scoring/evaluate.ts`

```ts
import { createHash } from 'node:crypto';
import type {
  ActionState, DataMode, MarketRegime, RecommendationBias, RiskLevel, SignalType, Trend, ValuationLabel,
} from '../domain/enums.js';
import type { SnapshotMetrics } from '../domain/fundamentals.js';
import type { ScoringConfig } from './config.js';
import { computeIndicatorSeries, type IndicatorPoint, type OhlcvBar } from '../technical/indicators.js';
import { computeLevels, type TradeLevels } from '../technical/levels.js';
import { beta, type DatedClose, maxDrawdownPct, relativeStrength, returnPct, round } from '../technical/stats.js';
import { classifyTrend, SMA200_SLOPE_LOOKBACK } from '../technical/trend.js';
import { toIst } from '../utils/ist.js';
import { type Decision, decide } from './DecisionEngine.js';
import { MOMENTUM, ENGINE_VERSION } from './rubrics.js';
import {
  marketContextScore, momentumScore, type NewsSentimentPoint, newsScore, overallScore, qualityScore, riskScore, technicalScore, valuationScore,
} from './ScoringEngine.js';
import { epsHistoryFromStatements, valuate } from './ValuationEngine.js';

/** Sectors where leverage is the business model: D/E is not scored (PRD §8.2). */
export const FINANCIAL_SECTORS: ReadonlySet<string> = new Set(['Financial Services']);
const DRAWDOWN_SESSIONS = 250;

export interface StatementRow {
  periodEnd: string;
  revenue: number | null;
  netProfit: number | null;
  eps: number | null;
}

export interface MarketContext {
  nifty: readonly DatedClose[];
  niftyTrend: Trend | null;
  regime: MarketRegime | null;
  vix: number | null;
}

export interface EvaluationInputs {
  stock: { id: string; symbol: string; sector: string | null };
  dataMode: DataMode;
  /** Daily bars, oldest first. */
  bars: readonly OhlcvBar[];
  stale: boolean;
  market: MarketContext;
  sector: { closes: readonly DatedClose[]; trend: Trend | null } | null;
  fundamentals: { asOf: string | null; snapshot: SnapshotMetrics | null; quarterly: readonly StatementRow[]; annual: readonly StatementRow[] };
  peerPes: readonly number[];
  news: readonly NewsSentimentPoint[];
  holdsPosition: boolean;
  capital: number;
  config: ScoringConfig;
  now: Date;
}

export interface EvaluationRecord {
  stockId: string;
  dataMode: DataMode;
  dataAsOf: Date;
  scoringConfigVersion: string;
  scores: {
    technical: number | null; quality: number | null; valuation: number | null; news: number | null;
    momentum: number | null; marketContext: number | null; overall: number | null; risk: number | null;
  };
  riskLevel: RiskLevel | null;
  trend: Trend | null;
  valuationLabel: ValuationLabel;
  marketRegime: MarketRegime | null;
  actionState: ActionState;
  recommendationBias: RecommendationBias | null;
  paperSignal: SignalType;
  trade: TradeLevels | null;
  invalidation: string;
  factorsAvailable: Record<string, unknown>;
  inputs: Record<string, unknown>;
  inputHash: string;
}

export interface EvaluationBuild {
  record: EvaluationRecord;
  indicatorSeries: IndicatorPoint[];
  decision: Decision;
}

/** Stable JSON: keys sorted at every level, numbers rounded to 6 decimals, Dates as ISO, undefined dropped. */
export function canonicalJson(value: unknown): string {
  const normalise = (v: unknown): unknown => {
    if (v instanceof Date) return v.toISOString();
    if (typeof v === 'number') return Number.isFinite(v) ? round(v, 6) : null;
    if (Array.isArray(v)) return v.map(normalise);
    if (v && typeof v === 'object') {
      const out: Record<string, unknown> = {};
      for (const key of Object.keys(v).sort()) {
        const item = (v as Record<string, unknown>)[key];
        if (item !== undefined) out[key] = normalise(item);
      }
      return out;
    }
    return v;
  };
  return JSON.stringify(normalise(value));
}

export const datedCloses = (bars: readonly OhlcvBar[]): DatedClose[] => bars.map((b) => ({ date: toIst(b.ts).date, close: b.close }));

/** Trend of any instrument from its daily bars (used for NIFTY 50 and sector indices). */
export function trendOf(bars: readonly OhlcvBar[]): Trend | null {
  const series = computeIndicatorSeries(bars);
  const last = series.at(-1)?.values;
  return classifyTrend({
    close: bars.at(-1)?.close ?? null,
    sma50: last?.sma50 ?? null,
    sma200: last?.sma200 ?? null,
    sma200Prev: series.at(-1 - SMA200_SLOPE_LOOKBACK)?.values.sma200 ?? null,
  });
}

function annualGrowth(rows: readonly StatementRow[], key: 'revenue' | 'netProfit'): number[] {
  const out: number[] = [];
  for (let k = 1; k < rows.length; k += 1) {
    const prev = rows[k - 1]?.[key];
    const cur = rows[k]?.[key];
    if (prev !== null && prev !== undefined && cur !== null && cur !== undefined && prev > 0) out.push((cur / prev - 1) * 100);
  }
  return out;
}

/** Composes all engines into one stock evaluation. Pure: same inputs → same record and hash. */
export function buildEvaluation(i: EvaluationInputs): EvaluationBuild {
  const t = i.config.thresholds;
  const series = computeIndicatorSeries(i.bars);
  const v = series.at(-1)?.values ?? null;
  const lastBar = i.bars.at(-1) ?? null;
  const price = lastBar?.close ?? null;
  const closes = datedCloses(i.bars);
  const trend = classifyTrend({
    close: price, sma50: v?.sma50 ?? null, sma200: v?.sma200 ?? null,
    sma200Prev: series.at(-1 - SMA200_SLOPE_LOOKBACK)?.values.sma200 ?? null,
  });

  const levels = price === null
    ? null
    : computeLevels({
        bars: i.bars, price, atr: v?.atr14 ?? null, sma20: v?.sma20 ?? null, sma50: v?.sma50 ?? null, sma200: v?.sma200 ?? null,
        trend, capital: i.capital, riskPct: t.riskPerTradePct, stopAtrMultiple: t.stopAtrMultiple, entryAtrWidth: t.entryAtrWidth,
      });
  const trade = levels?.trade ?? null;

  const annual = [...i.fundamentals.annual].sort((a, b) => a.periodEnd.localeCompare(b.periodEnd));
  const snapshot = i.fundamentals.snapshot;
  const valuation = valuate({
    closes,
    epsHistory: epsHistoryFromStatements(i.fundamentals.quarterly, annual),
    snapshotPe: snapshot?.pe ?? null,
    peerPes: i.peerPes,
    thresholds: { lowPctile: t.valuationLowPctile, highPctile: t.valuationHighPctile, minSectorPeers: t.minSectorPeers },
  });

  const technical = technicalScore({
    close: price, prevClose: i.bars.at(-2)?.close ?? null, volume: lastBar?.volume ?? null, volumeSma20: v?.volumeSma20 ?? null,
    trend, rsi14: v?.rsi14 ?? null, macd: v?.macd ?? null, macdSignal: v?.macdSignal ?? null, adx14: v?.adx14 ?? null,
  });
  const quality = qualityScore({
    roe: snapshot?.roe ?? null, roce: snapshot?.roce ?? null, debtToEquity: snapshot?.debtToEquity ?? null,
    isFinancial: i.stock.sector !== null && FINANCIAL_SECTORS.has(i.stock.sector),
    netMargins: annual.flatMap((r) => (r.revenue !== null && r.revenue > 0 && r.netProfit !== null ? [(r.netProfit / r.revenue) * 100] : [])),
    revenueGrowth: annualGrowth(annual, 'revenue'),
    profitGrowth: annualGrowth(annual, 'netProfit'),
  });
  const valuationFactor = valuationScore({ ownPercentile: valuation.ownPercentile, sectorPercentile: valuation.sectorPercentile, currentPe: valuation.currentPe });
  const news = newsScore(i.news, i.now, t.newsHalfLifeDays);
  const momentum = momentumScore({
    return1m: returnPct(closes, MOMENTUM.sessions.m1),
    return3m: returnPct(closes, MOMENTUM.sessions.m3),
    return6m: returnPct(closes, MOMENTUM.sessions.m6),
    rsVsNifty: relativeStrength(closes, i.market.nifty, MOMENTUM.sessions.m6),
    rsVsSector: i.sector ? relativeStrength(closes, i.sector.closes, MOMENTUM.sessions.m6) : null,
  });
  const market = marketContextScore({ regime: i.market.regime, sectorTrend: i.sector?.trend ?? null, vix: i.market.vix });

  const factors = {
    technical: technical.score, quality: quality.score, valuation: valuationFactor.score,
    news: news.score, momentum: momentum.score, market_context: market.score,
  };
  const overall = overallScore(factors, i.config.weights);
  const entryMid = trade ? (trade.entryLow + trade.entryHigh) / 2 : null;
  const risk = riskScore({
    atrPct: v?.atr14 !== null && v?.atr14 !== undefined && price ? (v.atr14 / price) * 100 : null,
    beta: beta(closes, i.market.nifty),
    maxDrawdownPct: maxDrawdownPct(closes.slice(-DRAWDOWN_SESSIONS).map((c) => c.close)),
    stopDistancePct: trade && entryMid ? ((entryMid - trade.stop) / entryMid) * 100 : null,
  });

  const decision = decide(
    {
      dailyBars: i.bars.length, price, stale: i.stale, lastBarDate: lastBar ? toIst(lastBar.ts).date : null,
      overall: overall.overall, qualityScore: quality.score, trend, regime: i.market.regime, valuationLabel: valuation.label,
      sma50: v?.sma50 ?? null, sma200: v?.sma200 ?? null, rsi14: v?.rsi14 ?? null, atr14: v?.atr14 ?? null,
      trade, holdsPosition: i.holdsPosition,
    },
    t,
  );

  // Everything the result depends on (never the wall clock unless news decay uses it).
  const inputs: Record<string, unknown> = {
    engineVersion: ENGINE_VERSION,
    configVersion: i.config.version,
    weights: i.config.weights,
    thresholds: t,
    lastBar: lastBar ? { ts: lastBar.ts, close: lastBar.close, volume: lastBar.volume } : null,
    dailyBars: i.bars.length,
    stale: i.stale,
    indicators: v,
    trend,
    market: { niftyTrend: i.market.niftyTrend, regime: i.market.regime, vix: i.market.vix },
    sectorTrend: i.sector?.trend ?? null,
    fundamentalsAsOf: i.fundamentals.asOf,
    snapshot,
    valuation,
    peerPes: i.peerPes,
    news: i.news.length > 0 ? { asOfDate: toIst(i.now).date, points: i.news } : null,
    holdsPosition: i.holdsPosition,
    capital: i.capital,
    levels: levels ? { trade, reason: levels.reason, supports: levels.supports.slice(0, 3), resistances: levels.resistances.slice(0, 3) } : null,
    factors: { technical, quality, valuation: valuationFactor, news, momentum, market_context: market },
    risk: { components: risk.components },
    decision: { rule: decision.rule, reason: decision.reason },
  };

  const record: EvaluationRecord = {
    stockId: i.stock.id,
    dataMode: i.dataMode,
    dataAsOf: lastBar?.ts ?? i.now,
    scoringConfigVersion: i.config.version,
    scores: {
      technical: technical.score, quality: quality.score, valuation: valuationFactor.score, news: news.score,
      momentum: momentum.score, marketContext: market.score, overall: overall.overall, risk: risk.score,
    },
    riskLevel: risk.level,
    trend,
    valuationLabel: valuation.label,
    marketRegime: i.market.regime,
    actionState: decision.actionState,
    recommendationBias: decision.bias,
    paperSignal: decision.paperSignal,
    // Rule 1 (insufficient/stale data): never store prices derived from untrustworthy bars.
    trade: decision.rule === 1 ? null : trade,
    invalidation: decision.invalidation,
    factorsAvailable: {
      ...Object.fromEntries(Object.entries(factors).map(([k, s]) => [k, s !== null])),
      coverage: overall.coverage,
    },
    inputs,
    inputHash: createHash('sha256').update(canonicalJson(inputs)).digest('hex'),
  };
  return { record, indicatorSeries: series, decision };
}
```
Check the peers case in the test. P/E = 25, with no statements, so the current P/E is the snapshot's 25. Peers [10, 12, 14, 16] are all ≤ 25, so the sector percentile is 100 → OVERVALUED. (The own history is unavailable: no EPS points.)

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): buildEvaluation composes engines into a hashed, explainable evaluation record`.

---
### Task 8: Repositories (config, indicators, evaluations, positions, links, peers, news sentiment)

**Files:**
- Create:
  - `backend/src/repositories/ScoringConfigRepository.ts`
  - `backend/src/repositories/TechnicalIndicatorRepository.ts`
  - `backend/src/repositories/EvaluationRepository.ts`
  - `backend/src/repositories/PaperPositionRepository.ts`
- Modify:
  - `backend/src/repositories/MarketRepository.ts` (`linksForStock`)
  - `backend/src/repositories/FundamentalsRepository.ts` (`sectorPeerPes`)
  - `backend/src/repositories/NewsRepository.ts` (`sentimentsForStock`)
- Test: `backend/tests/integration/analysisRepositories.test.ts`

**Interfaces:**
- Consumes: `parseScoringConfig` (Task 5), `IndicatorPoint` (Task 1), `EvaluationRecord` (Task 7), `NewsSentimentPoint` (Task 5).
- Produces:
  - `ScoringConfigRepository.getActive(): Promise<ScoringConfig>` (`NOT_FOUND` if none)
  - `TechnicalIndicatorRepository`:
    - `upsertSeries(stockId, mode, timeframe, points): Promise<number>`
    - `latest(stockId, mode, timeframe): Promise<{ ts; values } | null>`
  - `EvaluationRepository`:
    - `insert(record): Promise<{ id; inserted: boolean }>`
    - `latest(stockId, mode): Promise<StoredEvaluation | null>`
    - `StoredEvaluation { id; evaluatedAt; dataAsOf; scoringConfigVersion; actionState; recommendationBias; overallScore; riskLevel; entryLow; entryHigh; stopLoss; target1; target2; riskReward; positionSizeHint; invalidation; inputHash }`
  - `PaperPositionRepository.holdsPosition(stockId, mode): Promise<boolean>`
  - `MarketRepository.linksForStock(stockId): Promise<Array<{ market: Market; linkType: 'BENCHMARK' | 'SECTOR_INDEX' | 'CONSTITUENT' }>>`
  - `FundamentalsRepository.sectorPeerPes(sector, excludeStockId, mode): Promise<number[]>`: positive P/E from each active peer's latest snapshot
  - `NewsRepository.sentimentsForStock(stockId, mode, since): Promise<NewsSentimentPoint[]>`: the latest analysis per article

- [ ] **Step 1: Write the failing test** `backend/tests/integration/analysisRepositories.test.ts`

```ts
import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { PaperPositionRepository } from '../../src/repositories/PaperPositionRepository.js';
import { ScoringConfigRepository } from '../../src/repositories/ScoringConfigRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { TechnicalIndicatorRepository } from '../../src/repositories/TechnicalIndicatorRepository.js';
import type { EvaluationRecord } from '../../src/scoring/evaluate.js';
import type { IndicatorPoint } from '../../src/technical/indicators.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const idOf = async (trx: Database, symbol: string) => (await new StockRepository(trx).findBySymbol(symbol))?.id ?? '';

const point = (ts: string, sma20: number | null): IndicatorPoint => ({
  ts: new Date(ts), vwap: null, pivots: { p: 100, r1: 105, s1: 95, r2: 110, s2: 90 },
  values: {
    sma20, sma50: null, sma200: null, ema20: null, ema50: null, ema200: null, rsi14: 55.123, macd: null, macdSignal: null, macdHistogram: null,
    bollingerUpper: null, bollingerMiddle: null, bollingerLower: null, atr14: 2.5, adx14: null, stochK: null, stochD: null, volumeSma20: 1000,
  },
});

const record = (stockId: string, over: Partial<EvaluationRecord> = {}): EvaluationRecord => ({
  stockId, dataMode: 'MOCK', dataAsOf: new Date('2026-10-05T03:45:00Z'), scoringConfigVersion: 'v1',
  scores: { technical: 70, quality: null, valuation: 55, news: null, momentum: 60, marketContext: 80, overall: 66.5, risk: 40 },
  riskLevel: 'MEDIUM', trend: 'UPTREND', valuationLabel: 'FAIR', marketRegime: 'RISK_ON', actionState: 'BUY_ZONE',
  recommendationBias: 'BUY_BIAS', paperSignal: 'BUY',
  trade: { basis: 'SUPPORT', entryLow: 99, entryHigh: 101, stop: 96, target1: 110, target2: 115, riskReward: 2.2, positionSizeHint: 100 },
  invalidation: 'Bias invalid on a daily close below ₹96.00 (stop-loss).',
  factorsAvailable: { technical: true, coverage: 0.7 }, inputs: { engineVersion: 'engine-1' }, inputHash: 'a'.repeat(64), ...over,
});

describe('analysis repositories', () => {
  it('reads the active scoring config with defaults applied', async () => {
    const c = await new ScoringConfigRepository(db).getActive();
    expect(c).toMatchObject({ version: 'v1', thresholds: { buyOverallMin: 65, maxStaleSessions: 3 } });
  });

  it('upserts an indicator series (re-runs update in place) and reads the latest point', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'technical_indicators');
      const repo = new TechnicalIndicatorRepository(trx);
      const id = await idOf(trx, 'RELIANCE');
      expect(await repo.upsertSeries(id, 'MOCK', '1d', [point('2026-10-01T03:45:00Z', 100), point('2026-10-02T03:45:00Z', 101)])).toBe(2);
      expect(await repo.upsertSeries(id, 'MOCK', '1d', [point('2026-10-02T03:45:00Z', 102.5)])).toBe(1);
      const latest = await repo.latest(id, 'MOCK', '1d');
      expect(latest?.ts).toEqual(new Date('2026-10-02T03:45:00Z'));
      expect(latest?.values).toMatchObject({ sma20: 102.5, rsi14: 55.12, atr14: 2.5, sma200: null });
      expect(await repo.latest(id, 'LIVE', '1d')).toBeNull();
    });
  });

  it('stores an evaluation once per input hash', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'stock_evaluations');
      const repo = new EvaluationRepository(trx);
      const id = await idOf(trx, 'RELIANCE');
      const first = await repo.insert(record(id));
      expect(first.inserted).toBe(true);
      expect(await repo.insert(record(id))).toEqual({ id: first.id, inserted: false });
      const next = await repo.insert(record(id, { inputHash: 'b'.repeat(64), actionState: 'HOLD', recommendationBias: 'HOLD_BIAS', trade: null }));
      expect(next.inserted).toBe(true);
      expect(await repo.latest(id, 'MOCK')).toMatchObject({ id: next.id, actionState: 'HOLD', entryLow: null, inputHash: 'b'.repeat(64) });
    });
  });

  it('knows whether a paper position is held in a data mode', async () => {
    await withRollback(db, async (trx) => {
      const repo = new PaperPositionRepository(trx);
      const stockId = await idOf(trx, 'TCS');
      expect(await repo.holdsPosition(stockId, 'MOCK')).toBe(false);
      const userId = randomUUID();
      await sql`insert into auth.users (id, email) values (${userId}, ${`${userId}@example.com`})`.execute(trx);
      const account = await trx.selectFrom('paper_accounts').select('id').where('user_id', '=', userId).where('data_mode', '=', 'MOCK').executeTakeFirstOrThrow();
      await trx.insertInto('paper_positions').values({ account_id: account.id, stock_id: stockId, quantity: 5, average_buy_price: 3000 }).execute();
      expect(await repo.holdsPosition(stockId, 'MOCK')).toBe(true);
      expect(await repo.holdsPosition(stockId, 'LIVE')).toBe(false);
    });
  });

  it('lists index links for a stock', async () => {
    const id = await idOf(db, 'HDFCBANK');
    const links = await new MarketRepository(db).linksForStock(id);
    expect(links.map((l) => [l.market.symbol, l.linkType]).sort()).toEqual([
      ['BANKNIFTY', 'SECTOR_INDEX'], ['NIFTY50', 'BENCHMARK'], ['NIFTYFINSERVICE', 'SECTOR_INDEX'],
    ]);
  });

  it('collects sector peers\' latest positive P/E, excluding the stock itself', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots');
      const repo = new FundamentalsRepository(trx);
      const snap = async (symbol: string, asOf: string, pe: number | null) =>
        repo.upsertSnapshot({ stockId: await idOf(trx, symbol), dataMode: 'MOCK', asOf, source: 'mock', metrics: { ...emptySnapshotMetrics(), pe }, raw: {} });
      await snap('HDFCBANK', '2026-10-06', 15);
      await snap('ICICIBANK', '2026-10-05', 30);
      await snap('ICICIBANK', '2026-10-06', 18);
      await snap('SBIN', '2026-10-06', -2);
      await snap('AXISBANK', '2026-10-06', null);
      await snap('TCS', '2026-10-06', 25);
      expect(await repo.sectorPeerPes('Financial Services', await idOf(trx, 'HDFCBANK'), 'MOCK')).toEqual([18]);
    });
  });

  it('reads LLM news sentiment for a stock (latest analysis per article)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const stockId = await idOf(trx, 'INFY');
      const news = new NewsRepository(trx);
      const { ids } = await news.saveArticles([{ dataMode: 'MOCK', title: 'Infosys wins deal', description: null, content: null, source: 'example.com', sourceUrl: 'https://example.com/infy', author: null, publishedAt: new Date('2026-10-04T06:00:00Z'), language: 'en', contentHash: 'c'.repeat(64) }]);
      const newsId = ids[0] ?? '';
      const analysis = (prompt: string, score: number) => ({ news_id: newsId, stock_id: stockId, sentiment: 'BULLISH' as const, sentiment_score: score, confidence: 70, relevance_score: 0.9, impact_level: 'MEDIUM' as const, summary: 's', model: 'm', prompt_version: prompt });
      await trx.insertInto('news_ai_analysis').values([analysis('v1', 60), analysis('v2', 72)]).execute();
      const points = await news.sentimentsForStock(stockId, 'MOCK', new Date('2026-10-01T00:00:00Z'));
      expect(points).toHaveLength(1);
      expect(points[0]).toMatchObject({ relevance: 0.9, publishedAt: new Date('2026-10-04T06:00:00Z') });
      expect(await news.sentimentsForStock(stockId, 'LIVE', new Date('2026-10-01T00:00:00Z'))).toEqual([]);
    });
  });
});
```
The latest analysis per article is the newest `created_at`. Both rows insert in the same transaction, where `now()` is equal, so ties break on `prompt_version desc` (v2 → 72). Assert only the relevance and date, as above, to stay robust.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (modules or methods missing).

- [ ] **Step 3: Implement**

`backend/src/repositories/ScoringConfigRepository.ts`:
```ts
import type { Database } from '../database/db.js';
import { parseScoringConfig, type ScoringConfig } from '../scoring/config.js';
import { AppError } from '../utils/errors.js';

export class ScoringConfigRepository {
  constructor(private readonly db: Database) {}

  /** The single active config (a partial unique index guarantees at most one). */
  async getActive(): Promise<ScoringConfig> {
    const row = await this.db.selectFrom('scoring_configs').select(['version', 'weights', 'thresholds']).where('is_active', '=', true).executeTakeFirst();
    if (!row) throw new AppError('NOT_FOUND', 'No active scoring config');
    return parseScoringConfig(row);
  }
}
```
`backend/src/repositories/TechnicalIndicatorRepository.ts`:
```ts
import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { BarInterval, DataMode } from '../domain/enums.js';
import type { IndicatorPoint, IndicatorValues } from '../technical/indicators.js';
import { round } from '../technical/stats.js';

const CHUNK = 500;
const n4 = (v: number | null) => (v === null ? null : round(v, 4));
/** public.score columns are numeric(5,2) within 0–100. */
const n2 = (v: number | null) => (v === null ? null : round(Math.min(100, Math.max(0, v)), 2));

export class TechnicalIndicatorRepository {
  constructor(private readonly db: Database) {}

  /** Upserts the series: a re-run recomputes and overwrites (self-healing). Returns rows written. */
  async upsertSeries(stockId: string, mode: DataMode, timeframe: BarInterval, points: readonly IndicatorPoint[]): Promise<number> {
    let written = 0;
    for (let i = 0; i < points.length; i += CHUNK) {
      const rows = points.slice(i, i + CHUNK).map(({ ts, values: v, pivots, vwap }) => ({
        stock_id: stockId, data_mode: mode, timeframe, ts,
        sma_20: n4(v.sma20), sma_50: n4(v.sma50), sma_200: n4(v.sma200),
        ema_20: n4(v.ema20), ema_50: n4(v.ema50), ema_200: n4(v.ema200),
        rsi_14: n2(v.rsi14), macd: n4(v.macd), macd_signal: n4(v.macdSignal), macd_histogram: n4(v.macdHistogram),
        bollinger_upper: n4(v.bollingerUpper), bollinger_middle: n4(v.bollingerMiddle), bollinger_lower: n4(v.bollingerLower),
        atr_14: n4(v.atr14), adx_14: n2(v.adx14), stoch_k: n2(v.stochK), stoch_d: n2(v.stochD),
        vwap: n4(vwap), volume_sma_20: v.volumeSma20 === null ? null : round(v.volumeSma20, 2),
        pivots: sql<string>`${JSON.stringify(pivots ?? {})}::jsonb`,
      }));
      const result = await this.db
        .insertInto('technical_indicators')
        .values(rows)
        .onConflict((oc) => oc.columns(['stock_id', 'data_mode', 'timeframe', 'ts']).doUpdateSet((eb) => ({
          sma_20: eb.ref('excluded.sma_20'), sma_50: eb.ref('excluded.sma_50'), sma_200: eb.ref('excluded.sma_200'),
          ema_20: eb.ref('excluded.ema_20'), ema_50: eb.ref('excluded.ema_50'), ema_200: eb.ref('excluded.ema_200'),
          rsi_14: eb.ref('excluded.rsi_14'), macd: eb.ref('excluded.macd'), macd_signal: eb.ref('excluded.macd_signal'),
          macd_histogram: eb.ref('excluded.macd_histogram'), bollinger_upper: eb.ref('excluded.bollinger_upper'),
          bollinger_middle: eb.ref('excluded.bollinger_middle'), bollinger_lower: eb.ref('excluded.bollinger_lower'),
          atr_14: eb.ref('excluded.atr_14'), adx_14: eb.ref('excluded.adx_14'), stoch_k: eb.ref('excluded.stoch_k'),
          stoch_d: eb.ref('excluded.stoch_d'), vwap: eb.ref('excluded.vwap'), volume_sma_20: eb.ref('excluded.volume_sma_20'),
          pivots: eb.ref('excluded.pivots'),
        })))
        .returning('id')
        .execute();
      written += result.length;
    }
    return written;
  }

  async latest(stockId: string, mode: DataMode, timeframe: BarInterval): Promise<{ ts: Date; values: IndicatorValues } | null> {
    const r = await this.db.selectFrom('technical_indicators').selectAll()
      .where('stock_id', '=', stockId).where('data_mode', '=', mode).where('timeframe', '=', timeframe)
      .orderBy('ts', 'desc').limit(1).executeTakeFirst();
    if (!r) return null;
    return {
      ts: r.ts,
      values: {
        sma20: toNumber(r.sma_20), sma50: toNumber(r.sma_50), sma200: toNumber(r.sma_200),
        ema20: toNumber(r.ema_20), ema50: toNumber(r.ema_50), ema200: toNumber(r.ema_200),
        rsi14: toNumber(r.rsi_14), macd: toNumber(r.macd), macdSignal: toNumber(r.macd_signal), macdHistogram: toNumber(r.macd_histogram),
        bollingerUpper: toNumber(r.bollinger_upper), bollingerMiddle: toNumber(r.bollinger_middle), bollingerLower: toNumber(r.bollinger_lower),
        atr14: toNumber(r.atr_14), adx14: toNumber(r.adx_14), stochK: toNumber(r.stoch_k), stochD: toNumber(r.stoch_d),
        volumeSma20: toNumber(r.volume_sma_20),
      },
    };
  }
}
```
`backend/src/repositories/EvaluationRepository.ts`:
```ts
import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { ActionState, DataMode, RecommendationBias, RiskLevel } from '../domain/enums.js';
import type { EvaluationRecord } from '../scoring/evaluate.js';
import { AppError } from '../utils/errors.js';

export interface StoredEvaluation {
  id: string;
  evaluatedAt: Date;
  dataAsOf: Date;
  scoringConfigVersion: string;
  actionState: ActionState;
  recommendationBias: RecommendationBias | null;
  overallScore: number | null;
  riskLevel: RiskLevel | null;
  entryLow: number | null;
  entryHigh: number | null;
  stopLoss: number | null;
  target1: number | null;
  target2: number | null;
  riskReward: number | null;
  positionSizeHint: number | null;
  invalidation: string | null;
  inputHash: string;
}

const jsonb = (v: unknown) => sql<string>`${JSON.stringify(v)}::jsonb`;

export class EvaluationRepository {
  constructor(private readonly db: Database) {}

  /** One row per distinct input hash: unchanged inputs never create a new evaluation. */
  async insert(r: EvaluationRecord): Promise<{ id: string; inserted: boolean }> {
    const t = r.trade;
    const row = await this.db
      .insertInto('stock_evaluations')
      .values({
        stock_id: r.stockId, data_mode: r.dataMode, data_as_of: r.dataAsOf, scoring_config_version: r.scoringConfigVersion,
        technical_score: r.scores.technical, quality_score: r.scores.quality, valuation_score: r.scores.valuation,
        news_score: r.scores.news, momentum_score: r.scores.momentum, market_context_score: r.scores.marketContext,
        overall_score: r.scores.overall, risk_score: r.scores.risk, risk_level: r.riskLevel, trend: r.trend,
        valuation_label: r.valuationLabel, market_regime: r.marketRegime, action_state: r.actionState,
        recommendation_bias: r.recommendationBias,
        entry_low: t?.entryLow ?? null, entry_high: t?.entryHigh ?? null, stop_loss: t?.stop ?? null,
        target_1: t?.target1 ?? null, target_2: t?.target2 ?? null, risk_reward: t?.riskReward ?? null,
        position_size_hint: t?.positionSizeHint ?? null, invalidation: r.invalidation,
        // clock_timestamp(): distinct per row even inside one transaction, so latest() is deterministic.
        evaluated_at: sql`clock_timestamp()`,
        factors_available: jsonb(r.factorsAvailable), inputs: jsonb(r.inputs), input_hash: r.inputHash,
      })
      .onConflict((oc) => oc.doNothing())
      .returning('id')
      .executeTakeFirst();
    if (row) return { id: row.id, inserted: true };
    const existing = await this.db.selectFrom('stock_evaluations').select('id')
      .where('stock_id', '=', r.stockId).where('data_mode', '=', r.dataMode).where('input_hash', '=', r.inputHash)
      .executeTakeFirst();
    if (!existing) throw new AppError('INTERNAL', 'Evaluation insert conflicted but no existing row was found');
    return { id: existing.id, inserted: false };
  }

  async latest(stockId: string, mode: DataMode): Promise<StoredEvaluation | null> {
    const r = await this.db.selectFrom('stock_evaluations').selectAll()
      .where('stock_id', '=', stockId).where('data_mode', '=', mode)
      .orderBy('evaluated_at', 'desc').orderBy('created_at', 'desc').limit(1).executeTakeFirst();
    if (!r) return null;
    return {
      id: r.id, evaluatedAt: r.evaluated_at, dataAsOf: r.data_as_of, scoringConfigVersion: r.scoring_config_version,
      actionState: r.action_state, recommendationBias: r.recommendation_bias, overallScore: toNumber(r.overall_score),
      riskLevel: r.risk_level, entryLow: toNumber(r.entry_low), entryHigh: toNumber(r.entry_high), stopLoss: toNumber(r.stop_loss),
      target1: toNumber(r.target_1), target2: toNumber(r.target_2), riskReward: toNumber(r.risk_reward),
      positionSizeHint: r.position_size_hint, invalidation: r.invalidation, inputHash: r.input_hash,
    };
  }
}
```
`evaluated_at` is set with `clock_timestamp()`, so two evaluations inserted in one transaction (the test) still order deterministically.

`backend/src/repositories/PaperPositionRepository.ts`:
```ts
import type { Database } from '../database/db.js';
import type { DataMode } from '../domain/enums.js';

export class PaperPositionRepository {
  constructor(private readonly db: Database) {}

  /** True if any paper account in this data mode holds the stock (personal app: one owner). */
  async holdsPosition(stockId: string, mode: DataMode): Promise<boolean> {
    const row = await this.db
      .selectFrom('paper_positions as p')
      .innerJoin('paper_accounts as a', 'a.id', 'p.account_id')
      .select('p.id')
      .where('p.stock_id', '=', stockId)
      .where('a.data_mode', '=', mode)
      .limit(1)
      .executeTakeFirst();
    return row !== undefined;
  }
}
```
Add to `MarketRepository`:
```ts
  async linksForStock(stockId: string): Promise<Array<{ market: Market; linkType: 'BENCHMARK' | 'SECTOR_INDEX' | 'CONSTITUENT' }>> {
    const rows = await this.db
      .selectFrom('stock_market_links as l')
      .innerJoin('markets as m', 'm.id', 'l.market_id')
      .selectAll('m')
      .select('l.link_type')
      .where('l.stock_id', '=', stockId)
      .where('m.is_active', '=', true)
      .orderBy('l.link_type')
      .orderBy('m.symbol')
      .execute();
    return rows.map((r) => ({ market: mapMarket(r), linkType: r.link_type }));
  }
```
(`Market` is already imported in that file via `domain/types.js`.)

Add to `FundamentalsRepository`:
```ts
  /** Latest positive P/E of each other active stock in the sector (for sector-relative valuation). */
  async sectorPeerPes(sector: string, excludeStockId: string, mode: DataMode): Promise<number[]> {
    const rows = await this.db
      .selectFrom('fundamental_snapshots as f')
      .innerJoin('stocks as s', 's.id', 'f.stock_id')
      .select(['f.stock_id', 'f.pe'])
      .distinctOn('f.stock_id')
      .where('s.sector', '=', sector)
      .where('s.is_active', '=', true)
      .where('s.id', '!=', excludeStockId)
      .where('f.data_mode', '=', mode)
      .orderBy('f.stock_id')
      .orderBy('f.as_of', 'desc')
      .orderBy('f.created_at', 'desc')
      .execute();
    return rows.map((r) => toNumber(r.pe)).filter((pe): pe is number => pe !== null && pe > 0);
  }
```
Add to `NewsRepository` (import `NewsSentimentPoint` from `../scoring/ScoringEngine.js` and `requireNumber`, which is already imported):
```ts
  /** LLM sentiment for a stock's articles since a date; the latest analysis per article (Phase 7 writes these). */
  async sentimentsForStock(stockId: string, mode: DataMode, since: Date): Promise<NewsSentimentPoint[]> {
    const rows = await this.db
      .selectFrom('news_ai_analysis as a')
      .innerJoin('news as n', 'n.id', 'a.news_id')
      .select(['a.news_id', 'a.sentiment_score', 'a.relevance_score', 'n.published_at'])
      .distinctOn('a.news_id')
      .where('a.stock_id', '=', stockId)
      .where('n.data_mode', '=', mode)
      .where('n.published_at', '>=', since)
      .orderBy('a.news_id')
      .orderBy('a.created_at', 'desc')
      .orderBy('a.prompt_version', 'desc')
      .execute();
    return rows.map((r) => ({
      sentimentScore: requireNumber(r.sentiment_score, 'sentiment_score'),
      relevance: requireNumber(r.relevance_score, 'relevance_score'),
      publishedAt: r.published_at,
    }));
  }
```
Layering note: `NewsRepository` imports only the `NewsSentimentPoint` *type* from `scoring/`. If you prefer strict layering, move that interface to `domain/news.ts` and re-export it from `ScoringEngine.ts`, and record a ruling.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): repositories for scoring config, indicator series, evaluations, positions, peers and news sentiment`.

---

### Task 9: EvaluationService (gather → evaluate → persist → log)

**Files:** Create `backend/src/services/EvaluationService.ts`. Test: `backend/tests/integration/evaluationService.test.ts`.

**Interfaces:**
- Consumes:
  - `buildEvaluation`, `trendOf`, `datedCloses`, `StatementRow` (Task 7); `classifyRegime` (Task 2)
  - all Task 8 repositories
  - `StockRepository.listActive`, `MarketRepository.findBySymbol`, `MarketDataRepository.getBars`, `FundamentalsRepository.latestSnapshot` / `listStatements`, `AppSettingsRepository.get`, `SystemLogRepository`
  - `TradingSessions` (`sessionOn`), `mapWithConcurrency`, `toAppError`, `toIst`, `addDays`
- Produces:
  - `EvaluationRunRequest { jobName; symbols? }`
  - `StockEvaluationSummary { symbol; actionState; bias; overall; price; trade; invalidation; inserted; riskLevel; valuationLabel; trend }`
  - `EvaluationRunResult { runId; status; dataMode; configVersion; regime; stocks: { total; succeeded; failed }; evaluations: { inserted; unchanged }; indicatorRows; summaries; failures; notes }`
  - `EvaluationServiceDeps`
  - `class EvaluationService { run(request) }`
  - `HISTORY_DAYS = 1830`, `NEWS_LOOKBACK_DAYS = 30`, `SETTLE_MS = 30 * 60_000`

**Staleness:** count the trading sessions after the last daily bar's IST date whose close + 30 min is ≤ now. More than `maxStaleSessions` means stale; a gap of more than 60 days is always stale. Market context (NIFTY 50 trend, India VIX, regime) is computed **once** per run, and sector context once per sector index.

**Run status:** `FAILED` if no stock succeeded; `PARTIAL` if any stock failed; else `SUCCESS`. A stock with no or short history is a successful INSUFFICIENT_DATA evaluation, not a failure.

**Counts:** `fetched` = stocks; `inserted` = new evaluations; `skipped` = unchanged (same input hash); `failed` = failed stocks.

- [ ] **Step 1: Write the failing test** `backend/tests/integration/evaluationService.test.ts`

```ts
import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { ACTION_STATES } from '../../src/domain/enums.js';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { PaperPositionRepository } from '../../src/repositories/PaperPositionRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { ScoringConfigRepository } from '../../src/repositories/ScoringConfigRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { TechnicalIndicatorRepository } from '../../src/repositories/TechnicalIndicatorRepository.js';
import { EvaluationService } from '../../src/services/EvaluationService.js';
import { FundamentalsService } from '../../src/services/fundamentals/FundamentalsService.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MarketDataService } from '../../src/services/marketData/MarketDataService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({ level: 'silent', destination: new Writable({ write(_c, _e, cb) { cb(); } }) });
const NOW = new Date('2026-10-05T12:00:00Z'); // Monday 17:30 IST, after close + settle
const SYMBOLS = ['RELIANCE', 'HDFCBANK', 'NIFTY50', 'INDIAVIX', 'BANKNIFTY', 'NIFTYFINSERVICE', 'NIFTYENERGY'];

async function seed(trx: Database) {
  await isolateTables(trx, 'market_data', 'technical_indicators', 'stock_evaluations', 'fundamental_snapshots', 'financial_statements');
  const sessions = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());
  const provider = new MockMarketDataProvider(sessions, () => NOW);
  const logs = new SystemLogRepository(trx);
  await new MarketDataService({
    provider, sessions, dataMode: 'MOCK', logger: silent, now: () => NOW,
    providerSymbols: new ProviderSymbolRepository(trx), stocks: new StockRepository(trx), markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx), systemLogs: logs,
  }).sync({ jobName: 'seed', timeframe: '1d', from: new Date(NOW.getTime() - 420 * 86_400_000), to: NOW, symbols: SYMBOLS });
  await new FundamentalsService({
    provider: new MockFundamentalsProvider(async (ref) => (await provider.getQuote(ref)).price, () => NOW),
    providerSymbols: new ProviderSymbolRepository(trx), stocks: new StockRepository(trx), fundamentals: new FundamentalsRepository(trx),
    systemLogs: logs, dataMode: 'MOCK', logger: silent, now: () => NOW,
  }).sync({ jobName: 'seed', symbols: ['RELIANCE', 'HDFCBANK'] });
  return sessions;
}

function service(trx: Database, sessions: MarketCalendarService, now: Date) {
  return new EvaluationService({
    stocks: new StockRepository(trx), markets: new MarketRepository(trx), marketData: new MarketDataRepository(trx),
    fundamentals: new FundamentalsRepository(trx), news: new NewsRepository(trx), positions: new PaperPositionRepository(trx),
    configs: new ScoringConfigRepository(trx), settings: new AppSettingsRepository(trx), evaluations: new EvaluationRepository(trx),
    indicators: new TechnicalIndicatorRepository(trx), systemLogs: new SystemLogRepository(trx),
    sessions, dataMode: 'MOCK', logger: silent, now: () => now,
  });
}

describe('EvaluationService', () => {
  it('evaluates stocks end to end, stores indicators and evaluations, and is idempotent', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      const first = await service(trx, sessions, NOW).run({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'] });
      expect(first).toMatchObject({ status: 'SUCCESS', configVersion: 'v1', stocks: { total: 2, succeeded: 2, failed: 0 }, evaluations: { inserted: 2, unchanged: 0 } });
      expect(first.regime).not.toBeNull();
      expect(first.indicatorRows).toBeGreaterThan(500);
      for (const s of first.summaries) {
        expect(ACTION_STATES).toContain(s.actionState);
        expect(s.actionState).not.toBe('INSUFFICIENT_DATA');
        expect(s.invalidation).toMatch(/₹/);
      }
      const stockId = (await new StockRepository(trx).findBySymbol('RELIANCE'))?.id ?? '';
      expect(await new EvaluationRepository(trx).latest(stockId, 'MOCK')).toMatchObject({ scoringConfigVersion: 'v1', dataAsOf: new Date('2026-10-05T03:45:00Z') });
      expect((await new TechnicalIndicatorRepository(trx).latest(stockId, 'MOCK', '1d'))?.values.sma200).not.toBeNull();

      const again = await service(trx, sessions, NOW).run({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'] });
      expect(again.evaluations).toEqual({ inserted: 0, unchanged: 2 });
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({ id: again.runId, operation: 'evaluate', status: 'SUCCESS', recordsFetched: 2, recordsInserted: 0, recordsSkipped: 2 });
    });
  });

  it('never gives a buy view on stale or missing data', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      const later = new Date(NOW.getTime() + 10 * 86_400_000);
      const stale = await service(trx, sessions, later).run({ jobName: 'test', symbols: ['RELIANCE', 'TCS'] });
      expect(stale.status).toBe('SUCCESS');
      const bySymbol = Object.fromEntries(stale.summaries.map((s) => [s.symbol, s]));
      expect(bySymbol.RELIANCE).toMatchObject({ actionState: 'INSUFFICIENT_DATA', bias: null });
      expect(bySymbol.RELIANCE?.invalidation).toMatch(/stale/);
      expect(bySymbol.TCS).toMatchObject({ actionState: 'INSUFFICIENT_DATA', price: null });
    });
  });

  it('notes unknown symbols and fails the run when nothing can be evaluated', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      const r = await service(trx, sessions, NOW).run({ jobName: 'test', symbols: ['NOSUCH'] });
      expect(r.status).toBe('FAILED');
      expect(r.notes.join(' ')).toMatch(/NOSUCH/);
    });
  });
});
```
The seed syncs about 290 mock trading days × 7 instruments, so expect a few seconds. If it exceeds the 15 s default test timeout, add `{ timeout: 60_000 }` to these `it` calls rather than shrinking the history: the 200-bar rule needs it.

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/services/EvaluationService.ts`

```ts
import type { Logger } from 'pino';
import { z } from 'zod';
import type { DataMode, JobStatus, MarketRegime } from '../domain/enums.js';
import type { Bar, Stock, TradingSessions } from '../domain/types.js';
import type { AppSettingsRepository } from '../repositories/AppSettingsRepository.js';
import type { EvaluationRepository } from '../repositories/EvaluationRepository.js';
import type { FundamentalsRepository } from '../repositories/FundamentalsRepository.js';
import type { MarketDataRepository } from '../repositories/MarketDataRepository.js';
import type { MarketRepository } from '../repositories/MarketRepository.js';
import type { NewsRepository } from '../repositories/NewsRepository.js';
import type { PaperPositionRepository } from '../repositories/PaperPositionRepository.js';
import type { ScoringConfigRepository } from '../repositories/ScoringConfigRepository.js';
import type { StockRepository } from '../repositories/StockRepository.js';
import type { SystemLogRepository } from '../repositories/SystemLogRepository.js';
import type { TechnicalIndicatorRepository } from '../repositories/TechnicalIndicatorRepository.js';
import { buildEvaluation, datedCloses, type MarketContext, type StatementRow, trendOf } from '../scoring/evaluate.js';
import { ENGINE_VERSION } from '../scoring/rubrics.js';
import type { OhlcvBar } from '../technical/indicators.js';
import type { TradeLevels } from '../technical/levels.js';
import type { DatedClose } from '../technical/stats.js';
import { classifyRegime } from '../technical/trend.js';
import { mapWithConcurrency } from '../utils/concurrency.js';
import { AppError, toAppError } from '../utils/errors.js';
import { addDays, toIst } from '../utils/ist.js';
import type { InstrumentFailure } from './marketData/MarketDataService.js';

const DAY_MS = 86_400_000;
/** Five years of daily bars: enough for SMA200, 1Y risk metrics and the P/E history band. */
export const HISTORY_DAYS = 1830;
export const NEWS_LOOKBACK_DAYS = 30;
/** A session counts as completed this long after its close (matches the daily-bar settle rule). */
export const SETTLE_MS = 30 * 60_000;
const MAX_GAP_DAYS = 60;
const MIN_SECTOR_BARS = 200;
const DEFAULT_CAPITAL = 1_000_000;

export interface EvaluationRunRequest {
  jobName: string;
  symbols?: readonly string[];
}

export interface StockEvaluationSummary {
  symbol: string;
  actionState: string;
  bias: string | null;
  overall: number | null;
  price: number | null;
  trade: TradeLevels | null;
  invalidation: string;
  inserted: boolean;
  riskLevel: string | null;
  valuationLabel: string;
  trend: string | null;
}

export interface EvaluationRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  dataMode: DataMode;
  configVersion: string | null;
  regime: MarketRegime | null;
  stocks: { total: number; succeeded: number; failed: number };
  evaluations: { inserted: number; unchanged: number };
  indicatorRows: number;
  summaries: StockEvaluationSummary[];
  failures: InstrumentFailure[];
  notes: string[];
}

export interface EvaluationServiceDeps {
  stocks: StockRepository;
  markets: MarketRepository;
  marketData: MarketDataRepository;
  fundamentals: FundamentalsRepository;
  news: NewsRepository;
  positions: PaperPositionRepository;
  configs: ScoringConfigRepository;
  settings: AppSettingsRepository;
  evaluations: EvaluationRepository;
  indicators: TechnicalIndicatorRepository;
  systemLogs: SystemLogRepository;
  sessions: TradingSessions;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  concurrency?: number;
}

const toOhlcv = (b: Bar): OhlcvBar => ({ ts: b.ts, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume });

export class EvaluationService {
  private readonly now: () => Date;

  constructor(private readonly deps: EvaluationServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async run(request: EvaluationRunRequest): Promise<EvaluationRunResult> {
    const { systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({ service: 'EvaluationService', jobName: request.jobName, operation: 'evaluate' });
    const result: EvaluationRunResult = {
      runId, status: 'SUCCESS', dataMode: this.deps.dataMode, configVersion: null, regime: null,
      stocks: { total: 0, succeeded: 0, failed: 0 }, evaluations: { inserted: 0, unchanged: 0 },
      indicatorRows: 0, summaries: [], failures: [], notes: [],
    };
    let runError: unknown;

    try {
      const config = await this.deps.configs.getActive();
      result.configVersion = config.version;
      const capital = (await this.deps.settings.get('paper_initial_balance', z.number().positive())) ?? DEFAULT_CAPITAL;
      const market = await this.marketContext(now, config.thresholds, result);
      result.regime = market.regime;

      let stocks = await this.deps.stocks.listActive();
      if (request.symbols) {
        const wanted = new Set(request.symbols.map((s) => s.trim().toUpperCase()).filter(Boolean));
        stocks = stocks.filter((s) => wanted.has(s.symbol));
        const missing = [...wanted].filter((s) => !stocks.some((x) => x.symbol === s));
        if (missing.length > 0) result.notes.push(`unknown or inactive stock symbols: ${missing.join(', ')}`);
      }
      result.stocks.total = stocks.length;
      if (stocks.length === 0) throw new AppError('VALIDATION', 'No stocks to evaluate');

      const sectorCache = new Map<string, Promise<{ closes: DatedClose[]; trend: ReturnType<typeof trendOf> } | null>>();
      await mapWithConcurrency(stocks, this.deps.concurrency ?? 4, async (stock) => {
        try {
          const summary = await this.evaluateStock(stock, { now, config, capital, market, sectorCache });
          // Await before touching shared counters: `x += await …` loses concurrent updates.
          result.indicatorRows += summary.indicatorRows;
          if (summary.inserted) result.evaluations.inserted += 1;
          else result.evaluations.unchanged += 1;
          result.summaries.push(summary.summary);
          result.stocks.succeeded += 1;
        } catch (error) {
          const e = toAppError(error);
          result.failures.push({ symbol: stock.symbol, providerSymbol: stock.symbol, code: e.code, message: e.message });
          logger.warn({ symbol: stock.symbol, code: e.code }, 'evaluation failed for stock');
        }
      });
      result.summaries.sort((a, b) => a.symbol.localeCompare(b.symbol));
      result.stocks.failed = result.failures.length;
      result.status = result.stocks.succeeded === 0 ? 'FAILED' : result.failures.length > 0 ? 'PARTIAL' : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: { fetched: result.stocks.total, inserted: result.evaluations.inserted, skipped: result.evaluations.unchanged, failed: result.stocks.failed },
        message: `${result.stocks.succeeded}/${result.stocks.total} stocks evaluated; ${result.evaluations.inserted} new, ${result.evaluations.unchanged} unchanged`,
        ...(runError === undefined ? {} : { error: runError }),
        details: { failures: result.failures, notes: result.notes, regime: result.regime, configVersion: result.configVersion, engineVersion: ENGINE_VERSION },
      });
    }
    logger.info({ runId, status: result.status, inserted: result.evaluations.inserted }, 'evaluation run finished');
    return result;
  }

  private async bars(ref: { kind: 'stock' | 'market'; id: string }, now: Date): Promise<OhlcvBar[]> {
    const bars = await this.deps.marketData.getBars(ref, this.deps.dataMode, '1d', new Date(now.getTime() - HISTORY_DAYS * DAY_MS), now);
    return bars.map(toOhlcv);
  }

  /** NIFTY 50 trend + India VIX → regime. Computed once per run. */
  private async marketContext(
    now: Date, t: { vixRiskOnMax: number; vixRiskOffMin: number; maxStaleSessions: number }, result: EvaluationRunResult,
  ): Promise<MarketContext> {
    const nifty = await this.deps.markets.findBySymbol('NIFTY50');
    const niftyBars = nifty ? await this.bars({ kind: 'market', id: nifty.id }, now) : [];
    if (niftyBars.length === 0) result.notes.push('no NIFTY 50 daily bars: market regime and relative strength unavailable');
    const vixMarket = await this.deps.markets.findBySymbol('INDIAVIX');
    const vixBars = vixMarket ? await this.bars({ kind: 'market', id: vixMarket.id }, now) : [];
    const lastVix = vixBars.at(-1);
    const vix = lastVix && !(await this.isStale(lastVix.ts, now, t.maxStaleSessions)) ? lastVix.close : null;
    if (vix === null) result.notes.push('no recent India VIX close: regime uses the NIFTY trend only');
    const niftyTrend = trendOf(niftyBars);
    return { nifty: datedCloses(niftyBars), niftyTrend, regime: classifyRegime({ niftyTrend, vix }, t), vix };
  }

  private async sectorContext(stock: Stock, now: Date, cache: Map<string, Promise<{ closes: DatedClose[]; trend: ReturnType<typeof trendOf> } | null>>) {
    const links = await this.deps.markets.linksForStock(stock.id);
    for (const link of links.filter((l) => l.linkType === 'SECTOR_INDEX')) {
      let pending = cache.get(link.market.id);
      if (!pending) {
        pending = this.bars({ kind: 'market', id: link.market.id }, now).then((b) =>
          b.length >= MIN_SECTOR_BARS ? { closes: datedCloses(b), trend: trendOf(b) } : null,
        );
        cache.set(link.market.id, pending);
      }
      const context = await pending;
      if (context) return context;
    }
    return null;
  }

  /** True when more than maxSessions completed trading sessions have passed since the bar's IST date. */
  private async isStale(barTs: Date, now: Date, maxSessions: number): Promise<boolean> {
    const today = toIst(now).date;
    let date = addDays(toIst(barTs).date, 1);
    let completed = 0;
    for (let k = 0; date <= today; k += 1, date = addDays(date, 1)) {
      if (k > MAX_GAP_DAYS) return true;
      const session = await this.deps.sessions.sessionOn('NSE', date);
      if (session && session.close.getTime() + SETTLE_MS <= now.getTime()) completed += 1;
    }
    return completed > maxSessions;
  }

  private async evaluateStock(
    stock: Stock,
    ctx: {
      now: Date;
      config: Awaited<ReturnType<ScoringConfigRepository['getActive']>>;
      capital: number;
      market: MarketContext;
      sectorCache: Map<string, Promise<{ closes: DatedClose[]; trend: ReturnType<typeof trendOf> } | null>>;
    },
  ): Promise<{ summary: StockEvaluationSummary; inserted: boolean; indicatorRows: number }> {
    const mode = this.deps.dataMode;
    const { now, config } = ctx;
    const bars = await this.bars({ kind: 'stock', id: stock.id }, now);
    const lastBar = bars.at(-1);
    const stale = lastBar ? await this.isStale(lastBar.ts, now, config.thresholds.maxStaleSessions) : false;
    const [sector, snapshot, quarterly, annual, peerPes, news, holdsPosition] = await Promise.all([
      this.sectorContext(stock, now, ctx.sectorCache),
      this.deps.fundamentals.latestSnapshot(stock.id, mode),
      this.deps.fundamentals.listStatements(stock.id, mode, 'QUARTERLY', 12),
      this.deps.fundamentals.listStatements(stock.id, mode, 'ANNUAL', 8),
      stock.sector ? this.deps.fundamentals.sectorPeerPes(stock.sector, stock.id, mode) : Promise.resolve([]),
      this.deps.news.sentimentsForStock(stock.id, mode, new Date(now.getTime() - NEWS_LOOKBACK_DAYS * DAY_MS)),
      this.deps.positions.holdsPosition(stock.id, mode),
    ]);
    const toRow = (r: (typeof quarterly)[number]): StatementRow => ({ periodEnd: r.periodEnd, revenue: r.metrics.revenue, netProfit: r.metrics.netProfit, eps: r.metrics.eps });

    const { record, indicatorSeries } = buildEvaluation({
      stock: { id: stock.id, symbol: stock.symbol, sector: stock.sector }, dataMode: mode, bars, stale,
      market: ctx.market, sector,
      fundamentals: { asOf: snapshot?.asOf ?? null, snapshot: snapshot?.metrics ?? null, quarterly: quarterly.map(toRow), annual: annual.map(toRow) },
      peerPes, news, holdsPosition, capital: ctx.capital, config, now,
    });
    const indicatorRows = indicatorSeries.length > 0 ? await this.deps.indicators.upsertSeries(stock.id, mode, '1d', indicatorSeries) : 0;
    const { inserted } = await this.deps.evaluations.insert(record);
    return {
      inserted,
      indicatorRows,
      summary: {
        symbol: stock.symbol, actionState: record.actionState, bias: record.recommendationBias, overall: record.scores.overall,
        price: lastBar?.close ?? null, trade: record.trade, invalidation: record.invalidation, inserted,
        riskLevel: record.riskLevel, valuationLabel: record.valuationLabel, trend: record.trend,
      },
    };
  }
}
```
`toIst` and `addDays` are both used above, by `isStale`. If `FundamentalsRepository.listStatements` returns a different record shape than `{ periodEnd, metrics }`, adapt `toRow`; Phase 4 defined it as `FinancialStatementRecord`, which has those fields.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): EvaluationService gathers inputs, evaluates, persists and logs each run`.

---

### Task 10: Container wiring and `pnpm evaluate`

**Files:**
- Create: `backend/src/cli/evaluate.ts`
- Modify: `backend/src/container.ts`, `backend/package.json`, root `package.json`
- Test: `backend/tests/integration/container.test.ts` (new case)

**Interfaces — Produces:**
- `Container.repositories` gains `scoringConfigs`, `technicalIndicators`, `evaluations` and `paperPositions`.
- `Container.services.evaluation: EvaluationService`
- Script `pnpm evaluate [--symbols A,B]`

- [ ] **Step 1: Write the failing test.** Append inside `describe('container wiring')` in `backend/tests/integration/container.test.ts`:

```ts
  it('wires the evaluation service', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.services.evaluation).toBeDefined();
    expect((await c.repositories.scoringConfigs.getActive()).version).toBe('v1');
    await c.close();
  });
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (`services.evaluation` / `repositories.scoringConfigs` do not exist on the type).

- [ ] **Step 3: Implement.** In `backend/src/container.ts`:
- Import the four new repositories and `EvaluationService`.
- Add to the `Container` repositories type and to the `repositories` object:
```ts
    scoringConfigs: new ScoringConfigRepository(db),
    technicalIndicators: new TechnicalIndicatorRepository(db),
    evaluations: new EvaluationRepository(db),
    paperPositions: new PaperPositionRepository(db),
```
- Add `evaluation: EvaluationService` to the services type, and in `services`:
```ts
      evaluation: new EvaluationService({
        stocks: repositories.stocks, markets: repositories.markets, marketData: repositories.marketData,
        fundamentals: repositories.fundamentals, news: repositories.news, positions: repositories.paperPositions,
        configs: repositories.scoringConfigs, settings: repositories.settings, evaluations: repositories.evaluations,
        indicators: repositories.technicalIndicators, systemLogs: repositories.systemLogs,
        sessions: calendar, dataMode: config.dataMode, logger,
      }),
```
`backend/src/cli/evaluate.ts`:
```ts
import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { ENGINE_VERSION } from '../scoring/rubrics.js';
import { formatInr } from '../utils/format.js';

loadDotEnv();
const { values } = parseArgs({ options: { symbols: { type: 'string' } } });

const container = createContainer(readConfigOrExit(process.env));
try {
  const r = await container.services.evaluation.run({
    jobName: 'cli.evaluate',
    ...(values.symbols ? { symbols: values.symbols.split(',').map((s) => s.trim()).filter(Boolean) } : {}),
  });
  console.log(`[${r.dataMode}] evaluation (config ${r.configVersion ?? '?'}, ${ENGINE_VERSION}), market regime ${r.regime ?? 'unknown'}: ${r.status}`);
  console.log(`  ${r.stocks.succeeded}/${r.stocks.total} stocks; ${r.evaluations.inserted} new, ${r.evaluations.unchanged} unchanged; ${r.indicatorRows} indicator rows`);
  const pad = (s: string, n: number) => s.padEnd(n);
  console.log(`  ${pad('SYMBOL', 11)}${pad('STATE', 23)}${pad('BIAS', 17)}${pad('SCORE', 7)}${pad('PRICE', 13)}${pad('ENTRY', 25)}${pad('STOP', 13)}${pad('T1', 13)}R:R`);
  for (const s of r.summaries) {
    const t = s.trade;
    console.log(
      `  ${pad(s.symbol, 11)}${pad(s.actionState, 23)}${pad(s.bias ?? '-', 17)}${pad(s.overall?.toFixed(1) ?? '-', 7)}` +
        `${pad(s.price === null ? '-' : formatInr(s.price), 13)}${pad(t ? `${formatInr(t.entryLow)}–${formatInr(t.entryHigh)}` : '-', 25)}` +
        `${pad(t ? formatInr(t.stop) : '-', 13)}${pad(t ? formatInr(t.target1) : '-', 13)}${t ? t.riskReward.toFixed(2) : '-'}`,
    );
    console.log(`    ↳ ${s.invalidation}`);
  }
  for (const f of r.failures) console.log(`  FAILED ${f.symbol}: ${f.code} ${f.message}`);
  for (const n of r.notes) console.log(`  note: ${n}`);
  console.log('  AI-free deterministic analysis for personal research and paper trading only. Not investment advice.');
  process.exitCode = r.status === 'FAILED' ? 1 : 0;
} finally {
  await container.close();
}
```
Scripts:
- backend: `"evaluate": "tsx src/cli/evaluate.ts"`
- root: `"evaluate": "pnpm --filter @learning-stocks/backend evaluate"`

- [ ] **Step 4: Run the gate, then a real mock run**

Run the gate. Expected: PASS.
```bash
pnpm sync:market && pnpm sync:fundamentals && pnpm evaluate
pnpm evaluate   # second run: 0 new, 20 unchanged
```
**Calibration check (eyeball, not asserted).** Look at the spread of action states across the 20 mock stocks. A healthy spread has more than one state; all 20 identical (all HOLD or all BUY_ZONE) means the rubrics are miscalibrated. In that case, inspect `stock_evaluations.inputs` for a few stocks to see which factor dominates, adjust the rubric breakpoints, record a ruling, and re-run. Also confirm that the regime and VIX notes look sensible.

- [ ] **Step 5: Commit** `feat(backend): wire evaluation service; pnpm evaluate CLI`.

---

### Task 11: Docs + Phase 5 verification

**Files:** Modify `README.md`, `docs/architecture.md`, `docs/database.md`, `IMPLEMENTATION_PLAN.md`.

- [ ] **Step 1: Docs**
  - **README:**
    - status table: Phase 5 ✅
    - an "Evaluate stocks" section: `pnpm evaluate`, what each column means, the action states and biases, the invalidation line, the disclaimer
    - the live run: re-sync about 700 days of live daily bars first
    - Studio SQL: the latest evaluation per stock
    - known limitations:
      - news factor empty until Phase 7
      - LIVE sector indices without Yahoo history
      - IT has too few peers for sector valuation
      - INFY uses snapshot P/E
      - evaluations are on daily closes and stale data gives INSUFFICIENT_DATA
  - **`docs/architecture.md`:** an "Analytics engine" section covering:
    - the module map
    - indicators, with stability indexes and the verification approach
    - trend and regime rules
    - levels algorithm
    - valuation (availability lags, cross-check)
    - factor rubrics, a table pointing to `scoring/rubrics.ts`
    - overall/coverage
    - risk mapping
    - the decision table with bias and signal mapping
    - the `input_hash` and `ENGINE_VERSION` rule
    - staleness
  - **`docs/database.md`:**
    - `technical_indicators`: upserted full series; `pivots` = classic floor pivots
    - `stock_evaluations`: one row per input hash; what `inputs` and `factors_available` contain
    - scoring-config thresholds and defaults
  - **`IMPLEMENTATION_PLAN.md`:** Phase 5 ✅ with a link to this plan.

- [ ] **Step 2: Full verification**

```bash
pnpm db:test                                          # 119/119 (no schema change this phase)
pnpm typecheck && pnpm test && pnpm lint && pnpm format:check && pnpm --filter @learning-stocks/backend build
pnpm evaluate && pnpm evaluate                        # mock: 20/20; second run 0 new
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm sync:market --days 700
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm sync:fundamentals
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm evaluate
```
Expected:
- **Mock:** 20/20 evaluations, a spread of action states, and an idempotent re-run.
- **Live:** `[LIVE] evaluation … SUCCESS`. Regime from real NIFTY 50 + India VIX. RELIANCE's P/E cross-check either passes or is noted. INFY gets valuation from snapshot P/E plus peers (or INSUFFICIENT_DATA with a note for IT).
- **Spot check:** compare one stock's SMA50/SMA200/RSI against any public chart for the same date (eyeball within rounding), and read 3 invalidation sentences for sense.
- **Bonus-basis check (RELIANCE, 1:1 bonus Oct 2024):** print its LIVE annual/quarterly EPS and the evaluation's `inputs.valuation.notes`. Either the EPS points are restated (no jump, history used) or the basis-break guard fired (note present). Record what Yahoo does in the ledger.
- **SQL:** `select s.symbol, e.action_state, e.overall_score, e.entry_low, e.stop_loss, e.target_1, e.risk_reward from stock_evaluations e join stocks s on s.id = e.stock_id where e.data_mode = 'LIVE' order by e.evaluated_at desc limit 20`.

- [ ] **Step 3: Commit** `docs: analytics engine, evaluation usage and limits; mark Phase 5 complete`. Then run the final fresh review, do one fix pass, and **stop for approval before Phase 6**.

---

## Verification (end of phase)

- **Automated:** typecheck, lint, format, build, plus unit and integration tests under TZ=UTC:
  - indicators (textbook + reference + stability indexes + pivots + VWAP)
  - stats (date alignment)
  - trend and regime
  - levels (normal, pullback, fallback targets, size cap, degenerate)
  - valuation (no look-ahead, cross-check, peers, INFY, losses)
  - config parsing, factor and risk scores
  - decision table (every rule, ordering, mappings, language)
  - `buildEvaluation` (DB-safe record, determinism, stale/short/no data)
  - repositories and EvaluationService (end to end, idempotent, stale, unknown symbols)
  - container
  - pgTAP 119/119
- **End to end:** mock and live `pnpm evaluate` runs stored in `stock_evaluations`, with indicators in `technical_indicators` and one `system_logs` row per run.
