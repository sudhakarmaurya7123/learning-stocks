# Phase 3: Market Data Provider — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (Native, as in Phases 1–2) or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

## Context

Phases 1–2 are merged on `main`: the schema, a typed backend foundation, the market calendar and `/api/health`. There is still no market data. Phase 3 adds the **MarketDataProvider** abstraction, two adapters and an ingestion service:
- **Mock:** a deterministic, sector-correlated simulator, so everything works offline.
- **Yahoo:** `yahoo-finance2`, for real NSE/BSE data.
- **`MarketDataService`:** fetches bars, validates and normalises them (PRD §6.5), stores them idempotently, isolates per-instrument failures, retries transient errors and logs every run.

There are also two CLIs: `pnpm sync:market` to load data now (cron jobs arrive in Phase 8), and `pnpm verify:symbols` to check the Yahoo ticker mappings.

**Live findings that shape the design** (probed with `yahoo-finance2@4.0.3` on 2026-10-05):
- NSE daily bars come stamped `03:45Z` (09:15 IST), which matches the Phase 2 bar convention. Stocks plus `^NSEI`, `^BSESN`, `^NSEBANK`, `^CNXIT`, `^CNXPHARMA` and `^INDIAVIX` have full history.
- **No history on Yahoo for six sector indices:** `^CNXFMCG`, `NIFTY_FIN_SERVICE.NS`, `^CNXAUTO`, `^CNXMETAL`, `^CNXREALTY` and `^CNXENERGY` return only a same-day snapshot (one bar stamped at last-trade time). Alternative tickers don't exist. These must be reported as unverified, never presented as history.
- Yahoo emits null-OHLC placeholder bars for holidays and for the trailing empty 5m slot. 5m/15m data is limited to the last 60 days, and 1m to roughly 7 days.
- An unknown symbol throws a plain `Error("No data found, symbol may be delisted")`. The library's own error classes are `HTTPError`, `BadRequestError`, `InvalidOptionsError` and `FailedYahooValidationError`.

**Goal:** Real or mock NSE/BSE bars flow into `market_data` through a provider-agnostic, validated, idempotent, logged pipeline, with the Yahoo symbol coverage verified and reported.

**Architecture:** `providers/market/` holds the interface and two adapters, selected by `providers/factory.ts` from config. `services/marketData/` holds the pure `normalizeBars` and the `MarketDataService` orchestration (resolve instruments, then per instrument with bounded concurrency: retry → normalise → change-vs-previous-close → insert, then log the run). The CLIs call the service through the DI container. No business code imports `yahoo-finance2` outside `providers/market/yahoo/`.

**Tech Stack:** existing Phase 2 stack + `yahoo-finance2@4.0.3` (verified: `new YahooFinance({ suppressNotices: ['yahooSurvey'] })`, `.chart(sym, { period1, period2, interval })`, `.quote(sym)`).

**Spec:** `PRD.md` §5, §6 (providers, resilience, data quality), §7.3, §13; `docs/architecture.md` (bar `ts` = open time).

## Deviations from the PRD and outline (need your OK)

1. **`getIndexQuote` is merged into `getQuote`.** `ProviderInstrumentRef.kind` distinguishes stocks from indices, so one method serves both (PRD §6.1 listed both).
2. **New provider value `none`** for `NEWS_PROVIDER`, `FUNDAMENTALS_PROVIDER` and `LLM_PROVIDER` (the feature is disabled). Without it, live mode is impossible until Phases 4–7 exist. Live market data then runs as `MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo` with the others set to `none`. `MARKET_DATA_PROVIDER` cannot be `none`.
3. **Only complete bars are stored.** Intraday bars are stored once their interval has ended. Daily bars are stored once the session closed + 30 min settle. In-progress bars would otherwise be frozen forever by the idempotent insert. Live "current price" for open sessions comes from the latest completed 5m bar now, and from `getQuote` + cache in Phase 9.
4. **`system_logs` counts are in bars:** `records_failed` = rejected bars. Per-instrument failures go in `message` and `error_details.failures`.

## Global Constraints

- Everything from Phase 2 still applies:
  - the gate `pnpm --filter @learning-stocks/backend typecheck && pnpm --filter @learning-stocks/backend test && pnpm lint`
  - `TZ=UTC` tests
  - no `any` or `!`
  - ESM `.js` imports
  - the `{data, meta}` envelope
  - commits end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`
  - branch `phase-3-market-data`
- Stored rows: `data_mode` = `config.dataMode`, `source` = `provider.name` (`'mock'` or `'yahoo'`). Config already guarantees that a mock provider ⇒ MOCK.
- Bar `ts` = the bar's open time (UTC). Daily bars are normalised to that IST date's session open, whatever the provider stamped.
- Never store: null/non-positive prices, inconsistent OHLC, negative volume, future bars, bars on non-trading days, intraday bars outside the session, or incomplete bars.
- One instrument failing never aborts the run. `AUTH_FAILED` and `UNSUPPORTED` are not retried (Phase 2 `withRetry`), and Retry-After above the cap fails fast.
- Yahoo calls go through a token-bucket limiter (2 req/s, burst 2) and `withRetry`. Sync concurrency defaults to 4.
- **Mock data is labelled MOCK everywhere.** Fixture levels are synthetic, not real prices.

## Review Focus

1. **In-progress bars** (today's daily bar mid-session, the trailing null 5m slot) must not be stored, because DO NOTHING would freeze a wrong close. Covered in Task 4 (`INCOMPLETE`, `EMPTY`) and Task 6.
2. **Odd provider timestamps** (sector-index snapshot stamped 10:01:29Z) must be normalised to the session open, and the six snapshot-only indices flagged unverified. Covered in Tasks 4 and 8.
3. **One symbol delisted, rate-limited or timing out** must leave the others stored, with run status PARTIAL and failures listed. Covered in Task 6.
4. **Requested range beyond provider lookback** (5m older than 60 days) is clamped with a note, not a failed call. Covered in Task 6.
5. **Holiday bars from the provider:** null placeholders are dropped and a priced holiday bar is rejected `NOT_A_TRADING_DAY`. Re-running a sync is idempotent. Covered in Tasks 4 and 6.

## File structure

```
backend/src/
├── utils/{rateLimiter.ts, concurrency.ts}                         (Task 1)
├── domain/types.ts                    + TradingSession, TradingSessions (Task 2)
├── services/MarketCalendarService.ts  sessionOn() made public       (Task 2)
├── providers/market/types.ts                                      (Task 2)
├── providers/market/mock/{random.ts, fixtures.ts, MockMarketDataProvider.ts}  (Task 2)
├── providers/market/yahoo/{yahooClient.ts, errors.ts, YahooMarketDataProvider.ts} (Task 3)
├── services/marketData/barNormalizer.ts                           (Task 4)
├── repositories/ProviderSymbolRepository.ts; SystemLogRepository.ts (+details) (Task 5)
├── services/marketData/MarketDataService.ts                       (Task 6)
├── config/{env.ts (+none), readConfig.ts}; providers/factory.ts; container.ts; server.ts; cli/sync-market.ts (Task 7)
└── services/marketData/verifyProviderSymbols.ts; cli/verify-provider-symbols.ts (Task 8)
backend/tests/{unit,integration,live,fixtures}/…
```

---

### Task 1: Rate limiter and bounded concurrency

**Files:** Create `backend/src/utils/rateLimiter.ts` and `backend/src/utils/concurrency.ts`. Test: `backend/tests/unit/rateLimiter.test.ts` and `backend/tests/unit/concurrency.test.ts`.

**Interfaces — Produces:**
- `interface RateLimiter { acquire(): Promise<void> }`
- `createRateLimiter({ ratePerSecond, burst?, now?, sleep? }): RateLimiter`
- `mapWithConcurrency<T, R>(items: readonly T[], limit: number, fn: (item: T, index: number) => Promise<R>): Promise<R[]>`

- [ ] **Step 1: Branch and write the failing tests**

```bash
git checkout -b phase-3-market-data
```
`backend/tests/unit/rateLimiter.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

function clock() {
  let t = 0;
  const sleeps: number[] = [];
  return {
    sleeps,
    now: () => t,
    sleep: async (ms: number) => {
      sleeps.push(ms);
      t += ms;
    },
    advance: (ms: number) => {
      t += ms;
    },
  };
}

describe('createRateLimiter', () => {
  it('allows a burst, then spaces calls at the configured rate', async () => {
    const c = clock();
    const limiter = createRateLimiter({ ratePerSecond: 1, burst: 2, now: c.now, sleep: c.sleep });
    await limiter.acquire();
    await limiter.acquire();
    expect(c.sleeps).toEqual([]);
    await limiter.acquire();
    expect(c.sleeps).toEqual([1000]);
  });

  it('refills over time but never above the burst size', async () => {
    const c = clock();
    const limiter = createRateLimiter({ ratePerSecond: 2, burst: 2, now: c.now, sleep: c.sleep });
    await limiter.acquire();
    await limiter.acquire();
    c.advance(10_000);
    await limiter.acquire();
    await limiter.acquire();
    expect(c.sleeps).toEqual([]);
    await limiter.acquire();
    expect(c.sleeps).toEqual([500]);
  });

  it('serves concurrent callers in order without exceeding the rate', async () => {
    const c = clock();
    const limiter = createRateLimiter({ ratePerSecond: 1, burst: 1, now: c.now, sleep: c.sleep });
    const order: number[] = [];
    await Promise.all([1, 2, 3].map(async (n) => { await limiter.acquire(); order.push(n); }));
    expect(order).toEqual([1, 2, 3]);
    expect(c.sleeps).toEqual([1000, 1000]);
  });

  it('rejects a non-positive rate', () => {
    expect(() => createRateLimiter({ ratePerSecond: 0 })).toThrow(RangeError);
  });
});
```
`backend/tests/unit/concurrency.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { mapWithConcurrency } from '../../src/utils/concurrency.js';

describe('mapWithConcurrency', () => {
  it('preserves input order and never exceeds the limit', async () => {
    let running = 0;
    let peak = 0;
    const result = await mapWithConcurrency([5, 1, 4, 2, 3], 2, async (n) => {
      running += 1;
      peak = Math.max(peak, running);
      await new Promise((r) => setTimeout(r, n));
      running -= 1;
      return n * 10;
    });
    expect(result).toEqual([50, 10, 40, 20, 30]);
    expect(peak).toBe(2);
  });

  it('handles empty input and rejects invalid limits', async () => {
    expect(await mapWithConcurrency([], 3, async (n: number) => n)).toEqual([]);
    await expect(mapWithConcurrency([1], 0, async (n) => n)).rejects.toThrow(RangeError);
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/utils/rateLimiter.ts`

```ts
export interface RateLimiter {
  acquire(): Promise<void>;
}

export interface RateLimiterOptions {
  ratePerSecond: number;
  burst?: number;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Token bucket. Callers are served in arrival order. */
export function createRateLimiter(options: RateLimiterOptions): RateLimiter {
  if (!(options.ratePerSecond > 0)) throw new RangeError('ratePerSecond must be > 0');
  const capacity = Math.max(1, options.burst ?? 1);
  const refillPerMs = options.ratePerSecond / 1000;
  const now = options.now ?? Date.now;
  const sleep = options.sleep ?? defaultSleep;
  let tokens = capacity;
  let last = now();
  let queue: Promise<void> = Promise.resolve();

  const take = async (): Promise<void> => {
    for (;;) {
      const t = now();
      tokens = Math.min(capacity, tokens + (t - last) * refillPerMs);
      last = t;
      if (tokens >= 1) {
        tokens -= 1;
        return;
      }
      await sleep(Math.ceil((1 - tokens) / refillPerMs));
    }
  };

  return {
    acquire() {
      const next = queue.then(take);
      queue = next.catch(() => undefined);
      return next;
    },
  };
}
```
`backend/src/utils/concurrency.ts`:
```ts
/** Runs fn over items with at most `limit` in flight; results keep input order. fn should handle its own errors. */
export async function mapWithConcurrency<T, R>(
  items: readonly T[],
  limit: number,
  fn: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  if (!Number.isInteger(limit) || limit < 1) throw new RangeError('limit must be a positive integer');
  const results: R[] = new Array<R>(items.length);
  let next = 0;
  const worker = async (): Promise<void> => {
    while (next < items.length) {
      const index = next;
      next += 1;
      results[index] = await fn(items[index] as T, index);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): token-bucket rate limiter and bounded concurrency`.

---

### Task 2: Provider contract, public calendar sessions, deterministic mock provider

**Files:**
- Create:
  - `backend/src/providers/market/types.ts`
  - `backend/src/providers/market/mock/random.ts`
  - `backend/src/providers/market/mock/fixtures.ts`
  - `backend/src/providers/market/mock/MockMarketDataProvider.ts`
  - `backend/tests/fixtures/inMemoryHolidays.ts`
- Modify:
  - `backend/src/domain/types.ts` (add `TradingSession`, `TradingSessions`)
  - `backend/src/services/MarketCalendarService.ts` (`sessionOn` becomes public, typed `TradingSession`, `implements TradingSessions`)
  - `backend/tests/unit/marketCalendar.test.ts` (import `InMemoryHolidays` from the fixture)
- Test: `backend/tests/unit/mockMarketDataProvider.test.ts`, plus one new case in `marketCalendar.test.ts`

**Interfaces:**
- Produces in `domain/types.ts`:
  - `TradingSession { open: Date; close: Date }`
  - `TradingSessions { sessionOn(exchange: Exchange, date: string): Promise<TradingSession | null> }`
- Produces in `providers/market/types.ts`:
  - `ProviderInstrumentRef { providerSymbol: string; exchange: Exchange; kind: 'stock' | 'market' }`
  - `ProviderCapabilities { exchanges: readonly Exchange[]; intervals: readonly BarInterval[]; latency: 'realtime' | 'delayed' | 'eod'; maxLookbackDays: Partial<Record<BarInterval, number>> }`
  - `ProviderBar { ts: Date; open|high|low|close|adjustedClose|volume: number | null }`
  - `ProviderQuote { price: number; asOf: Date; previousClose: number | null; currency: string | null }`
  - `MarketDataProvider { readonly name; capabilities(); getHistorical(ref, from, to, interval): Promise<ProviderBar[]>; getQuote(ref): Promise<ProviderQuote> }`
  - `INTERVAL_MS: Record<BarInterval, number>`
- Produces the mock provider: `new MockMarketDataProvider(sessions: TradingSessions, now?: () => Date)`. It reports `name: 'mock'`, supports intervals `5m`, `15m` and `1d`, and throws `UNSUPPORTED` for `1m`.

- [ ] **Step 1: Write the failing tests**

`backend/tests/fixtures/inMemoryHolidays.ts` (move the class out of `marketCalendar.test.ts` and import it there):
```ts
import type { Holiday } from '../../src/domain/types.js';
import type { HolidayLookup } from '../../src/services/MarketCalendarService.js';

export class InMemoryHolidays implements HolidayLookup {
  calls = 0;
  constructor(private readonly holidays: Holiday[]) {}
  async listBetween(exchange: Holiday['exchange'], from: string, to: string): Promise<Holiday[]> {
    this.calls += 1;
    return this.holidays.filter((h) => h.exchange === exchange && h.date >= from && h.date <= to);
  }
}
```
Add to `backend/tests/unit/marketCalendar.test.ts`:
```ts
  it('exposes the session window for a date (regular, special, closed)', async () => {
    const s = service();
    expect(await s.sessionOn('NSE', '2026-10-05')).toEqual({
      open: new Date('2026-10-05T03:45:00Z'), close: new Date('2026-10-05T10:00:00Z'),
    });
    expect(await s.sessionOn('NSE', '2026-10-11')).toEqual({
      open: new Date('2026-10-11T12:30:00Z'), close: new Date('2026-10-11T13:30:00Z'),
    });
    expect(await s.sessionOn('NSE', '2026-10-07')).toBeNull();
  });
```
`backend/tests/unit/mockMarketDataProvider.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import type { ProviderBar, ProviderInstrumentRef } from '../../src/providers/market/types.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { CASE_HOLIDAYS } from '../fixtures/calendarCases.js';
import { InMemoryHolidays } from '../fixtures/inMemoryHolidays.js';

const sessions = () => new MarketCalendarService(new InMemoryHolidays(CASE_HOLIDAYS), new MemoryCache());
const RELIANCE: ProviderInstrumentRef = { providerSymbol: 'RELIANCE', exchange: 'NSE', kind: 'stock' };
const VIX: ProviderInstrumentRef = { providerSymbol: 'INDIAVIX', exchange: 'NSE', kind: 'market' };
const AFTER_WEEK = () => new Date('2026-10-13T00:00:00+05:30');
const consistent = (b: ProviderBar) =>
  b.open !== null && b.high !== null && b.low !== null && b.close !== null &&
  b.high >= Math.max(b.open, b.close, b.low) && b.low <= Math.min(b.open, b.close) && b.low > 0;

describe('MockMarketDataProvider', () => {
  const week = { from: new Date('2026-10-05T00:00:00+05:30'), to: new Date('2026-10-12T23:59:00+05:30') };

  it('is deterministic across instances', async () => {
    const a = await new MockMarketDataProvider(sessions(), AFTER_WEEK).getHistorical(RELIANCE, week.from, week.to, '1d');
    const b = await new MockMarketDataProvider(sessions(), AFTER_WEEK).getHistorical(RELIANCE, week.from, week.to, '1d');
    expect(a).toEqual(b);
  });

  it('emits daily bars only for trading days, stamped at the session open (incl. special sessions)', async () => {
    const bars = await new MockMarketDataProvider(sessions(), AFTER_WEEK).getHistorical(RELIANCE, week.from, week.to, '1d');
    expect(bars.map((b) => b.ts.toISOString())).toEqual([
      '2026-10-05T03:45:00.000Z', '2026-10-06T03:45:00.000Z', '2026-10-08T03:45:00.000Z',
      '2026-10-09T03:45:00.000Z', '2026-10-11T12:30:00.000Z', '2026-10-12T03:45:00.000Z',
    ]);
    expect(bars.every(consistent)).toBe(true);
  });

  it('emits 75 five-minute and 25 fifteen-minute bars per regular session, 12 in a 1h special session', async () => {
    const p = new MockMarketDataProvider(sessions(), AFTER_WEEK);
    const day = { from: new Date('2026-10-05T00:00:00+05:30'), to: new Date('2026-10-05T23:59:00+05:30') };
    const m5 = await p.getHistorical(RELIANCE, day.from, day.to, '5m');
    expect(m5).toHaveLength(75);
    expect(m5[0]?.ts.toISOString()).toBe('2026-10-05T03:45:00.000Z');
    expect(m5[74]?.ts.toISOString()).toBe('2026-10-05T09:55:00.000Z');
    expect(m5.every(consistent)).toBe(true);
    expect(await p.getHistorical(RELIANCE, day.from, day.to, '15m')).toHaveLength(25);
    const special = await p.getHistorical(RELIANCE, new Date('2026-10-11T00:00:00+05:30'), new Date('2026-10-11T23:59:00+05:30'), '5m');
    expect(special).toHaveLength(12);
  });

  it('daily bar aggregates the intraday path exactly', async () => {
    const p = new MockMarketDataProvider(sessions(), AFTER_WEEK);
    const from = new Date('2026-10-06T00:00:00+05:30');
    const to = new Date('2026-10-06T23:59:00+05:30');
    const [daily] = await p.getHistorical(RELIANCE, from, to, '1d');
    const m5 = await p.getHistorical(RELIANCE, from, to, '5m');
    expect(daily?.open).toBe(m5[0]?.open);
    expect(daily?.close).toBe(m5[m5.length - 1]?.close);
    expect(daily?.high).toBe(Math.max(...m5.map((b) => b.high ?? 0)));
    expect(daily?.low).toBe(Math.min(...m5.map((b) => b.low ?? Infinity)));
    expect(daily?.volume).toBe(m5.reduce((s, b) => s + (b.volume ?? 0), 0));
  });

  it('never returns bars that have not started yet', async () => {
    const now = () => new Date('2026-10-05T10:02:00+05:30');
    const bars = await new MockMarketDataProvider(sessions(), now)
      .getHistorical(RELIANCE, new Date('2026-10-05T00:00:00+05:30'), new Date('2026-10-05T23:59:00+05:30'), '5m');
    expect(bars).toHaveLength(10);
    expect(bars[9]?.ts.toISOString()).toBe('2026-10-05T04:30:00.000Z');
  });

  it('rejects 1m, simulates unknown symbols, and keeps VIX in a plausible band over years', async () => {
    const p = new MockMarketDataProvider(sessions(), AFTER_WEEK);
    await expect(p.getHistorical(RELIANCE, week.from, week.to, '1m')).rejects.toMatchObject({ code: 'UNSUPPORTED' });
    const unknown = await p.getHistorical({ providerSymbol: 'NEWLISTING', exchange: 'NSE', kind: 'stock' }, week.from, week.to, '1d');
    expect(unknown.length).toBeGreaterThan(0);
    const vix = await p.getHistorical(VIX, new Date('2021-10-01T00:00:00Z'), week.to, '1d');
    expect(vix.length).toBeGreaterThan(1000);
    expect(vix.every((b) => (b.close ?? 0) >= 9 && (b.close ?? 0) <= 45)).toBe(true);
  });

  it('quotes the latest started bar with the previous close', async () => {
    const q = await new MockMarketDataProvider(sessions(), () => new Date('2026-10-05T10:02:00+05:30')).getQuote(RELIANCE);
    expect(q.price).toBeGreaterThan(0);
    expect(q.previousClose).toBeGreaterThan(0);
    expect(q.asOf.getTime()).toBeLessThanOrEqual(new Date('2026-10-05T10:02:00+05:30').getTime());
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL (`sessionOn` is private, so the typecheck/visibility test fails, and the mock modules are missing).

- [ ] **Step 3: Implement.** In `backend/src/domain/types.ts` append:

```ts
export interface TradingSession {
  open: Date;
  close: Date;
}

/** Trading-session lookup by IST calendar date; null when the exchange is closed all day. */
export interface TradingSessions {
  sessionOn(exchange: Exchange, date: string): Promise<TradingSession | null>;
}
```
In `MarketCalendarService.ts`:
- delete the private `Session` interface
- import `TradingSession` and `TradingSessions`
- declare `export class MarketCalendarService implements TradingSessions`
- change `private async sessionOn(exchange: Exchange, date: string): Promise<Session | null>` to `async sessionOn(exchange: Exchange, date: string): Promise<TradingSession | null>`

`backend/src/providers/market/types.ts`:
```ts
import type { BarInterval, Exchange } from '../../domain/enums.js';

export interface ProviderInstrumentRef {
  providerSymbol: string;
  exchange: Exchange;
  kind: 'stock' | 'market';
}

export interface ProviderCapabilities {
  exchanges: readonly Exchange[];
  intervals: readonly BarInterval[];
  latency: 'realtime' | 'delayed' | 'eod';
  /** Oldest data the provider keeps per interval, in days. Absent = unlimited. */
  maxLookbackDays: Partial<Record<BarInterval, number>>;
}

/** A bar exactly as the provider reported it (nulls allowed). The normalizer decides what is stored. */
export interface ProviderBar {
  ts: Date;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  adjustedClose: number | null;
  volume: number | null;
}

export interface ProviderQuote {
  price: number;
  asOf: Date;
  previousClose: number | null;
  currency: string | null;
}

/** All market data enters the system through this interface. Providers never touch the database. */
export interface MarketDataProvider {
  readonly name: string;
  capabilities(): ProviderCapabilities;
  getHistorical(ref: ProviderInstrumentRef, from: Date, to: Date, interval: BarInterval): Promise<ProviderBar[]>;
  getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote>;
}

export const INTERVAL_MS: Readonly<Record<BarInterval, number>> = {
  '1m': 60_000,
  '5m': 300_000,
  '15m': 900_000,
  '1d': 86_400_000,
};
```
`backend/src/providers/market/mock/random.ts`:
```ts
/** FNV-1a 32-bit string hash. */
export function hashString(value: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** mulberry32: tiny deterministic PRNG in [0, 1). */
export function createRng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const rngFor = (...parts: string[]): (() => number) => createRng(hashString(parts.join('|')));

/** Standard normal via Box-Muller. */
export function normal(rng: () => number): number {
  const u = Math.max(rng(), Number.EPSILON);
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
```
`backend/src/providers/market/mock/fixtures.ts`:
```ts
import { hashString } from './random.js';

/**
 * MOCK DATA ONLY: synthetic simulator settings, NOT real prices.
 * `base` is the simulated level on MOCK_ANCHOR_DATE; the walk drifts from there.
 */
export interface MockProfile {
  base: number;
  sector: string;
  beta: number;
  dailyVol: number;
  avgVolume: number;
  kind: 'equity' | 'index' | 'volatility';
}

export const MOCK_ANCHOR_DATE = '2019-01-01';

const eq = (base: number, sector: string, beta: number, dailyVol: number, avgVolume: number): MockProfile =>
  ({ base, sector, beta, dailyVol, avgVolume, kind: 'equity' });
const ix = (base: number, sector: string, beta: number): MockProfile =>
  ({ base, sector, beta, dailyVol: 0.003, avgVolume: 0, kind: 'index' });

export const MOCK_PROFILES: Readonly<Record<string, MockProfile>> = {
  RELIANCE: eq(1100, 'energy', 1.0, 0.014, 9_000_000),
  TCS: eq(1900, 'it', 0.8, 0.013, 2_500_000),
  INFY: eq(700, 'it', 0.9, 0.015, 6_000_000),
  WIPRO: eq(300, 'it', 0.9, 0.016, 8_000_000),
  HCLTECH: eq(1000, 'it', 0.85, 0.015, 3_000_000),
  HDFCBANK: eq(1050, 'banks', 1.0, 0.012, 10_000_000),
  ICICIBANK: eq(360, 'banks', 1.15, 0.016, 14_000_000),
  SBIN: eq(290, 'banks', 1.25, 0.018, 18_000_000),
  AXISBANK: eq(620, 'banks', 1.2, 0.017, 8_000_000),
  KOTAKBANK: eq(1250, 'banks', 1.0, 0.014, 4_000_000),
  BAJFINANCE: eq(2600, 'financials', 1.3, 0.02, 1_500_000),
  BHARTIARTL: eq(320, 'telecom', 0.8, 0.015, 7_000_000),
  ITC: eq(280, 'fmcg', 0.6, 0.012, 15_000_000),
  HINDUNILVR: eq(1800, 'fmcg', 0.55, 0.011, 1_800_000),
  LT: eq(1300, 'infra', 1.1, 0.015, 2_500_000),
  ADANIPORTS: eq(380, 'infra', 1.3, 0.021, 6_000_000),
  MARUTI: eq(7500, 'auto', 0.9, 0.015, 600_000),
  SUNPHARMA: eq(430, 'pharma', 0.7, 0.015, 5_000_000),
  TITAN: eq(950, 'consumer', 1.0, 0.016, 2_000_000),
  ADANIENT: eq(1100, 'metals', 1.4, 0.025, 3_000_000),
  NIFTY50: ix(10800, 'market', 1.0),
  SENSEX: ix(36000, 'market', 1.0),
  BANKNIFTY: ix(27000, 'banks', 1.1),
  NIFTYFINSERVICE: ix(11000, 'financials', 1.15),
  NIFTYIT: ix(14000, 'it', 0.85),
  NIFTYPHARMA: ix(8500, 'pharma', 0.7),
  NIFTYAUTO: ix(7800, 'auto', 0.95),
  NIFTYFMCG: ix(30000, 'fmcg', 0.6),
  NIFTYMETAL: ix(3000, 'metals', 1.3),
  NIFTYREALTY: ix(250, 'realty', 1.4),
  NIFTYENERGY: ix(15000, 'energy', 1.0),
  INDIAVIX: { base: 15, sector: 'volatility', beta: 0, dailyVol: 0.05, avgVolume: 0, kind: 'volatility' },
};

/** Profile for a symbol; unknown symbols get a stable synthetic equity profile so new listings work in mock mode. */
export function profileFor(symbol: string): MockProfile {
  const known = MOCK_PROFILES[symbol];
  if (known) return known;
  const h = hashString(symbol);
  return eq(100 + (h % 2900), 'other', 0.8 + ((h >>> 8) % 60) / 100, 0.012 + ((h >>> 16) % 10) / 1000, 500_000 + (h % 5_000_000));
}
```
`backend/src/providers/market/mock/MockMarketDataProvider.ts`:
```ts
import type { BarInterval } from '../../../domain/enums.js';
import type { TradingSession, TradingSessions } from '../../../domain/types.js';
import { AppError } from '../../../utils/errors.js';
import { addDays, isoWeekdayOf, toIst } from '../../../utils/ist.js';
import type { MarketDataProvider, ProviderBar, ProviderCapabilities, ProviderInstrumentRef, ProviderQuote } from '../types.js';
import { MOCK_ANCHOR_DATE, type MockProfile, profileFor } from './fixtures.js';
import { normal, rngFor } from './random.js';

const FIVE_MIN_MS = 300_000;
const MARKET_DRIFT = 0.0003;
const MARKET_VOL = 0.009;
const SECTOR_VOL = 0.006;
const GAP_VOL = 0.003;
const WICK = 0.0007;
const QUOTE_LOOKBACK_DAYS = 10;

interface DayState {
  open: number;
  close: number;
  prevClose: number;
  volume: number;
}

interface Series {
  lastDate: string;
  byDate: Map<string, DayState>;
}

function aggregate(bars: ProviderBar[], ts: Date): ProviderBar {
  const first = bars[0];
  const last = bars[bars.length - 1];
  if (!first || !last) throw new Error('cannot aggregate an empty bar list');
  return {
    ts,
    open: first.open,
    close: last.close,
    high: Math.max(...bars.map((b) => b.high ?? -Infinity)),
    low: Math.min(...bars.map((b) => b.low ?? Infinity)),
    adjustedClose: last.close,
    volume: bars.reduce((sum, b) => sum + (b.volume ?? 0), 0),
  };
}

/**
 * MOCK provider: deterministic, sector-correlated simulation (market + sector + idiosyncratic factors).
 * Prices are synthetic and must only ever be stored with data_mode = MOCK.
 */
export class MockMarketDataProvider implements MarketDataProvider {
  readonly name = 'mock';
  private readonly series = new Map<string, Series>();

  constructor(
    private readonly sessions: TradingSessions,
    private readonly now: () => Date = () => new Date(),
  ) {}

  capabilities(): ProviderCapabilities {
    return { exchanges: ['NSE', 'BSE'], intervals: ['5m', '15m', '1d'], latency: 'realtime', maxLookbackDays: {} };
  }

  async getHistorical(ref: ProviderInstrumentRef, from: Date, to: Date, interval: BarInterval): Promise<ProviderBar[]> {
    if (interval === '1m') {
      throw new AppError('UNSUPPORTED', 'Mock provider does not generate 1m bars', { details: { provider: this.name } });
    }
    const now = this.now();
    const end = to < now ? to : now;
    const out: ProviderBar[] = [];
    const startDate = toIst(from).date;
    let date = startDate < MOCK_ANCHOR_DATE ? MOCK_ANCHOR_DATE : startDate;
    const lastDate = toIst(end).date;
    while (date <= lastDate) {
      const session = await this.sessions.sessionOn(ref.exchange, date);
      if (session) {
        const fiveMin = this.intradayBars(ref.providerSymbol, date, session);
        const bars =
          interval === '1d' ? [aggregate(fiveMin, session.open)]
          : interval === '15m' ? this.group(fiveMin, 3)
          : fiveMin;
        for (const bar of bars) {
          if (bar.ts >= from && bar.ts <= end) out.push(bar);
        }
      }
      date = addDays(date, 1);
    }
    return out;
  }

  async getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote> {
    const now = this.now();
    let date = toIst(now).date;
    for (let i = 0; i < QUOTE_LOOKBACK_DAYS; i += 1) {
      const session = await this.sessions.sessionOn(ref.exchange, date);
      if (session && session.open <= now) {
        const started = this.intradayBars(ref.providerSymbol, date, session).filter((b) => b.ts <= now);
        const last = started[started.length - 1];
        if (last?.close) {
          const asOf = new Date(Math.min(now.getTime(), last.ts.getTime() + FIVE_MIN_MS));
          return { price: last.close, asOf, previousClose: this.dayState(ref.providerSymbol, date).prevClose, currency: 'INR' };
        }
      }
      date = addDays(date, -1);
    }
    throw new AppError('EMPTY_RESPONSE', `No mock session in the last ${QUOTE_LOOKBACK_DAYS} days`, { details: { provider: this.name } });
  }

  private group(bars: ProviderBar[], size: number): ProviderBar[] {
    const out: ProviderBar[] = [];
    for (let i = 0; i < bars.length; i += size) {
      const chunk = bars.slice(i, i + size);
      const first = chunk[0];
      if (first) out.push(aggregate(chunk, first.ts));
    }
    return out;
  }

  private intradayBars(symbol: string, date: string, session: TradingSession): ProviderBar[] {
    const profile = profileFor(symbol);
    const day = this.dayState(symbol, date);
    const steps = Math.max(1, Math.floor((session.close.getTime() - session.open.getTime()) / FIVE_MIN_MS));
    const rng = rngFor('intraday', symbol, date);
    const walk: number[] = [0];
    for (let k = 1; k <= steps; k += 1) walk.push((walk[k - 1] ?? 0) + normal(rng));
    const end = walk[steps] ?? 0;
    const stepVol = (profile.kind === 'volatility' ? 0.02 : Math.max(profile.dailyVol, 0.004)) * 0.6 / Math.sqrt(steps);
    const lo = Math.log(day.open);
    const lc = Math.log(day.close);
    // Brownian bridge from the day's open to its close.
    const prices = walk.map((w, k) => Math.exp(lo + (k / steps) * (lc - lo) + (w - (k / steps) * end) * stepVol));
    const weights = Array.from({ length: steps }, (_, k) => (steps === 1 ? 1 : 1 + 1.5 * ((2 * k) / (steps - 1) - 1) ** 2));
    const weightSum = weights.reduce((a, b) => a + b, 0);
    return Array.from({ length: steps }, (_, k) => {
      const open = prices[k] ?? day.open;
      const close = prices[k + 1] ?? day.close;
      return {
        ts: new Date(session.open.getTime() + k * FIVE_MIN_MS),
        open,
        close,
        high: Math.max(open, close) * (1 + Math.abs(normal(rng)) * WICK),
        low: Math.min(open, close) * (1 - Math.abs(normal(rng)) * WICK),
        adjustedClose: null,
        volume: Math.round((day.volume * (weights[k] ?? 1)) / weightSum),
      };
    });
  }

  /** Daily state for every calendar day since the anchor (weekends move at 20% scale). Cached per symbol. */
  private dayState(symbol: string, date: string): DayState {
    const profile = profileFor(symbol);
    let series = this.series.get(symbol);
    if (!series) {
      series = { lastDate: addDays(MOCK_ANCHOR_DATE, -1), byDate: new Map() };
      this.series.set(symbol, series);
    }
    while (series.lastDate < date) {
      const next = addDays(series.lastDate, 1);
      const prevClose = series.byDate.get(series.lastDate)?.close ?? profile.base;
      series.byDate.set(next, this.step(symbol, profile, next, prevClose));
      series.lastDate = next;
    }
    const state = series.byDate.get(date);
    if (!state) throw new AppError('INTERNAL', `Mock series has no state for ${symbol} on ${date}`);
    return state;
  }

  private step(symbol: string, p: MockProfile, date: string, prevClose: number): DayState {
    const scale = isoWeekdayOf(date) >= 6 ? 0.2 : 1;
    const market = MARKET_DRIFT + normal(rngFor('market', date)) * MARKET_VOL;
    const sector = normal(rngFor('sector', p.sector, date)) * SECTOR_VOL;
    const idio = normal(rngFor('idio', symbol, date)) * p.dailyVol;
    const gap = normal(rngFor('gap', symbol, date)) * GAP_VOL * scale;
    const close =
      p.kind === 'volatility'
        ? Math.min(45, Math.max(9, prevClose + 0.1 * (p.base - prevClose) - 250 * market * scale + idio * prevClose * scale))
        : prevClose * Math.exp((p.beta * market + sector + idio) * scale);
    const volume = p.avgVolume > 0 ? Math.round(p.avgVolume * Math.exp(normal(rngFor('volume', symbol, date)) * 0.35) * scale) : 0;
    return { open: prevClose * Math.exp(gap), close, prevClose, volume };
  }
}
```
For the volatility kind, open = `prevClose·e^gap`, which can sit just outside [9, 45] by a fraction of a percent. If the VIX band test fails on `close`, clamp only `close` (as above); `open` is not asserted.

- [ ] **Step 4: Run the gate.** Expected: PASS, including the previous calendar tests now using the moved `InMemoryHolidays`.
- [ ] **Step 5: Commit** `feat(backend): market data provider contract and deterministic mock provider`.

---

### Task 3: Yahoo adapter (client wrapper, error mapping, NSE/BSE guard) + opt-in live smoke test

**Files:**
- Create:
  - `backend/src/providers/market/yahoo/yahooClient.ts`
  - `backend/src/providers/market/yahoo/errors.ts`
  - `backend/src/providers/market/yahoo/YahooMarketDataProvider.ts`
- Modify: `backend/vitest.config.ts` (add a `live` project), `backend/package.json` (`test:live` script, `yahoo-finance2@4.0.3` dependency)
- Test: `backend/tests/unit/yahooProvider.test.ts`, `backend/tests/live/yahoo.live.test.ts`

**Interfaces:**
- Consumes: the `MarketDataProvider` types (Task 2), `RateLimiter` (Task 1), `AppError`.
- Produces:
  - `YahooClient` (our narrow shape, not the library's)
  - `createYahooClient(): YahooClient`
  - `mapYahooError(error, symbol): AppError`
  - `new YahooMarketDataProvider(client: YahooClient, limiter: RateLimiter)` with `name 'yahoo'`, capabilities `{ exchanges: ['NSE', 'BSE'], intervals: ['1m', '5m', '15m', '1d'], latency: 'delayed', maxLookbackDays: { '1m': 7, '5m': 59, '15m': 59 } }`

- [ ] **Step 1: Install and write the failing tests**

```bash
pnpm --filter @learning-stocks/backend add yahoo-finance2@4.0.3
```
`backend/tests/unit/yahooProvider.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { mapYahooError } from '../../src/providers/market/yahoo/errors.js';
import type { YahooChart, YahooClient, YahooSnapshot } from '../../src/providers/market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from '../../src/providers/market/yahoo/YahooMarketDataProvider.js';

const REF = { providerSymbol: 'RELIANCE.NS', exchange: 'NSE', kind: 'stock' } as const;

class FakeClient implements YahooClient {
  calls: string[] = [];
  constructor(private readonly chartResult: YahooChart | Error, private readonly quoteResult: YahooSnapshot | Error = new Error('unused')) {}
  async chart(symbol: string): Promise<YahooChart> {
    this.calls.push(`chart:${symbol}`);
    if (this.chartResult instanceof Error) throw this.chartResult;
    return this.chartResult;
  }
  async quote(symbol: string): Promise<YahooSnapshot> {
    this.calls.push(`quote:${symbol}`);
    if (this.quoteResult instanceof Error) throw this.quoteResult;
    return this.quoteResult;
  }
}

function provider(client: YahooClient) {
  let acquired = 0;
  const p = new YahooMarketDataProvider(client, { acquire: async () => { acquired += 1; } });
  return { p, acquired: () => acquired };
}

const chart = (exchangeName: string | null): YahooChart => ({
  exchangeName,
  currency: 'INR',
  quotes: [
    { date: new Date('2026-10-05T03:45:00Z'), open: 1171.2, high: 1193, low: 1171.2, close: 1186.4, adjclose: 1186.4, volume: 14_251_054 },
    { date: new Date('2026-10-02T03:45:00Z'), open: null, high: null, low: null, close: null, adjclose: null, volume: null },
  ],
});

describe('YahooMarketDataProvider', () => {
  it('maps chart quotes to provider bars, keeping nulls for the normalizer, and rate-limits each call', async () => {
    const { p, acquired } = provider(new FakeClient(chart('NSI')));
    const bars = await p.getHistorical(REF, new Date('2026-09-01'), new Date('2026-10-06'), '1d');
    expect(bars[0]).toEqual({ ts: new Date('2026-10-05T03:45:00Z'), open: 1171.2, high: 1193, low: 1171.2, close: 1186.4, adjustedClose: 1186.4, volume: 14_251_054 });
    expect(bars[1]?.close).toBeNull();
    expect(acquired()).toBe(1);
  });

  it('accepts BSE listings and refuses non-Indian ones', async () => {
    await expect(provider(new FakeClient(chart('BSE'))).p.getHistorical(REF, new Date(), new Date(), '1d')).resolves.toHaveLength(2);
    await expect(provider(new FakeClient(chart('NMS'))).p.getHistorical(REF, new Date(), new Date(), '1d')).rejects.toMatchObject({ code: 'UNSUPPORTED' });
    await expect(provider(new FakeClient(chart(null))).p.getHistorical(REF, new Date(), new Date(), '1d')).rejects.toMatchObject({ code: 'INVALID_RESPONSE' });
  });

  it('declares delayed latency and Yahoo intraday lookback limits', () => {
    const caps = provider(new FakeClient(chart('NSI'))).p.capabilities();
    expect(caps).toMatchObject({ latency: 'delayed', maxLookbackDays: { '1m': 7, '5m': 59, '15m': 59 } });
  });

  it('quotes, and treats a missing price as EMPTY_RESPONSE', async () => {
    const ok = provider(new FakeClient(chart('NSI'), { price: 2114.4, time: new Date('2026-10-05T09:45:00Z'), previousClose: 2100, currency: 'INR', exchange: 'NSI' }));
    expect(await ok.p.getQuote(REF)).toEqual({ price: 2114.4, asOf: new Date('2026-10-05T09:45:00Z'), previousClose: 2100, currency: 'INR' });
    const empty = provider(new FakeClient(chart('NSI'), { price: null, time: null, previousClose: null, currency: null, exchange: 'NSI' }));
    await expect(empty.p.getQuote(REF)).rejects.toMatchObject({ code: 'EMPTY_RESPONSE' });
  });
});

describe('mapYahooError', () => {
  class FailedYahooValidationError extends Error {
    override name = 'FailedYahooValidationError';
  }
  it.each([
    [new Error('No data found, symbol may be delisted'), 'UNSUPPORTED'],
    [new Error('Too Many Requests'), 'RATE_LIMITED'],
    [new FailedYahooValidationError('Failed Yahoo Schema validation'), 'INVALID_RESPONSE'],
    [new Error('5m data not available for startTime=1 and endTime=2. The requested range must be within the last 60 days.'), 'INVALID_RESPONSE'],
    [new TypeError('fetch failed'), 'NETWORK'],
    [new Error('Request timed out'), 'TIMEOUT'],
    [new Error('Something odd happened'), 'PROVIDER_DOWN'],
  ])('%s -> %s', (error, code) => {
    const mapped = mapYahooError(error, 'RELIANCE.NS');
    expect(mapped.code).toBe(code);
    expect(mapped.details).toMatchObject({ provider: 'yahoo', symbol: 'RELIANCE.NS' });
  });
});
```
`backend/tests/live/yahoo.live.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import { createYahooClient } from '../../src/providers/market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from '../../src/providers/market/yahoo/YahooMarketDataProvider.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

// Network test against real Yahoo. Runs only via: pnpm --filter @learning-stocks/backend test:live
describe.skipIf(!process.env.LIVE_YAHOO)('Yahoo live smoke', () => {
  const p = new YahooMarketDataProvider(createYahooClient(), createRateLimiter({ ratePerSecond: 1, burst: 1 }));
  const monthAgo = () => new Date(Date.now() - 30 * 86_400_000);

  it('returns NSE daily bars stamped at 09:15 IST', async () => {
    const bars = await p.getHistorical({ providerSymbol: 'RELIANCE.NS', exchange: 'NSE', kind: 'stock' }, monthAgo(), new Date(), '1d');
    const priced = bars.filter((b) => b.close !== null);
    expect(priced.length).toBeGreaterThan(10);
    expect(priced.every((b) => b.ts.toISOString().endsWith('T03:45:00.000Z'))).toBe(true);
  });

  it('maps an unknown symbol to UNSUPPORTED', async () => {
    await expect(p.getHistorical({ providerSymbol: 'NOSUCHSYMBOL123.NS', exchange: 'NSE', kind: 'stock' }, monthAgo(), new Date(), '1d'))
      .rejects.toMatchObject({ code: 'UNSUPPORTED' });
  });
});
```
In `vitest.config.ts`, add a third project `{ extends: true, test: { name: 'live', include: ['tests/live/**/*.test.ts'], testTimeout: 60_000 } }`. In `backend/package.json`, add `"test:live": "LIVE_YAHOO=1 TZ=UTC vitest run --project live"`.

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test:unit`
Expected: FAIL (modules not found).

- [ ] **Step 3: Implement** `backend/src/providers/market/yahoo/yahooClient.ts`

```ts
import YahooFinance from 'yahoo-finance2';

/** Our narrow view of yahoo-finance2. The library's own types never leave this file. */
export interface YahooChartQuote {
  date: Date;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  adjclose: number | null;
  volume: number | null;
}

export interface YahooChart {
  exchangeName: string | null;
  currency: string | null;
  quotes: YahooChartQuote[];
}

export interface YahooSnapshot {
  price: number | null;
  time: Date | null;
  previousClose: number | null;
  currency: string | null;
  exchange: string | null;
}

export type YahooInterval = '1m' | '5m' | '15m' | '1d';

export interface YahooClient {
  chart(symbol: string, options: { period1: Date; period2: Date; interval: YahooInterval }): Promise<YahooChart>;
  quote(symbol: string): Promise<YahooSnapshot>;
}

export function createYahooClient(): YahooClient {
  const yf = new YahooFinance({ suppressNotices: ['yahooSurvey'] });
  return {
    async chart(symbol, options) {
      const result = await yf.chart(symbol, options);
      return {
        exchangeName: result.meta.exchangeName ?? null,
        currency: result.meta.currency ?? null,
        quotes: result.quotes.map((q) => ({
          date: q.date,
          open: q.open ?? null,
          high: q.high ?? null,
          low: q.low ?? null,
          close: q.close ?? null,
          adjclose: q.adjclose ?? null,
          volume: q.volume ?? null,
        })),
      };
    },
    async quote(symbol) {
      const q = await yf.quote(symbol);
      return {
        price: q.regularMarketPrice ?? null,
        time: q.regularMarketTime ?? null,
        previousClose: q.regularMarketPreviousClose ?? null,
        currency: q.currency ?? null,
        exchange: q.exchange ?? null,
      };
    },
  };
}
```
If the library's result types differ (for example `quote()` typed as a union), narrow inside this file only and record a ruling.
`backend/src/providers/market/yahoo/errors.ts`:
```ts
import { AppError } from '../../../utils/errors.js';

/** Maps yahoo-finance2 failures onto our taxonomy. Upstream messages are not copied (they can contain URLs). */
export function mapYahooError(error: unknown, symbol: string): AppError {
  if (error instanceof AppError) return error;
  const name = error instanceof Error ? error.name : 'Unknown';
  const message = error instanceof Error ? error.message : String(error);
  const details = { provider: 'yahoo', symbol, upstream: name };
  if (/no data found|delisted|not found/i.test(message)) {
    return new AppError('UNSUPPORTED', `Yahoo has no data for ${symbol}`, { details });
  }
  if (/too many requests|\b429\b/i.test(message)) {
    return new AppError('RATE_LIMITED', `Yahoo rate limit hit for ${symbol}`, { details });
  }
  if (name === 'FailedYahooValidationError' || name === 'InvalidOptionsError' || name === 'BadRequestError' || /must be within|not available for/i.test(message)) {
    return new AppError('INVALID_RESPONSE', `Yahoo could not serve the request for ${symbol}`, { details });
  }
  if (/timed? ?out|timeout/i.test(message)) {
    return new AppError('TIMEOUT', `Yahoo timed out for ${symbol}`, { details });
  }
  if (/fetch failed|econnreset|econnrefused|enotfound|eai_again|network/i.test(message)) {
    return new AppError('NETWORK', `Network error reaching Yahoo for ${symbol}`, { details });
  }
  if (/unauthorized|forbidden|\b40[13]\b/i.test(message)) {
    return new AppError('AUTH_FAILED', `Yahoo refused the request for ${symbol}`, { details });
  }
  return new AppError('PROVIDER_DOWN', `Yahoo request failed for ${symbol}`, { details });
}
```
`backend/src/providers/market/yahoo/YahooMarketDataProvider.ts`:
```ts
import type { BarInterval } from '../../../domain/enums.js';
import { AppError } from '../../../utils/errors.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import type { MarketDataProvider, ProviderBar, ProviderCapabilities, ProviderInstrumentRef, ProviderQuote } from '../types.js';
import { mapYahooError } from './errors.js';
import type { YahooClient } from './yahooClient.js';

/** Yahoo exchange codes for Indian listings (NSI = NSE). */
const INDIAN_EXCHANGES = new Set(['NSI', 'BSE']);

function assertIndianListing(exchange: string | null, symbol: string): void {
  if (exchange === null) {
    throw new AppError('INVALID_RESPONSE', `Yahoo did not report an exchange for ${symbol}`, { details: { provider: 'yahoo', symbol } });
  }
  if (!INDIAN_EXCHANGES.has(exchange)) {
    throw new AppError('UNSUPPORTED', `${symbol} is listed on ${exchange}, not NSE/BSE`, { details: { provider: 'yahoo', symbol, exchange } });
  }
}

/** Unofficial Yahoo Finance data: delayed, best-effort. Rate-limited per call. */
export class YahooMarketDataProvider implements MarketDataProvider {
  readonly name = 'yahoo';

  constructor(
    private readonly client: YahooClient,
    private readonly limiter: RateLimiter,
  ) {}

  capabilities(): ProviderCapabilities {
    return {
      exchanges: ['NSE', 'BSE'],
      intervals: ['1m', '5m', '15m', '1d'],
      latency: 'delayed',
      maxLookbackDays: { '1m': 7, '5m': 59, '15m': 59 },
    };
  }

  async getHistorical(ref: ProviderInstrumentRef, from: Date, to: Date, interval: BarInterval): Promise<ProviderBar[]> {
    await this.limiter.acquire();
    let chart;
    try {
      chart = await this.client.chart(ref.providerSymbol, { period1: from, period2: to, interval });
    } catch (error) {
      throw mapYahooError(error, ref.providerSymbol);
    }
    assertIndianListing(chart.exchangeName, ref.providerSymbol);
    return chart.quotes.map((q) => ({
      ts: q.date, open: q.open, high: q.high, low: q.low, close: q.close, adjustedClose: q.adjclose, volume: q.volume,
    }));
  }

  async getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote> {
    await this.limiter.acquire();
    let snapshot;
    try {
      snapshot = await this.client.quote(ref.providerSymbol);
    } catch (error) {
      throw mapYahooError(error, ref.providerSymbol);
    }
    assertIndianListing(snapshot.exchange, ref.providerSymbol);
    if (snapshot.price === null || snapshot.time === null) {
      throw new AppError('EMPTY_RESPONSE', `Yahoo returned no price for ${ref.providerSymbol}`, { details: { provider: 'yahoo', symbol: ref.providerSymbol } });
    }
    return { price: snapshot.price, asOf: snapshot.time, previousClose: snapshot.previousClose, currency: snapshot.currency };
  }
}
```

- [ ] **Step 4: Run the gate, then the live smoke test**

Run the gate. Expected: PASS (the live project's tests are skipped).
Run: `pnpm --filter @learning-stocks/backend test:live`. Expected: 2 passed (needs network).

- [ ] **Step 5: Commit** `feat(backend): Yahoo market data adapter with error mapping, NSE/BSE guard and live smoke test`.

---

### Task 4: Bar normalizer and validator (pure)

**Files:** Create `backend/src/services/marketData/barNormalizer.ts`. Test: `backend/tests/unit/barNormalizer.test.ts`.

**Interfaces:**
- Consumes: `ProviderBar`, `INTERVAL_MS` (Task 2); `Bar`, `InstrumentRef`, `TradingSession` (domain); `toIst`.
- Produces:
  - `DropReason = 'EMPTY' | 'INCOMPLETE' | 'DUPLICATE_IN_BATCH'`
  - `RejectReason = 'NON_POSITIVE_PRICE' | 'OHLC_INCONSISTENT' | 'NEGATIVE_VOLUME' | 'FUTURE_TIMESTAMP' | 'NOT_A_TRADING_DAY' | 'OUTSIDE_SESSION'`
  - `NormalizeContext { instrument; dataMode; source; timeframe; now; sessionFor(date: string): TradingSession | null; dailySettleMs?: number }`
  - `normalizeBars(raw, ctx): { bars: Bar[]; dropped: Partial<Record<DropReason, number>>; rejected: Partial<Record<RejectReason, number>> }` (bars ascending, `change`/`changePercent` null)
  - `DEFAULT_DAILY_SETTLE_MS = 30 * 60_000`

- [ ] **Step 1: Write the failing test** `backend/tests/unit/barNormalizer.test.ts`

```ts
import { describe, expect, it } from 'vitest';
import type { TradingSession } from '../../src/domain/types.js';
import type { ProviderBar } from '../../src/providers/market/types.js';
import { normalizeBars, type NormalizeContext } from '../../src/services/marketData/barNormalizer.js';

const SESSIONS: Record<string, TradingSession> = {
  '2026-10-05': { open: new Date('2026-10-05T03:45:00Z'), close: new Date('2026-10-05T10:00:00Z') },
  '2026-10-06': { open: new Date('2026-10-06T03:45:00Z'), close: new Date('2026-10-06T10:00:00Z') },
};
const ctx = (over: Partial<NormalizeContext> = {}): NormalizeContext => ({
  instrument: { kind: 'stock', id: 'stock-1' }, dataMode: 'LIVE', source: 'yahoo', timeframe: '1d',
  now: new Date('2026-10-06T12:00:00Z'), sessionFor: (d) => SESSIONS[d] ?? null, ...over,
});
const bar = (ts: string, o: number | null, h: number | null, l: number | null, c: number | null, v: number | null = 100): ProviderBar =>
  ({ ts: new Date(ts), open: o, high: h, low: l, close: c, adjustedClose: c, volume: v });

describe('normalizeBars', () => {
  it('normalises odd daily stamps to the session open and tags mode/source', () => {
    const r = normalizeBars([bar('2026-10-05T10:01:29Z', 100, 105, 99, 104)], ctx());
    expect(r.bars).toHaveLength(1);
    expect(r.bars[0]).toMatchObject({ ts: new Date('2026-10-05T03:45:00Z'), dataMode: 'LIVE', source: 'yahoo', timeframe: '1d', close: 104, volume: 100, change: null });
  });

  it('drops empty (null) bars and in-progress daily bars until close + settle', () => {
    const r = normalizeBars(
      [bar('2026-10-05T03:45:00Z', null, null, null, null, 0), bar('2026-10-06T03:45:00Z', 100, 105, 99, 104)],
      ctx({ now: new Date('2026-10-06T10:10:00Z') }),
    );
    expect(r.bars).toEqual([]);
    expect(r.dropped).toEqual({ EMPTY: 1, INCOMPLETE: 1 });
    const settled = normalizeBars([bar('2026-10-06T03:45:00Z', 100, 105, 99, 104)], ctx({ now: new Date('2026-10-06T10:30:00Z') }));
    expect(settled.bars).toHaveLength(1);
  });

  it('rejects invalid prices, inconsistent OHLC, negative volume, future bars and holidays', () => {
    const r = normalizeBars([
      bar('2026-10-05T03:45:00Z', 0, 105, 99, 104),
      bar('2026-10-05T03:45:00Z', 100, 98, 99, 99),
      bar('2026-10-05T03:45:00Z', 100, 105, 99, 104, -5),
      bar('2026-10-07T03:45:00Z', 100, 105, 99, 104),
      bar('2026-10-02T03:45:00Z', 100, 105, 99, 104),
    ], ctx());
    expect(r.bars).toEqual([]);
    expect(r.rejected).toEqual({ NON_POSITIVE_PRICE: 1, OHLC_INCONSISTENT: 1, NEGATIVE_VOLUME: 1, FUTURE_TIMESTAMP: 1, NOT_A_TRADING_DAY: 1 });
  });

  it('keeps intraday bars inside the session that have fully elapsed', () => {
    const now = new Date('2026-10-06T04:02:00Z');
    const r = normalizeBars([
      bar('2026-10-06T03:40:00Z', 100, 101, 99, 100),
      bar('2026-10-06T03:45:00Z', 100, 101, 99, 100),
      bar('2026-10-06T03:55:00Z', 100, 101, 99, 100),
      bar('2026-10-06T04:00:00Z', 100, 101, 99, 100),
    ], ctx({ timeframe: '5m', now }));
    expect(r.bars.map((b) => b.ts.toISOString())).toEqual(['2026-10-06T03:45:00.000Z', '2026-10-06T03:55:00.000Z']);
    expect(r.rejected).toEqual({ OUTSIDE_SESSION: 1 });
    expect(r.dropped).toEqual({ INCOMPLETE: 1 });
  });

  it('treats null volume (indices) as 0, de-duplicates by timestamp keeping the last, and sorts', () => {
    const r = normalizeBars([
      bar('2026-10-06T03:45:00Z', 100, 105, 99, 104, null),
      bar('2026-10-05T03:45:00Z', 90, 95, 89, 94, null),
      bar('2026-10-05T03:45:00Z', 91, 96, 90, 95, null),
    ], ctx({ now: new Date('2026-10-07T00:00:00Z') }));
    expect(r.bars.map((b) => [b.ts.toISOString(), b.close, b.volume])).toEqual([
      ['2026-10-05T03:45:00.000Z', 95, 0], ['2026-10-06T03:45:00.000Z', 104, 0],
    ]);
    expect(r.dropped).toEqual({ DUPLICATE_IN_BATCH: 1 });
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/services/marketData/barNormalizer.ts`

```ts
import type { BarInterval, DataMode } from '../../domain/enums.js';
import type { Bar, InstrumentRef, TradingSession } from '../../domain/types.js';
import { INTERVAL_MS, type ProviderBar } from '../../providers/market/types.js';
import { toIst } from '../../utils/ist.js';

export type DropReason = 'EMPTY' | 'INCOMPLETE' | 'DUPLICATE_IN_BATCH';
export type RejectReason =
  | 'NON_POSITIVE_PRICE' | 'OHLC_INCONSISTENT' | 'NEGATIVE_VOLUME'
  | 'FUTURE_TIMESTAMP' | 'NOT_A_TRADING_DAY' | 'OUTSIDE_SESSION';

/** Daily bars are final only this long after the close (providers revise the closing auction). */
export const DEFAULT_DAILY_SETTLE_MS = 30 * 60_000;

export interface NormalizeContext {
  instrument: InstrumentRef;
  dataMode: DataMode;
  source: string;
  timeframe: BarInterval;
  now: Date;
  sessionFor(date: string): TradingSession | null;
  dailySettleMs?: number;
}

export interface NormalizeResult {
  bars: Bar[];
  dropped: Partial<Record<DropReason, number>>;
  rejected: Partial<Record<RejectReason, number>>;
}

function bump<K extends string>(counts: Partial<Record<K, number>>, key: K): void {
  counts[key] = (counts[key] ?? 0) + 1;
}

/**
 * Validates and normalises provider bars (PRD §6.5). Never stores partial truth:
 * empty and in-progress bars are dropped; invalid bars are rejected and counted.
 * Daily bars are re-stamped at the session open of their IST date (bar ts = open time).
 */
export function normalizeBars(raw: readonly ProviderBar[], ctx: NormalizeContext): NormalizeResult {
  const dropped: NormalizeResult['dropped'] = {};
  const rejected: NormalizeResult['rejected'] = {};
  const byTs = new Map<number, Bar>();
  const settleMs = ctx.dailySettleMs ?? 30 * 60_000;
  const nowMs = ctx.now.getTime();

  for (const r of raw) {
    const { open, high, low, close } = r;
    if (open === null || high === null || low === null || close === null) {
      bump(dropped, 'EMPTY');
      continue;
    }
    if (![open, high, low, close].every((v) => Number.isFinite(v) && v > 0)) {
      bump(rejected, 'NON_POSITIVE_PRICE');
      continue;
    }
    if (high < Math.max(open, close, low) || low > Math.min(open, close)) {
      bump(rejected, 'OHLC_INCONSISTENT');
      continue;
    }
    const volume = r.volume ?? 0;
    if (!Number.isFinite(volume) || volume < 0) {
      bump(rejected, 'NEGATIVE_VOLUME');
      continue;
    }
    if (r.ts.getTime() > nowMs) {
      bump(rejected, 'FUTURE_TIMESTAMP');
      continue;
    }
    const session = ctx.sessionFor(toIst(r.ts).date);
    if (!session) {
      bump(rejected, 'NOT_A_TRADING_DAY');
      continue;
    }

    let ts: Date;
    if (ctx.timeframe === '1d') {
      ts = session.open;
      if (nowMs < session.close.getTime() + settleMs) {
        bump(dropped, 'INCOMPLETE');
        continue;
      }
    } else {
      if (r.ts < session.open || r.ts >= session.close) {
        bump(rejected, 'OUTSIDE_SESSION');
        continue;
      }
      ts = r.ts;
      const barEnd = Math.min(r.ts.getTime() + INTERVAL_MS[ctx.timeframe], session.close.getTime());
      if (nowMs < barEnd) {
        bump(dropped, 'INCOMPLETE');
        continue;
      }
    }

    if (byTs.has(ts.getTime())) bump(dropped, 'DUPLICATE_IN_BATCH');
    byTs.set(ts.getTime(), {
      instrument: ctx.instrument, dataMode: ctx.dataMode, timeframe: ctx.timeframe, ts,
      open, high, low, close, adjustedClose: r.adjustedClose ?? null, volume: Math.round(volume),
      change: null, changePercent: null, vwap: null, source: ctx.source,
    });
  }

  const bars = [...byTs.values()].sort((a, b) => a.ts.getTime() - b.ts.getTime());
  return { bars, dropped, rejected };
}
```
Replace the literal `30 * 60_000` in the function with `DEFAULT_DAILY_SETTLE_MS` (same value). It's shown inline above only for readability.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): bar normalizer enforcing PRD data-quality rules`.

---

### Task 5: Provider-symbol repository and structured run details

**Files:**
- Create: `backend/src/repositories/ProviderSymbolRepository.ts`
- Modify: `backend/src/repositories/SystemLogRepository.ts` (`finishRun` accepts `details?: Record<string, unknown>`)
- Test: `backend/tests/integration/providerSymbolRepository.test.ts`, plus one new case in `backend/tests/integration/systemLogRepository.test.ts`

**Interfaces — Produces:**
- `ProviderSymbolEntry { provider; providerSymbol; verified; kind: 'stock' | 'market'; symbol; exchange }`
- `ProviderSymbolRepository(db)`:
  - `listByProvider(provider, symbols?: readonly string[]): Promise<ProviderSymbolEntry[]>` (active instruments, stocks then markets, by symbol)
  - `setVerified(provider, providerSymbol, verified): Promise<void>` (`NOT_FOUND` if missing)
- `finishRun(..., { ..., details? })` stores `error_details` as follows:
  - `details` only → `details`
  - `error` only → the serialised error (unchanged)
  - both → `{ ...serialisedError, context: details }`

- [ ] **Step 1: Write the failing tests** `backend/tests/integration/providerSymbolRepository.test.ts`

```ts
import { afterAll, describe, expect, it } from 'vitest';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('ProviderSymbolRepository', () => {
  it('lists all active instruments for a provider, stocks first', async () => {
    const rows = await new ProviderSymbolRepository(db).listByProvider('yahoo');
    expect(rows).toHaveLength(32);
    expect(rows[0]).toMatchObject({ kind: 'stock', symbol: 'ADANIENT', providerSymbol: 'ADANIENT.NS', exchange: 'NSE' });
    expect(rows.find((r) => r.symbol === 'SENSEX')).toMatchObject({ kind: 'market', providerSymbol: '^BSESN', exchange: 'BSE' });
  });

  it('filters by internal symbols', async () => {
    const rows = await new ProviderSymbolRepository(db).listByProvider('yahoo', ['RELIANCE', 'NIFTY50']);
    expect(rows.map((r) => r.providerSymbol)).toEqual(['RELIANCE.NS', '^NSEI']);
  });

  it('sets the verified flag and rejects unknown symbols', async () => {
    await withRollback(db, async (trx) => {
      const repo = new ProviderSymbolRepository(trx);
      await repo.setVerified('yahoo', 'RELIANCE.NS', true);
      expect((await repo.listByProvider('yahoo', ['RELIANCE']))[0]?.verified).toBe(true);
      await expect(repo.setVerified('yahoo', 'NOPE.NS', true)).rejects.toMatchObject({ code: 'NOT_FOUND' });
    });
  });
});
```
Append to `backend/tests/integration/systemLogRepository.test.ts`:
```ts
  it('orders runs started in the same transaction newest first', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      await repo.startRun({ service: 's', jobName: 'j', operation: 'first' });
      const second = await repo.startRun({ service: 's', jobName: 'j', operation: 'second' });
      expect((await repo.recentRuns(1))[0]?.id).toBe(second);
    });
  });

  it('stores structured run details, alone or alongside an error', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const a = await repo.startRun({ service: 'MarketDataService', jobName: 'cli.sync-market', operation: 'sync:1d' });
      await repo.finishRun(a, { status: 'PARTIAL', counts: { fetched: 10, inserted: 8, skipped: 1, failed: 1 }, details: { failures: [{ symbol: 'TCS', code: 'UNSUPPORTED' }] } });
      expect((await repo.recentRuns(1))[0]?.errorDetails).toEqual({ failures: [{ symbol: 'TCS', code: 'UNSUPPORTED' }] });
    });
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const b = await repo.startRun({ service: 'MarketDataService', jobName: 'cli.sync-market', operation: 'sync:1d' });
      await repo.finishRun(b, { status: 'FAILED', counts: { fetched: 0, inserted: 0, skipped: 0, failed: 0 }, error: new AppError('UNSUPPORTED', 'no 1m'), details: { timeframe: '1m' } });
      expect((await repo.recentRuns(1))[0]?.errorDetails).toMatchObject({ code: 'UNSUPPORTED', context: { timeframe: '1m' } });
    });
  });
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (module missing; `details` not stored).

- [ ] **Step 3: Implement** `backend/src/repositories/ProviderSymbolRepository.ts`

```ts
import type { Database } from '../database/db.js';
import type { Exchange } from '../domain/enums.js';
import { AppError } from '../utils/errors.js';

export interface ProviderSymbolEntry {
  provider: string;
  providerSymbol: string;
  verified: boolean;
  kind: 'stock' | 'market';
  symbol: string;
  exchange: Exchange;
}

export class ProviderSymbolRepository {
  constructor(private readonly db: Database) {}

  async listByProvider(provider: string, symbols?: readonly string[]): Promise<ProviderSymbolEntry[]> {
    const wanted = symbols?.map((s) => s.trim().toUpperCase());
    let stockQuery = this.db.selectFrom('provider_symbols as p').innerJoin('stocks as s', 's.id', 'p.stock_id')
      .select(['p.provider', 'p.provider_symbol', 'p.verified', 's.symbol', 's.exchange'])
      .where('p.provider', '=', provider).where('s.is_active', '=', true);
    let marketQuery = this.db.selectFrom('provider_symbols as p').innerJoin('markets as m', 'm.id', 'p.market_id')
      .select(['p.provider', 'p.provider_symbol', 'p.verified', 'm.symbol', 'm.exchange'])
      .where('p.provider', '=', provider).where('m.is_active', '=', true);
    if (wanted) {
      if (wanted.length === 0) return [];
      stockQuery = stockQuery.where('s.symbol', 'in', wanted);
      marketQuery = marketQuery.where('m.symbol', 'in', wanted);
    }
    const [stocks, markets] = await Promise.all([stockQuery.orderBy('s.symbol').execute(), marketQuery.orderBy('m.symbol').execute()]);
    const map = (kind: 'stock' | 'market') => (r: (typeof stocks)[number]): ProviderSymbolEntry => ({
      provider: r.provider, providerSymbol: r.provider_symbol, verified: r.verified, kind, symbol: r.symbol, exchange: r.exchange,
    });
    return [...stocks.map(map('stock')), ...markets.map(map('market'))];
  }

  async setVerified(provider: string, providerSymbol: string, verified: boolean): Promise<void> {
    const result = await this.db.updateTable('provider_symbols').set({ verified })
      .where('provider', '=', provider).where('provider_symbol', '=', providerSymbol).executeTakeFirst();
    if (Number(result.numUpdatedRows) === 0) {
      throw new AppError('NOT_FOUND', `No ${provider} mapping for ${providerSymbol}`, { details: { provider, providerSymbol } });
    }
  }
}
```
Also fix the deferred Phase 2 minor that Task 6's test now depends on. Two runs started in one transaction share `now()`, so "newest run" is ambiguous:
- in `startRun`, set `started_at: sql\`clock_timestamp()\``
- in `recentRuns`, order by `started_at desc` first, then `created_at desc`

In `SystemLogRepository.finishRun`, add `details?: Record<string, unknown>` to the result type and replace the `error_details` expression with:
```ts
      error_details: (() => {
        const payload =
          result.error !== undefined && result.details !== undefined ? { ...serializeError(result.error), context: result.details }
          : result.error !== undefined ? serializeError(result.error)
          : result.details;
        return payload === undefined ? null : sql`${JSON.stringify(payload)}::jsonb`;
      })(),
```

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(backend): provider-symbol repository and structured run details`.

---

### Task 6: MarketDataService (orchestration, failure isolation, changes, run logging)

**Files:** Create `backend/src/services/marketData/MarketDataService.ts`. Test: `backend/tests/integration/marketDataService.test.ts`.

**Interfaces:**
- Consumes:
  - `MarketDataProvider`, `ProviderInstrumentRef`, `INTERVAL_MS` (Task 2)
  - `normalizeBars`, `DEFAULT_DAILY_SETTLE_MS` (Task 4)
  - `ProviderSymbolRepository` (Task 5), plus `StockRepository.findBySymbol`, `MarketRepository.findBySymbol`, `MarketDataRepository.insertBars` and `getBars`
  - `SystemLogRepository`, `TradingSessions`, `withRetry`, `RetryOptions`, `mapWithConcurrency`
- Produces:
  - `SyncRequest { jobName; timeframe; from; to; symbols?; includeIndices? }`
  - `SyncResult` (fields below)
  - `MarketDataServiceDeps`
  - `class MarketDataService { sync(request): Promise<SyncResult> }`

- [ ] **Step 1: Write the failing test** `backend/tests/integration/marketDataService.test.ts`

```ts
import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import type { BarInterval } from '../../src/domain/enums.js';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import type { MarketDataProvider, ProviderBar, ProviderCapabilities, ProviderInstrumentRef, ProviderQuote } from '../../src/providers/market/types.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MarketDataService } from '../../src/services/marketData/MarketDataService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({ level: 'silent', destination: new Writable({ write(_c, _e, cb) { cb(); } }) });
const FRIDAY_EVENING = new Date('2026-10-09T17:00:00+05:30');

/** Wraps the mock provider; can fail or inject raw bars for chosen symbols, and records calls. */
class StubProvider implements MarketDataProvider {
  readonly name = 'mock';
  calls: Array<{ symbol: string; from: Date; interval: BarInterval }> = [];
  constructor(
    private readonly inner: MarketDataProvider,
    private readonly behaviour: Record<string, AppError | ProviderBar[]> = {},
    private readonly caps?: Partial<ProviderCapabilities>,
  ) {}
  capabilities(): ProviderCapabilities { return { ...this.inner.capabilities(), ...this.caps }; }
  async getHistorical(ref: ProviderInstrumentRef, from: Date, to: Date, interval: BarInterval): Promise<ProviderBar[]> {
    this.calls.push({ symbol: ref.providerSymbol, from, interval });
    const b = this.behaviour[ref.providerSymbol];
    if (b instanceof AppError) throw b;
    if (b) return b;
    return this.inner.getHistorical(ref, from, to, interval);
  }
  async getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote> { return this.inner.getQuote(ref); }
}

function build(trx: Database, now: Date, wrap: (mock: MarketDataProvider) => MarketDataProvider = (m) => m) {
  const sessions = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());
  const provider = wrap(new MockMarketDataProvider(sessions, () => now));
  const service = new MarketDataService({
    provider, sessions, dataMode: 'MOCK', logger: silent, now: () => now,
    providerSymbols: new ProviderSymbolRepository(trx), stocks: new StockRepository(trx), markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx), systemLogs: new SystemLogRepository(trx),
    retry: { sleep: async () => undefined },
  });
  return { service, provider };
}

const range = (from: string, now = FRIDAY_EVENING) => ({ from: new Date(from), to: now });

describe('MarketDataService', () => {
  it('ingests daily bars idempotently, computes change vs previous close, and logs the run', async () => {
    await withRollback(db, async (trx) => {
      const { service } = build(trx, FRIDAY_EVENING);
      const first = await service.sync({ jobName: 'test', timeframe: '1d', ...range('2026-09-21T00:00:00+05:30'), symbols: ['RELIANCE', 'TCS'], includeIndices: false });
      // 15 weekdays (Sep 21 - Oct 9) minus the Oct 2 holiday = 14 trading days x 2 stocks.
      expect(first).toMatchObject({ status: 'SUCCESS', instruments: { total: 2, succeeded: 2, failed: 0 }, bars: { inserted: 28, duplicates: 0, rejected: 0 } });
      const again = await service.sync({ jobName: 'test', timeframe: '1d', ...range('2026-09-21T00:00:00+05:30'), symbols: ['RELIANCE', 'TCS'], includeIndices: false });
      expect(again.bars).toMatchObject({ inserted: 0, duplicates: 28 });

      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      const bars = await new MarketDataRepository(trx).getBars({ kind: 'stock', id: stock?.id ?? '' }, 'MOCK', '1d', new Date('2026-09-01'), FRIDAY_EVENING);
      expect(bars[0]?.change).toBeNull();
      const [a, b] = [bars[0], bars[1]];
      expect(b?.change).toBeCloseTo((b?.close ?? 0) - (a?.close ?? 0), 3);
      expect(b?.changePercent).toBeCloseTo((((b?.close ?? 0) - (a?.close ?? 0)) / (a?.close ?? 1)) * 100, 3);
      expect(bars.every((x) => x.source === 'mock' && x.dataMode === 'MOCK')).toBe(true);

      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({ id: again.runId, status: 'SUCCESS', recordsInserted: 0, recordsSkipped: 28 });
    });
  });

  it('includes indices, and stores only completed intraday bars with change vs the previous daily close', async () => {
    await withRollback(db, async (trx) => {
      await build(trx, FRIDAY_EVENING).service.sync({ jobName: 'test', timeframe: '1d', ...range('2026-10-05T00:00:00+05:30'), symbols: ['RELIANCE', 'NIFTY50'] });
      const midSession = new Date('2026-10-09T10:02:00+05:30');
      const intraday = await build(trx, midSession).service.sync({ jobName: 'test', timeframe: '5m', from: new Date('2026-10-09T09:00:00+05:30'), to: midSession, symbols: ['RELIANCE', 'NIFTY50'] });
      expect(intraday.bars.inserted).toBe(18);
      expect(intraday.droppedByReason.INCOMPLETE).toBe(2);
      const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
      const q = await new MarketDataRepository(trx).latestQuote({ kind: 'market', id: nifty?.id ?? '' }, 'MOCK');
      expect(q?.timeframe).toBe('5m');
      expect(q?.changePercent).not.toBeNull();
    });
  });

  it('isolates per-instrument failures and reports PARTIAL', async () => {
    await withRollback(db, async (trx) => {
      const { service, provider } = build(trx, FRIDAY_EVENING, (m) => new StubProvider(m, {
        TCS: new AppError('UNSUPPORTED', 'no data for TCS'),
        INFY: new AppError('TIMEOUT', 'slow'),
      }));
      const r = await service.sync({ jobName: 'test', timeframe: '1d', ...range('2026-10-05T00:00:00+05:30'), symbols: ['RELIANCE', 'TCS', 'INFY'], includeIndices: false });
      expect(r.status).toBe('PARTIAL');
      expect(r.instruments).toEqual({ total: 3, succeeded: 1, failed: 2 });
      expect(r.failures.map((f) => [f.symbol, f.code]).sort()).toEqual([['INFY', 'TIMEOUT'], ['TCS', 'UNSUPPORTED']]);
      expect((provider as StubProvider).calls.filter((c) => c.symbol === 'INFY')).toHaveLength(3);
      expect((provider as StubProvider).calls.filter((c) => c.symbol === 'TCS')).toHaveLength(1);
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run?.status).toBe('PARTIAL');
      expect(run?.errorDetails).toMatchObject({ failures: expect.arrayContaining([expect.objectContaining({ symbol: 'TCS', code: 'UNSUPPORTED' })]) });
    });
  });

  it('counts dropped and rejected provider bars and marks the run PARTIAL', async () => {
    await withRollback(db, async (trx) => {
      const raw: ProviderBar[] = [
        { ts: new Date('2026-10-05T03:45:00Z'), open: 100, high: 105, low: 99, close: 104, adjustedClose: 104, volume: 10 },
        { ts: new Date('2026-10-06T03:45:00Z'), open: 100, high: 98, low: 99, close: 99, adjustedClose: 99, volume: 10 },
        { ts: new Date('2026-10-02T03:45:00Z'), open: 100, high: 105, low: 99, close: 104, adjustedClose: 104, volume: 10 },
        { ts: new Date('2026-10-07T03:45:00Z'), open: null, high: null, low: null, close: null, adjustedClose: null, volume: null },
      ];
      const { service } = build(trx, FRIDAY_EVENING, (m) => new StubProvider(m, { RELIANCE: raw }));
      const r = await service.sync({ jobName: 'test', timeframe: '1d', ...range('2026-10-01T00:00:00+05:30'), symbols: ['RELIANCE'], includeIndices: false });
      expect(r.status).toBe('PARTIAL');
      expect(r.bars).toMatchObject({ fetched: 4, inserted: 1, rejected: 2, dropped: 1 });
      expect(r.rejectedByReason).toEqual({ OHLC_INCONSISTENT: 1, NOT_A_TRADING_DAY: 1 });
    });
  });

  it('fails fast for an unsupported timeframe and clamps ranges beyond provider lookback', async () => {
    await withRollback(db, async (trx) => {
      const unsupported = await build(trx, FRIDAY_EVENING).service.sync({ jobName: 'test', timeframe: '1m', ...range('2026-10-09T00:00:00+05:30'), symbols: ['RELIANCE'] });
      expect(unsupported.status).toBe('FAILED');
      expect(unsupported.notes.join(' ')).toMatch(/does not support 1m/);

      const { service, provider } = build(trx, FRIDAY_EVENING, (m) => new StubProvider(m, {}, { maxLookbackDays: { '5m': 2 } }));
      const r = await service.sync({ jobName: 'test', timeframe: '5m', ...range('2026-09-01T00:00:00+05:30'), symbols: ['RELIANCE'], includeIndices: false });
      expect(r.notes.join(' ')).toMatch(/clamped/);
      expect((provider as StubProvider).calls[0]?.from.getTime()).toBe(FRIDAY_EVENING.getTime() - 2 * 86_400_000);
    });
  });

  it('reports FAILED when every instrument fails, and notes unknown symbols', async () => {
    await withRollback(db, async (trx) => {
      const { service } = build(trx, FRIDAY_EVENING, (m) => new StubProvider(m, { RELIANCE: new AppError('AUTH_FAILED', 'bad key') }));
      const r = await service.sync({ jobName: 'test', timeframe: '1d', ...range('2026-10-05T00:00:00+05:30'), symbols: ['RELIANCE', 'NOSUCH'], includeIndices: false });
      expect(r.status).toBe('FAILED');
      expect(r.notes.join(' ')).toMatch(/NOSUCH/);
    });
  });
});
```
Check on the intraday test: on Oct 9, from 09:00 to 10:02 IST, the bars are 09:15…10:00 (10 started). 09:15–09:55 are complete (9 per symbol, 18 in total); the 10:00 bar is incomplete (1 per symbol, so 2 dropped).

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/services/marketData/MarketDataService.ts`

```ts
import type { Logger } from 'pino';
import type { BarInterval, DataMode, Exchange, JobStatus } from '../../domain/enums.js';
import type { Bar, InstrumentRef, TradingSession, TradingSessions } from '../../domain/types.js';
import type { MarketDataProvider, ProviderInstrumentRef } from '../../providers/market/types.js';
import type { MarketDataRepository } from '../../repositories/MarketDataRepository.js';
import type { MarketRepository } from '../../repositories/MarketRepository.js';
import type { ProviderSymbolEntry, ProviderSymbolRepository } from '../../repositories/ProviderSymbolRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { mapWithConcurrency } from '../../utils/concurrency.js';
import { AppError, type ErrorCode, isAppError } from '../../utils/errors.js';
import { addDays, toIst } from '../../utils/ist.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import { DEFAULT_DAILY_SETTLE_MS, type DropReason, normalizeBars, type RejectReason } from './barNormalizer.js';

const DAY_MS = 86_400_000;
const PREV_CLOSE_LOOKBACK_DAYS = 14;

export interface SyncRequest {
  jobName: string;
  timeframe: BarInterval;
  from: Date;
  to: Date;
  /** Internal symbols (stocks and/or markets). Omit for all active instruments. */
  symbols?: readonly string[];
  includeIndices?: boolean;
}

export interface InstrumentFailure {
  symbol: string;
  providerSymbol: string;
  code: ErrorCode;
  message: string;
}

export interface SyncResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  dataMode: DataMode;
  timeframe: BarInterval;
  from: Date;
  to: Date;
  instruments: { total: number; succeeded: number; failed: number };
  bars: { fetched: number; inserted: number; duplicates: number; dropped: number; rejected: number };
  droppedByReason: Partial<Record<DropReason, number>>;
  rejectedByReason: Partial<Record<RejectReason, number>>;
  failures: InstrumentFailure[];
  notes: string[];
}

export interface MarketDataServiceDeps {
  provider: MarketDataProvider;
  providerSymbols: ProviderSymbolRepository;
  stocks: StockRepository;
  markets: MarketRepository;
  marketData: MarketDataRepository;
  systemLogs: SystemLogRepository;
  sessions: TradingSessions;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  retry?: RetryOptions;
  concurrency?: number;
  dailySettleMs?: number;
}

interface Target {
  entry: ProviderSymbolEntry;
  ref: InstrumentRef;
  providerRef: ProviderInstrumentRef;
}

function addCounts<K extends string>(into: Partial<Record<K, number>>, from: Partial<Record<K, number>>): void {
  for (const [key, value] of Object.entries(from) as Array<[K, number | undefined]>) {
    into[key] = (into[key] ?? 0) + (value ?? 0);
  }
}

const sumValues = (rec: Partial<Record<string, number>>): number =>
  Object.values(rec).reduce<number>((s, v) => s + (v ?? 0), 0);

export class MarketDataService {
  private readonly now: () => Date;

  constructor(private readonly deps: MarketDataServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async sync(request: SyncRequest): Promise<SyncResult> {
    const { provider, systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({ service: 'MarketDataService', jobName: request.jobName, operation: `sync:${request.timeframe}` });
    const result: SyncResult = {
      runId, status: 'SUCCESS', provider: provider.name, dataMode: this.deps.dataMode, timeframe: request.timeframe,
      from: request.from, to: request.to < now ? request.to : now,
      instruments: { total: 0, succeeded: 0, failed: 0 },
      bars: { fetched: 0, inserted: 0, duplicates: 0, dropped: 0, rejected: 0 },
      droppedByReason: {}, rejectedByReason: {}, failures: [], notes: [],
    };
    let runError: unknown;

    try {
      const caps = provider.capabilities();
      if (!caps.intervals.includes(request.timeframe)) {
        throw new AppError('UNSUPPORTED', `Provider ${provider.name} does not support ${request.timeframe} bars`);
      }
      const lookback = caps.maxLookbackDays[request.timeframe];
      if (lookback !== undefined) {
        const earliest = new Date(now.getTime() - lookback * DAY_MS);
        if (result.from < earliest) {
          result.notes.push(`from clamped to ${earliest.toISOString()}: ${provider.name} keeps ${lookback} days of ${request.timeframe} data`);
          result.from = earliest;
        }
      }

      const targets = await this.resolveTargets(request, caps.exchanges, result);
      result.instruments.total = targets.length + result.failures.length;
      const sessionMaps = await this.loadSessions(targets, result.from, result.to);

      await mapWithConcurrency(targets, this.deps.concurrency ?? 4, async (target) => {
        try {
          const raw = await withRetry(
            () => provider.getHistorical(target.providerRef, result.from, result.to, request.timeframe),
            this.deps.retry,
          );
          result.bars.fetched += raw.length;
          const sessions = sessionMaps.get(target.entry.exchange) ?? new Map<string, TradingSession | null>();
          const normalized = normalizeBars(raw, {
            instrument: target.ref, dataMode: this.deps.dataMode, source: provider.name, timeframe: request.timeframe, now,
            sessionFor: (date) => sessions.get(date) ?? null, dailySettleMs: this.deps.dailySettleMs ?? DEFAULT_DAILY_SETTLE_MS,
          });
          addCounts(result.droppedByReason, normalized.dropped);
          addCounts(result.rejectedByReason, normalized.rejected);
          const withChanges = await this.applyChanges(target.ref, normalized.bars, sessions);
          const { inserted, skipped } = await this.deps.marketData.insertBars(withChanges);
          result.bars.inserted += inserted;
          result.bars.duplicates += skipped;
          result.instruments.succeeded += 1;
        } catch (error) {
          const e = isAppError(error) ? error : new AppError('INTERNAL', error instanceof Error ? error.message : String(error));
          result.failures.push({ symbol: target.entry.symbol, providerSymbol: target.entry.providerSymbol, code: e.code, message: e.message });
          logger.warn({ symbol: target.entry.symbol, code: e.code }, 'market data sync failed for instrument');
        }
      });

      result.instruments.failed = result.failures.length;
      result.bars.dropped = sumValues(result.droppedByReason);
      result.bars.rejected = sumValues(result.rejectedByReason);
      result.status =
        result.instruments.total === 0 || result.instruments.succeeded === 0 ? 'FAILED'
        : result.failures.length > 0 || result.bars.rejected > 0 ? 'PARTIAL'
        : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.bars.fetched, inserted: result.bars.inserted,
          skipped: result.bars.duplicates + result.bars.dropped, failed: result.bars.rejected,
        },
        message: this.summary(result),
        ...(runError === undefined ? {} : { error: runError }),
        details: {
          failures: result.failures, rejected: result.rejectedByReason, dropped: result.droppedByReason,
          notes: result.notes, provider: provider.name, timeframe: request.timeframe,
        },
      });
    }
    logger.info({ runId, status: result.status, inserted: result.bars.inserted, failed: result.instruments.failed }, 'market data sync finished');
    return result;
  }

  private async resolveTargets(request: SyncRequest, exchanges: readonly Exchange[], result: SyncResult): Promise<Target[]> {
    let entries = await this.deps.providerSymbols.listByProvider(this.deps.provider.name, request.symbols);
    if (request.includeIndices === false) entries = entries.filter((e) => e.kind === 'stock');
    if (request.symbols) {
      const found = new Set(entries.map((e) => e.symbol));
      const missing = request.symbols.map((s) => s.toUpperCase()).filter((s) => !found.has(s));
      if (missing.length > 0) result.notes.push(`unknown or unmapped symbols for ${this.deps.provider.name}: ${missing.join(', ')}`);
    }
    const targets: Target[] = [];
    for (const entry of entries) {
      if (!exchanges.includes(entry.exchange)) {
        result.failures.push({ symbol: entry.symbol, providerSymbol: entry.providerSymbol, code: 'UNSUPPORTED', message: `${this.deps.provider.name} does not cover ${entry.exchange}` });
        continue;
      }
      const instrument = entry.kind === 'stock' ? await this.deps.stocks.findBySymbol(entry.symbol, entry.exchange) : await this.deps.markets.findBySymbol(entry.symbol);
      if (!instrument) continue;
      targets.push({
        entry,
        ref: entry.kind === 'stock' ? { kind: 'stock', id: instrument.id } : { kind: 'market', id: instrument.id },
        providerRef: { providerSymbol: entry.providerSymbol, exchange: entry.exchange, kind: entry.kind },
      });
    }
    return targets;
  }

  private async loadSessions(targets: Target[], from: Date, to: Date): Promise<Map<Exchange, Map<string, TradingSession | null>>> {
    const out = new Map<Exchange, Map<string, TradingSession | null>>();
    const last = toIst(to).date;
    for (const exchange of new Set(targets.map((t) => t.entry.exchange))) {
      const days = new Map<string, TradingSession | null>();
      for (let d = addDays(toIst(from).date, -PREV_CLOSE_LOOKBACK_DAYS); d <= last; d = addDays(d, 1)) {
        days.set(d, await this.deps.sessions.sessionOn(exchange, d));
      }
      out.set(exchange, days);
    }
    return out;
  }

  /** change / change_percent vs the previous session's daily close (stored or in this batch). */
  private async applyChanges(ref: InstrumentRef, bars: Bar[], sessions: Map<string, TradingSession | null>): Promise<Bar[]> {
    const first = bars[0];
    const last = bars[bars.length - 1];
    if (!first || !last) return bars;
    const stored = await this.deps.marketData.getBars(ref, this.deps.dataMode, '1d', new Date(first.ts.getTime() - PREV_CLOSE_LOOKBACK_DAYS * DAY_MS), last.ts);
    const dailies = [...stored, ...bars.filter((b) => b.timeframe === '1d')].sort((a, b) => a.ts.getTime() - b.ts.getTime());
    return bars.map((bar) => {
      const sessionOpen = sessions.get(toIst(bar.ts).date)?.open ?? bar.ts;
      let prev: number | null = null;
      for (const d of dailies) {
        if (d.ts.getTime() < sessionOpen.getTime()) prev = d.close;
        else break;
      }
      if (prev === null) return bar;
      const change = bar.close - prev;
      return { ...bar, change, changePercent: (change / prev) * 100 };
    });
  }

  private summary(r: SyncResult): string {
    const failed = r.failures.map((f) => `${f.symbol} (${f.code})`).join(', ');
    return `${r.instruments.succeeded}/${r.instruments.total} instruments ok; ${r.bars.inserted} inserted, ${r.bars.duplicates} duplicates, ` +
      `${r.bars.dropped} dropped, ${r.bars.rejected} rejected${failed ? `; failed: ${failed}` : ''}`;
  }
}
```
Note: `result.instruments.total` counts unsupported-exchange entries plus resolved targets. Concurrent workers mutate `result` counters, which is safe because JS is single-threaded between awaits.

- [ ] **Step 4: Run the gate.** Expected: PASS. If the exact counts differ because of seeded holidays (for example a non-trading day not anticipated), recompute from `exchange_holidays` and record a ruling. Do not loosen the assertions to `>`.
- [ ] **Step 5: Commit** `feat(backend): MarketDataService with validation, failure isolation, change calc and run logging`.

---

### Task 7: `none` providers, factory, container wiring, `pnpm sync:market` CLI

**Files:**
- Create: `backend/src/providers/factory.ts`, `backend/src/config/readConfig.ts`, `backend/src/cli/sync-market.ts`
- Modify:
  - `backend/src/config/env.ts` (`none` for news, fundamentals and llm)
  - `backend/src/container.ts`
  - `backend/src/server.ts` (use `readConfigOrExit`)
  - `backend/package.json` and root `package.json` (scripts)
- Test: `backend/tests/unit/config.test.ts` (new cases), `backend/tests/integration/container.test.ts`

**Interfaces:**
- Produces:
  - `createMarketDataProvider(config, deps: { sessions: TradingSessions }): MarketDataProvider`
  - `readConfigOrExit(env): AppConfig`
  - `Container.providers.marketData`, `Container.repositories.providerSymbols`, `Container.services.marketData`
  - `createContainer(config, overrides)` also accepts `marketDataProvider?`

- [ ] **Step 1: Write the failing tests.** Append to `backend/tests/unit/config.test.ts`:

```ts
  it("allows live market data with not-yet-built features disabled via 'none'", () => {
    const c = loadConfig({ MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo', NEWS_PROVIDER: 'none', FUNDAMENTALS_PROVIDER: 'none', LLM_PROVIDER: 'none' });
    expect(c.dataMode).toBe('LIVE');
    expect(c.providers).toEqual({ marketData: 'yahoo', news: 'none', fundamentals: 'none', llm: 'none' });
    expect(() => loadConfig({ MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'none' })).toThrow(/MARKET_DATA_PROVIDER/);
  });
```
`backend/tests/integration/container.test.ts`:
```ts
import { Writable } from 'node:stream';
import { describe, expect, it } from 'vitest';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createLogger } from '../../src/utils/logger.js';

const silent = createLogger({ level: 'silent', destination: new Writable({ write(_c, _e, cb) { cb(); } }) });

describe('container wiring', () => {
  it('uses the mock provider in mock mode and exposes the market data service', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.providers.marketData.name).toBe('mock');
    expect(c.services.marketData).toBeDefined();
    await c.close();
  });

  it('uses the Yahoo provider in live mode (no network at construction)', async () => {
    const c = createContainer(loadConfig({ MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'yahoo', NEWS_PROVIDER: 'none', FUNDAMENTALS_PROVIDER: 'none', LLM_PROVIDER: 'none' }), { logger: silent });
    expect(c.providers.marketData.name).toBe('yahoo');
    expect(c.providers.marketData.capabilities().latency).toBe('delayed');
    await c.close();
  });
});
```

- [ ] **Step 2: Run to verify they fail.** Expected: FAIL (`none` rejected; `providers` missing on the container).

- [ ] **Step 3: Implement**
  - In `env.ts`, change `NEWS_PROVIDER` to `z.enum(['mock', 'rss', 'newsapi', 'none'])`, `FUNDAMENTALS_PROVIDER` to `z.enum(['mock', 'yahoo', 'none'])` and `LLM_PROVIDER` to `z.enum(['mock', 'openai', 'none'])`. The `liveModeProblems` rules are unchanged (`none` is allowed in live mode; `mock` is not).
  - Update `.env.example` comments to list `none` for those three.

`backend/src/config/readConfig.ts` (and replace the local `readConfig` in `server.ts` with it):
```ts
import { type AppConfig, ConfigError, loadConfig } from './env.js';

/** Loads config or prints the problems and exits (process entrypoints only). */
export function readConfigOrExit(env: Record<string, string | undefined>): AppConfig {
  try {
    return loadConfig(env);
  } catch (error) {
    if (error instanceof ConfigError) {
      console.error(error.message);
      process.exit(1);
    }
    throw error;
  }
}
```
`backend/src/providers/factory.ts`:
```ts
import type { AppConfig } from '../config/env.js';
import type { TradingSessions } from '../domain/types.js';
import { createRateLimiter } from '../utils/rateLimiter.js';
import { MockMarketDataProvider } from './market/mock/MockMarketDataProvider.js';
import type { MarketDataProvider } from './market/types.js';
import { createYahooClient } from './market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from './market/yahoo/YahooMarketDataProvider.js';

/** The only place a market data adapter is chosen. Business code depends on MarketDataProvider. */
export function createMarketDataProvider(config: AppConfig, deps: { sessions: TradingSessions }): MarketDataProvider {
  switch (config.providers.marketData) {
    case 'mock':
      return new MockMarketDataProvider(deps.sessions);
    case 'yahoo':
      return new YahooMarketDataProvider(createYahooClient(), createRateLimiter({ ratePerSecond: 2, burst: 2 }));
  }
}
```
In `container.ts`:
- add `ProviderSymbolRepository` to `repositories.providerSymbols`
- add `providers: { marketData: MarketDataProvider }`, built from `overrides.marketDataProvider ?? createMarketDataProvider(config, { sessions: calendar })`
- add `services.marketData = new MarketDataService({ provider, providerSymbols, stocks, markets, marketData, systemLogs, sessions: calendar, dataMode: config.dataMode, logger })`
- add `marketDataProvider?: MarketDataProvider` to the overrides type

`backend/src/cli/sync-market.ts`:
```ts
import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { BAR_INTERVALS, type BarInterval } from '../domain/enums.js';

const DEFAULT_DAYS: Record<BarInterval, number> = { '1d': 1825, '15m': 5, '5m': 5, '1m': 2 };

function usage(message: string): never {
  console.error(`${message}\nUsage: pnpm sync:market [--timeframe 1d|5m|15m|1m] [--days N] [--symbols RELIANCE,TCS] [--no-indices] [--if-open]`);
  process.exit(2);
}

loadDotEnv();
const { values } = parseArgs({
  options: {
    timeframe: { type: 'string', default: '1d' },
    days: { type: 'string' },
    symbols: { type: 'string' },
    'no-indices': { type: 'boolean', default: false },
    'if-open': { type: 'boolean', default: false },
  },
});
const timeframe = values.timeframe;
if (!(BAR_INTERVALS as readonly string[]).includes(timeframe)) usage(`Unknown timeframe ${timeframe}`);
const tf = timeframe as BarInterval;
const days = values.days === undefined ? DEFAULT_DAYS[tf] : Number(values.days);
if (!Number.isFinite(days) || days <= 0) usage(`--days must be a positive number`);

const config = readConfigOrExit(process.env);
const container = createContainer(config);
try {
  const now = new Date();
  if (values['if-open'] && !(await container.services.calendar.isOpen('NSE', now))) {
    console.log('NSE is closed; nothing to sync (--if-open).');
  } else {
    const result = await container.services.marketData.sync({
      jobName: 'cli.sync-market', timeframe: tf, from: new Date(now.getTime() - days * 86_400_000), to: now,
      ...(values.symbols ? { symbols: values.symbols.split(',').map((s) => s.trim()).filter(Boolean) } : {}),
      includeIndices: !values['no-indices'],
    });
    console.log(`[${result.dataMode}] ${result.provider} ${result.timeframe} sync: ${result.status}`);
    console.log(`  instruments: ${result.instruments.succeeded}/${result.instruments.total} ok`);
    console.log(`  bars: fetched ${result.bars.fetched}, inserted ${result.bars.inserted}, duplicates ${result.bars.duplicates}, dropped ${result.bars.dropped}, rejected ${result.bars.rejected}`);
    for (const f of result.failures) console.log(`  FAILED ${f.symbol} (${f.providerSymbol}): ${f.code} ${f.message}`);
    for (const n of result.notes) console.log(`  note: ${n}`);
    process.exitCode = result.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
```
Scripts:
- `backend/package.json`: `"sync:market": "tsx src/cli/sync-market.ts"`
- root `package.json`: `"sync:market": "pnpm --filter @learning-stocks/backend sync:market"`

- [ ] **Step 4: Run the gate, then a real mock sync**

Run the gate. Expected: PASS.
Then run `pnpm db:reset && pnpm sync:market` (mock mode, 5 years daily). Expected: `SUCCESS`, 32/32 instruments, roughly 1,200 bars per instrument inserted. Re-run it: 0 inserted, all duplicates. Then `pnpm sync:market --timeframe 5m --days 5`. Expected: SUCCESS.

- [ ] **Step 5: Commit** `feat(backend): provider factory, container wiring, 'none' providers and sync:market CLI`.

---

### Task 8: Yahoo symbol verification, docs, Phase 3 verification

**Files:**
- Create: `backend/src/services/marketData/verifyProviderSymbols.ts`, `backend/src/cli/verify-provider-symbols.ts`
- Modify: `README.md`, `docs/architecture.md` (Providers section), `IMPLEMENTATION_PLAN.md` (Phase 3 ✅ + link), `backend/package.json` and root `package.json` (`verify:symbols`)
- Test: `backend/tests/integration/verifyProviderSymbols.test.ts`

**Interfaces:**
- Produces:
  - `VerificationOutcome { symbol; providerSymbol; kind; verified: boolean; dailyBars: number; reason: string }`
  - `verifyProviderSymbols({ provider, providerSymbols, now, minDailyBars = 200, symbols?, retry? }): Promise<VerificationOutcome[]>`

- [ ] **Step 1: Write the failing test** `backend/tests/integration/verifyProviderSymbols.test.ts`

```ts
import { afterAll, describe, expect, it } from 'vitest';
import type { MarketDataProvider, ProviderBar, ProviderInstrumentRef } from '../../src/providers/market/types.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { verifyProviderSymbols } from '../../src/services/marketData/verifyProviderSymbols.js';
import { AppError } from '../../src/utils/errors.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

const priced = (n: number): ProviderBar[] =>
  Array.from({ length: n }, (_, i) => ({ ts: new Date(Date.UTC(2025, 0, 1) + i * 86_400_000), open: 1, high: 1, low: 1, close: 1, adjustedClose: 1, volume: 0 }));

const fake: MarketDataProvider = {
  name: 'yahoo',
  capabilities: () => ({ exchanges: ['NSE', 'BSE'], intervals: ['1d'], latency: 'delayed', maxLookbackDays: {} }),
  getQuote: async () => { throw new Error('unused'); },
  async getHistorical(ref: ProviderInstrumentRef): Promise<ProviderBar[]> {
    if (ref.providerSymbol === 'RELIANCE.NS') return priced(250);
    if (ref.providerSymbol === '^CNXAUTO') return [...priced(1), { ts: new Date(), open: null, high: null, low: null, close: null, adjustedClose: null, volume: null }];
    throw new AppError('UNSUPPORTED', 'Yahoo has no data');
  },
};

describe('verifyProviderSymbols', () => {
  it('marks symbols with enough daily history verified and explains the rest', async () => {
    await withRollback(db, async (trx) => {
      const repo = new ProviderSymbolRepository(trx);
      const outcomes = await verifyProviderSymbols({ provider: fake, providerSymbols: repo, now: () => new Date('2026-10-05T12:00:00Z'), symbols: ['RELIANCE', 'NIFTYAUTO', 'TCS'] });
      expect(outcomes.map((o) => [o.symbol, o.verified, o.reason])).toEqual([
        ['RELIANCE', true, 'OK'],
        ['TCS', false, 'UNSUPPORTED: Yahoo has no data'],
        ['NIFTYAUTO', false, 'INSUFFICIENT_HISTORY (1 daily bars, need 200)'],
      ]);
      const flags = await repo.listByProvider('yahoo', ['RELIANCE', 'NIFTYAUTO', 'TCS']);
      expect(Object.fromEntries(flags.map((f) => [f.symbol, f.verified]))).toEqual({ RELIANCE: true, TCS: false, NIFTYAUTO: false });
    });
  });
});
```

- [ ] **Step 2: Run to verify it fails.** Expected: FAIL (module not found).

- [ ] **Step 3: Implement** `backend/src/services/marketData/verifyProviderSymbols.ts`

```ts
import type { MarketDataProvider } from '../../providers/market/types.js';
import type { ProviderSymbolRepository } from '../../repositories/ProviderSymbolRepository.js';
import { isAppError } from '../../utils/errors.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';

const LOOKBACK_DAYS = 400;

export interface VerificationOutcome {
  symbol: string;
  providerSymbol: string;
  kind: 'stock' | 'market';
  verified: boolean;
  dailyBars: number;
  reason: string;
}

/** A mapping is verified only if the provider returns enough real daily history (not just a snapshot). */
export async function verifyProviderSymbols(deps: {
  provider: MarketDataProvider;
  providerSymbols: ProviderSymbolRepository;
  now: () => Date;
  minDailyBars?: number;
  symbols?: readonly string[];
  retry?: RetryOptions;
}): Promise<VerificationOutcome[]> {
  const minBars = deps.minDailyBars ?? 200;
  const entries = await deps.providerSymbols.listByProvider(deps.provider.name, deps.symbols);
  const outcomes: VerificationOutcome[] = [];
  for (const entry of entries) {
    const now = deps.now();
    let dailyBars = 0;
    let reason: string;
    try {
      const bars = await withRetry(
        () => deps.provider.getHistorical({ providerSymbol: entry.providerSymbol, exchange: entry.exchange, kind: entry.kind },
          new Date(now.getTime() - LOOKBACK_DAYS * 86_400_000), now, '1d'),
        deps.retry,
      );
      dailyBars = bars.filter((b) => b.close !== null).length;
      reason = dailyBars >= minBars ? 'OK' : `INSUFFICIENT_HISTORY (${dailyBars} daily bars, need ${minBars})`;
    } catch (error) {
      reason = isAppError(error) ? `${error.code}: ${error.message}` : `INTERNAL: ${String(error)}`;
    }
    const verified = reason === 'OK';
    await deps.providerSymbols.setVerified(deps.provider.name, entry.providerSymbol, verified);
    outcomes.push({ symbol: entry.symbol, providerSymbol: entry.providerSymbol, kind: entry.kind, verified, dailyBars, reason });
  }
  return outcomes;
}
```
`backend/src/cli/verify-provider-symbols.ts`:
```ts
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { createRateLimiter } from '../utils/rateLimiter.js';
import { createYahooClient } from '../providers/market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from '../providers/market/yahoo/YahooMarketDataProvider.js';
import { verifyProviderSymbols } from '../services/marketData/verifyProviderSymbols.js';

// Verifies the yahoo ticker mappings against live Yahoo (network). Stores no market data.
loadDotEnv();
const container = createContainer(readConfigOrExit(process.env));
try {
  const provider = new YahooMarketDataProvider(createYahooClient(), createRateLimiter({ ratePerSecond: 2, burst: 2 }));
  const outcomes = await verifyProviderSymbols({ provider, providerSymbols: container.repositories.providerSymbols, now: () => new Date() });
  for (const o of outcomes) {
    console.log(`${o.verified ? 'OK  ' : 'FAIL'}  ${o.symbol.padEnd(16)} ${o.providerSymbol.padEnd(22)} ${String(o.dailyBars).padStart(4)} bars  ${o.reason}`);
  }
  const bad = outcomes.filter((o) => !o.verified).length;
  console.log(`\n${outcomes.length - bad}/${outcomes.length} yahoo mappings verified.`);
} finally {
  await container.close();
}
```
Scripts: `"verify:symbols": "tsx src/cli/verify-provider-symbols.ts"` in the backend package, and the same with `--filter` in the root package.

- [ ] **Step 4: Docs.**
  - **README:** a "Load market data" section covering `pnpm sync:market` (mock, 5 years daily), `--timeframe 5m --days 5`, `--symbols`, live Yahoo (`MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=none LLM_PROVIDER=none`), `pnpm verify:symbols`, `test:live`, and a known-limitation note on the six sector indices without Yahoo history. Update the Phase status table.
  - **`docs/architecture.md`:** a "Market data providers" section covering the interface, capabilities, the normalisation/validation rules table (drop vs reject reasons), complete-bars-only, change computation, run logging and the run-count semantics.
  - **IMPLEMENTATION_PLAN.md:** Phase 3 ✅ with a link to this plan file.

- [ ] **Step 5: Full verification**

```bash
pnpm db:reset && pnpm db:test
pnpm typecheck && pnpm test && pnpm lint && pnpm format:check && pnpm --filter @learning-stocks/backend build
pnpm --filter @learning-stocks/backend test:live
pnpm sync:market && pnpm sync:market            # second run: 0 inserted
pnpm sync:market --timeframe 5m --days 5
pnpm verify:symbols                             # expect ~26/32 verified; the 6 snapshot-only sector indices FAIL with INSUFFICIENT_HISTORY
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=none LLM_PROVIDER=none \
  pnpm sync:market --days 30 --symbols RELIANCE,TCS,NIFTY50,SENSEX
```
Expected:
- pgTAP 113/113, all backend tests green, the live test 2/2.
- The mock syncs succeed and the re-run is idempotent.
- The live Yahoo sync shows `[LIVE] yahoo 1d sync: SUCCESS` with about 20 bars per instrument.
- `curl /api/health` is still 200.
- `select data_mode, source, count(*) from market_data group by 1, 2` shows MOCK/mock and LIVE/yahoo rows kept apart.

- [ ] **Step 6: Commit** `feat(backend): Yahoo symbol verification CLI; docs; mark Phase 3 complete`. Then run the final fresh review, do one fix pass, and **stop for approval before Phase 4**.

---

## Verification (end of phase)

- **Automated:** typecheck, lint, format, build, plus unit and integration tests under TZ=UTC: limiter, concurrency, mock determinism and calendar alignment, Yahoo mapping and error taxonomy, every normalizer rule, repositories, the service (idempotency, changes, intraday completeness, failure isolation, clamping, FAILED/PARTIAL statuses), the container and factory, and symbol verification. pgTAP 113/113.
- **Live** (`test:live`): real NSE bars stamped 09:15 IST; an unknown symbol maps to UNSUPPORTED.
- **End to end:**
  - mock 5-year backfill plus 5m intraday load
  - an idempotent re-run
  - `verify:symbols` reports the six snapshot-only sector indices as unverified
  - a live Yahoo sync for 4 instruments stores LIVE rows alongside the MOCK rows, never mixed
  - `system_logs` holds one row per run with counts and failure details
