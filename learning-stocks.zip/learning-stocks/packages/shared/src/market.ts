import { z } from 'zod';
import {
  EXCHANGES,
  IMPACT_LEVELS,
  MARKET_REGIMES,
  MARKET_TYPES,
  RISK_LEVELS,
  SENTIMENTS,
  TRENDS,
} from '@learning-stocks/shared/enums';

const nnum = z.number().nullable();

/** An index card on the dashboard: NIFTY 50, SENSEX, BANK NIFTY, India VIX and the rest. */
export const MarketCardSchema = z.object({
  symbol: z.string(),
  name: z.string(),
  exchange: z.enum(EXCHANGES),
  market_type: z.enum(MARKET_TYPES),
  quote: z
    .object({
      ts: z.string(),
      price: z.number(),
      change: nnum,
      change_percent: nnum,
      volume: nnum,
      source: z.string(),
    })
    .nullable(),
});
export type MarketCard = z.infer<typeof MarketCardSchema>;

/**
 * Open/closed/holiday and the next open, in IST.
 *
 * `next_open` is nullable because the calendar can run out of loaded holidays; the UI says
 * "unknown" rather than inventing a date.
 */
export const MarketStatusSchema = z.object({
  exchange: z.enum(EXCHANGES),
  is_open: z.boolean(),
  phase: z.string(),
  holiday: z.string().nullable(),
  next_open: z.string().nullable(),
  as_of: z.string(),
});
export type MarketStatus = z.infer<typeof MarketStatusSchema>;

/** PRD §3.1's AI market sentiment panel. Null overall when no summary has been generated. */
export const MarketSummarySchema = z.looseObject({
  market: z.string(),
  analysis_time: z.string(),
  data_as_of: z.string(),
  sentiment: z.enum(SENTIMENTS).nullable(),
  sentiment_score: nnum,
  confidence: nnum,
  trend: z.enum(TRENDS).nullable(),
  regime: z.enum(MARKET_REGIMES).nullable(),
  risk_level: z.enum(RISK_LEVELS).nullable(),
  summary: z.string().nullable(),
  key_drivers: z.array(z.string()),
  key_risks: z.array(z.string()),
  sectors_positive: z.array(z.string()),
  sectors_negative: z.array(z.string()),
  model: z.string().nullable(),
});
export type MarketSummary = z.infer<typeof MarketSummarySchema>;

/**
 * An article in the dashboard's market-wide feed (PRD §3.1).
 *
 * The sentiment fields are nullable because `news_ai_analysis` is written by a separate job: an
 * unscored article still belongs in the feed, just without a badge.
 */
export const NewsItemSchema = z.object({
  title: z.string(),
  description: z.string().nullable(),
  source: z.string(),
  source_url: z.string().nullable(),
  published_at: z.string(),
  linked_symbols: z.array(z.string()),
  sentiment: z.enum(SENTIMENTS).nullable(),
  sentiment_score: nnum,
  impact_level: z.enum(IMPACT_LEVELS).nullable(),
});
export type NewsItem = z.infer<typeof NewsItemSchema>;
