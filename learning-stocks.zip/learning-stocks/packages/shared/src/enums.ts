/**
 * The enum values the API serves, copied VERBATIM from backend/src/domain/enums.ts.
 *
 * This package deliberately does not import from the backend — it is the dependency-free layer
 * both sides compile — so the copies are kept in step by backend/tests/unit/sharedEnums.test.ts
 * rather than by the type system. Never retype these from memory: a value that today's mock data
 * never produces would pass every test and then blank a panel on the one live row that carries it.
 *
 * Generated from the source file, not transcribed.
 */

export const EXCHANGES = ['NSE', 'BSE'] as const;
export const MARKET_TYPES = ['BROAD_INDEX', 'SECTOR_INDEX', 'VOLATILITY'] as const;
export const DATA_MODES = ['MOCK', 'LIVE'] as const;
export const BAR_INTERVALS = ['1m', '5m', '15m', '1d'] as const;
export const SENTIMENTS = ['BULLISH', 'NEUTRAL', 'BEARISH'] as const;
export const IMPACT_LEVELS = ['LOW', 'MEDIUM', 'HIGH'] as const;
export const TRENDS = ['UPTREND', 'SIDEWAYS', 'DOWNTREND'] as const;
export const RISK_LEVELS = ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'] as const;
export const RECOMMENDATION_BIASES = [
  'STRONG_BUY_BIAS',
  'BUY_BIAS',
  'HOLD_BIAS',
  'SELL_BIAS',
  'STRONG_SELL_BIAS',
] as const;
export const ACTION_STATES = [
  'BUY_ZONE',
  'WAIT_FOR_PULLBACK',
  'WAIT_FOR_CONFIRMATION',
  'HOLD',
  'REDUCE',
  'AVOID',
  'INSUFFICIENT_DATA',
] as const;
export const VALUATION_LABELS = ['UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA'] as const;
export const MARKET_REGIMES = ['RISK_ON', 'NEUTRAL', 'RISK_OFF'] as const;
export const TRADE_SIDES = ['BUY', 'SELL'] as const;
export const ORDER_STATUSES = ['PENDING', 'EXECUTED', 'REJECTED', 'CANCELLED'] as const;
export const ORDER_SOURCES = ['MANUAL', 'AI_SIGNAL'] as const;
export const SIGNAL_TYPES = ['BUY', 'SELL', 'HOLD'] as const;
export const SIGNAL_STATUSES = ['ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED'] as const;
export const PERIOD_TYPES = ['QUARTERLY', 'ANNUAL', 'TTM'] as const;
export const USER_ROLES = ['OWNER', 'ADMIN', 'VIEWER'] as const;
export const JOB_STATUSES = ['STARTED', 'SUCCESS', 'PARTIAL', 'FAILED', 'SKIPPED'] as const;
export const ANALYSIS_STATUSES = ['OK', 'FAILED', 'INSUFFICIENT_DATA'] as const;

export type Exchange = (typeof EXCHANGES)[number];
export type MarketType = (typeof MARKET_TYPES)[number];
export type DataMode = (typeof DATA_MODES)[number];
export type BarInterval = (typeof BAR_INTERVALS)[number];
export type Sentiment = (typeof SENTIMENTS)[number];
export type ImpactLevel = (typeof IMPACT_LEVELS)[number];
export type Trend = (typeof TRENDS)[number];
export type RiskLevel = (typeof RISK_LEVELS)[number];
export type RecommendationBias = (typeof RECOMMENDATION_BIASES)[number];
export type ActionState = (typeof ACTION_STATES)[number];
export type ValuationLabel = (typeof VALUATION_LABELS)[number];
export type MarketRegime = (typeof MARKET_REGIMES)[number];
export type TradeSide = (typeof TRADE_SIDES)[number];
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export type OrderSource = (typeof ORDER_SOURCES)[number];
export type SignalType = (typeof SIGNAL_TYPES)[number];
export type SignalStatus = (typeof SIGNAL_STATUSES)[number];
export type PeriodType = (typeof PERIOD_TYPES)[number];
export type UserRole = (typeof USER_ROLES)[number];
export type JobStatus = (typeof JOB_STATUSES)[number];
export type AnalysisStatus = (typeof ANALYSIS_STATUSES)[number];
