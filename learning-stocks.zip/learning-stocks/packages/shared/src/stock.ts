import { z } from 'zod';
import {
  ACTION_STATES,
  BAR_INTERVALS,
  EXCHANGES,
  RECOMMENDATION_BIASES,
  RISK_LEVELS,
  SENTIMENTS,
  SIGNAL_STATUSES,
  SIGNAL_TYPES,
  TRENDS,
  VALUATION_LABELS,
  MARKET_REGIMES,
  ANALYSIS_STATUSES,
  IMPACT_LEVELS,
} from '@learning-stocks/shared/enums';
import { FreshnessSchema, SourceSchema } from '@learning-stocks/shared/envelope';

/**
 * A number the API may not have.
 *
 * null is never coerced to 0 anywhere in this contract: "we do not have the P/E" and "the P/E is
 * zero" are different facts, and a research desk that conflates them lies to its reader.
 */
const nnum = z.number().nullable();

export const StockSchema = z.object({
  symbol: z.string(),
  company_name: z.string(),
  exchange: z.enum(EXCHANGES),
  isin: z.string().nullable(),
  isin_verified: z.boolean(),
  sector: z.string().nullable(),
  industry: z.string().nullable(),
  market_cap: nnum,
  currency: z.string(),
});
export type Stock = z.infer<typeof StockSchema>;

export const QuoteSchema = z.object({
  ts: z.string(),
  timeframe: z.enum(BAR_INTERVALS),
  price: z.number(),
  change: nnum,
  change_percent: nnum,
  volume: nnum,
  source: z.string(),
});
export type Quote = z.infer<typeof QuoteSchema>;

/** A bar as /history serves it. `vwap` is frequently null; it is kept, not dropped. */
export const BarSchema = z.object({
  ts: z.string(),
  timeframe: z.enum(BAR_INTERVALS),
  open: z.number(),
  high: z.number(),
  low: z.number(),
  close: z.number(),
  volume: nnum,
  change: nnum,
  change_percent: nnum,
  vwap: nnum,
  source: z.string(),
});

export const PERFORMANCE_WINDOWS = ['1d', '1w', '1m', '3m', '1y'] as const;

/**
 * Trailing returns in percent.
 *
 * Every window is nullable and null is load-bearing: a window that contains no price movement is
 * unmeasurable, and reporting 0 there renders as a flat trading day on a Sunday (Phase 9 I2).
 */
export const PerformanceSchema = z.object({
  '1d': nnum,
  '1w': nnum,
  '1m': nnum,
  '3m': nnum,
  '1y': nnum,
});
export type Performance = z.infer<typeof PerformanceSchema>;

/** The aggregate's trimmed indicator view. `looseObject`: the route may add indicators. */
export const AggregateTechnicalSchema = z.looseObject({
  ts: z.string(),
  technical_score: nnum,
  rsi_14: nnum,
  macd: nnum,
  macd_signal: nnum,
  sma_20: nnum,
  sma_50: nnum,
  sma_200: nnum,
  atr_14: nnum,
  adx_14: nnum,
  bollinger_upper: nnum,
  bollinger_lower: nnum,
});

/** The full indicator set from /stocks/:symbol/technical, which the panel renders. */
export const TechnicalSchema = z.object({
  symbol: z.string(),
  ts: z.string(),
  timeframe: z.string(),
  technical_score: nnum,
  indicators: z.looseObject({
    sma_20: nnum,
    sma_50: nnum,
    sma_200: nnum,
    ema_20: nnum,
    ema_50: nnum,
    ema_200: nnum,
    rsi_14: nnum,
    macd: nnum,
    macd_signal: nnum,
    macd_histogram: nnum,
    bollinger_upper: nnum,
    bollinger_middle: nnum,
    bollinger_lower: nnum,
    atr_14: nnum,
    adx_14: nnum,
    stoch_k: nnum,
    stoch_d: nnum,
    volume_sma_20: nnum,
  }),
});

/** 17 snapshot metrics plus as_of and source. Every metric stays present and nullable. */
export const FundamentalsSchema = z.object({
  as_of: z.string(),
  source: z.string(),
  market_cap: nnum,
  pe: nnum,
  pb: nnum,
  eps_ttm: nnum,
  roe: nnum,
  roce: nnum,
  debt_to_equity: nnum,
  dividend_yield: nnum,
  operating_margin: nnum,
  net_margin: nnum,
  free_cash_flow: nnum,
  revenue_ttm: nnum,
  net_profit_ttm: nnum,
  revenue_growth_yoy: nnum,
  profit_growth_yoy: nnum,
  book_value_per_share: nnum,
  beta: nnum,
});
export type Fundamentals = z.infer<typeof FundamentalsSchema>;

export const ValuationSchema = z.object({
  label: z.enum(VALUATION_LABELS),
  valuation_score: nnum,
  quality_score: nnum,
});

/** PRD §3.2's decision card: the deterministic call, its levels and what would invalidate it. */
export const DecisionSchema = z.object({
  evaluated_at: z.string(),
  data_as_of: z.string(),
  scoring_config_version: z.string(),
  action_state: z.enum(ACTION_STATES),
  recommendation_bias: z.enum(RECOMMENDATION_BIASES),
  trend: z.enum(TRENDS),
  risk_level: z.enum(RISK_LEVELS),
  market_regime: z.enum(MARKET_REGIMES).nullable(),
  overall_score: nnum,
  risk_score: nnum,
  coverage: nnum,
  entry_low: nnum,
  entry_high: nnum,
  stop_loss: nnum,
  target_1: nnum,
  target_2: nnum,
  risk_reward: nnum,
  position_size_hint: nnum,
  invalidation: z.string().nullable(),
});
export type Decision = z.infer<typeof DecisionSchema>;

export const NewsArticleSchema = z.looseObject({
  title: z.string(),
  source: z.string(),
  source_url: z.string().nullable(),
  published_at: z.string(),
  relevance: nnum,
});

export const SentimentSchema = z.object({
  window_days: z.number(),
  article_count: z.number(),
  average_sentiment_score: nnum,
});

export const AnalysisFactSchema = z.looseObject({
  statement: z.string(),
  source_ids: z.array(z.string()),
});

/**
 * The AI analysis, as PRD §9.4 requires it to be explainable: facts separated from
 * interpretation, citations, what it lacked, and which model said it.
 */
export const AnalysisSchema = z.looseObject({
  analysis_time: z.string(),
  status: z.enum(ANALYSIS_STATUSES),
  sentiment: z.enum(SENTIMENTS).nullable(),
  sentiment_score: nnum,
  confidence: nnum,
  trend: z.enum(TRENDS).nullable(),
  risk_level: z.enum(RISK_LEVELS).nullable(),
  recommendation: z.enum(RECOMMENDATION_BIASES).nullable(),
  summary: z.string().nullable(),
  reasoning: z.array(z.string()),
  key_positive_factors: z.array(z.string()),
  key_negative_factors: z.array(z.string()),
  key_risks: z.array(z.string()),
  catalysts: z.array(z.string()),
  facts: z.array(AnalysisFactSchema),
  interpretation: z.array(z.string()),
  insufficient_data: z.array(z.string()),
  sources: z.array(SourceSchema),
  model: z.string().nullable(),
});
export type Analysis = z.infer<typeof AnalysisSchema>;

export const SignalSchema = z.object({
  id: z.string(),
  signal: z.enum(SIGNAL_TYPES),
  confidence: nnum,
  entry_low: nnum,
  entry_high: nnum,
  stop_loss: nnum,
  target_price: nnum,
  target_2: nnum,
  suggested_quantity: nnum,
  valid_until: z.string(),
  status: z.enum(SIGNAL_STATUSES),
  /** Always true: no job and no route places an order (PRD §1, §11). */
  requires_manual_action: z.literal(true),
});
export type Signal = z.infer<typeof SignalSchema>;

export const MarketContextSchema = z.looseObject({
  market: z.string(),
  sentiment: z.enum(SENTIMENTS).nullable(),
  sentiment_score: nnum,
  regime: z.enum(MARKET_REGIMES).nullable(),
  trend: z.enum(TRENDS).nullable(),
  risk_level: z.enum(RISK_LEVELS).nullable(),
  summary: z.string().nullable(),
  analysis_time: z.string(),
});

/**
 * The whole decision for one stock in one response: 13 sections, each independently nullable.
 *
 * Nullability is the contract, not defensive typing: PRD §17 requires a stock with no
 * fundamentals, no news or no analysis to render rather than fail.
 */
export const StockAggregateSchema = z.object({
  stock: StockSchema,
  quote: QuoteSchema.nullable(),
  performance: PerformanceSchema,
  technical: AggregateTechnicalSchema.nullable(),
  fundamental: FundamentalsSchema.nullable(),
  valuation: ValuationSchema.nullable(),
  decision: DecisionSchema.nullable(),
  news: z.array(NewsArticleSchema),
  sentiment: SentimentSchema.nullable(),
  ai_analysis: AnalysisSchema.nullable(),
  signal: SignalSchema.nullable(),
  market_context: MarketContextSchema.nullable(),
  data_freshness: z.record(z.string(), FreshnessSchema),
});
export type StockAggregate = z.infer<typeof StockAggregateSchema>;

/** A row of the dashboard's "Worth Considering" table (PRD §3.1). */
export const StockListRowSchema = z.looseObject({
  symbol: z.string(),
  company_name: z.string(),
  exchange: z.enum(EXCHANGES),
  isin: z.string().nullable(),
  isin_verified: z.boolean(),
  sector: z.string().nullable(),
  industry: z.string().nullable(),
  market_cap: nnum,
  currency: z.string(),
  evaluation: z
    .object({
      action_state: z.enum(ACTION_STATES),
      recommendation_bias: z.enum(RECOMMENDATION_BIASES),
      overall_score: nnum,
      risk_level: z.enum(RISK_LEVELS),
      evaluated_at: z.string(),
    })
    .nullable(),
  // Every one nullable, and null means "not evaluated", never "scored zero".
  quote: z.object({ price: z.number(), change_percent: nnum, ts: z.string() }).nullable(),
  valuation_label: z.enum(VALUATION_LABELS).nullable(),
  risk_reward: nnum,
  sentiment_score: nnum,
  scores: z
    .object({
      technical: nnum,
      quality: nnum,
      valuation: nnum,
      news: nnum,
      momentum: nnum,
    })
    .nullable(),
});
export type StockListRow = z.infer<typeof StockListRowSchema>;

/** One overlay point per bar. `value: null` is a hole, which keeps the line aligned. */
export const IndicatorPointSchema = z.object({ ts: z.string(), value: nnum });

export const HistorySchema = z.object({
  symbol: z.string(),
  range: z.string(),
  interval: z.enum(BAR_INTERVALS),
  bars: z.array(BarSchema),
  /** Aligned 1:1 with `bars`, or empty for an intraday range (indicators are computed daily). */
  indicators: z.object({
    sma_20: z.array(IndicatorPointSchema),
    sma_50: z.array(IndicatorPointSchema),
    sma_200: z.array(IndicatorPointSchema),
  }),
});
export type History = z.infer<typeof HistorySchema>;

export const EvaluationSchema = z.object({
  symbol: z.string(),
  evaluated_at: z.string(),
  data_as_of: z.string(),
  scoring_config_version: z.string(),
  action_state: z.enum(ACTION_STATES),
  recommendation_bias: z.enum(RECOMMENDATION_BIASES),
  trend: z.enum(TRENDS),
  valuation_label: z.enum(VALUATION_LABELS),
  market_regime: z.enum(MARKET_REGIMES).nullable(),
  risk_level: z.enum(RISK_LEVELS),
  scores: z.looseObject({
    technical: nnum,
    quality: nnum,
    valuation: nnum,
    news: nnum,
    momentum: nnum,
    market_context: nnum,
    overall: nnum,
    risk: nnum,
  }),
  coverage: nnum,
  levels: z.looseObject({
    entry_low: nnum,
    entry_high: nnum,
    stop_loss: nnum,
    target_1: nnum,
    target_2: nnum,
    risk_reward: nnum,
    position_size_hint: nnum,
  }),
  invalidation: z.string().nullable(),
});

/** /stocks/:symbol/news. Task 2 adds per-article sentiment, impact and the AI summary. */
export const StockNewsSchema = z.object({
  symbol: z.string(),
  articles: z.array(
    z.looseObject({
      title: z.string(),
      description: z.string().nullable(),
      source: z.string(),
      source_url: z.string().nullable(),
      published_at: z.string(),
      relevance: nnum,
      matched_by: z.string().nullable(),
      sentiment: z.enum(SENTIMENTS).nullable().optional(),
      sentiment_score: nnum.optional(),
      impact_level: z.enum(IMPACT_LEVELS).nullable().optional(),
      ai_summary: z.string().nullable().optional(),
    }),
  ),
});

export const StockSentimentSchema = z.object({
  symbol: z.string(),
  window_days: z.number(),
  article_count: z.number(),
  average_sentiment_score: nnum,
});
