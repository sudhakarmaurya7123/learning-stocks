import { z } from 'zod';
import { DATA_MODES, EXCHANGES } from '@learning-stocks/shared/enums';

const nnum = z.number().nullable();

export const FailedJobSchema = z.object({
  job_name: z.string(),
  service: z.string(),
  started_at: z.string().nullable(),
  message: z.string().nullable(),
});

export const WorkerSchema = z.object({
  /**
   * `unknown` is not an error: a process with no queue (a CLI) cannot tell. The admin page must
   * distinguish it from `down`, because a 202 from a sync route promises nothing without a worker.
   */
  status: z.enum(['live', 'stale', 'down', 'unknown']),
  live: z.number(),
  last_heartbeat: z.string().nullable(),
});

export const LlmBudgetSchema = z.object({
  daily_budget_inr: z.number(),
  spent_today_inr: z.number(),
  remaining_inr: z.number(),
  exhausted: z.boolean(),
});

/** Per-job last run, for the admin page's cron table (PRD §3.4). Added by Task 2. */
export const JobRunSchema = z.object({
  job_name: z.string(),
  service: z.string(),
  status: z.string(),
  records_processed: nnum,
  duration_ms: nnum,
  started_at: z.string().nullable(),
  finished_at: z.string().nullable(),
  message: z.string().nullable(),
});
export type JobRun = z.infer<typeof JobRunSchema>;

/** Today's LLM spend against the daily cap (PRD §3.4, §14). Added by Task 2. */
export const LlmSpendSchema = z.object({
  calls_today: z.number(),
  input_tokens: z.number(),
  output_tokens: z.number(),
  spent_inr: z.number(),
  budget_inr: z.number(),
  cache_hits: z.number(),
});
export type LlmSpend = z.infer<typeof LlmSpendSchema>;

/**
 * PRD §16's status payload.
 *
 * Every field is nullable where the underlying read can degrade: this page is most needed when
 * something is broken, so it answers 200 with nulls rather than 500 (Phase 9 finding I1).
 */
export const SystemStatusSchema = z.looseObject({
  data_mode: z.enum(DATA_MODES),
  database_status: z.enum(['up', 'down']),
  market_data_provider: z.string(),
  news_provider: z.string(),
  fundamentals_provider: z.string(),
  llm_provider: z.string(),
  auth_mode: z.enum(['jwt', 'none']),
  last_market_sync: z.string().nullable(),
  last_news_sync: z.string().nullable(),
  last_fundamentals_sync: z.string().nullable(),
  last_evaluation: z.string().nullable(),
  last_ai_analysis: z.string().nullable(),
  failed_jobs: z.array(FailedJobSchema),
  market_status: z
    .object({
      exchange: z.enum(EXCHANGES),
      is_open: z.boolean(),
      phase: z.string(),
      holiday: z.string().nullable(),
      next_open: z.string().nullable(),
    })
    .nullable(),
  llm_budget: LlmBudgetSchema.nullable(),
  /** One row per job, newest run (PRD §3.4's cron table). */
  jobs: z.array(JobRunSchema),
  llm_spend: LlmSpendSchema,
  worker: WorkerSchema,
  generated_at: z.string(),
});
export type SystemStatus = z.infer<typeof SystemStatusSchema>;

/** The answer from POST /stocks/:symbol/qa. */
export const QaAnswerSchema = z.looseObject({
  symbol: z.string(),
  question: z.string().optional(),
  answer: z.string().nullable(),
  sources: z.array(
    z.looseObject({
      id: z.string(),
      url: z.string().nullable(),
      as_of: z.string().nullable(),
      kind: z.string(),
      title: z.string().nullable(),
    }),
  ),
  insufficient_data: z.array(z.string()),
});
export type QaAnswer = z.infer<typeof QaAnswerSchema>;
