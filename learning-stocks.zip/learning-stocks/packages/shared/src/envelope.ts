import { z } from 'zod';
import { DATA_MODES } from '@learning-stocks/shared/enums';

/**
 * How old the newest stored fact behind a response is, and whether that is a problem (PRD §12).
 *
 * `cadence` says which threshold judged `stale`, so the UI can explain a badge rather than just
 * colour it. It is optional because a caller that predates it simply omits it.
 */
export const FreshnessSchema = z.object({
  as_of: z.string().nullable(),
  age_seconds: z.number().nullable(),
  stale: z.boolean(),
  market_open: z.boolean(),
  cadence: z.enum(['quote', 'daily']).optional(),
});
export type Freshness = z.infer<typeof FreshnessSchema>;

export const MetaSchema = z.object({
  data_mode: z.enum(DATA_MODES),
  generated_at: z.string(),
  freshness: FreshnessSchema.optional(),
});
export type Meta = z.infer<typeof MetaSchema>;

/** Every successful response. Generic so each route states its own payload. */
export const EnvelopeSchema = <T extends z.ZodType>(data: T) =>
  z.object({ data, meta: MetaSchema });

export const ERROR_CODES = [
  'VALIDATION',
  'UNAUTHORIZED',
  'FORBIDDEN',
  'NOT_FOUND',
  'RATE_LIMITED',
  'BUDGET_EXCEEDED',
  'UNSUPPORTED',
  'INTERNAL',
] as const;

export const ApiErrorSchema = z.object({
  error: z.object({
    code: z.enum(ERROR_CODES),
    message: z.string(),
    details: z.record(z.string(), z.unknown()).optional(),
  }),
});
export type ApiError = z.infer<typeof ApiErrorSchema>;

/**
 * A 202 from a sync or job route.
 *
 * `job_id: null` with `already_queued: true` means a run was already queued — the queue working
 * as intended, not a lost request. The UI must say so, because a bare null reads as a failure.
 */
export const ActionAcceptedSchema = z.object({
  job: z.string(),
  job_id: z.string().nullable(),
  already_queued: z.boolean(),
});
export type ActionAccepted = z.infer<typeof ActionAcceptedSchema>;

/** A citation on an AI output. snake_case on the wire, whatever the stored jsonb uses. */
export const SourceSchema = z.object({
  id: z.string(),
  url: z.string().nullable(),
  as_of: z.string().nullable(),
  kind: z.string(),
  title: z.string().nullable(),
});
export type Source = z.infer<typeof SourceSchema>;
