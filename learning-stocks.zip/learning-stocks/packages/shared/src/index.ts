/**
 * The API contract, shared by the backend that serves it and the browser that renders it.
 *
 * The browser parses every response through these schemas, and
 * backend/tests/integration/contract.test.ts parses real responses through the same ones. A field
 * rename therefore breaks a test rather than silently rendering `undefined` on a panel.
 *
 * No I/O, no secrets, no backend imports: both toolchains compile this source directly.
 * Modules here reference each other BY PACKAGE NAME, never by a relative path — the backend's
 * NodeNext resolution requires a `.js` suffix that Next's Turbopack rejects, and self-referencing
 * package imports are the only form both accept.
 */
export * from '@learning-stocks/shared/enums';
export * from '@learning-stocks/shared/envelope';
export * from '@learning-stocks/shared/market';
export * from '@learning-stocks/shared/stock';
export * from '@learning-stocks/shared/admin';
