import { describe, expect, it } from 'vitest';
import type { Gate } from '../../src/jobs/gates.js';
import { runJob } from '../../src/jobs/runJob.js';
import type { JobPayload, JobQueue } from '../../src/jobs/types.js';
import { silentUnitLogger } from '../fixtures/silentLogger.js';

const noopQueue: JobQueue = {
  start: async () => undefined,
  stop: async () => undefined,
  ensureQueues: async () => undefined,
  applySchedules: async () => undefined,
  work: async () => undefined,
  enqueue: async () => null,
};

/** A systemLogs stand-in: runJob only needs to open and close a row. */
const logs = () => {
  const rows: Array<{ status: string; message: string }> = [];
  return {
    rows,
    repo: {
      startRun: async () => 'run-1',
      finishRun: async (_id: string, r: { status: string; message?: string }) => {
        rows.push({ status: r.status, message: r.message ?? '' });
      },
      amendRun: async () => undefined,
    },
  };
};

const run = async (gate: Gate, payload: JobPayload) => {
  const { repo } = logs();
  return runJob({
    definition: {
      name: 'market.sync.eod',
      gate,
      run: async () => ({ status: 'SUCCESS', runId: null, message: 'ran', next: [] }),
    },
    payload,
    queue: noopQueue,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    systemLogs: repo as any,
    logger: silentUnitLogger,
    now: () => new Date('2026-10-10T06:00:00Z'),
  });
};

const calendarGate: Gate = async () => ({
  run: false,
  kind: 'calendar',
  reason: 'NSE is closed all day on 2026-10-10 (IST)',
});
const availabilityGate: Gate = async () => ({
  run: false,
  kind: 'availability',
  reason: 'news provider is disabled',
});

describe('manual triggers and gate kinds', () => {
  it('manual bypasses a calendar refusal, so a Saturday "Sync Market" does something', async () => {
    expect(await run(calendarGate, { manual: true })).toMatchObject({ status: 'SUCCESS' });
  });

  it('a scheduled run still respects the calendar', async () => {
    expect(await run(calendarGate, {})).toMatchObject({ status: 'SKIPPED' });
  });

  it('manual never bypasses an availability refusal', async () => {
    // A provider that is switched off cannot be forced into existence.
    expect(await run(availabilityGate, { manual: true })).toMatchObject({ status: 'SKIPPED' });
  });

  it('force is not a calendar bypass', async () => {
    // force belongs to the AI services' hash cache (POST /ai/regenerate). If it also bypassed
    // gates, one click on POST /jobs/ai.stock.analyze/run would force-regenerate every stock.
    expect(await run(calendarGate, { force: true })).toMatchObject({ status: 'SKIPPED' });
  });
});
