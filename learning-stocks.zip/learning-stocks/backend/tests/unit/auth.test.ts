import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { verifyToken } from '../../src/http/auth.js';

const SECRET_TEXT = 'super-secret-jwt-token-with-at-least-32-characters-long';
const SECRET = new TextEncoder().encode(SECRET_TEXT);
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const opts = { secret: SECRET_TEXT, issuer: ISSUER, audience: 'authenticated', jwksUrl: null };

const sign = (claims: Record<string, unknown>, exp = '1h') =>
  new SignJWT(claims)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(ISSUER)
    .setAudience('authenticated')
    .setIssuedAt()
    .setExpirationTime(exp)
    .sign(SECRET);

describe('verifyToken', () => {
  it('accepts a Supabase-shaped token and returns the subject', async () => {
    const token = await sign({ sub: 'u-1', role: 'authenticated', email: 'owner@example.com' });
    await expect(verifyToken(token, opts)).resolves.toEqual({
      sub: 'u-1',
      email: 'owner@example.com',
    });
  });

  it('rejects an expired token, a forged signature, and alg=none', async () => {
    const expired = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER)
      .setAudience('authenticated')
      .setIssuedAt(0)
      .setExpirationTime(1)
      .sign(SECRET);
    await expect(verifyToken(expired, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });

    const forged = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER)
      .setAudience('authenticated')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(new TextEncoder().encode('x'.repeat(48)));
    await expect(verifyToken(forged, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });

    // alg: none is the classic confusion attack: a token with no signature at all.
    const none = 'eyJhbGciOiJub25lIn0.eyJzdWIiOiJoYWNrZXIifQ.';
    await expect(verifyToken(none, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });

  it('rejects a token issued by someone else, or for another audience', async () => {
    const otherIssuer = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer('https://evil.example.com')
      .setAudience('authenticated')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(SECRET);
    await expect(verifyToken(otherIssuer, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });

    const otherAudience = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER)
      .setAudience('anon')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(SECRET);
    await expect(verifyToken(otherAudience, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });

  it('rejects a token with no subject', async () => {
    const noSub = await sign({ role: 'authenticated' });
    await expect(verifyToken(noSub, opts)).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });
});

describe('token failures are not an oracle', () => {
  it('tells an expired token and a forged one apart only in the logs', async () => {
    // errorBody serializes AppError.details, so a `reason` there would reach the client and say
    // whether the signature was the only thing wrong.
    const expired = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER)
      .setAudience('authenticated')
      .setIssuedAt(0)
      .setExpirationTime(1)
      .sign(SECRET);
    const forged = await new SignJWT({ sub: 'u-1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER)
      .setAudience('authenticated')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(new TextEncoder().encode('x'.repeat(48)));

    const reasons = await Promise.all(
      [expired, forged].map((token) =>
        verifyToken(token, opts).then(
          () => null,
          (error: unknown) => ({
            message: (error as { message: string }).message,
            details: (error as { details?: unknown }).details,
          }),
        ),
      ),
    );
    // Identical, and carrying nothing that distinguishes them.
    expect(reasons[0]).toEqual(reasons[1]);
    expect(reasons[0]?.details).toBeUndefined();
  });
});
