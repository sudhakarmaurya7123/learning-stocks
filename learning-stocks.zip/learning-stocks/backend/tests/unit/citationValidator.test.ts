import { describe, expect, it } from 'vitest';
import { validateCitations } from '../../src/rag/citationValidator.js';

const issued = new Set(['Q1', 'E1', 'N1', 'N2']);

describe('validateCitations', () => {
  it('accepts facts citing issued IDs (bracketed or bare)', () => {
    expect(
      validateCitations(
        { facts: [{ statement: 'Price fell', source_ids: ['Q1', '[N2]'] }] },
        issued,
      ),
    ).toEqual({
      valid: true,
      unknownIds: [],
      uncitedFacts: [],
    });
  });

  it('rejects IDs that were never issued, in source_ids or inline in any text', () => {
    const r = validateCitations(
      {
        facts: [{ statement: 'Margins improved [F1]', source_ids: ['N9'] }],
        texts: ['As [E1] and [T1] show'],
      },
      issued,
    );
    expect(r).toEqual({ valid: false, unknownIds: ['F1', 'N9', 'T1'], uncitedFacts: [] });
  });

  it('flags facts without citations without rejecting the output', () => {
    expect(
      validateCitations({ facts: [{ statement: 'Sector looks strong', source_ids: [] }] }, issued),
    ).toEqual({
      valid: true,
      unknownIds: [],
      uncitedFacts: ['Sector looks strong'],
    });
  });

  it('checks every ID inside a combined bracket', () => {
    const r = validateCitations({ facts: [], texts: ['Both [N1, X9] and [E1,N2] agree'] }, issued);
    expect(r).toMatchObject({ valid: false, unknownIds: ['X9'] });
  });
});
