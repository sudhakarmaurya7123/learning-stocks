import { describe, expect, it } from 'vitest';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';

const NOW = () => new Date('2026-10-05T20:00:00Z'); // IST 2026-10-06
const ref = (symbol: string) => ({
  providerSymbol: symbol,
  exchange: 'NSE' as const,
  kind: 'stock' as const,
});
const priced = () => new MockFundamentalsProvider(async () => 1000, NOW);

describe('MockFundamentalsProvider', () => {
  it('is deterministic and labelled mock', async () => {
    const a = await priced().getSnapshot(ref('RELIANCE'));
    expect(await priced().getSnapshot(ref('RELIANCE'))).toEqual(a);
    expect(a).toMatchObject({ reportingCurrency: 'INR', raw: { mock: true } });
  });

  it('reports 8 quarters (45-day results lag) and 5 fiscal years ending 31 March', async () => {
    const q = await priced().getStatements(ref('RELIANCE'), 'QUARTERLY');
    expect(q.statements.map((s) => s.periodEnd)).toEqual([
      '2024-09-30',
      '2024-12-31',
      '2025-03-31',
      '2025-06-30',
      '2025-09-30',
      '2025-12-31',
      '2026-03-31',
      '2026-06-30',
    ]);
    const a = await priced().getStatements(ref('RELIANCE'), 'ANNUAL');
    expect(a.statements.map((s) => s.periodEnd)).toEqual([
      '2022-03-31',
      '2023-03-31',
      '2024-03-31',
      '2025-03-31',
      '2026-03-31',
    ]);
  });

  it('keeps snapshot, quarters and years internally consistent', async () => {
    const p = priced();
    const snap = await p.getSnapshot(ref('RELIANCE'));
    const quarters = (await p.getStatements(ref('RELIANCE'), 'QUARTERLY')).statements;
    const years = (await p.getStatements(ref('RELIANCE'), 'ANNUAL')).statements;
    const last4 = quarters.slice(-4);
    const total = (rows: typeof quarters, f: 'revenue' | 'eps') =>
      rows.reduce((s, r) => s + (r.metrics[f] ?? 0), 0);
    expect(snap.metrics.revenueTtm).toBeCloseTo(total(last4, 'revenue'), 0);
    expect((snap.metrics.pe ?? 0) * (snap.metrics.epsTtm ?? 0)).toBeCloseTo(1000, 6);
    const fy26Quarters = quarters.filter(
      (s) => s.periodEnd > '2025-03-31' && s.periodEnd <= '2026-03-31',
    );
    expect(years.at(-1)?.metrics.revenue).toBeCloseTo(total(fy26Quarters, 'revenue'), 0);
  });

  it('leaves leverage ratios empty for banks and price ratios empty without a price', async () => {
    const bank = await priced().getSnapshot(ref('HDFCBANK'));
    expect(bank.metrics).toMatchObject({ debtToEquity: null, roce: null });
    expect((await priced().getSnapshot(ref('RELIANCE'))).metrics.debtToEquity).toBeGreaterThan(0);
    const unpriced = await new MockFundamentalsProvider(async () => null, NOW).getSnapshot(
      ref('RELIANCE'),
    );
    expect(unpriced.metrics).toMatchObject({ pe: null, pb: null, marketCap: null });
  });
});
