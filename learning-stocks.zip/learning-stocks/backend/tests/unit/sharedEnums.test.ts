import { describe, expect, it } from 'vitest';
import * as shared from '@learning-stocks/shared';
import * as domain from '../../src/domain/enums.js';

/**
 * `packages/shared` must not import from the backend — it is the dependency-free layer both sides
 * compile — so the two copies of each enum are kept in step by this test instead of by the type
 * system.
 *
 * A value present in the domain but missing from the schema throws ApiFailure('CONTRACT') in the
 * browser and blanks the panel, and only for the rows that happen to carry it: mock data would
 * never reveal it. Writing these from memory already produced four wrong arrays once
 * (RISK_LEVELS really has four values; the action states are BUY_ZONE/WAIT_FOR_CONFIRMATION).
 */
describe('the shared contract enums match the domain enums', () => {
  it.each([
    ['EXCHANGES', shared.EXCHANGES, domain.EXCHANGES],
    ['DATA_MODES', shared.DATA_MODES, domain.DATA_MODES],
    ['MARKET_TYPES', shared.MARKET_TYPES, domain.MARKET_TYPES],
    ['BAR_INTERVALS', shared.BAR_INTERVALS, domain.BAR_INTERVALS],
    ['ACTION_STATES', shared.ACTION_STATES, domain.ACTION_STATES],
    ['RECOMMENDATION_BIASES', shared.RECOMMENDATION_BIASES, domain.RECOMMENDATION_BIASES],
    ['RISK_LEVELS', shared.RISK_LEVELS, domain.RISK_LEVELS],
    ['SENTIMENTS', shared.SENTIMENTS, domain.SENTIMENTS],
    ['TRENDS', shared.TRENDS, domain.TRENDS],
    ['IMPACT_LEVELS', shared.IMPACT_LEVELS, domain.IMPACT_LEVELS],
    ['VALUATION_LABELS', shared.VALUATION_LABELS, domain.VALUATION_LABELS],
    ['MARKET_REGIMES', shared.MARKET_REGIMES, domain.MARKET_REGIMES],
    ['SIGNAL_STATUSES', shared.SIGNAL_STATUSES, domain.SIGNAL_STATUSES],
    ['SIGNAL_TYPES', shared.SIGNAL_TYPES, domain.SIGNAL_TYPES],
    ['USER_ROLES', shared.USER_ROLES, domain.USER_ROLES],
  ])('%s', (_name, fromShared, fromDomain) => {
    expect([...fromShared]).toEqual([...fromDomain]);
  });
});
