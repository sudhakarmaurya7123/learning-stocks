import { describe, expect, it } from 'vitest';
import type { TradingSession } from '../../src/domain/types.js';
import type { ProviderBar } from '../../src/providers/market/types.js';
import {
  normalizeBars,
  type NormalizeContext,
} from '../../src/services/marketData/barNormalizer.js';

const SESSIONS: Record<string, TradingSession> = {
  '2026-10-05': { open: new Date('2026-10-05T03:45:00Z'), close: new Date('2026-10-05T10:00:00Z') },
  '2026-10-06': { open: new Date('2026-10-06T03:45:00Z'), close: new Date('2026-10-06T10:00:00Z') },
};
const ctx = (over: Partial<NormalizeContext> = {}): NormalizeContext => ({
  instrument: { kind: 'stock', id: 'stock-1' },
  dataMode: 'LIVE',
  source: 'yahoo',
  timeframe: '1d',
  now: new Date('2026-10-06T12:00:00Z'),
  sessionFor: (d) => SESSIONS[d] ?? null,
  ...over,
});
const bar = (
  ts: string,
  o: number | null,
  h: number | null,
  l: number | null,
  c: number | null,
  v: number | null = 100,
): ProviderBar => ({
  ts: new Date(ts),
  open: o,
  high: h,
  low: l,
  close: c,
  adjustedClose: c,
  volume: v,
});

describe('normalizeBars', () => {
  it('normalises odd daily stamps to the session open and tags mode/source', () => {
    const r = normalizeBars([bar('2026-10-05T10:01:29Z', 100, 105, 99, 104)], ctx());
    expect(r.bars).toHaveLength(1);
    expect(r.bars[0]).toMatchObject({
      ts: new Date('2026-10-05T03:45:00Z'),
      dataMode: 'LIVE',
      source: 'yahoo',
      timeframe: '1d',
      close: 104,
      volume: 100,
      change: null,
    });
  });

  it('drops empty (null) bars and in-progress daily bars until close + settle', () => {
    const r = normalizeBars(
      [
        bar('2026-10-05T03:45:00Z', null, null, null, null, 0),
        bar('2026-10-06T03:45:00Z', 100, 105, 99, 104),
      ],
      ctx({ now: new Date('2026-10-06T10:10:00Z') }),
    );
    expect(r.bars).toEqual([]);
    expect(r.dropped).toEqual({ EMPTY: 1, INCOMPLETE: 1 });
    const settled = normalizeBars(
      [bar('2026-10-06T03:45:00Z', 100, 105, 99, 104)],
      ctx({ now: new Date('2026-10-06T10:30:00Z') }),
    );
    expect(settled.bars).toHaveLength(1);
  });

  it('rejects invalid prices, inconsistent OHLC, negative volume, future bars and holidays', () => {
    const r = normalizeBars(
      [
        bar('2026-10-05T03:45:00Z', 0, 105, 99, 104),
        bar('2026-10-05T03:45:00Z', 100, 98, 99, 99),
        bar('2026-10-05T03:45:00Z', 100, 105, 99, 104, -5),
        bar('2026-10-07T03:45:00Z', 100, 105, 99, 104),
        bar('2026-10-02T03:45:00Z', 100, 105, 99, 104),
      ],
      ctx(),
    );
    expect(r.bars).toEqual([]);
    expect(r.rejected).toEqual({
      NON_POSITIVE_PRICE: 1,
      OHLC_INCONSISTENT: 1,
      NEGATIVE_VOLUME: 1,
      FUTURE_TIMESTAMP: 1,
      NOT_A_TRADING_DAY: 1,
    });
  });

  it('keeps intraday bars inside the session that have fully elapsed', () => {
    const now = new Date('2026-10-06T04:02:00Z');
    const r = normalizeBars(
      [
        bar('2026-10-06T03:40:00Z', 100, 101, 99, 100),
        bar('2026-10-06T03:45:00Z', 100, 101, 99, 100),
        bar('2026-10-06T03:55:00Z', 100, 101, 99, 100),
        bar('2026-10-06T04:00:00Z', 100, 101, 99, 100),
      ],
      ctx({ timeframe: '5m', now }),
    );
    expect(r.bars.map((b) => b.ts.toISOString())).toEqual([
      '2026-10-06T03:45:00.000Z',
      '2026-10-06T03:55:00.000Z',
    ]);
    expect(r.rejected).toEqual({ OUTSIDE_SESSION: 1 });
    expect(r.dropped).toEqual({ INCOMPLETE: 1 });
  });

  it('treats null volume (indices) as 0, de-duplicates by timestamp keeping the last, and sorts', () => {
    const r = normalizeBars(
      [
        bar('2026-10-06T03:45:00Z', 100, 105, 99, 104, null),
        bar('2026-10-05T03:45:00Z', 90, 95, 89, 94, null),
        bar('2026-10-05T03:45:00Z', 91, 96, 90, 95, null),
      ],
      ctx({ now: new Date('2026-10-07T00:00:00Z') }),
    );
    expect(r.bars.map((b) => [b.ts.toISOString(), b.close, b.volume])).toEqual([
      ['2026-10-05T03:45:00.000Z', 95, 0],
      ['2026-10-06T03:45:00.000Z', 104, 0],
    ]);
    expect(r.dropped).toEqual({ DUPLICATE_IN_BATCH: 1 });
  });

  it('drops flat zero-volume holiday placeholders (Yahoo carry-forward) but still rejects priced holiday bars', () => {
    const r = normalizeBars(
      [
        bar('2026-10-02T03:45:00Z', 1257.5, 1257.5, 1257.5, 1257.5, 0),
        bar('2026-10-02T03:45:00Z', 100, 105, 99, 104, 5000),
      ],
      ctx(),
    );
    expect(r.bars).toEqual([]);
    expect(r.dropped).toEqual({ HOLIDAY_PLACEHOLDER: 1 });
    expect(r.rejected).toEqual({ NOT_A_TRADING_DAY: 1 });
  });

  it('accepts priced bars on dates outside the loaded holiday calendar (provider authority), still dropping placeholders', () => {
    const r = normalizeBars(
      [
        bar('2025-02-01T03:45:00Z', 100, 105, 99, 104, 5000),
        bar('2025-02-02T03:45:00Z', 50, 50, 50, 50, 0),
      ],
      ctx({ calendarCovers: (d) => !d.startsWith('2025') }),
    );
    expect(r.bars.map((b) => b.ts.toISOString())).toEqual(['2025-02-01T03:45:00.000Z']);
    expect(r.dropped).toEqual({ HOLIDAY_PLACEHOLDER: 1 });
    expect(r.uncalendared).toBe(1);
  });

  it('waits a settle margin after an intraday bar ends before treating it as final (delayed providers)', () => {
    const justEnded = normalizeBars(
      [bar('2026-10-06T03:55:00Z', 100, 101, 99, 100)],
      ctx({ timeframe: '5m', now: new Date('2026-10-06T04:01:00Z') }),
    );
    expect(justEnded.bars).toEqual([]);
    expect(justEnded.dropped).toEqual({ INCOMPLETE: 1 });
    const settled = normalizeBars(
      [bar('2026-10-06T03:55:00Z', 100, 101, 99, 100)],
      ctx({ timeframe: '5m', now: new Date('2026-10-06T04:02:00Z') }),
    );
    expect(settled.bars).toHaveLength(1);
  });
});
