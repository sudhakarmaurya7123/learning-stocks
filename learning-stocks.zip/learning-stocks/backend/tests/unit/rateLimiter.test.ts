import { describe, expect, it } from 'vitest';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

function clock() {
  let t = 0;
  const sleeps: number[] = [];
  return {
    sleeps,
    now: () => t,
    sleep: async (ms: number) => {
      sleeps.push(ms);
      t += ms;
    },
    advance: (ms: number) => {
      t += ms;
    },
  };
}

describe('createRateLimiter', () => {
  it('allows a burst, then spaces calls at the configured rate', async () => {
    const c = clock();
    const limiter = createRateLimiter({ ratePerSecond: 1, burst: 2, now: c.now, sleep: c.sleep });
    await limiter.acquire();
    await limiter.acquire();
    expect(c.sleeps).toEqual([]);
    await limiter.acquire();
    expect(c.sleeps).toEqual([1000]);
  });

  it('refills over time but never above the burst size', async () => {
    const c = clock();
    const limiter = createRateLimiter({ ratePerSecond: 2, burst: 2, now: c.now, sleep: c.sleep });
    await limiter.acquire();
    await limiter.acquire();
    c.advance(10_000);
    await limiter.acquire();
    await limiter.acquire();
    expect(c.sleeps).toEqual([]);
    await limiter.acquire();
    expect(c.sleeps).toEqual([500]);
  });

  it('serves concurrent callers in order without exceeding the rate', async () => {
    const c = clock();
    const limiter = createRateLimiter({ ratePerSecond: 1, burst: 1, now: c.now, sleep: c.sleep });
    const order: number[] = [];
    await Promise.all(
      [1, 2, 3].map(async (n) => {
        await limiter.acquire();
        order.push(n);
      }),
    );
    expect(order).toEqual([1, 2, 3]);
    expect(c.sleeps).toEqual([1000, 1000]);
  });

  it('rejects a non-positive rate', () => {
    expect(() => createRateLimiter({ ratePerSecond: 0 })).toThrow(RangeError);
  });
});
