import { describe, expect, it } from 'vitest';
import type {
  YahooFundamentalsClient,
  YahooStatementRow,
  YahooSummary,
} from '../../src/providers/fundamentals/yahoo/yahooFundamentalsClient.js';
import { YahooFundamentalsProvider } from '../../src/providers/fundamentals/yahoo/YahooFundamentalsProvider.js';

const REF = { providerSymbol: 'RELIANCE.NS', exchange: 'NSE', kind: 'stock' } as const;
const NOW = () => new Date('2026-10-05T12:00:00Z');
const summary = (over: Partial<YahooSummary> = {}): YahooSummary => ({
  exchange: 'NSI',
  financialCurrency: 'INR',
  marketCap: 16_054_925_393_920,
  trailingPE: 21.48497,
  priceToBook: 1.7759284,
  trailingEps: 55.22,
  returnOnEquity: 0.13838,
  debtToEquity: 46.278,
  dividendYield: 0.0051,
  operatingMargins: 0.12331,
  profitMargins: 0.066149995,
  freeCashflow: null,
  totalRevenue: 11_296_050_249_728,
  netIncomeToCommon: 747_000_000_000,
  revenueGrowth: 0.297,
  earningsGrowth: -0.224,
  bookValue: 668.045,
  beta: 0.194,
  ...over,
});
const row = (
  date: string,
  periodType: string,
  values: Record<string, number>,
): YahooStatementRow => ({ date: new Date(`${date}T00:00:00Z`), periodType, values });

class FakeClient implements YahooFundamentalsClient {
  calls: string[] = [];
  constructor(
    private readonly s: YahooSummary | Error,
    private readonly rows: YahooStatementRow[] = [],
  ) {}
  async summary(symbol: string) {
    this.calls.push(`summary:${symbol}`);
    if (this.s instanceof Error) throw this.s;
    return this.s;
  }
  async timeSeries(symbol: string, type: string) {
    this.calls.push(`ts:${type}`);
    return this.rows;
  }
}

function provider(client: FakeClient) {
  let acquired = 0;
  return {
    p: new YahooFundamentalsProvider(
      client,
      {
        acquire: async () => {
          acquired += 1;
        },
      },
      NOW,
    ),
    acquired: () => acquired,
  };
}

describe('YahooFundamentalsProvider', () => {
  it('converts Yahoo fractions to percent and D/E percent to a ratio; ROCE is never provided', async () => {
    const { p } = provider(new FakeClient(summary()));
    const s = await p.getSnapshot(REF);
    expect(s.reportingCurrency).toBe('INR');
    expect(s.asOf).toEqual(NOW());
    expect(s.metrics.roe).toBeCloseTo(13.838, 6);
    expect(s.metrics.debtToEquity).toBeCloseTo(0.46278, 6);
    expect(s.metrics.dividendYield).toBeCloseTo(0.51, 6);
    expect(s.metrics.operatingMargin).toBeCloseTo(12.331, 6);
    expect(s.metrics.netMargin).toBeCloseTo(6.6149995, 6);
    expect(s.metrics.revenueGrowthYoy).toBeCloseTo(29.7, 6);
    expect(s.metrics.profitGrowthYoy).toBeCloseTo(-22.4, 6);
    expect(s.metrics).toMatchObject({
      pe: 21.48497,
      pb: 1.7759284,
      epsTtm: 55.22,
      bookValuePerShare: 668.045,
      beta: 0.194,
      freeCashFlow: null,
      roce: null,
      netProfitTtm: 747_000_000_000,
    });
    expect(p.capabilities().fields).not.toContain('roce');
  });

  it('keeps missing values null and passes the reporting currency through', async () => {
    const { p } = provider(
      new FakeClient(
        summary({ returnOnEquity: null, debtToEquity: null, financialCurrency: 'USD' }),
      ),
    );
    const s = await p.getSnapshot(REF);
    expect(s.metrics).toMatchObject({ roe: null, debtToEquity: null });
    expect(s.reportingCurrency).toBe('USD');
  });

  it('refuses non-Indian listings and maps unknown symbols to UNSUPPORTED', async () => {
    await expect(
      provider(new FakeClient(summary({ exchange: 'NMS' }))).p.getSnapshot(REF),
    ).rejects.toMatchObject({ code: 'UNSUPPORTED' });
    await expect(
      provider(new FakeClient(summary({ exchange: null }))).p.getSnapshot(REF),
    ).rejects.toMatchObject({ code: 'INVALID_RESPONSE' });
    await expect(
      provider(new FakeClient(new Error('Quote not found for symbol: NOPE.NS'))).p.getSnapshot(REF),
    ).rejects.toMatchObject({ code: 'UNSUPPORTED' });
  });

  it('maps statements for the requested period, drops empty rows, reuses the cached currency', async () => {
    const client = new FakeClient(summary(), [
      row('2025-03-31', '12M', {
        totalRevenue: 9.64693e12,
        operatingIncome: 1.12462e12,
        netIncome: 6.9648e11,
        dilutedEPS: 51.47,
        totalDebt: 3.69575e12,
        stockholdersEquity: 8.432e12,
        operatingCashFlow: 1.78703e12,
        capitalExpenditure: -1.39967e12,
      }),
      row('2026-03-31', '12M', {
        totalRevenue: 1.057219e13,
        netIncomeCommonStockholders: 8.0775e11,
        netIncome: 1e9,
      }),
      row('2026-06-30', '3M', { totalRevenue: 3.09468e12 }),
      row('2024-03-31', '12M', { someOtherField: 5 }),
    ]);
    const { p, acquired } = provider(client);
    await p.getSnapshot(REF);
    const annual = await p.getStatements(REF, 'ANNUAL');
    expect(annual.reportingCurrency).toBe('INR');
    expect(annual.statements.map((s) => s.periodEnd)).toEqual(['2025-03-31', '2026-03-31']);
    expect(annual.statements[0]?.metrics).toEqual({
      revenue: 9.64693e12,
      operatingProfit: 1.12462e12,
      netProfit: 6.9648e11,
      eps: 51.47,
      totalDebt: 3.69575e12,
      totalEquity: 8.432e12,
      cashFromOperations: 1.78703e12,
      capex: -1.39967e12,
    });
    expect(annual.statements[1]?.metrics.netProfit).toBe(8.0775e11);
    expect(client.calls.filter((c) => c.startsWith('summary'))).toHaveLength(1);
    expect(acquired()).toBe(2);
  });

  it('bounds every Yahoo call with a deadline (the library has no per-call timeout)', async () => {
    const hanging: YahooFundamentalsClient = {
      summary: () => new Promise<YahooSummary>(() => undefined),
      timeSeries: () => new Promise<YahooStatementRow[]>(() => undefined),
    };
    const p = new YahooFundamentalsProvider(hanging, { acquire: async () => undefined }, NOW, {
      timeoutMs: 20,
    });
    await expect(p.getSnapshot(REF)).rejects.toMatchObject({ code: 'TIMEOUT' });
  });

  it('fetches the currency first when statements are requested without a snapshot', async () => {
    const client = new FakeClient(summary({ financialCurrency: 'USD' }), [
      row('2026-03-31', '12M', { totalRevenue: 2.0158e10 }),
    ]);
    const r = await provider(client).p.getStatements(REF, 'ANNUAL');
    expect(r.reportingCurrency).toBe('USD');
    expect(client.calls).toEqual(['summary:RELIANCE.NS', 'ts:annual']);
  });
});
