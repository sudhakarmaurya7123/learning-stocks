import { describe, expect, it } from 'vitest';
import { MockNewsProvider } from '../../src/providers/news/mock/MockNewsProvider.js';

const NOW = () => new Date('2026-10-05T06:30:00Z'); // 12:00 IST
const RELIANCE = { symbol: 'RELIANCE', name: 'Reliance Industries', aliases: ['RIL'] };
const SINCE = new Date('2026-09-05T00:00:00Z');

describe('MockNewsProvider', () => {
  it('is deterministic and clearly labelled synthetic', async () => {
    const a = await new MockNewsProvider(NOW).fetchForInstruments({
      subjects: [RELIANCE],
      since: SINCE,
      limit: 100,
    });
    const b = await new MockNewsProvider(NOW).fetchForInstruments({
      subjects: [RELIANCE],
      since: SINCE,
      limit: 100,
    });
    expect(a).toEqual(b);
    expect(a.failures).toEqual([]);
    expect(a.articles.length).toBeGreaterThan(5);
    for (const art of a.articles) {
      expect(art.title).toMatch(/^\[MOCK\] Reliance Industries /);
      expect(art.url).toMatch(/^https:\/\/mock-news\.invalid\//);
      expect(art.title).not.toMatch(/\d/);
    }
  });

  it('never returns articles after now or before since, newest first, within the limit', async () => {
    const r = await new MockNewsProvider(NOW).fetchForInstruments({
      subjects: [RELIANCE],
      since: SINCE,
      limit: 3,
    });
    expect(r.articles).toHaveLength(3);
    const times = r.articles.map((x) => x.publishedAt?.getTime() ?? 0);
    expect(times).toEqual([...times].sort((x, y) => y - x));
    expect(times.every((t) => t <= NOW().getTime() && t >= SINCE.getTime())).toBe(true);
  });

  it('produces market news that names indices', async () => {
    const r = await new MockNewsProvider(NOW).fetchMarketNews({ since: SINCE, limit: 100 });
    expect(r.articles.length).toBeGreaterThan(10);
    expect(r.articles.some((x) => /Nifty|Sensex|VIX/.test(x.title ?? ''))).toBe(true);
  });

  it('declares one instrument per query', () => {
    expect(new MockNewsProvider(NOW).capabilities()).toEqual({
      maxInstrumentsPerQuery: 1,
      latency: 'realtime',
    });
  });
});
