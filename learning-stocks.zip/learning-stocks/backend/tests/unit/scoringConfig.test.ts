import { describe, expect, it } from 'vitest';
import { parseScoringConfig } from '../../src/scoring/config.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

describe('parseScoringConfig', () => {
  it('maps seeded thresholds to camelCase and fills defaults for newer keys', () => {
    expect(SEED_CONFIG.version).toBe('v1');
    expect(SEED_CONFIG.weights.market_context).toBe(15);
    expect(SEED_CONFIG.thresholds).toMatchObject({
      buyOverallMin: 65,
      minDailyBars: 200,
      stopAtrMultiple: 1.5,
      vixRiskOnMax: 20,
      vixRiskOffMin: 25,
      weakQualityMax: 40,
      maxStaleSessions: 3,
    });
  });

  it('rejects a malformed config row', () => {
    expect(() =>
      parseScoringConfig({ version: 'bad', weights: { technical: 'x' }, thresholds: {} }),
    ).toThrow(expect.objectContaining({ code: 'INTERNAL' }));
  });
});
