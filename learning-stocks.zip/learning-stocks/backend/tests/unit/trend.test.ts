import { describe, expect, it } from 'vitest';
import { classifyRegime, classifyTrend } from '../../src/technical/trend.js';

const T = { vixRiskOnMax: 20, vixRiskOffMin: 25 };

describe('classifyTrend', () => {
  it('needs close > SMA50 > SMA200 with a rising SMA200 for an uptrend (and the mirror for a downtrend)', () => {
    expect(classifyTrend({ close: 120, sma50: 110, sma200: 100, sma200Prev: 98 })).toBe('UPTREND');
    expect(classifyTrend({ close: 120, sma50: 110, sma200: 100, sma200Prev: 101 })).toBe(
      'SIDEWAYS',
    );
    expect(classifyTrend({ close: 80, sma50: 90, sma200: 100, sma200Prev: 102 })).toBe('DOWNTREND');
    expect(classifyTrend({ close: 95, sma50: 105, sma200: 100, sma200Prev: 99 })).toBe('SIDEWAYS');
    expect(classifyTrend({ close: 95, sma50: 105, sma200: null, sma200Prev: null })).toBeNull();
  });
});

describe('classifyRegime', () => {
  it('is RISK_OFF on a NIFTY downtrend or high VIX, RISK_ON on an uptrend with calm VIX', () => {
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: 14 }, T)).toBe('RISK_ON');
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: 22 }, T)).toBe('NEUTRAL');
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: 27 }, T)).toBe('RISK_OFF');
    expect(classifyRegime({ niftyTrend: 'DOWNTREND', vix: 12 }, T)).toBe('RISK_OFF');
    expect(classifyRegime({ niftyTrend: 'SIDEWAYS', vix: null }, T)).toBe('NEUTRAL');
    expect(classifyRegime({ niftyTrend: 'UPTREND', vix: null }, T)).toBe('RISK_ON');
    expect(classifyRegime({ niftyTrend: null, vix: null }, T)).toBeNull();
  });
});
