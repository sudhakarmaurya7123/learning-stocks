import { describe, expect, it } from 'vitest';
import {
  dedupeDocuments,
  mmr,
  orderForContext,
  recencyDecay,
  rerank,
  type RankedDocument,
} from '../../src/rag/retriever.js';
import type { MatchedDocument } from '../../src/repositories/EmbeddingRepository.js';

const NOW = new Date('2026-10-06T00:00:00Z');
const daysAgo = (d: number) => new Date(NOW.getTime() - d * 86_400_000);
const doc = (
  id: string,
  similarity: number,
  over: Partial<MatchedDocument> = {},
): MatchedDocument => ({
  id,
  sourceType: 'NEWS',
  sourceId: id,
  stockId: 's',
  content: id,
  metadata: {},
  publishedAt: NOW,
  similarity,
  ...over,
});

describe('recencyDecay', () => {
  it('halves every half-life, treats unknown dates as 0.5 and future dates as fresh', () => {
    expect(recencyDecay(daysAgo(30), NOW, 30)).toBeCloseTo(0.5, 10);
    expect(recencyDecay(daysAgo(60), NOW, 30)).toBeCloseTo(0.25, 10);
    expect(recencyDecay(null, NOW, 30)).toBe(0.5);
    expect(recencyDecay(daysAgo(-3), NOW, 30)).toBe(1);
  });
});

describe('rerank', () => {
  it('scores similarity × recency × relevance with source-specific half-lives', () => {
    const ranked = rerank(
      [
        doc('old-news', 0.9, { publishedAt: daysAgo(60), metadata: { relevance: 1 } }),
        doc('fresh-weak', 0.5, { metadata: { relevance: 0.6 } }),
        doc('annual', 0.6, { sourceType: 'FINANCIALS', publishedAt: daysAgo(365) }),
      ],
      NOW,
    );
    expect(ranked.map((r) => [r.id, Number(r.score.toFixed(4))])).toEqual([
      ['annual', 0.3],
      ['fresh-weak', 0.3],
      ['old-news', 0.225],
    ]);
    expect(ranked.find((r) => r.id === 'annual')?.relevance).toBe(1);
  });
});

describe('mmr', () => {
  it('prefers a diverse document over a near-duplicate of one already chosen', () => {
    const ranked: RankedDocument[] = [
      { ...doc('a', 1), recency: 1, relevance: 1, score: 1 },
      { ...doc('a-copy', 0.99), recency: 1, relevance: 1, score: 0.99 },
      { ...doc('b', 0.6), recency: 1, relevance: 1, score: 0.6 },
    ];
    const v = (i: number) => Array.from({ length: 4 }, (_, k) => (k === i ? 1 : 0));
    const vectors = new Map([
      ['a', v(0)],
      ['a-copy', v(0)],
      ['b', v(1)],
    ]);
    expect(mmr(ranked, vectors, 2).map((d) => d.id)).toEqual(['a', 'b']);
    expect(mmr(ranked, vectors, 5).map((d) => d.id)).toEqual(['a', 'b', 'a-copy']);
  });
});

describe('orderForContext', () => {
  it('puts stock documents first, newest first, ties by id — independent of score', () => {
    const r = (
      id: string,
      stockId: string | null,
      days: number,
      score: number,
    ): RankedDocument => ({
      ...doc(id, 0.5, { stockId, publishedAt: daysAgo(days) }),
      recency: 1,
      relevance: 1,
      score,
    });
    const ordered = orderForContext([
      r('m', null, 1, 0.9),
      r('b', 's', 5, 0.1),
      r('a', 's', 5, 0.2),
      r('c', 's', 2, 0.3),
    ]);
    expect(ordered.map((d) => d.id)).toEqual(['c', 'a', 'b', 'm']);
  });
});

describe('dedupeDocuments', () => {
  it('keeps one row per (source, content) when the same article is stored for several stocks', () => {
    const out = dedupeDocuments([
      doc('r1', 0.7, { sourceId: 'art', stockId: 's1', content: 'x' }),
      doc('r2', 0.8, { sourceId: 'art', stockId: 's2', content: 'x' }),
      doc('r3', 0.6, { sourceId: 'other', content: 'y' }),
    ]);
    expect(out.map((d) => d.id).sort()).toEqual(['r2', 'r3']);
  });
});
