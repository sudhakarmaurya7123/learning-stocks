import { describe, expect, it } from 'vitest';
import {
  MarketSummarySchema,
  NewsSentimentSchema,
  QaAnswerSchema,
  StockAnalysisSchema,
  TradeSignalNarrativeSchema,
} from '../../src/ai/schemas.js';
import { toStrictJsonSchema } from '../../src/providers/llm/jsonSchema.js';

describe('AI output schemas', () => {
  it('are all valid strict structured-output schemas without length constraints', () => {
    for (const s of [
      NewsSentimentSchema,
      StockAnalysisSchema,
      MarketSummarySchema,
      TradeSignalNarrativeSchema,
      QaAnswerSchema,
    ]) {
      const json = JSON.stringify(toStrictJsonSchema(s));
      expect(json).not.toMatch(/minLength|maxLength|minItems|maxItems/);
    }
  });

  it('accepts a PRD §9.2-shaped stock analysis with nullable code-owned fields', () => {
    const ok = StockAnalysisSchema.safeParse({
      sentiment: 'NEUTRAL',
      sentiment_score: 50,
      confidence: 40,
      technical_score: null,
      fundamental_score: null,
      news_score: null,
      momentum_score: null,
      risk_score: null,
      overall_score: null,
      trend: null,
      risk_level: null,
      recommendation: null,
      summary: 's',
      reasoning: [],
      positive_factors: [],
      negative_factors: [],
      key_risks: [],
      catalysts: [],
      invalidation_conditions: [],
      facts: [{ statement: 'x', source_ids: ['E1'] }],
      interpretation: [],
      insufficient_data: [],
    });
    expect(ok.success).toBe(true);
    expect(NewsSentimentSchema.safeParse({ sentiment: 'UP' }).success).toBe(false);
  });
});
