import { describe, expect, it } from 'vitest';
import {
  clusterZones,
  computeLevels,
  type LevelBar,
  type LevelsInput,
  swingPivots,
} from '../../src/technical/levels.js';

/** Triangle wave between 100 and 120 (step 2, period 20); high/low = close ± 1. 60 bars, last close 102. */
function wave(): LevelBar[] {
  return Array.from({ length: 60 }, (_, i) => {
    const k = i % 20;
    const close = k <= 10 ? 100 + 2 * k : 120 - 2 * (k - 10);
    return { high: close + 1, low: close - 1, close };
  });
}

const base = (over: Partial<LevelsInput> = {}): LevelsInput => ({
  bars: wave(),
  price: 102,
  atr: 3,
  sma20: null,
  sma50: null,
  sma200: null,
  trend: 'SIDEWAYS',
  capital: 1_000_000,
  riskPct: 1,
  stopAtrMultiple: 1.5,
  entryAtrWidth: 0.5,
  ...over,
});

describe('swingPivots / clusterZones', () => {
  it('finds strict local extremes with n bars on each side', () => {
    const p = swingPivots(wave(), 5);
    expect(p.highs).toEqual([121, 121, 121]);
    expect(p.lows).toEqual([99, 99]);
  });

  it('clusters levels within the width and counts touches', () => {
    expect(clusterZones([100, 100.5, 110, 99.8], 1)).toEqual([
      { low: 99.8, high: 100.5, mid: 100.15, touches: 3, sources: [] },
      { low: 110, high: 110, mid: 110, touches: 1, sources: [] },
    ]);
  });
});

describe('computeLevels', () => {
  it('builds entry, stop, targets, R:R and size from the nearest support (PRD §8.4)', () => {
    const r = computeLevels(base());
    expect(r.reason).toBeNull();
    expect(r.trade).toEqual({
      basis: 'SUPPORT',
      entryLow: 99,
      entryHigh: 100.5,
      stop: 94.5,
      target1: 121,
      target2: 126.25,
      riskReward: 4.05,
      positionSizeHint: 1904,
    });
    expect(r.supports[0]?.mid).toBe(99);
    expect(r.resistances[0]?.low).toBe(121);
  });

  it('uses the SMA20–SMA50 pullback band in a confirmed uptrend', () => {
    const r = computeLevels(base({ trend: 'UPTREND', sma20: 105, sma50: 101 }));
    expect(r.trade).toMatchObject({
      basis: 'PULLBACK_BAND',
      entryLow: 101,
      entryHigh: 105,
      stop: 96.5,
    });
  });

  it('falls back to 2R/3R targets when nothing resists above the entry', () => {
    const flat = Array.from({ length: 40 }, (_, i) => ({
      high: 100 + i + 1,
      low: 100 + i - 1,
      close: 100 + i,
    }));
    const r = computeLevels(
      base({ bars: flat, price: 150, trend: 'UPTREND', sma20: 139, sma50: 135 }),
    );
    const t = r.trade;
    expect(t?.basis).toBe('PULLBACK_BAND');
    const mid = (135 + 139) / 2;
    const risk = mid - (135 - 4.5);
    expect(t?.target1).toBeCloseTo(mid + 2 * risk, 2);
    expect(t?.target2).toBeCloseTo(mid + 3 * risk, 2);
    expect(t?.riskReward).toBe(2);
  });

  it('ignores resistance within 1×ATR of the entry zone (calibration: not a meaningful target)', () => {
    // SMA50 at 102.5 sits just above the 99–100.5 entry zone (ATR 3): too close to be T1; the 121 zone is.
    const r = computeLevels(base({ price: 101.5, sma50: 102.5 }));
    expect(r.resistances[0]?.mid).toBe(102.5);
    expect(r.trade?.target1).toBe(121);
  });

  it('targets significant resistance only: a single-touch swing high is skipped', () => {
    // Lower the middle peak to a one-off swing high at 111; the 121 zone (two peaks + 52-week high) stays.
    const bars = wave().map((b, i) =>
      i >= 25 && i <= 35 ? { high: b.close - 9, low: b.close - 11, close: b.close - 10 } : b,
    );
    const r = computeLevels(base({ bars }));
    expect(r.resistances.find((z) => z.mid === 111)?.touches).toBe(1);
    expect(r.trade?.target1).toBe(121);
  });

  it('does not treat the 52-week high as resistance when price is already at its highs', () => {
    const rising = Array.from({ length: 40 }, (_, i) => ({
      high: 100 + i + 1,
      low: 100 + i - 1,
      close: 100 + i,
    }));
    const r = computeLevels(
      base({ bars: rising, price: 139.5, trend: 'UPTREND', sma20: 130, sma50: 125 }),
    );
    expect(r.resistances.some((z) => z.sources.includes('52W_HIGH'))).toBe(false);
    expect(r.trade?.riskReward).toBe(2);
  });

  it('caps the size so the position never costs more than the capital', () => {
    const r = computeLevels(base({ capital: 10_000, riskPct: 100 }));
    expect(r.trade?.positionSizeHint).toBe(Math.floor(10_000 / 100.5));
  });

  it('returns no trade (with a reason) for degenerate inputs instead of invalid prices', () => {
    expect(computeLevels(base({ atr: null })).reason).toMatch(/ATR/);
    expect(computeLevels(base({ atr: 0 })).trade).toBeNull();
    expect(computeLevels(base({ price: 50 })).reason).toMatch(/no support/);
    // ATR 80 merges every level into one zone (mid 110); at price 130 it is support, and 110 − 1.5×80 < 0.
    const wide = computeLevels(base({ atr: 80, price: 130 }));
    expect(wide.trade).toBeNull();
    expect(wide.reason).toMatch(/stop/);
    expect(computeLevels(base({ bars: wave().slice(0, 8) })).reason).toMatch(/history/);
  });
});
