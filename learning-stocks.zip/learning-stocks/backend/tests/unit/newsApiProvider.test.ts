import { describe, expect, it } from 'vitest';
import {
  buildInstrumentQuery,
  NEWSAPI_MARKET_QUERY,
  NewsApiProvider,
} from '../../src/providers/news/newsapi/NewsApiProvider.js';
import { AppError } from '../../src/utils/errors.js';
import type { HttpRequest } from '../../src/utils/http.js';

const KEY = 'test-key-123';
const article = (over: Record<string, unknown> = {}) => ({
  source: { id: null, name: 'Example' },
  author: 'A. Writer',
  title: 'Infosys wins large deal',
  description: 'Infosys signed a multi-year contract.',
  url: 'https://example.com/infosys-deal',
  urlToImage: null,
  publishedAt: '2026-10-04T09:00:00Z',
  content: 'Infosys signed a contract with a client… [+1234 chars]',
  ...over,
});

function provider(body: unknown) {
  const requests: HttpRequest[] = [];
  let acquired = 0;
  const p = new NewsApiProvider(
    KEY,
    {
      acquire: async () => {
        acquired += 1;
      },
    },
    {
      fetchJson: async (req) => {
        requests.push(req);
        return { data: body };
      },
    },
  );
  return { p, requests, acquired: () => acquired };
}

describe('NewsApiProvider', () => {
  it('batches instruments into one OR query, sends the key only in a header', async () => {
    const { p, requests, acquired } = provider({
      status: 'ok',
      totalResults: 1,
      articles: [article()],
    });
    const since = new Date('2026-10-01T00:00:00Z');
    await p.fetchForInstruments({
      subjects: [
        { symbol: 'RELIANCE', name: 'Reliance Industries', aliases: [] },
        { symbol: 'INFY', name: 'Infosys', aliases: [] },
      ],
      since,
      limit: 30,
    });
    const req = requests[0];
    const url = new URL(req?.url ?? '');
    expect(url.origin + url.pathname).toBe('https://newsapi.org/v2/everything');
    expect(url.searchParams.get('q')).toBe('"Reliance Industries" OR "Infosys"');
    expect(Object.fromEntries(url.searchParams)).toMatchObject({
      searchIn: 'title,description',
      language: 'en',
      sortBy: 'publishedAt',
      from: since.toISOString(),
      pageSize: '30',
    });
    expect(req?.url).not.toContain(KEY);
    expect(req?.headers?.['x-api-key']).toBe(KEY);
    expect(acquired()).toBe(1);
  });

  it('maps articles, drops [Removed] placeholders, strips the truncation marker', async () => {
    const { p } = provider({
      status: 'ok',
      totalResults: 3,
      articles: [
        article(),
        article({ title: '[Removed]', url: 'https://removed.com' }),
        article({ title: 'No date', url: 'https://example.com/2', publishedAt: 'garbage' }),
      ],
    });
    const r = await p.fetchMarketNews({ since: new Date('2026-10-01T00:00:00Z'), limit: 10 });
    expect(r.failures).toEqual([]);
    expect(r.articles).toHaveLength(2);
    expect(r.articles[0]).toEqual({
      title: 'Infosys wins large deal',
      url: 'https://example.com/infosys-deal',
      description: 'Infosys signed a multi-year contract.',
      content: 'Infosys signed a contract with a client',
      author: 'A. Writer',
      publishedAt: new Date('2026-10-04T09:00:00Z'),
      publisherUrl: null,
      language: 'en',
    });
    expect(r.articles[1]?.publishedAt).toBeNull();
  });

  it('uses a market query and caps the page size at 100', async () => {
    const { p, requests } = provider({ status: 'ok', totalResults: 0, articles: [] });
    await p.fetchMarketNews({ since: new Date(), limit: 500 });
    const url = new URL(requests[0]?.url ?? '');
    expect(url.searchParams.get('q')).toBe(NEWSAPI_MARKET_QUERY);
    expect(url.searchParams.get('pageSize')).toBe('100');
  });

  it.each([
    [{ status: 'error', code: 'apiKeyInvalid', message: 'bad' }, 'AUTH_FAILED'],
    [{ status: 'error', code: 'rateLimited', message: 'slow down' }, 'RATE_LIMITED'],
    [{ status: 'error', code: 'parameterInvalid', message: 'x' }, 'INVALID_RESPONSE'],
    [{ unexpected: true }, 'INVALID_RESPONSE'],
  ])('maps error body %j to %s', async (body, code) => {
    await expect(
      provider(body).p.fetchMarketNews({ since: new Date(), limit: 5 }),
    ).rejects.toMatchObject({ code });
  });

  it('fails fast on any rate limit (quota body or HTTP 429) so retries never burn the daily quota', async () => {
    await expect(
      provider({ status: 'error', code: 'apiKeyExhausted', message: 'quota' }).p.fetchMarketNews({
        since: new Date(),
        limit: 5,
      }),
    ).rejects.toMatchObject({ code: 'RATE_LIMITED', retryAfterMs: 3_600_000 });
    const http429 = new NewsApiProvider(
      KEY,
      { acquire: async () => undefined },
      {
        fetchJson: async () => {
          throw new AppError('RATE_LIMITED', 'Rate limited by https://newsapi.org/v2/everything');
        },
      },
    );
    await expect(http429.fetchMarketNews({ since: new Date(), limit: 5 })).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      retryAfterMs: 3_600_000,
    });
  });

  it('refuses a query longer than NewsAPI allows', () => {
    const many = Array.from({ length: 40 }, (_, i) => ({
      symbol: `S${i}`,
      name: `Very Long Company Name Number ${i}`,
      aliases: [],
    }));
    expect(() => buildInstrumentQuery(many)).toThrow(/too long/);
  });
});
