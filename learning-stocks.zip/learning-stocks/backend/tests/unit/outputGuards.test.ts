import { describe, expect, it } from 'vitest';
import {
  bannedPhraseIssues,
  biasIssues,
  capList,
  citationIssues,
  clampText,
  sectorIssues,
  unknownRupeeIssues,
} from '../../src/ai/outputGuards.js';

describe('bannedPhraseIssues', () => {
  it.each([
    'Returns are guaranteed',
    'It WILL DEFINITELY rally',
    'a sure shot winner',
    'a sure-shot pick',
    'certain to rise this week',
    'certain to go down',
    'a risk free trade',
    'This guarantees profits',
  ])('flags %s anywhere in nested output', (text) => {
    expect(bannedPhraseIssues({ a: [{ b: text }] })).toHaveLength(1);
  });

  it('allows bias language and honest uncertainty', () => {
    expect(
      bannedPhraseIssues({
        s: 'AI analysis indicates a bullish bias; there is no guarantee of returns.',
      }),
    ).toEqual([]);
  });
});

describe('unknownRupeeIssues', () => {
  const context =
    'Last price ₹1,186.40 · stop ₹1,110.00 · 52-week range ₹1,000.00 to ₹1,300.00 · Revenue: ₹2,48,000.00 crore';
  it('accepts amounts present in the context (1% tolerance) and rejects invented ones', () => {
    expect(
      unknownRupeeIssues(
        { s: 'Price near ₹1,186 with a stop at ₹1,110 and revenue of ₹2,48,000 crore' },
        context,
      ),
    ).toEqual([]);
    const issues = unknownRupeeIssues(
      { s: 'A target of ₹1,450 looks reachable', t: ['₹2,000'] },
      context,
    );
    expect(issues).toHaveLength(2);
    expect(issues[0]).toMatch(/₹1,450 does not appear in the context/);
  });
});

describe('citationIssues', () => {
  const issued = new Set(['E1', 'N1']);
  it('rejects unknown IDs in facts, inline brackets and combined brackets', () => {
    expect(
      citationIssues([{ statement: 'ok', source_ids: ['E1'] }], { s: 'see [N1]' }, issued),
    ).toEqual([]);
    expect(citationIssues([{ statement: 'x', source_ids: ['N7'] }], {}, issued)[0]).toMatch(
      /unknown source IDs N7/,
    );
    expect(citationIssues([], { s: 'see [N1, X9]' }, issued)[0]).toMatch(/X9/);
  });
});

describe('biasIssues and sectorIssues', () => {
  it('rejects sentiment that contradicts the computed bias', () => {
    expect(biasIssues('BULLISH', 'SELL_BIAS')).toHaveLength(1);
    expect(biasIssues('BEARISH', 'STRONG_BUY_BIAS')).toHaveLength(1);
    expect(biasIssues('NEUTRAL', 'SELL_BIAS')).toEqual([]);
    expect(biasIssues('BULLISH', 'HOLD_BIAS')).toEqual([]);
    expect(biasIssues('BEARISH', null)).toEqual([]);
  });

  it('rejects sectors outside the supplied list', () => {
    expect(sectorIssues(['Banks', 'Aerospace'], new Set(['Banks', 'IT']))[0]).toMatch(/Aerospace/);
  });
});

describe('clampText and capList', () => {
  it('truncates long text and long lists', () => {
    expect(clampText('abcdef', 4)).toBe('abc…');
    expect(capList(['a', 'b', 'c'], 2)).toEqual(['a', 'b']);
  });
});
