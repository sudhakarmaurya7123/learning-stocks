import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { embeddingCostInr } from '../../src/providers/llm/pricing.js';
import { mapOpenAIError, OpenAIProvider } from '../../src/providers/llm/openai/OpenAIProvider.js';
import { AppError } from '../../src/utils/errors.js';
import type { HttpRequest } from '../../src/utils/http.js';

const vec = (seed: number) => Array.from({ length: 1536 }, (_, i) => (i === seed ? 1 : 0));

function provider(respond: (req: HttpRequest) => unknown, over: { embeddingModel?: string } = {}) {
  const requests: HttpRequest[] = [];
  const p = new OpenAIProvider({
    apiKey: 'sk-test',
    chatModel: 'gpt-test',
    embeddingModel: over.embeddingModel ?? 'text-embedding-3-small',
    limiter: { acquire: async () => undefined },
    fetchJson: async (req) => {
      requests.push(req);
      const out = respond(req);
      if (out instanceof Error) throw out;
      return { data: out };
    },
  });
  return { p, requests };
}

const embeddingsReply = (req: HttpRequest) => {
  const input = (req.body as { input: string[] }).input;
  // Deliberately out of order: the adapter must sort by index.
  return {
    model: 'text-embedding-3-small',
    data: input.map((_, i) => ({ index: i, embedding: vec(i) })).reverse(),
    usage: { prompt_tokens: input.length * 3, total_tokens: input.length * 3 },
  };
};

describe('OpenAIProvider.embed', () => {
  it('posts batches of 64 with the key only in the authorization header and keeps input order', async () => {
    const { p, requests } = provider(embeddingsReply);
    const texts = Array.from({ length: 70 }, (_, i) => `t${i}`);
    const r = await p.embed(texts);
    expect(requests).toHaveLength(2);
    expect(requests[0]).toMatchObject({
      url: 'https://api.openai.com/v1/embeddings',
      method: 'POST',
      headers: { authorization: 'Bearer sk-test' },
      body: { model: 'text-embedding-3-small', dimensions: 1536, encoding_format: 'float' },
      errorBodyChars: 2000,
    });
    expect(requests[0]?.url).not.toContain('sk-test');
    expect((requests[0]?.body as { input: string[] }).input).toHaveLength(64);
    expect(r.vectors).toHaveLength(70);
    expect(r.vectors[1]?.[1]).toBe(1);
    expect(r.usage).toEqual({ inputTokens: 210, outputTokens: 0 });
  });

  it('sends dimensions only for text-embedding-3 models and rejects wrong vector sizes', async () => {
    const ada = provider(embeddingsReply, { embeddingModel: 'text-embedding-ada-002' });
    await ada.p.embed(['x']);
    expect(ada.requests[0]?.body).not.toHaveProperty('dimensions');
    const short = provider(() => ({
      model: 'm',
      data: [{ index: 0, embedding: [1, 2, 3] }],
      usage: { prompt_tokens: 1, total_tokens: 1 },
    }));
    await expect(short.p.embed(['x'])).rejects.toMatchObject({ code: 'INVALID_RESPONSE' });
  });

  it('returns an empty result without calling the API for no input', async () => {
    const { p, requests } = provider(embeddingsReply);
    expect((await p.embed([])).vectors).toEqual([]);
    expect(requests).toHaveLength(0);
  });
});

const Out = z.object({ answer: z.string(), score: z.number().int().min(0).max(100) });
const chat = (content: string | null, extra: Record<string, unknown> = {}) => ({
  model: 'gpt-test-2026',
  choices: [{ finish_reason: 'stop', message: { content, refusal: null, ...extra } }],
  usage: { prompt_tokens: 120, completion_tokens: 30 },
});

describe('OpenAIProvider.completeStructured', () => {
  it('requests strict json_schema output and parses it', async () => {
    const { p, requests } = provider(() => chat('{"answer":"ok","score":42}'));
    const r = await p.completeStructured({
      system: 'sys',
      user: 'usr',
      schema: Out,
      schemaName: 'out',
    });
    expect(r).toMatchObject({
      data: { answer: 'ok', score: 42 },
      model: 'gpt-test-2026',
      usage: { inputTokens: 120, outputTokens: 30 },
    });
    const body = requests[0]?.body as Record<string, unknown>;
    expect(requests[0]?.url).toBe('https://api.openai.com/v1/chat/completions');
    expect(body).toMatchObject({
      model: 'gpt-test',
      messages: [
        { role: 'system', content: 'sys' },
        { role: 'user', content: 'usr' },
      ],
      response_format: { type: 'json_schema', json_schema: { name: 'out', strict: true } },
    });
    expect(body).not.toHaveProperty('temperature');
    expect(body).not.toHaveProperty('max_tokens');
  });

  it('passes temperature and max_completion_tokens only when asked', async () => {
    const { p, requests } = provider(() => chat('{"answer":"ok","score":1}'));
    await p.completeStructured({
      system: 's',
      user: 'u',
      schema: Out,
      schemaName: 'out',
      temperature: 0.2,
      maxOutputTokens: 500,
    });
    expect(requests[0]?.body).toMatchObject({ temperature: 0.2, max_completion_tokens: 500 });
  });

  it.each([
    ['refusal', chat(null, { refusal: 'I cannot help' }), 'INVALID_RESPONSE'],
    [
      'truncated',
      {
        ...chat('{"answer":'),
        choices: [{ finish_reason: 'length', message: { content: '{"answer":' } }],
      },
      'INVALID_RESPONSE',
    ],
    ['empty', chat(null), 'EMPTY_RESPONSE'],
    ['not JSON', chat('hello'), 'INVALID_RESPONSE'],
    ['schema mismatch', chat('{"answer":"ok","score":500}'), 'INVALID_RESPONSE'],
  ])('%s → %s', async (_label, reply, code) => {
    const { p } = provider(() => reply);
    await expect(
      p.completeStructured({ system: 's', user: 'u', schema: Out, schemaName: 'out' }),
    ).rejects.toMatchObject({ code });
  });

  it('keeps the raw output on a schema mismatch for one repair attempt (Phase 7)', async () => {
    const { p } = provider(() => chat('{"answer":"ok","score":500}'));
    const e = await p
      .completeStructured({ system: 's', user: 'u', schema: Out, schemaName: 'out' })
      .catch((x: unknown) => x);
    expect((e as AppError).details).toMatchObject({ raw: '{"answer":"ok","score":500}' });
  });

  it('refuses structured calls when configured for embeddings only', async () => {
    const p = new OpenAIProvider({
      apiKey: 'k',
      chatModel: null,
      embeddingModel: 'text-embedding-3-small',
      limiter: { acquire: async () => undefined },
    });
    await expect(
      p.completeStructured({ system: 's', user: 'u', schema: Out, schemaName: 'out' }),
    ).rejects.toMatchObject({ code: 'UNSUPPORTED' });
  });

  it('attaches token usage to parse and schema failures so the spend can be recorded', async () => {
    const { p } = provider(() => chat('{"answer":"ok","score":500}'));
    const e = await p
      .completeStructured({ system: 's', user: 'u', schema: Out, schemaName: 'out' })
      .catch((x: unknown) => x);
    expect((e as AppError).details).toMatchObject({
      usage: { inputTokens: 120, outputTokens: 30 },
    });
  });
});

describe('mapOpenAIError', () => {
  const http = (code: AppError['code'], status: number, body: string, retryAfterMs?: number) =>
    new AppError(code, `status ${status}`, {
      details: { url: 'https://api.openai.com/v1/embeddings', status, body },
      ...(retryAfterMs === undefined ? {} : { retryAfterMs }),
    });

  it('treats insufficient_quota as non-retryable AUTH_FAILED', () => {
    const e = mapOpenAIError(
      http(
        'RATE_LIMITED',
        429,
        '{"error":{"code":"insufficient_quota","message":"You exceeded your current quota"}}',
      ),
    );
    expect(e.code).toBe('AUTH_FAILED');
    expect(e.retryable).toBe(false);
    expect(e.details).toMatchObject({ provider: 'openai', upstreamCode: 'insufficient_quota' });
  });

  it('surfaces the upstream message for 400s and drops the raw body', () => {
    const e = mapOpenAIError(
      http(
        'INVALID_RESPONSE',
        400,
        '{"error":{"message":"Invalid schema for response_format","code":"invalid_schema"}}',
      ),
    );
    expect(e.message).toMatch(/Invalid schema for response_format/);
    expect(e.details).not.toHaveProperty('body');
  });

  it('keeps transient errors retryable with their Retry-After', () => {
    const e = mapOpenAIError(
      http('RATE_LIMITED', 429, '{"error":{"code":"rate_limit_exceeded"}}', 2000),
    );
    expect(e).toMatchObject({ code: 'RATE_LIMITED', retryAfterMs: 2000 });
  });
});

describe('embeddingCostInr', () => {
  it('prices known models and returns null for unknown ones', () => {
    expect(embeddingCostInr('text-embedding-3-small', 1_000_000, 88)).toBeCloseTo(1.76, 4);
    expect(embeddingCostInr('mystery-model', 1000, 88)).toBeNull();
  });
});
