import { describe, expect, it } from 'vitest';
import { MemoryCache } from '../../src/utils/cache.js';

describe('MemoryCache', () => {
  it('expires entries after their TTL', () => {
    let now = 1_000;
    const cache = new MemoryCache(10, () => now);
    cache.set('quote:RELIANCE', 2500, 30_000);
    expect(cache.get<number>('quote:RELIANCE')).toBe(2500);
    now += 30_001;
    expect(cache.get('quote:RELIANCE')).toBeUndefined();
  });

  it('evicts the least recently used entry beyond capacity', () => {
    const cache = new MemoryCache(2);
    cache.set('a', 1, 60_000);
    cache.set('b', 2, 60_000);
    cache.get('a');
    cache.set('c', 3, 60_000);
    expect(cache.get('a')).toBe(1);
    expect(cache.get('b')).toBeUndefined();
    expect(cache.get('c')).toBe(3);
  });

  it('deletes by prefix', () => {
    const cache = new MemoryCache();
    cache.set('quote:A', 1, 60_000);
    cache.set('quote:B', 2, 60_000);
    cache.set('summary', 3, 60_000);
    expect(cache.deleteByPrefix('quote:')).toBe(2);
    expect(cache.get('summary')).toBe(3);
  });

  it('getOrSet loads once for concurrent callers and does not cache failures', async () => {
    const cache = new MemoryCache();
    let loads = 0;
    const load = async () => {
      loads += 1;
      return 'v';
    };
    const [x, y] = await Promise.all([
      cache.getOrSet('k', 1000, load),
      cache.getOrSet('k', 1000, load),
    ]);
    expect([x, y, loads]).toEqual(['v', 'v', 1]);

    let attempts = 0;
    const failing = async (): Promise<string> => {
      attempts += 1;
      throw new Error('db down');
    };
    await expect(cache.getOrSet('f', 1000, failing)).rejects.toThrow('db down');
    await expect(cache.getOrSet('f', 1000, failing)).rejects.toThrow('db down');
    expect(attempts).toBe(2);
  });
});
