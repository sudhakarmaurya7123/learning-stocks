import { describe, expect, it } from 'vitest';
import { createRegistry } from '../../src/jobs/registry.js';
import { JOB_NAMES } from '../../src/jobs/types.js';

/** A container with every optional service present, and one with them all disabled. */
function containerStub(
  options: { ai: boolean; news: boolean; fundamentals: boolean; llm: boolean },
  calendar: { sessionOn(exchange: string, date: string): Promise<unknown> } = {
    sessionOn: async () => null,
  },
) {
  const notCalled = () => {
    throw new Error('handler must not run in a registry shape test');
  };
  return {
    config: { dataMode: 'MOCK' as const },
    logger: { child: () => ({ info: notCalled, warn: notCalled, error: notCalled }) },
    repositories: {},
    services: {
      calendar,
      marketData: {},
      evaluation: {},
      news: options.news ? {} : null,
      fundamentals: options.fundamentals ? {} : null,
      embeddings: options.llm ? {} : null,
      ai: options.ai ? {} : null,
    },
  } as never;
}

describe('createRegistry', () => {
  it('defines exactly the known jobs, each under its own name', () => {
    const registry = createRegistry(
      containerStub({ ai: true, news: true, fundamentals: true, llm: true }),
    );
    expect(Object.keys(registry).sort()).toEqual([...JOB_NAMES].sort());
    for (const name of JOB_NAMES) expect(registry[name].name).toBe(name);
  });

  it('gates every job that needs a provider or the market calendar', async () => {
    const registry = createRegistry(
      containerStub({ ai: false, news: false, fundamentals: false, llm: false }),
    );
    const at = new Date('2026-10-06T06:00:00Z');
    for (const name of [
      'news.sync',
      'embeddings.generate',
      'news.sentiment',
      'ai.stock.analyze',
      'ai.market.summary',
      'ai.daily.summary',
      'signals.generate',
      'fundamentals.sync',
    ] as const) {
      const gate = registry[name].gate;
      expect(gate, `${name} must have a gate`).toBeDefined();
      await expect(gate?.(at)).resolves.toMatchObject({ run: false });
    }
  });

  it('leaves the always-safe maintenance jobs ungated', () => {
    const registry = createRegistry(
      containerStub({ ai: true, news: true, fundamentals: true, llm: true }),
    );
    expect(registry['signals.expire'].gate).toBeUndefined();
    expect(registry['holidays.check'].gate).toBeUndefined();
  });

  it('gates every AI job on the trading day, even with the LLM enabled', async () => {
    // A weekday holiday must not spend the LLM budget: news.sync keeps changing the retrieved
    // context, so the input hash keeps changing and the service's own cache would not stop it.
    const sessions = { sessionOn: async () => null }; // every day closed
    const registry = createRegistry(
      containerStub({ ai: true, news: true, fundamentals: true, llm: true }, sessions),
    );
    const holiday = new Date('2026-10-07T06:00:00Z'); // a Wednesday holiday in the fixture
    for (const name of ['ai.stock.analyze', 'ai.market.summary', 'ai.daily.summary'] as const) {
      await expect(registry[name].gate?.(holiday), name).resolves.toMatchObject({ run: false });
    }
  });
});
