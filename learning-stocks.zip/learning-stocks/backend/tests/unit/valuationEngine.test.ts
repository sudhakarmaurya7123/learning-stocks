import { describe, expect, it } from 'vitest';
import {
  epsHistoryFromStatements,
  valuate,
  type ValuationInput,
} from '../../src/scoring/ValuationEngine.js';
import type { DatedClose } from '../../src/technical/stats.js';

const T = { lowPctile: 30, highPctile: 70, minSectorPeers: 4 };
const days = (n: number, close: (i: number) => number, start = '2024-01-01'): DatedClose[] =>
  Array.from({ length: n }, (_, i) => ({
    date: new Date(Date.parse(`${start}T00:00:00Z`) + i * 86_400_000).toISOString().slice(0, 10),
    close: close(i),
  }));
const input = (over: Partial<ValuationInput>): ValuationInput => ({
  closes: [],
  epsHistory: [],
  snapshotPe: null,
  peerPes: [],
  thresholds: T,
  ...over,
});

describe('epsHistoryFromStatements', () => {
  it('builds TTM EPS from 4 consecutive quarters and annual EPS, each from its results date (no look-ahead)', () => {
    const quarterly = [
      { periodEnd: '2025-03-31', eps: 10 },
      { periodEnd: '2025-06-30', eps: 11 },
      { periodEnd: '2025-09-30', eps: 12 },
      { periodEnd: '2025-12-31', eps: 13 },
      { periodEnd: '2026-03-31', eps: 14 },
    ];
    const annual = [
      { periodEnd: '2025-03-31', eps: 40 },
      { periodEnd: '2024-03-31', eps: null },
    ];
    expect(epsHistoryFromStatements(quarterly, annual)).toEqual([
      { availableOn: '2025-05-30', epsTtm: 40, shares: null },
      { availableOn: '2026-02-14', epsTtm: 46, shares: null },
      { availableOn: '2026-05-15', epsTtm: 50, shares: null },
    ]);
    const withProfit = epsHistoryFromStatements(
      [],
      [{ periodEnd: '2025-03-31', eps: 40, netProfit: 4000 }],
    );
    expect(withProfit).toEqual([{ availableOn: '2025-05-30', epsTtm: 40, shares: 100 }]);
  });

  it('skips TTM windows with a missing quarter', () => {
    const gap = [
      { periodEnd: '2025-03-31', eps: 1 },
      { periodEnd: '2025-06-30', eps: 1 },
      { periodEnd: '2025-12-31', eps: 1 },
      { periodEnd: '2026-03-31', eps: 1 },
    ];
    expect(epsHistoryFromStatements(gap, [])).toEqual([]);
  });
});

describe('valuate', () => {
  const eps = [{ availableOn: '2024-01-01', epsTtm: 10, shares: null }];

  it('labels from the percentile of the current P/E in its own history', () => {
    const cheapNow = valuate(
      input({
        closes: days(300, (i) => (i < 299 ? 200 + (i % 50) : 205)),
        epsHistory: eps,
        snapshotPe: 20.5,
      }),
    );
    expect(cheapNow).toMatchObject({ currentPe: 20.5, historyPoints: 300, sectorPercentile: null });
    expect(cheapNow.ownPercentile).toBeLessThanOrEqual(30);
    expect(cheapNow.label).toBe('UNDERVALUED');
    const richNow = valuate(
      input({
        closes: days(300, (i) => (i < 299 ? 200 + (i % 50) : 248)),
        epsHistory: eps,
        snapshotPe: 24.8,
      }),
    );
    expect(richNow.label).toBe('OVERVALUED');
  });

  it('never uses EPS before it was published', () => {
    const late = [{ availableOn: '2024-06-01', epsTtm: 10, shares: null }];
    const r = valuate(input({ closes: days(300, () => 200), epsHistory: late, snapshotPe: 20 }));
    expect(r.historyPoints).toBe(300 - 152);
    expect(r.ownPercentile).toBeNull();
    expect(r.notes.join(' ')).toMatch(/history/);
  });

  it('drops own history that disagrees with the provider P/E (bonus/split basis) and says so', () => {
    const r = valuate(
      input({ closes: days(300, (i) => 200 + (i % 50)), epsHistory: eps, snapshotPe: 10 }),
    );
    expect(r.ownPercentile).toBeNull();
    expect(r.notes.join(' ')).toMatch(/disagrees/);
    expect(r.label).toBe('INSUFFICIENT_DATA');
  });

  it('drops own history when the implied share count changes (bonus/split/merger), not on organic growth', () => {
    const closes = days(300, (i) => 200 + (i % 50));
    const bonus = [
      { availableOn: '2024-01-01', epsTtm: 20, shares: 100 },
      { availableOn: '2024-06-01', epsTtm: 10.4, shares: 192 },
    ];
    const r = valuate(input({ closes, epsHistory: bonus, snapshotPe: 24 }));
    expect(r.ownPercentile).toBeNull();
    expect(r.notes.join(' ')).toMatch(/share count/);
    // EPS +55% with an unchanged share count is growth (TITAN/MARUTI-like), not a basis change.
    const growth = [
      { availableOn: '2024-01-01', epsTtm: 10, shares: 100 },
      { availableOn: '2024-06-01', epsTtm: 15.5, shares: 100 },
    ];
    expect(
      valuate(input({ closes, epsHistory: growth, snapshotPe: 16 })).ownPercentile,
    ).not.toBeNull();
  });

  it('treats a company whose earnings turned negative as INSUFFICIENT_DATA (no stale P/E)', () => {
    const turned = [
      { availableOn: '2024-01-01', epsTtm: 10, shares: null },
      { availableOn: '2024-08-01', epsTtm: -5, shares: null },
    ];
    const r = valuate(
      input({
        closes: days(300, (i) => 200 + (i % 50)),
        epsHistory: turned,
        snapshotPe: null,
        peerPes: [10, 20, 30, 40],
      }),
    );
    expect(r).toMatchObject({ currentPe: null, label: 'INSUFFICIENT_DATA' });
    expect(r.notes.join(' ')).toMatch(/positive earnings/);
  });

  it('uses sector peers only with at least 4 of them, and averages both views', () => {
    const closes = days(300, (i) => (i < 299 ? 200 + (i % 50) : 205));
    const three = valuate(
      input({ closes: days(10, () => 200), snapshotPe: 20, peerPes: [30, 40, 50] }),
    );
    expect(three).toMatchObject({
      sectorPercentile: null,
      peersUsed: 3,
      label: 'INSUFFICIENT_DATA',
    });
    const both = valuate(
      input({ closes, epsHistory: eps, snapshotPe: 20.5, peerPes: [10, 15, 30, 40] }),
    );
    expect(both.sectorPercentile).toBe(50);
    expect(both.ownPercentile).not.toBeNull();
  });

  it('falls back to the snapshot P/E without statements (INFY) and refuses non-positive earnings', () => {
    const infy = valuate(
      input({ closes: days(5, () => 1000), snapshotPe: 13.9, peerPes: [20, 25, 28, 30] }),
    );
    expect(infy).toMatchObject({ currentPe: 13.9, sectorPercentile: 0, label: 'UNDERVALUED' });
    const loss = valuate(
      input({
        closes: days(300, () => 100),
        epsHistory: [{ availableOn: '2024-01-01', epsTtm: -5, shares: null }],
        snapshotPe: null,
        peerPes: [10, 20, 30, 40],
      }),
    );
    expect(loss).toMatchObject({ currentPe: null, label: 'INSUFFICIENT_DATA' });
    expect(loss.notes.join(' ')).toMatch(/positive earnings/);
  });
});
