import { describe, expect, it } from 'vitest';
import type { RawArticle } from '../../src/providers/news/types.js';
import {
  normalizeArticles,
  type TaggedRawArticle,
} from '../../src/services/news/articleNormalizer.js';

const NOW = new Date('2026-10-05T12:00:00Z');
const ctx = { dataMode: 'LIVE' as const, now: NOW, since: new Date('2026-09-28T00:00:00Z') };
const raw = (over: Partial<RawArticle> = {}): RawArticle => ({
  title: 'Reliance Industries raises funds via bonds',
  url: 'https://www.business-standard.com/markets/news/reliance-bonds-1.html',
  description: null,
  content: null,
  author: null,
  publishedAt: new Date('2026-10-05T06:00:00Z'),
  publisherUrl: null,
  language: null,
  ...over,
});
const tag = (article: RawArticle, queriedFor: string[] = []): TaggedRawArticle => ({
  article,
  queriedFor,
});

describe('normalizeArticles', () => {
  it('keeps a valid article, deriving source from the link host and defaulting language', () => {
    const r = normalizeArticles([tag(raw())], ctx);
    expect(r.articles).toHaveLength(1);
    expect(r.articles[0]).toMatchObject({
      dataMode: 'LIVE',
      title: 'Reliance Industries raises funds via bonds',
      source: 'business-standard.com',
      sourceUrl: 'https://www.business-standard.com/markets/news/reliance-bonds-1.html',
      language: 'en',
      queriedFor: [],
    });
    expect(r.articles[0]?.contentHash).toMatch(/^[a-f0-9]{64}$/);
  });

  it('drops (never repairs) missing titles, bad URLs, missing/garbled dates, future and stale items', () => {
    const r = normalizeArticles(
      [
        tag(raw({ title: '  ' })),
        tag(raw({ url: 'ftp://x.example/a' })),
        tag(raw({ publishedAt: null })),
        tag(raw({ publishedAt: new Date('garbage') })),
        tag(raw({ publishedAt: new Date(NOW.getTime() + 10 * 60_000) })),
        tag(raw({ publishedAt: new Date('2026-09-01T00:00:00Z') })),
        tag(
          raw({
            title: 'Within tolerance',
            url: 'https://x.example/ok',
            publishedAt: new Date(NOW.getTime() + 2 * 60_000),
          }),
        ),
      ],
      ctx,
    );
    expect(r.articles.map((a) => a.title)).toEqual(['Within tolerance']);
    expect(r.dropped).toEqual({
      MISSING_TITLE: 1,
      INVALID_URL: 1,
      INVALID_DATE: 2,
      FUTURE_DATE: 1,
      TOO_OLD: 1,
    });
  });

  it('prefers the publisher URL (Google News) for source and drops a description that only repeats the title', () => {
    const r = normalizeArticles(
      [
        tag(
          raw({
            url: 'https://news.google.com/rss/articles/CBMi123?oc=5',
            publisherUrl: 'https://www.business-standard.com',
            description:
              '<a href="https://news.google.com/rss/articles/CBMi123">Reliance Industries raises funds via bonds</a>&nbsp;&nbsp;<font>Business Standard</font>',
          }),
        ),
      ],
      ctx,
    );
    expect(r.articles[0]).toMatchObject({
      source: 'business-standard.com',
      sourceUrl: 'https://news.google.com/rss/articles/CBMi123',
      description: null,
    });
    const kept = normalizeArticles(
      [
        tag(
          raw({
            description: '<p>The company raised &#8377;13,000 crore through 10-year bonds.</p>',
          }),
        ),
      ],
      ctx,
    );
    expect(kept.articles[0]?.description).toBe(
      'The company raised ₹13,000 crore through 10-year bonds.',
    );
  });

  it('merges the same story from two routes (same title + publisher + day, or same URL) and unions queriedFor', () => {
    const google = raw({
      url: 'https://news.google.com/rss/articles/A?oc=5',
      publisherUrl: 'https://www.business-standard.com',
    });
    const direct = raw({ publishedAt: new Date('2026-10-05T06:03:00Z') });
    const editedTitle = raw({ title: 'Reliance Industries raises ₹13,000 crore via bonds' });
    const r = normalizeArticles(
      [tag(google, ['RELIANCE']), tag(direct), tag(editedTitle, ['TCS'])],
      ctx,
    );
    expect(r.articles).toHaveLength(1);
    expect(r.articles[0]?.queriedFor).toEqual(['RELIANCE', 'TCS']);
    expect(r.dropped).toEqual({ DUPLICATE_IN_BATCH: 2 });
  });

  it('sorts newest first and normalises language tags', () => {
    const r = normalizeArticles(
      [
        tag(
          raw({
            title: 'Older',
            url: 'https://x.example/1',
            publishedAt: new Date('2026-10-04T06:00:00Z'),
            language: 'en-IN',
          }),
        ),
        tag(
          raw({
            title: 'Newer',
            url: 'https://x.example/2',
            publishedAt: new Date('2026-10-05T06:00:00Z'),
          }),
        ),
      ],
      ctx,
    );
    expect(r.articles.map((a) => [a.title, a.language])).toEqual([
      ['Newer', 'en'],
      ['Older', 'en'],
    ]);
  });
});
