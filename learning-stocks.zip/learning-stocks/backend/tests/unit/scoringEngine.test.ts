import { describe, expect, it } from 'vitest';
import {
  marketContextScore,
  momentumScore,
  newsScore,
  overallScore,
  qualityScore,
  riskScore,
  technicalScore,
  valuationScore,
} from '../../src/scoring/ScoringEngine.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

const tech = {
  close: 110,
  prevClose: 108,
  volume: 2000,
  volumeSma20: 1000,
  trend: 'UPTREND' as const,
  rsi14: 65,
  macd: 2,
  macdSignal: 1.5,
  adx14: 30,
};

describe('ScoringEngine', () => {
  it('technical: a strong confirmed uptrend scores 100; missing parts are dropped, not zeroed', () => {
    expect(technicalScore(tech).score).toBe(100);
    const mixed = technicalScore({
      ...tech,
      trend: 'SIDEWAYS',
      macd: 1,
      macdSignal: 1.5,
      rsi14: 50,
      adx14: null,
      volumeSma20: null,
    });
    expect(mixed.score).toBe(52);
    expect(mixed.components).toMatchObject({
      trend: 50,
      macd: 35,
      rsi: 72.5,
      adx: null,
      volume: null,
    });
    expect(
      technicalScore({
        ...tech,
        trend: null,
        macd: null,
        macdSignal: null,
        rsi14: null,
        adx14: null,
        volumeSma20: null,
      }).score,
    ).toBeNull();
  });

  it('quality: ROE, leverage, margin trend and growth consistency; banks are exempt from D/E', () => {
    const q = {
      roe: 18,
      roce: null,
      debtToEquity: 0.5,
      isFinancial: false,
      netMargins: [10, 12],
      revenueGrowth: [5, 10, -2, 8],
      profitGrowth: [3, 12, 5, 9],
    };
    expect(qualityScore(q).score).toBe(83.82);
    expect(qualityScore({ ...q, isFinancial: true }).components.debtToEquity).toBeNull();
  });

  it('valuation: cheaper vs history and peers scores higher; earnings yield counts', () => {
    expect(valuationScore({ ownPercentile: 20, sectorPercentile: null, currentPe: 20 }).score).toBe(
      70,
    );
    expect(
      valuationScore({ ownPercentile: null, sectorPercentile: null, currentPe: null }).score,
    ).toBeNull();
  });

  it('news: relevance-weighted, recency-decayed mean sentiment (half-life)', () => {
    const now = new Date('2026-10-06T00:00:00Z');
    const pts = [
      { sentimentScore: 80, relevance: 1, publishedAt: now },
      { sentimentScore: 20, relevance: 1, publishedAt: new Date(now.getTime() - 7 * 86_400_000) },
    ];
    expect(newsScore(pts, now, 7).score).toBe(60);
    expect(newsScore([], now, 7).score).toBeNull();
  });

  it('momentum and market context map returns, relative strength, regime and VIX', () => {
    expect(
      momentumScore({ return1m: 7.5, return3m: 0, return6m: -35, rsVsNifty: 10, rsVsSector: null })
        .score,
    ).toBe(45.59);
    expect(marketContextScore({ regime: 'RISK_ON', sectorTrend: null, vix: 15 }).score).toBe(91.67);
  });

  it('overall: renormalises weights over available factors and reports coverage', () => {
    const r = overallScore(
      {
        technical: 80,
        quality: null,
        valuation: 60,
        news: null,
        momentum: 40,
        market_context: 100,
      },
      SEED_CONFIG.weights,
    );
    expect(r).toEqual({
      overall: 72.86,
      available: ['technical', 'valuation', 'momentum', 'market_context'],
      coverage: 0.7,
    });
    expect(
      overallScore(
        {
          technical: null,
          quality: null,
          valuation: null,
          news: null,
          momentum: null,
          market_context: null,
        },
        SEED_CONFIG.weights,
      ).overall,
    ).toBeNull();
  });

  it('risk: volatility, beta, drawdown and stop distance map to a level', () => {
    const calm = riskScore({ atrPct: 2, beta: 1, maxDrawdownPct: 20, stopDistancePct: null });
    expect(calm).toMatchObject({ score: 38.13, level: 'MEDIUM' });
    expect(
      riskScore({ atrPct: 5, beta: 2, maxDrawdownPct: 50, stopDistancePct: 15 }),
    ).toMatchObject({ score: 91.25, level: 'VERY_HIGH' });
    expect(
      riskScore({ atrPct: null, beta: null, maxDrawdownPct: null, stopDistancePct: null }),
    ).toMatchObject({ score: null, level: null });
  });
});
