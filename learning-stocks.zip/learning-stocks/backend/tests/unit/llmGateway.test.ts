import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { LlmGateway } from '../../src/ai/LlmGateway.js';
import type { RenderedPrompt } from '../../src/ai/promptLoader.js';
import type {
  EmbeddingResult,
  LLMProvider,
  StructuredRequest,
  StructuredResult,
} from '../../src/providers/llm/types.js';
import type { LlmCallRecord } from '../../src/repositories/LlmCallRepository.js';
import { AppError } from '../../src/utils/errors.js';

const Out = z.object({ text: z.string() });
type O = z.infer<typeof Out>;
const PROMPT: RenderedPrompt = {
  version: 'stock_qa_v1',
  templateHash: 'h',
  system: 'SYS',
  user: 'USER',
};

class ScriptedProvider implements LLMProvider {
  readonly name = 'openai';
  readonly chatModel = 'gpt-5-mini';
  responseModel = 'gpt-5-mini-2025-08-07';
  readonly embeddingModel = 'e';
  readonly embeddingDimensions = 1536;
  users: string[] = [];
  constructor(private readonly script: Array<O | AppError>) {}
  async completeStructured<T>(req: StructuredRequest<T>): Promise<StructuredResult<T>> {
    this.users.push(req.user);
    const next = this.script.shift();
    if (!next) throw new Error('script exhausted');
    if (next instanceof AppError) throw next;
    return {
      data: req.schema.parse(next),
      model: this.responseModel,
      usage: { inputTokens: 1000, outputTokens: 500 },
      latencyMs: 5,
    };
  }
  async embed(): Promise<EmbeddingResult> {
    throw new Error('unused');
  }
}

function gateway(script: Array<O | AppError>, budgetFailsOnCall?: number) {
  const rows: LlmCallRecord[] = [];
  let ensures = 0;
  const provider = new ScriptedProvider(script);
  const g = new LlmGateway({
    provider,
    llmCalls: {
      record: async (r) => {
        rows.push(r);
        return 'id';
      },
    },
    budget: {
      ensure: async () => {
        ensures += 1;
        if (ensures === budgetFailsOnCall) throw new AppError('BUDGET_EXCEEDED', 'budget');
      },
    },
    usdInrRate: 88,
    priceOverride: null,
    retry: { sleep: async () => undefined },
  });
  return { g, rows, provider, ensures: () => ensures };
}

const call = (validate?: (d: O) => string[]) => ({
  purpose: 'stock_qa',
  prompt: PROMPT,
  schema: Out,
  schemaName: 'stock_qa',
  maxOutputTokens: 800,
  ...(validate ? { validate } : {}),
});

describe('LlmGateway', () => {
  it('returns a valid first answer, recording one OK row with the ₹ cost of the dated snapshot', async () => {
    const { g, rows } = gateway([{ text: 'fine' }]);
    const r = await g.complete(call());
    expect(r).toMatchObject({
      data: { text: 'fine' },
      attempts: 1,
      model: 'gpt-5-mini-2025-08-07',
    });
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({
      status: 'OK',
      purpose: 'stock_qa',
      promptVersion: 'stock_qa_v1',
      inputTokens: 1000,
      outputTokens: 500,
    });
    expect(rows[0]?.estCostInr).toBeCloseTo(((1000 * 0.25 + 500 * 2) / 1e6) * 88, 4);
  });

  it('repairs once with the issues in the prompt, then succeeds', async () => {
    const { g, rows, provider } = gateway([{ text: 'bad' }, { text: 'good' }]);
    const r = await g.complete(
      call((d) => (d.text === 'bad' ? ['banned phrase "guaranteed"'] : [])),
    );
    expect(r).toMatchObject({ data: { text: 'good' }, attempts: 2 });
    expect(rows.map((x) => x.status)).toEqual(['INVALID_OUTPUT', 'OK']);
    expect(provider.users[1]).toContain('USER');
    expect(provider.users[1]).toContain('- banned phrase "guaranteed"');
  });

  it('gives up after one repair', async () => {
    const { g, rows } = gateway([{ text: 'bad' }, { text: 'bad' }]);
    await expect(g.complete(call(() => ['still wrong']))).rejects.toMatchObject({
      code: 'INVALID_RESPONSE',
      details: { issues: ['still wrong'] },
    });
    expect(rows.map((x) => x.status)).toEqual(['INVALID_OUTPUT', 'INVALID_OUTPUT']);
  });

  it('repairs a schema failure from the provider and records its token usage', async () => {
    const schemaFail = new AppError('INVALID_RESPONSE', 'Model output does not match stock_qa', {
      details: {
        raw: '{"text":1}',
        issues: ['text: expected string'],
        usage: { inputTokens: 900, outputTokens: 100 },
      },
    });
    const { g, rows } = gateway([schemaFail, { text: 'ok' }]);
    await expect(g.complete(call())).resolves.toMatchObject({ attempts: 2 });
    expect(rows[0]).toMatchObject({
      status: 'INVALID_OUTPUT',
      inputTokens: 900,
      outputTokens: 100,
    });
    expect(rows[0]?.estCostInr).toBeGreaterThan(0);
  });

  it('does not repair transport or auth failures', async () => {
    const { g, rows } = gateway([new AppError('AUTH_FAILED', 'quota')]);
    await expect(g.complete(call())).rejects.toMatchObject({ code: 'AUTH_FAILED' });
    expect(rows.map((x) => x.status)).toEqual(['FAILED']);
  });

  it('retries transient errors before counting an attempt', async () => {
    const { g, rows } = gateway([new AppError('TIMEOUT', 'slow'), { text: 'ok' }]);
    await expect(g.complete(call())).resolves.toMatchObject({ attempts: 1 });
    expect(rows.map((x) => x.status)).toEqual(['OK']);
  });

  it('checks the budget before every attempt, including the repair', async () => {
    const { g, provider, ensures } = gateway([{ text: 'bad' }, { text: 'good' }], 2);
    await expect(g.complete(call((d) => (d.text === 'bad' ? ['x'] : [])))).rejects.toMatchObject({
      code: 'BUDGET_EXCEEDED',
    });
    expect(ensures()).toBe(2);
    expect(provider.users).toHaveLength(1);
  });

  it('refuses to silently price an unknown model at zero (the budget would stop protecting spend)', async () => {
    const { g, provider } = gateway([{ text: 'fine' }]);
    provider.responseModel = 'gpt-9-unreleased-2027-01-01';
    await expect(g.complete(call())).rejects.toMatchObject({
      code: 'INTERNAL',
      details: { model: 'gpt-9-unreleased-2027-01-01' },
    });
  });
});
