import { describe, expect, it } from 'vitest';
import type { TradingSession, TradingSessions } from '../../src/domain/types.js';
import { nextSessionClose, signalFor } from '../../src/services/ai/TradeSignalService.js';

describe('signalFor', () => {
  it('maps PRD §8.5 action states to paper signals', () => {
    expect(signalFor('BUY_ZONE')).toBe('BUY');
    expect(signalFor('REDUCE')).toBe('SELL');
    for (const s of [
      'WAIT_FOR_PULLBACK',
      'WAIT_FOR_CONFIRMATION',
      'HOLD',
      'AVOID',
      'INSUFFICIENT_DATA',
    ] as const)
      expect(signalFor(s)).toBeNull();
  });
});

describe('nextSessionClose', () => {
  it('skips holidays and weekends', async () => {
    const sessions: TradingSessions = {
      hasCalendar: async () => true,
      sessionOn: async (_e, date): Promise<TradingSession | null> =>
        date === '2026-10-08'
          ? { open: new Date('2026-10-08T03:45:00Z'), close: new Date('2026-10-08T10:00:00Z') }
          : null,
    };
    expect(await nextSessionClose(sessions, 'NSE', new Date('2026-10-05T03:45:00Z'))).toEqual(
      new Date('2026-10-08T10:00:00Z'),
    );
  });
});
