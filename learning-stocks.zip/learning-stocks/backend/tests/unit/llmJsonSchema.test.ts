import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { toStrictJsonSchema } from '../../src/providers/llm/jsonSchema.js';
import { sampleFromJsonSchema } from '../../src/providers/llm/mock/sample.js';

const Analysis = z.object({
  sentiment: z.enum(['BULLISH', 'NEUTRAL', 'BEARISH']),
  confidence: z.number().int().min(0).max(100),
  target: z.number().nullable(),
  facts: z.array(z.object({ statement: z.string(), source_ids: z.array(z.string()) })),
  summary: z.string().min(10),
});

describe('toStrictJsonSchema', () => {
  it('closes every object, requires every property and drops $schema', () => {
    const s = toStrictJsonSchema(Analysis);
    expect(s.$schema).toBeUndefined();
    expect(s).toMatchObject({
      type: 'object',
      additionalProperties: false,
      required: ['sentiment', 'confidence', 'target', 'facts', 'summary'],
    });
    expect(s).toHaveProperty('properties.facts.items.additionalProperties', false);
    // zod emits nullable primitives as a type array; OpenAI strict mode accepts it.
    expect(s).toHaveProperty('properties.target.type', ['number', 'null']);
  });

  it('rejects optional properties and open records (strict mode forbids them)', () => {
    expect(() =>
      toStrictJsonSchema(z.object({ a: z.object({ b: z.string().optional() }) })),
    ).toThrow(/\$\.a\.b is optional/);
    expect(() => toStrictJsonSchema(z.object({ m: z.record(z.string(), z.number()) }))).toThrow(
      /\$\.m is an open object/,
    );
  });
});

describe('sampleFromJsonSchema', () => {
  it('produces a value the zod schema accepts', () => {
    const sample = sampleFromJsonSchema(toStrictJsonSchema(Analysis));
    expect(Analysis.safeParse(sample).success).toBe(true);
    expect(sample).toMatchObject({ sentiment: 'BULLISH', confidence: 50, target: 50, facts: [] });
  });

  it('honours bounds and minItems', () => {
    const S = z.object({
      low: z.number().int().min(60).max(90),
      xs: z.array(z.number().max(10)).min(2),
    });
    expect(sampleFromJsonSchema(toStrictJsonSchema(S))).toEqual({ low: 60, xs: [10, 10] });
  });
});
