import { Writable } from 'node:stream';
import { describe, expect, it } from 'vitest';
import { createLogger } from '../../src/utils/logger.js';

function capture() {
  const lines: string[] = [];
  const destination = new Writable({
    write(chunk, _enc, cb) {
      lines.push(String(chunk));
      cb();
    },
  });
  return { lines, destination };
}

describe('createLogger', () => {
  it('writes structured JSON and redacts secrets', () => {
    const { lines, destination } = capture();
    const logger = createLogger({ level: 'info', destination });
    logger.info(
      {
        apiKey: 'k-123',
        config: { secrets: { openaiApiKey: 'sk-abc' } },
        req: { headers: { authorization: 'Bearer t' } },
      },
      'hello',
    );
    const out = lines.join('');
    expect(out).toContain('"msg":"hello"');
    expect(out).not.toContain('k-123');
    expect(out).not.toContain('sk-abc');
    expect(out).not.toContain('Bearer t');
    expect(out).toContain('[REDACTED]');
  });

  it('redacts API-key headers', () => {
    const { lines, destination } = capture();
    createLogger({ level: 'info', destination }).info(
      { headers: { 'x-api-key': 'nk-1' }, request: { headers: { 'x-api-key': 'nk-2' } } },
      'outbound',
    );
    const out = lines.join('');
    expect(out).not.toContain('nk-1');
    expect(out).not.toContain('nk-2');
  });

  it('respects the level', () => {
    const { lines, destination } = capture();
    createLogger({ level: 'warn', destination }).info('quiet');
    expect(lines).toHaveLength(0);
  });
});
