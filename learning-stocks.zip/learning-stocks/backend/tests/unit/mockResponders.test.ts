import { describe, expect, it } from 'vitest';
import { mockResponders } from '../../src/ai/mockResponders.js';
import {
  bannedPhraseIssues,
  biasIssues,
  citationIssues,
  unknownRupeeIssues,
} from '../../src/ai/outputGuards.js';
import {
  MarketSummarySchema,
  NewsSentimentSchema,
  QaAnswerSchema,
  StockAnalysisSchema,
  TradeSignalNarrativeSchema,
} from '../../src/ai/schemas.js';
import { MockLLMProvider } from '../../src/providers/llm/mock/MockLLMProvider.js';

const p = new MockLLMProvider({ responders: mockResponders() });
const CONTEXT = [
  'CONTEXT for RELIANCE (Reliance Industries Ltd; NSE; sector Energy) [MOCK data]',
  'Missing (INSUFFICIENT_DATA): previous analysis',
  '[Q1] QUOTE (as of close of session 2026-10-05)',
  '- Last price ₹1,186.40 (+0.52% vs previous close; 1d bar; source mock)',
  '[E1] EVALUATION AND LEVELS (computed) (as of close of session 2026-10-05)',
  '- Action state (computed; explain, never change): AVOID; bias SELL_BIAS',
  '[M1] MARKET CONTEXT (computed) (as of close of session 2026-10-05)',
  '- Regime RISK_OFF; NIFTY 50 trend DOWNTREND; India VIX 21.40; sector trend n/a',
  '[N1] DOCUMENT: NEWS (as of 2026-10-04 10:30 IST)',
].join('\n');
const ISSUED = new Set(['Q1', 'E1', 'M1', 'N1']);
const clean = (out: unknown, facts: Array<{ statement: string; source_ids: string[] }>) => [
  ...bannedPhraseIssues(out),
  ...unknownRupeeIssues(out, CONTEXT),
  ...citationIssues(facts, out, ISSUED),
];

describe('mockResponders', () => {
  it('stock analysis agrees with the computed bias, cites issued IDs only and passes every guard', async () => {
    const r = await p.completeStructured({
      system: 's',
      user: CONTEXT,
      schema: StockAnalysisSchema,
      schemaName: 'stock_analysis',
    });
    expect(r.data.sentiment).toBe('BEARISH');
    expect(biasIssues(r.data.sentiment, 'SELL_BIAS')).toEqual([]);
    expect(clean(r.data, r.data.facts)).toEqual([]);
    expect(r.data.summary).toContain('[MOCK]');
    expect(r.data.insufficient_data).toEqual(['[MOCK] previous analysis']);
  });

  it('news sentiment follows the article wording', async () => {
    const run = async (article: string) =>
      (
        await p.completeStructured({
          system: 's',
          user: `Subject: Reliance Industries Ltd (RELIANCE)\n\n<<<BEGIN ARTICLE>>>\n${article}\n<<<END ARTICLE>>>`,
          schema: NewsSentimentSchema,
          schemaName: 'news_sentiment',
        })
      ).data;
    expect((await run('Reliance shares rise after strong results')).sentiment).toBe('BULLISH');
    expect((await run('Reliance falls after a regulatory query')).sentiment).toBe('BEARISH');
    expect((await run('Reliance holds annual general meeting')).sentiment).toBe('NEUTRAL');
  });

  it('market summary, trade signal and Q&A pass every guard', async () => {
    const m = (
      await p.completeStructured({
        system: 's',
        user: CONTEXT,
        schema: MarketSummarySchema,
        schemaName: 'market_summary',
      })
    ).data;
    expect(m.sentiment).toBe('BEARISH');
    expect(m.sectors_positive).toEqual([]);
    expect(clean(m, m.facts)).toEqual([]);
    const t = (
      await p.completeStructured({
        system: 's',
        user: `Signal decided by code: SELL\n\n${CONTEXT}`,
        schema: TradeSignalNarrativeSchema,
        schemaName: 'trade_signal',
      })
    ).data;
    expect(clean(t, t.facts)).toEqual([]);
    const q = (
      await p.completeStructured({
        system: 's',
        user: `<<<BEGIN QUESTION>>>\nWhat drives it?\n<<<END QUESTION>>>\n\n${CONTEXT}`,
        schema: QaAnswerSchema,
        schemaName: 'stock_qa',
      })
    ).data;
    expect(q.answer).toContain('[MOCK]');
    expect(clean(q, q.facts)).toEqual([]);
  });
});
