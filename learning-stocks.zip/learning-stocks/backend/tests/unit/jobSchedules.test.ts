import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { DEFAULT_SCHEDULES, loadSchedules } from '../../src/jobs/schedules.js';
import { JOB_NAMES } from '../../src/jobs/types.js';

/** Minimal settings stand-in: get(key, schema) is the whole surface loadSchedules uses. */
function settingsWith(value: unknown) {
  return {
    get: async <T>(key: string, schema: z.ZodType<T>): Promise<T | null> =>
      key === 'job_schedules' && value !== undefined ? schema.parse(value) : null,
  };
}

describe('DEFAULT_SCHEDULES', () => {
  it('only schedules known jobs, and leaves chained jobs unscheduled', () => {
    const scheduled = new Set(DEFAULT_SCHEDULES.map((s) => s.name));
    for (const s of DEFAULT_SCHEDULES) expect(JOB_NAMES).toContain(s.name);
    // Chained-only jobs must have no cron of their own, or they would run on empty inputs.
    for (const chained of [
      'evaluation.compute',
      'embeddings.generate',
      'news.sentiment',
      'signals.generate',
    ])
      expect(scheduled.has(chained as never)).toBe(false);
  });

  it('schedules every job the PRD gives a time', () => {
    expect([...new Set(DEFAULT_SCHEDULES.map((s) => s.name))].sort()).toEqual([
      'ai.daily.summary',
      'ai.market.summary',
      'ai.stock.analyze',
      'fundamentals.sync',
      'holidays.check',
      'market.sync.eod',
      'market.sync.intraday',
      'news.sync',
      'signals.expire',
    ]);
  });

  it('recovers a missed daily or weekly run, but never backfills a 5-minute tick', () => {
    const byName = (n: string) => DEFAULT_SCHEDULES.filter((s) => s.name === n);
    for (const n of ['market.sync.eod', 'fundamentals.sync', 'ai.daily.summary', 'holidays.check'])
      expect(byName(n).every((s) => s.missed === 'once')).toBe(true);
    for (const n of ['market.sync.intraday', 'news.sync', 'signals.expire', 'ai.stock.analyze'])
      expect(byName(n).every((s) => s.missed === 'skip')).toBe(true);
  });
});

describe('one schedule entry per job', () => {
  it('never lists a job twice: pg-boss keys on (name, key) and would keep only the last', () => {
    const names = DEFAULT_SCHEDULES.map((s) => s.name);
    expect(names).toHaveLength(new Set(names).size);
  });
});

describe('cron windows (IST)', () => {
  // Asserted against pg-boss's own parser, on an unstarted instance (no connection needed), so
  // the test fails if an expression drifts rather than months later in production.
  const ist = (d: Date) =>
    new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Kolkata',
      timeStyle: 'short',
      hour12: false,
    }).format(d);
  const preview = async (name: string, from: Date, count: number) => {
    const { PgBoss } = await import('pg-boss');
    const boss = new PgBoss('postgresql://unused/unused');
    const entry = DEFAULT_SCHEDULES.find((s) => s.name === name);
    if (!entry) throw new Error(`no schedule for ${name}`);
    return boss.previewSchedule(entry.cron, { tz: 'Asia/Kolkata', from, count }).map(ist);
  };

  it('ticks the intraday sync every 5 minutes across the session', async () => {
    // from = 2026-10-06T02:00:00Z = 07:30 IST, a Tuesday morning before the open.
    // 09:00 and 09:10 are before the open; the gate skips them (see jobGates.test.ts).
    const times = await preview('market.sync.intraday', new Date('2026-10-06T02:00:00Z'), 4);
    expect(times).toEqual(['09:00', '09:05', '09:10', '09:15']);
  });

  it('includes the 15:30 IST tick that collects the final completed bar', async () => {
    // from = 2026-10-06T09:50:00Z = 15:20 IST.
    const times = await preview('market.sync.intraday', new Date('2026-10-06T09:50:00Z'), 3);
    expect(times).toContain('15:30');
  });

  it('runs EOD after the 30-minute settle window, not on its boundary', async () => {
    expect((await preview('market.sync.eod', new Date('2026-10-06T02:00:00Z'), 1))[0]).toBe(
      '16:05',
    );
  });
});

describe('loadSchedules', () => {
  it('returns the defaults when app_settings has no override', async () => {
    expect(await loadSchedules(settingsWith(undefined))).toEqual(DEFAULT_SCHEDULES);
  });

  it('replaces the cron of a named job and leaves the rest alone', async () => {
    const loaded = await loadSchedules(settingsWith({ 'news.sync': '*/20 * * * *' }));
    expect(loaded.find((s) => s.name === 'news.sync')?.cron).toBe('*/20 * * * *');
    expect(loaded.find((s) => s.name === 'signals.expire')).toEqual(
      DEFAULT_SCHEDULES.find((s) => s.name === 'signals.expire'),
    );
  });

  it('disables a job when its override is null, and rejects an unknown job name', async () => {
    const loaded = await loadSchedules(settingsWith({ 'news.sync': null }));
    expect(loaded.some((s) => s.name === 'news.sync')).toBe(false);
    await expect(loadSchedules(settingsWith({ 'not.a.job': '* * * * *' }))).rejects.toThrow();
  });
});
