import { describe, expect, it } from 'vitest';
import {
  fitMetrics,
  fitNumeric,
  SNAPSHOT_COLUMNS,
} from '../../src/services/fundamentals/numeric.js';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';

describe('fitNumeric', () => {
  it('rounds to the column scale and nulls what would overflow or is not finite', () => {
    expect(fitNumeric(21.48497, 10, 2)).toBe(21.48);
    expect(fitNumeric(99_999_999.99, 10, 2)).toBe(99_999_999.99);
    expect(fitNumeric(100_000_000, 10, 2)).toBeNull();
    expect(fitNumeric(-1e12, 10, 2)).toBeNull();
    expect(fitNumeric(Number.NaN, 8, 2)).toBeNull();
    expect(fitNumeric(Number.POSITIVE_INFINITY, 8, 2)).toBeNull();
    expect(fitNumeric(null, 8, 2)).toBeNull();
  });

  it('fits every snapshot field and reports which ones were out of range', () => {
    const r = fitMetrics(
      { ...emptySnapshotMetrics(), pe: 1e12, beta: Number.NaN, roe: 13.838 },
      SNAPSHOT_COLUMNS,
    );
    expect(r.metrics).toMatchObject({ pe: null, beta: null, roe: 13.84 });
    expect(r.outOfRange.sort()).toEqual(['beta', 'pe']);
  });
});
