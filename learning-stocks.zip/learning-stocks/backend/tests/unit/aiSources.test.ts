import { describe, expect, it } from 'vitest';
import { citedIds, sourcesFor } from '../../src/ai/sources.js';
import type { ContextBlock } from '../../src/rag/contextBuilder.js';
import type { RankedDocument } from '../../src/rag/retriever.js';

const blocks: ContextBlock[] = [
  {
    id: 'E1',
    kind: 'EVALUATION',
    title: 'EVALUATION AND LEVELS (computed)',
    asOf: new Date('2026-10-05T03:45:00Z'),
    asOfMode: 'session',
    lines: [],
  },
  {
    id: 'N1',
    kind: 'DOCUMENT',
    title: 'DOCUMENT: NEWS',
    asOf: new Date('2026-10-04T05:00:00Z'),
    asOfMode: 'instant',
    lines: [],
  },
];
const doc = {
  id: 'd',
  sourceType: 'NEWS',
  sourceId: 's',
  stockId: 'x',
  content: 'c',
  publishedAt: null,
  similarity: 1,
  recency: 1,
  relevance: 1,
  score: 1,
  metadata: { title: 'Reliance wins order', sourceUrl: 'https://example.com/a' },
} as RankedDocument;

describe('sources', () => {
  it('collects cited IDs from facts and inline brackets, in context order', () => {
    expect(citedIds({ s: 'see [N1, E1]' }, [{ statement: 'x', source_ids: ['E1'] }])).toEqual([
      'E1',
      'N1',
    ]);
  });

  it('describes each cited block, with title and URL for retrieved documents; unknown IDs are dropped', () => {
    expect(sourcesFor(['E1', 'N1', 'X9'], blocks, [doc])).toEqual([
      {
        id: 'E1',
        kind: 'EVALUATION',
        title: 'EVALUATION AND LEVELS (computed)',
        asOf: '2026-10-05T03:45:00.000Z',
        url: null,
      },
      {
        id: 'N1',
        kind: 'DOCUMENT',
        title: 'Reliance wins order',
        asOf: '2026-10-04T05:00:00.000Z',
        url: 'https://example.com/a',
      },
    ]);
  });
});
