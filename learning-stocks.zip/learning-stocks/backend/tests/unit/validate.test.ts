import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { parseBody, parseQuery } from '../../src/http/validate.js';

describe('request validation', () => {
  it('returns typed values on success, coercing query strings', () => {
    const q = parseQuery(z.object({ limit: z.coerce.number().int().min(1).max(100).default(20) }), {
      limit: '50',
    });
    expect(q).toEqual({ limit: 50 });
  });

  it('rejects a bad value as VALIDATION with the field path in details', () => {
    try {
      parseBody(z.object({ question: z.string().min(1).max(500) }), { question: '' });
      throw new Error('expected parseBody to throw');
    } catch (error) {
      expect(error).toMatchObject({ code: 'VALIDATION', httpStatus: 400 });
      expect(JSON.stringify((error as { details?: unknown }).details)).toMatch(/question/);
    }
  });

  it('rejects an unknown key rather than ignoring it', () => {
    // Silently dropping a misspelled filter would make the API lie about what it applied.
    expect(() => parseQuery(z.object({ sector: z.string() }).strict(), { secter: 'it' })).toThrow();
  });
});
