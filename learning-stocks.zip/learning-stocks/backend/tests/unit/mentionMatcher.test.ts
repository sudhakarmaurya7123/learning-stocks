import { describe, expect, it } from 'vitest';
import {
  coreCompanyName,
  type MatchSubject,
  MentionMatcher,
  QUERY_ONLY_RELEVANCE,
  ROUNDUP_BODY_CAP,
} from '../../src/services/news/mentionMatcher.js';

const stock = (symbol: string, name: string, aliases: string[] = []): MatchSubject => ({
  ref: { kind: 'stock', id: `s-${symbol}` },
  symbol,
  name: coreCompanyName(name),
  aliases,
});
const market = (symbol: string, name: string, aliases: string[]): MatchSubject => ({
  ref: { kind: 'market', id: `m-${symbol}` },
  symbol,
  name,
  aliases,
});

const matcher = new MentionMatcher([
  stock('RELIANCE', 'Reliance Industries Limited', ['RIL']),
  stock('TCS', 'Tata Consultancy Services Limited', ['Tata Consultancy']),
  stock('INFY', 'Infosys Limited'),
  stock('WIPRO', 'Wipro Limited'),
  stock('HCLTECH', 'HCL Technologies Limited', ['HCLTech', 'HCL Tech']),
  stock('SBIN', 'State Bank of India', ['SBI']),
  stock('LT', 'Larsen & Toubro Limited', ['L&T', 'Larsen and Toubro']),
  stock('ITC', 'ITC Limited'),
  stock('HDFCBANK', 'HDFC Bank Limited'),
  stock('SUNPHARMA', 'Sun Pharmaceutical Industries Limited', ['Sun Pharma']),
  market('NIFTY50', 'NIFTY 50', ['Nifty 50', 'Nifty50', 'Nifty']),
  market('BANKNIFTY', 'NIFTY BANK', ['Nifty Bank', 'Bank Nifty']),
  market('SENSEX', 'SENSEX', ['Sensex', 'BSE Sensex']),
]);
const title = (t: string) => ({ title: t, description: null, content: null });
const brief = (r: ReturnType<MentionMatcher['match']>) =>
  r.map((m) => [m.symbol, m.relevance, m.matchedBy]);

describe('coreCompanyName', () => {
  it('strips legal suffixes only', () => {
    expect(coreCompanyName('Reliance Industries Limited')).toBe('Reliance Industries');
    expect(coreCompanyName('Foo Ltd.')).toBe('Foo');
    expect(coreCompanyName('State Bank of India')).toBe('State Bank of India');
  });
});

describe('MentionMatcher', () => {
  it('keeps numbers after a name unless they name another index (review finding 1)', () => {
    expect(brief(matcher.match(title('Sensex 500-point rally lifts sentiment')))).toEqual([
      ['SENSEX', 0.9, 'alias:title'],
    ]);
    expect(brief(matcher.match(title('Nifty 200-day moving average holds')))).toEqual([
      ['NIFTY50', 0.9, 'alias:title'],
    ]);
    expect(
      brief(matcher.match(title('Reliance Industries 500 crore investment in green energy'))),
    ).toEqual([['RELIANCE', 1, 'name:title']]);
    expect(brief(matcher.match(title('HDFC Bank 100 crore penalty')))).toEqual([
      ['HDFCBANK', 1, 'name:title'],
    ]);
    expect(matcher.match(title('Nifty 500 index rebalanced'))).toEqual([]);
  });

  it('does not attach separately listed look-alikes (review finding 2)', () => {
    expect(matcher.match(title('L&T Technology Services Q2 results beat estimates'))).toEqual([]);
    expect(matcher.match(title('Larsen & Toubro Infotech merger completed'))).toEqual([]);
    expect(matcher.match(title('SBI Funds Management IPO opens'))).toEqual([]);
    expect(matcher.match(title('ITC Infotech acquisition announced'))).toEqual([]);
    expect(matcher.match(title('Sun Pharma Advanced Research Company shares surge'))).toEqual([]);
    expect(matcher.match(title('SBI LIFE SHARES RISE'))).toEqual([]);
    expect(brief(matcher.match(title('SBI RAISES LENDING RATES')))).toEqual([
      ['SBIN', 0.9, 'alias:title'],
    ]);
  });

  it('does not read tax acronyms as company names (review finding 3)', () => {
    expect(matcher.match(title('Govt tweaks TDS/TCS rules for NRIs'))).toEqual([]);
    expect(matcher.match(title('GST council restricts ITC claims on inputs'))).toEqual([]);
    expect(brief(matcher.match(title('ITC shares rally after GST cut')))).toEqual([
      ['ITC', 1, 'name:title'],
    ]);
    expect(brief(matcher.match(title('TCS rallies on deal win')))).toEqual([
      ['TCS', 0.85, 'symbol:title'],
    ]);
  });

  it('scores a company name in the title highest', () => {
    expect(brief(matcher.match(title('Reliance Industries Q2 profit rises')))).toEqual([
      ['RELIANCE', 1, 'name:title'],
    ]);
    expect(brief(matcher.match(title('RELIANCE INDUSTRIES shares climb')))).toEqual([
      ['RELIANCE', 1, 'name:title'],
    ]);
  });

  it('matches acronyms case-sensitively and only as whole words', () => {
    expect(brief(matcher.match(title('RIL shares gain')))).toEqual([
      ['RELIANCE', 0.9, 'alias:title'],
    ]);
    expect(matcher.match(title('ril and April outlook'))).toEqual([]);
    expect(brief(matcher.match(title("Infosys's guidance disappoints")))).toEqual([
      ['INFY', 1, 'name:title'],
    ]);
  });

  it('handles L&T and excludes group companies named by a following word', () => {
    expect(brief(matcher.match(title('L&T bags mega order')))).toEqual([
      ['LT', 0.9, 'alias:title'],
    ]);
    expect(brief(matcher.match(title('Larsen & Toubro wins contract')))).toEqual([
      ['LT', 1, 'name:title'],
    ]);
    expect(matcher.match(title('L&T Finance raises funds'))).toEqual([]);
    expect(matcher.match(title('SBI Life shares fall'))).toEqual([]);
    expect(matcher.match(title('ITC Hotels lists on exchanges'))).toEqual([]);
    expect(brief(matcher.match(title('SBI raises lending rates')))).toEqual([
      ['SBIN', 0.9, 'alias:title'],
    ]);
  });

  it('lets the longest overlapping name win and ignores other index names', () => {
    expect(brief(matcher.match(title('Nifty Bank hits record high')))).toEqual([
      ['BANKNIFTY', 0.9, 'alias:title'],
    ]);
    expect(brief(matcher.match(title('Nifty, Sensex end higher')))).toEqual([
      ['NIFTY50', 0.9, 'alias:title'],
      ['SENSEX', 0.9, 'alias:title'],
    ]);
    expect(matcher.match(title('Nifty Midcap index slips'))).toEqual([]);
    expect(matcher.match(title('Nifty 500 index rebalanced'))).toEqual([]);
  });

  it('does not let everyday words after a name suppress a real mention (recall)', () => {
    expect(brief(matcher.match(title('Nifty next week: support seen near key level')))).toEqual([
      ['NIFTY50', 0.9, 'alias:title'],
    ]);
    expect(brief(matcher.match(title('Sensex 500 points higher in early trade')))).toEqual([
      ['SENSEX', 0.9, 'alias:title'],
    ]);
    expect(brief(matcher.match(title('RIL oil-to-chemicals unit expands')))).toEqual([
      ['RELIANCE', 0.9, 'alias:title'],
    ]);
    expect(brief(matcher.match(title('Reliance Industries capital expenditure to rise')))).toEqual([
      ['RELIANCE', 1, 'name:title'],
    ]);
    expect(
      brief(matcher.match(title('Larsen & Toubro Finance arm unaffected; L&T order book grows'))),
    ).toEqual([['LT', 0.9, 'alias:title']]);
  });

  it('weights description and content lower, with a small bonus for repeats', () => {
    expect(
      brief(
        matcher.match({
          title: 'Tech stocks rally',
          description: 'Infosys led gains.',
          content: null,
        }),
      ),
    ).toEqual([['INFY', 0.75, 'name:description']]);
    expect(
      brief(
        matcher.match({ title: 'Tech stocks rally', description: null, content: 'Wipro rose.' }),
      ),
    ).toEqual([['WIPRO', 0.6, 'name:content']]);
    expect(
      brief(
        matcher.match({
          title: 'Tech stocks rally',
          description: 'Infosys rose. Analysts like Infosys.',
          content: null,
        }),
      ),
    ).toEqual([['INFY', 0.8, 'name:description']]);
  });

  it('caps body-only mentions in roundup articles below the sentiment threshold', () => {
    const roundup = matcher.match({
      title: 'Top IT gainers today',
      description: 'Infosys, Wipro, HCLTech and TCS led gains.',
      content: null,
    });
    expect(roundup.map((m) => m.relevance)).toEqual([
      ROUNDUP_BODY_CAP,
      ROUNDUP_BODY_CAP,
      ROUNDUP_BODY_CAP,
      ROUNDUP_BODY_CAP,
    ]);
    const led = matcher.match({
      title: 'TCS leads IT rally',
      description: 'Infosys, Wipro and HCLTech also rose.',
      content: null,
    });
    expect(brief(led)[0]).toEqual(['TCS', 0.85, 'symbol:title']);
    expect(led.slice(1).every((m) => m.relevance === ROUNDUP_BODY_CAP)).toBe(true);
    expect(ROUNDUP_BODY_CAP).toBeLessThan(0.5);
  });

  it('adds a low query-only mention when the instrument query returned an article that never names it', () => {
    expect(brief(matcher.match(title('IT services demand slows'), ['TCS']))).toEqual([
      ['TCS', QUERY_ONLY_RELEVANCE, 'query'],
    ]);
    expect(brief(matcher.match(title('TCS wins deal'), ['TCS']))).toEqual([
      ['TCS', 0.85, 'symbol:title'],
    ]);
    expect(QUERY_ONLY_RELEVANCE).toBeLessThan(0.5);
  });
});
