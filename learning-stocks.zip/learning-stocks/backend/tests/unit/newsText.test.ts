import { describe, expect, it } from 'vitest';
import {
  canonicalizeUrl,
  cleanText,
  contentHash,
  decodeEntities,
  sourceKey,
  stripHtml,
} from '../../src/services/news/text.js';

describe('news text utilities', () => {
  it('decodes named and numeric entities, leaving unknown ones', () => {
    expect(decodeEntities('Tom &amp; Jerry&#39;s &#x20B9;5 &nbsp;x &bogus;')).toBe(
      "Tom & Jerry's ₹5  x &bogus;",
    );
  });

  it('strips HTML (Google News description) to plain text', () => {
    const html =
      '<a href="https://news.google.com/x" target="_blank">HDFC Bank Q2 update</a>&nbsp;&nbsp;<font color="#6f6f6f">Sahi</font>';
    expect(stripHtml(html)).toBe('HDFC Bank Q2 update Sahi');
    expect(stripHtml('a<script>alert(1)</script>b<br/>c')).toBe('a b c');
  });

  it('cleans and truncates text, returning null for blanks', () => {
    expect(cleanText('  <p>Hello</p>  ', 100)).toBe('Hello');
    expect(cleanText('a'.repeat(10), 5)).toBe('aaaa…');
    expect(cleanText('   ', 10)).toBeNull();
    expect(cleanText(null, 10)).toBeNull();
  });

  it('canonicalises URLs: lowercase host, no fragment or tracking params, sorted query, no trailing slash', () => {
    expect(canonicalizeUrl('HTTPS://Example.COM/a/b/?utm_source=x&id=2&oc=5&b=1#frag')).toBe(
      'https://example.com/a/b?b=1&id=2',
    );
    expect(canonicalizeUrl('https://example.com/')).toBe('https://example.com/');
    expect(canonicalizeUrl('javascript:alert(1)')).toBeNull();
    expect(canonicalizeUrl('not a url')).toBeNull();
  });

  it('derives the publisher key from a URL host', () => {
    expect(sourceKey('https://www.Business-Standard.com/markets/x')).toBe('business-standard.com');
    expect(sourceKey('nope')).toBeNull();
  });

  it('hashes title + source + IST publish date, ignoring case and punctuation', () => {
    const at = new Date('2026-10-05T10:00:00Z');
    const a = contentHash('Reliance Q2: profit rises!', 'example.com', at);
    expect(a).toMatch(/^[a-f0-9]{64}$/);
    expect(
      contentHash('reliance q2   profit rises', 'EXAMPLE.com', new Date('2026-10-05T17:00:00Z')),
    ).toBe(a);
    expect(contentHash('Reliance Q2: profit rises!', 'other.com', at)).not.toBe(a);
    // 2026-10-05T19:00Z is 2026-10-06 00:30 IST: a different IST day.
    expect(
      contentHash('Reliance Q2: profit rises!', 'example.com', new Date('2026-10-05T19:00:00Z')),
    ).not.toBe(a);
  });
});
