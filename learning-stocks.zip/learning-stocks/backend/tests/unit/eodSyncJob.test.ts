import { describe, expect, it } from 'vitest';
import { eodSyncJob } from '../../src/jobs/handlers/market.js';

/** Only what eodSyncJob touches: the sync, the bar check and the calendar. */
const containerFor = (hasBar: boolean) =>
  ({
    config: { dataMode: 'MOCK' as const },
    services: {
      calendar: {
        sessionOn: async (_e: string, date: string) =>
          date === '2026-10-06'
            ? { open: new Date('2026-10-06T03:45:00Z'), close: new Date('2026-10-06T10:00:00Z') }
            : null,
      },
      marketData: {
        sync: async () => ({
          runId: 'service-run',
          status: 'SUCCESS' as const,
          bars: { fetched: 1, inserted: 1, duplicates: 0, dropped: 0, rejected: 0 },
          instruments: { total: 1, succeeded: 1, failed: 0 },
        }),
      },
    },
    repositories: { marketData: { hasDailyBarOn: async () => hasBar } },
  }) as never;

const AT = new Date('2026-10-06T10:35:00Z'); // 16:05 IST, 5 min past the settle window

describe('eodSyncJob settle guard', () => {
  it('chains the evaluation when the settled session has its daily bar', async () => {
    const outcome = await eodSyncJob(containerFor(true)).run({}, AT);
    expect(outcome.status).toBe('SUCCESS');
    expect(outcome.next).toEqual([
      { name: 'evaluation.compute', data: { origin: 'eod' }, singletonKey: 'eod' },
    ]);
    expect(outcome.amended).not.toBe(true);
  });

  it('amends the run to PARTIAL and stops the chain when the bar is missing', async () => {
    const outcome = await eodSyncJob(containerFor(false)).run({}, AT);
    expect(outcome.status).toBe('PARTIAL');
    // amended: the service recorded SUCCESS for its own work; without this the override would
    // never reach system_logs, which is the only thing /system-status reads.
    expect(outcome.amended).toBe(true);
    expect(outcome.runId).toBe('service-run');
    expect(outcome.message).toMatch(/2026-10-06/);
    expect(outcome.next).toEqual([]);
  });
});
