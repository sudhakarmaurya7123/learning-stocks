import { createServer, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { Writable } from 'node:stream';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { AppError } from '../../src/utils/errors.js';
import { httpJson, redactUrl } from '../../src/utils/http.js';
import { createLogger } from '../../src/utils/logger.js';

let server: Server;
let base = '';

beforeAll(async () => {
  server = createServer((req, res) => {
    const path = (req.url ?? '').split('?')[0];
    const send = (status: number, body: string, headers: Record<string, string> = {}) => {
      res.writeHead(status, { 'content-type': 'application/json', ...headers });
      res.end(body);
    };
    if (path === '/ok') return send(200, '{"price":101.5}');
    if (path === '/stall-body') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.write('{"partial":');
      return;
    }
    if (path === '/slow') return void setTimeout(() => send(200, '{}'), 300);
    if (path === '/401') return send(401, '{}');
    if (path === '/429') return send(429, '{}', { 'retry-after': '2' });
    if (path === '/503') return send(503, '{}');
    if (path === '/404') return send(404, '{}');
    if (path === '/bad-json') return send(200, '{not json');
    if (path === '/400-body')
      return send(400, '{"error":{"message":"bad schema","code":"invalid_schema"}}');
    if (path === '/empty') return send(200, '');
    return send(500, '{}');
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(() => new Promise<void>((resolve) => server.close(() => resolve())));

async function codeOf(p: Promise<unknown>): Promise<AppError> {
  try {
    await p;
  } catch (e) {
    if (e instanceof AppError) return e;
    throw e;
  }
  throw new Error('expected rejection');
}

describe('httpJson', () => {
  it('parses JSON on success', async () => {
    const res = await httpJson<{ price: number }>({ url: `${base}/ok` });
    expect(res.status).toBe(200);
    expect(res.data.price).toBe(101.5);
  });

  it('maps a slow response to TIMEOUT', async () => {
    expect((await codeOf(httpJson({ url: `${base}/slow`, timeoutMs: 50 }))).code).toBe('TIMEOUT');
  });

  it('maps 401 to AUTH_FAILED, 503 to PROVIDER_DOWN, 404 to INVALID_RESPONSE', async () => {
    expect((await codeOf(httpJson({ url: `${base}/401` }))).code).toBe('AUTH_FAILED');
    expect((await codeOf(httpJson({ url: `${base}/503` }))).code).toBe('PROVIDER_DOWN');
    const notFound = await codeOf(httpJson({ url: `${base}/404` }));
    expect(notFound.code).toBe('INVALID_RESPONSE');
    expect(notFound.details).toMatchObject({ status: 404 });
  });

  it('maps 429 to RATE_LIMITED with Retry-After in ms', async () => {
    const e = await codeOf(httpJson({ url: `${base}/429` }));
    expect(e.code).toBe('RATE_LIMITED');
    expect(e.retryAfterMs).toBe(2000);
  });

  it('maps malformed and empty bodies', async () => {
    expect((await codeOf(httpJson({ url: `${base}/bad-json` }))).code).toBe('INVALID_RESPONSE');
    expect((await codeOf(httpJson({ url: `${base}/empty` }))).code).toBe('EMPTY_RESPONSE');
  });

  it('maps a refused connection to NETWORK', async () => {
    const closed = createServer();
    await new Promise<void>((resolve) => closed.listen(0, '127.0.0.1', resolve));
    const port = (closed.address() as AddressInfo).port;
    await new Promise<void>((resolve) => closed.close(() => resolve()));
    expect((await codeOf(httpJson({ url: `http://127.0.0.1:${port}/x` }))).code).toBe('NETWORK');
  });

  it('maps a body that stalls after the headers to TIMEOUT', async () => {
    expect((await codeOf(httpJson({ url: `${base}/stall-body`, timeoutMs: 100 }))).code).toBe(
      'TIMEOUT',
    );
  });

  it('never leaks a query-string key through the error cause or logs (unparseable URL)', async () => {
    const e = await codeOf(httpJson({ url: 'http://bad host/x?apikey=SECRET_IN_CAUSE' }));
    expect(e.code).toBe('NETWORK');
    const cause =
      e.cause instanceof Error
        ? `${e.cause.message} ${String(e.cause.stack)}`
        : JSON.stringify(e.cause ?? null);
    expect(`${e.message} ${JSON.stringify(e.details)} ${cause}`).not.toContain('SECRET_IN_CAUSE');
    const lines: string[] = [];
    const logger = createLogger({
      level: 'info',
      destination: new Writable({
        write(c, _e, cb) {
          lines.push(String(c));
          cb();
        },
      }),
    });
    logger.error({ err: e }, 'provider failed');
    expect(lines.join('')).not.toContain('SECRET_IN_CAUSE');
  });

  it('never leaks query-string secrets into errors', async () => {
    const e = await codeOf(httpJson({ url: `${base}/401?apikey=SUPER_SECRET_KEY` }));
    expect(JSON.stringify({ message: e.message, details: e.details })).not.toContain(
      'SUPER_SECRET_KEY',
    );
    expect(redactUrl('https://api.example.com/v1/q?apikey=abc&s=1')).toBe(
      'https://api.example.com/v1/q',
    );
  });

  it('keeps a capped error body only when asked', async () => {
    await expect(httpJson({ url: `${base}/400-body`, errorBodyChars: 20 })).rejects.toMatchObject({
      code: 'INVALID_RESPONSE',
      details: { status: 400, body: '{"error":{"message":' },
    });
    const plain = await httpJson({ url: `${base}/400-body` }).catch((e: unknown) => e);
    expect((plain as AppError).details).not.toHaveProperty('body');
  });
});
