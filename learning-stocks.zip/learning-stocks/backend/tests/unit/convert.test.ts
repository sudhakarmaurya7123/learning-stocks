import { describe, expect, it } from 'vitest';
import { requireNumber, toNumber } from '../../src/database/convert.js';

describe('numeric conversion', () => {
  it('converts pg numeric/int8 strings to numbers and keeps null', () => {
    expect(toNumber('2510.4500')).toBe(2510.45);
    expect(toNumber('9007199254')).toBe(9007199254);
    expect(toNumber(null)).toBeNull();
    expect(toNumber(undefined)).toBeNull();
  });
  it('rejects non-numeric strings and missing required values', () => {
    expect(() => toNumber('abc')).toThrow(/not a number/);
    expect(() => requireNumber(null, 'close')).toThrow(/close/);
  });
});
