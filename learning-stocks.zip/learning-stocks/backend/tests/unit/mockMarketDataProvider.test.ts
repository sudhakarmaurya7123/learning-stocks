import { describe, expect, it } from 'vitest';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import type { ProviderBar, ProviderInstrumentRef } from '../../src/providers/market/types.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { CASE_HOLIDAYS } from '../fixtures/calendarCases.js';
import { InMemoryHolidays } from '../fixtures/inMemoryHolidays.js';

const sessions = () =>
  new MarketCalendarService(new InMemoryHolidays(CASE_HOLIDAYS), new MemoryCache());
const RELIANCE: ProviderInstrumentRef = {
  providerSymbol: 'RELIANCE',
  exchange: 'NSE',
  kind: 'stock',
};
const VIX: ProviderInstrumentRef = { providerSymbol: 'INDIAVIX', exchange: 'NSE', kind: 'market' };
const AFTER_WEEK = () => new Date('2026-10-13T00:00:00+05:30');
const consistent = (b: ProviderBar) =>
  b.open !== null &&
  b.high !== null &&
  b.low !== null &&
  b.close !== null &&
  b.high >= Math.max(b.open, b.close, b.low) &&
  b.low <= Math.min(b.open, b.close) &&
  b.low > 0;

describe('MockMarketDataProvider', () => {
  const week = {
    from: new Date('2026-10-05T00:00:00+05:30'),
    to: new Date('2026-10-12T23:59:00+05:30'),
  };

  it('is deterministic across instances', async () => {
    const a = await new MockMarketDataProvider(sessions(), AFTER_WEEK).getHistorical(
      RELIANCE,
      week.from,
      week.to,
      '1d',
    );
    const b = await new MockMarketDataProvider(sessions(), AFTER_WEEK).getHistorical(
      RELIANCE,
      week.from,
      week.to,
      '1d',
    );
    expect(a).toEqual(b);
  });

  it('emits daily bars only for trading days, stamped at the session open (incl. special sessions)', async () => {
    const bars = await new MockMarketDataProvider(sessions(), AFTER_WEEK).getHistorical(
      RELIANCE,
      week.from,
      week.to,
      '1d',
    );
    expect(bars.map((b) => b.ts.toISOString())).toEqual([
      '2026-10-05T03:45:00.000Z',
      '2026-10-06T03:45:00.000Z',
      '2026-10-08T03:45:00.000Z',
      '2026-10-09T03:45:00.000Z',
      '2026-10-11T12:30:00.000Z',
      '2026-10-12T03:45:00.000Z',
    ]);
    expect(bars.every(consistent)).toBe(true);
  });

  it('emits 75 five-minute and 25 fifteen-minute bars per regular session, 12 in a 1h special session', async () => {
    const p = new MockMarketDataProvider(sessions(), AFTER_WEEK);
    const day = {
      from: new Date('2026-10-05T00:00:00+05:30'),
      to: new Date('2026-10-05T23:59:00+05:30'),
    };
    const m5 = await p.getHistorical(RELIANCE, day.from, day.to, '5m');
    expect(m5).toHaveLength(75);
    expect(m5[0]?.ts.toISOString()).toBe('2026-10-05T03:45:00.000Z');
    expect(m5[74]?.ts.toISOString()).toBe('2026-10-05T09:55:00.000Z');
    expect(m5.every(consistent)).toBe(true);
    expect(await p.getHistorical(RELIANCE, day.from, day.to, '15m')).toHaveLength(25);
    const special = await p.getHistorical(
      RELIANCE,
      new Date('2026-10-11T00:00:00+05:30'),
      new Date('2026-10-11T23:59:00+05:30'),
      '5m',
    );
    expect(special).toHaveLength(12);
  });

  it('daily bar aggregates the intraday path exactly', async () => {
    const p = new MockMarketDataProvider(sessions(), AFTER_WEEK);
    const from = new Date('2026-10-06T00:00:00+05:30');
    const to = new Date('2026-10-06T23:59:00+05:30');
    const [daily] = await p.getHistorical(RELIANCE, from, to, '1d');
    const m5 = await p.getHistorical(RELIANCE, from, to, '5m');
    expect(daily?.open).toBe(m5[0]?.open);
    expect(daily?.close).toBe(m5[m5.length - 1]?.close);
    expect(daily?.high).toBe(Math.max(...m5.map((b) => b.high ?? 0)));
    expect(daily?.low).toBe(Math.min(...m5.map((b) => b.low ?? Infinity)));
    expect(daily?.volume).toBe(m5.reduce((s, b) => s + (b.volume ?? 0), 0));
  });

  it('never returns bars that have not started yet', async () => {
    const now = () => new Date('2026-10-05T10:02:00+05:30');
    const bars = await new MockMarketDataProvider(sessions(), now).getHistorical(
      RELIANCE,
      new Date('2026-10-05T00:00:00+05:30'),
      new Date('2026-10-05T23:59:00+05:30'),
      '5m',
    );
    expect(bars).toHaveLength(10);
    expect(bars[9]?.ts.toISOString()).toBe('2026-10-05T04:30:00.000Z');
  });

  it('rejects 1m, simulates unknown symbols, and keeps VIX in a plausible band over years', async () => {
    const p = new MockMarketDataProvider(sessions(), AFTER_WEEK);
    await expect(p.getHistorical(RELIANCE, week.from, week.to, '1m')).rejects.toMatchObject({
      code: 'UNSUPPORTED',
    });
    const unknown = await p.getHistorical(
      { providerSymbol: 'NEWLISTING', exchange: 'NSE', kind: 'stock' },
      week.from,
      week.to,
      '1d',
    );
    expect(unknown.length).toBeGreaterThan(0);
    const vix = await p.getHistorical(VIX, new Date('2021-10-01T00:00:00Z'), week.to, '1d');
    expect(vix.length).toBeGreaterThan(1000);
    expect(vix.every((b) => (b.close ?? 0) >= 9 && (b.close ?? 0) <= 45)).toBe(true);
  });

  it('quotes the latest started bar with the previous close', async () => {
    const q = await new MockMarketDataProvider(
      sessions(),
      () => new Date('2026-10-05T10:02:00+05:30'),
    ).getQuote(RELIANCE);
    expect(q.price).toBeGreaterThan(0);
    expect(q.previousClose).toBeGreaterThan(0);
    expect(q.asOf.getTime()).toBeLessThanOrEqual(new Date('2026-10-05T10:02:00+05:30').getTime());
  });
});
