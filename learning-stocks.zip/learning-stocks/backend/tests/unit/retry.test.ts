import { describe, expect, it } from 'vitest';
import { AppError } from '../../src/utils/errors.js';
import { withRetry } from '../../src/utils/retry.js';

function harness() {
  const sleeps: number[] = [];
  return { sleeps, opts: { sleep: async (ms: number) => void sleeps.push(ms), random: () => 1 } };
}

describe('withRetry', () => {
  it('retries retryable errors with exponential backoff and then succeeds', async () => {
    const h = harness();
    let calls = 0;
    const result = await withRetry(async () => {
      calls += 1;
      if (calls < 3) throw new AppError('TIMEOUT', 'slow');
      return 'ok';
    }, h.opts);
    expect(result).toBe('ok');
    expect(calls).toBe(3);
    expect(h.sleeps).toEqual([500, 1000]);
  });

  it('never retries AUTH_FAILED', async () => {
    const h = harness();
    let calls = 0;
    await expect(
      withRetry(async () => {
        calls += 1;
        throw new AppError('AUTH_FAILED', 'bad key');
      }, h.opts),
    ).rejects.toMatchObject({ code: 'AUTH_FAILED' });
    expect(calls).toBe(1);
  });

  it('does not retry unknown (non-AppError) errors', async () => {
    let calls = 0;
    await expect(
      withRetry(async () => {
        calls += 1;
        throw new Error('bug');
      }, harness().opts),
    ).rejects.toThrow('bug');
    expect(calls).toBe(1);
  });

  it('gives up after the attempt limit and rethrows the last error', async () => {
    const h = harness();
    let calls = 0;
    await expect(
      withRetry(
        async () => {
          calls += 1;
          throw new AppError('NETWORK', `fail ${calls}`);
        },
        { ...h.opts, attempts: 3 },
      ),
    ).rejects.toThrow('fail 3');
    expect(calls).toBe(3);
  });

  it('honours a provider Retry-After longer than the backoff', async () => {
    const h = harness();
    let calls = 0;
    await withRetry(async () => {
      calls += 1;
      if (calls === 1) throw new AppError('RATE_LIMITED', 'wait', { retryAfterMs: 7000 });
      return 1;
    }, h.opts);
    expect(h.sleeps).toEqual([7000]);
  });

  it('gives up immediately when Retry-After exceeds maxDelayMs (never blocks a job for hours)', async () => {
    const h = harness();
    let calls = 0;
    await expect(
      withRetry(async () => {
        calls += 1;
        throw new AppError('RATE_LIMITED', 'come back tomorrow', { retryAfterMs: 86_400_000 });
      }, h.opts),
    ).rejects.toMatchObject({ code: 'RATE_LIMITED' });
    expect(calls).toBe(1);
    expect(h.sleeps).toEqual([]);
  });

  it('caps the delay at maxDelayMs', async () => {
    const h = harness();
    let calls = 0;
    await withRetry(
      async () => {
        calls += 1;
        if (calls < 5) throw new AppError('PROVIDER_DOWN', 'down');
        return 1;
      },
      { ...h.opts, attempts: 5, baseDelayMs: 1000, maxDelayMs: 3000 },
    );
    expect(h.sleeps).toEqual([1000, 2000, 3000, 3000]);
  });
});
