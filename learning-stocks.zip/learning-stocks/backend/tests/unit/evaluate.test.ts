import { describe, expect, it } from 'vitest';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';
import {
  buildEvaluation,
  canonicalJson,
  type EvaluationInputs,
  trendOf,
} from '../../src/scoring/evaluate.js';
import { ENGINE_VERSION } from '../../src/scoring/rubrics.js';
import type { OhlcvBar } from '../../src/technical/indicators.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

const NOW = new Date('2026-10-06T12:00:00Z');
function bars(n: number, drift = 0.0008): OhlcvBar[] {
  let s = 7;
  const rnd = () => ((s = (s * 16807) % 2147483647), s / 2147483647);
  let p = 1000;
  return Array.from({ length: n }, (_, i) => {
    const open = p;
    p = p * (1 + drift + (rnd() - 0.5) * 0.03);
    return {
      ts: new Date(NOW.getTime() - (n - i) * 86_400_000),
      open,
      high: Math.max(open, p) * 1.005,
      low: Math.min(open, p) * 0.995,
      close: p,
      volume: 100_000,
    };
  });
}
const inputs = (over: Partial<EvaluationInputs> = {}): EvaluationInputs => {
  const b = bars(420);
  const nifty = b.map((x) => ({ date: x.ts.toISOString().slice(0, 10), close: x.close / 10 }));
  return {
    stock: { id: 'stock-1', symbol: 'TEST', sector: 'Information Technology' },
    dataMode: 'MOCK',
    bars: b,
    stale: false,
    market: { nifty, niftyTrend: 'UPTREND', regime: 'RISK_ON', vix: 14 },
    sector: null,
    fundamentals: {
      asOf: '2026-10-06',
      snapshot: { ...emptySnapshotMetrics(), pe: 25, roe: 20, debtToEquity: 0.3 },
      quarterly: [],
      annual: [],
    },
    peerPes: [],
    news: [],
    holdsPosition: false,
    capital: 1_000_000,
    config: SEED_CONFIG,
    now: NOW,
    ...over,
  };
};

describe('canonicalJson', () => {
  it('sorts keys at every level and rounds numbers so equal inputs hash equally', () => {
    expect(canonicalJson({ b: 1.123456789, a: { d: [3, { z: 1, y: 2 }], c: null } })).toBe(
      '{"a":{"c":null,"d":[3,{"y":2,"z":1}]},"b":1.123457}',
    );
    expect(canonicalJson({ t: new Date('2026-01-01T00:00:00Z'), u: undefined })).toBe(
      '{"t":"2026-01-01T00:00:00.000Z"}',
    );
  });
});

describe('buildEvaluation', () => {
  it('produces a complete, DB-safe record and the full indicator series', () => {
    const { record, indicatorSeries, decision } = buildEvaluation(inputs());
    expect(indicatorSeries).toHaveLength(420);
    expect(record).toMatchObject({
      stockId: 'stock-1',
      dataMode: 'MOCK',
      scoringConfigVersion: 'v1',
      actionState: decision.actionState,
    });
    expect(record.dataAsOf).toEqual(inputs().bars.at(-1)?.ts);
    for (const v of Object.values(record.scores))
      if (v !== null) expect(v >= 0 && v <= 100).toBe(true);
    expect(record.scores.news).toBeNull();
    expect(record.scores.technical).not.toBeNull();
    expect(record.factorsAvailable).toMatchObject({ news: false, technical: true });
    if (record.trade) {
      expect(record.trade.stop).toBeGreaterThan(0);
      expect(record.trade.entryLow).toBeLessThanOrEqual(record.trade.entryHigh);
      expect(record.trade.riskReward).toBeGreaterThanOrEqual(0);
    }
    expect(record.invalidation.length).toBeGreaterThan(10);
    expect(record.inputs).toMatchObject({ engineVersion: ENGINE_VERSION, configVersion: 'v1' });
    expect(JSON.stringify(record.inputs)).not.toMatch(/evaluatedAt|"now"/);
  });

  it('is deterministic, and the hash changes when any input that matters changes', () => {
    const a = buildEvaluation(inputs()).record.inputHash;
    expect(buildEvaluation(inputs()).record.inputHash).toBe(a);
    expect(a).toMatch(/^[a-f0-9]{64}$/);
    expect(buildEvaluation(inputs({ holdsPosition: true })).record.inputHash).not.toBe(a);
    expect(
      buildEvaluation(inputs({ market: { ...inputs().market, vix: 30 } })).record.inputHash,
    ).not.toBe(a);
    expect(
      buildEvaluation(inputs({ now: new Date(NOW.getTime() + 3_600_000) })).record.inputHash,
    ).toBe(a);
  });

  it('marks no bars, short history and stale data as INSUFFICIENT_DATA', () => {
    const empty = buildEvaluation(inputs({ bars: [] })).record;
    expect(empty).toMatchObject({ actionState: 'INSUFFICIENT_DATA', trade: null, dataAsOf: NOW });
    const short = buildEvaluation(inputs({ bars: bars(150) })).record;
    expect(short).toMatchObject({ actionState: 'INSUFFICIENT_DATA', trade: null });
    const stale = buildEvaluation(inputs({ stale: true })).record;
    expect(stale).toMatchObject({ actionState: 'INSUFFICIENT_DATA', trade: null });
  });

  it('exempts financials from D/E and uses peers for valuation when available', () => {
    const bank = buildEvaluation(
      inputs({ stock: { id: 's', symbol: 'BANK', sector: 'Financial Services' } }),
    ).record;
    expect(
      (bank.inputs as { factors: { quality: { components: { debtToEquity: unknown } } } }).factors
        .quality.components.debtToEquity,
    ).toBeNull();
    const peers = buildEvaluation(inputs({ peerPes: [10, 12, 14, 16] })).record;
    expect(peers.valuationLabel).toBe('OVERVALUED');
  });

  it('classifies an index series trend from its bars', () => {
    expect(trendOf(bars(420, 0.003))).toBe('UPTREND');
    expect(trendOf(bars(100))).toBeNull();
  });
});
