import { describe, expect, it } from 'vitest';
import { emptyStatementMetrics } from '../../src/domain/fundamentals.js';
import {
  financialsDocumentText,
  newsDocumentText,
  sha256Hex,
  statementAvailableOn,
} from '../../src/rag/documents.js';

describe('newsDocumentText', () => {
  it('joins title, description and content, skipping blanks and repeated text', () => {
    expect(
      newsDocumentText({ title: 'Infosys wins deal', description: 'A large deal.', content: null }),
    ).toBe('Infosys wins deal\n\nA large deal.');
    expect(
      newsDocumentText({
        title: 'T',
        description: 'Lead para.',
        content: 'Lead para. More detail follows.',
      }),
    ).toBe('T\n\nLead para. More detail follows.');
  });
});

describe('financialsDocumentText', () => {
  const metrics = {
    ...emptyStatementMetrics(),
    revenue: 2_480_000_000_000,
    netProfit: 190_000_000_000,
    eps: 14.04,
  };
  const prior = {
    ...emptyStatementMetrics(),
    revenue: 2_357_000_000_000,
    netProfit: 200_000_000_000,
    eps: 14.8,
  };

  it('summarises a statement deterministically with YoY and lists unreported fields', () => {
    const text = financialsDocumentText({
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd',
      periodType: 'QUARTERLY',
      periodEnd: '2026-06-30',
      source: 'yahoo',
      metrics,
      prior: { periodEnd: '2025-06-30', metrics: prior },
    });
    expect(text).toBe(
      [
        'RELIANCE (Reliance Industries Ltd): quarterly results for the quarter ended 30 Jun 2026 (source: yahoo).',
        'Revenue: ₹2,48,000.00 crore (+5.22% YoY vs ₹2,35,700.00 crore).',
        'Net profit: ₹19,000.00 crore (-5.00% YoY vs ₹20,000.00 crore).',
        'EPS: ₹14.04 (-5.14% YoY vs ₹14.80).',
        'Not reported: operating profit, total debt, total equity, cash from operations, capex.',
      ].join('\n'),
    );
    expect(sha256Hex(text)).toMatch(/^[a-f0-9]{64}$/);
  });

  it('omits YoY without a comparable period and for a non-positive base', () => {
    const text = financialsDocumentText({
      symbol: 'X',
      companyName: 'X Ltd',
      periodType: 'ANNUAL',
      periodEnd: '2026-03-31',
      source: 'mock',
      metrics: { ...emptyStatementMetrics(), netProfit: 50_000_000 },
      prior: {
        periodEnd: '2025-03-31',
        metrics: { ...emptyStatementMetrics(), netProfit: -10_000_000 },
      },
    });
    expect(text).toContain('annual results for the year ended 31 Mar 2026');
    expect(text).toContain('Net profit: ₹5.00 crore (vs ₹-1.00 crore a year earlier).');
  });

  it('dates availability with the results lag (no look-ahead)', () => {
    expect(statementAvailableOn('QUARTERLY', '2026-06-30')).toBe('2026-08-14');
    expect(statementAvailableOn('ANNUAL', '2026-03-31')).toBe('2026-05-30');
  });
});
