import { describe, expect, it } from 'vitest';
import { computeIndicatorSeries, type OhlcvBar } from '../../src/technical/indicators.js';

const day = (i: number) => new Date(Date.UTC(2025, 0, 1) + i * 86_400_000);

/** Deterministic 300-bar series (Park–Miller LCG). Same generator the reference values were computed on. */
function referenceBars(): OhlcvBar[] {
  let s = 1;
  const rnd = () => {
    s = (s * 16807) % 2147483647;
    return s / 2147483647;
  };
  const bars: OhlcvBar[] = [];
  let p = 100;
  for (let i = 0; i < 300; i += 1) {
    const open = p;
    p = p * (1 + (rnd() - 0.48) * 0.04);
    const close = p;
    const high = Math.max(open, close) * (1 + rnd() * 0.01);
    const low = Math.min(open, close) * (1 - rnd() * 0.01);
    bars.push({ ts: day(i), open, high, low, close, volume: Math.round(1e5 + rnd() * 1e5) });
  }
  return bars;
}

const closesOnly = (closes: number[]): OhlcvBar[] =>
  closes.map((c, i) => ({ ts: day(i), open: c, high: c, low: c, close: c, volume: 1000 }));

describe('computeIndicatorSeries', () => {
  it('matches the StockCharts textbook RSI(14) (Wilder smoothing)', () => {
    const closes = [
      44.3389, 44.0902, 44.1497, 43.6124, 44.3278, 44.8264, 45.0955, 45.4245, 45.8433, 46.0826,
      45.8931, 46.0328, 45.614, 46.282, 46.282, 46.0028, 46.0328, 46.4116, 46.2222, 45.6439,
      46.2122, 46.2521, 45.7137, 46.4515,
    ];
    const rsi = computeIndicatorSeries(closesOnly(closes)).map((p) => p.values.rsi14);
    expect(rsi.slice(0, 14).every((v) => v === null)).toBe(true);
    expect(rsi.slice(14).map((v) => Number(v?.toFixed(2)))).toEqual([
      70.53, 66.32, 66.55, 69.41, 66.36, 57.97, 62.93, 63.26, 56.06, 62.38,
    ]);
  });

  it('matches reference values (computed once with technicalindicators@3.1.0) on the last bar', () => {
    const last = computeIndicatorSeries(referenceBars()).at(-1)?.values;
    expect(last?.sma50).toBeCloseTo(117.5694, 3);
    expect(last?.ema50).toBeCloseTo(117.3485, 3);
    expect(last?.rsi14).toBeCloseTo(59.88, 1);
    expect(last?.atr14).toBeCloseTo(2.4522, 3);
    expect(last?.adx14).toBeCloseTo(28.9059, 3);
    expect(last?.macd).toBeCloseTo(2.082053, 5);
    expect(last?.macdSignal).toBeCloseTo(2.203009, 5);
    expect(last?.macdHistogram).toBeCloseTo(-0.120956, 5);
    expect(last?.bollingerUpper).toBeCloseTo(127.306685, 4);
    expect(last?.bollingerMiddle).toBeCloseTo(121.208378, 4);
    expect(last?.bollingerLower).toBeCloseTo(115.110071, 4);
    expect(last?.stochK).toBeCloseTo(74.450752, 4);
    expect(last?.stochD).toBeCloseTo(70.456158, 4);
  });

  it('leaves every indicator null until it has enough history (never extrapolated)', () => {
    const series = computeIndicatorSeries(referenceBars());
    const firstNonNull = (key: keyof (typeof series)[number]['values']) =>
      series.findIndex((p) => p.values[key] !== null);
    expect(firstNonNull('sma20')).toBe(19);
    expect(firstNonNull('sma200')).toBe(199);
    expect(firstNonNull('ema20')).toBe(19);
    expect(firstNonNull('ema200')).toBe(199);
    expect(firstNonNull('rsi14')).toBe(14);
    expect(firstNonNull('macd')).toBe(25);
    expect(firstNonNull('macdSignal')).toBe(33);
    expect(firstNonNull('macdHistogram')).toBe(33);
    expect(firstNonNull('bollingerUpper')).toBe(19);
    expect(firstNonNull('atr14')).toBe(13);
    expect(firstNonNull('adx14')).toBe(26);
    expect(firstNonNull('stochK')).toBe(15);
    expect(firstNonNull('volumeSma20')).toBe(19);
    expect(computeIndicatorSeries(referenceBars().slice(0, 150)).at(-1)?.values.sma200).toBeNull();
  });

  it('never emits NaN: flat, circuit-locked bars give null instead of a non-finite value', () => {
    const flat = Array.from({ length: 60 }, (_, i) => ({
      ts: day(i),
      open: 100,
      high: 100,
      low: 100,
      close: 100,
      volume: 0,
    }));
    for (const p of computeIndicatorSeries(flat)) {
      for (const v of Object.values(p.values)) expect(v === null || Number.isFinite(v)).toBe(true);
    }
  });

  it('computes classic floor pivots from the previous bar', () => {
    const bars: OhlcvBar[] = [
      { ts: day(0), open: 100, high: 110, low: 90, close: 105, volume: 1 },
      { ts: day(1), open: 105, high: 108, low: 101, close: 107, volume: 1 },
    ];
    const [first, second] = computeIndicatorSeries(bars);
    expect(first?.pivots).toBeNull();
    expect(second?.pivots).toEqual({
      p: 101.6667,
      r1: 113.3333,
      s1: 93.3333,
      r2: 121.6667,
      s2: 81.6667,
    });
  });

  it('computes session VWAP only when a session key is given, resetting each session', () => {
    const bar = (i: number, price: number, volume: number): OhlcvBar => ({
      ts: new Date(Date.UTC(2026, 9, 5, 4, i * 5)),
      open: price,
      high: price,
      low: price,
      close: price,
      volume,
    });
    const bars = [
      bar(0, 100, 10),
      bar(1, 110, 30),
      { ...bar(2, 200, 10), ts: new Date(Date.UTC(2026, 9, 6, 4, 0)) },
    ];
    expect(computeIndicatorSeries(bars).map((p) => p.vwap)).toEqual([null, null, null]);
    const vwap = computeIndicatorSeries(bars, {
      sessionKey: (ts) => ts.toISOString().slice(0, 10),
    }).map((p) => p.vwap);
    expect(vwap).toEqual([100, 107.5, 200]);
    const indexBars = bars.map((b) => ({ ...b, volume: 0 }));
    expect(
      computeIndicatorSeries(indexBars, { sessionKey: (ts) => ts.toISOString().slice(0, 10) }).map(
        (p) => p.vwap,
      ),
    ).toEqual([null, null, null]);
  });
});
