import { describe, expect, it } from 'vitest';
import { chatCostInr, chatPrice } from '../../src/providers/llm/pricing.js';

describe('chat pricing', () => {
  it('matches dated snapshots by the longest model prefix', () => {
    expect(chatPrice('gpt-5-mini')).toEqual({ input: 0.25, output: 2 });
    expect(chatPrice('gpt-5-mini-2025-08-07')).toEqual({ input: 0.25, output: 2 });
    expect(chatPrice('gpt-4o-mini-2024-07-18')).toEqual({ input: 0.15, output: 0.6 });
    expect(chatPrice('gpt-4o-2024-11-20')).toEqual({ input: 2.5, output: 10 });
    expect(chatPrice('gpt-5minimal')).toBeNull();
    expect(chatPrice('mystery')).toBeNull();
  });

  it('lets an explicit override win and prices calls in ₹', () => {
    expect(chatPrice('mystery', { input: 1, output: 4 })).toEqual({ input: 1, output: 4 });
    expect(chatCostInr('gpt-5-mini', 1_000_000, 1_000_000, 88)).toBeCloseTo(198, 6);
    expect(chatCostInr('mock-chat-v1', 5000, 5000, 88)).toBe(0);
    expect(chatCostInr('mystery', 10, 10, 88)).toBeNull();
  });
});
