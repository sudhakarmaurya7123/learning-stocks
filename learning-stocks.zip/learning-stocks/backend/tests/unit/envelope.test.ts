import { describe, expect, it } from 'vitest';
import { freshness, meta, ok } from '../../src/http/envelope.js';

const NOW = new Date('2026-10-06T06:00:00Z'); // 11:30 IST, mid-session

describe('freshness', () => {
  it('reports a fresh quote inside the session', () => {
    const f = freshness(new Date('2026-10-06T05:55:00Z'), {
      now: NOW,
      marketOpen: true,
      stalenessMinutes: 20,
    });
    expect(f).toEqual({
      as_of: '2026-10-06T05:55:00.000Z',
      age_seconds: 300,
      stale: false,
      market_open: true,
      // Defaulted: a caller that names no cadence is judging a quote, as every pre-Phase-10
      // caller was. Asserted rather than loosened to toMatchObject, so the exact wire shape
      // stays pinned.
      cadence: 'quote',
    });
  });

  it('marks a quote stale once it passes the threshold while the market is open', () => {
    const f = freshness(new Date('2026-10-06T05:30:00Z'), {
      now: NOW,
      marketOpen: true,
      stalenessMinutes: 20,
    });
    expect(f).toMatchObject({ age_seconds: 1800, stale: true });
  });

  it('never calls the last close stale while the market is closed', () => {
    // Sunday 11:30 IST, holding Friday's close: old, but it is the newest fact there is.
    const f = freshness(new Date('2026-10-02T10:00:00Z'), {
      now: new Date('2026-10-04T06:00:00Z'),
      marketOpen: false,
      stalenessMinutes: 20,
    });
    expect(f.stale).toBe(false);
    expect(f.market_open).toBe(false);
    expect(f.age_seconds).toBeGreaterThan(20 * 60);
  });

  it('treats missing data as stale with a null age', () => {
    expect(freshness(null, { now: NOW, marketOpen: true, stalenessMinutes: 20 })).toEqual({
      as_of: null,
      age_seconds: null,
      stale: true,
      market_open: true,
      cadence: 'quote',
    });
  });
});

describe('meta', () => {
  it('omits freshness when not supplied, and carries it when it is', () => {
    expect(meta('MOCK', NOW)).toEqual({
      data_mode: 'MOCK',
      generated_at: '2026-10-06T06:00:00.000Z',
    });
    const f = freshness(NOW, { now: NOW, marketOpen: true, stalenessMinutes: 20 });
    expect(meta('MOCK', NOW, f).freshness).toEqual(f);
    expect(ok({ x: 1 }, meta('MOCK', NOW))).toEqual({
      data: { x: 1 },
      meta: { data_mode: 'MOCK', generated_at: '2026-10-06T06:00:00.000Z' },
    });
  });
});
