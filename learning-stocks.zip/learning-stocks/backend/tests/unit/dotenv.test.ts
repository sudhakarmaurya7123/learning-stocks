import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { loadDotEnv } from '../../src/config/dotenv.js';

describe('loadDotEnv', () => {
  afterEach(() => {
    delete process.env.LS_DOTENV_PROBE;
  });

  it('returns false when the file does not exist (fresh clone)', () => {
    expect(loadDotEnv(join(tmpdir(), 'definitely-missing.env'))).toBe(false);
  });

  it('loads variables from the given file', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ls-env-'));
    const file = join(dir, '.env');
    writeFileSync(file, '# comment line\nLS_DOTENV_PROBE=hello\n');
    expect(loadDotEnv(file)).toBe(true);
    expect(process.env.LS_DOTENV_PROBE).toBe('hello');
  });
});
