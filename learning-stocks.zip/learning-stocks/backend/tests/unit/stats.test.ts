import { describe, expect, it } from 'vitest';
import {
  beta,
  clampScore,
  type DatedClose,
  interpolate,
  maxDrawdownPct,
  percentileRank,
  relativeStrength,
  returnPct,
  returnSince,
  weightedMean,
} from '../../src/technical/stats.js';

const dated = (closes: number[], start = 0, skip: number[] = []): DatedClose[] =>
  closes
    .map((close, i) => ({
      date: new Date(Date.UTC(2025, 0, 1) + (start + i) * 86_400_000).toISOString().slice(0, 10),
      close,
    }))
    .filter((_, i) => !skip.includes(i));

describe('stats', () => {
  it('interpolates piecewise-linearly and clamps at the ends', () => {
    const pts = [
      [0, 0],
      [10, 100],
    ] as const;
    expect(interpolate(5, pts)).toBe(50);
    expect(interpolate(-5, pts)).toBe(0);
    expect(interpolate(50, pts)).toBe(100);
    expect(
      interpolate(15, [
        [10, 0],
        [20, 100],
        [30, 0],
      ]),
    ).toBe(50);
  });

  it('clamps and rounds scores; ranks percentiles; drops null parts in weighted means', () => {
    expect(clampScore(104.123)).toBe(100);
    expect(clampScore(-3)).toBe(0);
    expect(clampScore(33.3333)).toBe(33.33);
    expect(percentileRank([10, 20, 30, 40], 20)).toBe(50);
    expect(percentileRank([], 20)).toBeNull();
    expect(
      weightedMean([
        [80, 1],
        [null, 5],
        [40, 3],
      ]),
    ).toBe(50);
    expect(weightedMean([[null, 1]])).toBeNull();
  });

  it('computes returns over sessions and since a date', () => {
    const s = dated([100, 110, 121]);
    expect(returnPct(s, 2)).toBeCloseTo(21, 9);
    expect(returnPct(s, 5)).toBeNull();
    expect(returnSince(s, s[1]?.date ?? '')).toBeCloseTo(10, 9);
  });

  it('aligns stock and index by date, not array position (index missing a day)', () => {
    const closes = Array.from(
      { length: 200 },
      (_, i) => 100 * (1 + 0.01 * Math.sin(i / 3)) * (1 + i / 1000),
    );
    const stock = dated(closes);
    const index = dated(closes, 0, [57]); // the index lacks day 57
    expect(beta(stock, index)).toBeCloseTo(1, 9);
    expect(relativeStrength(stock, index, 100)).toBeCloseTo(0, 9);
  });

  it('needs enough paired returns for beta and measures max drawdown', () => {
    expect(beta(dated([1, 2, 3]), dated([1, 2, 3]))).toBeNull();
    expect(maxDrawdownPct([100, 120, 90, 130, 104])).toBeCloseTo(25, 9);
    expect(maxDrawdownPct([])).toBeNull();
  });
});
