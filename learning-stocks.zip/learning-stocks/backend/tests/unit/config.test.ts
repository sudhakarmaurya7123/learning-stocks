import { describe, expect, it } from 'vitest';
import { ConfigError, loadConfig } from '../../src/config/env.js';

const DB = { DATABASE_URL: 'postgresql://postgres:postgres@127.0.0.1:54322/postgres' };

describe('loadConfig', () => {
  it('starts in mock mode with only DATABASE_URL set', () => {
    const c = loadConfig({ ...DB });
    expect(c.dataMode).toBe('MOCK');
    expect(c.providers).toEqual({
      marketData: 'mock',
      news: 'mock',
      fundamentals: 'mock',
      llm: 'mock',
    });
    expect(c.host).toBe('127.0.0.1');
    expect(c.port).toBe(4000);
    expect(c.autoPaperTrade).toBe(false);
  });

  it('treats blank values as unset', () => {
    const c = loadConfig({ ...DB, OPENAI_API_KEY: '', PORT: '', MOCK_DATA: '' });
    expect(c.secrets.openaiApiKey).toBeNull();
    expect(c.port).toBe(4000);
    expect(c.dataMode).toBe('MOCK');
  });

  it('forces every provider to mock when MOCK_DATA=true', () => {
    const c = loadConfig({
      ...DB,
      MOCK_DATA: 'true',
      MARKET_DATA_PROVIDER: 'yahoo',
      LLM_PROVIDER: 'openai',
    });
    expect(c.providers.marketData).toBe('mock');
    expect(c.providers.llm).toBe('mock');
  });

  it('refuses live mode with a mock provider (would label mock data LIVE)', () => {
    expect(() =>
      loadConfig({
        ...DB,
        MOCK_DATA: 'false',
        MARKET_DATA_PROVIDER: 'yahoo',
        NEWS_PROVIDER: 'rss',
        FUNDAMENTALS_PROVIDER: 'mock',
        LLM_PROVIDER: 'mock',
      }),
    ).toThrow(/FUNDAMENTALS_PROVIDER=mock requires MOCK_DATA=true/);
  });

  it('requires OPENAI_API_KEY and LLM_MODEL only when the OpenAI provider is selected', () => {
    const live = {
      ...DB,
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'rss',
      FUNDAMENTALS_PROVIDER: 'yahoo',
      LLM_PROVIDER: 'openai',
    };
    expect(() => loadConfig(live)).toThrow(/OPENAI_API_KEY/);
    const c = loadConfig({ ...live, OPENAI_API_KEY: 'sk-test', LLM_MODEL: 'gpt-5-mini' });
    expect(c.dataMode).toBe('LIVE');
    expect(c.providers).toEqual({
      marketData: 'yahoo',
      news: 'rss',
      fundamentals: 'yahoo',
      llm: 'openai',
    });
  });

  it('requires NEWS_API_KEY only for the newsapi provider', () => {
    const live = {
      ...DB,
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'newsapi',
      FUNDAMENTALS_PROVIDER: 'yahoo',
      LLM_PROVIDER: 'openai',
      OPENAI_API_KEY: 'k',
      LLM_MODEL: 'm',
    };
    expect(() => loadConfig(live)).toThrow(/NEWS_API_KEY/);
  });

  it('rejects an embedding dimension that does not match the vector(1536) column', () => {
    expect(() => loadConfig({ ...DB, EMBEDDING_DIMENSIONS: '768' })).toThrow(
      /EMBEDDING_DIMENSIONS/,
    );
  });

  it('reports invalid and missing values readably', () => {
    expect(() => loadConfig({ ...DB, PORT: 'abc' })).toThrow(ConfigError);
    expect(() => loadConfig({ ...DB, PORT: 'abc' })).toThrow(/PORT/);
  });

  it('defaults DATABASE_URL to local Supabase outside production, but requires it in production', () => {
    expect(loadConfig({}).databaseUrl).toBe(
      'postgresql://postgres:postgres@127.0.0.1:54322/postgres',
    );
    expect(loadConfig({ DATABASE_URL: '' }).dataMode).toBe('MOCK');
    expect(() => loadConfig({ NODE_ENV: 'production' })).toThrow(/DATABASE_URL/);
  });

  it("allows live market data with not-yet-built features disabled via 'none'", () => {
    const c = loadConfig({
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'none',
      FUNDAMENTALS_PROVIDER: 'none',
      LLM_PROVIDER: 'none',
    });
    expect(c.dataMode).toBe('LIVE');
    expect(c.providers).toEqual({
      marketData: 'yahoo',
      news: 'none',
      fundamentals: 'none',
      llm: 'none',
    });
    expect(() => loadConfig({ MOCK_DATA: 'false', MARKET_DATA_PROVIDER: 'none' })).toThrow(
      /MARKET_DATA_PROVIDER/,
    );
  });

  it('reads USD_INR_RATE (default 88) and refuses an unpriced embedding model for OpenAI in live mode', () => {
    expect(loadConfig({}).llm.usdInrRate).toBe(88);
    expect(loadConfig({ USD_INR_RATE: '90.5' }).llm.usdInrRate).toBe(90.5);
    const live = {
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'none',
      FUNDAMENTALS_PROVIDER: 'none',
      LLM_PROVIDER: 'openai',
      OPENAI_API_KEY: 'sk-x',
      LLM_MODEL: 'gpt-5-mini',
    };
    expect(loadConfig(live).providers.llm).toBe('openai');
    expect(() => loadConfig({ ...live, EMBEDDING_MODEL: 'mystery-embed' })).toThrow(
      /EMBEDDING_MODEL=mystery-embed has no price entry/,
    );
  });

  it('refuses an unpriced chat model in live mode unless both price overrides are set', () => {
    const live = {
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'none',
      FUNDAMENTALS_PROVIDER: 'none',
      LLM_PROVIDER: 'openai',
      OPENAI_API_KEY: 'sk-x',
    };
    expect(loadConfig({ ...live, LLM_MODEL: 'gpt-5-mini' }).llm.priceOverride).toBeNull();
    expect(() => loadConfig({ ...live, LLM_MODEL: 'brand-new-model' })).toThrow(
      /LLM_MODEL=brand-new-model has no price entry/,
    );
    const priced = loadConfig({
      ...live,
      LLM_MODEL: 'brand-new-model',
      LLM_PRICE_INPUT_USD_PER_M: '1',
      LLM_PRICE_OUTPUT_USD_PER_M: '3',
    });
    expect(priced.llm.priceOverride).toEqual({ input: 1, output: 3 });
    expect(() => loadConfig({ LLM_PRICE_INPUT_USD_PER_M: '1' })).toThrow(
      /set both LLM_PRICE_INPUT_USD_PER_M and LLM_PRICE_OUTPUT_USD_PER_M/,
    );
  });

  it('defaults the worker queue schema and timezone, and allows overrides', () => {
    expect(loadConfig({}).worker).toEqual({ queueSchema: 'pgboss', timezone: 'Asia/Kolkata' });
    const c = loadConfig({ WORKER_QUEUE_SCHEMA: 'jobs_test', WORKER_TIMEZONE: 'UTC' });
    expect(c.worker).toEqual({ queueSchema: 'jobs_test', timezone: 'UTC' });
  });
});
