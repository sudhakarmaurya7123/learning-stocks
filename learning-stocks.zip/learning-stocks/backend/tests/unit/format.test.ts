import { describe, expect, it } from 'vitest';
import { formatDate, formatInr, formatInrCrore } from '../../src/utils/format.js';

describe('formatInr', () => {
  it('uses Indian digit grouping with two decimals', () => {
    expect(formatInr(1234567.5)).toBe('₹12,34,567.50');
    expect(formatInr(99.999)).toBe('₹100.00');
    expect(formatInr(0.5)).toBe('₹0.50');
  });

  it('formats rupees as crore and ISO dates as day-month-year', () => {
    expect(formatInrCrore(2_480_000_000_000)).toBe('₹2,48,000.00 crore');
    expect(formatInrCrore(-12_345_000)).toBe('₹-1.23 crore');
    expect(formatDate('2026-06-30')).toBe('30 Jun 2026');
  });
});
