import { describe, expect, it } from 'vitest';
import { chunkText } from '../../src/rag/chunker.js';
import { estimateTokens } from '../../src/utils/tokens.js';

const words = (n: number) => Array.from({ length: n }, (_, i) => `w${i}`);

describe('chunkText', () => {
  it('returns one normalised chunk for short text and none for blank text', () => {
    expect(chunkText('  Reliance   wins\n\n order ')).toEqual(['Reliance wins order']);
    expect(chunkText(' \n ')).toEqual([]);
  });

  it('splits long text into overlapping, contiguous windows within the budget that cover every word in order', () => {
    const all = words(2000);
    const chunks = chunkText(all.join(' '), { maxTokens: 100, overlapTokens: 10 });
    expect(chunks.length).toBeGreaterThan(1);
    let covered = 0; // index of the first word not yet in any chunk
    for (const [k, c] of chunks.entries()) {
      expect(estimateTokens(c)).toBeLessThanOrEqual(100);
      const ws = c.split(' ');
      const first = all.indexOf(ws[0] ?? '');
      if (k === 0) expect(first).toBe(0);
      else expect(first).toBeLessThan(covered); // starts inside the previous chunk: overlap
      expect(ws).toEqual(all.slice(first, first + ws.length)); // contiguous, in order
      covered = first + ws.length;
    }
    expect(covered).toBe(all.length);
  });

  it('keeps a single over-long word as its own chunk and rejects bad options', () => {
    expect(chunkText('x'.repeat(5000), { maxTokens: 100, overlapTokens: 10 })).toHaveLength(1);
    expect(() => chunkText('a', { maxTokens: 10, overlapTokens: 10 })).toThrow(RangeError);
  });
});
