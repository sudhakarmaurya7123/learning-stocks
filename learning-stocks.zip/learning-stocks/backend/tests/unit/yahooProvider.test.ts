import { describe, expect, it } from 'vitest';
import { mapYahooError } from '../../src/providers/market/yahoo/errors.js';
import type {
  YahooChart,
  YahooClient,
  YahooSnapshot,
} from '../../src/providers/market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from '../../src/providers/market/yahoo/YahooMarketDataProvider.js';

const REF = { providerSymbol: 'RELIANCE.NS', exchange: 'NSE', kind: 'stock' } as const;

class FakeClient implements YahooClient {
  calls: string[] = [];
  constructor(
    private readonly chartResult: YahooChart | Error,
    private readonly quoteResult: YahooSnapshot | Error = new Error('unused'),
  ) {}
  async chart(symbol: string): Promise<YahooChart> {
    this.calls.push(`chart:${symbol}`);
    if (this.chartResult instanceof Error) throw this.chartResult;
    return this.chartResult;
  }
  async quote(symbol: string): Promise<YahooSnapshot> {
    this.calls.push(`quote:${symbol}`);
    if (this.quoteResult instanceof Error) throw this.quoteResult;
    return this.quoteResult;
  }
}

function provider(client: YahooClient) {
  let acquired = 0;
  const p = new YahooMarketDataProvider(client, {
    acquire: async () => {
      acquired += 1;
    },
  });
  return { p, acquired: () => acquired };
}

const chart = (exchangeName: string | null): YahooChart => ({
  exchangeName,
  currency: 'INR',
  quotes: [
    {
      date: new Date('2026-10-05T03:45:00Z'),
      open: 1171.2,
      high: 1193,
      low: 1171.2,
      close: 1186.4,
      adjclose: 1186.4,
      volume: 14_251_054,
    },
    {
      date: new Date('2026-10-02T03:45:00Z'),
      open: null,
      high: null,
      low: null,
      close: null,
      adjclose: null,
      volume: null,
    },
  ],
});

describe('YahooMarketDataProvider', () => {
  it('maps chart quotes to provider bars, keeping nulls for the normalizer, and rate-limits each call', async () => {
    const { p, acquired } = provider(new FakeClient(chart('NSI')));
    const bars = await p.getHistorical(REF, new Date('2026-09-01'), new Date('2026-10-06'), '1d');
    expect(bars[0]).toEqual({
      ts: new Date('2026-10-05T03:45:00Z'),
      open: 1171.2,
      high: 1193,
      low: 1171.2,
      close: 1186.4,
      adjustedClose: 1186.4,
      volume: 14_251_054,
    });
    expect(bars[1]?.close).toBeNull();
    expect(acquired()).toBe(1);
  });

  it('accepts BSE listings and refuses non-Indian ones', async () => {
    await expect(
      provider(new FakeClient(chart('BSE'))).p.getHistorical(REF, new Date(), new Date(), '1d'),
    ).resolves.toHaveLength(2);
    await expect(
      provider(new FakeClient(chart('NMS'))).p.getHistorical(REF, new Date(), new Date(), '1d'),
    ).rejects.toMatchObject({ code: 'UNSUPPORTED' });
    await expect(
      provider(new FakeClient(chart(null))).p.getHistorical(REF, new Date(), new Date(), '1d'),
    ).rejects.toMatchObject({ code: 'INVALID_RESPONSE' });
  });

  it('declares delayed latency and Yahoo intraday lookback limits', () => {
    const caps = provider(new FakeClient(chart('NSI'))).p.capabilities();
    expect(caps).toMatchObject({
      latency: 'delayed',
      maxLookbackDays: { '1m': 7, '5m': 59, '15m': 59 },
    });
  });

  it('quotes, and treats a missing price as EMPTY_RESPONSE', async () => {
    const ok = provider(
      new FakeClient(chart('NSI'), {
        price: 2114.4,
        time: new Date('2026-10-05T09:45:00Z'),
        previousClose: 2100,
        currency: 'INR',
        exchange: 'NSI',
      }),
    );
    expect(await ok.p.getQuote(REF)).toEqual({
      price: 2114.4,
      asOf: new Date('2026-10-05T09:45:00Z'),
      previousClose: 2100,
      currency: 'INR',
    });
    const empty = provider(
      new FakeClient(chart('NSI'), {
        price: null,
        time: null,
        previousClose: null,
        currency: null,
        exchange: 'NSI',
      }),
    );
    await expect(empty.p.getQuote(REF)).rejects.toMatchObject({ code: 'EMPTY_RESPONSE' });
  });
});

describe('mapYahooError', () => {
  class FailedYahooValidationError extends Error {
    override name = 'FailedYahooValidationError';
  }
  it.each([
    [new Error('No data found, symbol may be delisted'), 'UNSUPPORTED'],
    [new Error('Too Many Requests'), 'RATE_LIMITED'],
    [new FailedYahooValidationError('Failed Yahoo Schema validation'), 'INVALID_RESPONSE'],
    [
      new Error(
        '5m data not available for startTime=1 and endTime=2. The requested range must be within the last 60 days.',
      ),
      'INVALID_RESPONSE',
    ],
    [new TypeError('fetch failed'), 'NETWORK'],
    [new Error('Request timed out'), 'TIMEOUT'],
    [new Error('Something odd happened'), 'PROVIDER_DOWN'],
  ])('%s -> %s', (error, code) => {
    const mapped = mapYahooError(error, 'RELIANCE.NS');
    expect(mapped.code).toBe(code);
    expect(mapped.details).toMatchObject({ provider: 'yahoo', symbol: 'RELIANCE.NS' });
  });

  it('bounds a stalled Yahoo request with a deadline and maps it to TIMEOUT', async () => {
    const stalled: YahooClient = {
      chart: () => new Promise<YahooChart>(() => undefined),
      quote: () => new Promise<YahooSnapshot>(() => undefined),
    };
    const p = new YahooMarketDataProvider(
      stalled,
      { acquire: async () => undefined },
      { timeoutMs: 30 },
    );
    await expect(p.getHistorical(REF, new Date(), new Date(), '1d')).rejects.toMatchObject({
      code: 'TIMEOUT',
    });
    await expect(p.getQuote(REF)).rejects.toMatchObject({ code: 'TIMEOUT' });
  });
});
