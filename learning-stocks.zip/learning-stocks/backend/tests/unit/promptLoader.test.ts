import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { loadPrompt, PROMPT_NAMES, renderPrompt } from '../../src/ai/promptLoader.js';

function tempPrompts(body: string, shared = 'SHARED RULES v1') {
  const dir = mkdtempSync(join(tmpdir(), 'prompts-'));
  writeFileSync(join(dir, 'shared_rules_v1.txt'), shared);
  writeFileSync(join(dir, 'stock_qa_v1.txt'), body);
  return dir;
}

describe('promptLoader', () => {
  it('loads every shipped prompt with the shared rules inlined', () => {
    for (const name of PROMPT_NAMES) {
      const p = loadPrompt(name);
      expect(p.version).toBe(name);
      expect(p.system).toContain('Use ONLY the supplied context');
      expect(p.system).not.toContain('{{shared_rules}}');
      expect(p.user.length).toBeGreaterThan(0);
      expect(p.templateHash).toMatch(/^[a-f0-9]{64}$/);
    }
  });

  it('renders variables once and refuses missing ones', () => {
    const dir = tempPrompts(
      '# header\n### SYSTEM\n{{shared_rules}}\nBe careful.\n### USER\nQ: {{question}}\n{{context}}',
    );
    const p = loadPrompt('stock_qa_v1', dir);
    expect(p.system).toBe('SHARED RULES v1\nBe careful.');
    const r = renderPrompt(p, { question: 'what is {{context}}?', context: 'CTX' });
    expect(r.user).toBe('Q: what is {{context}}?\nCTX');
    expect(() => renderPrompt(p, { question: 'q' })).toThrow(/missing prompt variable: context/);
  });

  it('changes the template hash when the prompt or the shared rules change', () => {
    const body = '### SYSTEM\n{{shared_rules}}\n### USER\n{{question}}';
    const a = loadPrompt('stock_qa_v1', tempPrompts(body)).templateHash;
    const b = loadPrompt('stock_qa_v1', tempPrompts(`${body}!`)).templateHash;
    const c = loadPrompt('stock_qa_v1', tempPrompts(body, 'SHARED RULES v1 edited')).templateHash;
    expect(new Set([a, b, c]).size).toBe(3);
  });
});
