import { describe, expect, it } from 'vitest';
import { allGates, enabledGate, intradayWindowGate, tradingDayGate } from '../../src/jobs/gates.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { CASE_HOLIDAYS } from '../fixtures/calendarCases.js';
import { InMemoryHolidays } from '../fixtures/inMemoryHolidays.js';

const sessions = () =>
  new MarketCalendarService(new InMemoryHolidays(CASE_HOLIDAYS), new MemoryCache());
const FIVE_MIN = 5 * 60_000;

describe('tradingDayGate', () => {
  it('judges the IST date, not the UTC date', async () => {
    const gate = tradingDayGate(sessions(), 'NSE');
    // 2026-10-05T22:00Z is 03:30 IST on Oct 6 — a Tuesday, a trading day.
    expect(await gate(new Date('2026-10-05T22:00:00Z'))).toEqual({ run: true });
    // 2026-10-06T19:00Z is 00:30 IST on Oct 7, which is a holiday in the fixture.
    expect(await gate(new Date('2026-10-06T19:00:00Z'))).toMatchObject({ run: false });
  });

  it('refuses a weekend with a reason naming the date', async () => {
    const r = await tradingDayGate(sessions(), 'NSE')(new Date('2026-10-10T06:00:00Z'));
    expect(r).toMatchObject({ run: false });
    if (!r.run) expect(r.reason).toMatch(/2026-10-10/);
  });
});

describe('intradayWindowGate', () => {
  const gate = () => intradayWindowGate(sessions(), 'NSE', FIVE_MIN);

  it('runs for the tick at the close, which carries the last completed bar', async () => {
    // 15:30 IST = 10:00Z. isOpen() is false here, but [15:25, 15:30) was in session.
    expect(await gate()(new Date('2026-10-05T10:00:00Z'))).toEqual({ run: true });
  });

  it('runs at the open tick and inside the session', async () => {
    expect(await gate()(new Date('2026-10-05T03:50:00Z'))).toEqual({ run: true });
    expect(await gate()(new Date('2026-10-05T06:00:00Z'))).toEqual({ run: true });
  });

  it('does not run before the open or after the close', async () => {
    // 09:15 IST = 03:45Z: the window [09:10, 09:15) is entirely before the open.
    expect(await gate()(new Date('2026-10-05T03:45:00Z'))).toMatchObject({ run: false });
    // 15:35 IST = 10:05Z: the window [15:30, 15:35) is entirely after the close.
    expect(await gate()(new Date('2026-10-05T10:05:00Z'))).toMatchObject({ run: false });
  });

  it('does not run on a non-trading day', async () => {
    expect(await gate()(new Date('2026-10-07T06:00:00Z'))).toMatchObject({ run: false });
  });

  it('covers a special session, including its closing tick, on a Sunday', async () => {
    // Fixture special session 2026-10-11 (a Sunday) is 18:00-19:00 IST = 12:30-13:30Z.
    // 12:35Z = 18:05 IST, inside the session.
    expect(await gate()(new Date('2026-10-11T12:35:00Z'))).toEqual({ run: true });
    // 13:30Z = 19:00 IST, the close: the window [18:55, 19:00) was in session, so this tick runs.
    expect(await gate()(new Date('2026-10-11T13:30:00Z'))).toEqual({ run: true });
    // 06:00Z = 11:30 IST, hours before this day's only session.
    expect(await gate()(new Date('2026-10-11T06:00:00Z'))).toMatchObject({ run: false });
  });
});

describe('enabledGate and allGates', () => {
  it('refuses when a dependency is disabled, naming it', async () => {
    const r = await enabledGate('news provider', null)(new Date());
    expect(r).toMatchObject({ run: false });
    if (!r.run) expect(r.reason).toMatch(/news provider/);
  });

  it('returns the first refusal and runs only when every gate passes', async () => {
    const no = enabledGate('llm', null);
    const yes = enabledGate('llm', {});
    const at = new Date('2026-10-05T06:00:00Z');
    expect(await allGates(yes, tradingDayGate(sessions(), 'NSE'))(at)).toEqual({ run: true });
    expect(await allGates(yes, no, tradingDayGate(sessions(), 'NSE'))(at)).toMatchObject({
      run: false,
    });
  });
});
