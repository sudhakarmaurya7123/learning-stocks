import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { hashEmbedding } from '../../src/providers/llm/mock/hashEmbedding.js';
import { MockLLMProvider } from '../../src/providers/llm/mock/MockLLMProvider.js';
import { EMBEDDING_DIMENSIONS } from '../../src/providers/llm/types.js';
import { cosine } from '../../src/utils/vector.js';

const Out = z.object({ answer: z.string(), score: z.number().int().min(0).max(100) });

describe('hashEmbedding', () => {
  it('is deterministic, 1536-d and unit length', () => {
    const v = hashEmbedding('Reliance Industries quarterly profit rises');
    expect(v).toHaveLength(EMBEDDING_DIMENSIONS);
    expect(v).toEqual(hashEmbedding('Reliance Industries quarterly profit rises'));
    expect(Math.hypot(...v)).toBeCloseTo(1, 10);
  });

  it('places texts sharing words closer than unrelated texts', () => {
    const q = hashEmbedding('Reliance quarterly profit');
    const near = hashEmbedding('Reliance Industries reports higher quarterly profit');
    const far = hashEmbedding('Monsoon rainfall forecast for Kerala');
    expect(cosine(q, near)).toBeGreaterThan(cosine(q, far));
  });

  it('maps empty or stopword-only text to a fixed unit vector (never a zero vector)', () => {
    const v = hashEmbedding('the and of');
    expect(v[0]).toBe(1);
    expect(Math.hypot(...v)).toBe(1);
  });
});

describe('MockLLMProvider', () => {
  it('embeds with usage and its model name', async () => {
    const r = await new MockLLMProvider().embed(['alpha beta', 'gamma']);
    expect(r.vectors).toHaveLength(2);
    expect(r.model).toBe('mock-hash-embedding-v1');
    expect(r.usage).toEqual({ inputTokens: 3 + 2, outputTokens: 0 });
  });

  it('returns schema-valid output derived from the schema when no responder is registered', async () => {
    const r = await new MockLLMProvider().completeStructured({
      system: 's',
      user: 'u',
      schema: Out,
      schemaName: 'out',
    });
    expect(r.data).toEqual({ answer: 'MOCK', score: 50 });
    expect(r.model).toBe('mock-chat-v1');
  });

  it('uses a registered responder and validates its output', async () => {
    const p = new MockLLMProvider({
      responders: {
        out: (req) => ({ answer: `echo:${req.user}`, score: 7 }),
        bad: () => ({ answer: 1 }),
      },
    });
    expect(
      (await p.completeStructured({ system: 's', user: 'hi', schema: Out, schemaName: 'out' }))
        .data,
    ).toEqual({
      answer: 'echo:hi',
      score: 7,
    });
    await expect(
      p.completeStructured({ system: 's', user: 'u', schema: Out, schemaName: 'bad' }),
    ).rejects.toMatchObject({
      code: 'INVALID_RESPONSE',
      details: { provider: 'mock', schemaName: 'bad' },
    });
  });
});
