import { describe, expect, it } from 'vitest';
import { freshness } from '../../src/http/envelope.js';

// 11:30 IST on Tuesday 2026-10-06, mid-session.
const NOW = new Date('2026-10-06T06:00:00Z');
// The open of the most recent COMPLETED session: Monday 2026-10-05, 09:15 IST.
const LAST_COMPLETE_OPEN = new Date('2026-10-05T03:45:00Z');
const open = {
  now: NOW,
  marketOpen: true,
  stalenessMinutes: 20,
  lastCompleteSessionOpen: LAST_COMPLETE_OPEN,
};

/**
 * Phase 9 finding I4.
 *
 * A fixed duration cannot judge a daily fact. Daily bars are stored only after the close plus a
 * 30-minute settle (Phase 3 deviation 3), so mid-session the newest daily fact is the PREVIOUS
 * session's bar — measured: on 2026-10-07 the stored technical.as_of was 2026-10-06T03:45Z. That
 * bar is already over 24h old at today's open, and 72h old on a Monday, so a 24-hour window would
 * report "stale" exactly as often as the bug it replaces. Freshness is session-based instead.
 */
describe('freshness cadence (Phase 9 finding I4)', () => {
  it("treats the previous session's daily bar as fresh mid-session", () => {
    // THE finding: daily facts were judged against the 20-minute quote threshold, so every
    // indicator, evaluation and fundamentals panel read "stale" from 09:35 onward — while being
    // as current as a daily fact can be, because today's bar is not written until after close.
    const mondaysBar = new Date('2026-10-05T03:45:00Z');
    expect(freshness(mondaysBar, { ...open, cadence: 'quote' }).stale).toBe(true);
    expect(freshness(mondaysBar, { ...open, cadence: 'daily' }).stale).toBe(false);
  });

  it('is fresh across a weekend, where a 24-hour window would not be', () => {
    // Monday 11:30 IST with Friday's bar: 72h old and perfectly current. This case is the whole
    // reason the cadence is session-based rather than a duration.
    const monday = new Date('2026-10-12T06:00:00Z');
    const fridaysBar = new Date('2026-10-09T03:45:00Z');
    expect(
      freshness(fridaysBar, {
        now: monday,
        marketOpen: true,
        stalenessMinutes: 20,
        cadence: 'daily',
        lastCompleteSessionOpen: fridaysBar,
      }).stale,
    ).toBe(false);
    // The same bar judged as a QUOTE is stale, which is the distinction this cadence exists for.
    expect(
      freshness(fridaysBar, {
        now: monday,
        marketOpen: true,
        stalenessMinutes: 20,
        cadence: 'quote',
        lastCompleteSessionOpen: fridaysBar,
      }).stale,
    ).toBe(true);
  });

  it('still calls a skipped session stale', () => {
    // Tuesday with Thursday's bar: a session was missed, which is a real problem worth flagging.
    const thursdaysBar = new Date('2026-10-01T03:45:00Z');
    expect(freshness(thursdaysBar, { ...open, cadence: 'daily' }).stale).toBe(true);
  });

  it('judges a quote on the quote threshold, unchanged', () => {
    expect(freshness(new Date('2026-10-06T05:50:00Z'), { ...open, cadence: 'quote' }).stale).toBe(
      false,
    );
    expect(freshness(new Date('2026-10-06T05:20:00Z'), { ...open, cadence: 'quote' }).stale).toBe(
      true,
    );
  });

  it('defaults to the quote cadence, so existing callers are unchanged', () => {
    const { cadence, ...rest } = { ...open, cadence: 'quote' as const };
    expect(cadence).toBe('quote');
    expect(freshness(new Date('2026-10-06T05:20:00Z'), rest).stale).toBe(true);
    expect(freshness(new Date('2026-10-06T05:20:00Z'), rest).cadence).toBe('quote');
  });

  it('reports which cadence judged it, so the UI can explain the badge', () => {
    expect(freshness(NOW, { ...open, cadence: 'daily' }).cadence).toBe('daily');
  });

  it('never marks anything stale while the market is closed, whatever the cadence', () => {
    const closed = { ...open, marketOpen: false };
    const ancient = new Date('2026-01-01T03:45:00Z');
    for (const cadence of ['quote', 'daily'] as const) {
      expect(freshness(ancient, { ...closed, cadence }).stale).toBe(false);
    }
  });

  it('falls back to the quote threshold when the caller cannot supply a session', () => {
    // A CLI or a degraded calendar read has no session to compare against. Fall back rather than
    // throw: a freshness badge must never be the thing that fails a page.
    const noSession: Omit<typeof open, 'lastCompleteSessionOpen'> = {
      now: open.now,
      marketOpen: open.marketOpen,
      stalenessMinutes: open.stalenessMinutes,
    };
    expect(
      freshness(new Date('2026-10-06T05:59:00Z'), { ...noSession, cadence: 'daily' }).stale,
    ).toBe(false);
    expect(
      freshness(new Date('2026-10-06T05:20:00Z'), { ...noSession, cadence: 'daily' }).stale,
    ).toBe(true);
  });

  it('reports a missing fact as stale with null age, under either cadence', () => {
    for (const cadence of ['quote', 'daily'] as const) {
      const f = freshness(null, { ...open, cadence });
      expect(f).toMatchObject({ as_of: null, age_seconds: null, stale: true });
    }
  });
});
