import { describe, expect, it } from 'vitest';
import { type DecisionInput, decide } from '../../src/scoring/DecisionEngine.js';
import { SEED_CONFIG } from '../fixtures/scoringConfig.js';

const T = SEED_CONFIG.thresholds;
/** A clean BUY_ZONE setup; each test changes one thing. */
const ready = (over: Partial<DecisionInput> = {}): DecisionInput => ({
  dailyBars: 500,
  price: 100.2,
  stale: false,
  lastBarDate: '2026-10-05',
  overall: 70,
  qualityScore: 60,
  trend: 'UPTREND',
  regime: 'RISK_ON',
  valuationLabel: 'FAIR',
  sma50: 100,
  sma200: 90,
  rsi14: 55,
  atr14: 2,
  trade: {
    basis: 'SUPPORT',
    entryLow: 99,
    entryHigh: 101,
    stop: 96,
    target1: 110,
    target2: 115,
    riskReward: 2.2,
    positionSizeHint: 100,
  },
  holdsPosition: false,
  ...over,
});
const fixtureTrade = () => {
  const trade = ready().trade;
  if (!trade) throw new Error('fixture has a trade');
  return trade;
};
const BANNED = /guarantee|definitely|sure-shot|certain to|risk-free/i;

describe('decide (PRD §8.5)', () => {
  it('rule 5: BUY_ZONE with a priced invalidation; strong bias at overall ≥ 80', () => {
    const d = decide(ready(), T);
    expect(d).toMatchObject({
      actionState: 'BUY_ZONE',
      bias: 'BUY_BIAS',
      paperSignal: 'BUY',
      rule: 5,
    });
    expect(d.invalidation).toContain('₹96.00');
    expect(decide(ready({ overall: 85 }), T).bias).toBe('STRONG_BUY_BIAS');
  });

  it('rule 1: insufficient bars, no price, stale data or no score → INSUFFICIENT_DATA', () => {
    for (const over of [
      { dailyBars: 150 },
      { price: null },
      { overall: null },
    ] as Partial<DecisionInput>[]) {
      expect(decide(ready(over), T)).toMatchObject({
        actionState: 'INSUFFICIENT_DATA',
        bias: null,
        paperSignal: 'HOLD',
        rule: 1,
      });
    }
    const stale = decide(ready({ stale: true, lastBarDate: '2026-09-20' }), T);
    expect(stale.actionState).toBe('INSUFFICIENT_DATA');
    expect(stale.invalidation).toMatch(/2026-09-20/);
  });

  it('rule 2: AVOID on a weak overall score; REDUCE when a paper position is held', () => {
    expect(decide(ready({ overall: 30 }), T)).toMatchObject({
      actionState: 'AVOID',
      bias: 'SELL_BIAS',
      paperSignal: 'HOLD',
      rule: 2,
    });
    expect(decide(ready({ overall: 20 }), T).bias).toBe('STRONG_SELL_BIAS');
    expect(decide(ready({ overall: 30, holdsPosition: true }), T)).toMatchObject({
      actionState: 'REDUCE',
      bias: 'SELL_BIAS',
      paperSignal: 'SELL',
    });
    const weakAll = ready({
      overall: 50,
      trend: 'DOWNTREND',
      regime: 'RISK_OFF',
      qualityScore: 30,
      price: 85,
    });
    expect(decide(weakAll, T)).toMatchObject({ actionState: 'AVOID', rule: 2 });
    expect(decide(weakAll, T).invalidation).toContain('₹90.00');
  });

  it('rule 3: below SMA200 or in a downtrend → WAIT_FOR_CONFIRMATION (quality acceptable)', () => {
    const below = decide(ready({ price: 85 }), T);
    expect(below).toMatchObject({
      actionState: 'WAIT_FOR_CONFIRMATION',
      bias: 'HOLD_BIAS',
      rule: 3,
    });
    expect(below.invalidation).toContain('₹90.00');
    expect(
      decide(
        ready({ overall: 50, trend: 'DOWNTREND', regime: 'RISK_OFF', qualityScore: 60, price: 85 }),
        T,
      ).actionState,
    ).toBe('WAIT_FOR_CONFIRMATION');
  });

  it('rule 4: extended above SMA50, overbought RSI or above entry + ATR → WAIT_FOR_PULLBACK', () => {
    const extended = decide(ready({ price: 109 }), T);
    expect(extended).toMatchObject({ actionState: 'WAIT_FOR_PULLBACK', rule: 4 });
    expect(extended.invalidation).toContain('₹99.00–₹101.00');
    expect(decide(ready({ rsi14: 75 }), T).actionState).toBe('WAIT_FOR_PULLBACK');
    expect(decide(ready({ price: 103.5 }), T).actionState).toBe('WAIT_FOR_PULLBACK');
  });

  it('first matching rule wins', () => {
    expect(decide(ready({ overall: 30, price: 85 }), T).rule).toBe(2);
    expect(decide(ready({ price: 85, rsi14: 80 }), T).rule).toBe(3);
    expect(decide(ready({ rsi14: 75, valuationLabel: 'OVERVALUED' }), T).rule).toBe(4);
  });

  it('rule 6: HOLD when any BUY_ZONE condition fails', () => {
    for (const over of [
      { valuationLabel: 'OVERVALUED' },
      { trade: { ...fixtureTrade(), riskReward: 1.5 } },
      { regime: 'RISK_OFF' },
      { price: 102 },
      { overall: 60 },
      { trade: null },
    ] as Partial<DecisionInput>[]) {
      expect(decide(ready(over), T)).toMatchObject({
        actionState: 'HOLD',
        bias: 'HOLD_BIAS',
        paperSignal: 'HOLD',
        rule: 6,
      });
    }
    expect(decide(ready({ overall: 60 }), T).invalidation).toContain('₹96.00');
  });

  it('never uses banned certainty language', () => {
    const states = [
      ready(),
      ready({ dailyBars: 10 }),
      ready({ overall: 30 }),
      ready({ price: 85 }),
      ready({ price: 109 }),
      ready({ overall: 60 }),
      ready({ trade: null, overall: 60 }),
    ];
    for (const s of states) expect(decide(s, T).invalidation).not.toMatch(BANNED);
  });
});
