import { describe, expect, it } from 'vitest';
import {
  buildMarketContext,
  type MarketContextInput,
  vixRiskLevel,
} from '../../src/ai/marketContext.js';

const AS_OF = new Date('2026-10-05T03:45:00Z');
const input: MarketContextInput = {
  dataMode: 'MOCK',
  indices: [
    {
      symbol: 'NIFTY50',
      name: 'NIFTY 50',
      price: 24850.5,
      changePercent: -0.42,
      asOf: AS_OF,
      timeframe: '1d',
      returnsPct: { w1: -1.2, m1: 2.5, m3: null },
    },
  ],
  regime: { asOf: AS_OF, regime: 'RISK_OFF', niftyTrend: 'DOWNTREND', vix: 21.4 },
  sectors: [
    { sector: 'Banks', trend: 'DOWNTREND', stocks: 5 },
    { sector: 'IT', trend: null, stocks: 4 },
  ],
  breadth: {
    asOf: AS_OF,
    evaluated: 20,
    byAction: { AVOID: 5, WAIT_FOR_CONFIRMATION: 11, HOLD: 4 },
    byTrend: { DOWNTREND: 9, SIDEWAYS: 8, UPTREND: 3 },
  },
  newsSentiment: { asOf: AS_OF, articles: 12, bullish: 3, neutral: 5, bearish: 4, avgScore: 47.5 },
  documents: [],
};

describe('vixRiskLevel', () => {
  it('maps India VIX bands', () => {
    expect([10, 15, 19.9, 20, 24.9, 25, null].map(vixRiskLevel)).toEqual([
      'LOW',
      'MEDIUM',
      'MEDIUM',
      'HIGH',
      'HIGH',
      'VERY_HIGH',
      null,
    ]);
  });
});

describe('buildMarketContext', () => {
  it('issues I/M/S/B/D blocks, lists allowed sectors and stamps daily values at the session close', () => {
    const c = buildMarketContext(input);
    expect([...c.ids]).toEqual(['I1', 'M1', 'S1', 'B1', 'D1']);
    expect([...c.sectors]).toEqual(['Banks', 'IT']);
    expect(c.text).toContain('[I1] INDEX: NIFTY 50 (as of close of session 2026-10-05)');
    expect(c.text).toContain(
      '- Level 24850.50 (-0.42% vs previous close); returns 1W -1.20% · 1M +2.50% · 3M n/a',
    );
    expect(c.text).toContain(
      '- Regime RISK_OFF; NIFTY 50 trend DOWNTREND; India VIX 21.40; risk level HIGH',
    );
    expect(c.text).toContain('- Banks: sector-index trend DOWNTREND (5 stocks covered)');
    expect(c.text).toContain(
      '- 20 stocks evaluated; action states AVOID 5, HOLD 4, WAIT_FOR_CONFIRMATION 11; trends DOWNTREND 9, SIDEWAYS 8, UPTREND 3',
    );
    expect(c.missing).toEqual(['documents']);
    expect(buildMarketContext(input).contextHash).toBe(c.contextHash);
  });
});
