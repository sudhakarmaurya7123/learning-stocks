import { describe, expect, it } from 'vitest';
import { AppError, isAppError, toAppError } from '../../src/utils/errors.js';

describe('AppError', () => {
  it('marks only transient failures as retryable (auth failures never retry)', () => {
    for (const code of ['TIMEOUT', 'RATE_LIMITED', 'NETWORK', 'PROVIDER_DOWN'] as const) {
      expect(new AppError(code, 'x').retryable).toBe(true);
    }
    for (const code of [
      'AUTH_FAILED',
      'INVALID_RESPONSE',
      'EMPTY_RESPONSE',
      'UNSUPPORTED',
      'VALIDATION',
      'NOT_FOUND',
    ] as const) {
      expect(new AppError(code, 'x').retryable).toBe(false);
    }
  });

  it('maps codes to HTTP statuses', () => {
    expect(new AppError('VALIDATION', 'x').httpStatus).toBe(400);
    expect(new AppError('NOT_FOUND', 'x').httpStatus).toBe(404);
    expect(new AppError('PROVIDER_DOWN', 'x').httpStatus).toBe(503);
    expect(new AppError('INTERNAL', 'x').httpStatus).toBe(500);
  });

  it('keeps cause, details and retryAfterMs', () => {
    const cause = new Error('root');
    const e = new AppError('RATE_LIMITED', 'slow down', {
      cause,
      details: { provider: 'yahoo' },
      retryAfterMs: 2000,
    });
    expect(e.cause).toBe(cause);
    expect(e.details).toEqual({ provider: 'yahoo' });
    expect(e.retryAfterMs).toBe(2000);
    expect(isAppError(e)).toBe(true);
    expect(isAppError(new Error('plain'))).toBe(false);
  });

  it('treats BUDGET_EXCEEDED as a non-retryable 429', () => {
    const e = new AppError('BUDGET_EXCEEDED', 'daily LLM budget reached');
    expect(e.retryable).toBe(false);
    expect(e.httpStatus).toBe(429);
  });
});

describe('toAppError', () => {
  it('passes AppErrors through and wraps anything else as INTERNAL', () => {
    const e = new AppError('TIMEOUT', 'slow');
    expect(toAppError(e)).toBe(e);
    expect(toAppError(new Error('boom'))).toMatchObject({ code: 'INTERNAL', message: 'boom' });
    expect(toAppError('text')).toMatchObject({ code: 'INTERNAL', message: 'text' });
  });
});
