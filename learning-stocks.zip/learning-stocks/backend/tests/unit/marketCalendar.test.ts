import { describe, expect, it } from 'vitest';
import type { Holiday } from '../../src/domain/types.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { addDays, istToUtc, toIst } from '../../src/utils/ist.js';
import { CASE_HOLIDAYS, NEXT_OPEN_CASES, OPEN_CASES } from '../fixtures/calendarCases.js';
import { InMemoryHolidays } from '../fixtures/inMemoryHolidays.js';

const service = (holidays: Holiday[] = CASE_HOLIDAYS) =>
  new MarketCalendarService(new InMemoryHolidays(holidays), new MemoryCache());

describe('ist utils', () => {
  it('converts across the UTC/IST date boundary', () => {
    expect(toIst(new Date('2026-10-05T22:00:00Z'))).toMatchObject({
      date: '2026-10-06',
      isoWeekday: 2,
    });
    expect(istToUtc('2026-10-05', '09:15:00').toISOString()).toBe('2026-10-05T03:45:00.000Z');
  });
});

describe('MarketCalendarService', () => {
  it.each(OPEN_CASES)('isOpen: $label', async ({ exchange, at, open }) => {
    expect(await service().isOpen(exchange, new Date(at))).toBe(open);
  });

  it.each(NEXT_OPEN_CASES)('nextOpen: $label', async ({ at, next }) => {
    expect((await service().nextOpen('NSE', new Date(at)))?.toISOString()).toBe(
      new Date(next).toISOString(),
    );
  });

  it('finds the next session across a year boundary', async () => {
    const next = await service([]).nextOpen('NSE', new Date('2026-12-31T16:00:00+05:30'));
    expect(next?.toISOString()).toBe('2027-01-01T03:45:00.000Z');
  });

  it('reports status phases with holiday names and next open', async () => {
    const s = service();
    expect(await s.status('NSE', new Date('2026-10-05T10:00:00+05:30'))).toMatchObject({
      isOpen: true,
      phase: 'OPEN',
      holiday: null,
    });
    expect(await s.status('NSE', new Date('2026-10-05T16:00:00+05:30'))).toMatchObject({
      isOpen: false,
      phase: 'CLOSED',
    });
    expect(await s.status('NSE', new Date('2026-10-10T11:00:00+05:30'))).toMatchObject({
      phase: 'WEEKEND',
    });
    const holiday = await s.status('NSE', new Date('2026-10-07T11:00:00+05:30'));
    expect(holiday).toMatchObject({ phase: 'HOLIDAY', holiday: 'TEST HOLIDAY (Wed)' });
    expect(holiday.nextOpen?.toISOString()).toBe('2026-10-08T03:45:00.000Z');
  });

  it('knows trading days (special sessions count)', async () => {
    const s = service();
    expect(await s.isTradingDay('NSE', '2026-10-05')).toBe(true);
    expect(await s.isTradingDay('NSE', '2026-10-07')).toBe(false);
    expect(await s.isTradingDay('NSE', '2026-10-10')).toBe(false);
    expect(await s.isTradingDay('NSE', '2026-10-11')).toBe(true);
  });

  it('caches holiday lookups per exchange and year', async () => {
    const lookup = new InMemoryHolidays(CASE_HOLIDAYS);
    const s = new MarketCalendarService(lookup, new MemoryCache());
    await s.isOpen('NSE', new Date('2026-10-05T10:00:00+05:30'));
    await s.isOpen('NSE', new Date('2026-10-06T10:00:00+05:30'));
    expect(lookup.calls).toBe(1);
  });

  it('exposes the session window for a date (regular, special, closed)', async () => {
    const s = service();
    expect(await s.sessionOn('NSE', '2026-10-05')).toEqual({
      open: new Date('2026-10-05T03:45:00Z'),
      close: new Date('2026-10-05T10:00:00Z'),
    });
    expect(await s.sessionOn('NSE', '2026-10-11')).toEqual({
      open: new Date('2026-10-11T12:30:00Z'),
      close: new Date('2026-10-11T13:30:00Z'),
    });
    expect(await s.sessionOn('NSE', '2026-10-07')).toBeNull();
  });

  /**
   * The reference point for judging a daily fact's freshness (Phase 9 finding I4).
   *
   * Daily bars land only after the close plus a settle, so "is this daily fact current?" cannot be
   * answered with a duration — mid-session the newest one is yesterday's, and on a Monday it is
   * Friday's. It is current iff it is at or after the open of the most recent COMPLETED session.
   */
  describe('lastCompleteSessionOpen', () => {
    const SETTLE_MS = 30 * 60_000;

    it("returns the previous session's open while today's session is still running", async () => {
      // Tuesday 2026-10-06, 11:30 IST. Today's bar does not exist yet, so Monday's is the newest
      // complete fact and the one freshness must be measured against.
      const at = new Date('2026-10-06T06:00:00Z');
      expect(await service().lastCompleteSessionOpen('NSE', at)).toEqual(
        new Date('2026-10-05T03:45:00Z'),
      );
    });

    it("returns today's open once the close plus settle has passed", async () => {
      // 16:05 IST on Monday: the close was 15:30 and the 30-minute settle has elapsed, so today's
      // bar is written and today's session is the reference.
      const at = new Date('2026-10-05T10:35:00Z');
      expect(await service().lastCompleteSessionOpen('NSE', at)).toEqual(
        new Date('2026-10-05T03:45:00Z'),
      );
    });

    it('does not count a session whose settle has not elapsed', async () => {
      // 15:45 IST: closed, but inside the settle window, so the provider may still revise the
      // close. Treating it as complete would freeze a bar that is about to change.
      const at = new Date('2026-10-05T10:15:00Z');
      expect(await service().lastCompleteSessionOpen('NSE', at)).toEqual(
        new Date('2026-10-02T03:45:00Z'),
      );
    });

    it('skips weekends and holidays', async () => {
      // Monday 2026-10-12, 11:30 IST. Friday the 9th is the last regular session; the 11th is a
      // special Sunday session in the fixture, which DOES count — it is a real session.
      const monday = new Date('2026-10-12T06:00:00Z');
      expect(await service().lastCompleteSessionOpen('NSE', monday)).toEqual(
        new Date('2026-10-11T12:30:00Z'),
      );
      // Thursday 2026-10-08, 11:30 IST: Wednesday the 7th is a holiday, so Tuesday the 6th stands.
      const thursday = new Date('2026-10-08T06:00:00Z');
      expect(await service().lastCompleteSessionOpen('NSE', thursday)).toEqual(
        new Date('2026-10-06T03:45:00Z'),
      );
    });

    it('is exactly the settle boundary, not approximately', async () => {
      const close = new Date('2026-10-05T10:00:00Z');
      const justBefore = new Date(close.getTime() + SETTLE_MS - 1);
      const exactly = new Date(close.getTime() + SETTLE_MS);
      expect(await service().lastCompleteSessionOpen('NSE', justBefore)).toEqual(
        new Date('2026-10-02T03:45:00Z'),
      );
      expect(await service().lastCompleteSessionOpen('NSE', exactly)).toEqual(
        new Date('2026-10-05T03:45:00Z'),
      );
    });

    it('returns null when the search window holds no complete session', async () => {
      // Every day in the lookback declared a full-day holiday: there is no reference session, so
      // the answer is null and the caller falls back to the quote threshold rather than throwing.
      // Asserted by construction, not by hoping a real date runs the search out.
      const start = '2026-09-01';
      const allClosed: Holiday[] = Array.from({ length: 60 }, (_, i) => ({
        exchange: 'NSE' as const,
        date: addDays(start, i),
        description: 'CLOSED FOR THE TEST',
        specialOpen: null,
        specialClose: null,
      }));
      const shut = new MarketCalendarService(new InMemoryHolidays(allClosed), new MemoryCache());
      expect(
        await shut.lastCompleteSessionOpen('NSE', new Date('2026-10-20T06:00:00Z')),
      ).toBeNull();
    });
  });
});
