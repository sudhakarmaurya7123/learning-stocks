import { describe, expect, it } from 'vitest';
import { parseRssFeed } from '../../src/providers/news/rss/feedParser.js';
import {
  googleNewsSearchUrl,
  RssNewsProvider,
} from '../../src/providers/news/rss/RssNewsProvider.js';
import { AppError } from '../../src/utils/errors.js';
import {
  BOT_BLOCK_HTML,
  EMPTY_CHANNEL_XML,
  ET_XML,
  GOOGLE_NEWS_XML,
  MINT_SINGLE_ITEM_XML,
} from '../fixtures/news/feeds.js';

const NOW = () => new Date('2026-10-05T18:00:00Z');
const RELIANCE = { symbol: 'RELIANCE', name: 'Reliance Industries', aliases: ['RIL'] };

function provider(
  responses: Record<string, string | Error>,
  feeds = [
    { name: 'ET', url: 'https://et.example/rss' },
    { name: 'Mint', url: 'https://mint.example/rss' },
  ],
) {
  const fetched: string[] = [];
  let acquired = 0;
  const p = new RssNewsProvider(
    {
      acquire: async () => {
        acquired += 1;
      },
    },
    {
      now: NOW,
      marketFeeds: feeds,
      fetchText: async (url) => {
        fetched.push(url);
        const key = Object.keys(responses).find((k) => url.startsWith(k));
        const r = key === undefined ? undefined : responses[key];
        if (r === undefined) throw new Error(`unexpected fetch ${url}`);
        if (r instanceof Error) throw r;
        return r;
      },
    },
  );
  return { p, fetched, acquired: () => acquired };
}

describe('parseRssFeed', () => {
  it('reads RSS items including CDATA, attributes and escaped HTML', () => {
    const [g] = parseRssFeed(GOOGLE_NEWS_XML, 'google');
    expect(g).toMatchObject({
      title: 'Reliance Industries raises funds through bonds - Business Standard',
      sourceName: 'Business Standard',
      sourceUrl: 'https://www.business-standard.com',
      link: 'https://news.google.com/rss/articles/CBMiAAA?oc=5',
    });
    expect(g?.description).toContain('<a href=');
    const et = parseRssFeed(ET_XML, 'et');
    expect(et[0]?.title).toBe(
      'Ahead of Market: things that will decide stock market action on Tuesday',
    );
    expect(et[1]?.title).toBe('2026');
  });

  it('treats a single item as a list, and an empty channel as no items', () => {
    const mint = parseRssFeed(MINT_SINGLE_ITEM_XML, 'mint');
    expect(mint).toHaveLength(1);
    expect(mint[0]).toMatchObject({
      link: 'https://www.livemint.com/market/stock-market-news/nifty-prediction-1.html',
      pubDate: 'Mon, 05 Oct 2026 23:17:54 +0530',
    });
    expect(parseRssFeed(EMPTY_CHANNEL_XML, 'empty')).toEqual([]);
  });

  it('rejects non-RSS bodies (bot-block pages) as INVALID_RESPONSE', () => {
    expect(() => parseRssFeed(BOT_BLOCK_HTML, 'blocked')).toThrow(
      expect.objectContaining({ code: 'INVALID_RESPONSE' }),
    );
  });
});

describe('RssNewsProvider', () => {
  it('searches Google News for the quoted company name in India English, stripping the publisher suffix', async () => {
    const { p, fetched, acquired } = provider({ 'https://news.google.com/': GOOGLE_NEWS_XML });
    const r = await p.fetchForInstruments({
      subjects: [RELIANCE],
      since: new Date('2026-09-28T18:00:00Z'),
      limit: 10,
    });
    expect(fetched[0]).toBe(googleNewsSearchUrl('"Reliance Industries"', 7));
    expect(fetched[0]).toContain('q=%22Reliance+Industries%22+when%3A7d');
    expect(fetched[0]).toContain('ceid=IN%3Aen');
    expect(r.articles[0]).toMatchObject({
      title: 'Reliance Industries raises funds through bonds',
      publisherUrl: 'https://www.business-standard.com',
      publishedAt: new Date('2026-10-05T15:06:07Z'),
    });
    expect(r.articles.find((a) => a.title === 'RIL shares in focus')?.publishedAt).toBeNull();
    expect(acquired()).toBe(1);
  });

  it('refuses more than one instrument per query', async () => {
    const { p } = provider({});
    await expect(
      p.fetchForInstruments({ subjects: [RELIANCE, RELIANCE], since: new Date(), limit: 5 }),
    ).rejects.toMatchObject({ code: 'INTERNAL' });
  });

  it('isolates a failing market feed and reports it; throws only when every feed fails', async () => {
    const partial = provider({
      'https://et.example/': ET_XML,
      'https://mint.example/': new AppError(
        'AUTH_FAILED',
        'Authentication failed calling https://mint.example/rss',
      ),
    });
    const r = await partial.p.fetchMarketNews({
      since: new Date('2026-10-01T00:00:00Z'),
      limit: 50,
    });
    expect(r.articles.map((a) => a.title)).toContain(
      'Ahead of Market: things that will decide stock market action on Tuesday',
    );
    expect(r.failures).toEqual([
      { source: 'Mint', code: 'PROVIDER_DOWN', message: 'Mint blocked the request' },
    ]);

    const dead = provider({
      'https://et.example/': new AppError('TIMEOUT', 'slow'),
      'https://mint.example/': BOT_BLOCK_HTML,
    });
    await expect(dead.p.fetchMarketNews({ since: new Date(), limit: 5 })).rejects.toMatchObject({
      code: 'TIMEOUT',
    });
  });
});
