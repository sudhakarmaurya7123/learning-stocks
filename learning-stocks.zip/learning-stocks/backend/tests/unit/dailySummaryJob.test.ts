import { describe, expect, it } from 'vitest';
import { dailySummaryJob } from '../../src/jobs/handlers/ai.js';

/** Only what dailySummaryJob touches: the calendar for the gate, and the summary service. */
const containerFor = () => {
  const calls: Array<{ force: boolean }> = [];
  const container = {
    config: { dataMode: 'MOCK' as const },
    services: {
      calendar: {
        sessionOn: async (_e: string, date: string) =>
          // Mon 2026-10-05 and Tue 2026-10-06 trade; 2026-10-07 is a holiday.
          date === '2026-10-05' || date === '2026-10-06'
            ? {
                open: new Date(`${date}T03:45:00Z`),
                close: new Date(`${date}T10:00:00Z`),
              }
            : null,
      },
      ai: {
        marketSummary: {
          run: async (req: { force: boolean }) => {
            calls.push({ force: req.force });
            return {
              runId: 'service-run',
              status: 'SUCCESS' as const,
              outcome: 'GENERATED',
              summaryId: 's1',
              notes: [],
            };
          },
        },
      },
    },
  } as never;
  return { container, calls };
};

describe('dailySummaryJob freshness', () => {
  it('generates the forced summary shortly after the close it is for', async () => {
    const { container, calls } = containerFor();
    // 16:15 IST on Tuesday = 10:45Z, 45 min after that day's 15:30 close.
    const outcome = await dailySummaryJob(container).run({}, new Date('2026-10-06T10:45:00Z'));
    expect(outcome.status).toBe('SUCCESS');
    expect(calls).toEqual([{ force: true }]);
  });

  it('skips a recovered run whose close is long past, instead of forcing a stale summary', async () => {
    const { container, calls } = containerFor();
    // missed:'once' carries no occurrence identity, so a job recovered on Tuesday morning after
    // a Monday-evening outage arrives with `at` = now. Forcing here bypasses the hash cache and
    // spends real money stamping a mid-morning summary as the previous day's close.
    const gate = dailySummaryJob(container).gate;
    const recovered = new Date('2026-10-06T04:30:00Z'); // 10:00 IST Tuesday, mid-session
    await expect(gate?.(recovered)).resolves.toMatchObject({ run: false });
    expect(calls).toEqual([]);
  });

  it('still refuses a non-trading day', async () => {
    const { container } = containerFor();
    const gate = dailySummaryJob(container).gate;
    await expect(gate?.(new Date('2026-10-07T10:45:00Z'))).resolves.toMatchObject({ run: false });
  });
});
