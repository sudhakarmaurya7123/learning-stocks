import { describe, expect, it } from 'vitest';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';
import type { Bar, Stock } from '../../src/domain/types.js';
import { toFundamentalsDto } from '../../src/dto/fundamentals.js';
import { toQuoteDto } from '../../src/dto/market.js';
import { toStockDto } from '../../src/dto/stock.js';

const STOCK: Stock = {
  id: 's-1',
  symbol: 'RELIANCE',
  companyName: 'Reliance Industries Ltd',
  exchange: 'NSE',
  isin: 'INE002A01018',
  isinVerified: true,
  sector: 'Oil Gas & Consumable Fuels',
  industry: 'Refineries',
  marketCap: 1_900_000_000_000,
  currency: 'INR',
  isActive: true,
  aliases: ['RIL'],
};

const BAR: Bar = {
  instrument: { kind: 'stock', id: 's-1' },
  dataMode: 'MOCK',
  timeframe: '1d',
  ts: new Date('2026-10-06T03:45:00Z'),
  open: 1171.2,
  high: 1193,
  low: 1171.2,
  close: 1186.4,
  adjustedClose: 1186.4,
  volume: 14_251_054,
  change: 15.2,
  changePercent: 1.3,
  vwap: null,
  source: 'mock',
};

describe('toStockDto', () => {
  it('maps to the exact snake_case key set Phase 10 renders', () => {
    expect(Object.keys(toStockDto(STOCK)).sort()).toEqual([
      'company_name',
      'currency',
      'exchange',
      'industry',
      'isin',
      'isin_verified',
      'market_cap',
      'sector',
      'symbol',
    ]);
  });

  it('does not leak the internal id', () => {
    // The wire identifier is the symbol; exposing a row uuid invites it into URLs and bookmarks.
    expect(toStockDto(STOCK)).not.toHaveProperty('id');
  });
});

describe('toQuoteDto', () => {
  it('maps to the exact key set, with timestamps as ISO-8601 UTC strings', () => {
    const dto = toQuoteDto(BAR);
    expect(Object.keys(dto).sort()).toEqual([
      'change',
      'change_percent',
      'close',
      'high',
      'low',
      'open',
      'source',
      'timeframe',
      'ts',
      'volume',
      'vwap',
    ]);
    expect(dto.ts).toBe('2026-10-06T03:45:00.000Z');
  });

  it('keeps an unavailable value as null rather than 0 or absent', () => {
    // 0 and null mean different things on a research desk: "the VWAP is zero" versus "we do not
    // have it". A dropped key renders as undefined and silently blanks a panel.
    const dto = toQuoteDto({ ...BAR, vwap: null, change: null, changePercent: null });
    expect(dto.vwap).toBeNull();
    expect(dto.change).toBeNull();
    expect('vwap' in dto).toBe(true);
    expect('change' in dto).toBe(true);
  });

  it('emits numbers, not numeric strings', () => {
    // pg returns numeric as a string. A JSON string here would break every chart in Phase 10.
    expect(typeof toQuoteDto(BAR).close).toBe('number');
    expect(toQuoteDto(BAR).close).toBe(1186.4);
  });
});

describe('toFundamentalsDto', () => {
  it('exposes every snapshot metric in snake_case, nulls included', () => {
    const dto = toFundamentalsDto({
      stockId: 's-1',
      dataMode: 'MOCK',
      asOf: '2026-10-06',
      source: 'mock',
      metrics: { ...emptySnapshotMetrics(), pe: 24.5, roe: 9.1 },
      raw: {},
    });
    expect(dto.as_of).toBe('2026-10-06');
    expect(dto.pe).toBe(24.5);
    expect(dto.roe).toBe(9.1);
    // A metric the provider does not supply stays present and null, never dropped.
    expect(dto.debt_to_equity).toBeNull();
    expect('debt_to_equity' in dto).toBe(true);
    expect(dto.market_cap).toBeNull();
    // Every metric is accounted for: 17 snapshot fields plus as_of and source.
    expect(Object.keys(dto)).toHaveLength(19);
  });

  it('never exposes the provider raw blob', () => {
    // `raw` is a debugging aid holding whatever the provider sent; it is not a wire contract.
    const dto = toFundamentalsDto({
      stockId: 's-1',
      dataMode: 'MOCK',
      asOf: '2026-10-06',
      source: 'mock',
      metrics: emptySnapshotMetrics(),
      raw: { secret: 'provider internals' },
    });
    expect(dto).not.toHaveProperty('raw');
    expect(JSON.stringify(dto)).not.toContain('provider internals');
  });
});
