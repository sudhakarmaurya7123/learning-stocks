import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { mockResponders } from '../../src/ai/mockResponders.js';
import type { Database } from '../../src/database/db.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { AIAnalysisService } from '../../src/services/ai/AIAnalysisService.js';
import { AppError } from '../../src/utils/errors.js';
import { aiDeps, NOW, seedPipeline, silent } from './aiFixtures.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

function service(trx: Database, now: Date, options: Parameters<typeof aiDeps>[2] = {}) {
  const d = aiDeps(trx, now, options);
  return new AIAnalysisService({
    stocks: new StockRepository(trx),
    evaluations: new EvaluationRepository(trx),
    analyses: d.analyses,
    context: d.context,
    gateway: d.gateway,
    settings: d.settings,
    systemLogs: new SystemLogRepository(trx),
    dataMode: 'MOCK',
    logger: silent,
    now: () => now,
  });
}
const calls = (trx: Database) =>
  trx
    .selectFrom('llm_calls')
    .select(['purpose', 'status'])
    .where('purpose', '=', 'stock_analysis')
    .execute();

describe('AIAnalysisService', () => {
  it('stores a cited analysis whose numbers come from the evaluation, then serves the cache (also a day later)', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seedPipeline(trx);
      const first = await service(trx, NOW).run({ jobName: 'test', symbols: ['RELIANCE'] });
      expect(first.results).toEqual([
        { symbol: 'RELIANCE', outcome: 'ANALYSED', analysisId: expect.any(String), message: null },
      ]);
      const ev = await new EvaluationRepository(trx).latestDetail(rel, 'MOCK');
      const row = await trx
        .selectFrom('stock_ai_analysis')
        .selectAll()
        .where('stock_id', '=', rel)
        .executeTakeFirstOrThrow();
      expect(row).toMatchObject({
        status: 'OK',
        recommendation: ev?.recommendationBias,
        trend: ev?.trend,
        risk_level: ev?.riskLevel,
        prompt_version: 'stock_analysis_v1',
      });
      expect(Number(row.overall_score)).toBeCloseTo(ev?.overallScore ?? -1, 2);
      expect(Number(row.confidence)).toBeLessThanOrEqual(Math.round((ev?.coverage ?? 1) * 100));
      expect(JSON.stringify(row.sources)).toContain('"id":"E1"');
      expect(row.summary).toContain('[MOCK]');
      expect(await calls(trx)).toEqual([{ purpose: 'stock_analysis', status: 'OK' }]);

      const again = await service(trx, NOW).run({ jobName: 'test', symbols: ['RELIANCE'] });
      expect(again.results[0]?.outcome).toBe('CACHED');
      const nextDay = await service(trx, new Date(NOW.getTime() + 86_400_000)).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(nextDay.results[0]?.outcome).toBe('CACHED');
      expect(await calls(trx)).toHaveLength(1);
    });
  });

  it('repairs once, stores FAILED when still invalid, and replaces the FAILED row on a later valid run', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seedPipeline(trx);
      const bad = {
        stock_analysis: (req: { system: string; user: string; schemaName: string }) => ({
          ...(mockResponders().stock_analysis?.(req) as object),
          summary: 'Returns are guaranteed with a target of ₹99,999.',
        }),
      };
      const failed = await service(trx, NOW, { responders: bad }).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(failed.results[0]?.outcome).toBe('FAILED');
      expect((await calls(trx)).map((c) => c.status)).toEqual(['INVALID_OUTPUT', 'INVALID_OUTPUT']);
      const failedRow = await trx
        .selectFrom('stock_ai_analysis')
        .select(['id', 'status'])
        .where('stock_id', '=', rel)
        .executeTakeFirstOrThrow();
      expect(failedRow.status).toBe('FAILED');

      await trx
        .updateTable('app_settings')
        .set({ value: JSON.stringify(0) })
        .where('key', '=', 'analysis_min_interval_minutes')
        .execute();
      const ok = await service(trx, NOW).run({ jobName: 'test', symbols: ['RELIANCE'] });
      expect(ok.results[0]).toMatchObject({ outcome: 'ANALYSED', analysisId: failedRow.id });
      const rows = await trx
        .selectFrom('stock_ai_analysis')
        .select('status')
        .where('stock_id', '=', rel)
        .execute();
      expect(rows).toEqual([{ status: 'OK' }]);
    });
  });

  it('records INSUFFICIENT_DATA without a model call when there is no evaluation', async () => {
    await withRollback(db, async (trx) => {
      await seedPipeline(trx);
      const r = await service(trx, NOW).run({ jobName: 'test', symbols: ['TCS'] });
      expect(r.results[0]?.outcome).toBe('INSUFFICIENT_DATA');
      const row = await trx
        .selectFrom('stock_ai_analysis')
        .select(['status', 'model', 'insufficient_data'])
        .executeTakeFirstOrThrow();
      expect(row).toMatchObject({ status: 'INSUFFICIENT_DATA', model: 'none' });
      expect(JSON.stringify(row.insufficient_data)).toContain('evaluation');
      expect(await calls(trx)).toEqual([]);
    });
  });

  it('respects the minimum interval for changed inputs unless forced, and stops at the budget', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seedPipeline(trx);
      await service(trx, NOW).run({ jobName: 'test', symbols: ['RELIANCE'] });
      // New evidence changes the context (RELIANCE's latest close moves): within 30 minutes it waits; force regenerates.
      const last = await trx
        .selectFrom('market_data')
        .select('ts')
        .where('stock_id', '=', rel)
        .where('timeframe', '=', '1d')
        .orderBy('ts', 'desc')
        .limit(1)
        .executeTakeFirstOrThrow();
      await trx
        .updateTable('market_data')
        .set({ close: sql`close + 1`, high: sql`greatest(high, close + 1)` }) // keep OHLC consistent
        .where('stock_id', '=', rel)
        .where('timeframe', '=', '1d')
        .where('ts', '=', last.ts)
        .execute();
      const soon = await service(trx, new Date(NOW.getTime() + 10 * 60_000)).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(soon.results[0]?.outcome).toBe('MIN_INTERVAL');
      const forced = await service(trx, new Date(NOW.getTime() + 10 * 60_000)).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
        force: true,
      });
      expect(forced.results[0]?.outcome).toBe('ANALYSED');
      const budgetStub = {
        ensure: async () => {
          throw new AppError('BUDGET_EXCEEDED', 'budget');
        },
      };
      const blocked = await service(trx, new Date(NOW.getTime() + 60 * 60_000), {
        budget: budgetStub,
      }).run({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'], force: true });
      expect(blocked.results.map((x) => x.outcome)).toEqual([
        'BUDGET_EXHAUSTED',
        'BUDGET_EXHAUSTED',
      ]);
      expect(blocked.status).toBe('SKIPPED');
    });
  });
});
