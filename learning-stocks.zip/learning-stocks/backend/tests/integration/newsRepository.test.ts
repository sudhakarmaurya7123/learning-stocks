import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import type { NewsArticle } from '../../src/domain/news.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

const article = (over: Partial<NewsArticle> = {}): NewsArticle => ({
  dataMode: 'MOCK',
  title: 'Reliance Industries wins order',
  description: null,
  content: null,
  source: 'example.com',
  sourceUrl: 'https://example.com/a1',
  author: null,
  publishedAt: new Date('2026-10-05T06:00:00Z'),
  language: 'en',
  contentHash: 'a'.repeat(64),
  ...over,
});

async function ids(trx: Database) {
  const reliance = await new StockRepository(trx).findBySymbol('RELIANCE');
  const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
  return {
    reliance: { kind: 'stock' as const, id: reliance?.id ?? '' },
    nifty: { kind: 'market' as const, id: nifty?.id ?? '' },
  };
}

describe('NewsRepository', () => {
  it('inserts new articles and resolves existing ones by content hash or by URL', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      const first = await repo.saveArticles([
        article(),
        article({ sourceUrl: 'https://example.com/a2', contentHash: 'b'.repeat(64) }),
      ]);
      expect(first.inserted).toBe(2);
      expect(new Set(first.ids).size).toBe(2);

      const again = await repo.saveArticles([
        article({ sourceUrl: 'https://news.google.com/rss/articles/X' }), // same hash, different URL
        article({ title: 'Edited headline', contentHash: 'c'.repeat(64) }), // same URL, different hash
        article({ sourceUrl: 'https://example.com/a3', contentHash: 'd'.repeat(64) }),
      ]);
      expect(again.inserted).toBe(1);
      expect(again.ids[0]).toBe(first.ids[0]);
      expect(again.ids[1]).toBe(first.ids[0]);
      expect(again.ids[2]).not.toBe(first.ids[0]);
    });
  });

  it('keeps MOCK and LIVE copies apart and refuses mixed batches', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      expect((await repo.saveArticles([article()])).inserted).toBe(1);
      expect((await repo.saveArticles([article({ dataMode: 'LIVE' })])).inserted).toBe(1);
      await expect(
        repo.saveArticles([article(), article({ dataMode: 'LIVE', contentHash: 'e'.repeat(64) })]),
      ).rejects.toMatchObject({ code: 'INTERNAL' });
    });
  });

  it('upserts mentions keeping the strongest relevance, tolerating duplicates in one call', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      const { reliance, nifty } = await ids(trx);
      const [newsId = ''] = (await repo.saveArticles([article()])).ids;
      expect(
        await repo.saveMentions([
          { newsId, ref: reliance, relevance: 0.4, matchedBy: 'query' },
          { newsId, ref: reliance, relevance: 0.6, matchedBy: 'name:content' },
          { newsId, ref: nifty, relevance: 0.9, matchedBy: 'alias:title' },
        ]),
      ).toBe(2);
      await repo.saveMentions([{ newsId, ref: reliance, relevance: 1, matchedBy: 'name:title' }]);
      await repo.saveMentions([{ newsId, ref: reliance, relevance: 0.4, matchedBy: 'query' }]);
      const [item] = await repo.listForInstrument(reliance, 'MOCK');
      expect(item).toMatchObject({
        id: newsId,
        title: 'Reliance Industries wins order',
        relevance: 1,
        matchedBy: 'name:title',
      });
      expect((await repo.listForInstrument(nifty, 'MOCK'))[0]?.relevance).toBe(0.9);
    });
  });

  it("lists an instrument's news newest first, filtered by mode, date and relevance", async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const repo = new NewsRepository(trx);
      const { reliance } = await ids(trx);
      const saved = await repo.saveArticles([
        article({
          title: 'Old',
          sourceUrl: 'https://example.com/old',
          contentHash: '1'.repeat(64),
          publishedAt: new Date('2026-09-01T06:00:00Z'),
        }),
        article({
          title: 'New',
          sourceUrl: 'https://example.com/new',
          contentHash: '2'.repeat(64),
        }),
        article({
          title: 'Weak',
          sourceUrl: 'https://example.com/weak',
          contentHash: '3'.repeat(64),
          publishedAt: new Date('2026-10-04T06:00:00Z'),
        }),
      ]);
      const [oldId = '', newId = '', weakId = ''] = saved.ids;
      await repo.saveMentions([
        { newsId: oldId, ref: reliance, relevance: 1, matchedBy: 'name:title' },
        { newsId: newId, ref: reliance, relevance: 1, matchedBy: 'name:title' },
        { newsId: weakId, ref: reliance, relevance: 0.4, matchedBy: 'query' },
      ]);
      expect((await repo.listForInstrument(reliance, 'MOCK')).map((n) => n.title)).toEqual([
        'New',
        'Weak',
        'Old',
      ]);
      expect(
        (
          await repo.listForInstrument(reliance, 'MOCK', {
            since: new Date('2026-10-01T00:00:00Z'),
            minRelevance: 0.5,
          })
        ).map((n) => n.title),
      ).toEqual(['New']);
      expect(await repo.listForInstrument(reliance, 'LIVE')).toEqual([]);
    });
  });
});
