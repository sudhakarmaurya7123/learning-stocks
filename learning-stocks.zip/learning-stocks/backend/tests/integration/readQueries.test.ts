import { afterAll, describe, expect, it } from 'vitest';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const repo = () => new StockRepository(db);

describe('StockRepository.listWithFilters', () => {
  it('returns every active stock with its latest evaluation when unfiltered', async () => {
    const rows = await repo().listWithFilters({ mode: 'MOCK' });
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.map((r) => r.stock.symbol)).toContain('RELIANCE');
    // Sorted by symbol so the list is stable between calls.
    expect(rows.map((r) => r.stock.symbol)).toEqual([...rows.map((r) => r.stock.symbol)].sort());
  });

  it('matches a query against the symbol and the company name', async () => {
    const bySymbol = await repo().listWithFilters({ mode: 'MOCK', query: 'RELI' });
    expect(bySymbol.map((r) => r.stock.symbol)).toContain('RELIANCE');
    // A user searching "Reliance Industries" is searching by name, not ticker.
    const byName = await repo().listWithFilters({ mode: 'MOCK', query: 'Industries' });
    expect(byName.map((r) => r.stock.symbol)).toContain('RELIANCE');
  });

  it('treats LIKE metacharacters in a query as literal text', async () => {
    // '%' unescaped would match every stock and look like a working search.
    const rows = await repo().listWithFilters({ mode: 'MOCK', query: '%' });
    expect(rows).toEqual([]);
  });

  it('filters by sector', async () => {
    const all = await repo().listWithFilters({ mode: 'MOCK' });
    const sector = all.find((r) => r.stock.sector !== null)?.stock.sector;
    if (sector === undefined || sector === null) throw new Error('expected a stock with a sector');
    const rows = await repo().listWithFilters({ mode: 'MOCK', sector });
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.every((r) => r.stock.sector === sector)).toBe(true);
  });

  it('filters by action state, and returns one row per stock', async () => {
    const all = await repo().listWithFilters({ mode: 'MOCK' });
    const evaluated = all.filter((r) => r.evaluation !== null);
    expect(evaluated.length).toBeGreaterThan(0);
    const state = evaluated[0]?.evaluation?.actionState;
    if (state === undefined) throw new Error('expected a stored evaluation to filter on');
    const rows = await repo().listWithFilters({ mode: 'MOCK', action: state });
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.every((r) => r.evaluation?.actionState === state)).toBe(true);
    // distinctOn: a stock with 30 stored evaluations still appears once, with the newest.
    const symbols = rows.map((r) => r.stock.symbol);
    expect(symbols).toHaveLength(new Set(symbols).size);
  });

  it("never mixes modes: the same stock gets its own mode's evaluation", async () => {
    // The stocks are mode-independent reference data; their evaluations are not. This database
    // holds both MOCK and LIVE evaluations, so a missing data_mode filter would return whichever
    // row sorted first and silently show mock numbers as live ones.
    const mock = await repo().listWithFilters({ mode: 'MOCK' });
    const live = await repo().listWithFilters({ mode: 'LIVE' });
    const pick = (rows: Awaited<ReturnType<ReturnType<typeof repo>['listWithFilters']>>) =>
      rows.find((r) => r.stock.symbol === 'RELIANCE')?.evaluation;
    const m = pick(mock);
    const l = pick(live);
    expect(m).not.toBeUndefined();
    if (m && l) {
      // Different evaluation rows, so different evaluated_at timestamps.
      expect(m.evaluatedAt.getTime()).not.toBe(l.evaluatedAt.getTime());
    }
  });

  it('returns a stock with no evaluation in this mode rather than dropping it', async () => {
    // A left join, not an inner one: a newly added instrument has no evaluation yet, and hiding
    // it would make it invisible on the dashboard until the next worker run.
    const rows = await repo().listWithFilters({ mode: 'LIVE' });
    expect(rows.map((r) => r.stock.symbol)).toContain('RELIANCE');
    // Every active stock is listed whether or not this mode has evaluated it.
    const mock = await repo().listWithFilters({ mode: 'MOCK' });
    expect(rows).toHaveLength(mock.length);
  });
});
