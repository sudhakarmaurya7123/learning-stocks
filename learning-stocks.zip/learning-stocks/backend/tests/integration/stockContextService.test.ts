import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';
import { MockLLMProvider } from '../../src/providers/llm/mock/MockLLMProvider.js';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import { Retriever } from '../../src/rag/retriever.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { EmbeddingRepository } from '../../src/repositories/EmbeddingRepository.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { LlmCallRepository } from '../../src/repositories/LlmCallRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { PaperPositionRepository } from '../../src/repositories/PaperPositionRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { ScoringConfigRepository } from '../../src/repositories/ScoringConfigRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { TechnicalIndicatorRepository } from '../../src/repositories/TechnicalIndicatorRepository.js';
import { EvaluationService } from '../../src/services/EvaluationService.js';
import { FundamentalsService } from '../../src/services/fundamentals/FundamentalsService.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MarketDataService } from '../../src/services/marketData/MarketDataService.js';
import { EmbeddingService } from '../../src/services/rag/EmbeddingService.js';
import { StockContextService } from '../../src/services/rag/StockContextService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { formatDate } from '../../src/utils/format.js';
import { createLogger } from '../../src/utils/logger.js';
import { newsArticle } from '../fixtures/ragArticles.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
const NOW = new Date('2026-10-05T12:00:00Z');
const SYMBOLS = ['RELIANCE', 'NIFTY50', 'INDIAVIX', 'NIFTYENERGY'];

async function seed(trx: Database) {
  await isolateTables(
    trx,
    'market_data',
    'technical_indicators',
    'stock_evaluations',
    'fundamental_snapshots',
    'financial_statements',
    'news',
    'document_embeddings',
    'llm_calls',
  );
  const sessions = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());
  const market = new MockMarketDataProvider(sessions, () => NOW);
  const logs = new SystemLogRepository(trx);
  const common = { dataMode: 'MOCK' as const, logger: silent, now: () => NOW };
  await new MarketDataService({
    ...common,
    provider: market,
    sessions,
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    systemLogs: logs,
  }).sync({
    jobName: 'seed',
    timeframe: '1d',
    from: new Date(NOW.getTime() - 420 * 86_400_000),
    to: NOW,
    symbols: SYMBOLS,
  });
  await new FundamentalsService({
    ...common,
    provider: new MockFundamentalsProvider(
      async (ref) => (await market.getQuote(ref)).price,
      () => NOW,
    ),
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    systemLogs: logs,
  }).sync({ jobName: 'seed', symbols: ['RELIANCE'] });
  await new EvaluationService({
    ...common,
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    news: new NewsRepository(trx),
    positions: new PaperPositionRepository(trx),
    configs: new ScoringConfigRepository(trx),
    settings: new AppSettingsRepository(trx),
    evaluations: new EvaluationRepository(trx),
    indicators: new TechnicalIndicatorRepository(trx),
    systemLogs: logs,
    sessions,
  }).run({ jobName: 'seed', symbols: ['RELIANCE'] });
  const rel = (await new StockRepository(trx).findBySymbol('RELIANCE'))?.id ?? '';
  const news = new NewsRepository(trx);
  const { ids } = await news.saveArticles([
    newsArticle(
      'Reliance retail arm opens 300 stores',
      'https://example.com/r',
      new Date('2026-10-04T05:00:00Z'),
    ),
  ]);
  await news.saveMentions([
    {
      newsId: ids[0] ?? '',
      ref: { kind: 'stock', id: rel },
      relevance: 0.9,
      matchedBy: 'name:title',
    },
  ]);
  const llm = new MockLLMProvider();
  const deps = {
    embeddings: new EmbeddingRepository(trx),
    llmCalls: new LlmCallRepository(trx),
    dataMode: 'MOCK' as const,
    usdInrRate: 88,
  };
  await new EmbeddingService({
    ...deps,
    provider: llm,
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    settings: new AppSettingsRepository(trx),
    systemLogs: logs,
    logger: silent,
  }).run({ jobName: 'seed' });
  return new StockContextService({
    stocks: new StockRepository(trx),
    marketData: new MarketDataRepository(trx),
    evaluations: new EvaluationRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    dataMode: 'MOCK',
    now: () => NOW,
    retriever: new Retriever({ ...deps, provider: llm, cache: new MemoryCache(), now: () => NOW }),
  });
}

describe('StockContextService', () => {
  it('assembles every block from stored data plus retrieved documents', async () => {
    await withRollback(db, async (trx) => {
      const service = await seed(trx);
      const ctx = await service.build('RELIANCE');
      expect([...ctx.ids].slice(0, 9)).toEqual([
        'Q1',
        'P1',
        'T1',
        'F1',
        'R1',
        'R2',
        'V1',
        'E1',
        'M1',
      ]);
      expect(ctx.ids.has('N1')).toBe(true);
      expect(ctx.missing).toEqual(['previous analysis']);
      expect(ctx.evaluationId).not.toBeNull();
      const latest = await new EvaluationRepository(trx).latest(ctx.stockId, 'MOCK');
      expect(ctx.text).toContain(
        `Action state (computed; explain, never change): ${latest?.actionState ?? ''}`,
      );
      expect(ctx.text).toContain('Reliance retail arm opens 300 stores');
      // Latest results come from the DB as structured blocks, never via similarity ranking.
      const fundamentals = new FundamentalsRepository(trx);
      const [q] = await fundamentals.listStatements(ctx.stockId, 'MOCK', 'QUARTERLY', 1);
      const [a] = await fundamentals.listStatements(ctx.stockId, 'MOCK', 'ANNUAL', 1);
      expect(ctx.text).toContain(`quarter ended ${formatDate(q?.periodEnd ?? '')}`);
      expect(ctx.text).toContain(`year ended ${formatDate(a?.periodEnd ?? '')}`);
      expect(ctx.documents.some((d) => d.sourceType === 'FINANCIALS')).toBe(false);
    });
  });

  it('reports missing data for a stock with nothing stored, and NOT_FOUND for an unknown symbol', async () => {
    await withRollback(db, async (trx) => {
      const service = await seed(trx);
      const ctx = await service.build('TCS');
      expect(ctx.blocks).toEqual([]);
      expect(ctx.missing).toContain('evaluation');
      await expect(service.build('NOSUCH')).rejects.toMatchObject({ code: 'NOT_FOUND' });
    });
  });
});
