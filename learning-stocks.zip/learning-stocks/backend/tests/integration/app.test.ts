import { Writable } from 'node:stream';
import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createDatabase } from '../../src/database/db.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { LOCAL_DATABASE_URL } from './helpers.js';

const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
const config = loadConfig({
  DATABASE_URL: process.env.DATABASE_URL ?? LOCAL_DATABASE_URL,
  OPENAI_API_KEY: 'sk-should-never-leak',
  // This file exercises /health and the error handler, not auth. AUTH_MODE=none keeps it
  // independent of JWT material, which buildApp requires in the default jwt mode.
  AUTH_MODE: 'none',
});

describe('app', () => {
  const container = createContainer(config, { logger: silent });
  let app: FastifyInstance;
  beforeAll(async () => {
    app = await buildApp(container);
    app.get('/api/__boom/app-error', async () => {
      throw new AppError('NOT_FOUND', 'Stock XYZ not found');
    });
    app.post('/api/__echo', async () => ({ ok: true }));
    app.get('/api/__boom/bug', async () => {
      throw new Error('internal stack detail');
    });
  });
  afterAll(async () => {
    await app.close();
    await container.close();
  });

  it('GET /api/health reports DB, config and NSE status in the envelope', async () => {
    const res = await app.inject({ method: 'GET', url: '/api/health' });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.data).toMatchObject({
      status: 'ok',
      database: 'up',
      data_mode: 'MOCK',
      providers: { market_data: 'mock', news: 'mock', fundamentals: 'mock', llm: 'mock' },
      market: { exchange: 'NSE' },
    });
    expect(['OPEN', 'CLOSED', 'WEEKEND', 'HOLIDAY']).toContain(body.data.market.phase);
    expect(body.meta).toMatchObject({ data_mode: 'MOCK' });
    expect(Number.isNaN(Date.parse(body.meta.generated_at))).toBe(false);
    expect(res.body).not.toContain('sk-should-never-leak');
  });

  it('maps AppError to its status and envelope, hides internal errors, and 404s unknown routes', async () => {
    const notFound = await app.inject({ method: 'GET', url: '/api/__boom/app-error' });
    expect(notFound.statusCode).toBe(404);
    expect(notFound.json()).toEqual({
      error: { code: 'NOT_FOUND', message: 'Stock XYZ not found' },
    });

    const bug = await app.inject({ method: 'GET', url: '/api/__boom/bug' });
    expect(bug.statusCode).toBe(500);
    expect(bug.json()).toEqual({ error: { code: 'INTERNAL', message: 'Internal server error' } });

    const missing = await app.inject({ method: 'GET', url: '/api/nope' });
    expect(missing.statusCode).toBe(404);
    expect(missing.json().error.code).toBe('NOT_FOUND');
  });
});

describe('framework errors', () => {
  it('passes framework 4xx errors through with their status instead of 500', async () => {
    const container = createContainer(config, { logger: silent });
    const app = await buildApp(container);
    app.post('/api/__echo', async () => ({ ok: true }));
    const badJson = await app.inject({
      method: 'POST',
      url: '/api/__echo',
      headers: { 'content-type': 'application/json' },
      payload: '{bad',
    });
    expect(badJson.statusCode).toBe(400);
    expect(badJson.json().error.code).toBe('VALIDATION');
    const unsupported = await app.inject({
      method: 'POST',
      url: '/api/__echo',
      headers: { 'content-type': 'text/x-unknown' },
      payload: 'x',
    });
    expect(unsupported.statusCode).toBe(415);
    expect(unsupported.json().error.code).toBe('VALIDATION');
    await app.close();
    await container.close();
  });
});

describe('app with the database down', () => {
  it('answers /api/health quickly with 503 degraded', async () => {
    const db = createDatabase('postgresql://postgres:postgres@127.0.0.1:1/postgres', { max: 1 });
    const container = createContainer(config, { logger: silent, db });
    const app = await buildApp(container);
    const started = Date.now();
    const res = await app.inject({ method: 'GET', url: '/api/health' });
    expect(res.statusCode).toBe(503);
    expect(res.json().data).toMatchObject({
      status: 'degraded',
      database: 'down',
      market: null,
      data_mode: 'MOCK',
    });
    expect(Date.now() - started).toBeLessThan(5000);
    await app.close();
    await container.close();
  });
});
