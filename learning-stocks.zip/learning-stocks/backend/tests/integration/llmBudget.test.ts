import { afterAll, describe, expect, it } from 'vitest';
import { LlmBudget } from '../../src/ai/LlmBudget.js';
import type { Database } from '../../src/database/db.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { LlmCallRepository, type LlmCallRecord } from '../../src/repositories/LlmCallRepository.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const NOON_IST = new Date('2026-10-06T06:30:00Z');
const CALL = {
  purpose: 'stock_analysis',
  provider: 'openai',
  model: 'gpt-5-mini',
  promptVersion: 'stock_analysis_v1',
};

const spend = (inr: number): LlmCallRecord => ({
  purpose: 'x',
  provider: 'openai',
  model: 'gpt-5-mini',
  promptVersion: null,
  inputTokens: 1,
  outputTokens: 1,
  estCostInr: inr,
  latencyMs: 1,
  cacheHit: false,
  status: 'OK',
  error: null,
});

async function setup(trx: Database, budgetInr: number) {
  await isolateTables(trx, 'llm_calls');
  await trx
    .updateTable('app_settings')
    .set({ value: JSON.stringify(budgetInr) })
    .where('key', '=', 'llm_daily_budget_inr')
    .execute();
  const calls = new LlmCallRepository(trx);
  const budget = (now: Date) =>
    new LlmBudget({
      llmCalls: calls,
      settings: new AppSettingsRepository(trx),
      defaultDailyInr: 500,
      now: () => now,
    });
  return { calls, budget };
}

describe('LlmBudget', () => {
  it('sums today’s spend from IST midnight and reports the remaining budget', async () => {
    await withRollback(db, async (trx) => {
      const { calls, budget } = await setup(trx, 10);
      await calls.record(spend(3.5));
      await trx
        .updateTable('llm_calls')
        .set({ created_at: new Date('2026-10-05T18:00:00Z') })
        .execute(); // 23:30 IST previous day
      await calls.record(spend(4));
      await trx
        .updateTable('llm_calls')
        .set({ created_at: new Date('2026-10-05T18:31:00Z') })
        .where('est_cost_inr', '=', '4')
        .execute(); // 00:01 IST today
      expect(await budget(NOON_IST).status()).toMatchObject({
        dailyBudgetInr: 10,
        spentTodayInr: 4,
        remainingInr: 6,
        exhausted: false,
        dayStart: new Date('2026-10-05T18:30:00Z'),
      });
    });
  });

  it('refuses a call that would pass the budget, recording a BUDGET_EXCEEDED row', async () => {
    await withRollback(db, async (trx) => {
      const { calls, budget } = await setup(trx, 5);
      await calls.record(spend(4.5));
      await expect(budget(new Date()).ensure(0.4, CALL)).resolves.toBeUndefined();
      await expect(budget(new Date()).ensure(0.6, CALL)).rejects.toMatchObject({
        code: 'BUDGET_EXCEEDED',
      });
      const rows = await trx
        .selectFrom('llm_calls')
        .select(['status', 'purpose', 'est_cost_inr'])
        .where('status', '=', 'BUDGET_EXCEEDED')
        .execute();
      expect(rows).toEqual([
        { status: 'BUDGET_EXCEEDED', purpose: 'stock_analysis', est_cost_inr: '0.0000' },
      ]);
    });
  });

  it('falls back to the configured default when the setting is missing', async () => {
    await withRollback(db, async (trx) => {
      const { budget } = await setup(trx, 1);
      await trx.deleteFrom('app_settings').where('key', '=', 'llm_daily_budget_inr').execute();
      expect((await budget(NOON_IST).status()).dailyBudgetInr).toBe(500);
    });
  });
});
