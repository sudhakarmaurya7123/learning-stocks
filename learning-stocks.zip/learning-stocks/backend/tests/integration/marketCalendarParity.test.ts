import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import {
  CASE_HOLIDAYS,
  CASE_WINDOW,
  NEXT_OPEN_CASES,
  OPEN_CASES,
} from '../fixtures/calendarCases.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('MarketCalendarService ↔ SQL parity', () => {
  it('agrees with is_market_open and next_market_open on every shared case', async () => {
    await withRollback(db, async (trx) => {
      await trx
        .deleteFrom('exchange_holidays')
        .where('holiday_date', '>=', CASE_WINDOW.from)
        .where('holiday_date', '<=', CASE_WINDOW.to)
        .execute();
      await trx
        .insertInto('exchange_holidays')
        .values(
          CASE_HOLIDAYS.map((h) => ({
            exchange: h.exchange,
            holiday_date: h.date,
            description: h.description,
            special_open: h.specialOpen,
            special_close: h.specialClose,
          })),
        )
        .execute();
      const ts = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());

      for (const c of OPEN_CASES) {
        const { rows } = await sql<{
          open: boolean;
        }>`select public.is_market_open(${c.exchange}::public.exchange_code, ${c.at}::timestamptz) as open`.execute(
          trx,
        );
        expect(rows[0]?.open, `SQL: ${c.label}`).toBe(c.open);
        expect(await ts.isOpen(c.exchange, new Date(c.at)), `TS: ${c.label}`).toBe(c.open);
      }
      for (const c of NEXT_OPEN_CASES) {
        const { rows } = await sql<{
          next: Date;
        }>`select public.next_market_open('NSE', ${c.at}::timestamptz) as next`.execute(trx);
        const expected = new Date(c.next).toISOString();
        expect(rows[0]?.next.toISOString(), `SQL: ${c.label}`).toBe(expected);
        expect((await ts.nextOpen('NSE', new Date(c.at)))?.toISOString(), `TS: ${c.label}`).toBe(
          expected,
        );
      }
    });
  });
});
