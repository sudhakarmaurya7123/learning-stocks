import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { emptySnapshotMetrics } from '../../src/domain/fundamentals.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { PaperPositionRepository } from '../../src/repositories/PaperPositionRepository.js';
import { ScoringConfigRepository } from '../../src/repositories/ScoringConfigRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { TechnicalIndicatorRepository } from '../../src/repositories/TechnicalIndicatorRepository.js';
import type { EvaluationRecord } from '../../src/scoring/evaluate.js';
import type { IndicatorPoint } from '../../src/technical/indicators.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const idOf = async (trx: Database, symbol: string) =>
  (await new StockRepository(trx).findBySymbol(symbol))?.id ?? '';

const point = (ts: string, sma20: number | null): IndicatorPoint => ({
  ts: new Date(ts),
  vwap: null,
  pivots: { p: 100, r1: 105, s1: 95, r2: 110, s2: 90 },
  values: {
    sma20,
    sma50: null,
    sma200: null,
    ema20: null,
    ema50: null,
    ema200: null,
    rsi14: 55.123,
    macd: null,
    macdSignal: null,
    macdHistogram: null,
    bollingerUpper: null,
    bollingerMiddle: null,
    bollingerLower: null,
    atr14: 2.5,
    adx14: null,
    stochK: null,
    stochD: null,
    volumeSma20: 1000,
  },
});

const record = (stockId: string, over: Partial<EvaluationRecord> = {}): EvaluationRecord => ({
  stockId,
  dataMode: 'MOCK',
  dataAsOf: new Date('2026-10-05T03:45:00Z'),
  scoringConfigVersion: 'v1',
  scores: {
    technical: 70,
    quality: null,
    valuation: 55,
    news: null,
    momentum: 60,
    marketContext: 80,
    overall: 66.5,
    risk: 40,
  },
  riskLevel: 'MEDIUM',
  trend: 'UPTREND',
  valuationLabel: 'FAIR',
  marketRegime: 'RISK_ON',
  actionState: 'BUY_ZONE',
  recommendationBias: 'BUY_BIAS',
  paperSignal: 'BUY',
  trade: {
    basis: 'SUPPORT',
    entryLow: 99,
    entryHigh: 101,
    stop: 96,
    target1: 110,
    target2: 115,
    riskReward: 2.2,
    positionSizeHint: 100,
  },
  invalidation: 'Bias invalid on a daily close below ₹96.00 (stop-loss).',
  factorsAvailable: { technical: true, coverage: 0.7 },
  inputs: { engineVersion: 'engine-1' },
  inputHash: 'a'.repeat(64),
  ...over,
});

describe('analysis repositories', () => {
  it('reads the active scoring config with defaults applied', async () => {
    const c = await new ScoringConfigRepository(db).getActive();
    expect(c).toMatchObject({
      version: 'v1',
      thresholds: { buyOverallMin: 65, maxStaleSessions: 3 },
    });
  });

  it('upserts an indicator series (re-runs update in place) and reads the latest point', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'technical_indicators');
      const repo = new TechnicalIndicatorRepository(trx);
      const id = await idOf(trx, 'RELIANCE');
      expect(
        await repo.upsertSeries(id, 'MOCK', '1d', [
          point('2026-10-01T03:45:00Z', 100),
          point('2026-10-02T03:45:00Z', 101),
        ]),
      ).toBe(2);
      expect(
        await repo.upsertSeries(id, 'MOCK', '1d', [point('2026-10-02T03:45:00Z', 102.5)]),
      ).toBe(1);
      const latest = await repo.latest(id, 'MOCK', '1d');
      expect(latest?.ts).toEqual(new Date('2026-10-02T03:45:00Z'));
      expect(latest?.values).toMatchObject({
        sma20: 102.5,
        rsi14: 55.12,
        atr14: 2.5,
        sma200: null,
      });
      expect(await repo.latest(id, 'LIVE', '1d')).toBeNull();
    });
  });

  it('stores an evaluation once per input hash', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'stock_evaluations');
      const repo = new EvaluationRepository(trx);
      const id = await idOf(trx, 'RELIANCE');
      const first = await repo.insert(record(id));
      expect(first.inserted).toBe(true);
      expect(await repo.insert(record(id))).toEqual({ id: first.id, inserted: false });
      const next = await repo.insert(
        record(id, {
          inputHash: 'b'.repeat(64),
          actionState: 'HOLD',
          recommendationBias: 'HOLD_BIAS',
          trade: null,
        }),
      );
      expect(next.inserted).toBe(true);
      expect(await repo.latest(id, 'MOCK')).toMatchObject({
        id: next.id,
        actionState: 'HOLD',
        entryLow: null,
        inputHash: 'b'.repeat(64),
      });
    });
  });

  it('knows whether a paper position is held in a data mode', async () => {
    await withRollback(db, async (trx) => {
      const repo = new PaperPositionRepository(trx);
      const stockId = await idOf(trx, 'TCS');
      expect(await repo.holdsPosition(stockId, 'MOCK')).toBe(false);
      const userId = randomUUID();
      await sql`insert into auth.users (id, email) values (${userId}, ${`${userId}@example.com`})`.execute(
        trx,
      );
      const account = await trx
        .selectFrom('paper_accounts')
        .select('id')
        .where('user_id', '=', userId)
        .where('data_mode', '=', 'MOCK')
        .executeTakeFirstOrThrow();
      await trx
        .insertInto('paper_positions')
        .values({ account_id: account.id, stock_id: stockId, quantity: 5, average_buy_price: 3000 })
        .execute();
      expect(await repo.holdsPosition(stockId, 'MOCK')).toBe(true);
      expect(await repo.holdsPosition(stockId, 'LIVE')).toBe(false);
    });
  });

  it('lists index links for a stock', async () => {
    const id = await idOf(db, 'HDFCBANK');
    const links = await new MarketRepository(db).linksForStock(id);
    expect(links.map((l) => [l.market.symbol, l.linkType]).sort()).toEqual([
      ['BANKNIFTY', 'SECTOR_INDEX'],
      ['NIFTY50', 'BENCHMARK'],
      ['NIFTYFINSERVICE', 'SECTOR_INDEX'],
    ]);
  });

  it("collects sector peers' latest positive P/E, excluding the stock itself", async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots');
      const repo = new FundamentalsRepository(trx);
      const snap = async (symbol: string, asOf: string, pe: number | null) =>
        repo.upsertSnapshot({
          stockId: await idOf(trx, symbol),
          dataMode: 'MOCK',
          asOf,
          source: 'mock',
          metrics: { ...emptySnapshotMetrics(), pe },
          raw: {},
        });
      await snap('HDFCBANK', '2026-10-06', 15);
      await snap('ICICIBANK', '2026-10-05', 30);
      await snap('ICICIBANK', '2026-10-06', 18);
      await snap('SBIN', '2026-10-06', -2);
      await snap('AXISBANK', '2026-10-06', null);
      await snap('TCS', '2026-10-06', 25);
      expect(
        await repo.sectorPeerPes('Financial Services', await idOf(trx, 'HDFCBANK'), 'MOCK'),
      ).toEqual([18]);
    });
  });

  it('reads LLM news sentiment for a stock (latest analysis per article)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const stockId = await idOf(trx, 'INFY');
      const news = new NewsRepository(trx);
      const { ids } = await news.saveArticles([
        {
          dataMode: 'MOCK',
          title: 'Infosys wins deal',
          description: null,
          content: null,
          source: 'example.com',
          sourceUrl: 'https://example.com/infy',
          author: null,
          publishedAt: new Date('2026-10-04T06:00:00Z'),
          language: 'en',
          contentHash: 'c'.repeat(64),
        },
      ]);
      const newsId = ids[0] ?? '';
      const analysis = (prompt: string, score: number) => ({
        news_id: newsId,
        stock_id: stockId,
        sentiment: 'BULLISH' as const,
        sentiment_score: score,
        confidence: 70,
        relevance_score: 0.9,
        impact_level: 'MEDIUM' as const,
        summary: 's',
        model: 'm',
        prompt_version: prompt,
      });
      await trx
        .insertInto('news_ai_analysis')
        .values([analysis('v1', 60), analysis('v2', 72)])
        .execute();
      const points = await news.sentimentsForStock(
        stockId,
        'MOCK',
        new Date('2026-10-01T00:00:00Z'),
      );
      expect(points).toHaveLength(1);
      expect(points[0]).toMatchObject({
        relevance: 0.9,
        publishedAt: new Date('2026-10-04T06:00:00Z'),
      });
      expect(
        await news.sentimentsForStock(stockId, 'LIVE', new Date('2026-10-01T00:00:00Z')),
      ).toEqual([]);
    });
  });
});
