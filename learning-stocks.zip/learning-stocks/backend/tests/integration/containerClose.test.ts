import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createTestDb, silentLogger } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const SCHEMA = 'pgboss_test_close';

describe('container.close', () => {
  it('stops the job queue it created, so the process can exit', async () => {
    // /system-status starts the queue lazily inside a GET request. Without this, one status call
    // left a pg-boss pool that SIGTERM shutdown could not close.
    await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
    const container = createContainer(
      loadConfig({ AUTH_MODE: 'none', WORKER_QUEUE_SCHEMA: SCHEMA }),
      { db, logger: silentLogger },
    );
    try {
      // Reading status is what starts the queue.
      await container.services.systemHealth.status();
      const before = await sql<{ n: number }>`
        select count(*)::int as n from ${sql.id(SCHEMA)}.instance where stopped_on is null
      `.execute(db);
      expect(before.rows[0]?.n).toBe(1);

      await container.close();
      const after = await sql<{ n: number }>`
        select count(*)::int as n from ${sql.id(SCHEMA)}.instance where stopped_on is null
      `.execute(db);
      expect(after.rows[0]?.n).toBe(0);
    } finally {
      await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
    }
  });

  it('does not destroy a database pool it was given', async () => {
    // Route tests pass their own transaction and reuse the pool across cases.
    const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
      db,
      logger: silentLogger,
      jobQueue: null,
    });
    await container.close();
    const r = await sql<{ one: number }>`select 1 as one`.execute(db);
    expect(r.rows[0]?.one).toBe(1);
  });
});
