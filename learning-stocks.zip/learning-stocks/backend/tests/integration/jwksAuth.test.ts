import { createServer, type Server } from 'node:http';
import { exportJWK, generateKeyPair, SignJWT } from 'jose';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { Database } from '../../src/database/db.js';
import { keyFor, verifyToken, type VerifyOptions } from '../../src/http/auth.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';
import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';

const db = createTestDb();

/**
 * The browser login path, which no other test covers.
 *
 * Measured against the real local stack on 2026-10-07: GoTrue signs **ES256** and publishes one EC
 * key at /auth/v1/.well-known/jwks.json, so a browser token verifies with JWT_SECRET unset — which
 * is how .env ships. Every other auth test passes `jwksUrl: null` with a shared HS256 secret, so an
 * ES256 regression would reach the owner as "login is broken" with nothing red in the suite.
 */
describe('JWKS verification (the real browser login path)', () => {
  let server: Server;
  let origin: string;
  let signWith: (
    claims: Record<string, unknown>,
    over?: { issuer?: string; audience?: string },
  ) => Promise<string>;
  let options: VerifyOptions;
  let jwksHits = 0;

  beforeAll(async () => {
    const { privateKey, publicKey } = await generateKeyPair('ES256');
    const jwk = { ...(await exportJWK(publicKey)), kid: 'test-key', alg: 'ES256', use: 'sig' };
    server = createServer((_request, response) => {
      jwksHits += 1;
      response.writeHead(200, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ keys: [jwk] }));
    });
    await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
    const address = server.address();
    const port = typeof address === 'object' && address !== null ? address.port : 0;
    origin = `http://127.0.0.1:${port}`;
    options = {
      secret: null,
      jwksUrl: `${origin}/auth/v1/.well-known/jwks.json`,
      issuer: `${origin}/auth/v1`,
      audience: 'authenticated',
    };
    // One signer, one key: every negative case changes exactly ONE claim, so a refusal can only be
    // the pin under test and never an incidental signature failure.
    signWith = (claims, over = {}) =>
      new SignJWT(claims)
        .setProtectedHeader({ alg: 'ES256', kid: 'test-key' })
        .setIssuer(over.issuer ?? `${origin}/auth/v1`)
        .setAudience(over.audience ?? 'authenticated')
        .setIssuedAt()
        .setExpirationTime('1h')
        .sign(privateKey);
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  });

  it('accepts an ES256 token fetched from JWKS, with no shared secret configured', async () => {
    const token = await signWith({ sub: 'user-1', role: 'authenticated', email: 'a@b.test' });
    expect(await verifyToken(token, options, keyFor(options))).toEqual({
      sub: 'user-1',
      email: 'a@b.test',
    });
  });

  it('refuses a wrong issuer on an OTHERWISE VALID token', async () => {
    // Signed with THE SAME key the JWKS serves, so the signature verifies and the only thing wrong
    // is `iss`. Signing with a fresh key would fail on the signature instead, and the test would
    // pass even with the issuer pin removed — proving nothing about the pin.
    const foreign = await signWith({ sub: 'user-1' }, { issuer: 'https://evil.example/auth/v1' });
    await expect(verifyToken(foreign, options, keyFor(options))).rejects.toMatchObject({
      code: 'UNAUTHORIZED',
    });
    // Control: the same claims with the right issuer DO verify, so the refusal above is the pin.
    await expect(
      verifyToken(await signWith({ sub: 'user-1' }), options, keyFor(options)),
    ).resolves.toMatchObject({ sub: 'user-1' });
  });

  it('refuses a wrong audience on an otherwise valid token', async () => {
    const wrongAudience = await signWith({ sub: 'user-1' }, { audience: 'anon' });
    await expect(verifyToken(wrongAudience, options, keyFor(options))).rejects.toMatchObject({
      code: 'UNAUTHORIZED',
    });
  });

  it('fetches JWKS once across many authenticated requests, not once per request', async () => {
    // Auth runs before the rate limiter, so a per-request JWKS fetch is an unthrottled outbound
    // loop an attacker could drive. Measured with VALID tokens through the real app: a malformed
    // token never reaches key lookup, so asserting 0 fetches on garbage would prove nothing.
    jwksHits = 0;
    await withRollback(db, async (trx) => {
      const userId = await seedUser(trx);
      const container = createContainer(loadConfig({ AUTH_MODE: 'jwt', SUPABASE_URL: origin }), {
        db: trx,
        logger: silentLogger,
        jobQueue: null,
      });
      const app = await buildApp(container);
      await app.ready();
      try {
        for (let i = 0; i < 3; i += 1) {
          const token = await signWith({ sub: userId, role: 'authenticated' });
          const res = await app.inject({
            method: 'GET',
            url: '/api/market-status',
            headers: { authorization: `Bearer ${token}` },
          });
          expect(res.statusCode).toBe(200);
        }
      } finally {
        await app.close();
        await container.close();
      }
    });
    // jose caches the key set in closure state; registerAuth builds it once per server.
    expect(jwksHits).toBe(1);
  });
});

/** A real auth.users row, so handle_new_user() provisions the profile the API reads. */
async function seedUser(trx: Database): Promise<string> {
  const id = randomUUID();
  await sql`
    insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)
    values (${id}::uuid, '00000000-0000-0000-0000-000000000000'::uuid, 'authenticated',
            'authenticated', ${`${id}@example.com`}, 'x', now(), now())
  `.execute(trx);
  await trx.updateTable('user_profiles').set({ role: 'OWNER' }).where('user_id', '=', id).execute();
  return id;
}
