import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer, type Container } from '../../src/container.js';
import { createTestDb, silentLogger } from './helpers.js';

const db = createTestDb();
let app: FastifyInstance;
let container: Container;

beforeAll(async () => {
  container = createContainer(loadConfig({ AUTH_MODE: 'none' }), { db, logger: silentLogger });
  app = await buildApp(container);
  await app.ready();
});
afterAll(async () => {
  await app.close();
  await container.close();
  await db.destroy();
});

const get = (url: string) => app.inject({ method: 'GET', url });

describe('GET /stocks/:symbol', () => {
  it('returns the full aggregate with freshness in meta', async () => {
    const r = await get('/api/stocks/RELIANCE');
    expect(r.statusCode).toBe(200);
    const body = r.json();
    expect(Object.keys(body.data).sort()).toEqual([
      'ai_analysis',
      'data_freshness',
      'decision',
      'fundamental',
      'market_context',
      'news',
      'performance',
      'quote',
      'sentiment',
      'signal',
      'stock',
      'technical',
      'valuation',
    ]);
    expect(body.data.stock.symbol).toBe('RELIANCE');
    expect(body.meta.freshness).toMatchObject({ market_open: expect.any(Boolean) });
  });

  it('404s an unknown symbol in our error envelope', async () => {
    const r = await get('/api/stocks/NOSUCHSTOCK');
    expect(r.statusCode).toBe(404);
    expect(r.json()).toMatchObject({ error: { code: 'NOT_FOUND' } });
  });

  it('serves a repeat request from the cache inside the TTL', async () => {
    // PRD §14: aggregates cache for 60s, or every dashboard refresh re-runs ~10 queries.
    //
    // Counting service calls, not comparing payloads: the same database row yields the same
    // response with or without a cache, so a payload comparison passes even with the cache
    // removed entirely.
    let builds = 0;
    const real = container.services.aggregate.build.bind(container.services.aggregate);
    container.services.aggregate.build = async (symbol: string) => {
      builds += 1;
      return real(symbol);
    };
    try {
      expect((await get('/api/stocks/TCS')).statusCode).toBe(200);
      expect(builds).toBe(1);
      // A second call inside the TTL must not rebuild. Mixed case hits the same key.
      expect((await get('/api/stocks/tcs')).statusCode).toBe(200);
      expect(builds).toBe(1);
      // A different symbol is a different key, so it does rebuild.
      expect((await get('/api/stocks/INFY')).statusCode).toBe(200);
      expect(builds).toBe(2);
    } finally {
      container.services.aggregate.build = real;
    }
  });

  it('never exposes a paper-trading or portfolio route in this phase', async () => {
    // Phase 11 owns those, next to the engine that makes them work.
    const tree = app.printRoutes({ commonPrefix: false });
    expect(tree).not.toMatch(/paper-trade|portfolio/);
  });
});
