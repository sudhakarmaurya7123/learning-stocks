import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { PgBossQueue } from '../../src/jobs/PgBossQueue.js';
import { createTestDb, LOCAL_DATABASE_URL, silentLogger } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

const SCHEMA = 'pgboss_test_lifecycle';
const makeQueue = () =>
  new PgBossQueue({
    connectionString: process.env.DATABASE_URL ?? LOCAL_DATABASE_URL,
    schema: SCHEMA,
    logger: silentLogger,
    tz: 'Asia/Kolkata',
    schedule: false,
    supervise: false,
  });

describe('PgBossQueue lifecycle', () => {
  it('starts once under concurrent callers, leaving no orphaned instance', async () => {
    // start() guarded on `this.boss`, which is assigned only AFTER await boss.start() — so two
    // concurrent first callers each constructed and started a PgBoss, and one was overwritten
    // and orphaned forever, holding a pool nothing could ever close.
    await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
    const queue = makeQueue();
    try {
      await Promise.all([queue.start(), queue.start(), queue.start()]);
      const { rows } = await sql<{ n: number }>`
        select count(*)::int as n from ${sql.id(SCHEMA)}.instance where stopped_on is null
      `.execute(db);
      expect(rows[0]?.n).toBe(1);
    } finally {
      await queue.stop();
      await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
    }
  });

  it('stop() marks the instance stopped, and is safe to call twice', async () => {
    await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
    const queue = makeQueue();
    await queue.start();
    await queue.stop();
    // Idempotent: a shutdown path must not throw because something already closed the queue.
    await expect(queue.stop()).resolves.toBeUndefined();
    const { rows } = await sql<{ n: number }>`
      select count(*)::int as n from ${sql.id(SCHEMA)}.instance where stopped_on is null
    `.execute(db);
    expect(rows[0]?.n).toBe(0);
    await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
  });
});
