import { afterAll, describe, expect, it } from 'vitest';
import type {
  MarketDataProvider,
  ProviderBar,
  ProviderInstrumentRef,
} from '../../src/providers/market/types.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { verifyProviderSymbols } from '../../src/services/marketData/verifyProviderSymbols.js';
import { AppError } from '../../src/utils/errors.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

const priced = (n: number): ProviderBar[] =>
  Array.from({ length: n }, (_, i) => ({
    ts: new Date(Date.UTC(2025, 0, 1) + i * 86_400_000),
    open: 1,
    high: 1,
    low: 1,
    close: 1,
    adjustedClose: 1,
    volume: 0,
  }));

const fake: MarketDataProvider = {
  name: 'yahoo',
  capabilities: () => ({
    exchanges: ['NSE', 'BSE'],
    intervals: ['1d'],
    latency: 'delayed',
    maxLookbackDays: {},
  }),
  getQuote: async () => {
    throw new Error('unused');
  },
  async getHistorical(ref: ProviderInstrumentRef): Promise<ProviderBar[]> {
    if (ref.providerSymbol === 'RELIANCE.NS') return priced(250);
    if (ref.providerSymbol === '^CNXAUTO')
      return [
        ...priced(1),
        {
          ts: new Date(),
          open: null,
          high: null,
          low: null,
          close: null,
          adjustedClose: null,
          volume: null,
        },
      ];
    throw new AppError('UNSUPPORTED', 'Yahoo has no data');
  },
};

describe('verifyProviderSymbols', () => {
  it('marks symbols with enough daily history verified and explains the rest', async () => {
    await withRollback(db, async (trx) => {
      const repo = new ProviderSymbolRepository(trx);
      const outcomes = await verifyProviderSymbols({
        provider: fake,
        providerSymbols: repo,
        now: () => new Date('2026-10-05T12:00:00Z'),
        symbols: ['RELIANCE', 'NIFTYAUTO', 'TCS'],
      });
      expect(outcomes.map((o) => [o.symbol, o.verified, o.reason])).toEqual([
        ['RELIANCE', true, 'OK'],
        ['TCS', false, 'UNSUPPORTED: Yahoo has no data'],
        ['NIFTYAUTO', false, 'INSUFFICIENT_HISTORY (1 daily bars, need 200)'],
      ]);
      const flags = await repo.listByProvider('yahoo', ['RELIANCE', 'NIFTYAUTO', 'TCS']);
      expect(Object.fromEntries(flags.map((f) => [f.symbol, f.verified]))).toEqual({
        RELIANCE: true,
        TCS: false,
        NIFTYAUTO: false,
      });
    });
  });
});
