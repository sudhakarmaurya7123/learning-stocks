import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import { type BudgetGate, LlmBudget } from '../../src/ai/LlmBudget.js';
import { LlmGateway } from '../../src/ai/LlmGateway.js';
import { mockResponders } from '../../src/ai/mockResponders.js';
import type { Database } from '../../src/database/db.js';
import { MockLLMProvider } from '../../src/providers/llm/mock/MockLLMProvider.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { LlmCallRepository } from '../../src/repositories/LlmCallRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsAnalysisRepository } from '../../src/repositories/NewsAnalysisRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { SentimentService } from '../../src/services/ai/SentimentService.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { newsArticle } from '../fixtures/ragArticles.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});

async function seed(trx: Database) {
  await isolateTables(trx, 'news', 'llm_calls');
  const rel = (await new StockRepository(trx).findBySymbol('RELIANCE'))?.id ?? '';
  const tcs = (await new StockRepository(trx).findBySymbol('TCS'))?.id ?? '';
  const nifty = (await new MarketRepository(trx).findBySymbol('NIFTY50'))?.id ?? '';
  const news = new NewsRepository(trx);
  const { ids } = await news.saveArticles([
    newsArticle(
      'Reliance shares rise after strong results',
      'https://example.com/1',
      new Date('2026-10-05T05:00:00Z'),
    ),
    newsArticle(
      'Sensex falls as banks drag',
      'https://example.com/2',
      new Date('2026-10-04T05:00:00Z'),
    ),
    newsArticle(
      'TCS mentioned in passing',
      'https://example.com/3',
      new Date('2026-10-03T05:00:00Z'),
    ),
  ]);
  await news.saveMentions([
    {
      newsId: ids[0] ?? '',
      ref: { kind: 'stock', id: rel },
      relevance: 0.9,
      matchedBy: 'name:title',
    },
    {
      newsId: ids[1] ?? '',
      ref: { kind: 'market', id: nifty },
      relevance: 0.9,
      matchedBy: 'alias:title',
    },
    { newsId: ids[2] ?? '', ref: { kind: 'stock', id: tcs }, relevance: 0.4, matchedBy: 'query' },
  ]);
  return { rel };
}

function service(trx: Database, budget?: BudgetGate) {
  const llmCalls = new LlmCallRepository(trx);
  const settings = new AppSettingsRepository(trx);
  const gateway = new LlmGateway({
    provider: new MockLLMProvider({ responders: mockResponders() }),
    llmCalls,
    budget: budget ?? new LlmBudget({ llmCalls, settings, defaultDailyInr: 100 }),
    usdInrRate: 88,
    priceOverride: null,
  });
  return new SentimentService({
    gateway,
    analyses: new NewsAnalysisRepository(trx),
    settings,
    systemLogs: new SystemLogRepository(trx),
    dataMode: 'MOCK',
    logger: silent,
  });
}

describe('SentimentService', () => {
  it('analyses qualifying stock and market articles once, skipping weak matches', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const r = await service(trx).run({ jobName: 'test' });
      expect(r).toMatchObject({
        status: 'SUCCESS',
        pending: 2,
        analysed: 2,
        budgetExhausted: false,
      });
      const rows = await trx
        .selectFrom('news_ai_analysis')
        .select(['stock_id', 'sentiment', 'prompt_version'])
        .orderBy('stock_id')
        .execute();
      expect(rows).toEqual([
        { stock_id: rel, sentiment: 'BULLISH', prompt_version: 'news_sentiment_v1' },
        { stock_id: null, sentiment: 'BEARISH', prompt_version: 'news_sentiment_v1' },
      ]);
      expect(
        (await trx.selectFrom('llm_calls').select('status').execute()).map((x) => x.status),
      ).toEqual(['OK', 'OK']);
      // The Phase 5 news factor now has input.
      expect(
        await new NewsRepository(trx).sentimentsForStock(
          rel,
          'MOCK',
          new Date('2026-10-01T00:00:00Z'),
        ),
      ).toHaveLength(1);
      const again = await service(trx).run({ jobName: 'test' });
      expect(again).toMatchObject({ pending: 0, analysed: 0, status: 'SUCCESS' });
    });
  });

  it('stops at the budget without storing anything', async () => {
    await withRollback(db, async (trx) => {
      await seed(trx);
      const r = await service(trx, {
        ensure: async () => {
          throw new AppError('BUDGET_EXCEEDED', 'budget');
        },
      }).run({ jobName: 'test' });
      expect(r).toMatchObject({ status: 'SKIPPED', analysed: 0, budgetExhausted: true });
      expect(r.notes.join(' ')).toMatch(/LLM_BUDGET_EXHAUSTED/);
      expect(await trx.selectFrom('news_ai_analysis').select('id').execute()).toEqual([]);
    });
  });
});
