import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import type { StatementPeriod } from '../../src/domain/fundamentals.js';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';
import type {
  FundamentalsProvider,
  ProviderFundamentalSnapshot,
  ProviderStatements,
} from '../../src/providers/fundamentals/types.js';
import type { ProviderInstrumentRef } from '../../src/providers/market/types.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { FundamentalsService } from '../../src/services/fundamentals/FundamentalsService.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
const NOW = new Date('2026-10-05T20:00:00Z'); // IST 2026-10-06 01:30

/** Wraps the mock; per symbol it can throw, report another currency, or patch snapshot metrics. */
class StubFundamentals implements FundamentalsProvider {
  readonly name = 'mock';
  constructor(
    private readonly inner: FundamentalsProvider,
    private readonly over: {
      fail?: Record<string, AppError>;
      currency?: Record<string, string>;
      patch?: Record<string, Partial<ProviderFundamentalSnapshot['metrics']>>;
    },
  ) {}
  capabilities() {
    return this.inner.capabilities();
  }
  async getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot> {
    const f = this.over.fail?.[ref.providerSymbol];
    if (f) throw f;
    const s = await this.inner.getSnapshot(ref);
    return {
      ...s,
      reportingCurrency: this.over.currency?.[ref.providerSymbol] ?? s.reportingCurrency,
      metrics: { ...s.metrics, ...this.over.patch?.[ref.providerSymbol] },
    };
  }
  async getStatements(
    ref: ProviderInstrumentRef,
    period: StatementPeriod,
  ): Promise<ProviderStatements> {
    const s = await this.inner.getStatements(ref, period);
    return {
      ...s,
      reportingCurrency: this.over.currency?.[ref.providerSymbol] ?? s.reportingCurrency,
    };
  }
}

function build(trx: Database, wrap: (m: FundamentalsProvider) => FundamentalsProvider = (m) => m) {
  const provider = wrap(
    new MockFundamentalsProvider(
      async () => 1000,
      () => NOW,
    ),
  );
  return new FundamentalsService({
    provider,
    dataMode: 'MOCK',
    logger: silent,
    now: () => NOW,
    retry: { sleep: async () => undefined },
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    systemLogs: new SystemLogRepository(trx),
  });
}
const idOf = async (trx: Database, symbol: string) =>
  (await new StockRepository(trx).findBySymbol(symbol))?.id ?? '';

describe('FundamentalsService', () => {
  it('stores snapshots (IST as_of) and statements, and refreshes them on a same-day re-run', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const first = await build(trx).sync({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'] });
      expect(first).toMatchObject({
        status: 'SUCCESS',
        asOf: '2026-10-06',
        stocks: { total: 2, succeeded: 2, failed: 0 },
        snapshots: { inserted: 2, updated: 0 },
        statements: { inserted: 26, updated: 0, skipped: 0 },
      });

      const repo = new FundamentalsRepository(trx);
      const reliance = await repo.latestSnapshot(await idOf(trx, 'RELIANCE'), 'MOCK');
      expect(reliance).toMatchObject({ asOf: '2026-10-06', source: 'mock', raw: { mock: true } });
      expect((reliance?.metrics.pe ?? 0) * (reliance?.metrics.epsTtm ?? 0)).toBeCloseTo(1000, -1);
      expect(
        (await repo.latestSnapshot(await idOf(trx, 'HDFCBANK'), 'MOCK'))?.metrics.debtToEquity,
      ).toBeNull();
      const annual = await repo.listStatements(await idOf(trx, 'RELIANCE'), 'MOCK', 'ANNUAL');
      expect(annual.map((s) => s.periodEnd)).toEqual([
        '2026-03-31',
        '2025-03-31',
        '2024-03-31',
        '2023-03-31',
        '2022-03-31',
      ]);

      const again = await build(trx).sync({ jobName: 'test', symbols: ['RELIANCE', 'HDFCBANK'] });
      expect(again).toMatchObject({
        snapshots: { inserted: 0, updated: 2 },
        statements: { inserted: 0, updated: 26 },
      });
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({
        id: again.runId,
        status: 'SUCCESS',
        operation: 'sync:fundamentals',
        // 2 snapshots + 26 statements: counts must survive stocks synced concurrently.
        recordsFetched: 28,
        recordsInserted: 0,
        recordsSkipped: 28,
      });
    });
  });

  it('leaves absolute amounts empty and skips statements for a non-INR reporter, without failing', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const r = await build(
        trx,
        (m) => new StubFundamentals(m, { currency: { INFY: 'USD' } }),
      ).sync({ jobName: 'test', symbols: ['INFY'] });
      expect(r).toMatchObject({ status: 'SUCCESS', statements: { inserted: 0, skipped: 13 } });
      expect(r.notes.join(' ')).toMatch(/INFY.*USD/);
      const snap = await new FundamentalsRepository(trx).latestSnapshot(
        await idOf(trx, 'INFY'),
        'MOCK',
      );
      expect(snap?.metrics).toMatchObject({
        revenueTtm: null,
        netProfitTtm: null,
        freeCashFlow: null,
      });
      expect(snap?.metrics.pe).toBeGreaterThan(0);
      expect(
        await new FundamentalsRepository(trx).listStatements(
          await idOf(trx, 'INFY'),
          'MOCK',
          'ANNUAL',
        ),
      ).toEqual([]);
    });
  });

  it('stores out-of-range and non-finite values as null with a note', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const r = await build(
        trx,
        (m) => new StubFundamentals(m, { patch: { TCS: { pe: 1e12, beta: Number.NaN } } }),
      ).sync({ jobName: 'test', symbols: ['TCS'], includeStatements: false });
      expect(r.status).toBe('SUCCESS');
      expect(r.notes.join(' ')).toMatch(/TCS.*pe.*beta|TCS.*beta.*pe/);
      expect(
        (await new FundamentalsRepository(trx).latestSnapshot(await idOf(trx, 'TCS'), 'MOCK'))
          ?.metrics,
      ).toMatchObject({ pe: null, beta: null });
    });
  });

  it('isolates a failing stock (PARTIAL) and ignores index symbols with a note', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'fundamental_snapshots', 'financial_statements');
      const r = await build(
        trx,
        (m) => new StubFundamentals(m, { fail: { TCS: new AppError('UNSUPPORTED', 'no data') } }),
      ).sync({
        jobName: 'test',
        symbols: ['RELIANCE', 'TCS', 'NIFTY50'],
        includeStatements: false,
      });
      expect(r.status).toBe('PARTIAL');
      expect(r.stocks).toEqual({ total: 2, succeeded: 1, failed: 1 });
      expect(r.failures).toEqual([expect.objectContaining({ symbol: 'TCS', code: 'UNSUPPORTED' })]);
      expect(r.notes.join(' ')).toMatch(/NIFTY50/);
    });
  });
});
