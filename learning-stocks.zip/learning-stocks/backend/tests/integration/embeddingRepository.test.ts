import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { hashEmbedding } from '../../src/providers/llm/mock/hashEmbedding.js';
import { sha256Hex } from '../../src/rag/documents.js';
import {
  EmbeddingRepository,
  type EmbeddingRow,
} from '../../src/repositories/EmbeddingRepository.js';
import { LlmCallRepository } from '../../src/repositories/LlmCallRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { newsArticle } from '../fixtures/ragArticles.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const MODEL = 'mock-hash-embedding-v1';

const row = (
  over: Partial<EmbeddingRow> & Pick<EmbeddingRow, 'sourceId' | 'content'>,
): EmbeddingRow => ({
  dataMode: 'MOCK',
  sourceType: 'NEWS',
  stockId: null,
  chunkIndex: 0,
  contentHash: sha256Hex(over.content),
  embedding: hashEmbedding(over.content),
  embeddingModel: MODEL,
  metadata: {},
  publishedAt: new Date('2026-10-04T05:00:00Z'),
  ...over,
});

async function ids(trx: Database) {
  const stocks = new StockRepository(trx);
  const rel = await stocks.findBySymbol('RELIANCE');
  const tcs = await stocks.findBySymbol('TCS');
  const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
  if (!rel || !tcs || !nifty) throw new Error('seed data missing');
  return { rel: rel.id, tcs: tcs.id, nifty: nifty.id };
}

describe('EmbeddingRepository', () => {
  it('lists pending targets: one per qualifying stock mention, else market-level for a qualifying market mention, else none', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'document_embeddings', 'news');
      const { rel, tcs, nifty } = await ids(trx);
      const news = new NewsRepository(trx);
      const saved = await news.saveArticles([
        newsArticle('Reliance and TCS sign deal', 'https://example.com/a'),
        newsArticle('Sensex ends flat', 'https://example.com/b', new Date('2026-10-05T05:00:00Z')),
        newsArticle(
          'TCS mentioned in passing',
          'https://example.com/c',
          new Date('2026-10-03T05:00:00Z'),
        ),
      ]);
      const [a, b, c] = saved.ids;
      await news.saveMentions([
        {
          newsId: a ?? '',
          ref: { kind: 'stock', id: rel },
          relevance: 0.9,
          matchedBy: 'name:title',
        },
        {
          newsId: a ?? '',
          ref: { kind: 'stock', id: tcs },
          relevance: 0.8,
          matchedBy: 'name:title',
        },
        {
          newsId: b ?? '',
          ref: { kind: 'market', id: nifty },
          relevance: 0.9,
          matchedBy: 'alias:title',
        },
        { newsId: c ?? '', ref: { kind: 'stock', id: tcs }, relevance: 0.4, matchedBy: 'query' },
      ]);
      const repo = new EmbeddingRepository(trx);
      const pending = await repo.pendingNews('MOCK', MODEL, 0.5, 10);
      // C has only a weak (0.4) query match: never embedded.
      expect(pending.map((p) => p.title)).toEqual([
        'Sensex ends flat',
        'Reliance and TCS sign deal',
      ]);
      expect(pending[1]?.targets.map((t) => t.stockId).sort()).toEqual([rel, tcs].sort());
      expect(pending[1]?.targets.find((t) => t.stockId === rel)?.relevance).toBe(0.9);
      expect(pending[0]?.targets).toEqual([{ stockId: null, relevance: 0.9 }]);
      expect(c).toBeDefined();

      await repo.upsertChunks([
        row({ sourceId: a ?? '', stockId: rel, content: 'Reliance and TCS sign deal' }),
      ]);
      const after = await repo.pendingNews('MOCK', MODEL, 0.5, 10);
      expect(after.find((p) => p.newsId === a)?.targets).toEqual([
        { stockId: tcs, relevance: 0.8 },
      ]);
      expect(await repo.pendingNews('MOCK', 'other-model', 0.5, 10)).toHaveLength(2);
      expect(await repo.pendingNews('MOCK', MODEL, 0.5, 1)).toHaveLength(1);
    });
  });

  it('upserts by (chunk, stock), reuses vectors by hash, trims surplus chunks and matches by model and scope', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'document_embeddings');
      const { rel, tcs } = await ids(trx);
      const repo = new EmbeddingRepository(trx);
      const src = '00000000-0000-4000-8000-000000000001';
      const written = await repo.upsertChunks([
        row({ sourceId: src, stockId: rel, content: 'reliance retail growth' }),
        row({ sourceId: src, stockId: rel, chunkIndex: 1, content: 'second chunk text' }),
        row({ sourceId: src, stockId: tcs, content: 'reliance retail growth' }),
        row({
          sourceId: '00000000-0000-4000-8000-000000000002',
          content: 'sensex market wide rally',
        }),
      ]);
      expect(written).toBe(4);
      // Same key again with new content: updated in place, not duplicated.
      await repo.upsertChunks([
        row({ sourceId: src, stockId: rel, content: 'reliance retail growth revised' }),
      ]);
      expect(await repo.chunkHashes('MOCK', MODEL, 'NEWS', [src])).toHaveLength(3);

      const vectors = await repo.vectorsByHash('MOCK', MODEL, [
        sha256Hex('reliance retail growth'),
        sha256Hex('nope'),
      ]);
      expect([...vectors.keys()]).toEqual([sha256Hex('reliance retail growth')]);
      expect(vectors.get(sha256Hex('reliance retail growth'))?.[0]).toBeCloseTo(
        hashEmbedding('reliance retail growth')[0] ?? 0,
        6,
      );

      await repo.deleteSurplusChunks('NEWS', src, rel, MODEL, 1);
      expect(
        (await repo.chunkHashes('MOCK', MODEL, 'NEWS', [src])).map((c) => c.chunkIndex),
      ).toEqual([0, 0]);

      const q = hashEmbedding('reliance retail');
      const forRel = await repo.match({
        query: q,
        dataMode: 'MOCK',
        stockId: rel,
        since: null,
        k: 10,
        sourceTypes: ['NEWS'],
        embeddingModel: MODEL,
      });
      expect(forRel).toHaveLength(1);
      expect(forRel[0]).toMatchObject({ sourceType: 'NEWS', sourceId: src, stockId: rel });
      expect(forRel[0]?.similarity).toBeGreaterThan(0);
      const market = await repo.match({
        query: q,
        dataMode: 'MOCK',
        stockId: null,
        since: null,
        k: 10,
        sourceTypes: null,
        embeddingModel: MODEL,
        marketOnly: true,
      });
      expect(market.map((m) => m.content)).toEqual(['sensex market wide rally']);
      expect(
        await repo.match({
          query: q,
          dataMode: 'MOCK',
          stockId: rel,
          since: null,
          k: 10,
          sourceTypes: null,
          embeddingModel: 'other',
        }),
      ).toEqual([]);
      const byId = await repo.vectorsByIds(forRel.map((m) => m.id));
      expect(byId.get(forRel[0]?.id ?? '')).toHaveLength(1536);
    });
  });

  it('removes market-level rows of a source and rejects wrong vector sizes', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'document_embeddings');
      const repo = new EmbeddingRepository(trx);
      const src = '00000000-0000-4000-8000-000000000003';
      await repo.upsertChunks([row({ sourceId: src, content: 'market level' })]);
      await repo.deleteMarketRows('NEWS', src, MODEL);
      expect(await repo.chunkHashes('MOCK', MODEL, 'NEWS', [src])).toEqual([]);
      await expect(
        repo.upsertChunks([row({ sourceId: src, content: 'x', embedding: [1, 2, 3] })]),
      ).rejects.toMatchObject({ code: 'INVALID_RESPONSE' });
    });
  });
});

describe('LlmCallRepository', () => {
  it('records a call with tokens and estimated cost', async () => {
    await withRollback(db, async (trx) => {
      const id = await new LlmCallRepository(trx).record({
        purpose: 'embeddings',
        provider: 'openai',
        model: 'text-embedding-3-small',
        promptVersion: null,
        inputTokens: 1200,
        outputTokens: 0,
        estCostInr: 0.0021,
        latencyMs: 340,
        cacheHit: false,
        status: 'OK',
        error: null,
      });
      const stored = await trx
        .selectFrom('llm_calls')
        .selectAll()
        .where('id', '=', id)
        .executeTakeFirstOrThrow();
      expect(stored).toMatchObject({
        purpose: 'embeddings',
        input_tokens: 1200,
        est_cost_inr: '0.0021',
        status: 'OK',
      });
    });
  });
});
