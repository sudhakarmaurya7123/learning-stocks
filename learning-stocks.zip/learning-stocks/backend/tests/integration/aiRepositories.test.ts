import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import {
  MarketSummaryRepository,
  type MarketSummaryRecord,
} from '../../src/repositories/MarketSummaryRepository.js';
import {
  NewsAnalysisRepository,
  type NewsSentimentRecord,
} from '../../src/repositories/NewsAnalysisRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { QaRepository } from '../../src/repositories/QaRepository.js';
import {
  StockAnalysisRepository,
  type StockAnalysisRecord,
} from '../../src/repositories/StockAnalysisRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { TradeSignalRepository } from '../../src/repositories/TradeSignalRepository.js';
import { newsArticle } from '../fixtures/ragArticles.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const V = 'news_sentiment_v1';

async function refs(trx: Database) {
  const s = new StockRepository(trx);
  return {
    rel: (await s.findBySymbol('RELIANCE'))?.id ?? '',
    tcs: (await s.findBySymbol('TCS'))?.id ?? '',
    nifty: (await new MarketRepository(trx).findBySymbol('NIFTY50'))?.id ?? '',
  };
}

const sentiment = (newsId: string, stockId: string | null): NewsSentimentRecord => ({
  newsId,
  stockId,
  sentiment: 'BEARISH',
  sentimentScore: 30,
  confidence: 70,
  relevanceScore: 0.9,
  impactLevel: 'MEDIUM',
  summary: 's',
  positiveFactors: [],
  negativeFactors: ['n'],
  reasoning: ['r'],
  model: 'mock-chat-v1',
  promptVersion: V,
});

const analysis = (
  stockId: string,
  over: Partial<StockAnalysisRecord> = {},
): StockAnalysisRecord => ({
  stockId,
  evaluationId: null,
  dataMode: 'MOCK',
  dataAsOf: new Date('2026-10-05T03:45:00Z'),
  status: 'OK',
  sentiment: 'NEUTRAL',
  sentimentScore: 50,
  confidence: 40,
  technicalScore: 60,
  fundamentalScore: 55,
  newsScore: null,
  momentumScore: 70,
  riskScore: 40,
  overallScore: 58,
  trend: 'UPTREND',
  riskLevel: 'MEDIUM',
  recommendation: 'HOLD_BIAS',
  summary: 'sum',
  reasoning: ['r'],
  keyPositiveFactors: [],
  keyNegativeFactors: [],
  keyRisks: ['k'],
  catalysts: [],
  invalidationConditions: ['i'],
  facts: [{ statement: 'f', source_ids: ['E1'] }],
  interpretation: [],
  insufficientData: [],
  sources: [{ id: 'E1', kind: 'EVALUATION', title: 'EVALUATION', asOf: '2026-10-05', url: null }],
  inputHash: 'h1',
  model: 'mock-chat-v1',
  promptVersion: 'stock_analysis_v1',
  ...over,
});

describe('NewsAnalysisRepository', () => {
  it('lists stock and market-level targets above the threshold, skips analysed ones, and reads market sentiment', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const { rel, tcs, nifty } = await refs(trx);
      const news = new NewsRepository(trx);
      const { ids } = await news.saveArticles([
        newsArticle(
          'Reliance shares rise',
          'https://example.com/1',
          new Date('2026-10-05T05:00:00Z'),
        ),
        newsArticle('Sensex falls', 'https://example.com/2', new Date('2026-10-04T05:00:00Z')),
        newsArticle('TCS in passing', 'https://example.com/3', new Date('2026-10-03T05:00:00Z')),
      ]);
      const [a, b, c] = ids.map((x) => x ?? '');
      await news.saveMentions([
        {
          newsId: a ?? '',
          ref: { kind: 'stock', id: rel },
          relevance: 0.9,
          matchedBy: 'name:title',
        },
        {
          newsId: b ?? '',
          ref: { kind: 'market', id: nifty },
          relevance: 0.8,
          matchedBy: 'alias:title',
        },
        { newsId: c ?? '', ref: { kind: 'stock', id: tcs }, relevance: 0.4, matchedBy: 'query' },
      ]);
      const repo = new NewsAnalysisRepository(trx);
      const pending = await repo.pending('MOCK', V, 0.5, 10);
      expect(pending.map((p) => [p.title, p.symbol, p.relevance])).toEqual([
        ['Reliance shares rise', 'RELIANCE', 0.9],
        ['Sensex falls', null, 0.8],
      ]);
      expect(await repo.insert(sentiment(b ?? '', null))).toBe(true);
      expect(await repo.insert(sentiment(b ?? '', null))).toBe(false);
      expect((await repo.pending('MOCK', V, 0.5, 10)).map((p) => p.title)).toEqual([
        'Reliance shares rise',
      ]);
      expect(await repo.pending('MOCK', 'news_sentiment_v2', 0.5, 10)).toHaveLength(2);
      expect(await repo.marketSentiments('MOCK', new Date('2026-10-01T00:00:00Z'))).toEqual([
        {
          sentiment: 'BEARISH',
          sentimentScore: 30,
          relevance: 0.9,
          publishedAt: new Date('2026-10-04T05:00:00Z'),
        },
      ]);
    });
  });
});

describe('StockAnalysisRepository', () => {
  it('never overwrites a usable row, replaces a FAILED one, and honours replace', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'stock_ai_analysis');
      const { rel } = await refs(trx);
      const repo = new StockAnalysisRepository(trx);
      const failed = await repo.save(analysis(rel, { status: 'FAILED', summary: null }));
      expect(failed.written).toBe(true);
      expect(await repo.findUsable(rel, 'MOCK', 'h1', 'stock_analysis_v1')).toBeNull();
      const ok = await repo.save(analysis(rel));
      expect(ok).toEqual({ id: failed.id, written: true });
      expect((await repo.findUsable(rel, 'MOCK', 'h1', 'stock_analysis_v1'))?.status).toBe('OK');
      expect(await repo.save(analysis(rel, { summary: 'other' }))).toEqual({
        id: failed.id,
        written: false,
      });
      expect((await repo.latest(rel, 'MOCK'))?.summary).toBe('sum');
      await repo.save(analysis(rel, { summary: 'regenerated' }), { replace: true });
      const latest = await repo.latest(rel, 'MOCK');
      expect(latest).toMatchObject({
        summary: 'regenerated',
        overallScore: 58,
        facts: [{ statement: 'f', source_ids: ['E1'] }],
      });
      expect(latest?.sources[0]).toMatchObject({ id: 'E1', kind: 'EVALUATION' });
    });
  });
});

describe('MarketSummaryRepository', () => {
  it('stores one summary per input hash and returns the latest', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_ai_summary');
      const { nifty } = await refs(trx);
      const repo = new MarketSummaryRepository(trx);
      const r: MarketSummaryRecord = {
        marketId: nifty,
        dataMode: 'MOCK',
        dataAsOf: new Date('2026-10-05T03:45:00Z'),
        sentiment: 'BEARISH',
        sentimentScore: 35,
        confidence: 50,
        trend: 'DOWNTREND',
        regime: 'RISK_OFF',
        riskLevel: 'HIGH',
        summary: 's',
        keyDrivers: ['d'],
        keyRisks: [],
        sectorsPositive: [],
        sectorsNegative: ['Banks'],
        sources: [],
        inputHash: 'm1',
        model: 'mock-chat-v1',
        promptVersion: 'market_analysis_v1',
      };
      expect((await repo.insert(r)).inserted).toBe(true);
      expect((await repo.insert(r)).inserted).toBe(false);
      expect(await repo.findByHash(nifty, 'MOCK', 'm1', 'market_analysis_v1')).toMatchObject({
        regime: 'RISK_OFF',
        sectorsNegative: ['Banks'],
      });
      expect((await repo.latest(nifty, 'MOCK'))?.riskLevel).toBe('HIGH');
    });
  });
});

describe('TradeSignalRepository', () => {
  it('creates, lists active, changes status and expires', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'ai_trade_signals');
      const { rel } = await refs(trx);
      const repo = new TradeSignalRepository(trx);
      const id = await repo.create({
        stockId: rel,
        analysisId: null,
        evaluationId: null,
        dataMode: 'MOCK',
        signal: 'BUY',
        confidence: 60,
        entryPrice: 1157.5,
        entryLow: 1150,
        entryHigh: 1165,
        targetPrice: 1240,
        target2: 1300,
        stopLoss: 1110,
        riskRewardRatio: 1.8,
        suggestedQuantity: 200,
        reasoning: ['r'],
        validUntil: new Date('2026-10-06T10:00:00Z'),
      });
      expect((await repo.active(rel, 'MOCK')).map((s) => [s.id, s.status, s.entryLow])).toEqual([
        [id, 'ACTIVE', 1150],
      ]);
      expect(await repo.expire('MOCK', new Date('2026-10-06T09:00:00Z'))).toBe(0);
      expect(await repo.expire('MOCK', new Date('2026-10-06T11:00:00Z'))).toBe(1);
      expect(await repo.active(rel, 'MOCK')).toEqual([]);
      await repo.setStatus([id], 'INVALIDATED');
      const row = await trx
        .selectFrom('ai_trade_signals')
        .select('status')
        .where('id', '=', id)
        .executeTakeFirstOrThrow();
      expect(row.status).toBe('INVALIDATED');
    });
  });
});

describe('QaRepository', () => {
  it('finds a cached answer by (stock, mode, question hash, context hash, prompt version)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'ai_qa_log');
      const { rel } = await refs(trx);
      const repo = new QaRepository(trx);
      const answer = { answer: 'a', facts: [], interpretation: [], insufficient_data: [] };
      await repo.insert({
        stockId: rel,
        dataMode: 'MOCK',
        question: 'Why?',
        questionHash: 'q',
        contextHash: 'c',
        answer,
        sources: [],
        model: 'mock-chat-v1',
        promptVersion: 'stock_qa_v1',
      });
      expect(await repo.findCached(rel, 'MOCK', 'q', 'c', 'stock_qa_v1')).toMatchObject({
        answer,
        model: 'mock-chat-v1',
      });
      expect(await repo.findCached(rel, 'MOCK', 'q', 'other', 'stock_qa_v1')).toBeNull();
    });
  });
});
