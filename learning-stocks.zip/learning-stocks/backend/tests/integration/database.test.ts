import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { createDatabase, pingDatabase } from '../../src/database/db.js';
import { DB_ENUMS } from '../../src/domain/enums.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('database layer', () => {
  it('pings a live database and reports a dead one without hanging', async () => {
    expect(await pingDatabase(db)).toBe(true);
    const dead = createDatabase('postgresql://postgres:postgres@127.0.0.1:1/postgres', { max: 1 });
    const started = Date.now();
    expect(await pingDatabase(dead, 1500)).toBe(false);
    expect(Date.now() - started).toBeLessThan(3000);
    await dead.destroy();
  });

  it('returns DATE columns as YYYY-MM-DD strings regardless of host timezone', async () => {
    const row = await db
      .selectFrom('exchange_holidays')
      .select('holiday_date')
      .where('exchange', '=', 'NSE')
      .orderBy('holiday_date')
      .executeTakeFirstOrThrow();
    expect(row.holiday_date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(row.holiday_date).toBe('2026-01-15');
  });

  it('mirrors every Postgres enum exactly (labels and order)', async () => {
    for (const [name, labels] of Object.entries(DB_ENUMS)) {
      const result = await sql<{ label: string }>`
        select e.enumlabel as label from pg_enum e join pg_type t on t.oid = e.enumtypid
        join pg_namespace n on n.oid = t.typnamespace
        where n.nspname = 'public' and t.typname = ${name} order by e.enumsortorder`.execute(db);
      expect(
        result.rows.map((r) => r.label),
        name,
      ).toEqual([...labels]);
    }
  });

  it('withRollback leaves no data behind', async () => {
    await withRollback(db, async (trx) => {
      await trx
        .insertInto('app_settings')
        .values({ key: 'zz_probe', value: sql`'1'::jsonb` })
        .execute();
    });
    const left = await db
      .selectFrom('app_settings')
      .select('key')
      .where('key', '=', 'zz_probe')
      .execute();
    expect(left).toHaveLength(0);
  });
});
