import { Writable } from 'node:stream';
import { describe, expect, it } from 'vitest';
import { NewsSentimentSchema } from '../../src/ai/schemas.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createLogger } from '../../src/utils/logger.js';

const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});

describe('container wiring', () => {
  it('uses the mock provider in mock mode and exposes the market data service', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.providers.marketData.name).toBe('mock');
    expect(c.services.marketData).toBeDefined();
    await c.close();
  });

  it('uses the Yahoo provider in live mode (no network at construction)', async () => {
    const c = createContainer(
      loadConfig({
        MOCK_DATA: 'false',
        MARKET_DATA_PROVIDER: 'yahoo',
        NEWS_PROVIDER: 'none',
        FUNDAMENTALS_PROVIDER: 'none',
        LLM_PROVIDER: 'none',
      }),
      { logger: silent },
    );
    expect(c.providers.marketData.name).toBe('yahoo');
    expect(c.providers.marketData.capabilities().latency).toBe('delayed');
    await c.close();
  });

  const live = (over: Record<string, string>) =>
    loadConfig({
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'none',
      FUNDAMENTALS_PROVIDER: 'none',
      LLM_PROVIDER: 'none',
      ...over,
    });

  it('wires mock news and fundamentals in mock mode', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.providers.news?.name).toBe('mock');
    expect(c.providers.fundamentals?.name).toBe('mock');
    expect(c.services.news).not.toBeNull();
    expect(c.services.fundamentals).not.toBeNull();
    await c.close();
  });

  it("disables news and fundamentals with 'none'", async () => {
    const c = createContainer(live({}), { logger: silent });
    expect(c.providers.news).toBeNull();
    expect(c.services.news).toBeNull();
    expect(c.services.fundamentals).toBeNull();
    await c.close();
  });

  it('wires real adapters in live mode (no network at construction)', async () => {
    const rss = createContainer(live({ NEWS_PROVIDER: 'rss', FUNDAMENTALS_PROVIDER: 'yahoo' }), {
      logger: silent,
    });
    expect(rss.providers.news?.name).toBe('rss');
    expect(rss.providers.fundamentals?.name).toBe('yahoo');
    await rss.close();
    const newsapi = createContainer(live({ NEWS_PROVIDER: 'newsapi', NEWS_API_KEY: 'k' }), {
      logger: silent,
    });
    expect(newsapi.providers.news?.capabilities()).toEqual({
      maxInstrumentsPerQuery: 10,
      latency: 'delayed',
    });
    await newsapi.close();
  });

  it('wires the evaluation service', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.services.evaluation).toBeDefined();
    expect((await c.repositories.scoringConfigs.getActive()).version).toBe('v1');
    await c.close();
  });

  it('wires the mock LLM, embeddings, retriever and stock context in mock mode', async () => {
    const c = createContainer(loadConfig({}), { logger: silent });
    expect(c.providers.llm?.name).toBe('mock');
    expect(c.services.embeddings).not.toBeNull();
    expect(c.services.retriever).not.toBeNull();
    expect(c.services.stockContext).not.toBeNull();
    await c.close();
  });

  it('disables RAG with LLM_PROVIDER=none and builds the OpenAI adapter without network', async () => {
    const base = {
      MOCK_DATA: 'false',
      MARKET_DATA_PROVIDER: 'yahoo',
      NEWS_PROVIDER: 'none',
      FUNDAMENTALS_PROVIDER: 'none',
    };
    const none = createContainer(loadConfig({ ...base, LLM_PROVIDER: 'none' }), { logger: silent });
    expect(none.providers.llm).toBeNull();
    expect(none.services.embeddings).toBeNull();
    expect(none.services.stockContext).toBeNull();
    await none.close();
    const openai = createContainer(
      loadConfig({
        ...base,
        LLM_PROVIDER: 'openai',
        OPENAI_API_KEY: 'sk-x',
        LLM_MODEL: 'gpt-5-mini',
      }),
      { logger: silent },
    );
    expect(openai.providers.llm).toMatchObject({
      name: 'openai',
      embeddingModel: 'text-embedding-3-small',
      chatModel: 'gpt-5-mini',
    });
    await openai.close();
  });

  it('wires the AI services and the budget in mock mode, and disables them with LLM_PROVIDER=none', async () => {
    const mock = createContainer(loadConfig({}), { logger: silent });
    expect(mock.services.ai).not.toBeNull();
    expect(mock.services.budget).toBeDefined();
    expect(
      (
        await mock.providers.llm?.completeStructured({
          system: 's',
          user: 'Subject: X\n\n<<<BEGIN ARTICLE>>>\nX shares rise\n<<<END ARTICLE>>>',
          schema: NewsSentimentSchema,
          schemaName: 'news_sentiment',
        })
      )?.data.sentiment,
    ).toBe('BULLISH'); // mock responders registered
    await mock.close();
    const none = createContainer(
      loadConfig({
        MOCK_DATA: 'false',
        MARKET_DATA_PROVIDER: 'yahoo',
        NEWS_PROVIDER: 'none',
        FUNDAMENTALS_PROVIDER: 'none',
        LLM_PROVIDER: 'none',
      }),
      { logger: silent },
    );
    expect(none.services.ai).toBeNull();
    await none.close();
  });
});
