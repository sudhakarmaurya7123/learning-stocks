import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { MockNewsProvider } from '../../src/providers/news/mock/MockNewsProvider.js';
import type {
  InstrumentNewsQuery,
  NewsFetchResult,
  NewsProvider,
  RawArticle,
} from '../../src/providers/news/types.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { NewsService } from '../../src/services/news/NewsService.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
const NOW = new Date('2026-10-05T12:00:00Z');
const SINCE = new Date('2026-09-28T12:00:00Z');
const ok = (articles: RawArticle[] = []): NewsFetchResult => ({ articles, failures: [] });
const raw = (over: Partial<RawArticle>): RawArticle => ({
  title: 'x',
  url: 'https://example.com/x',
  description: null,
  content: null,
  author: null,
  publishedAt: new Date('2026-10-05T06:00:00Z'),
  publisherUrl: null,
  language: 'en',
  ...over,
});

/** Scripted provider: per query key ('market' or 'SYM1,SYM2') a result or an error. */
class ScriptedNews implements NewsProvider {
  readonly name = 'mock';
  calls: string[] = [];
  constructor(
    private readonly script: Record<string, NewsFetchResult | AppError>,
    private readonly size = 1,
  ) {}
  capabilities() {
    return { maxInstrumentsPerQuery: this.size, latency: 'realtime' as const };
  }
  async fetchForInstruments(q: InstrumentNewsQuery) {
    return this.answer(q.subjects.map((s) => s.symbol).join(','));
  }
  async fetchMarketNews() {
    return this.answer('market');
  }
  private async answer(key: string): Promise<NewsFetchResult> {
    this.calls.push(key);
    const r = this.script[key];
    if (r instanceof AppError) throw r;
    return r ?? ok();
  }
}

function build(trx: Database, provider: NewsProvider) {
  return new NewsService({
    provider,
    dataMode: 'MOCK',
    logger: silent,
    now: () => NOW,
    retry: { sleep: async () => undefined },
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    news: new NewsRepository(trx),
    systemLogs: new SystemLogRepository(trx),
  });
}

async function stockRef(trx: Database, symbol: string) {
  return {
    kind: 'stock' as const,
    id: (await new StockRepository(trx).findBySymbol(symbol))?.id ?? '',
  };
}

describe('NewsService', () => {
  it('syncs mock news idempotently, linking articles to stocks and indices', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const service = build(trx, new MockNewsProvider(() => NOW));
      const first = await service.sync({
        jobName: 'test',
        since: SINCE,
        symbols: ['RELIANCE', 'TCS'],
      });
      expect(first).toMatchObject({
        status: 'SUCCESS',
        queries: { total: 3, succeeded: 3, failed: 0 },
      });
      expect(first.articles.new).toBeGreaterThan(0);
      expect(first.articles.existing).toBe(0);

      const news = new NewsRepository(trx);
      const reliance = await news.listForInstrument(await stockRef(trx, 'RELIANCE'), 'MOCK');
      expect(reliance.length).toBeGreaterThan(0);
      expect(
        reliance.every(
          (n) =>
            n.title.startsWith('[MOCK] Reliance Industries') &&
            n.relevance === 1 &&
            n.matchedBy === 'name:title',
        ),
      ).toBe(true);
      const markets = new MarketRepository(trx);
      const indexMentions = await Promise.all(
        ['NIFTY50', 'SENSEX', 'BANKNIFTY', 'INDIAVIX'].map(
          async (s) =>
            (
              await news.listForInstrument(
                { kind: 'market', id: (await markets.findBySymbol(s))?.id ?? '' },
                'MOCK',
              )
            ).length,
        ),
      );
      expect(indexMentions.reduce((a, b) => a + b, 0)).toBeGreaterThan(0);

      const again = await service.sync({
        jobName: 'test',
        since: SINCE,
        symbols: ['RELIANCE', 'TCS'],
      });
      expect(again.articles).toMatchObject({ new: 0, existing: first.articles.new });
      expect(again.mentions).toBe(first.mentions);
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({
        id: again.runId,
        status: 'SUCCESS',
        operation: 'sync:news',
        recordsInserted: 0,
      });
    });
  });

  it('isolates a failing query and a failing feed, and reports PARTIAL', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const provider = new ScriptedNews({
        market: {
          articles: [],
          failures: [{ source: 'Mint Markets', code: 'AUTH_FAILED', message: 'blocked' }],
        },
        RELIANCE: ok([
          raw({ title: 'Reliance Industries wins order', url: 'https://example.com/ril-order' }),
        ]),
        TCS: new AppError('TIMEOUT', 'slow'),
      });
      const r = await build(trx, provider).sync({
        jobName: 'test',
        since: SINCE,
        symbols: ['RELIANCE', 'TCS'],
      });
      expect(r.status).toBe('PARTIAL');
      expect(r.queries).toEqual({ total: 3, succeeded: 2, failed: 1 });
      expect(r.failures.map((f) => [f.source, f.code]).sort()).toEqual([
        ['Mint Markets', 'AUTH_FAILED'],
        ['TCS', 'TIMEOUT'],
      ]);
      expect(provider.calls.filter((c) => c === 'TCS')).toHaveLength(3);
      expect(r.articles.new).toBe(1);
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run?.errorDetails).toMatchObject({
        failures: expect.arrayContaining([
          expect.objectContaining({ source: 'TCS', code: 'TIMEOUT' }),
        ]),
      });
    });
  });

  it('stores one row for a story seen by two routes and adds a low query-only mention', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const title = 'Reliance Industries raises funds via bonds';
      const r = await build(
        trx,
        new ScriptedNews({
          RELIANCE: ok([
            raw({
              title,
              url: 'https://news.google.com/rss/articles/A?oc=5',
              publisherUrl: 'https://www.business-standard.com',
            }),
          ]),
          market: ok([
            raw({
              title,
              url: 'https://www.business-standard.com/markets/news/ril-bonds.html',
              publishedAt: new Date('2026-10-05T06:04:00Z'),
            }),
          ]),
          TCS: ok([
            raw({ title: 'IT services demand slows', url: 'https://example.com/it-demand' }),
          ]),
        }),
      ).sync({ jobName: 'test', since: SINCE, symbols: ['RELIANCE', 'TCS'] });
      expect(r.articles).toMatchObject({ fetched: 3, new: 2, dropped: 1 });
      expect(r.droppedByReason).toEqual({ DUPLICATE_IN_BATCH: 1 });
      const news = new NewsRepository(trx);
      expect(await news.listForInstrument(await stockRef(trx, 'RELIANCE'), 'MOCK')).toEqual([
        expect.objectContaining({ title, relevance: 1, matchedBy: 'name:title' }),
      ]);
      expect(await news.listForInstrument(await stockRef(trx, 'TCS'), 'MOCK')).toEqual([
        expect.objectContaining({ relevance: 0.4, matchedBy: 'query' }),
      ]);
    });
  });

  it('batches instruments when the provider allows it (no query-only mentions for batches)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const provider = new ScriptedNews(
        {
          'INFY,RELIANCE,TCS': ok([
            raw({ title: 'Markets await RBI policy', url: 'https://example.com/rbi' }),
          ]),
        },
        10,
      );
      const r = await build(trx, provider).sync({
        jobName: 'test',
        since: SINCE,
        symbols: ['RELIANCE', 'TCS', 'INFY'],
        includeMarket: false,
      });
      expect(provider.calls).toEqual(['INFY,RELIANCE,TCS']);
      expect(r).toMatchObject({ status: 'SUCCESS', mentions: 0 });
    });
  });

  it('reports FAILED when nothing succeeds and notes unknown symbols; counts undated articles as dropped', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'news');
      const failed = await build(
        trx,
        new ScriptedNews({ TCS: new AppError('AUTH_FAILED', 'bad key') }),
      ).sync({ jobName: 'test', since: SINCE, symbols: ['TCS', 'NOSUCH'], includeMarket: false });
      expect(failed.status).toBe('FAILED');
      expect(failed.notes.join(' ')).toMatch(/NOSUCH/);

      const undated = await build(
        trx,
        new ScriptedNews({ market: ok([raw({ publishedAt: null })]) }),
      ).sync({ jobName: 'test', since: SINCE, symbols: [] });
      expect(undated).toMatchObject({ status: 'SUCCESS', droppedByReason: { INVALID_DATE: 1 } });
    });
  });
});
