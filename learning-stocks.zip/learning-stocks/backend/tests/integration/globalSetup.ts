import pg from 'pg';
import { LOCAL_DATABASE_URL } from './helpers.js';

export default async function setup(): Promise<void> {
  const url = process.env.DATABASE_URL ?? LOCAL_DATABASE_URL;
  const client = new pg.Client({ connectionString: url, connectionTimeoutMillis: 3000 });
  try {
    await client.connect();
    await client.query('select 1');
  } catch {
    throw new Error(
      `Integration tests need the local database at ${url}. Run: pnpm db:start && pnpm db:reset`,
    );
  } finally {
    await client.end().catch(() => undefined);
  }
}
