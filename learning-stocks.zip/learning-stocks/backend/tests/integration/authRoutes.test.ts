import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { requireAdmin } from '../../src/http/auth.js';
import type { Database } from '../../src/database/db.js';
import { capturingLogger, createTestDb, silentLogger, withRollback } from './helpers.js';

const SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long';
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const db = createTestDb();
const jwtEnv = { AUTH_MODE: 'jwt', JWT_SECRET: SECRET, SUPABASE_URL: 'http://127.0.0.1:54321' };

const sign = (sub: string) =>
  new SignJWT({ sub, role: 'authenticated', email: `${sub}@example.com` })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(ISSUER)
    .setAudience('authenticated')
    .setIssuedAt()
    .setExpirationTime('1h')
    .sign(new TextEncoder().encode(SECRET));

/**
 * Inserts a real auth.users row so handle_new_user() creates the profile, then sets the role.
 * Measured: this works as `postgres` inside a transaction, and the trigger assigns OWNER to the
 * first user in a clean user_profiles.
 */
async function seedUser(trx: Database, role: 'OWNER' | 'ADMIN' | 'VIEWER' | null): Promise<string> {
  const id = randomUUID();
  await sql`
    insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)
    values (${id}::uuid, '00000000-0000-0000-0000-000000000000'::uuid, 'authenticated',
            'authenticated', ${`${id}@example.com`}, 'x', now(), now())
  `.execute(trx);
  if (role === null) {
    // A token that verifies but has no profile row: identity without authorization.
    await trx.deleteFrom('user_profiles').where('user_id', '=', id).execute();
  } else {
    await trx.updateTable('user_profiles').set({ role }).where('user_id', '=', id).execute();
  }
  return id;
}

/** buildApp plus two throwaway routes, so this file does not depend on Tasks 5 and 8. */
async function appOver(trx: Database, env: Record<string, string>, logger = silentLogger) {
  const container = createContainer(loadConfig(env), { db: trx, logger });
  // extraRoutes, not app.get: Fastify encapsulates hooks per scope, so a route added to the
  // returned instance would sit outside the auth preHandler and always answer 200.
  const app = await buildApp(container, {
    extraRoutes: (api) => {
      api.get('/_probe/read', async () => ({ data: 'ok' }));
      api.post('/_probe/admin', async (request) => {
        requireAdmin(request);
        return { data: 'ok' };
      });
    },
  });
  await app.ready();
  return app;
}

describe('auth', () => {
  it('refuses a request with no token, and leaves /api/health public', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, jwtEnv);
      const denied = await app.inject({ method: 'GET', url: '/api/_probe/read' });
      expect(denied.statusCode).toBe(401);
      expect(denied.json()).toMatchObject({ error: { code: 'UNAUTHORIZED' } });
      // A load balancer cannot present a token, and Phase 2's app.test.ts calls this untokened.
      // 200, not "< 500": a 401 also satisfies "< 500", so the weaker assertion passed even with
      // /health moved inside the authenticated scope.
      expect((await app.inject({ method: 'GET', url: '/api/health' })).statusCode).toBe(200);
    });
  });

  it('refuses a valid token with no user_profiles row (403, not an implied role)', async () => {
    // A token proves identity; the profile row is the authorization. Defaulting to VIEWER would
    // let anyone who can sign up read the whole research desk.
    await withRollback(db, async (trx) => {
      const id = await seedUser(trx, null);
      const app = await appOver(trx, jwtEnv);
      const r = await app.inject({
        method: 'GET',
        url: '/api/_probe/read',
        headers: { authorization: `Bearer ${await sign(id)}` },
      });
      expect(r.statusCode).toBe(403);
      expect(r.json()).toMatchObject({ error: { code: 'FORBIDDEN' } });
    });
  });

  it('lets a VIEWER read but not run an admin action, and lets an OWNER do both', async () => {
    await withRollback(db, async (trx) => {
      const viewer = await seedUser(trx, 'VIEWER');
      const owner = await seedUser(trx, 'OWNER');
      const app = await appOver(trx, jwtEnv);
      const asUser = async (id: string) => ({ authorization: `Bearer ${await sign(id)}` });

      expect(
        (
          await app.inject({
            method: 'GET',
            url: '/api/_probe/read',
            headers: await asUser(viewer),
          })
        ).statusCode,
      ).toBe(200);
      expect(
        (
          await app.inject({
            method: 'POST',
            url: '/api/_probe/admin',
            headers: await asUser(viewer),
            payload: {},
          })
        ).statusCode,
      ).toBe(403);
      expect(
        (
          await app.inject({
            method: 'POST',
            url: '/api/_probe/admin',
            headers: await asUser(owner),
            payload: {},
          })
        ).statusCode,
      ).toBe(200);
    });
  });

  it('never logs the Authorization header', async () => {
    // PRD §15: a bearer token in a log file is a leaked credential. Phase 2 already redacts
    // req.headers.authorization; this is the regression test for a future log call that
    // serializes headers around the redaction.
    await withRollback(db, async (trx) => {
      const { logger, lines } = capturingLogger();
      const id = await seedUser(trx, 'OWNER');
      const token = await sign(id);
      const app = await appOver(trx, jwtEnv, logger);
      await app.inject({
        method: 'GET',
        url: '/api/_probe/read',
        headers: { authorization: `Bearer ${token}` },
      });
      expect(lines.length).toBeGreaterThan(0);
      expect(lines.join('\n')).not.toContain(token);
      expect(lines.join('\n')).not.toMatch(/Bearer /);
    });
  });
});

describe('AUTH_MODE=none', () => {
  it('answers as OWNER without a token, in mock mode on loopback', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none' });
      expect((await app.inject({ method: 'GET', url: '/api/_probe/read' })).statusCode).toBe(200);
      // The bypass user is OWNER, so admin routes work locally without a Supabase user.
      expect(
        (await app.inject({ method: 'POST', url: '/api/_probe/admin', payload: {} })).statusCode,
      ).toBe(200);
    });
  });

  it('is refused in live mode and when not bound to loopback', () => {
    expect(() =>
      loadConfig({
        AUTH_MODE: 'none',
        MOCK_DATA: 'false',
        MARKET_DATA_PROVIDER: 'yahoo',
        NEWS_PROVIDER: 'none',
        FUNDAMENTALS_PROVIDER: 'none',
        LLM_PROVIDER: 'none',
      }),
    ).toThrow(/AUTH_MODE=none/);
    expect(() => loadConfig({ AUTH_MODE: 'none', HOST: '0.0.0.0' })).toThrow(/AUTH_MODE=none/);
  });

  it('refuses jwt mode with no secret and no Supabase URL, at buildApp not loadConfig', async () => {
    // loadConfig({}) is called by config.test.ts, container.test.ts, jobHandlers.test.ts, every
    // CLI and the worker — none of which has JWT material. Failing there breaks the suite.
    expect(() => loadConfig({})).not.toThrow();
    await withRollback(db, async (trx) => {
      const container = createContainer(loadConfig({ AUTH_MODE: 'jwt' }), {
        db: trx,
        logger: silentLogger,
      });
      await expect(buildApp(container)).rejects.toThrow(/JWT_SECRET|SUPABASE_URL/);
    });
  });
});
