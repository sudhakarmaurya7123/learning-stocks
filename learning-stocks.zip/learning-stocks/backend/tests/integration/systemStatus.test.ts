import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { Database } from '../../src/database/db.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { PgBossQueue } from '../../src/jobs/PgBossQueue.js';
import {
  createTestDb,
  isolateTables,
  LOCAL_DATABASE_URL,
  silentLogger,
  withRollback,
} from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const ZERO = { fetched: 0, inserted: 0, skipped: 0, failed: 0 };

const build = async (trx: Database) => {
  const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
    db: trx,
    logger: silentLogger,
    // No real queue: worker liveness degrades to 'unknown' rather than opening a connection.
    jobQueue: null,
  });
  const app = await buildApp(container);
  await app.ready();
  return {
    app,
    status: async () =>
      (await app.inject({ method: 'GET', url: '/api/system-status' })).json().data,
  };
};

describe('GET /system-status', () => {
  it('reports providers, data mode, market status and the LLM budget', async () => {
    await withRollback(db, async (trx) => {
      const { status } = await build(trx);
      expect(await status()).toMatchObject({
        data_mode: 'MOCK',
        database_status: 'up',
        market_data_provider: 'mock',
        news_provider: 'mock',
        fundamentals_provider: 'mock',
        llm_provider: 'mock',
        auth_mode: 'none',
        market_status: expect.objectContaining({ is_open: expect.any(Boolean) }),
        llm_budget: expect.objectContaining({
          daily_budget_inr: expect.any(Number),
          exhausted: expect.any(Boolean),
        }),
        worker: expect.objectContaining({
          status: expect.stringMatching(/^(live|down|unknown)$/),
        }),
      });
    });
  });

  it('counts only a real run as the last sync, never a SKIPPED one', async () => {
    // A market-closed SKIP is not a sync. Reporting it as last_market_sync would tell the owner
    // the data is current when nothing was fetched.
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const logs = new SystemLogRepository(trx);
      const { status } = await build(trx);

      const skipped = await logs.startRun({
        service: 'JobRunner',
        jobName: 'market.sync.intraday',
        operation: 'market.sync.intraday',
      });
      await logs.finishRun(skipped, { status: 'SKIPPED', counts: ZERO, message: 'closed' });
      expect((await status()).last_market_sync).toBeNull();

      const real = await logs.startRun({
        service: 'MarketDataService',
        jobName: 'market.sync.eod',
        operation: 'sync:1d',
      });
      await logs.finishRun(real, {
        status: 'SUCCESS',
        counts: { ...ZERO, inserted: 32 },
        message: 'ok',
      });
      const afterReal = (await status()).last_market_sync;
      expect(afterReal).not.toBeNull();

      // And a LATER skip must not overwrite it. Without this the rule is untested whenever the
      // skip happens to be the older row: the real run would sort first for the wrong reason.
      const laterSkip = await logs.startRun({
        service: 'MarketDataService',
        jobName: 'market.sync.intraday',
        operation: 'sync:5m',
      });
      await logs.finishRun(laterSkip, { status: 'SKIPPED', counts: ZERO, message: 'closed' });
      expect((await status()).last_market_sync).toBe(afterReal);
    });
  });

  it('counts a CLI run too, because it keys on the service not the job name', async () => {
    // `pnpm sync:market` logs jobName 'cli.sync-market'. It is still a market sync.
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const logs = new SystemLogRepository(trx);
      const { status } = await build(trx);
      const cli = await logs.startRun({
        service: 'MarketDataService',
        jobName: 'cli.sync-market',
        operation: 'sync:1d',
      });
      await logs.finishRun(cli, {
        status: 'PARTIAL',
        counts: { ...ZERO, inserted: 1 },
        message: 'one instrument failed',
      });
      expect((await status()).last_market_sync).not.toBeNull();
    });
  });

  it('lists failed jobs so a silent breakage is visible', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const logs = new SystemLogRepository(trx);
      const { status } = await build(trx);
      const failed = await logs.startRun({
        service: 'NewsService',
        jobName: 'news.sync',
        operation: 'news.sync',
      });
      await logs.finishRun(failed, {
        status: 'FAILED',
        counts: ZERO,
        message: 'provider refused the request',
      });
      const d = await status();
      expect(d.failed_jobs).toHaveLength(1);
      expect(d.failed_jobs[0]).toMatchObject({ job_name: 'news.sync', service: 'NewsService' });
      // A failure is not a sync: last_news_sync must stay null.
      expect(d.last_news_sync).toBeNull();
    });
  });

  it('reports a real worker as live, with a real queue attached', async () => {
    // The jobQueue: null cases below cannot catch this: with a real PgBossQueue the liveness
    // query ran before start() and threw, so a plainly-running worker reported 'unknown'.
    // Verified by hand against `pnpm worker`; this pins it.
    await withRollback(db, async (trx) => {
      const schema = 'pgboss_test_status';
      await sql`drop schema if exists ${sql.id(schema)} cascade`.execute(db);
      const queue = new PgBossQueue({
        connectionString: process.env.DATABASE_URL ?? LOCAL_DATABASE_URL,
        schema,
        logger: silentLogger,
        tz: 'Asia/Kolkata',
        // A worker-shaped instance: schedule on, which is what liveness looks for.
        schedule: true,
        supervise: false,
      });
      await queue.start();
      try {
        const container = createContainer(
          loadConfig({ AUTH_MODE: 'none', WORKER_QUEUE_SCHEMA: schema }),
          {
            db: trx,
            logger: silentLogger,
          },
        );
        const app = await buildApp(container);
        await app.ready();
        const d = (await app.inject({ method: 'GET', url: '/api/system-status' })).json().data;
        expect(d.worker).toMatchObject({ status: 'live', live: 1 });
        expect(d.worker.last_heartbeat).not.toBeNull();
        await app.close();
      } finally {
        await queue.stop();
        await sql`drop schema if exists ${sql.id(schema)} cascade`.execute(db);
      }
    });
  });

  it('reports database_status down instead of 500 when the database is unreachable', async () => {
    // The status page is most needed exactly when something is broken. pingDatabase never throws,
    // but it shared a Promise.all with six queries that do — so the whole route 500d and the
    // 'down' branch was dead code.
    // A pool pointed at a closed port: every query rejects, which is what an outage looks like.
    const container = createContainer(
      loadConfig({
        AUTH_MODE: 'none',
        DATABASE_URL: 'postgresql://postgres:postgres@127.0.0.1:1/postgres',
      }),
      { logger: silentLogger, jobQueue: null },
    );
    const app = await buildApp(container);
    await app.ready();
    const r = await app.inject({ method: 'GET', url: '/api/system-status' });
    expect(r.statusCode).toBe(200);
    const d = r.json().data;
    expect(d.database_status).toBe('down');
    // The parts that need the database degrade to null rather than taking the page down.
    expect(d.last_market_sync).toBeNull();
    expect(d.failed_jobs).toEqual([]);
    await app.close();
    await container.close();
  });

  it("reports worker status 'unknown' rather than failing when no queue is available", async () => {
    // Worker liveness is a nicety on a status page; it must never take /system-status down.
    await withRollback(db, async (trx) => {
      const { status } = await build(trx);
      expect((await status()).worker).toMatchObject({ status: 'unknown', live: 0 });
    });
  });
});
