import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { emptyStatementMetrics } from '../../src/domain/fundamentals.js';
import { MockLLMProvider } from '../../src/providers/llm/mock/MockLLMProvider.js';
import type { EmbeddingResult } from '../../src/providers/llm/types.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { EmbeddingRepository } from '../../src/repositories/EmbeddingRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { LlmCallRepository } from '../../src/repositories/LlmCallRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { EmbeddingService } from '../../src/services/rag/EmbeddingService.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { newsArticle } from '../fixtures/ragArticles.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});

class CountingProvider extends MockLLMProvider {
  calls: string[][] = [];
  failWith: AppError | null = null;
  override async embed(texts: readonly string[]): Promise<EmbeddingResult> {
    this.calls.push([...texts]);
    if (this.failWith) throw this.failWith;
    return super.embed(texts);
  }
}

async function seed(trx: Database) {
  await isolateTables(trx, 'document_embeddings', 'news', 'financial_statements', 'llm_calls');
  const stocks = new StockRepository(trx);
  const rel = (await stocks.findBySymbol('RELIANCE'))?.id ?? '';
  const tcs = (await stocks.findBySymbol('TCS'))?.id ?? '';
  const nifty = (await new MarketRepository(trx).findBySymbol('NIFTY50'))?.id ?? '';
  const news = new NewsRepository(trx);
  const a = newsArticle('Reliance and TCS sign cloud deal', 'https://example.com/a');
  const { ids } = await news.saveArticles([
    a,
    newsArticle('Sensex ends flat', 'https://example.com/b'),
    // Syndicated copy: same text, other URL → same chunk hash → vector reused.
    {
      ...newsArticle('Reliance and TCS sign cloud deal', 'https://other.example/a'),
      source: 'other.example',
    },
    newsArticle('TCS mentioned in passing', 'https://example.com/e'),
  ]);
  const [ia, ib, id, ie] = ids.map((x) => x ?? '');
  await news.saveMentions([
    { newsId: ia ?? '', ref: { kind: 'stock', id: rel }, relevance: 0.9, matchedBy: 'name:title' },
    { newsId: ia ?? '', ref: { kind: 'stock', id: tcs }, relevance: 0.8, matchedBy: 'name:title' },
    {
      newsId: ib ?? '',
      ref: { kind: 'market', id: nifty },
      relevance: 0.9,
      matchedBy: 'alias:title',
    },
    { newsId: id ?? '', ref: { kind: 'stock', id: rel }, relevance: 0.7, matchedBy: 'name:title' },
    { newsId: ie ?? '', ref: { kind: 'stock', id: tcs }, relevance: 0.4, matchedBy: 'query' },
  ]);
  const statement = (periodEnd: string, revenue: number) => ({
    stockId: rel,
    dataMode: 'MOCK' as const,
    periodType: 'QUARTERLY' as const,
    periodEnd,
    source: 'mock',
    metrics: { ...emptyStatementMetrics(), revenue, netProfit: revenue / 10 },
    raw: {},
  });
  await new FundamentalsRepository(trx).upsertStatements([
    statement('2025-06-30', 2_000_000_000_000),
    statement('2026-06-30', 2_200_000_000_000),
  ]);
  return { rel, tcs, ib: ib ?? '', statement };
}

function service(trx: Database, provider = new CountingProvider(), batchSize?: number) {
  return new EmbeddingService({
    provider,
    embeddings: new EmbeddingRepository(trx),
    llmCalls: new LlmCallRepository(trx),
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    settings: new AppSettingsRepository(trx),
    systemLogs: new SystemLogRepository(trx),
    dataMode: 'MOCK',
    logger: silent,
    usdInrRate: 88,
    retry: { sleep: async () => undefined },
    ...(batchSize === undefined ? {} : { batchSize }),
  });
}

const rowsFor = (trx: Database) =>
  trx
    .selectFrom('document_embeddings')
    .select(['source_type', 'source_id', 'stock_id', 'content'])
    .execute();

describe('EmbeddingService', () => {
  it('embeds each unique text once, writes one row per (document, target), records the call and logs the run', async () => {
    await withRollback(db, async (trx) => {
      const { rel, tcs } = await seed(trx);
      const provider = new CountingProvider();
      const r = await service(trx, provider).run({ jobName: 'test' });
      expect(r).toMatchObject({
        status: 'SUCCESS',
        model: 'mock-hash-embedding-v1',
        documents: { planned: 5, written: 5, failed: 0 },
        chunks: { unique: 4, reused: 0, embedded: 4 },
        rowsWritten: 6,
        estCostInr: 0,
      });
      expect(provider.calls.flat()).toHaveLength(4);
      const rows = await rowsFor(trx);
      expect(rows.filter((x) => x.stock_id === tcs).map((x) => x.content)).toEqual([
        expect.stringContaining('Reliance and TCS sign cloud deal'),
      ]);
      expect(rows.filter((x) => x.source_type === 'FINANCIALS' && x.stock_id === rel)).toHaveLength(
        2,
      );
      expect(rows.filter((x) => x.stock_id === null)).toHaveLength(1); // Sensex (market mention 0.9)
      expect(rows.some((x) => x.content.includes('TCS mentioned in passing'))).toBe(false); // query-only match: not embedded
      const fin = rows.find(
        (x) => x.source_type === 'FINANCIALS' && x.content.includes('30 Jun 2026'),
      );
      expect(fin?.content).toContain('(+10.00% YoY');
      const calls = await trx.selectFrom('llm_calls').selectAll().execute();
      expect(calls).toHaveLength(1);
      expect(calls[0]).toMatchObject({ purpose: 'embeddings', provider: 'mock', status: 'OK' });
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({ id: r.runId, status: 'SUCCESS', recordsInserted: 6 });
    });
  });

  it('is idempotent on re-run and only re-embeds a restated statement', async () => {
    await withRollback(db, async (trx) => {
      const { statement } = await seed(trx);
      await service(trx).run({ jobName: 'test' });
      const provider = new CountingProvider();
      const again = await service(trx, provider).run({ jobName: 'test' });
      expect(again).toMatchObject({ status: 'SUCCESS', documents: { planned: 0 }, rowsWritten: 0 });
      expect(provider.calls).toHaveLength(0);

      await new FundamentalsRepository(trx).upsertStatements([
        statement('2026-06-30', 2_400_000_000_000),
      ]);
      const restated = await service(trx, provider).run({
        jobName: 'test',
        sources: ['FINANCIALS'],
      });
      expect(restated).toMatchObject({
        documents: { planned: 1, written: 1 },
        chunks: { embedded: 1 },
      });
      const fin = (await rowsFor(trx)).filter((x) => x.source_type === 'FINANCIALS');
      expect(fin).toHaveLength(2);
      expect(fin.some((x) => x.content.includes('(+20.00% YoY'))).toBe(true);
    });
  });

  it('adds a row when a stock mention arrives later and drops the market-level placeholder (no re-embed)', async () => {
    await withRollback(db, async (trx) => {
      const { tcs, ib } = await seed(trx);
      await service(trx).run({ jobName: 'test' });
      await new NewsRepository(trx).saveMentions([
        { newsId: ib, ref: { kind: 'stock', id: tcs }, relevance: 0.9, matchedBy: 'name:title' },
      ]);
      const provider = new CountingProvider();
      const r = await service(trx, provider).run({ jobName: 'test', sources: ['NEWS'] });
      expect(r).toMatchObject({
        documents: { planned: 1, written: 1 },
        chunks: { reused: 1, embedded: 0 },
      });
      expect(provider.calls).toHaveLength(0);
      const forB = (await rowsFor(trx)).filter((x) => x.source_id === ib);
      expect(forB.map((x) => x.stock_id)).toEqual([tcs]);
    });
  });

  it('stops after an auth failure: no further batches, FAILED run, FAILED llm_calls row, nothing written', async () => {
    await withRollback(db, async (trx) => {
      await seed(trx);
      const provider = new CountingProvider();
      provider.failWith = new AppError('AUTH_FAILED', 'OpenAI quota exhausted');
      const r = await service(trx, provider, 2).run({ jobName: 'test' });
      expect(r.status).toBe('FAILED');
      expect(provider.calls).toHaveLength(1);
      expect(r.failures).toHaveLength(5);
      expect(r.failures[0]).toMatchObject({ code: 'AUTH_FAILED' });
      expect(r.notes.join(' ')).toMatch(/aborted/);
      expect(await rowsFor(trx)).toEqual([]);
      const calls = await trx.selectFrom('llm_calls').select(['status', 'error']).execute();
      expect(calls).toEqual([{ status: 'FAILED', error: 'AUTH_FAILED: OpenAI quota exhausted' }]);
    });
  });

  it('honours the per-run document cap with a note', async () => {
    await withRollback(db, async (trx) => {
      await seed(trx);
      const r = await service(trx).run({ jobName: 'test', maxDocuments: 2 });
      expect(r.documents.planned).toBe(2);
      expect(r.notes.join(' ')).toMatch(/document cap reached: 2/);
    });
  });

  it('stops before any paid call when the budget refuses, without a second FAILED row', async () => {
    await withRollback(db, async (trx) => {
      await seed(trx);
      const provider = new CountingProvider();
      const refusals: string[] = [];
      const budget = {
        ensure: async (_estimate: number, call: { purpose: string }) => {
          refusals.push(call.purpose);
          throw new AppError('BUDGET_EXCEEDED', 'Daily LLM budget reached');
        },
      };
      const r = await new EmbeddingService({
        provider,
        embeddings: new EmbeddingRepository(trx),
        llmCalls: new LlmCallRepository(trx),
        stocks: new StockRepository(trx),
        fundamentals: new FundamentalsRepository(trx),
        settings: new AppSettingsRepository(trx),
        systemLogs: new SystemLogRepository(trx),
        dataMode: 'MOCK',
        logger: silent,
        usdInrRate: 88,
        budget,
        batchSize: 2,
      }).run({ jobName: 'test' });
      expect(provider.calls).toHaveLength(0);
      expect(refusals).toEqual(['embeddings']);
      expect(r.status).toBe('FAILED');
      expect(r.notes.join(' ')).toMatch(/aborted after BUDGET_EXCEEDED/);
      expect(await trx.selectFrom('llm_calls').select('status').execute()).toEqual([]);
    });
  });
});
