import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { limit } from '../../src/http/rateLimit.js';
import type { Database } from '../../src/database/db.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long';
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const db = createTestDb();

const sign = (sub: string) =>
  new SignJWT({ sub, role: 'authenticated' })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuer(ISSUER)
    .setAudience('authenticated')
    .setIssuedAt()
    .setExpirationTime('1h')
    .sign(new TextEncoder().encode(SECRET));

async function seedOwner(trx: Database): Promise<string> {
  const id = randomUUID();
  await sql`
    insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)
    values (${id}::uuid, '00000000-0000-0000-0000-000000000000'::uuid, 'authenticated',
            'authenticated', ${`${id}@example.com`}, 'x', now(), now())
  `.execute(trx);
  await trx.updateTable('user_profiles').set({ role: 'OWNER' }).where('user_id', '=', id).execute();
  return id;
}

async function appOver(trx: Database, env: Record<string, string>) {
  const container = createContainer(loadConfig(env), { db: trx, logger: silentLogger });
  // extraRoutes: hooks are encapsulated per scope, so probe routes must be registered inside the
  // authenticated scope to see the auth preHandler (and therefore request.user).
  const app = await buildApp(container, {
    extraRoutes: (api) => {
      api.get('/_probe/read', { config: { rateLimit: limit('reads') } }, async () => ({
        data: 'ok',
      }));
      api.post('/_probe/tight', { config: { rateLimit: limit('ai.regenerate') } }, async () => ({
        data: 'ok',
      }));
    },
  });
  await app.ready();
  return app;
}

describe('http plugins', () => {
  it('sets security headers and restricts CORS to the configured origin', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none', CORS_ORIGIN: 'http://127.0.0.1:3000' });
      const r = await app.inject({ method: 'GET', url: '/api/_probe/read' });
      expect(r.headers['x-content-type-options']).toBe('nosniff');

      const allowed = await app.inject({
        method: 'OPTIONS',
        url: '/api/_probe/read',
        headers: { origin: 'http://127.0.0.1:3000', 'access-control-request-method': 'GET' },
      });
      expect(allowed.headers['access-control-allow-origin']).toBe('http://127.0.0.1:3000');

      const refused = await app.inject({
        method: 'OPTIONS',
        url: '/api/_probe/read',
        headers: { origin: 'https://evil.example.com', 'access-control-request-method': 'GET' },
      });
      expect(refused.headers['access-control-allow-origin']).toBeUndefined();
    });
  });

  it('enforces a per-route limit and returns our error envelope with Retry-After', async () => {
    // Sequential, never Promise.all: parallel inject miscounts the limiter (measured — 5
    // concurrent injects against max 3 gave five 429s, while real HTTP gave 200,200,200,429,429),
    // so a parallel assertion here would test the harness, not the limit.
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none' });
      const hit = () => app.inject({ method: 'POST', url: '/api/_probe/tight', payload: {} });
      const codes: number[] = [];
      for (let i = 0; i < 6; i += 1) codes.push((await hit()).statusCode);
      // ai.regenerate is 5/hour, so the first five pass and the sixth is refused.
      expect(codes.slice(0, 5)).toEqual([200, 200, 200, 200, 200]);
      const last = codes.at(-1);
      expect(last).toBe(429);
      const refused = await hit();
      expect(refused.json()).toMatchObject({ error: { code: 'RATE_LIMITED' } });
      expect(refused.headers['retry-after']).toBeDefined();
    });
  });

  it('keys the limit on the user, so one caller cannot exhaust another from the same IP', async () => {
    // THE regression test for Review Focus 2. Measured against 11.2.0: with the limiter on its
    // default onRequest hook the keyGenerator sees no user, so both tokens share the IP bucket
    // and user B gets 429. Two real users are required — under AUTH_MODE=none there is only one,
    // and inject always reports the same IP, so a single-user version of this test is vacuous.
    await withRollback(db, async (trx) => {
      const a = await seedOwner(trx);
      const b = await seedOwner(trx);
      const app = await appOver(trx, {
        AUTH_MODE: 'jwt',
        JWT_SECRET: SECRET,
        SUPABASE_URL: 'http://127.0.0.1:54321',
      });
      const hit = async (id: string) =>
        (
          await app.inject({
            method: 'POST',
            url: '/api/_probe/tight',
            payload: {},
            headers: { authorization: `Bearer ${await sign(id)}` },
          })
        ).statusCode;

      for (let i = 0; i < 5; i += 1) expect(await hit(a)).toBe(200);
      expect(await hit(a)).toBe(429); // user A is spent
      expect(await hit(b)).toBe(200); // user B is untouched
    });
  });

  it('leaves an unknown route as a 404 in our envelope', async () => {
    await withRollback(db, async (trx) => {
      const app = await appOver(trx, { AUTH_MODE: 'none' });
      const r = await app.inject({ method: 'GET', url: '/api/nope' });
      expect(r.statusCode).toBe(404);
      expect(r.json()).toMatchObject({ error: { code: 'NOT_FOUND' } });
    });
  });
});
