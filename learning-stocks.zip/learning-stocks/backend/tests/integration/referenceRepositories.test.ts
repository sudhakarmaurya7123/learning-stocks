import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { z } from 'zod';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('StockRepository', () => {
  const repo = new StockRepository(db);

  it('lists the 20 seeded active stocks ordered by symbol', async () => {
    const stocks = await repo.listActive();
    expect(stocks).toHaveLength(20);
    expect(stocks[0]?.symbol).toBe('ADANIENT');
    expect(stocks.every((s) => s.currency === 'INR')).toBe(true);
  });

  it('finds by symbol case-insensitively and returns null for unknown symbols', async () => {
    const rel = await repo.findBySymbol('reliance');
    expect(rel).toMatchObject({
      symbol: 'RELIANCE',
      exchange: 'NSE',
      isin: 'INE002A01018',
      isinVerified: true,
    });
    expect(await repo.findBySymbol('NOSUCH')).toBeNull();
  });

  it('searches by symbol prefix, company name and ISIN with exact symbol first', async () => {
    expect((await repo.search('TCS'))[0]?.symbol).toBe('TCS');
    expect((await repo.search('mahindra')).map((s) => s.symbol)).toContain('KOTAKBANK');
    expect((await repo.search('INE009A01021')).map((s) => s.symbol)).toEqual(['INFY']);
    expect(await repo.search('%')).toEqual([]);
  });

  it('lists stocks with their provider symbol', async () => {
    const yahoo = await repo.listWithProviderSymbol('yahoo');
    expect(yahoo).toHaveLength(20);
    expect(yahoo.find((p) => p.instrument.symbol === 'RELIANCE')).toMatchObject({
      providerSymbol: 'RELIANCE.NS',
      // runtime state: `pnpm verify:symbols` flips it, so assert the type, not the value
      verified: expect.any(Boolean),
    });
  });

  it('excludes inactive stocks', async () => {
    await withRollback(db, async (trx) => {
      await trx
        .updateTable('stocks')
        .set({ is_active: false })
        .where('symbol', '=', 'ITC')
        .execute();
      const scoped = new StockRepository(trx);
      expect((await scoped.listActive()).map((s) => s.symbol)).not.toContain('ITC');
      expect(await scoped.listWithProviderSymbol('mock')).toHaveLength(19);
    });
  });

  it('exposes aliases for news matching (empty array when none)', async () => {
    expect((await repo.findBySymbol('LT'))?.aliases).toEqual(['L&T', 'Larsen and Toubro']);
    expect((await repo.findBySymbol('INFY'))?.aliases).toEqual([]);
    expect((await new MarketRepository(db).findBySymbol('NIFTY50'))?.aliases).toContain('Nifty');
  });
});

describe('MarketRepository', () => {
  const repo = new MarketRepository(db);
  it('lists the 12 markets and maps yahoo index symbols', async () => {
    expect(await repo.listActive()).toHaveLength(12);
    expect(await repo.findBySymbol('NIFTY50')).toMatchObject({
      name: 'NIFTY 50',
      marketType: 'BROAD_INDEX',
    });
    const yahoo = await repo.listWithProviderSymbol('yahoo');
    expect(yahoo.find((p) => p.instrument.symbol === 'INDIAVIX')?.providerSymbol).toBe('^INDIAVIX');
  });
});

describe('HolidayRepository', () => {
  it('returns EQUITY holidays in an inclusive date window as plain dates', async () => {
    const list = await new HolidayRepository(db).listBetween('NSE', '2026-10-01', '2026-10-31');
    expect(list.map((h) => h.date)).toEqual(['2026-10-02', '2026-10-20']);
    expect(list[0]).toMatchObject({ exchange: 'NSE', specialOpen: null, specialClose: null });
  });
});

describe('AppSettingsRepository', () => {
  const repo = new AppSettingsRepository(db);
  it('returns typed values, null for missing keys, and rejects malformed values', async () => {
    expect(await repo.get('paper_initial_balance', z.number())).toBe(1_000_000);
    expect(await repo.get('auto_paper_trade', z.boolean())).toBe(false);
    expect(await repo.get('no_such_key', z.number())).toBeNull();
    await withRollback(db, async (trx) => {
      await trx
        .insertInto('app_settings')
        .values({ key: 'zz_bad', value: sql`'"text"'::jsonb` })
        .execute();
      await expect(new AppSettingsRepository(trx).get('zz_bad', z.number())).rejects.toMatchObject({
        code: 'INTERNAL',
      });
    });
  });
});
