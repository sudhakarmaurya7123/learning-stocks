import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { MarketSummaryRepository } from '../../src/repositories/MarketSummaryRepository.js';
import { NewsAnalysisRepository } from '../../src/repositories/NewsAnalysisRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { MarketSummaryService } from '../../src/services/ai/MarketSummaryService.js';
import { parseEvaluationInputs } from '../../src/services/rag/StockContextService.js';
import { vixRiskLevel } from '../../src/ai/marketContext.js';
import { aiDeps, NOW, seedPipeline, silent } from './aiFixtures.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

function service(trx: Database) {
  const d = aiDeps(trx, NOW);
  return new MarketSummaryService({
    markets: new MarketRepository(trx),
    stocks: new StockRepository(trx),
    marketData: new MarketDataRepository(trx),
    evaluations: new EvaluationRepository(trx),
    newsAnalyses: new NewsAnalysisRepository(trx),
    summaries: new MarketSummaryRepository(trx),
    retriever: d.retriever,
    gateway: d.gateway,
    systemLogs: new SystemLogRepository(trx),
    dataMode: 'MOCK',
    logger: silent,
    now: () => NOW,
  });
}

describe('MarketSummaryService', () => {
  it('generates a summary whose regime, trend and risk level come from code, then serves the cache', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seedPipeline(trx);
      const r = await service(trx).run({ jobName: 'test' });
      expect(r).toMatchObject({ status: 'SUCCESS', outcome: 'GENERATED' });
      const ev = await new EvaluationRepository(trx).latestDetail(rel, 'MOCK');
      const view = parseEvaluationInputs(ev?.inputs);
      const row = await trx.selectFrom('market_ai_summary').selectAll().executeTakeFirstOrThrow();
      expect(row).toMatchObject({
        regime: view.market?.regime ?? null,
        trend: view.market?.niftyTrend ?? null,
        risk_level: vixRiskLevel(view.market?.vix ?? null),
        prompt_version: 'market_analysis_v1',
      });
      expect(row.summary).toContain('[MOCK]');
      expect((await service(trx).run({ jobName: 'test' })).outcome).toBe('CACHED');
      expect(
        await trx
          .selectFrom('llm_calls')
          .select('purpose')
          .where('purpose', '=', 'market_summary')
          .execute(),
      ).toHaveLength(1);
    });
  });

  it('reports INSUFFICIENT_DATA without a model call when nothing is evaluated', async () => {
    await withRollback(db, async (trx) => {
      await seedPipeline(trx);
      await trx.deleteFrom('stock_evaluations').execute();
      const r = await service(trx).run({ jobName: 'test' });
      expect(r).toMatchObject({ outcome: 'INSUFFICIENT_DATA', status: 'SKIPPED' });
      expect(
        await trx
          .selectFrom('llm_calls')
          .select('purpose')
          .where('purpose', '=', 'market_summary')
          .execute(),
      ).toEqual([]);
    });
  });
});
