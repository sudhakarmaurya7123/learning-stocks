import { afterAll, describe, expect, it } from 'vitest';
import { loadConfig } from '../../src/config/env.js';
import { type Container, createContainer } from '../../src/container.js';
import { createRegistry } from '../../src/jobs/registry.js';
import { runJob } from '../../src/jobs/runJob.js';
import type { JobName, JobPayload, JobQueue } from '../../src/jobs/types.js';
import { createTestDb, isolateTables, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

/**
 * The container is built over the test transaction, so every write this file makes is rolled
 * back. Building it on the real pool would leave bars, sentiment, analyses and signals in the
 * developer's database on every `pnpm test` — the same leak that broke a Phase 5 test in Phase 7.
 */
const withJobs = (
  fn: (ctx: { registry: ReturnType<typeof createRegistry>; container: Container }) => Promise<void>,
) =>
  withRollback(db, async (trx) => {
    const container = createContainer(loadConfig({}), { db: trx, logger: silentLogger });
    await fn({ registry: createRegistry(container), container });
    // No container.close(): the transaction owns the connection and withRollback releases it.
  });

function recordingQueue() {
  const sent: Array<{ name: JobName; data: JobPayload | undefined }> = [];
  const queue: JobQueue = {
    start: async () => undefined,
    stop: async () => undefined,
    ensureQueues: async () => undefined,
    applySchedules: async () => undefined,
    work: async () => undefined,
    enqueue: async (name, data) => {
      sent.push({ name, data });
      return 'id';
    },
  };
  return { queue, sent };
}

const run = async (
  ctx: { registry: ReturnType<typeof createRegistry>; container: Container },
  name: JobName,
  payload: JobPayload,
  now: Date,
) => {
  const { queue, sent } = recordingQueue();
  const outcome = await runJob({
    definition: ctx.registry[name],
    payload,
    queue,
    systemLogs: ctx.container.repositories.systemLogs,
    logger: silentLogger,
    now: () => now,
  });
  return { outcome, chained: sent.map((s) => s.name) };
};

// A Tuesday inside the session, and the same day after the close.
const IN_SESSION = new Date('2026-10-06T06:00:00Z');
const AFTER_CLOSE = new Date('2026-10-06T10:35:00Z');

describe('job handlers (MOCK mode, real services)', () => {
  it('evaluation.compute chains AI analysis only from the EOD origin', async () => {
    await withJobs(async (ctx) => {
      const eod = await run(ctx, 'evaluation.compute', { origin: 'eod' }, AFTER_CLOSE);
      expect(eod.outcome.status).not.toBe('FAILED');
      expect(eod.chained).toEqual(['ai.stock.analyze']);

      const intraday = await run(ctx, 'evaluation.compute', { origin: 'intraday' }, IN_SESSION);
      expect(intraday.outcome.status).not.toBe('FAILED');
      expect(intraday.chained).toEqual([]);
    });
  });

  it('market.sync.intraday stores bars and chains evaluation tagged intraday', async () => {
    await withJobs(async (ctx) => {
      const { queue, sent } = recordingQueue();
      const outcome = await runJob({
        definition: ctx.registry['market.sync.intraday'],
        payload: {},
        queue,
        systemLogs: ctx.container.repositories.systemLogs,
        logger: silentLogger,
        now: () => IN_SESSION,
      });
      expect(outcome.status).not.toBe('FAILED');
      expect(sent).toEqual([{ name: 'evaluation.compute', data: { origin: 'intraday' } }]);
    });
  });

  it('market.sync.intraday is skipped outside the session, logs a SKIPPED row and chains nothing', async () => {
    await withJobs(async (ctx) => {
      await isolateTables(ctx.container.db, 'system_logs');
      // 2026-10-06T12:00:00Z = 17:30 IST, well after the close.
      const r = await run(ctx, 'market.sync.intraday', {}, new Date('2026-10-06T12:00:00Z'));
      expect(r.outcome.status).toBe('SKIPPED');
      expect(r.chained).toEqual([]);
      const [row] = await ctx.container.repositories.systemLogs.recentRuns(1);
      expect(row).toMatchObject({ jobName: 'market.sync.intraday', status: 'SKIPPED' });
    });
  });

  it('news.sync chains embeddings, which chains sentiment', async () => {
    await withJobs(async (ctx) => {
      expect((await run(ctx, 'news.sync', {}, IN_SESSION)).chained).toEqual([
        'embeddings.generate',
      ]);
      expect((await run(ctx, 'embeddings.generate', {}, IN_SESSION)).chained).toEqual([
        'news.sentiment',
      ]);
    });
  });

  it('signals.expire runs with no service of its own and logs its own row', async () => {
    await withJobs(async (ctx) => {
      await isolateTables(ctx.container.db, 'system_logs');
      const r = await run(ctx, 'signals.expire', {}, IN_SESSION);
      expect(r.outcome.status).toBe('SUCCESS');
      expect(r.outcome.runId).toBeNull();
      expect(r.chained).toEqual([]);
      const [row] = await ctx.container.repositories.systemLogs.recentRuns(1);
      expect(row).toMatchObject({ jobName: 'signals.expire', status: 'SUCCESS' });
    });
  });

  it('holidays.check warns when next year has no calendar', async () => {
    await withJobs(async (ctx) => {
      const r = await run(ctx, 'holidays.check', {}, new Date('2026-12-07T06:00:00Z'));
      // Only 2026 is seeded, so this must be a visible warning, not a silent success.
      expect(r.outcome.status).toBe('PARTIAL');
      expect(r.outcome.message).toMatch(/2027/);
    });
  });

  it('holidays.check reads the IST year across the UTC new-year boundary', async () => {
    await withJobs(async (ctx) => {
      // 2026-12-31T19:00:00Z is already 2027-01-01 in IST. A UTC-dated check would ask about
      // 2026 (seeded) and report the current year present on the day it ran out.
      const r = await run(ctx, 'holidays.check', {}, new Date('2026-12-31T19:00:00Z'));
      expect(r.outcome.status).toBe('PARTIAL');
      expect(r.outcome.message).toMatch(/2027/);
      expect(r.outcome.message).toMatch(/2028/);
    });
  });

  it('never enqueues a paper order from any job', async () => {
    await withJobs(async (ctx) => {
      const names = new Set<string>();
      for (const name of Object.keys(ctx.registry) as JobName[]) {
        const { queue, sent } = recordingQueue();
        await runJob({
          definition: ctx.registry[name],
          payload: { origin: 'eod' },
          queue,
          systemLogs: ctx.container.repositories.systemLogs,
          logger: silentLogger,
          now: () => AFTER_CLOSE,
        }).catch(() => undefined);
        for (const s of sent) names.add(s.name);
      }
      expect([...names].some((n) => /order|trade\.execute/.test(n))).toBe(false);
    });
  });
});
