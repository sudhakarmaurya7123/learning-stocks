import { sql } from 'kysely';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { PgBossQueue } from '../../src/jobs/PgBossQueue.js';
import type { JobName } from '../../src/jobs/types.js';
import { createTestDb, LOCAL_DATABASE_URL, silentLogger } from './helpers.js';

// Its own throwaway schema: this file must never touch a developer's running worker.
const SCHEMA = 'pgboss_test_queue';
const db = createTestDb();
const queue = new PgBossQueue({
  connectionString: process.env.DATABASE_URL ?? LOCAL_DATABASE_URL,
  schema: SCHEMA,
  logger: silentLogger,
  tz: 'Asia/Kolkata',
});

beforeAll(async () => {
  await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
  await queue.start();
});
afterAll(async () => {
  await queue.stop();
  await sql`drop schema if exists ${sql.id(SCHEMA)} cascade`.execute(db);
  await db.destroy();
});

const NAMES: readonly JobName[] = ['news.sync', 'evaluation.compute'];

describe('PgBossQueue', () => {
  it('installs its own schema on start (supabase db reset drops it)', async () => {
    const r = await sql<{ n: number }>`
      select count(*)::int as n from information_schema.tables where table_schema = ${SCHEMA}
    `.execute(db);
    expect(r.rows[0]?.n ?? 0).toBeGreaterThan(0);
  });

  it('enqueues a job and reports null for a duplicate under the same singleton key', async () => {
    await queue.ensureQueues(NAMES);
    const first = await queue.enqueue('news.sync', { origin: 'test' }, { singletonKey: 'k' });
    const second = await queue.enqueue('news.sync', { origin: 'test' }, { singletonKey: 'k' });
    expect(first).not.toBeNull();
    expect(second).toBeNull();
  });

  it('is safe to call ensureQueues twice (every worker restart does)', async () => {
    await queue.ensureQueues(NAMES);
    await expect(queue.ensureQueues(NAMES)).resolves.toBeUndefined();
  });

  it('delivers an enqueued payload to the worker', async () => {
    await queue.ensureQueues(NAMES);
    const seen: unknown[] = [];
    await queue.work('evaluation.compute', async (payload) => {
      seen.push(payload);
    });
    await queue.enqueue('evaluation.compute', { origin: 'eod' });
    await vi.waitUntil(() => seen.length > 0, { timeout: 10_000 });
    expect(seen).toEqual([{ origin: 'eod' }]);
  });

  it('applies schedules in IST and updates a changed cron in place', async () => {
    await queue.ensureQueues(NAMES);
    await queue.applySchedules([{ name: 'news.sync', cron: '*/10 * * * *', missed: 'skip' }]);
    await queue.applySchedules([{ name: 'news.sync', cron: '*/15 * * * *', missed: 'skip' }]);
    const rows = await sql<{ cron: string; timezone: string }>`
      select cron, timezone from ${sql.id(SCHEMA)}.schedule where name = 'news.sync'
    `.execute(db);
    expect(rows.rows).toEqual([{ cron: '*/15 * * * *', timezone: 'Asia/Kolkata' }]);
  });

  it('removes a schedule that is no longer in the table', async () => {
    await queue.ensureQueues(NAMES);
    await queue.applySchedules([{ name: 'news.sync', cron: '*/10 * * * *', missed: 'skip' }]);
    await queue.applySchedules([
      { name: 'evaluation.compute', cron: '0 18 * * *', missed: 'once' },
    ]);
    const rows = await sql<{ name: string }>`
      select name from ${sql.id(SCHEMA)}.schedule order by name
    `.execute(db);
    expect(rows.rows.map((r) => r.name)).toEqual(['evaluation.compute']);
  });
});
