import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { ACTION_STATES } from '../../src/domain/enums.js';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { PaperPositionRepository } from '../../src/repositories/PaperPositionRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { ScoringConfigRepository } from '../../src/repositories/ScoringConfigRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { TechnicalIndicatorRepository } from '../../src/repositories/TechnicalIndicatorRepository.js';
import { EvaluationService } from '../../src/services/EvaluationService.js';
import { FundamentalsService } from '../../src/services/fundamentals/FundamentalsService.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MarketDataService } from '../../src/services/marketData/MarketDataService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
const NOW = new Date('2026-10-05T12:00:00Z'); // Monday 17:30 IST, after close + settle
const SYMBOLS = [
  'RELIANCE',
  'HDFCBANK',
  'NIFTY50',
  'INDIAVIX',
  'BANKNIFTY',
  'NIFTYFINSERVICE',
  'NIFTYENERGY',
];

async function seed(trx: Database) {
  await isolateTables(
    trx,
    'market_data',
    'technical_indicators',
    'stock_evaluations',
    'fundamental_snapshots',
    'financial_statements',
    // Stored news sentiment puts the news-decay date into the hash; these tests assume none.
    'news',
  );
  const sessions = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());
  const provider = new MockMarketDataProvider(sessions, () => NOW);
  const logs = new SystemLogRepository(trx);
  await new MarketDataService({
    provider,
    sessions,
    dataMode: 'MOCK',
    logger: silent,
    now: () => NOW,
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    systemLogs: logs,
  }).sync({
    jobName: 'seed',
    timeframe: '1d',
    from: new Date(NOW.getTime() - 420 * 86_400_000),
    to: NOW,
    symbols: SYMBOLS,
  });
  await new FundamentalsService({
    provider: new MockFundamentalsProvider(
      async (ref) => (await provider.getQuote(ref)).price,
      () => NOW,
    ),
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    systemLogs: logs,
    dataMode: 'MOCK',
    logger: silent,
    now: () => NOW,
  }).sync({ jobName: 'seed', symbols: ['RELIANCE', 'HDFCBANK'] });
  return sessions;
}

function service(trx: Database, sessions: MarketCalendarService, now: Date, historyDays?: number) {
  return new EvaluationService({
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    news: new NewsRepository(trx),
    positions: new PaperPositionRepository(trx),
    configs: new ScoringConfigRepository(trx),
    settings: new AppSettingsRepository(trx),
    evaluations: new EvaluationRepository(trx),
    indicators: new TechnicalIndicatorRepository(trx),
    systemLogs: new SystemLogRepository(trx),
    sessions,
    dataMode: 'MOCK',
    logger: silent,
    now: () => now,
    ...(historyDays === undefined ? {} : { historyDays }),
  });
}

describe('EvaluationService', () => {
  it('evaluates stocks end to end, stores indicators and evaluations, and is idempotent', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      const first = await service(trx, sessions, NOW).run({
        jobName: 'test',
        symbols: ['RELIANCE', 'HDFCBANK'],
      });
      expect(first).toMatchObject({
        status: 'SUCCESS',
        configVersion: 'v1',
        stocks: { total: 2, succeeded: 2, failed: 0 },
        evaluations: { inserted: 2, unchanged: 0 },
      });
      expect(first.regime).not.toBeNull();
      expect(first.indicatorRows).toBeGreaterThan(500);
      for (const s of first.summaries) {
        expect(ACTION_STATES).toContain(s.actionState);
        expect(s.actionState).not.toBe('INSUFFICIENT_DATA');
        expect(s.invalidation).toMatch(/₹/);
      }
      const stockId = (await new StockRepository(trx).findBySymbol('RELIANCE'))?.id ?? '';
      expect(await new EvaluationRepository(trx).latest(stockId, 'MOCK')).toMatchObject({
        scoringConfigVersion: 'v1',
        dataAsOf: new Date('2026-10-05T03:45:00Z'),
      });
      expect(
        (await new TechnicalIndicatorRepository(trx).latest(stockId, 'MOCK', '1d'))?.values.sma200,
      ).not.toBeNull();

      const again = await service(trx, sessions, NOW).run({
        jobName: 'test',
        symbols: ['RELIANCE', 'HDFCBANK'],
      });
      expect(again.evaluations).toEqual({ inserted: 0, unchanged: 2 });
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({
        id: again.runId,
        operation: 'evaluate',
        status: 'SUCCESS',
        recordsFetched: 2,
        recordsInserted: 0,
        recordsSkipped: 2,
      });
    });
  });

  it('keeps the same input hash when the clock moves but no new bar arrived (window anchored to the last bar)', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      // A 300-day window cuts into the 420-day seed, so a wall-clock-anchored window would drop a bar tomorrow.
      const first = await service(trx, sessions, NOW, 300).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(first.evaluations.inserted).toBe(1);
      const nextDay = await service(trx, sessions, new Date(NOW.getTime() + 86_400_000), 300).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(nextDay.evaluations).toEqual({ inserted: 0, unchanged: 1 });
    });
  });

  it('never gives a buy view on stale or missing data', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      const later = new Date(NOW.getTime() + 10 * 86_400_000);
      const stale = await service(trx, sessions, later).run({
        jobName: 'test',
        symbols: ['RELIANCE', 'TCS'],
      });
      expect(stale.status).toBe('SUCCESS');
      const bySymbol = Object.fromEntries(stale.summaries.map((s) => [s.symbol, s]));
      expect(bySymbol.RELIANCE).toMatchObject({ actionState: 'INSUFFICIENT_DATA', bias: null });
      expect(bySymbol.RELIANCE?.invalidation).toMatch(/stale/);
      expect(bySymbol.TCS).toMatchObject({ actionState: 'INSUFFICIENT_DATA', price: null });
    });
  });

  it('notes unknown symbols and fails the run when nothing can be evaluated', async () => {
    await withRollback(db, async (trx) => {
      const sessions = await seed(trx);
      const r = await service(trx, sessions, NOW).run({ jobName: 'test', symbols: ['NOSUCH'] });
      expect(r.status).toBe('FAILED');
      expect(r.notes.join(' ')).toMatch(/NOSUCH/);
    });
  });
});
