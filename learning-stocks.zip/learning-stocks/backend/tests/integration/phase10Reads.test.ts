import { createHash, randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { Database } from '../../src/database/db.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { createTestDb, isolateTables, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

/**
 * `jobQueue: null` and an explicit close, for the same reason as contract.test.ts: /system-status
 * resolves worker liveness by starting a real pg-boss, which would leak a pool per call.
 */
async function get(
  url: string,
  seed?: (trx: Database) => Promise<void>,
): Promise<{ status: number; data: unknown }> {
  let out: { status: number; data: unknown } | undefined;
  await withRollback(db, async (trx) => {
    await seed?.(trx);
    const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
      db: trx,
      logger: silentLogger,
      jobQueue: null,
    });
    const app = await buildApp(container);
    await app.ready();
    try {
      const res = await app.inject({ method: 'GET', url });
      const body = res.json() as { data?: unknown };
      out = { status: res.statusCode, data: body.data };
    } finally {
      await app.close();
      await container.close();
    }
  });
  if (out === undefined) throw new Error('no response captured');
  return out;
}

/** One article per stock in `symbols`, newest first, optionally with its AI sentiment row. */
async function seedNews(
  trx: Database,
  symbols: readonly string[],
  options: { withSentiment?: boolean } = {},
): Promise<void> {
  await isolateTables(trx, 'news_ai_analysis', 'news_mentions', 'news');
  const stocks = new StockRepository(trx);
  for (const [i, symbol] of symbols.entries()) {
    const stock = await stocks.findBySymbol(symbol);
    if (!stock) throw new Error(`seed precondition failed: no stock ${symbol}`);
    const newsId = randomUUID();
    // Descending published_at, so the newest-first ordering assertion is meaningful.
    const publishedAt = new Date(Date.UTC(2026, 9, 6, 12 - i, 0, 0));
    await trx
      .insertInto('news')
      .values({
        id: newsId,
        data_mode: 'MOCK',
        title: `[TEST] ${symbol} article`,
        description: `Body for ${symbol}`,
        source: 'test-news.invalid',
        source_url: `https://test-news.invalid/${symbol}/${newsId}`,
        published_at: publishedAt,
        // The column is constrained to ^[a-f0-9]{64}$ — a real sha256 digest, not a label.
        content_hash: createHash('sha256').update(newsId).digest('hex'),
      })
      .execute();
    await trx
      .insertInto('news_mentions')
      .values({
        news_id: newsId,
        stock_id: stock.id,
        relevance_score: '1',
        matched_by: 'SYMBOL',
      })
      .execute();
    if (options.withSentiment === true) {
      await trx
        .insertInto('news_ai_analysis')
        .values({
          news_id: newsId,
          stock_id: stock.id,
          sentiment: 'BULLISH',
          sentiment_score: '72',
          confidence: '60',
          relevance_score: '1',
          impact_level: 'HIGH',
          summary: `[TEST] ${symbol} sentiment summary`,
          positive_factors: sql`'[]'::jsonb`,
          negative_factors: sql`'[]'::jsonb`,
          reasoning: sql`'[]'::jsonb`,
          model: 'mock-chat-v1',
          prompt_version: 'v1',
        })
        .execute();
    }
  }
}

describe('GET /news (market-wide feed, PRD §3.1)', () => {
  it('returns the newest articles across every stock, newest first', async () => {
    // Seeded, not ambient: `length > 0` against whatever the dev worker last wrote is a pass that
    // proves nothing, and the suite must be green straight after `db:reset`.
    const { status, data } = await get('/api/news?limit=3', (trx) =>
      seedNews(trx, ['RELIANCE', 'TCS', 'INFY', 'WIPRO', 'SBIN']),
    );
    expect(status).toBe(200);
    const items = data as Array<{ published_at: string; linked_symbols: string[]; title: string }>;
    expect(items).toHaveLength(3);
    const times = items.map((i) => Date.parse(i.published_at));
    expect([...times].sort((a, b) => b - a)).toEqual(times);
    // PRD §3.1 wants the linked stocks on each headline, so a reader knows who it is about.
    expect(items[0]?.linked_symbols).toContain('RELIANCE');
  });

  it('defaults the limit and rejects an absurd one rather than scanning the table', async () => {
    const defaulted = await get('/api/news', (trx) => seedNews(trx, ['RELIANCE', 'TCS']));
    expect(defaulted.status).toBe(200);
    expect((defaulted.data as unknown[]).length).toBe(2);
    expect((await get('/api/news?limit=5000')).status).toBe(400);
    expect((await get('/api/news?limit=0')).status).toBe(400);
    expect((await get('/api/news?limit=abc')).status).toBe(400);
  });

  it('carries the per-article sentiment when the AI job has run, and null when it has not', async () => {
    const withAi = await get('/api/news?limit=1', (trx) =>
      seedNews(trx, ['RELIANCE'], { withSentiment: true }),
    );
    const scored = (withAi.data as Array<Record<string, unknown>>)[0];
    expect(scored).toMatchObject({ sentiment: 'BULLISH', impact_level: 'HIGH' });

    const withoutAi = await get('/api/news?limit=1', (trx) => seedNews(trx, ['RELIANCE']));
    const unscored = (withoutAi.data as Array<Record<string, unknown>>)[0];
    // Present and null, not absent: the panel renders a headline with no sentiment badge.
    expect('sentiment' in (unscored ?? {})).toBe(true);
    expect(unscored?.['sentiment']).toBeNull();
  });
});

describe('GET /stocks (enriched for the Worth Considering table, PRD §3.1)', () => {
  it('carries price, valuation and scores, so the table needs one request not twenty', async () => {
    const { data } = await get('/api/stocks');
    const rows = data as Array<Record<string, unknown>>;
    const row = rows.find((r) => r['symbol'] === 'RELIANCE');
    expect(row).toBeDefined();
    // PRD §3.1's columns: price, change %, action, valuation, scores, R:R, sentiment, risk.
    for (const key of ['quote', 'valuation_label', 'risk_reward', 'sentiment_score', 'scores']) {
      expect(key in (row ?? {}), `row should carry ${key}`).toBe(true);
    }
  });

  it('keeps every enriched field present and null for an unevaluated stock', async () => {
    // A stock the evaluation job has not reached must not look like a 0-score AVOID, and a
    // dropped key renders as undefined, which blanks a cell with no explanation.
    const { data } = await get('/api/stocks', async (trx) => {
      await isolateTables(trx, 'stock_evaluations', 'market_data', 'news_ai_analysis');
    });
    const rows = data as Array<Record<string, unknown>>;
    expect(rows.length).toBeGreaterThan(0);
    const row = rows[0] ?? {};
    for (const key of ['quote', 'valuation_label', 'risk_reward', 'sentiment_score', 'scores']) {
      expect(key in row, `${key} must be present even when unknown`).toBe(true);
      expect(row[key], `${key} must be null, not 0`).toBeNull();
    }
    expect(row['evaluation']).toBeNull();
  });

  it('still honours the query, sector and action filters', async () => {
    const { data } = await get('/api/stocks?query=RELIANCE');
    expect((data as Array<{ symbol: string }>).map((r) => r.symbol)).toEqual(['RELIANCE']);
  });
});

describe('GET /stocks/:symbol/news (per-article AI sentiment, PRD §3.2)', () => {
  it('exposes the stored sentiment, impact and AI summary per article', async () => {
    const { data } = await get('/api/stocks/RELIANCE/news', (trx) =>
      seedNews(trx, ['RELIANCE'], { withSentiment: true }),
    );
    const articles = (data as { articles: Array<Record<string, unknown>> }).articles;
    expect(articles.length).toBeGreaterThan(0);
    // news_ai_analysis holds these; Phase 9 deliberately did not expose them, and PRD §3.2 needs
    // them on the news panel.
    expect(articles[0]).toMatchObject({
      sentiment: 'BULLISH',
      impact_level: 'HIGH',
      ai_summary: '[TEST] RELIANCE sentiment summary',
    });
    expect(articles[0]?.['sentiment_score']).toBe(72);
  });

  it('renders an article with no sentiment row as nulls, not omissions', async () => {
    const { data } = await get('/api/stocks/RELIANCE/news', (trx) => seedNews(trx, ['RELIANCE']));
    const article = (data as { articles: Array<Record<string, unknown>> }).articles[0] ?? {};
    for (const key of ['sentiment', 'sentiment_score', 'impact_level', 'ai_summary']) {
      expect(key in article).toBe(true);
      expect(article[key]).toBeNull();
    }
  });
});

describe('GET /stocks/:symbol/history (chart overlays, PRD §3.2)', () => {
  it('returns SMA series aligned to the bars, so the chart does not recompute them', async () => {
    const { data } = await get('/api/stocks/RELIANCE/history?range=1Y&interval=1d');
    const d = data as {
      bars: unknown[];
      indicators: Record<string, Array<{ ts: string; value: number | null }>>;
    };
    expect(d.bars.length).toBeGreaterThan(0);
    // One point per bar, aligned 1:1, so the chart binds them without re-keying by timestamp.
    for (const key of ['sma_20', 'sma_50', 'sma_200']) {
      expect(d.indicators[key], `${key} series`).toHaveLength(d.bars.length);
    }
    // Measured: indicators are backfilled five years, so a 1Y window starts INSIDE the warm-up
    // period and sma_20[0] is NOT null. Assert the invariant instead: a value is either absent
    // (null) or a real price — never 0, which would draw the line along the x-axis.
    for (const key of ['sma_20', 'sma_50', 'sma_200']) {
      const series = d.indicators[key] ?? [];
      expect(series.every((pt) => pt.value === null || pt.value > 0)).toBe(true);
    }
  });

  it('aligns each indicator point to its bar timestamp', async () => {
    const { data } = await get('/api/stocks/RELIANCE/history?range=3M&interval=1d');
    const d = data as {
      bars: Array<{ ts: string }>;
      indicators: Record<string, Array<{ ts: string }>>;
    };
    expect(d.indicators['sma_20']?.map((p) => p.ts)).toEqual(d.bars.map((b) => b.ts));
  });

  it('yields null points rather than dropping them when no indicator row exists', async () => {
    // Bars without indicators are normal on a fresh sync: the series must stay the same length as
    // the bars, with holes, or the chart silently shifts the overlay against the candles.
    const { data } = await get('/api/stocks/RELIANCE/history?range=3M&interval=1d', async (trx) => {
      await isolateTables(trx, 'technical_indicators');
    });
    const d = data as {
      bars: unknown[];
      indicators: Record<string, Array<{ value: number | null }>>;
    };
    expect(d.indicators['sma_20']).toHaveLength(d.bars.length);
    expect((d.indicators['sma_20'] ?? []).every((p) => p.value === null)).toBe(true);
  });

  it('serves intraday ranges without indicators, which are computed daily', async () => {
    const { status, data } = await get('/api/stocks/RELIANCE/history?range=1D&interval=5m');
    expect(status).toBe(200);
    const d = data as { indicators: Record<string, unknown[]> };
    // A daily SMA has no meaning on a 5-minute axis; the series are empty rather than misaligned.
    expect(d.indicators['sma_20']).toEqual([]);
  });
});

describe('GET /system-status (admin detail, PRD §3.4)', () => {
  it('reports per-job last run with records and duration', async () => {
    const { data } = await get('/api/system-status', async (trx) => {
      await isolateTables(trx, 'system_logs');
      const logs = new SystemLogRepository(trx);
      const id = await logs.startRun({
        service: 'MarketDataService',
        jobName: 'market.sync.eod',
        operation: 'sync:1d',
      });
      await logs.finishRun(id, {
        status: 'SUCCESS',
        counts: { fetched: 40, inserted: 20, skipped: 20, failed: 0 },
        message: 'seeded run',
      });
    });
    const d = data as { jobs: Array<Record<string, unknown>> };
    expect(Array.isArray(d.jobs)).toBe(true);
    const job = d.jobs.find((j) => j['job_name'] === 'market.sync.eod');
    expect(job).toBeDefined();
    for (const key of ['job_name', 'service', 'status', 'records_processed', 'duration_ms']) {
      expect(key in (job ?? {}), `job should carry ${key}`).toBe(true);
    }
    expect(job?.['status']).toBe('SUCCESS');
  });

  it("reports only each job's newest run, so the table is one row per job", async () => {
    const { data } = await get('/api/system-status', async (trx) => {
      await isolateTables(trx, 'system_logs');
      const logs = new SystemLogRepository(trx);
      for (const status of ['FAILED', 'SUCCESS'] as const) {
        const id = await logs.startRun({
          service: 'NewsService',
          jobName: 'news.sync',
          operation: 'sync',
        });
        await logs.finishRun(id, {
          status,
          counts: { fetched: 1, inserted: 1, skipped: 0, failed: 0 },
        });
      }
    });
    const jobs = (data as { jobs: Array<Record<string, unknown>> }).jobs.filter(
      (j) => j['job_name'] === 'news.sync',
    );
    expect(jobs).toHaveLength(1);
    // The newest run is the SUCCESS, not the earlier FAILED.
    expect(jobs[0]?.['status']).toBe('SUCCESS');
  });

  it("reports today's LLM spend against the budget (PRD §3.4)", async () => {
    const { data } = await get('/api/system-status');
    const spend = (data as { llm_spend: Record<string, unknown> }).llm_spend;
    for (const key of [
      'calls_today',
      'input_tokens',
      'output_tokens',
      'spent_inr',
      'budget_inr',
      'cache_hits',
    ]) {
      expect(key in spend, `llm_spend should carry ${key}`).toBe(true);
    }
    expect(typeof spend['budget_inr']).toBe('number');
  });

  it('still answers 200 with the pre-existing fields', async () => {
    // The additions are additive: a Phase 9 consumer must not break.
    const { status, data } = await get('/api/system-status');
    expect(status).toBe(200);
    expect(data).toMatchObject({
      data_mode: 'MOCK',
      database_status: 'up',
      failed_jobs: expect.any(Array),
    });
  });
});

describe('the new reads never spend money', () => {
  it('serves /news with an LLM provider that throws on any call', async () => {
    // PRD §14's first rule. Phase 9 proved it for its own routes; a new read route that is not
    // covered is unproven, and this is the cheapest place to prove it.
    let out = 0;
    await withRollback(db, async (trx) => {
      await seedNews(trx, ['RELIANCE']);
      const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
        db: trx,
        logger: silentLogger,
        jobQueue: null,
        llmProvider: {
          name: 'exploding',
          chat: () => {
            throw new Error('a page load must never call the LLM');
          },
          embed: () => {
            throw new Error('a page load must never embed');
          },
        } as never,
      });
      const app = await buildApp(container);
      await app.ready();
      try {
        out = (await app.inject({ method: 'GET', url: '/api/news' })).statusCode;
      } finally {
        await app.close();
        await container.close();
      }
    });
    expect(out).toBe(200);
  });
});
