import { afterAll, describe, expect, it } from 'vitest';
import type { JobDefinition } from '../../src/jobs/runJob.js';
import { runJob } from '../../src/jobs/runJob.js';
import type { JobName, JobPayload, JobQueue } from '../../src/jobs/types.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { AppError } from '../../src/utils/errors.js';
import { createTestDb, isolateTables, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const NOW = new Date('2026-10-05T06:00:00Z');

/** Records what was enqueued; nothing else here needs a real queue. */
function fakeQueue() {
  const sent: Array<{ name: JobName; data: JobPayload | undefined; key: string | undefined }> = [];
  const queue: JobQueue = {
    start: async () => undefined,
    stop: async () => undefined,
    ensureQueues: async () => undefined,
    applySchedules: async () => undefined,
    work: async () => undefined,
    enqueue: async (name, data, options) => {
      sent.push({ name, data, key: options?.singletonKey });
      return 'job-id';
    },
  };
  return { queue, sent };
}

describe('runJob', () => {
  it('runs the handler and enqueues its follow-ups with their singleton keys', async () => {
    await withRollback(db, async (trx) => {
      const { queue, sent } = fakeQueue();
      const definition: JobDefinition = {
        name: 'market.sync.eod',
        run: async () => ({
          status: 'SUCCESS',
          runId: 'service-run',
          message: 'ok',
          next: [{ name: 'evaluation.compute', data: { origin: 'eod' }, singletonKey: 'eod' }],
        }),
      };
      const outcome = await runJob({
        definition,
        payload: {},
        queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(outcome.status).toBe('SUCCESS');
      expect(sent).toEqual([{ name: 'evaluation.compute', data: { origin: 'eod' }, key: 'eod' }]);
    });
  });

  it('writes no row of its own when the service logged the run', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const { queue } = fakeQueue();
      await runJob({
        definition: {
          name: 'news.sync',
          run: async () => ({ status: 'SUCCESS', runId: 'service-run', message: 'ok', next: [] }),
        },
        payload: {},
        queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(await new SystemLogRepository(trx).recentRuns(5)).toEqual([]);
    });
  });

  it('logs a SKIPPED row and chains nothing when the gate refuses', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const { queue, sent } = fakeQueue();
      let ran = false;
      const outcome = await runJob({
        definition: {
          name: 'market.sync.intraday',
          gate: async () => ({
            run: false,
            kind: 'calendar',
            reason: 'NSE is closed all day on 2026-10-07 (IST)',
          }),
          run: async () => {
            ran = true;
            return {
              status: 'SUCCESS',
              runId: null,
              message: 'ok',
              next: [{ name: 'evaluation.compute' }],
            };
          },
        },
        payload: {},
        queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(ran).toBe(false);
      expect(sent).toEqual([]);
      expect(outcome.status).toBe('SKIPPED');
      const [row] = await new SystemLogRepository(trx).recentRuns(5);
      expect(row).toMatchObject({ jobName: 'market.sync.intraday', status: 'SKIPPED' });
      expect(row?.message).toMatch(/closed all day/);
    });
  });

  it('logs the run itself when no service did (runId null)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const { queue } = fakeQueue();
      await runJob({
        definition: {
          name: 'signals.expire',
          run: async () => ({
            status: 'SUCCESS',
            runId: null,
            message: '3 signals expired',
            next: [],
            counts: { fetched: 0, inserted: 0, skipped: 0, failed: 0 },
          }),
        },
        payload: {},
        queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      const [row] = await new SystemLogRepository(trx).recentRuns(5);
      expect(row).toMatchObject({ jobName: 'signals.expire', status: 'SUCCESS' });
      expect(row?.message).toMatch(/3 signals expired/);
    });
  });

  it('records a FAILED row when the GATE throws, and does not run or chain', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const { queue, sent } = fakeQueue();
      let ran = false;
      // Gates are not pure: tradingDayGate and intradayWindowGate query exchange_holidays. A
      // database outage makes the gate throw, and 10 of the 13 jobs have one — so without this
      // path /system-status would still report the last success as if nothing were wrong.
      const outcome = await runJob({
        definition: {
          name: 'ai.stock.analyze',
          gate: async () => {
            throw new AppError('INTERNAL', 'connection terminated unexpectedly');
          },
          run: async () => {
            ran = true;
            return { status: 'SUCCESS', runId: null, message: 'ok', next: [] };
          },
        },
        payload: {},
        queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(ran).toBe(false);
      expect(sent).toEqual([]);
      expect(outcome.status).toBe('FAILED');
      const [row] = await new SystemLogRepository(trx).recentRuns(5);
      expect(row).toMatchObject({ jobName: 'ai.stock.analyze', status: 'FAILED' });
      expect(row?.errorDetails).toMatchObject({ code: 'INTERNAL' });
    });
  });

  it('records a FAILED row when the handler throws before any service ran, and does not chain', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const { queue, sent } = fakeQueue();
      const outcome = await runJob({
        definition: {
          name: 'evaluation.compute',
          run: async () => {
            throw new AppError('INTERNAL', 'container is missing the evaluation service');
          },
        },
        payload: {},
        queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(outcome.status).toBe('FAILED');
      expect(sent).toEqual([]);
      const [row] = await new SystemLogRepository(trx).recentRuns(5);
      expect(row).toMatchObject({ jobName: 'evaluation.compute', status: 'FAILED' });
      expect(row?.errorDetails).toMatchObject({ code: 'INTERNAL' });
    });
  });

  it('amends the service row when the handler overrides its verdict', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'system_logs');
      const systemLogs = new SystemLogRepository(trx);
      // Stand in for the service: it opened and closed its own row as SUCCESS.
      const runId = await systemLogs.startRun({
        service: 'MarketDataService',
        jobName: 'market.sync.eod',
        operation: 'sync:1d',
      });
      await systemLogs.finishRun(runId, {
        status: 'SUCCESS',
        counts: { fetched: 1, inserted: 1, skipped: 0, failed: 0 },
        message: 'ok',
      });
      const { queue } = fakeQueue();
      await runJob({
        definition: {
          name: 'market.sync.eod',
          run: async () => ({
            status: 'PARTIAL',
            amended: true,
            runId,
            message: 'no settled daily bar stored for 2026-10-06 (IST)',
            next: [],
          }),
        },
        payload: {},
        queue,
        systemLogs,
        logger: silentLogger,
        now: () => NOW,
      });
      // One row, carrying the handler's verdict: /system-status reads this table and nothing else.
      const rows = await systemLogs.recentRuns(5);
      expect(rows).toHaveLength(1);
      expect(rows[0]).toMatchObject({ id: runId, status: 'PARTIAL', recordsInserted: 1 });
      expect(rows[0]?.message).toMatch(/no settled daily bar/);
    });
  });

  it('still chains after a PARTIAL run, but not after FAILED', async () => {
    await withRollback(db, async (trx) => {
      const partial = fakeQueue();
      await runJob({
        definition: {
          name: 'news.sync',
          run: async () => ({
            status: 'PARTIAL',
            runId: 'r',
            message: '1 source failed',
            next: [{ name: 'embeddings.generate' }],
          }),
        },
        payload: {},
        queue: partial.queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(partial.sent.map((s) => s.name)).toEqual(['embeddings.generate']);

      const failed = fakeQueue();
      await runJob({
        definition: {
          name: 'news.sync',
          run: async () => ({
            status: 'FAILED',
            runId: 'r',
            message: 'provider down',
            next: [{ name: 'embeddings.generate' }],
          }),
        },
        payload: {},
        queue: failed.queue,
        systemLogs: new SystemLogRepository(trx),
        logger: silentLogger,
        now: () => NOW,
      });
      expect(failed.sent).toEqual([]);
    });
  });
});
