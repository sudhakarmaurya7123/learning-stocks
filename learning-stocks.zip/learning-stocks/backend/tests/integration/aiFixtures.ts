import { Writable } from 'node:stream';
import { LlmBudget, type BudgetGate } from '../../src/ai/LlmBudget.js';
import { LlmGateway } from '../../src/ai/LlmGateway.js';
import { mockResponders } from '../../src/ai/mockResponders.js';
import type { Database } from '../../src/database/db.js';
import { MockFundamentalsProvider } from '../../src/providers/fundamentals/mock/MockFundamentalsProvider.js';
import {
  MockLLMProvider,
  type MockResponder,
} from '../../src/providers/llm/mock/MockLLMProvider.js';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import { Retriever } from '../../src/rag/retriever.js';
import { AppSettingsRepository } from '../../src/repositories/AppSettingsRepository.js';
import { EmbeddingRepository } from '../../src/repositories/EmbeddingRepository.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { FundamentalsRepository } from '../../src/repositories/FundamentalsRepository.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { LlmCallRepository } from '../../src/repositories/LlmCallRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { NewsRepository } from '../../src/repositories/NewsRepository.js';
import { PaperPositionRepository } from '../../src/repositories/PaperPositionRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { ScoringConfigRepository } from '../../src/repositories/ScoringConfigRepository.js';
import { StockAnalysisRepository } from '../../src/repositories/StockAnalysisRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { TechnicalIndicatorRepository } from '../../src/repositories/TechnicalIndicatorRepository.js';
import { EvaluationService } from '../../src/services/EvaluationService.js';
import { FundamentalsService } from '../../src/services/fundamentals/FundamentalsService.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MarketDataService } from '../../src/services/marketData/MarketDataService.js';
import { EmbeddingService } from '../../src/services/rag/EmbeddingService.js';
import { StockContextService } from '../../src/services/rag/StockContextService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { createLogger } from '../../src/utils/logger.js';
import { newsArticle } from '../fixtures/ragArticles.js';
import { isolateTables } from './helpers.js';

export const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
export const NOW = new Date('2026-10-05T12:00:00Z'); // Monday 17:30 IST, after close
const MARKETS = [
  'NIFTY50',
  'SENSEX',
  'BANKNIFTY',
  'NIFTYIT',
  'NIFTYPHARMA',
  'INDIAVIX',
  'NIFTYFINSERVICE',
  'NIFTYENERGY',
];

/** Mock pipeline for Phase 7 tests: bars, fundamentals, evaluations, one news article, embeddings. */
export async function seedPipeline(
  trx: Database,
  stocks: readonly string[] = ['RELIANCE', 'HDFCBANK'],
) {
  await isolateTables(
    trx,
    'market_data',
    'technical_indicators',
    'stock_evaluations',
    'fundamental_snapshots',
    'financial_statements',
    'news',
    'document_embeddings',
    'llm_calls',
    'stock_ai_analysis',
    'market_ai_summary',
    'ai_trade_signals',
    'ai_qa_log',
  );
  const sessions = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());
  const market = new MockMarketDataProvider(sessions, () => NOW);
  const logs = new SystemLogRepository(trx);
  const common = { dataMode: 'MOCK' as const, logger: silent, now: () => NOW };
  await new MarketDataService({
    ...common,
    provider: market,
    sessions,
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    systemLogs: logs,
  }).sync({
    jobName: 'seed',
    timeframe: '1d',
    from: new Date(NOW.getTime() - 420 * 86_400_000),
    to: NOW,
    symbols: [...stocks, ...MARKETS],
  });
  await new FundamentalsService({
    ...common,
    provider: new MockFundamentalsProvider(
      async (ref) => (await market.getQuote(ref)).price,
      () => NOW,
    ),
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    systemLogs: logs,
  }).sync({ jobName: 'seed', symbols: [...stocks] });
  await new EvaluationService({
    ...common,
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    news: new NewsRepository(trx),
    positions: new PaperPositionRepository(trx),
    configs: new ScoringConfigRepository(trx),
    settings: new AppSettingsRepository(trx),
    evaluations: new EvaluationRepository(trx),
    indicators: new TechnicalIndicatorRepository(trx),
    systemLogs: logs,
    sessions,
  }).run({ jobName: 'seed', symbols: [...stocks] });
  const rel = (await new StockRepository(trx).findBySymbol('RELIANCE'))?.id ?? '';
  const news = new NewsRepository(trx);
  const { ids } = await news.saveArticles([
    newsArticle(
      'Reliance retail arm opens 300 stores',
      'https://example.com/r',
      new Date('2026-10-04T05:00:00Z'),
    ),
  ]);
  await news.saveMentions([
    {
      newsId: ids[0] ?? '',
      ref: { kind: 'stock', id: rel },
      relevance: 0.9,
      matchedBy: 'name:title',
    },
  ]);
  await new EmbeddingService({
    provider: new MockLLMProvider(),
    embeddings: new EmbeddingRepository(trx),
    llmCalls: new LlmCallRepository(trx),
    stocks: new StockRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    settings: new AppSettingsRepository(trx),
    systemLogs: logs,
    dataMode: 'MOCK',
    logger: silent,
    usdInrRate: 88,
  }).run({ jobName: 'seed' });
  await trx.deleteFrom('llm_calls').execute(); // tests count only the calls they cause
  return { sessions, rel };
}

/** Gateway + context wiring with the MOCK provider (responders overridable) and an optional budget stub. */
export function aiDeps(
  trx: Database,
  now: Date,
  options: { responders?: Record<string, MockResponder>; budget?: BudgetGate } = {},
) {
  const provider = new MockLLMProvider({
    responders: { ...mockResponders(), ...options.responders },
  });
  const llmCalls = new LlmCallRepository(trx);
  const settings = new AppSettingsRepository(trx);
  const budget =
    options.budget ?? new LlmBudget({ llmCalls, settings, defaultDailyInr: 100, now: () => now });
  const gateway = new LlmGateway({
    provider,
    llmCalls,
    budget,
    usdInrRate: 88,
    priceOverride: null,
  });
  const retriever = new Retriever({
    provider,
    embeddings: new EmbeddingRepository(trx),
    llmCalls,
    cache: new MemoryCache(),
    dataMode: 'MOCK',
    usdInrRate: 88,
    now: () => now,
  });
  const analyses = new StockAnalysisRepository(trx);
  const context = new StockContextService({
    stocks: new StockRepository(trx),
    marketData: new MarketDataRepository(trx),
    evaluations: new EvaluationRepository(trx),
    fundamentals: new FundamentalsRepository(trx),
    retriever,
    analyses,
    dataMode: 'MOCK',
    now: () => now,
  });
  return { provider, gateway, retriever, context, analyses, settings, llmCalls };
}
