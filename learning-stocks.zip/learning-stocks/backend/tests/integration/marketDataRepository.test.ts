import { afterAll, describe, expect, it } from 'vitest';
import type { Bar } from '../../src/domain/types.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

function bar(
  instrumentId: string,
  kind: 'stock' | 'market',
  ts: string,
  close: number,
  overrides: Partial<Bar> = {},
): Bar {
  return {
    instrument:
      kind === 'stock' ? { kind: 'stock', id: instrumentId } : { kind: 'market', id: instrumentId },
    dataMode: 'MOCK',
    timeframe: '5m',
    ts: new Date(ts),
    open: close - 1,
    high: close + 2,
    low: close - 2,
    close,
    adjustedClose: null,
    volume: 12_345,
    change: null,
    changePercent: null,
    vwap: null,
    source: 'mock',
    ...overrides,
  };
}

describe('MarketDataRepository', () => {
  it('inserts bars, skips duplicates, and returns numbers (not strings)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      if (!stock) throw new Error('seed missing');
      const repo = new MarketDataRepository(trx);
      const bars = [
        bar(stock.id, 'stock', '2026-10-05T03:45:00Z', 2500.25),
        bar(stock.id, 'stock', '2026-10-05T03:50:00Z', 2501.5),
      ];
      expect(await repo.insertBars(bars)).toEqual({ inserted: 2, skipped: 0 });
      expect(await repo.insertBars(bars)).toEqual({ inserted: 0, skipped: 2 });
      expect(await repo.insertBars([])).toEqual({ inserted: 0, skipped: 0 });

      const quote = await repo.latestQuote({ kind: 'stock', id: stock.id }, 'MOCK');
      expect(quote).toMatchObject({
        price: 2501.5,
        volume: 12_345,
        timeframe: '5m',
        source: 'mock',
      });
      expect(typeof quote?.price).toBe('number');
      expect(quote?.ts.toISOString()).toBe('2026-10-05T03:50:00.000Z');

      const range = await repo.getBars(
        { kind: 'stock', id: stock.id },
        'MOCK',
        '5m',
        new Date('2026-10-05T03:45:00Z'),
        new Date('2026-10-05T03:50:00Z'),
      );
      expect(range.map((b) => b.close)).toEqual([2500.25, 2501.5]);
    });
  });

  it('keeps MOCK and LIVE apart', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const stock = await new StockRepository(trx).findBySymbol('TCS');
      if (!stock) throw new Error('seed missing');
      const repo = new MarketDataRepository(trx);
      await repo.insertBars([bar(stock.id, 'stock', '2026-10-05T04:00:00Z', 4000)]);
      expect(await repo.latestQuote({ kind: 'stock', id: stock.id }, 'LIVE')).toBeNull();
      expect(
        await repo.getBars(
          { kind: 'stock', id: stock.id },
          'LIVE',
          '5m',
          new Date('2026-10-01'),
          new Date('2026-10-31'),
        ),
      ).toEqual([]);
    });
  });

  it('stores and reads index bars', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
      if (!nifty) throw new Error('seed missing');
      const repo = new MarketDataRepository(trx);
      await repo.insertBars([bar(nifty.id, 'market', '2026-10-05T03:45:00Z', 25_100.5)]);
      expect((await repo.latestQuote({ kind: 'market', id: nifty.id }, 'MOCK'))?.price).toBe(
        25_100.5,
      );
    });
  });

  it('reports whether a settled daily bar exists for an IST date, per mode', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const repo = new MarketDataRepository(trx);
      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      const ref = { kind: 'stock', id: stock?.id ?? '' } as const;
      // 2026-10-05 is a Monday; the daily bar is stamped at that session's open (09:15 IST).
      await repo.insertBars([
        {
          instrument: ref,
          dataMode: 'MOCK',
          timeframe: '1d',
          ts: new Date('2026-10-05T03:45:00Z'),
          open: 100,
          high: 105,
          low: 99,
          close: 104,
          adjustedClose: 104,
          volume: 10,
          change: null,
          changePercent: null,
          vwap: null,
          source: 'mock',
        },
      ]);
      expect(await repo.hasDailyBarOn('2026-10-05', 'MOCK')).toBe(true);
      // A day with no bar, and the same day in the other mode: mock and live never answer for
      // each other (the EOD guard would otherwise pass on the wrong mode's data).
      expect(await repo.hasDailyBarOn('2026-10-06', 'MOCK')).toBe(false);
      expect(await repo.hasDailyBarOn('2026-10-05', 'LIVE')).toBe(false);
    });
  });
});
