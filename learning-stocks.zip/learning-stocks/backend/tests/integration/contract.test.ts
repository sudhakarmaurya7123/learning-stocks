import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import {
  EnvelopeSchema,
  HistorySchema,
  MarketCardSchema,
  MarketStatusSchema,
  MarketSummarySchema,
  NewsItemSchema,
  StockAggregateSchema,
  StockListRowSchema,
  SystemStatusSchema,
} from '@learning-stocks/shared';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { Database } from '../../src/database/db.js';
import { StockAnalysisRepository } from '../../src/repositories/StockAnalysisRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();

/**
 * Parses a live response through the shared schema the browser will use.
 *
 * `jobQueue: null` is load-bearing: /system-status resolves worker liveness, which calls
 * `queue.start()` on a real PgBossQueue (the Phase 9 T8 fix). Without the override every call
 * here would boot pg-boss against the test schema and leak a pool that SIGTERM cannot close —
 * the Phase 9 C1 defect, re-created in a helper. Closing the app and container is the other half.
 */
async function parsedOn<T>(trx: Database, url: string, schema: z.ZodType<T>): Promise<T> {
  const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
    db: trx,
    logger: silentLogger,
    jobQueue: null,
  });
  const app = await buildApp(container);
  await app.ready();
  try {
    const res = await app.inject({ method: 'GET', url });
    expect(res.statusCode, `${url} should answer 200`).toBe(200);
    const result = schema.safeParse(res.json());
    // The failure message must name the field, or a drift takes an hour to find.
    if (!result.success) {
      throw new Error(
        `${url} violates its contract: ${JSON.stringify(z.treeifyError(result.error), null, 2)}`,
      );
    }
    return result.data;
  } finally {
    await app.close();
    await container.close();
  }
}

/** The same, in a transaction of its own, for a test that needs no seeding. */
async function parsed<T>(url: string, schema: z.ZodType<T>): Promise<T> {
  let out: T | undefined;
  await withRollback(db, async (trx) => {
    out = await parsedOn(trx, url, schema);
  });
  // withRollback resolves to void, so the value is carried out here. It is always assigned: a
  // failure inside the transaction throws rather than leaving this undefined.
  if (out === undefined) throw new Error('no response captured');
  return out;
}

/**
 * Writes one analysis carrying sources, so the snake_case assertion has something to assert on.
 *
 * Seeded rather than read from whatever the dev worker last wrote: `expect(length > 0)` against
 * ambient data is a pass that proves nothing, and the suite must be green right after `db:reset`.
 */
async function seedAnalysisWithSources(trx: Database, symbol: string): Promise<void> {
  const stock = await new StockRepository(trx).findBySymbol(symbol);
  if (!stock) throw new Error(`seed precondition failed: no stock ${symbol}`);
  await new StockAnalysisRepository(trx).save({
    stockId: stock.id,
    evaluationId: null,
    dataMode: 'MOCK',
    dataAsOf: new Date('2026-10-06T03:45:00Z'),
    status: 'OK',
    sentiment: 'NEUTRAL',
    sentimentScore: 50,
    confidence: 50,
    technicalScore: null,
    fundamentalScore: null,
    newsScore: null,
    momentumScore: null,
    riskScore: null,
    overallScore: null,
    trend: 'UPTREND',
    riskLevel: 'MEDIUM',
    recommendation: 'HOLD_BIAS',
    summary: 'Contract fixture.',
    reasoning: ['Fixture reasoning.'],
    keyPositiveFactors: [],
    keyNegativeFactors: [],
    keyRisks: [],
    catalysts: [],
    invalidationConditions: [],
    facts: [{ statement: 'Fixture fact.', source_ids: ['E1'] }],
    interpretation: ['Fixture interpretation.'],
    insufficientData: [],
    // The stored shape is camelCase (domain SourceRef.asOf); the wire must be snake_case.
    sources: [
      {
        id: 'E1',
        kind: 'EVALUATION',
        title: 'EVALUATION AND LEVELS (computed)',
        asOf: '2026-10-06T03:45:00.000Z',
        url: null,
      },
    ],
    inputHash: 'contract-fixture-hash',
    model: 'mock-chat-v1',
    promptVersion: 'v1',
  });
}

describe('API responses satisfy the shared contract', () => {
  it('parses every read route the frontend calls', async () => {
    await parsed('/api/markets', EnvelopeSchema(z.array(MarketCardSchema)));
    await parsed('/api/market-status', EnvelopeSchema(MarketStatusSchema));
    await parsed('/api/market-summary', EnvelopeSchema(MarketSummarySchema.nullable()));
    await parsed('/api/stocks', EnvelopeSchema(z.array(StockListRowSchema)));
    await parsed('/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
    await parsed(
      '/api/stocks/RELIANCE/history?range=6M&interval=1d',
      EnvelopeSchema(HistorySchema),
    );
    // An intraday range serves empty overlay series rather than a daily SMA on a 5-minute axis.
    await parsed(
      '/api/stocks/RELIANCE/history?range=1D&interval=5m',
      EnvelopeSchema(HistorySchema),
    );
    await parsed('/api/system-status', EnvelopeSchema(SystemStatusSchema));
    await parsed('/api/news', EnvelopeSchema(z.array(NewsItemSchema)));
  });

  it('parses an aggregate whose sections are empty, which is a fresh database', async () => {
    // Deliberately NOT "12 of 13 sections are populated": that passes only because this dev
    // database has a worker filling it, and the end-of-phase check runs `pnpm db:reset` before
    // `pnpm test`. The contract must hold on an empty database, which is a new checkout's state.
    const { data } = await parsed('/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
    expect(data.stock.symbol).toBe('RELIANCE');
    expect(Array.isArray(data.news)).toBe(true);
    for (const k of ['1d', '1w', '1m', '3m', '1y'] as const) {
      expect(k in data.performance).toBe(true);
    }
  });

  it('emits snake_case throughout, including inside jsonb passthroughs', async () => {
    // sources[] came back as camelCase `asOf` while every sibling key was snake_case: a jsonb
    // column passed straight through. One inconsistent key is a bug the browser inherits.
    await withRollback(db, async (trx) => {
      await seedAnalysisWithSources(trx, 'RELIANCE');
      const { data } = await parsedOn(
        trx,
        '/api/stocks/RELIANCE',
        EnvelopeSchema(StockAggregateSchema),
      );
      const sources = data.ai_analysis?.sources ?? [];
      expect(sources.length).toBeGreaterThan(0);
      for (const src of sources) {
        expect(src).toHaveProperty('as_of');
        expect(src).not.toHaveProperty('asOf');
      }
    });
  });

  it('exposes the same snake_case sources on the dedicated analysis route', async () => {
    // /stocks/:symbol/analysis maps `sources` too, so the fix has to be made in both places.
    await withRollback(db, async (trx) => {
      await seedAnalysisWithSources(trx, 'RELIANCE');
      const sourceRef = z.object({
        id: z.string(),
        url: z.string().nullable(),
        as_of: z.string().nullable(),
        kind: z.string(),
        title: z.string().nullable(),
      });
      const { data } = await parsedOn(
        trx,
        '/api/stocks/RELIANCE/analysis',
        EnvelopeSchema(z.looseObject({ sources: z.array(sourceRef) })),
      );
      for (const src of data.sources) expect(src).not.toHaveProperty('asOf');
    });
  });
});
