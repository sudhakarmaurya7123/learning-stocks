import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { sql } from 'kysely';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { PgBossQueue } from '../../src/jobs/PgBossQueue.js';
import { DEFAULT_SCHEDULES } from '../../src/jobs/schedules.js';
import { JOB_NAMES } from '../../src/jobs/types.js';
import { startWorker } from '../../src/worker.js';
import { createTestDb, LOCAL_DATABASE_URL, silentLogger } from './helpers.js';

// A schema per test: test 1's worker registers real handlers on all 13 queues, so sharing one
// schema would let it consume test 2's job — and run the real evaluation service doing it.
const SCHEMA = 'pgboss_test_worker';
const OVERLAP_SCHEMA = 'pgboss_test_overlap';
const db = createTestDb();
const container = createContainer(loadConfig({ WORKER_QUEUE_SCHEMA: SCHEMA }), {
  logger: silentLogger,
});

beforeAll(async () => {
  for (const schema of [SCHEMA, OVERLAP_SCHEMA])
    await sql`drop schema if exists ${sql.id(schema)} cascade`.execute(db);
});
afterAll(async () => {
  for (const schema of [SCHEMA, OVERLAP_SCHEMA])
    await sql`drop schema if exists ${sql.id(schema)} cascade`.execute(db);
  await container.close();
  await db.destroy();
});

describe('worker', () => {
  it('registers every job queue and the full schedule, then stops cleanly', async () => {
    // No-op handlers: pg-boss fires a cron pass immediately on start and matches any occurrence
    // in the preceding 60 seconds, so the real registry here would run signals.expire (an UPDATE
    // outside any transaction) against the developer's database roughly one run in five. This
    // test only asserts the queue and schedule rows, which needs no real handler at all.
    const ran: string[] = [];
    const worker = await startWorker(container, {
      handler: (name) => async () => {
        ran.push(name);
      },
    });
    const queues = await sql<{ name: string }>`
      select name from ${sql.id(SCHEMA)}.queue order by name
    `.execute(db);
    // A subset check: pg-boss also keeps internal queues of its own (__pgboss__send-it, which
    // delivers cron sends), and those are not ours to assert over.
    const names = new Set(queues.rows.map((r) => r.name));
    expect([...JOB_NAMES].filter((n) => !names.has(n))).toEqual([]);

    const schedules = await sql<{ name: string; timezone: string }>`
      select distinct name, timezone from ${sql.id(SCHEMA)}.schedule
    `.execute(db);
    expect(schedules.rows.map((r) => r.name).sort()).toEqual(
      [...new Set(DEFAULT_SCHEDULES.map((s) => s.name))].sort(),
    );
    expect(schedules.rows.every((r) => r.timezone === 'Asia/Kolkata')).toBe(true);
    await worker.stop();
    // Whatever the cron pass delivered went to the no-op, so nothing in this file touched the
    // pipeline. Starting a worker must never be a side effect on real data.
    expect(ran.filter((n) => !JOB_NAMES.includes(n as never))).toEqual([]);
  });

  it('keeps one successor and drops the rest while a run is in flight', async () => {
    // Review Focus 2: a run slower than its interval must not pile up, and must not lose the one
    // successor that carries fresh data. `stately` allows one job per state, so this only means
    // anything while a job is genuinely ACTIVE — hence the held handler.
    const queue = new PgBossQueue({
      connectionString: process.env.DATABASE_URL ?? LOCAL_DATABASE_URL,
      schema: OVERLAP_SCHEMA,
      logger: silentLogger,
      tz: 'Asia/Kolkata',
    });
    await queue.start();
    await queue.ensureQueues(['evaluation.compute']);

    let started = false;
    let release = () => {};
    const held = new Promise<void>((resolve) => {
      release = resolve;
    });
    await queue.work('evaluation.compute', async () => {
      started = true;
      await held;
    });

    expect(await queue.enqueue('evaluation.compute', { origin: 'eod' })).not.toBeNull();
    await vi.waitUntil(() => started, { timeout: 10_000 });

    // One job is active. A successor is accepted (it carries newer data) and a third is dropped.
    expect(await queue.enqueue('evaluation.compute', { origin: 'intraday' })).not.toBeNull();
    expect(await queue.enqueue('evaluation.compute', { origin: 'intraday' })).toBeNull();

    // Release before stopping, or the graceful stop waits on the handler forever.
    release();
    await queue.stop();
  });
});
