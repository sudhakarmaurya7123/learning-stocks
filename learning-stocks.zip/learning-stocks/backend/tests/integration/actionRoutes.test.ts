import { randomUUID } from 'node:crypto';
import { sql } from 'kysely';
import { SignJWT } from 'jose';
import { afterAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { Database } from '../../src/database/db.js';
import type { JobName, JobPayload, JobQueue } from '../../src/jobs/types.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long';
const ISSUER = 'http://127.0.0.1:54321/auth/v1';
const db = createTestDb();
afterAll(() => db.destroy());

/** Records what the API enqueued; never opens a pg-boss connection. */
function recordingQueue() {
  const sent: Array<{ name: JobName; data: JobPayload | undefined; key: string | undefined }> = [];
  let nextIsDuplicate = false;
  const queue: JobQueue = {
    start: async () => undefined,
    stop: async () => undefined,
    ensureQueues: async () => undefined,
    applySchedules: async () => undefined,
    work: async () => undefined,
    enqueue: async (name, data, options) => {
      sent.push({ name, data, key: options?.singletonKey });
      if (nextIsDuplicate) {
        nextIsDuplicate = false;
        return null;
      }
      return `job-${sent.length}`;
    },
  };
  return {
    queue,
    sent,
    dedupeNext: () => {
      nextIsDuplicate = true;
    },
  };
}

const build = async (
  trx: Database,
  env: Record<string, string> = {},
  overrides: { llmProvider?: null } = {},
) => {
  const q = recordingQueue();
  const container = createContainer(loadConfig({ AUTH_MODE: 'none', ...env }), {
    db: trx,
    logger: silentLogger,
    jobQueue: q.queue,
    ...overrides,
  });
  const app = await buildApp(container);
  await app.ready();
  const post = (url: string, payload: Record<string, unknown> = {}) =>
    app.inject({ method: 'POST', url, payload });
  return { app, container, post, ...q };
};

describe('sync and job actions', () => {
  it('enqueues a market sync as a manual trigger, with its own singleton key', async () => {
    await withRollback(db, async (trx) => {
      const { post, sent } = await build(trx);
      const r = await post('/api/sync/market', { symbols: ['RELIANCE'] });
      expect(r.statusCode).toBe(202);
      expect(r.json().data).toMatchObject({ job_id: expect.any(String), already_queued: false });
      expect(sent).toEqual([
        {
          name: 'market.sync.eod',
          // manual bypasses the trading-day gate so a weekend click does something; `force` is
          // absent because handlers pass it to the AI services' hash cache.
          data: { origin: 'api', manual: true, symbols: ['RELIANCE'] },
          // A key derived from the request: distinct from a cron send's '' (so a manual trigger
          // never collapses into a queued scheduled job) and distinct between different asks.
          key: 'manual:RELIANCE',
        },
      ]);
    });
  });

  it('does not collapse two syncs with different symbols into one', async () => {
    // A shared singleton key makes the second request dedup into the first and answer
    // 202 already_queued — so the caller asks to sync TCS, is told it is queued, and TCS is
    // never synced. Reproduced against pg-boss 12.37.0 before the fix.
    await withRollback(db, async (trx) => {
      const { post, sent } = await build(trx);
      await post('/api/sync/market', { symbols: ['RELIANCE'] });
      await post('/api/sync/market', { symbols: ['TCS'] });
      const keys = sent.map((x) => x.key);
      expect(keys[0]).not.toBe(keys[1]);
    });
  });

  it('still dedups two identical requests', async () => {
    // The flip side: asking for the same thing twice should collapse, or a double-click
    // would queue two full syncs.
    await withRollback(db, async (trx) => {
      const { post, sent } = await build(trx);
      await post('/api/sync/market', { symbols: ['RELIANCE'] });
      await post('/api/sync/market', { symbols: ['RELIANCE'] });
      expect(sent[0]?.key).toBe(sent[1]?.key);
    });
  });

  it('reports a deduplicated send as 202 already_queued, not as a failure', async () => {
    await withRollback(db, async (trx) => {
      const { post, dedupeNext } = await build(trx);
      dedupeNext();
      const r = await post('/api/sync/news', {});
      expect(r.statusCode).toBe(202);
      expect(r.json().data).toMatchObject({ job_id: null, already_queued: true });
    });
  });

  it('rejects an unknown job name and accepts a known one', async () => {
    await withRollback(db, async (trx) => {
      const { post } = await build(trx);
      expect((await post('/api/jobs/not.a.job/run')).statusCode).toBe(400);
      expect((await post('/api/jobs/signals.expire/run')).statusCode).toBe(202);
    });
  });

  it('never sends force when running an AI job manually', async () => {
    // One click on "Run AI analysis" must not force-regenerate all 20 stocks past the hash
    // cache. Only POST /ai/regenerate sets force, and it has its own 5/hour limit.
    await withRollback(db, async (trx) => {
      const { post, sent } = await build(trx);
      await post('/api/jobs/ai.stock.analyze/run');
      expect(sent.at(-1)?.key).toBe('manual');
      expect(sent.at(-1)?.data).toEqual({ origin: 'api', manual: true });
      expect(sent.at(-1)?.data).not.toHaveProperty('force');
    });
  });

  it('rejects an unknown field in a sync body rather than ignoring it', async () => {
    await withRollback(db, async (trx) => {
      const { post } = await build(trx);
      expect((await post('/api/sync/market', { symbol: 'RELIANCE' })).statusCode).toBe(400);
    });
  });
});

describe('AI actions', () => {
  it('validates the QA question length', async () => {
    await withRollback(db, async (trx) => {
      const { post } = await build(trx);
      expect((await post('/api/stocks/RELIANCE/qa', { question: '' })).statusCode).toBe(400);
      expect(
        (await post('/api/stocks/RELIANCE/qa', { question: 'x'.repeat(501) })).statusCode,
      ).toBe(400);
    });
  });

  it('404s an unknown symbol on /ai/analyze', async () => {
    await withRollback(db, async (trx) => {
      const { post } = await build(trx);
      expect((await post('/api/ai/analyze', { symbol: 'NOSUCHSTOCK' })).statusCode).toBe(404);
    });
  });

  it('returns 501, not 500, when AI is disabled', async () => {
    // LLM_PROVIDER=none is a configuration, not a crash.
    await withRollback(db, async (trx) => {
      // In mock mode loadConfig forces every provider to 'mock', so LLM_PROVIDER=none cannot
      // express "AI is off" here (env.ts:196). The container override is the honest lever.
      const { post } = await build(trx, {}, { llmProvider: null });
      expect((await post('/api/ai/analyze', { symbol: 'RELIANCE' })).statusCode).toBe(501);
      expect((await post('/api/stocks/RELIANCE/qa', { question: 'why?' })).statusCode).toBe(501);
    });
  });
});

describe('admin authorization on actions', () => {
  const sign = (sub: string) =>
    new SignJWT({ sub, role: 'authenticated' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuer(ISSUER)
      .setAudience('authenticated')
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(new TextEncoder().encode(SECRET));

  const seed = async (trx: Database, role: 'OWNER' | 'VIEWER') => {
    const id = randomUUID();
    await sql`
      insert into auth.users (id, instance_id, aud, role, email, encrypted_password, created_at, updated_at)
      values (${id}::uuid, '00000000-0000-0000-0000-000000000000'::uuid, 'authenticated',
              'authenticated', ${`${id}@example.com`}, 'x', now(), now())
    `.execute(trx);
    await trx.updateTable('user_profiles').set({ role }).where('user_id', '=', id).execute();
    return id;
  };

  it('refuses a VIEWER on every admin route, not just the first', async () => {
    // Each admin route calls requireAdmin by hand, so any one of them could lose the call
    // silently. Testing only /sync/market would not notice.
    await withRollback(db, async (trx) => {
      const viewer = await seed(trx, 'VIEWER');
      const { app } = await build(trx, {
        AUTH_MODE: 'jwt',
        JWT_SECRET: SECRET,
        SUPABASE_URL: 'http://127.0.0.1:54321',
      });
      const token = `Bearer ${await sign(viewer)}`;
      const admin: Array<[string, Record<string, unknown>]> = [
        ['/api/sync/market', {}],
        ['/api/sync/news', {}],
        ['/api/sync/fundamentals', {}],
        ['/api/jobs/signals.expire/run', {}],
        ['/api/ai/analyze', { symbol: 'RELIANCE' }],
        ['/api/ai/regenerate', { symbol: 'RELIANCE' }],
      ];
      for (const [url, payload] of admin) {
        const r = await app.inject({
          method: 'POST',
          url,
          payload,
          headers: { authorization: token },
        });
        expect(r.statusCode, url).toBe(403);
      }
      // Q&A is not admin-only (PRD §12 marks it without †), so a VIEWER may ask.
      const qa = await app.inject({
        method: 'POST',
        url: '/api/stocks/RELIANCE/qa',
        payload: { question: 'why?' },
        headers: { authorization: token },
      });
      expect(qa.statusCode).not.toBe(403);
    });
  });

  it('lets an OWNER sync but refuses a VIEWER', async () => {
    await withRollback(db, async (trx) => {
      const viewer = await seed(trx, 'VIEWER');
      const owner = await seed(trx, 'OWNER');
      const { app } = await build(trx, {
        AUTH_MODE: 'jwt',
        JWT_SECRET: SECRET,
        SUPABASE_URL: 'http://127.0.0.1:54321',
      });
      const call = async (id: string) =>
        (
          await app.inject({
            method: 'POST',
            url: '/api/sync/market',
            payload: {},
            headers: { authorization: `Bearer ${await sign(id)}` },
          })
        ).statusCode;
      expect(await call(owner)).toBe(202);
      // A VIEWER may read the research desk but not spend provider quota on it.
      expect(await call(viewer)).toBe(403);
    });
  });
});
