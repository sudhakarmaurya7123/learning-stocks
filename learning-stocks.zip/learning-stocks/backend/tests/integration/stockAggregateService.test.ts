import { afterAll, describe, expect, it } from 'vitest';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { LLMProvider } from '../../src/providers/llm/types.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { StockAggregateService } from '../../src/services/StockAggregateService.js';
import { createTestDb, isolateTables, silentLogger, withRollback } from './helpers.js';
import type { Database } from '../../src/database/db.js';

const db = createTestDb();
afterAll(() => db.destroy());

const serviceOver = (trx: Database, llmProvider?: LLMProvider | null, now?: () => Date) => {
  const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
    db: trx,
    logger: silentLogger,
    ...(llmProvider === undefined ? {} : { llmProvider }),
  });
  return new StockAggregateService({
    ...(now === undefined ? {} : { now }),
    stocks: container.repositories.stocks,
    marketData: container.repositories.marketData,
    technicalIndicators: container.repositories.technicalIndicators,
    fundamentals: container.repositories.fundamentals,
    evaluations: container.repositories.evaluations,
    news: container.repositories.news,
    analyses: container.repositories.stockAnalyses,
    signals: container.repositories.tradeSignals,
    markets: container.repositories.markets,
    summaries: container.repositories.marketSummaries,
    settings: container.repositories.settings,
    sessions: container.services.calendar,
    dataMode: container.config.dataMode,
    logger: silentLogger,
  });
};

describe('StockAggregateService', () => {
  it('assembles every PRD §12 section for a loaded stock', async () => {
    await withRollback(db, async (trx) => {
      const a = await serviceOver(trx).build('RELIANCE');
      // The aggregate key set is the contract Phase 10 renders against: a renamed or dropped
      // section must fail here rather than in the browser.
      expect(Object.keys(a ?? {}).sort()).toEqual([
        'ai_analysis',
        'data_freshness',
        'decision',
        'fundamental',
        'market_context',
        'news',
        'performance',
        'quote',
        'sentiment',
        'signal',
        'stock',
        'technical',
        'valuation',
      ]);
      expect(a?.stock).toMatchObject({ symbol: 'RELIANCE', exchange: 'NSE' });
      expect(a?.quote).toMatchObject({ price: expect.any(Number), ts: expect.any(String) });
      expect(a?.decision).toMatchObject({ action_state: expect.any(String) });
    });
  });

  it('returns null for an unknown symbol, so the route can 404', async () => {
    await withRollback(db, async (trx) => {
      expect(await serviceOver(trx).build('NOSUCHSTOCK')).toBeNull();
    });
  });

  it('is case-insensitive on the symbol', async () => {
    await withRollback(db, async (trx) => {
      expect((await serviceOver(trx).build('reliance'))?.stock.symbol).toBe('RELIANCE');
    });
  });

  it('keeps the other sections when fundamentals, news, analysis and signals are absent', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(
        trx,
        'fundamental_snapshots',
        'financial_statements',
        'news_ai_analysis',
        'news_mentions',
        'news',
        'ai_trade_signals',
        'stock_ai_analysis',
      );
      const a = await serviceOver(trx).build('RELIANCE');
      // PRD §17: every section fails independently. One missing input must not take the page down.
      expect(a?.stock.symbol).toBe('RELIANCE');
      expect(a?.quote).not.toBeNull();
      expect(a?.decision).not.toBeNull();
      expect(a?.fundamental).toBeNull();
      expect(a?.ai_analysis).toBeNull();
      expect(a?.signal).toBeNull();
      expect(a?.news).toEqual([]);
    });
  });

  it('never calls the LLM provider', async () => {
    // The point of the whole service: this is a page-load path. StockContextService embeds the
    // query through the retriever, so an aggregate built on it would charge for every dashboard
    // refresh — PRD §14's first rule is that the LLM is never called on page load.
    await withRollback(db, async (trx) => {
      let calls = 0;
      const throwing: LLMProvider = {
        name: 'throwing',
        chatModel: 'throwing-chat',
        embeddingModel: 'throwing-embed',
        embeddingDimensions: 1536,
        embed: async () => {
          calls += 1;
          throw new Error('embed called while building the aggregate');
        },
        completeStructured: async () => {
          calls += 1;
          throw new Error('completeStructured called while building the aggregate');
        },
      };
      const a = await serviceOver(trx, throwing).build('RELIANCE');
      expect(a).not.toBeNull();
      expect(calls).toBe(0);
    });
  });

  it('degrades a section that throws to null instead of failing the page', async () => {
    // The empty-table case above covers "no rows yet". This covers the other failure: a query
    // that errors (a dropped connection, a permission change). Letting it propagate would turn
    // one broken panel into a blank dashboard, which PRD §17 forbids.
    await withRollback(db, async (trx) => {
      const service = serviceOver(trx);
      const broken = {
        latestSnapshot: async () => {
          throw new Error('fundamentals query failed');
        },
        listStatements: async () => {
          throw new Error('statements query failed');
        },
      };
      // Replace just the fundamentals repository on the constructed service.
      Object.assign(service as unknown as { deps: Record<string, unknown> }, {
        deps: {
          ...(service as unknown as { deps: Record<string, unknown> }).deps,
          fundamentals: broken,
        },
      });
      const a = await service.build('RELIANCE');
      expect(a).not.toBeNull();
      expect(a?.fundamental).toBeNull();
      // Everything else still resolved.
      expect(a?.quote).not.toBeNull();
      expect(a?.decision).not.toBeNull();
    });
  });

  it('reports an unavailable performance window as null, never 0 %', async () => {
    // 0 % means "the price did not move"; null means "we cannot compute this". Showing 0 % for a
    // stock with no history would read as a flat year rather than as missing data.
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const a = await serviceOver(trx).build('RELIANCE');
      expect(a).not.toBeNull();
      expect(a?.quote).toBeNull();
      expect(a?.performance['1d']).toBeNull();
      expect(a?.performance['1y']).toBeNull();
    });
  });

  it('reports per-section freshness', async () => {
    await withRollback(db, async (trx) => {
      const a = await serviceOver(trx).build('RELIANCE');
      expect(a?.data_freshness.quote).toMatchObject({ market_open: expect.any(Boolean) });
      expect(a?.data_freshness).toHaveProperty('evaluation');
      expect(a?.data_freshness).toHaveProperty('fundamental');
      expect(a?.data_freshness).toHaveProperty('ai_analysis');
    });
  });

  it('computes performance windows from stored bars, with null when history is short', async () => {
    await withRollback(db, async (trx) => {
      const a = await serviceOver(trx).build('RELIANCE');
      expect(a?.performance).toMatchObject({
        '1d': expect.anything(),
        '1w': expect.anything(),
        '1y': expect.anything(),
      });
      // Percentages, not prices: a 1-day return of 1.3 means 1.3 %.
      const oneDay = a?.performance['1d'];
      if (oneDay !== null && oneDay !== undefined) expect(Math.abs(oneDay)).toBeLessThan(100);
    });
  });

  /**
   * Phase 9 finding I2.
   *
   * With the market shut, the newest price IS the base close, so the return arithmetic yields
   * exactly 0 — rendering "0.00%" on a Sunday, which a reader takes as "flat trading day" rather
   * than "the market did not open". The windows are seeded here rather than read from whatever
   * the dev worker last wrote, so the assertions mean something after `db:reset`.
   */
  describe('1-day performance (Phase 9 finding I2)', () => {
    /** Daily closes on the three sessions before Sunday 2026-10-11, plus an optional live tick. */
    async function seedWeek(
      trx: Database,
      intradayOn?: { ts: Date; close: number },
    ): Promise<void> {
      await isolateTables(trx, 'market_data');
      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      if (!stock) throw new Error('seed precondition failed: no RELIANCE');
      const instrument = { kind: 'stock', id: stock.id } as const;
      const daily = [
        // Far enough back that the 1-week window (cutoff ~Oct 4) has a base bar at or before it;
        // without this the week's return is correctly null for lack of history, which would make
        // the "longer window still measurable" assertion test nothing.
        { ts: new Date('2026-10-01T03:45:00Z'), close: 980 },
        { ts: new Date('2026-10-02T03:45:00Z'), close: 1000 },
        { ts: new Date('2026-10-07T03:45:00Z'), close: 1000 },
        { ts: new Date('2026-10-08T03:45:00Z'), close: 1010 },
        { ts: new Date('2026-10-09T03:45:00Z'), close: 1020 },
      ];
      const bar = (ts: Date, close: number, timeframe: '1d' | '5m') => ({
        instrument,
        dataMode: 'MOCK' as const,
        timeframe,
        ts,
        open: close,
        high: close,
        low: close,
        close,
        adjustedClose: close,
        volume: 1000,
        change: null,
        changePercent: null,
        vwap: null,
        source: 'mock',
      });
      await new MarketDataRepository(trx).insertBars([
        ...daily.map((d) => bar(d.ts, d.close, '1d')),
        ...(intradayOn === undefined ? [] : [bar(intradayOn.ts, intradayOn.close, '5m')]),
      ]);
    }

    it('is null on a Sunday, because no session happened', async () => {
      await withRollback(db, async (trx) => {
        await seedWeek(trx);
        // Sunday 2026-10-11, 12:00 IST. Friday's close is both the newest price and the base.
        const a = await serviceOver(trx, undefined, () => new Date('2026-10-11T06:30:00Z')).build(
          'RELIANCE',
        );
        expect(a?.performance['1d']).toBeNull();
      });
    });

    it('is null before the open, when today has produced no price yet', async () => {
      await withRollback(db, async (trx) => {
        await seedWeek(trx);
        // Monday 2026-10-12, 08:00 IST: a session is coming but nothing has traded.
        const a = await serviceOver(trx, undefined, () => new Date('2026-10-12T02:30:00Z')).build(
          'RELIANCE',
        );
        expect(a?.performance['1d']).toBeNull();
      });
    });

    it('is measurable mid-session from a live tick newer than the last daily bar', async () => {
      await withRollback(db, async (trx) => {
        // Monday 11:30 IST with a 5m bar at 11:25. No daily bar exists for today yet — they land
        // after close + settle — so a rule that looked for a daily bar after the cutoff would
        // null this out and hide a real intraday move.
        await seedWeek(trx, { ts: new Date('2026-10-12T05:55:00Z'), close: 1040 });
        const a = await serviceOver(trx, undefined, () => new Date('2026-10-12T06:00:00Z')).build(
          'RELIANCE',
        );
        // (1040 - 1020) / 1020 = 1.96 %, measured against Friday's close.
        expect(a?.performance['1d']).toBeCloseTo(1.96, 1);
      });
    });

    it('agrees with the quote the page header shows', async () => {
      await withRollback(db, async (trx) => {
        await seedWeek(trx, { ts: new Date('2026-10-12T05:55:00Z'), close: 1040 });
        const a = await serviceOver(trx, undefined, () => new Date('2026-10-12T06:00:00Z')).build(
          'RELIANCE',
        );
        // Two panels disagreeing about today's move is worse than either being absent.
        expect(a?.quote?.price).toBe(1040);
        expect(a?.performance['1d']).not.toBeNull();
      });
    });

    it('keeps a longer window measurable on a day with no session', async () => {
      await withRollback(db, async (trx) => {
        await seedWeek(trx);
        const a = await serviceOver(trx, undefined, () => new Date('2026-10-11T06:30:00Z')).build(
          'RELIANCE',
        );
        // The 1-week window spans real sessions, so it is still a fact: (1020-1000)/1000 = 2 %.
        expect(a?.performance['1w']).toBeCloseTo(2, 1);
      });
    });
  });
});
