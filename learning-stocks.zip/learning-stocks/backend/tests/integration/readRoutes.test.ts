import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer, type Container } from '../../src/container.js';
import { createTestDb, silentLogger } from './helpers.js';

const db = createTestDb();
let app: FastifyInstance;
let container: Container;

beforeAll(async () => {
  container = createContainer(loadConfig({ AUTH_MODE: 'none' }), { db, logger: silentLogger });
  app = await buildApp(container);
  await app.ready();
});
afterAll(async () => {
  await app.close();
  await container.close();
  await db.destroy();
});

const get = (url: string) => app.inject({ method: 'GET', url });

describe('market reads', () => {
  it('lists index cards with their latest quote', async () => {
    const r = await get('/api/markets');
    expect(r.statusCode).toBe(200);
    const body = r.json();
    expect(body.meta).toMatchObject({ data_mode: 'MOCK' });
    expect(body.data.map((m: { symbol: string }) => m.symbol)).toContain('NIFTY50');
    const nifty = body.data.find((m: { symbol: string }) => m.symbol === 'NIFTY50');
    expect(nifty).toMatchObject({ name: expect.any(String), quote: expect.anything() });
  });

  it('reports market status in IST with the next open', async () => {
    const r = await get('/api/market-status');
    expect(r.statusCode).toBe(200);
    expect(r.json().data).toMatchObject({
      exchange: 'NSE',
      is_open: expect.any(Boolean),
      phase: expect.stringMatching(/^(OPEN|CLOSED|WEEKEND|HOLIDAY)$/),
    });
  });

  it('returns the latest market AI summary, or null when there is none', async () => {
    const r = await get('/api/market-summary');
    expect(r.statusCode).toBe(200);
    // 200 with null, never 404: "no summary yet" is a normal state on a fresh database.
    expect(r.json()).toHaveProperty('data');
  });
});

describe('stock list', () => {
  it('lists stocks with their latest evaluation', async () => {
    const r = await get('/api/stocks');
    expect(r.statusCode).toBe(200);
    const symbols = r.json().data.map((s: { symbol: string }) => s.symbol);
    expect(symbols).toContain('RELIANCE');
  });

  it('filters by query, sector and action state, and rejects an unknown state', async () => {
    const q = await get('/api/stocks?query=RELI');
    expect(q.json().data.map((s: { symbol: string }) => s.symbol)).toContain('RELIANCE');

    const all = await get('/api/stocks');
    const sector = all
      .json()
      .data.map((s: { sector: string | null }) => s.sector)
      .find((v: string | null) => v !== null);
    const bySector = await get(`/api/stocks?sector=${encodeURIComponent(String(sector))}`);
    expect(bySector.statusCode).toBe(200);
    expect(bySector.json().data.every((s: { sector: string | null }) => s.sector === sector)).toBe(
      true,
    );

    expect((await get('/api/stocks?action=HOLD')).statusCode).toBe(200);
    // A misspelled filter must fail loudly rather than be ignored and return everything.
    expect((await get('/api/stocks?action=NOT_A_STATE')).statusCode).toBe(400);
    expect((await get('/api/stocks?nonsense=1')).statusCode).toBe(400);
  });
});

describe('per-stock reads', () => {
  it('resolves a symbol case-insensitively and 404s an unknown one', async () => {
    expect((await get('/api/stocks/reliance/quote')).statusCode).toBe(200);
    const missing = await get('/api/stocks/NOSUCHSTOCK/quote');
    expect(missing.statusCode).toBe(404);
    expect(missing.json()).toMatchObject({ error: { code: 'NOT_FOUND' } });
  });

  it('caches a quote for the TTL (PRD §14), keyed per symbol', async () => {
    // Counting repository calls, not comparing payloads: the same row yields the same response
    // with or without a cache, so a payload comparison would pass either way.
    // Clear first: earlier cases in this file already requested these quotes, so a shared cache
    // would make the counts start from zero and the assertion meaningless.
    container.cache.deleteByPrefix('quote:');
    let reads = 0;
    const repo = container.repositories.marketData;
    const real = repo.latestQuote.bind(repo);
    repo.latestQuote = async (ref, m) => {
      reads += 1;
      return real(ref, m);
    };
    try {
      expect((await get('/api/stocks/RELIANCE/quote')).statusCode).toBe(200);
      expect(reads).toBe(1);
      expect((await get('/api/stocks/reliance/quote')).statusCode).toBe(200);
      expect(reads).toBe(1);
      // A different symbol is a different key.
      expect((await get('/api/stocks/TCS/quote')).statusCode).toBe(200);
      expect(reads).toBe(2);
    } finally {
      repo.latestQuote = real;
    }
  });

  it('carries freshness in meta on a quote', async () => {
    const r = await get('/api/stocks/RELIANCE/quote');
    expect(r.json().meta.freshness).toMatchObject({
      market_open: expect.any(Boolean),
      stale: expect.any(Boolean),
    });
  });

  it('serves history and validates range against interval', async () => {
    const ok = await get('/api/stocks/RELIANCE/history?range=1Y&interval=1d');
    expect(ok.statusCode).toBe(200);
    expect(Array.isArray(ok.json().data.bars)).toBe(true);
    // 5m bars only exist for the last ~60 days (Phase 3's provider limit), so a 5Y request for
    // them cannot be served honestly — better a 400 than a silently truncated chart.
    expect((await get('/api/stocks/RELIANCE/history?range=5Y&interval=5m')).statusCode).toBe(400);
    expect((await get('/api/stocks/RELIANCE/history?range=10Y')).statusCode).toBe(400);
  });

  it('answers every per-stock read with 200, even when a section has no data', async () => {
    // PRD §17: missing fundamentals, news or AI analysis is a normal state, not an error. A 500
    // here would blank the dashboard for a stock that simply has not been analysed yet.
    for (const path of [
      'technical',
      'fundamentals',
      'evaluation',
      'news',
      'sentiment',
      'analysis',
      'ai-summary',
    ]) {
      const r = await get(`/api/stocks/RELIANCE/${path}`);
      expect(r.statusCode, path).toBe(200);
      expect(r.json(), path).toHaveProperty('data');
    }
  });

  it('404s every per-stock read for an unknown symbol', async () => {
    for (const path of ['technical', 'fundamentals', 'evaluation', 'news', 'analysis']) {
      const r = await get(`/api/stocks/NOPE/${path}`);
      expect(r.statusCode, path).toBe(404);
    }
  });
});
