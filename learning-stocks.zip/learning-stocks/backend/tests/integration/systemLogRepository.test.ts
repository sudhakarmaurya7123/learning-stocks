import { randomUUID } from 'node:crypto';
import { afterAll, describe, expect, it } from 'vitest';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { AppError } from '../../src/utils/errors.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('SystemLogRepository', () => {
  it('records a job run from start to finish with counts', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const runId = await repo.startRun({
        service: 'MarketDataService',
        jobName: 'market.sync.intraday',
        operation: 'sync',
      });
      expect((await repo.recentRuns(1))[0]).toMatchObject({ id: runId, status: 'STARTED' });

      await repo.finishRun(runId, {
        status: 'PARTIAL',
        counts: { fetched: 100, inserted: 95, skipped: 2, failed: 3 },
        message: '3 symbols failed',
      });
      const [run] = await repo.recentRuns(1);
      expect(run).toMatchObject({
        status: 'PARTIAL',
        recordsFetched: 100,
        recordsInserted: 95,
        recordsSkipped: 2,
        recordsFailed: 3,
        recordsProcessed: 100,
        message: '3 symbols failed',
      });
      expect(run?.finishedAt).toBeInstanceOf(Date);
      expect(run?.executionTimeMs).toBeGreaterThanOrEqual(0);
    });
  });

  it('stores structured error details without secrets-bearing URLs', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const runId = await repo.startRun({
        service: 'NewsService',
        jobName: 'news.sync',
        operation: 'sync',
      });
      const error = new AppError(
        'AUTH_FAILED',
        'Authentication failed calling https://newsapi.org/v2/everything',
        { details: { status: 401 } },
      );
      await repo.finishRun(runId, {
        status: 'FAILED',
        counts: { fetched: 0, inserted: 0, skipped: 0, failed: 1 },
        error,
      });
      const [run] = await repo.recentRuns(1);
      expect(run?.errorDetails).toMatchObject({ code: 'AUTH_FAILED', details: { status: 401 } });
    });
  });

  it('rejects finishing an unknown run', async () => {
    await withRollback(db, async (trx) => {
      await expect(
        new SystemLogRepository(trx).finishRun('00000000-0000-0000-0000-000000000000', {
          status: 'SUCCESS',
          counts: { fetched: 0, inserted: 0, skipped: 0, failed: 0 },
        }),
      ).rejects.toMatchObject({ code: 'NOT_FOUND' });
    });
  });

  it('orders runs started in the same transaction newest first', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      await repo.startRun({ service: 's', jobName: 'j', operation: 'first' });
      const second = await repo.startRun({ service: 's', jobName: 'j', operation: 'second' });
      expect((await repo.recentRuns(1))[0]?.id).toBe(second);
    });
  });

  it('stores structured run details, alone or alongside an error', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const a = await repo.startRun({
        service: 'MarketDataService',
        jobName: 'cli.sync-market',
        operation: 'sync:1d',
      });
      await repo.finishRun(a, {
        status: 'PARTIAL',
        counts: { fetched: 10, inserted: 8, skipped: 1, failed: 1 },
        details: { failures: [{ symbol: 'TCS', code: 'UNSUPPORTED' }] },
      });
      expect((await repo.recentRuns(1))[0]?.errorDetails).toEqual({
        failures: [{ symbol: 'TCS', code: 'UNSUPPORTED' }],
      });
    });
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const b = await repo.startRun({
        service: 'MarketDataService',
        jobName: 'cli.sync-market',
        operation: 'sync:1d',
      });
      await repo.finishRun(b, {
        status: 'FAILED',
        counts: { fetched: 0, inserted: 0, skipped: 0, failed: 0 },
        error: new AppError('UNSUPPORTED', 'no 1m'),
        details: { timeframe: '1m' },
      });
      expect((await repo.recentRuns(1))[0]?.errorDetails).toMatchObject({
        code: 'UNSUPPORTED',
        context: { timeframe: '1m' },
      });
    });
  });
  it('amends a finished run’s verdict without touching its counts', async () => {
    await withRollback(db, async (trx) => {
      const repo = new SystemLogRepository(trx);
      const id = await repo.startRun({
        service: 'MarketDataService',
        jobName: 'market.sync.eod',
        operation: 'sync:1d',
      });
      await repo.finishRun(id, {
        status: 'SUCCESS',
        counts: { fetched: 10, inserted: 8, skipped: 2, failed: 0 },
        message: 'ok',
      });
      await repo.amendRun(id, {
        status: 'PARTIAL',
        message: 'no settled daily bar for 2026-10-06',
      });
      const [row] = await repo.recentRuns(1);
      expect(row).toMatchObject({ id, status: 'PARTIAL', recordsInserted: 8, recordsSkipped: 2 });
      expect(row?.message).toMatch(/no settled daily bar/);
      expect(row?.finishedAt).not.toBeNull();
      await expect(
        repo.amendRun(randomUUID(), { status: 'FAILED', message: 'x' }),
      ).rejects.toMatchObject({ code: 'NOT_FOUND' });
    });
  });
});
