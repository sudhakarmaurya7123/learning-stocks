import { afterAll, describe, expect, it } from 'vitest';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

describe('ProviderSymbolRepository', () => {
  it('lists all active instruments for a provider, stocks first', async () => {
    const rows = await new ProviderSymbolRepository(db).listByProvider('yahoo');
    expect(rows).toHaveLength(32);
    expect(rows[0]).toMatchObject({
      kind: 'stock',
      symbol: 'ADANIENT',
      providerSymbol: 'ADANIENT.NS',
      exchange: 'NSE',
    });
    expect(rows.find((r) => r.symbol === 'SENSEX')).toMatchObject({
      kind: 'market',
      providerSymbol: '^BSESN',
      exchange: 'BSE',
    });
  });

  it('filters by internal symbols', async () => {
    const rows = await new ProviderSymbolRepository(db).listByProvider('yahoo', [
      'RELIANCE',
      'NIFTY50',
    ]);
    expect(rows.map((r) => r.providerSymbol)).toEqual(['RELIANCE.NS', '^NSEI']);
  });

  it('sets the verified flag and rejects unknown symbols', async () => {
    await withRollback(db, async (trx) => {
      const repo = new ProviderSymbolRepository(trx);
      await repo.setVerified('yahoo', 'RELIANCE.NS', true);
      expect((await repo.listByProvider('yahoo', ['RELIANCE']))[0]?.verified).toBe(true);
      await expect(repo.setVerified('yahoo', 'NOPE.NS', true)).rejects.toMatchObject({
        code: 'NOT_FOUND',
      });
    });
  });
});
