import { sql } from 'kysely';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { EvaluationRepository } from '../../src/repositories/EvaluationRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { TradeSignalRepository } from '../../src/repositories/TradeSignalRepository.js';
import { TradeSignalService } from '../../src/services/ai/TradeSignalService.js';
import { AppError } from '../../src/utils/errors.js';
import { aiDeps, NOW, seedPipeline, silent } from './aiFixtures.js';
import { createTestDb, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

function service(
  trx: Database,
  sessions: Awaited<ReturnType<typeof seedPipeline>>['sessions'],
  now: Date,
  options: Parameters<typeof aiDeps>[2] = {},
) {
  const d = aiDeps(trx, now, options);
  return new TradeSignalService({
    stocks: new StockRepository(trx),
    evaluations: new EvaluationRepository(trx),
    analyses: d.analyses,
    signals: new TradeSignalRepository(trx),
    context: d.context,
    gateway: d.gateway,
    sessions,
    systemLogs: new SystemLogRepository(trx),
    dataMode: 'MOCK',
    logger: silent,
    now: () => now,
  });
}

/** Turn RELIANCE's latest evaluation into a BUY_ZONE with known levels. */
async function buyZone(trx: Database, rel: string) {
  const ev = await new EvaluationRepository(trx).latestDetail(rel, 'MOCK');
  await trx
    .updateTable('stock_evaluations')
    .set({
      action_state: 'BUY_ZONE',
      recommendation_bias: 'BUY_BIAS',
      entry_low: 1150,
      entry_high: 1165,
      stop_loss: 1110,
      target_1: 1240,
      target_2: 1300,
      risk_reward: 2.1,
      position_size_hint: 200,
    })
    .where('id', '=', ev?.id ?? '')
    .execute();
  return ev?.id ?? '';
}

describe('TradeSignalService', () => {
  it('creates one ACTIVE BUY signal per evaluation with code-derived levels, valid until the next session close', async () => {
    await withRollback(db, async (trx) => {
      const { rel, sessions } = await seedPipeline(trx);
      const evId = await buyZone(trx, rel);
      const r = await service(trx, sessions, NOW).run({
        jobName: 'test',
        symbols: ['RELIANCE', 'HDFCBANK'],
      });
      expect(r.created).toBe(1);
      const [s] = await new TradeSignalRepository(trx).active(rel, 'MOCK');
      expect(s).toMatchObject({
        signal: 'BUY',
        evaluationId: evId,
        entryLow: 1150,
        entryHigh: 1165,
        entryPrice: 1157.5,
        stopLoss: 1110,
        targetPrice: 1240,
        target2: 1300,
        riskRewardRatio: 2.1,
        suggestedQuantity: 200,
        validUntil: new Date('2026-10-06T10:00:00Z'),
      });
      expect(s?.reasoning.join(' ')).toContain('[MOCK]');
      const again = await service(trx, sessions, NOW).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(again.results[0]?.outcome).toBe('EXISTS');
      expect(await trx.selectFrom('paper_orders').select('id').execute()).toEqual([]); // never trades
    });
  });

  it('invalidates a signal when a newer evaluation exists, and expires it after valid_until', async () => {
    await withRollback(db, async (trx) => {
      const { rel, sessions } = await seedPipeline(trx);
      const evId = await buyZone(trx, rel);
      await service(trx, sessions, NOW).run({ jobName: 'test', symbols: ['RELIANCE'] });
      await sql`insert into public.stock_evaluations
                  (stock_id, data_mode, data_as_of, scoring_config_version, action_state, valuation_label, factors_available, inputs, input_hash, evaluated_at)
                select stock_id, data_mode, data_as_of, scoring_config_version, 'HOLD', valuation_label, factors_available, inputs, 'newer', clock_timestamp() + interval '1 second'
                  from public.stock_evaluations where id = ${evId}`.execute(trx);
      const r = await service(trx, sessions, NOW).run({ jobName: 'test', symbols: ['RELIANCE'] });
      expect(r).toMatchObject({ invalidated: 1, created: 0 });
      expect(r.results[0]?.outcome).toBe('NONE');

      await trx.updateTable('ai_trade_signals').set({ status: 'ACTIVE' }).execute();
      const later = await service(trx, sessions, new Date('2026-10-07T00:00:00Z')).run({
        jobName: 'test',
        symbols: [],
      });
      expect(later.expired).toBe(1);
    });
  });

  it('still creates the signal with deterministic reasoning when the budget is exhausted', async () => {
    await withRollback(db, async (trx) => {
      const { rel, sessions } = await seedPipeline(trx);
      await buyZone(trx, rel);
      const budget = {
        ensure: async () => {
          throw new AppError('BUDGET_EXCEEDED', 'budget');
        },
      };
      const r = await service(trx, sessions, NOW, { budget }).run({
        jobName: 'test',
        symbols: ['RELIANCE'],
      });
      expect(r).toMatchObject({ created: 1, narrativeFallbacks: 1 });
      const [s] = await new TradeSignalRepository(trx).active(rel, 'MOCK');
      expect(s?.reasoning[0]).toMatch(/^Computed action state BUY_ZONE/);
    });
  });
});
