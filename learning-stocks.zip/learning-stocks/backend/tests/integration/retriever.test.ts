import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import { hashEmbedding } from '../../src/providers/llm/mock/hashEmbedding.js';
import { MockLLMProvider } from '../../src/providers/llm/mock/MockLLMProvider.js';
import type { EmbeddingResult } from '../../src/providers/llm/types.js';
import { sha256Hex } from '../../src/rag/documents.js';
import { Retriever } from '../../src/rag/retriever.js';
import {
  EmbeddingRepository,
  type EmbeddingRow,
} from '../../src/repositories/EmbeddingRepository.js';
import { LlmCallRepository } from '../../src/repositories/LlmCallRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { AppError } from '../../src/utils/errors.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const NOW = new Date('2026-10-06T06:00:00Z');
const daysAgo = (d: number) => new Date(NOW.getTime() - d * 86_400_000);
let n = 0;
const uuid = () => `00000000-0000-4000-8000-${String((n += 1)).padStart(12, '0')}`;

class CountingProvider extends MockLLMProvider {
  embeds = 0;
  override async embed(texts: readonly string[]): Promise<EmbeddingResult> {
    this.embeds += 1;
    return super.embed(texts);
  }
}

async function seed(trx: Database) {
  await isolateTables(trx, 'document_embeddings', 'llm_calls');
  const stocks = new StockRepository(trx);
  const rel = (await stocks.findBySymbol('RELIANCE'))?.id ?? '';
  const tcs = (await stocks.findBySymbol('TCS'))?.id ?? '';
  const row = (content: string, over: Partial<EmbeddingRow>): EmbeddingRow => ({
    dataMode: 'MOCK',
    sourceType: 'NEWS',
    sourceId: uuid(),
    stockId: rel,
    chunkIndex: 0,
    content,
    contentHash: sha256Hex(content),
    embedding: hashEmbedding(content),
    embeddingModel: 'mock-hash-embedding-v1',
    metadata: { relevance: 0.9 },
    publishedAt: daysAgo(2),
    ...over,
  });
  await new EmbeddingRepository(trx).upsertChunks([
    row('Reliance retail expansion adds new stores', {}),
    row('Reliance retail expansion old story', { publishedAt: daysAgo(200) }),
    row('RELIANCE (Reliance Industries Ltd): annual results for the year ended 31 Mar 2026', {
      sourceType: 'FINANCIALS',
      publishedAt: daysAgo(300),
      metadata: {},
    }),
    row('TCS retail deal', { stockId: tcs }),
    row('Sensex rallies as retail stocks gain', { stockId: null, metadata: { relevance: 0.9 } }),
    row('Nifty retail stocks extend rally', { stockId: null, metadata: { relevance: 0.9 } }),
    row('Retail stocks lift Bank Nifty and Sensex', {
      stockId: null,
      metadata: { relevance: 0.9 },
    }),
    row('Retail stocks gain as India VIX eases', { stockId: null, metadata: { relevance: 0.9 } }),
    row('Reliance retail expansion adds new stores', { embeddingModel: 'other-model' }),
    row('Reliance retail expansion adds new stores', { dataMode: 'LIVE' }),
  ]);
  return { rel };
}

function retriever(trx: Database, provider = new CountingProvider(), cache = new MemoryCache()) {
  return new Retriever({
    provider,
    embeddings: new EmbeddingRepository(trx),
    llmCalls: new LlmCallRepository(trx),
    cache,
    dataMode: 'MOCK',
    usdInrRate: 88,
    now: () => NOW,
  });
}

describe('Retriever', () => {
  it('returns the stock’s recent news and financials (longer window), scoped by mode, model and stock', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const docs = await retriever(trx).retrieve({
        query: 'Reliance retail expansion stores',
        stockId: rel,
      });
      expect(docs.map((d) => d.content).sort()).toEqual([
        'RELIANCE (Reliance Industries Ltd): annual results for the year ended 31 Mar 2026',
        'Reliance retail expansion adds new stores',
      ]);
      expect(docs[0]?.content).toBe('Reliance retail expansion adds new stores');
      expect(docs.every((d) => d.stockId === rel)).toBe(true);
    });
  });

  it('adds market-level documents only when asked', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const docs = await retriever(trx).retrieve({
        query: 'retail stocks',
        stockId: rel,
        includeMarket: true,
      });
      expect(docs.map((d) => d.content)).toContain('Sensex rallies as retail stocks gain');
      // Market-level news never crowds out the stock's own documents.
      expect(docs.filter((d) => d.stockId === null)).toHaveLength(2);
    });
  });

  it('can restrict retrieval to news', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const docs = await retriever(trx).retrieve({
        query: 'Reliance annual results',
        stockId: rel,
        sourceTypes: ['NEWS'],
      });
      expect(docs.length).toBeGreaterThan(0);
      expect(docs.every((d) => d.sourceType === 'NEWS')).toBe(true);
    });
  });

  it('embeds a repeated query once (cache) and records the query-embedding call', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const provider = new CountingProvider();
      const r = retriever(trx, provider);
      await r.retrieve({ query: 'Reliance outlook', stockId: rel });
      await r.retrieve({ query: 'Reliance outlook', stockId: rel });
      expect(provider.embeds).toBe(1);
      const calls = await trx.selectFrom('llm_calls').select(['purpose', 'status']).execute();
      expect(calls).toEqual([{ purpose: 'query_embedding', status: 'OK' }]);
    });
  });

  it('returns the same documents in the same order a day later (stable context hash)', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const cache = new MemoryCache();
      const at = (now: Date) =>
        new Retriever({
          provider: new CountingProvider(),
          embeddings: new EmbeddingRepository(trx),
          llmCalls: new LlmCallRepository(trx),
          cache,
          dataMode: 'MOCK',
          usdInrRate: 88,
          now: () => now,
        }).retrieve({ query: 'Reliance retail expansion', stockId: rel, includeMarket: true });
      const today = await at(NOW);
      const tomorrow = await at(new Date(NOW.getTime() + 86_400_000));
      expect(tomorrow.map((d) => d.id)).toEqual(today.map((d) => d.id));
    });
  });

  it('de-duplicates an article stored for several stocks in market-wide retrieval', async () => {
    await withRollback(db, async (trx) => {
      await seed(trx);
      const stocks = new StockRepository(trx);
      const ids = [
        (await stocks.findBySymbol('INFY'))?.id ?? '',
        (await stocks.findBySymbol('WIPRO'))?.id ?? '',
      ];
      const sourceId = '00000000-0000-4000-8000-00000000abcd';
      const content = 'Infosys and Wipro win a joint outsourcing contract';
      await new EmbeddingRepository(trx).upsertChunks(
        ids.map((stockId) => ({
          dataMode: 'MOCK' as const,
          sourceType: 'NEWS' as const,
          sourceId,
          stockId,
          chunkIndex: 0,
          content,
          contentHash: sha256Hex(content),
          embedding: hashEmbedding(content),
          embeddingModel: 'mock-hash-embedding-v1',
          metadata: { relevance: 0.9 },
          publishedAt: daysAgo(1),
        })),
      );
      const docs = await retriever(trx).retrieve({
        query: 'Infosys Wipro outsourcing contract',
        stockId: null,
      });
      expect(docs.filter((d) => d.sourceId === sourceId)).toHaveLength(1);
    });
  });

  it('checks the budget before embedding a query', async () => {
    await withRollback(db, async (trx) => {
      const { rel } = await seed(trx);
      const provider = new CountingProvider();
      const r = new Retriever({
        provider,
        embeddings: new EmbeddingRepository(trx),
        llmCalls: new LlmCallRepository(trx),
        cache: new MemoryCache(),
        dataMode: 'MOCK',
        usdInrRate: 88,
        now: () => NOW,
        budget: {
          ensure: async () => {
            throw new AppError('BUDGET_EXCEEDED', 'Daily LLM budget reached');
          },
        },
      });
      await expect(r.retrieve({ query: 'anything', stockId: rel })).rejects.toMatchObject({
        code: 'BUDGET_EXCEEDED',
      });
      expect(provider.embeds).toBe(0);
      expect(await trx.selectFrom('llm_calls').select('status').execute()).toEqual([]);
    });
  });
});
