import { afterAll, describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import type { LLMProvider } from '../../src/providers/llm/types.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());

/** Every GET route, with a symbol and query string where one is needed. */
const GET_PATHS = [
  '/api/health',
  '/api/markets',
  '/api/market-status',
  '/api/market-summary',
  '/api/news',
  '/api/stocks',
  '/api/stocks/RELIANCE',
  '/api/stocks/RELIANCE/quote',
  '/api/stocks/RELIANCE/history?range=1M&interval=1d',
  '/api/stocks/RELIANCE/technical',
  '/api/stocks/RELIANCE/fundamentals',
  '/api/stocks/RELIANCE/evaluation',
  '/api/stocks/RELIANCE/news',
  '/api/stocks/RELIANCE/sentiment',
  '/api/stocks/RELIANCE/analysis',
  '/api/stocks/RELIANCE/ai-summary',
  '/api/system-status',
] as const;

/**
 * Full GET paths from Fastify's printed route tree.
 *
 * The tree nests relative segments under their parent, so each line's indentation depth decides
 * which prefix it belongs to. HEAD is registered alongside every GET and is not a separate route.
 */
function fullGetPaths(tree: string): string[] {
  const prefixes: string[] = [];
  const paths: string[] = [];
  for (const line of tree.split('\n')) {
    const match = /^([\s│├└─]*)(\S+)\s*\((.*)\)\s*$/.exec(line);
    if (!match) continue;
    const [, indent, segment, methods] = match;
    if (segment === undefined || methods === undefined) continue;
    const depth = Math.floor((indent?.length ?? 0) / 4);
    prefixes.length = depth;
    prefixes[depth] = segment;
    const full = prefixes.slice(0, depth + 1).join('');
    if (methods.includes('GET') && full.startsWith('/api/')) paths.push(full);
  }
  return paths;
}

describe('no GET route spends money', () => {
  it('answers every read with 200 while an LLM call would throw', async () => {
    // PRD §14's first rule: the LLM is never called on a page load. This is the regression test —
    // a future read route that reaches for the retriever (which embeds its query, and bills for
    // it) fails here rather than on the OpenAI invoice.
    await withRollback(db, async (trx) => {
      let calls = 0;
      const throwing: LLMProvider = {
        name: 'throwing',
        chatModel: 'throwing-chat',
        embeddingModel: 'throwing-embed',
        embeddingDimensions: 1536,
        embed: async () => {
          calls += 1;
          throw new Error('embed called from a GET route');
        },
        completeStructured: async () => {
          calls += 1;
          throw new Error('completeStructured called from a GET route');
        },
      };
      const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
        db: trx,
        logger: silentLogger,
        llmProvider: throwing,
        // No real queue: /system-status reports worker liveness 'unknown' instead of connecting.
        jobQueue: null,
      });
      const app = await buildApp(container);
      await app.ready();

      for (const path of GET_PATHS) {
        const r = await app.inject({ method: 'GET', url: path });
        // 200, not "< 500": a mistyped path would 404 and prove nothing about spending.
        expect(r.statusCode, path).toBe(200);
      }
      expect(calls).toBe(0);
      await app.close();
    });
  });

  it('covers every registered GET route, so a new one cannot slip past untested', async () => {
    // Without this, adding a read route and forgetting to list it above would leave it
    // unprotected while the suite stayed green.
    await withRollback(db, async (trx) => {
      const container = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
        db: trx,
        logger: silentLogger,
      });
      const app = await buildApp(container);
      await app.ready();

      // printRoutes emits a TREE with relative segments — "/quote" nested under "/:symbol" —
      // so full paths have to be rebuilt by depth. Matching the printed fragments directly
      // silently matches nothing, which makes this check pass while covering no route at all.
      const registered = fullGetPaths(app.printRoutes({ commonPrefix: false }));
      expect(registered.length).toBeGreaterThan(10);

      const covered = GET_PATHS.map((p) => p.split('?')[0] ?? p);
      const missing = registered.filter((route) => {
        // A parameterised route is covered when a concrete path matches its shape.
        const pattern = new RegExp(`^${route.replace(/:[^/]+/g, '[^/]+')}$`);
        return !covered.some((path) => pattern.test(path));
      });
      expect(missing, 'GET routes not exercised by the no-spend test').toEqual([]);
      await app.close();
    });
  });
});
