import { Writable } from 'node:stream';
import { afterAll, describe, expect, it } from 'vitest';
import type { Database } from '../../src/database/db.js';
import type { BarInterval } from '../../src/domain/enums.js';
import { MockMarketDataProvider } from '../../src/providers/market/mock/MockMarketDataProvider.js';
import type {
  MarketDataProvider,
  ProviderBar,
  ProviderCapabilities,
  ProviderInstrumentRef,
  ProviderQuote,
} from '../../src/providers/market/types.js';
import { HolidayRepository } from '../../src/repositories/HolidayRepository.js';
import { MarketDataRepository } from '../../src/repositories/MarketDataRepository.js';
import { MarketRepository } from '../../src/repositories/MarketRepository.js';
import { ProviderSymbolRepository } from '../../src/repositories/ProviderSymbolRepository.js';
import { StockRepository } from '../../src/repositories/StockRepository.js';
import { SystemLogRepository } from '../../src/repositories/SystemLogRepository.js';
import { MarketCalendarService } from '../../src/services/MarketCalendarService.js';
import { MarketDataService } from '../../src/services/marketData/MarketDataService.js';
import { MemoryCache } from '../../src/utils/cache.js';
import { AppError } from '../../src/utils/errors.js';
import { createLogger } from '../../src/utils/logger.js';
import { createTestDb, isolateTables, withRollback } from './helpers.js';

const db = createTestDb();
afterAll(() => db.destroy());
const silent = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_c, _e, cb) {
      cb();
    },
  }),
});
const FRIDAY_EVENING = new Date('2026-10-09T17:00:00+05:30');

/** Wraps the mock provider; can fail or inject raw bars for chosen symbols, and records calls. */
class StubProvider implements MarketDataProvider {
  readonly name = 'mock';
  calls: Array<{ symbol: string; from: Date; interval: BarInterval }> = [];
  constructor(
    private readonly inner: MarketDataProvider,
    private readonly behaviour: Record<string, AppError | ProviderBar[]> = {},
    private readonly caps?: Partial<ProviderCapabilities>,
  ) {}
  capabilities(): ProviderCapabilities {
    return { ...this.inner.capabilities(), ...this.caps };
  }
  async getHistorical(
    ref: ProviderInstrumentRef,
    from: Date,
    to: Date,
    interval: BarInterval,
  ): Promise<ProviderBar[]> {
    this.calls.push({ symbol: ref.providerSymbol, from, interval });
    const b = this.behaviour[ref.providerSymbol];
    if (b instanceof AppError) throw b;
    if (b) return b;
    return this.inner.getHistorical(ref, from, to, interval);
  }
  async getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote> {
    return this.inner.getQuote(ref);
  }
}

function build(
  trx: Database,
  now: Date,
  wrap: (mock: MarketDataProvider) => MarketDataProvider = (m) => m,
) {
  const sessions = new MarketCalendarService(new HolidayRepository(trx), new MemoryCache());
  const provider = wrap(new MockMarketDataProvider(sessions, () => now));
  const service = new MarketDataService({
    provider,
    sessions,
    dataMode: 'MOCK',
    logger: silent,
    now: () => now,
    providerSymbols: new ProviderSymbolRepository(trx),
    stocks: new StockRepository(trx),
    markets: new MarketRepository(trx),
    marketData: new MarketDataRepository(trx),
    systemLogs: new SystemLogRepository(trx),
    retry: { sleep: async () => undefined },
  });
  return { service, provider };
}

const range = (from: string, now = FRIDAY_EVENING) => ({ from: new Date(from), to: now });

describe('MarketDataService', () => {
  it('ingests daily bars idempotently, computes change vs previous close, and logs the run', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const { service } = build(trx, FRIDAY_EVENING);
      const first = await service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-09-21T00:00:00+05:30'),
        symbols: ['RELIANCE', 'TCS'],
        includeIndices: false,
      });
      // 15 weekdays (Sep 21 - Oct 9) minus the Oct 2 holiday = 14 trading days x 2 stocks.
      expect(first).toMatchObject({
        status: 'SUCCESS',
        instruments: { total: 2, succeeded: 2, failed: 0 },
        bars: { inserted: 28, duplicates: 0, rejected: 0 },
      });
      const again = await service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-09-21T00:00:00+05:30'),
        symbols: ['RELIANCE', 'TCS'],
        includeIndices: false,
      });
      expect(again.bars).toMatchObject({ inserted: 0, duplicates: 28 });

      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      const bars = await new MarketDataRepository(trx).getBars(
        { kind: 'stock', id: stock?.id ?? '' },
        'MOCK',
        '1d',
        new Date('2026-09-01'),
        FRIDAY_EVENING,
      );
      expect(bars[0]?.change).toBeNull();
      const [a, b] = [bars[0], bars[1]];
      expect(b?.change).toBeCloseTo((b?.close ?? 0) - (a?.close ?? 0), 3);
      expect(b?.changePercent).toBeCloseTo(
        (((b?.close ?? 0) - (a?.close ?? 0)) / (a?.close ?? 1)) * 100,
        3,
      );
      expect(bars.every((x) => x.source === 'mock' && x.dataMode === 'MOCK')).toBe(true);

      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run).toMatchObject({
        id: again.runId,
        status: 'SUCCESS',
        recordsInserted: 0,
        recordsSkipped: 28,
      });
    });
  });

  it('includes indices, and stores only completed intraday bars with change vs the previous daily close', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      await build(trx, FRIDAY_EVENING).service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-10-05T00:00:00+05:30'),
        symbols: ['RELIANCE', 'NIFTY50'],
      });
      const midSession = new Date('2026-10-09T10:02:00+05:30');
      const intraday = await build(trx, midSession).service.sync({
        jobName: 'test',
        timeframe: '5m',
        from: new Date('2026-10-09T09:00:00+05:30'),
        to: midSession,
        symbols: ['RELIANCE', 'NIFTY50'],
      });
      expect(intraday.bars.inserted).toBe(18);
      expect(intraday.droppedByReason.INCOMPLETE).toBe(2);
      const nifty = await new MarketRepository(trx).findBySymbol('NIFTY50');
      const q = await new MarketDataRepository(trx).latestQuote(
        { kind: 'market', id: nifty?.id ?? '' },
        'MOCK',
      );
      expect(q?.timeframe).toBe('5m');
      expect(q?.changePercent).not.toBeNull();
    });
  });

  it('isolates per-instrument failures and reports PARTIAL', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const { service, provider } = build(
        trx,
        FRIDAY_EVENING,
        (m) =>
          new StubProvider(m, {
            TCS: new AppError('UNSUPPORTED', 'no data for TCS'),
            INFY: new AppError('TIMEOUT', 'slow'),
          }),
      );
      const r = await service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-10-05T00:00:00+05:30'),
        symbols: ['RELIANCE', 'TCS', 'INFY'],
        includeIndices: false,
      });
      expect(r.status).toBe('PARTIAL');
      expect(r.instruments).toEqual({ total: 3, succeeded: 1, failed: 2 });
      expect(r.failures.map((f) => [f.symbol, f.code]).sort()).toEqual([
        ['INFY', 'TIMEOUT'],
        ['TCS', 'UNSUPPORTED'],
      ]);
      expect((provider as StubProvider).calls.filter((c) => c.symbol === 'INFY')).toHaveLength(3);
      expect((provider as StubProvider).calls.filter((c) => c.symbol === 'TCS')).toHaveLength(1);
      const [run] = await new SystemLogRepository(trx).recentRuns(1);
      expect(run?.status).toBe('PARTIAL');
      expect(run?.errorDetails).toMatchObject({
        failures: expect.arrayContaining([
          expect.objectContaining({ symbol: 'TCS', code: 'UNSUPPORTED' }),
        ]),
      });
    });
  });

  it('counts dropped and rejected provider bars and marks the run PARTIAL', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const raw: ProviderBar[] = [
        {
          ts: new Date('2026-10-05T03:45:00Z'),
          open: 100,
          high: 105,
          low: 99,
          close: 104,
          adjustedClose: 104,
          volume: 10,
        },
        {
          ts: new Date('2026-10-06T03:45:00Z'),
          open: 100,
          high: 98,
          low: 99,
          close: 99,
          adjustedClose: 99,
          volume: 10,
        },
        {
          ts: new Date('2026-10-02T03:45:00Z'),
          open: 100,
          high: 105,
          low: 99,
          close: 104,
          adjustedClose: 104,
          volume: 10,
        },
        {
          ts: new Date('2026-10-07T03:45:00Z'),
          open: null,
          high: null,
          low: null,
          close: null,
          adjustedClose: null,
          volume: null,
        },
      ];
      const { service } = build(trx, FRIDAY_EVENING, (m) => new StubProvider(m, { RELIANCE: raw }));
      const r = await service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-10-01T00:00:00+05:30'),
        symbols: ['RELIANCE'],
        includeIndices: false,
      });
      expect(r.status).toBe('PARTIAL');
      expect(r.bars).toMatchObject({ fetched: 4, inserted: 1, rejected: 2, dropped: 1 });
      expect(r.rejectedByReason).toEqual({ OHLC_INCONSISTENT: 1, NOT_A_TRADING_DAY: 1 });
    });
  });

  it('fails fast for an unsupported timeframe and clamps ranges beyond provider lookback', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const unsupported = await build(trx, FRIDAY_EVENING).service.sync({
        jobName: 'test',
        timeframe: '1m',
        ...range('2026-10-09T00:00:00+05:30'),
        symbols: ['RELIANCE'],
      });
      expect(unsupported.status).toBe('FAILED');
      expect(unsupported.notes.join(' ')).toMatch(/does not support 1m/);

      const { service, provider } = build(
        trx,
        FRIDAY_EVENING,
        (m) => new StubProvider(m, {}, { maxLookbackDays: { '5m': 2 } }),
      );
      const r = await service.sync({
        jobName: 'test',
        timeframe: '5m',
        ...range('2026-09-01T00:00:00+05:30'),
        symbols: ['RELIANCE'],
        includeIndices: false,
      });
      expect(r.notes.join(' ')).toMatch(/clamped/);
      expect((provider as StubProvider).calls[0]?.from.getTime()).toBe(
        FRIDAY_EVENING.getTime() - 2 * 86_400_000,
      );
    });
  });

  it('reports FAILED when every instrument fails, and notes unknown symbols', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const { service } = build(
        trx,
        FRIDAY_EVENING,
        (m) => new StubProvider(m, { RELIANCE: new AppError('AUTH_FAILED', 'bad key') }),
      );
      const r = await service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-10-05T00:00:00+05:30'),
        symbols: ['RELIANCE', 'NOSUCH'],
        includeIndices: false,
      });
      expect(r.status).toBe('FAILED');
      expect(r.notes.join(' ')).toMatch(/NOSUCH/);
    });
  });

  it('stores provider-priced sessions on dates outside the loaded holiday calendar, with a note', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const raw: ProviderBar[] = [
        {
          ts: new Date('2025-01-31T03:45:00Z'),
          open: 100,
          high: 105,
          low: 99,
          close: 104,
          adjustedClose: 104,
          volume: 10,
        },
        {
          ts: new Date('2025-02-01T03:45:00Z'),
          open: 104,
          high: 106,
          low: 101,
          close: 102,
          adjustedClose: 102,
          volume: 10,
        },
      ];
      const { service } = build(trx, FRIDAY_EVENING, (m) => new StubProvider(m, { RELIANCE: raw }));
      const r = await service.sync({
        jobName: 'test',
        timeframe: '1d',
        from: new Date('2025-01-30T00:00:00+05:30'),
        to: FRIDAY_EVENING,
        symbols: ['RELIANCE'],
        includeIndices: false,
      });
      expect(r.status).toBe('SUCCESS');
      expect(r.bars.inserted).toBe(2);
      expect(r.notes.join(' ')).toMatch(/holiday calendar/);
    });
  });

  it('repairs NULL changes when earlier history arrives later (daily backfill and intraday-before-daily)', async () => {
    await withRollback(db, async (trx) => {
      await isolateTables(trx, 'market_data');
      const stock = await new StockRepository(trx).findBySymbol('RELIANCE');
      const ref = { kind: 'stock' as const, id: stock?.id ?? '' };
      const repo = new MarketDataRepository(trx);
      const mid = new Date('2026-10-09T10:02:00+05:30');
      await build(trx, mid).service.sync({
        jobName: 'test',
        timeframe: '5m',
        from: new Date('2026-10-09T09:00:00+05:30'),
        to: mid,
        symbols: ['RELIANCE'],
        includeIndices: false,
      });
      expect(
        (await repo.getBars(ref, 'MOCK', '5m', new Date('2026-10-09T00:00:00Z'), mid)).every(
          (b) => b.changePercent === null,
        ),
      ).toBe(true);

      await build(trx, FRIDAY_EVENING).service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-10-05T00:00:00+05:30'),
        symbols: ['RELIANCE'],
        includeIndices: false,
      });
      const daily = await repo.getBars(ref, 'MOCK', '1d', new Date('2026-09-01'), FRIDAY_EVENING);
      expect(daily[0]?.ts.toISOString()).toBe('2026-10-05T03:45:00.000Z');
      expect(daily[0]?.change).toBeNull();
      expect(
        (await repo.getBars(ref, 'MOCK', '5m', new Date('2026-10-09T00:00:00Z'), mid)).every(
          (b) => b.changePercent !== null,
        ),
      ).toBe(true);

      await build(trx, FRIDAY_EVENING).service.sync({
        jobName: 'test',
        timeframe: '1d',
        ...range('2026-09-21T00:00:00+05:30'),
        symbols: ['RELIANCE'],
        includeIndices: false,
      });
      const healed = await repo.getBars(
        ref,
        'MOCK',
        '1d',
        new Date('2026-10-05T00:00:00Z'),
        new Date('2026-10-05T23:59:00Z'),
      );
      expect(healed[0]?.change).not.toBeNull();
    });
  });
});
