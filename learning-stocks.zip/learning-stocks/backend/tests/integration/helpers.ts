import { Writable } from 'node:stream';
import type { Logger } from 'pino';
import { createDatabase, type Database } from '../../src/database/db.js';
import type { DB } from '../../src/database/types.generated.js';
import { createLogger } from '../../src/utils/logger.js';

export const LOCAL_DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:54322/postgres';

export function createTestDb(): Database {
  return createDatabase(process.env.DATABASE_URL ?? LOCAL_DATABASE_URL, { max: 2 });
}

const ROLLBACK = Symbol('rollback');

/** Runs fn inside a transaction that is always rolled back: tests never leave data behind. */
export async function withRollback(
  db: Database,
  fn: (trx: Database) => Promise<void>,
): Promise<void> {
  try {
    await db.transaction().execute(async (trx) => {
      await fn(trx);
      throw ROLLBACK;
    });
  } catch (error) {
    if (error !== ROLLBACK) throw error;
  }
}

/**
 * Empties tables inside the current (rolled-back) transaction so a test does not depend on
 * whatever data a developer has synced locally. Nothing is deleted outside the transaction.
 */
export async function isolateTables(
  trx: Database,
  ...tables: Array<keyof DB & string>
): Promise<void> {
  for (const table of tables) await trx.deleteFrom(table).execute();
}

/** A logger that writes nowhere: integration tests assert on data, not on log output. */
export const silentLogger = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_chunk, _encoding, callback) {
      callback();
    },
  }),
});

/**
 * A logger that keeps every line, so a test can assert what was (and was not) written.
 *
 * Used for the "never logs the Authorization header" assertion: a test that declares an array and
 * never wires it to a logger passes no matter what the code does.
 */
export function capturingLogger(): { logger: Logger; lines: string[] } {
  const lines: string[] = [];
  const logger = createLogger({
    level: 'info',
    destination: new Writable({
      write(chunk, _encoding, callback) {
        lines.push(String(chunk));
        callback();
      },
    }),
  });
  return { logger, lines };
}
