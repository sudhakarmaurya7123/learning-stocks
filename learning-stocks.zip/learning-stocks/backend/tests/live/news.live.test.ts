import { describe, expect, it } from 'vitest';
import {
  DEFAULT_MARKET_FEEDS,
  RssNewsProvider,
} from '../../src/providers/news/rss/RssNewsProvider.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

// Network test against real feeds. Runs only via: pnpm --filter @learning-stocks/backend test:live
describe.skipIf(!process.env.LIVE_NEWS)('RSS live smoke', () => {
  const p = new RssNewsProvider(createRateLimiter({ ratePerSecond: 1, burst: 1 }));
  const weekAgo = () => new Date(Date.now() - 7 * 86_400_000);

  it('finds recent Google News results for an NSE company with publisher and date', async () => {
    const r = await p.fetchForInstruments({
      subjects: [{ symbol: 'RELIANCE', name: 'Reliance Industries', aliases: [] }],
      since: weekAgo(),
      limit: 20,
    });
    expect(r.articles.length).toBeGreaterThan(0);
    expect(r.articles.every((a) => a.publisherUrl !== null && a.publishedAt !== null)).toBe(true);
  });

  it('reads every default market feed', async () => {
    const r = await p.fetchMarketNews({ since: weekAgo(), limit: 50 });
    expect(r.failures).toEqual([]);
    expect(r.articles.length).toBeGreaterThanOrEqual(DEFAULT_MARKET_FEEDS.length * 5);
  });
});
