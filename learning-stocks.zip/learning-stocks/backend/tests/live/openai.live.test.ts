import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { bannedPhraseIssues } from '../../src/ai/outputGuards.js';
import {
  MarketSummarySchema,
  NewsSentimentSchema,
  QaAnswerSchema,
  StockAnalysisSchema,
  TradeSignalNarrativeSchema,
} from '../../src/ai/schemas.js';
import { loadDotEnv } from '../../src/config/dotenv.js';
import { OpenAIProvider } from '../../src/providers/llm/openai/OpenAIProvider.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

loadDotEnv();
const key = process.env.OPENAI_API_KEY;
// Costs a fraction of a rupee. Runs only via: pnpm --filter @learning-stocks/backend test:live:openai
describe.skipIf(!process.env.LIVE_OPENAI || !key)('OpenAI live smoke', () => {
  const p = new OpenAIProvider({
    apiKey: key ?? '',
    chatModel: process.env.LLM_MODEL ?? null,
    embeddingModel: process.env.EMBEDDING_MODEL ?? 'text-embedding-3-small',
    limiter: createRateLimiter({ ratePerSecond: 1, burst: 1 }),
  });

  it('returns 1536-d embeddings with usage', async () => {
    const r = await p.embed(['Reliance Industries quarterly results', 'Nifty closes higher']);
    expect(r.vectors.map((v) => v.length)).toEqual([1536, 1536]);
    expect(r.usage.inputTokens).toBeGreaterThan(0);
  });

  it.skipIf(!process.env.LLM_MODEL)('accepts a representative strict schema', async () => {
    const S = z.object({
      sentiment: z.enum(['BULLISH', 'NEUTRAL', 'BEARISH']),
      confidence: z.number().int().min(0).max(100),
      target: z.number().nullable(),
      facts: z.array(z.object({ statement: z.string(), source_ids: z.array(z.string()) })),
    });
    const r = await p.completeStructured({
      system: 'Answer only from the context. Context: [N1] Company X reported flat sales.',
      user: 'Give a cautious sentiment with one cited fact.',
      schema: S,
      schemaName: 'smoke',
    });
    expect(S.safeParse(r.data).success).toBe(true);
  });

  it.skipIf(!process.env.LLM_MODEL)(
    'accepts every Phase 7 output schema (strict mode)',
    async () => {
      const context = [
        '[E1] EVALUATION AND LEVELS (computed)',
        '- Action state (computed; explain, never change): HOLD; bias HOLD_BIAS',
        '[M1] MARKET CONTEXT (computed)',
        '- Regime NEUTRAL; NIFTY 50 trend SIDEWAYS; India VIX 14.00; risk level LOW',
        '[S1] SECTORS (computed; choose sectors only from this list)',
        '- Banks: sector-index trend SIDEWAYS (5 stocks covered)',
      ].join('\n');
      const schemas: Array<[string, z.ZodType]> = [
        ['news_sentiment', NewsSentimentSchema],
        ['stock_analysis', StockAnalysisSchema],
        ['market_summary', MarketSummarySchema],
        ['trade_signal', TradeSignalNarrativeSchema],
        ['stock_qa', QaAnswerSchema],
      ];
      for (const [name, schema] of schemas) {
        const r = await p.completeStructured({
          system: 'Use only the context. Bias language only. Paper trading only.',
          user: `Context:\n${context}\n\nProduce the ${name} output.`,
          schema,
          schemaName: name,
          maxOutputTokens: 1200,
        });
        expect(schema.safeParse(r.data).success).toBe(true);
        expect(bannedPhraseIssues(r.data)).toEqual([]);
      }
    },
  );
});
