import { describe, expect, it } from 'vitest';
import { createYahooFundamentalsClient } from '../../src/providers/fundamentals/yahoo/yahooFundamentalsClient.js';
import { YahooFundamentalsProvider } from '../../src/providers/fundamentals/yahoo/YahooFundamentalsProvider.js';
import { createYahooFinance } from '../../src/providers/yahoo/instance.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

// Network test against real Yahoo. Runs only via: pnpm --filter @learning-stocks/backend test:live
describe.skipIf(!process.env.LIVE_YAHOO)('Yahoo fundamentals live smoke', () => {
  const p = new YahooFundamentalsProvider(
    createYahooFundamentalsClient(createYahooFinance()),
    createRateLimiter({ ratePerSecond: 1, burst: 1 }),
  );
  const ref = (s: string) => ({
    providerSymbol: s,
    exchange: 'NSE' as const,
    kind: 'stock' as const,
  });

  it('returns INR fundamentals for RELIANCE with percent units', async () => {
    const s = await p.getSnapshot(ref('RELIANCE.NS'));
    expect(s.reportingCurrency).toBe('INR');
    expect(s.metrics.pe).toBeGreaterThan(0);
    expect(s.metrics.marketCap).toBeGreaterThan(1e12);
    expect(s.metrics.dividendYield).toBeGreaterThan(0);
    expect(s.metrics.dividendYield).toBeLessThan(10);
    const annual = await p.getStatements(ref('RELIANCE.NS'), 'ANNUAL');
    expect(annual.statements.length).toBeGreaterThanOrEqual(3);
    expect(
      annual.statements.every(
        (x) => x.periodEnd.endsWith('-03-31') && (x.metrics.revenue ?? 0) > 0,
      ),
    ).toBe(true);
  });

  it('reports INFY statements in a non-INR currency (the reason for currency gating)', async () => {
    expect((await p.getSnapshot(ref('INFY.NS'))).reportingCurrency).not.toBe('INR');
  });
});
