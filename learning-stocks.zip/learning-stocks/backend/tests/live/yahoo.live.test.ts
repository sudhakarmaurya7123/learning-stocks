import { describe, expect, it } from 'vitest';
import { createYahooClient } from '../../src/providers/market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from '../../src/providers/market/yahoo/YahooMarketDataProvider.js';
import { createRateLimiter } from '../../src/utils/rateLimiter.js';

// Network test against real Yahoo. Runs only via: pnpm --filter @learning-stocks/backend test:live
describe.skipIf(!process.env.LIVE_YAHOO)('Yahoo live smoke', () => {
  const p = new YahooMarketDataProvider(
    createYahooClient(),
    createRateLimiter({ ratePerSecond: 1, burst: 1 }),
  );
  const monthAgo = () => new Date(Date.now() - 30 * 86_400_000);

  it('returns NSE daily bars stamped at 09:15 IST', async () => {
    const bars = await p.getHistorical(
      { providerSymbol: 'RELIANCE.NS', exchange: 'NSE', kind: 'stock' },
      monthAgo(),
      new Date(),
      '1d',
    );
    const priced = bars.filter((b) => b.close !== null);
    expect(priced.length).toBeGreaterThan(10);
    expect(priced.every((b) => b.ts.toISOString().endsWith('T03:45:00.000Z'))).toBe(true);
  });

  it('maps an unknown symbol to UNSUPPORTED', async () => {
    await expect(
      p.getHistorical(
        { providerSymbol: 'NOSUCHSYMBOL123.NS', exchange: 'NSE', kind: 'stock' },
        monthAgo(),
        new Date(),
        '1d',
      ),
    ).rejects.toMatchObject({ code: 'UNSUPPORTED' });
  });
});
