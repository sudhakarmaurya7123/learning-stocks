export const GOOGLE_NEWS_XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/"><channel><title>"Reliance Industries" - Google News</title>
<item><title>Reliance Industries raises funds through bonds - Business Standard</title><link>https://news.google.com/rss/articles/CBMiAAA?oc=5</link><guid isPermaLink="false">CBMiAAA</guid><pubDate>Mon, 05 Oct 2026 15:06:07 GMT</pubDate><description>&lt;a href="https://news.google.com/rss/articles/CBMiAAA?oc=5" target="_blank"&gt;Reliance Industries raises funds through bonds&lt;/a&gt;&amp;nbsp;&amp;nbsp;&lt;font color="#6f6f6f"&gt;Business Standard&lt;/font&gt;</description><source url="https://www.business-standard.com">Business Standard</source></item>
<item><title>RIL shares in focus - Example Wire</title><link>https://news.google.com/rss/articles/CBMiBBB?oc=5</link><pubDate>not a date</pubDate><source url="https://example.com">Example Wire</source></item>
</channel></rss>`;

export const ET_XML = `<?xml version="1.0" encoding="UTF-8"?><rss xmlns:atom="http://www.w3.org/2005/Atom" version="2.0"><channel><title>Markets-Economic Times</title>
<item><title><![CDATA[Ahead of Market: things that will decide stock market action on Tuesday]]> </title><description><![CDATA[Indian equities rebounded on Monday, with Sensex and Nifty rising.]]> </description><link>https://economictimes.indiatimes.com/markets/stocks/news/ahead-of-market/articleshow/1.cms</link><enclosure type="image/jpeg" url="https://img.example/1.jpg" length="0"/><guid>https://economictimes.indiatimes.com/markets/stocks/news/ahead-of-market/articleshow/1.cms</guid><pubDate>Mon, 05 Oct 2026 21:27:49 +0530</pubDate></item>
<item><title>2026</title><link>https://economictimes.indiatimes.com/markets/2026.cms</link><pubDate>Mon, 05 Oct 2026 20:00:00 +0530</pubDate></item>
</channel></rss>`;

export const MINT_SINGLE_ITEM_XML = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>mint - markets</title>
<item><title><![CDATA[Nifty prediction: momentum stays weak]]></title><link><![CDATA[https://www.livemint.com/market/stock-market-news/nifty-prediction-1.html]]></link><description><![CDATA[The Nifty closed above a key level.]]></description><pubDate><![CDATA[Mon, 05 Oct 2026 23:17:54 +0530]]></pubDate></item>
</channel></rss>`;

export const EMPTY_CHANNEL_XML = `<?xml version="1.0"?><rss version="2.0"><channel><title>empty</title></channel></rss>`;
export const BOT_BLOCK_HTML = `<!doctype html><html><head><title>Access denied</title></head><body>Blocked</body></html>`;
