import type { Holiday } from '../../src/domain/types.js';
import type { HolidayLookup } from '../../src/services/MarketCalendarService.js';

export class InMemoryHolidays implements HolidayLookup {
  calls = 0;
  constructor(private readonly holidays: Holiday[]) {}
  async listBetween(exchange: Holiday['exchange'], from: string, to: string): Promise<Holiday[]> {
    this.calls += 1;
    return this.holidays.filter((h) => h.exchange === exchange && h.date >= from && h.date <= to);
  }
}
