import { Writable } from 'node:stream';
import type { Logger } from 'pino';
import { createLogger } from '../../src/utils/logger.js';

/** A logger that writes nowhere, for unit tests that construct services directly. */
export const silentUnitLogger: Logger = createLogger({
  level: 'silent',
  destination: new Writable({
    write(_chunk, _encoding, callback) {
      callback();
    },
  }),
});
