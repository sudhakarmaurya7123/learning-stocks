import { parseScoringConfig } from '../../src/scoring/config.js';

/** Mirrors supabase/seeds/07_config.sql (scoring config v1). */
export const SEED_CONFIG = parseScoringConfig({
  version: 'v1',
  weights: {
    technical: 30,
    quality: 10,
    valuation: 10,
    news: 20,
    momentum: 15,
    market_context: 15,
  },
  thresholds: {
    buy_overall_min: 65,
    strong_buy_overall_min: 80,
    avoid_overall_max: 35,
    strong_sell_overall_max: 25,
    extended_above_sma50_pct: 8,
    rsi_overbought: 70,
    min_risk_reward: 2,
    stop_atr_multiple: 1.5,
    entry_atr_width: 0.5,
    risk_per_trade_pct: 1,
    min_daily_bars: 200,
    valuation_low_pctile: 30,
    valuation_high_pctile: 70,
    min_sector_peers: 4,
    news_half_life_days: 7,
  },
});
