import type { NewsArticle } from '../../src/domain/news.js';
import { sha256Hex } from '../../src/rag/documents.js';

export const newsArticle = (
  title: string,
  url: string,
  publishedAt = new Date('2026-10-04T05:00:00Z'),
): NewsArticle => ({
  dataMode: 'MOCK',
  title,
  description: `${title} details.`,
  content: null,
  source: 'example.com',
  sourceUrl: url,
  author: null,
  publishedAt,
  language: 'en',
  contentHash: sha256Hex(url),
});
