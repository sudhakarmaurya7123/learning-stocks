import type { Holiday } from '../../src/domain/types.js';

export const CASE_WINDOW = { from: '2026-10-05', to: '2026-10-12' } as const;

export const CASE_HOLIDAYS: Holiday[] = [
  {
    exchange: 'NSE',
    date: '2026-10-07',
    description: 'TEST HOLIDAY (Wed)',
    specialOpen: null,
    specialClose: null,
  },
  {
    exchange: 'NSE',
    date: '2026-10-11',
    description: 'TEST SPECIAL SESSION (Sun)',
    specialOpen: '18:00:00',
    specialClose: '19:00:00',
  },
];

export const OPEN_CASES: ReadonlyArray<{
  exchange: 'NSE' | 'BSE';
  at: string;
  open: boolean;
  label: string;
}> = [
  { exchange: 'NSE', at: '2026-10-05T09:14:59+05:30', open: false, label: '09:14:59 IST closed' },
  { exchange: 'NSE', at: '2026-10-05T09:15:00+05:30', open: true, label: '09:15 IST open' },
  { exchange: 'NSE', at: '2026-10-05T15:29:59+05:30', open: true, label: '15:29:59 IST open' },
  { exchange: 'NSE', at: '2026-10-05T15:30:00+05:30', open: false, label: '15:30 IST closed' },
  { exchange: 'NSE', at: '2026-10-05T03:45:00Z', open: true, label: '03:45 UTC = 09:15 IST open' },
  {
    exchange: 'NSE',
    at: '2026-10-05T22:00:00Z',
    open: false,
    label: '22:00 UTC = 03:30 IST next day closed',
  },
  { exchange: 'NSE', at: '2026-10-10T11:00:00+05:30', open: false, label: 'Saturday closed' },
  { exchange: 'NSE', at: '2026-10-07T11:00:00+05:30', open: false, label: 'holiday closed' },
  {
    exchange: 'BSE',
    at: '2026-10-07T11:00:00+05:30',
    open: true,
    label: 'holiday is per-exchange',
  },
  { exchange: 'NSE', at: '2026-10-11T18:30:00+05:30', open: true, label: 'special session open' },
  {
    exchange: 'NSE',
    at: '2026-10-11T17:59:00+05:30',
    open: false,
    label: 'before special session closed',
  },
];

export const NEXT_OPEN_CASES: ReadonlyArray<{ at: string; next: string; label: string }> = [
  {
    at: '2026-10-05T09:00:00+05:30',
    next: '2026-10-05T09:15:00+05:30',
    label: 'pre-open -> same day',
  },
  {
    at: '2026-10-05T16:00:00+05:30',
    next: '2026-10-06T09:15:00+05:30',
    label: 'after close -> next day',
  },
  { at: '2026-10-06T16:00:00+05:30', next: '2026-10-08T09:15:00+05:30', label: 'skips holiday' },
  {
    at: '2026-10-09T16:00:00+05:30',
    next: '2026-10-11T18:00:00+05:30',
    label: 'weekend special session',
  },
];
