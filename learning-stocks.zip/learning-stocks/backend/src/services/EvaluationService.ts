import type { Logger } from 'pino';
import { z } from 'zod';
import type { DataMode, JobStatus, MarketRegime } from '../domain/enums.js';
import type { Bar, Stock, TradingSessions } from '../domain/types.js';
import type { AppSettingsRepository } from '../repositories/AppSettingsRepository.js';
import type { EvaluationRepository } from '../repositories/EvaluationRepository.js';
import type { FundamentalsRepository } from '../repositories/FundamentalsRepository.js';
import type { MarketDataRepository } from '../repositories/MarketDataRepository.js';
import type { MarketRepository } from '../repositories/MarketRepository.js';
import type { NewsRepository } from '../repositories/NewsRepository.js';
import type { PaperPositionRepository } from '../repositories/PaperPositionRepository.js';
import type { ScoringConfigRepository } from '../repositories/ScoringConfigRepository.js';
import type { StockRepository } from '../repositories/StockRepository.js';
import type { SystemLogRepository } from '../repositories/SystemLogRepository.js';
import type { TechnicalIndicatorRepository } from '../repositories/TechnicalIndicatorRepository.js';
import {
  buildEvaluation,
  datedCloses,
  type MarketContext,
  type StatementRow,
  trendOf,
} from '../scoring/evaluate.js';
import { ENGINE_VERSION } from '../scoring/rubrics.js';
import type { OhlcvBar } from '../technical/indicators.js';
import type { TradeLevels } from '../technical/levels.js';
import type { DatedClose } from '../technical/stats.js';
import { classifyRegime } from '../technical/trend.js';
import { mapWithConcurrency } from '../utils/concurrency.js';
import { AppError, toAppError } from '../utils/errors.js';
import { addDays, toIst } from '../utils/ist.js';
import type { InstrumentFailure } from './marketData/MarketDataService.js';

const DAY_MS = 86_400_000;
/** Five years of daily bars: enough for SMA200, 1Y risk metrics and the P/E history band. */
export const HISTORY_DAYS = 1830;
export const NEWS_LOOKBACK_DAYS = 30;
/** A session counts as completed this long after its close (matches the daily-bar settle rule). */
export const SETTLE_MS = 30 * 60_000;
const MAX_GAP_DAYS = 60;
/** Extra days fetched so the window can be anchored to the last bar even after a long data gap. */
const WINDOW_BUFFER_DAYS = 400;
const MIN_SECTOR_BARS = 200;
const DEFAULT_CAPITAL = 1_000_000;

export interface EvaluationRunRequest {
  jobName: string;
  symbols?: readonly string[];
}

export interface StockEvaluationSummary {
  symbol: string;
  actionState: string;
  bias: string | null;
  overall: number | null;
  price: number | null;
  trade: TradeLevels | null;
  invalidation: string;
  inserted: boolean;
  riskLevel: string | null;
  valuationLabel: string;
  trend: string | null;
}

export interface EvaluationRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  dataMode: DataMode;
  configVersion: string | null;
  regime: MarketRegime | null;
  stocks: { total: number; succeeded: number; failed: number };
  evaluations: { inserted: number; unchanged: number };
  indicatorRows: number;
  summaries: StockEvaluationSummary[];
  failures: InstrumentFailure[];
  notes: string[];
}

export interface EvaluationServiceDeps {
  stocks: StockRepository;
  markets: MarketRepository;
  marketData: MarketDataRepository;
  fundamentals: FundamentalsRepository;
  news: NewsRepository;
  positions: PaperPositionRepository;
  configs: ScoringConfigRepository;
  settings: AppSettingsRepository;
  evaluations: EvaluationRepository;
  indicators: TechnicalIndicatorRepository;
  systemLogs: SystemLogRepository;
  sessions: TradingSessions;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  concurrency?: number;
  /** Days of daily history per instrument (default HISTORY_DAYS). */
  historyDays?: number;
}

const toOhlcv = (b: Bar): OhlcvBar => ({
  ts: b.ts,
  open: b.open,
  high: b.high,
  low: b.low,
  close: b.close,
  volume: b.volume,
});

export class EvaluationService {
  private readonly now: () => Date;

  constructor(private readonly deps: EvaluationServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async run(request: EvaluationRunRequest): Promise<EvaluationRunResult> {
    const { systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({
      service: 'EvaluationService',
      jobName: request.jobName,
      operation: 'evaluate',
    });
    const result: EvaluationRunResult = {
      runId,
      status: 'SUCCESS',
      dataMode: this.deps.dataMode,
      configVersion: null,
      regime: null,
      stocks: { total: 0, succeeded: 0, failed: 0 },
      evaluations: { inserted: 0, unchanged: 0 },
      indicatorRows: 0,
      summaries: [],
      failures: [],
      notes: [],
    };
    let runError: unknown;

    try {
      const config = await this.deps.configs.getActive();
      result.configVersion = config.version;
      const capital =
        (await this.deps.settings.get('paper_initial_balance', z.number().positive())) ??
        DEFAULT_CAPITAL;
      const market = await this.marketContext(now, config.thresholds, result);
      result.regime = market.regime;

      let stocks = await this.deps.stocks.listActive();
      if (request.symbols) {
        const wanted = new Set(request.symbols.map((s) => s.trim().toUpperCase()).filter(Boolean));
        stocks = stocks.filter((s) => wanted.has(s.symbol));
        const missing = [...wanted].filter((s) => !stocks.some((x) => x.symbol === s));
        if (missing.length > 0)
          result.notes.push(`unknown or inactive stock symbols: ${missing.join(', ')}`);
      }
      result.stocks.total = stocks.length;
      if (stocks.length === 0) throw new AppError('VALIDATION', 'No stocks to evaluate');

      const sectorCache = new Map<
        string,
        Promise<{ closes: DatedClose[]; trend: ReturnType<typeof trendOf> } | null>
      >();
      await mapWithConcurrency(stocks, this.deps.concurrency ?? 4, async (stock) => {
        try {
          const summary = await this.evaluateStock(stock, {
            now,
            config,
            capital,
            market,
            sectorCache,
          });
          // Await before touching shared counters: `x += await …` loses concurrent updates.
          result.indicatorRows += summary.indicatorRows;
          if (summary.inserted) result.evaluations.inserted += 1;
          else result.evaluations.unchanged += 1;
          result.summaries.push(summary.summary);
          result.stocks.succeeded += 1;
        } catch (error) {
          const e = toAppError(error);
          result.failures.push({
            symbol: stock.symbol,
            providerSymbol: stock.symbol,
            code: e.code,
            message: e.message,
          });
          logger.warn({ symbol: stock.symbol, code: e.code }, 'evaluation failed for stock');
        }
      });
      result.summaries.sort((a, b) => a.symbol.localeCompare(b.symbol));
      result.stocks.failed = result.failures.length;
      result.status =
        result.stocks.succeeded === 0
          ? 'FAILED'
          : result.failures.length > 0
            ? 'PARTIAL'
            : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.stocks.total,
          inserted: result.evaluations.inserted,
          skipped: result.evaluations.unchanged,
          failed: result.stocks.failed,
        },
        message: `${result.stocks.succeeded}/${result.stocks.total} stocks evaluated; ${result.evaluations.inserted} new, ${result.evaluations.unchanged} unchanged`,
        ...(runError === undefined ? {} : { error: runError }),
        details: {
          failures: result.failures,
          notes: result.notes,
          regime: result.regime,
          configVersion: result.configVersion,
          engineVersion: ENGINE_VERSION,
        },
      });
    }
    logger.info(
      { runId, status: result.status, inserted: result.evaluations.inserted },
      'evaluation run finished',
    );
    return result;
  }

  /**
   * Daily bars for the last `historyDays` before the instrument's **last bar** (not before now): the window
   * only moves when a new bar arrives, so re-running without new data reproduces the same input hash.
   */
  private async bars(
    ref: { kind: 'stock' | 'market'; id: string },
    now: Date,
  ): Promise<OhlcvBar[]> {
    const days = this.deps.historyDays ?? HISTORY_DAYS;
    const fetched = await this.deps.marketData.getBars(
      ref,
      this.deps.dataMode,
      '1d',
      new Date(now.getTime() - (days + WINDOW_BUFFER_DAYS) * DAY_MS),
      now,
    );
    const last = fetched.at(-1);
    if (!last) return [];
    const from = last.ts.getTime() - days * DAY_MS;
    return fetched.filter((b) => b.ts.getTime() >= from).map(toOhlcv);
  }

  /** NIFTY 50 trend + India VIX → regime. Computed once per run. */
  private async marketContext(
    now: Date,
    t: { vixRiskOnMax: number; vixRiskOffMin: number; maxStaleSessions: number },
    result: EvaluationRunResult,
  ): Promise<MarketContext> {
    const nifty = await this.deps.markets.findBySymbol('NIFTY50');
    const niftyBars = nifty ? await this.bars({ kind: 'market', id: nifty.id }, now) : [];
    if (niftyBars.length === 0)
      result.notes.push('no NIFTY 50 daily bars: market regime and relative strength unavailable');
    const vixMarket = await this.deps.markets.findBySymbol('INDIAVIX');
    const vixBars = vixMarket ? await this.bars({ kind: 'market', id: vixMarket.id }, now) : [];
    const lastVix = vixBars.at(-1);
    const vix =
      lastVix && !(await this.isStale(lastVix.ts, now, t.maxStaleSessions)) ? lastVix.close : null;
    if (vix === null)
      result.notes.push('no recent India VIX close: regime uses the NIFTY trend only');
    const niftyTrend = trendOf(niftyBars);
    return {
      nifty: datedCloses(niftyBars),
      niftyTrend,
      regime: classifyRegime({ niftyTrend, vix }, t),
      vix,
    };
  }

  private async sectorContext(
    stock: Stock,
    now: Date,
    cache: Map<string, Promise<{ closes: DatedClose[]; trend: ReturnType<typeof trendOf> } | null>>,
  ) {
    const links = await this.deps.markets.linksForStock(stock.id);
    for (const link of links.filter((l) => l.linkType === 'SECTOR_INDEX')) {
      let pending = cache.get(link.market.id);
      if (!pending) {
        pending = this.bars({ kind: 'market', id: link.market.id }, now).then((b) =>
          b.length >= MIN_SECTOR_BARS ? { closes: datedCloses(b), trend: trendOf(b) } : null,
        );
        cache.set(link.market.id, pending);
      }
      const context = await pending;
      if (context) return context;
    }
    return null;
  }

  /** True when more than maxSessions completed trading sessions have passed since the bar's IST date. */
  private async isStale(barTs: Date, now: Date, maxSessions: number): Promise<boolean> {
    const today = toIst(now).date;
    let date = addDays(toIst(barTs).date, 1);
    let completed = 0;
    for (let k = 0; date <= today; k += 1, date = addDays(date, 1)) {
      if (k > MAX_GAP_DAYS) return true;
      const session = await this.deps.sessions.sessionOn('NSE', date);
      if (session && session.close.getTime() + SETTLE_MS <= now.getTime()) completed += 1;
    }
    return completed > maxSessions;
  }

  private async evaluateStock(
    stock: Stock,
    ctx: {
      now: Date;
      config: Awaited<ReturnType<ScoringConfigRepository['getActive']>>;
      capital: number;
      market: MarketContext;
      sectorCache: Map<
        string,
        Promise<{ closes: DatedClose[]; trend: ReturnType<typeof trendOf> } | null>
      >;
    },
  ): Promise<{ summary: StockEvaluationSummary; inserted: boolean; indicatorRows: number }> {
    const mode = this.deps.dataMode;
    const { now, config } = ctx;
    const bars = await this.bars({ kind: 'stock', id: stock.id }, now);
    const lastBar = bars.at(-1);
    const stale = lastBar
      ? await this.isStale(lastBar.ts, now, config.thresholds.maxStaleSessions)
      : false;
    const [sector, snapshot, quarterly, annual, peerPes, news, holdsPosition] = await Promise.all([
      this.sectorContext(stock, now, ctx.sectorCache),
      this.deps.fundamentals.latestSnapshot(stock.id, mode),
      this.deps.fundamentals.listStatements(stock.id, mode, 'QUARTERLY', 12),
      this.deps.fundamentals.listStatements(stock.id, mode, 'ANNUAL', 8),
      stock.sector
        ? this.deps.fundamentals.sectorPeerPes(stock.sector, stock.id, mode)
        : Promise.resolve([]),
      this.deps.news.sentimentsForStock(
        stock.id,
        mode,
        new Date(now.getTime() - NEWS_LOOKBACK_DAYS * DAY_MS),
      ),
      this.deps.positions.holdsPosition(stock.id, mode),
    ]);
    const toRow = (r: (typeof quarterly)[number]): StatementRow => ({
      periodEnd: r.periodEnd,
      revenue: r.metrics.revenue,
      netProfit: r.metrics.netProfit,
      eps: r.metrics.eps,
    });

    const { record, indicatorSeries } = buildEvaluation({
      stock: { id: stock.id, symbol: stock.symbol, sector: stock.sector },
      dataMode: mode,
      bars,
      stale,
      market: ctx.market,
      sector,
      fundamentals: {
        asOf: snapshot?.asOf ?? null,
        snapshot: snapshot?.metrics ?? null,
        quarterly: quarterly.map(toRow),
        annual: annual.map(toRow),
      },
      peerPes,
      news,
      holdsPosition,
      capital: ctx.capital,
      config,
      now,
    });
    const indicatorRows =
      indicatorSeries.length > 0
        ? await this.deps.indicators.upsertSeries(stock.id, mode, '1d', indicatorSeries)
        : 0;
    const { inserted } = await this.deps.evaluations.insert(record);
    return {
      inserted,
      indicatorRows,
      summary: {
        symbol: stock.symbol,
        actionState: record.actionState,
        bias: record.recommendationBias,
        overall: record.scores.overall,
        price: lastBar?.close ?? null,
        trade: record.trade,
        invalidation: record.invalidation,
        inserted,
        riskLevel: record.riskLevel,
        valuationLabel: record.valuationLabel,
        trend: record.trend,
      },
    };
  }
}
