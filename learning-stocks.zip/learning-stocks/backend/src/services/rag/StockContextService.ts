import { z } from 'zod';
import { MARKET_REGIMES, TRENDS, VALUATION_LABELS, type DataMode } from '../../domain/enums.js';
import {
  type BuiltContext,
  buildStockContext,
  type ResultDoc,
  type StockContextInput,
} from '../../rag/contextBuilder.js';
import type { StatementPeriod } from '../../domain/fundamentals.js';
import { financialsDocumentText, findYearAgo, statementAvailableOn } from '../../rag/documents.js';
import type { RankedDocument, Retriever } from '../../rag/retriever.js';
import type {
  EvaluationRepository,
  StoredEvaluationDetail,
} from '../../repositories/EvaluationRepository.js';
import type { FundamentalsRepository } from '../../repositories/FundamentalsRepository.js';
import type { MarketDataRepository } from '../../repositories/MarketDataRepository.js';
import type { StockAnalysisRepository } from '../../repositories/StockAnalysisRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { Stock } from '../../domain/types.js';
import { returnPct } from '../../technical/stats.js';
import { AppError } from '../../utils/errors.js';
import { toIst } from '../../utils/ist.js';

const DAY_MS = 86_400_000;
const PERFORMANCE_LOOKBACK_DAYS = 400;
const SESSIONS = { w1: 5, m1: 21, m3: 63, m6: 126, y1: 250 } as const;

const n = z.number().nullable().catch(null);
const trend = z.enum(TRENDS).nullable().catch(null);
/** Defensive view of the engine's stored inputs: a section that does not parse becomes null, never an error. */
const InputsView = z.object({
  indicators: z
    .object({ sma20: n, sma50: n, sma200: n, rsi14: n, macd: n, macdSignal: n, adx14: n, atr14: n })
    .nullable()
    .catch(null),
  market: z
    .object({ niftyTrend: trend, regime: z.enum(MARKET_REGIMES).nullable().catch(null), vix: n })
    .nullable()
    .catch(null),
  sectorTrend: trend,
  valuation: z
    .object({
      label: z.enum(VALUATION_LABELS),
      currentPe: n,
      ownPercentile: n,
      sectorPercentile: n,
      peersUsed: z.number(),
      notes: z.array(z.string()),
    })
    .nullable()
    .catch(null),
  decision: z.object({ reason: z.string() }).nullable().catch(null),
});
type View = z.infer<typeof InputsView>;
const EMPTY_VIEW: View = {
  indicators: null,
  market: null,
  sectorTrend: null,
  valuation: null,
  decision: null,
};

export type EvaluationInputsView = View;

/** Defensive parse of stored engine inputs (sections that do not parse become null). */
export function parseEvaluationInputs(inputs: unknown): EvaluationInputsView {
  return InputsView.catch(EMPTY_VIEW).parse(inputs);
}

export interface StockContext extends BuiltContext {
  stockId: string;
  symbol: string;
  evaluationId: string | null;
  documents: RankedDocument[];
}

export interface StockContextDeps {
  stocks: StockRepository;
  marketData: MarketDataRepository;
  evaluations: EvaluationRepository;
  fundamentals: FundamentalsRepository;
  retriever: Retriever;
  /** Supplies the previous AI analysis block (A1) when a caller asks for it. */
  analyses?: StockAnalysisRepository;
  dataMode: DataMode;
  now?: () => Date;
}

/** Gathers what the context builder needs. No LLM call except the (cached) query embedding. */
export class StockContextService {
  constructor(private readonly deps: StockContextDeps) {}

  async build(
    symbol: string,
    options: { query?: string; includeMarket?: boolean; includePreviousAnalysis?: boolean } = {},
  ): Promise<StockContext> {
    const { dataMode } = this.deps;
    const now = this.deps.now?.() ?? new Date();
    const stock = await this.deps.stocks.findBySymbol(symbol.trim().toUpperCase());
    if (!stock) throw new AppError('NOT_FOUND', `Unknown stock ${symbol}`);
    const ref = { kind: 'stock' as const, id: stock.id };

    const [quote, bars, evaluation, snapshot, quarter, annual, documents] = await Promise.all([
      this.deps.marketData.latestQuote(ref, dataMode),
      this.deps.marketData.getBars(
        ref,
        dataMode,
        '1d',
        new Date(now.getTime() - PERFORMANCE_LOOKBACK_DAYS * DAY_MS),
        now,
      ),
      this.deps.evaluations.latestDetail(stock.id, dataMode),
      this.deps.fundamentals.latestSnapshot(stock.id, dataMode),
      this.latestResults(stock, 'QUARTERLY'),
      this.latestResults(stock, 'ANNUAL'),
      this.deps.retriever.retrieve({
        query:
          options.query ??
          `${stock.companyName} ${stock.symbol} latest news, quarterly results, outlook and risks`,
        stockId: stock.id,
        includeMarket: options.includeMarket ?? true,
        // Results enter as structured R blocks (latest by date), not by similarity.
        sourceTypes: ['NEWS'],
      }),
    ]);
    const view = evaluation ? parseEvaluationInputs(evaluation.inputs) : EMPTY_VIEW;
    // A1 never feeds the stock analysis itself (it would change every next input hash).
    const previous =
      options.includePreviousAnalysis && this.deps.analyses
        ? await this.deps.analyses.latest(stock.id, dataMode, { okOnly: true })
        : null;

    const closes = bars.map((b) => ({ date: toIst(b.ts).date, close: b.close }));
    const lastBar = bars.at(-1);
    const year = bars.slice(-SESSIONS.y1);
    const input: StockContextInput = {
      stock: {
        symbol: stock.symbol,
        companyName: stock.companyName,
        exchange: stock.exchange,
        sector: stock.sector,
      },
      dataMode,
      quote: quote && {
        price: quote.price,
        changePercent: quote.changePercent,
        asOf: quote.ts,
        timeframe: quote.timeframe,
        source: quote.source,
      },
      performance: lastBar
        ? {
            asOf: lastBar.ts,
            returnsPct: {
              w1: returnPct(closes, SESSIONS.w1),
              m1: returnPct(closes, SESSIONS.m1),
              m3: returnPct(closes, SESSIONS.m3),
              m6: returnPct(closes, SESSIONS.m6),
              y1: returnPct(closes, SESSIONS.y1),
            },
            high52w: Math.max(...year.map((b) => b.high)),
            low52w: Math.min(...year.map((b) => b.low)),
          }
        : null,
      technicals:
        evaluation && view.indicators
          ? { asOf: evaluation.dataAsOf, trend: evaluation.trend, ...view.indicators }
          : null,
      fundamentals: snapshot && {
        asOf: snapshot.asOf,
        source: snapshot.source,
        pe: snapshot.metrics.pe,
        pb: snapshot.metrics.pb,
        roe: snapshot.metrics.roe,
        roce: snapshot.metrics.roce,
        debtToEquity: snapshot.metrics.debtToEquity,
        netMargin: snapshot.metrics.netMargin,
        revenueGrowthYoy: snapshot.metrics.revenueGrowthYoy,
        profitGrowthYoy: snapshot.metrics.profitGrowthYoy,
        marketCap: snapshot.metrics.marketCap,
      },
      valuation:
        evaluation && view.valuation ? { asOf: evaluation.dataAsOf, ...view.valuation } : null,
      evaluation: evaluation && evaluationBlock(evaluation, view),
      market:
        evaluation && view.market
          ? { asOf: evaluation.dataAsOf, ...view.market, sectorTrend: view.sectorTrend }
          : null,
      documents,
      results: { quarter, annual },
      previousAnalysis: previous
        ? {
            analysisTime: previous.analysisTime,
            recommendation: previous.recommendation ?? 'n/a',
            summary: previous.summary ?? '',
          }
        : null,
    };
    return {
      ...buildStockContext(input),
      stockId: stock.id,
      symbol: stock.symbol,
      evaluationId: evaluation?.id ?? null,
      documents,
    };
  }

  /** Latest statement of a period type, as the same deterministic text the embeddings use. */
  private async latestResults(
    stock: Stock,
    periodType: StatementPeriod,
  ): Promise<ResultDoc | null> {
    const rows = await this.deps.fundamentals.listStatements(
      stock.id,
      this.deps.dataMode,
      periodType,
      periodType === 'QUARTERLY' ? 5 : 2,
    );
    const latest = rows[0];
    if (!latest) return null;
    const prior = findYearAgo(rows, latest.periodEnd);
    return {
      periodEnd: latest.periodEnd,
      availableOn: statementAvailableOn(periodType, latest.periodEnd),
      text: financialsDocumentText({
        symbol: stock.symbol,
        companyName: stock.companyName,
        periodType,
        periodEnd: latest.periodEnd,
        source: latest.source,
        metrics: latest.metrics,
        prior: prior ? { periodEnd: prior.periodEnd, metrics: prior.metrics } : null,
      }),
    };
  }
}

function evaluationBlock(
  e: StoredEvaluationDetail,
  view: View,
): NonNullable<StockContextInput['evaluation']> {
  return {
    asOf: e.dataAsOf,
    evaluatedAt: e.evaluatedAt,
    actionState: e.actionState,
    bias: e.recommendationBias,
    overallScore: e.overallScore,
    riskScore: e.riskScore,
    riskLevel: e.riskLevel,
    scores: e.scores,
    entryLow: e.entryLow,
    entryHigh: e.entryHigh,
    stopLoss: e.stopLoss,
    target1: e.target1,
    target2: e.target2,
    riskReward: e.riskReward,
    invalidation: e.invalidation,
    reason: view.decision?.reason ?? null,
  };
}
