import type { Logger } from 'pino';
import type { BudgetGate } from '../../ai/LlmBudget.js';
import { z } from 'zod';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import type { StatementPeriod } from '../../domain/fundamentals.js';
import type { Stock } from '../../domain/types.js';
import { embeddingCostInr } from '../../providers/llm/pricing.js';
import type { LLMProvider } from '../../providers/llm/types.js';
import { chunkText } from '../../rag/chunker.js';
import {
  financialsDocumentText,
  findYearAgo,
  newsDocumentText,
  sha256Hex,
  statementAvailableOn,
} from '../../rag/documents.js';
import type { AppSettingsRepository } from '../../repositories/AppSettingsRepository.js';
import type {
  EmbeddingRepository,
  EmbeddingRow,
  SourceType,
} from '../../repositories/EmbeddingRepository.js';
import type { FundamentalsRepository } from '../../repositories/FundamentalsRepository.js';
import type { LlmCallRepository } from '../../repositories/LlmCallRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { round } from '../../technical/stats.js';
import { AppError, type ErrorCode, toAppError } from '../../utils/errors.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import { estimateTokens } from '../../utils/tokens.js';

export type EmbeddableSource = Extract<SourceType, 'NEWS' | 'FINANCIALS'>;
export const DEFAULT_MAX_DOCUMENTS = 500;
const EMBED_BATCH = 64;
const DEFAULT_RELEVANCE_THRESHOLD = 0.5;
const QUARTERS_KEPT = 8;
const YEARS_KEPT = 5;

interface Chunk {
  content: string;
  hash: string;
}
interface PlannedDoc {
  sourceType: EmbeddableSource;
  sourceId: string;
  publishedAt: Date | null;
  chunks: Chunk[];
  targets: Array<{ stockId: string | null; metadata: Record<string, unknown> }>;
  /** True when this document now has stock rows, so its market-level placeholder goes. */
  replacesMarketRow: boolean;
}

export interface EmbeddingFailure {
  sourceType: EmbeddableSource;
  sourceId: string;
  code: ErrorCode;
  message: string;
}

export interface EmbeddingRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  model: string;
  dataMode: DataMode;
  documents: { planned: number; written: number; failed: number };
  chunks: { unique: number; reused: number; embedded: number };
  rowsWritten: number;
  tokens: number;
  estCostInr: number;
  failures: EmbeddingFailure[];
  notes: string[];
}

export interface EmbeddingServiceDeps {
  provider: LLMProvider;
  embeddings: EmbeddingRepository;
  llmCalls: LlmCallRepository;
  stocks: StockRepository;
  fundamentals: FundamentalsRepository;
  settings: AppSettingsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  usdInrRate: number;
  retry?: RetryOptions;
  batchSize?: number;
  /** Daily ₹ budget gate (PRD §14); every batch is checked before the paid call. */
  budget?: BudgetGate;
}

const toChunks = (text: string): Chunk[] =>
  chunkText(text).map((content) => ({ content, hash: sha256Hex(content) }));

/** Embeds new or changed documents once per content hash; every model call is recorded in llm_calls. */
export class EmbeddingService {
  constructor(private readonly deps: EmbeddingServiceDeps) {}

  async run(request: {
    jobName: string;
    sources?: readonly EmbeddableSource[];
    maxDocuments?: number;
  }): Promise<EmbeddingRunResult> {
    const { provider, systemLogs, logger } = this.deps;
    const sources = request.sources ?? ['NEWS', 'FINANCIALS'];
    const max = request.maxDocuments ?? DEFAULT_MAX_DOCUMENTS;
    const model = provider.embeddingModel;
    const runId = await systemLogs.startRun({
      service: 'EmbeddingService',
      jobName: request.jobName,
      operation: `embed:${sources.join('+').toLowerCase()}`,
    });
    const result: EmbeddingRunResult = {
      runId,
      status: 'SUCCESS',
      provider: provider.name,
      model,
      dataMode: this.deps.dataMode,
      documents: { planned: 0, written: 0, failed: 0 },
      chunks: { unique: 0, reused: 0, embedded: 0 },
      rowsWritten: 0,
      tokens: 0,
      estCostInr: 0,
      failures: [],
      notes: [],
    };
    let runError: unknown;
    try {
      const planned: PlannedDoc[] = [];
      if (sources.includes('NEWS')) planned.push(...(await this.planNews(model, max + 1)));
      if (sources.includes('FINANCIALS') && planned.length <= max)
        planned.push(...(await this.planFinancials(model)));
      if (planned.length > max) {
        result.notes.push(
          `document cap reached: ${max} documents processed, more are pending; run again for the rest`,
        );
        planned.length = max;
      }
      result.documents.planned = planned.length;

      const { vectors, failed } = await this.vectorsFor(planned, model, result);
      for (const doc of planned) {
        const missing = doc.chunks.find((c) => !vectors.has(c.hash));
        if (missing) {
          this.fail(
            result,
            doc,
            failed.get(missing.hash) ?? new AppError('INTERNAL', 'No vector for chunk'),
          );
          continue;
        }
        try {
          const rows: EmbeddingRow[] = doc.targets.flatMap((t) =>
            doc.chunks.map((c, chunkIndex) => ({
              dataMode: this.deps.dataMode,
              sourceType: doc.sourceType,
              sourceId: doc.sourceId,
              stockId: t.stockId,
              chunkIndex,
              content: c.content,
              contentHash: c.hash,
              embedding: vectors.get(c.hash) ?? [],
              embeddingModel: model,
              metadata: t.metadata,
              publishedAt: doc.publishedAt,
            })),
          );
          result.rowsWritten += await this.deps.embeddings.upsertChunks(rows);
          for (const t of doc.targets) {
            await this.deps.embeddings.deleteSurplusChunks(
              doc.sourceType,
              doc.sourceId,
              t.stockId,
              model,
              doc.chunks.length,
            );
          }
          if (doc.replacesMarketRow)
            await this.deps.embeddings.deleteMarketRows(doc.sourceType, doc.sourceId, model);
          result.documents.written += 1;
        } catch (error) {
          this.fail(result, doc, toAppError(error));
        }
      }
      result.documents.failed = result.failures.length;
      result.status =
        result.failures.length === 0
          ? 'SUCCESS'
          : result.documents.written > 0
            ? 'PARTIAL'
            : 'FAILED';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.documents.planned,
          inserted: result.rowsWritten,
          skipped: result.chunks.reused,
          failed: result.documents.failed,
        },
        message: `${result.documents.written}/${result.documents.planned} documents; ${result.chunks.embedded} chunks embedded, ${result.chunks.reused} reused; ${result.rowsWritten} rows; ₹${result.estCostInr.toFixed(4)}`,
        ...(runError === undefined ? {} : { error: runError }),
        details: {
          model,
          tokens: result.tokens,
          estCostInr: result.estCostInr,
          failures: result.failures.slice(0, 50),
          notes: result.notes,
        },
      });
    }
    logger.info(
      { runId, status: result.status, rows: result.rowsWritten, embedded: result.chunks.embedded },
      'embedding run finished',
    );
    return result;
  }

  private fail(result: EmbeddingRunResult, doc: PlannedDoc, e: AppError): void {
    result.failures.push({
      sourceType: doc.sourceType,
      sourceId: doc.sourceId,
      code: e.code,
      message: e.message,
    });
  }

  private async planNews(model: string, limit: number): Promise<PlannedDoc[]> {
    const threshold =
      (await this.deps.settings.get('news_relevance_threshold', z.number().min(0).max(1))) ??
      DEFAULT_RELEVANCE_THRESHOLD;
    const pending = await this.deps.embeddings.pendingNews(
      this.deps.dataMode,
      model,
      threshold,
      limit,
    );
    return pending.map((a): PlannedDoc => {
      const base = { title: a.title, source: a.source, sourceUrl: a.sourceUrl };
      return {
        sourceType: 'NEWS',
        sourceId: a.newsId,
        publishedAt: a.publishedAt,
        chunks: toChunks(newsDocumentText(a)),
        targets: a.targets.map((t) => ({
          stockId: t.stockId,
          metadata: { ...base, relevance: t.relevance },
        })),
        replacesMarketRow: a.targets.some((t) => t.stockId !== null),
      };
    });
  }

  /** Statement summaries change when a statement is restated or its YoY comparator arrives: compare chunk hashes. */
  private async planFinancials(model: string): Promise<PlannedDoc[]> {
    const planned: PlannedDoc[] = [];
    for (const stock of await this.deps.stocks.listActive()) {
      const docs = [
        ...(await this.statementDocs(stock, 'QUARTERLY', QUARTERS_KEPT)),
        ...(await this.statementDocs(stock, 'ANNUAL', YEARS_KEPT)),
      ];
      if (docs.length === 0) continue;
      const stored = await this.deps.embeddings.chunkHashes(
        this.deps.dataMode,
        model,
        'FINANCIALS',
        docs.map((d) => d.sourceId),
      );
      for (const doc of docs) {
        const mine = stored.filter((s) => s.sourceId === doc.sourceId && s.stockId === stock.id);
        const unchanged =
          mine.length === doc.chunks.length &&
          doc.chunks.every((c, i) => mine.find((s) => s.chunkIndex === i)?.contentHash === c.hash);
        if (!unchanged) planned.push(doc);
      }
    }
    return planned;
  }

  private async statementDocs(
    stock: Stock,
    periodType: StatementPeriod,
    keep: number,
  ): Promise<PlannedDoc[]> {
    // Fetch one extra year so the oldest kept period still has its YoY comparator.
    const rows = await this.deps.fundamentals.listStatementsWithIds(
      stock.id,
      this.deps.dataMode,
      periodType,
      keep + (periodType === 'QUARTERLY' ? 4 : 1),
    );
    return rows.slice(0, keep).map((r): PlannedDoc => {
      const prior = findYearAgo(rows, r.periodEnd);
      const text = financialsDocumentText({
        symbol: stock.symbol,
        companyName: stock.companyName,
        periodType,
        periodEnd: r.periodEnd,
        source: r.source,
        metrics: r.metrics,
        prior: prior ? { periodEnd: prior.periodEnd, metrics: prior.metrics } : null,
      });
      return {
        sourceType: 'FINANCIALS',
        sourceId: r.id,
        publishedAt: new Date(`${statementAvailableOn(periodType, r.periodEnd)}T00:00:00+05:30`),
        chunks: toChunks(text),
        targets: [
          {
            stockId: stock.id,
            metadata: {
              symbol: stock.symbol,
              periodType,
              periodEnd: r.periodEnd,
              source: r.source,
            },
          },
        ],
        replacesMarketRow: false,
      };
    });
  }

  /** Reuses stored vectors by chunk hash; embeds the rest in batches. Auth/unsupported failures abort remaining batches. */
  private async vectorsFor(
    planned: readonly PlannedDoc[],
    model: string,
    result: EmbeddingRunResult,
  ) {
    const unique = new Map<string, string>();
    for (const doc of planned) for (const c of doc.chunks) unique.set(c.hash, c.content);
    result.chunks.unique = unique.size;
    const vectors = await this.deps.embeddings.vectorsByHash(this.deps.dataMode, model, [
      ...unique.keys(),
    ]);
    result.chunks.reused = vectors.size;
    const todo = [...unique.entries()].filter(([hash]) => !vectors.has(hash));
    const failed = new Map<string, AppError>();
    const size = this.deps.batchSize ?? EMBED_BATCH;
    let abort: AppError | null = null;
    for (let i = 0; i < todo.length; i += size) {
      const batch = todo.slice(i, i + size);
      if (abort) {
        for (const [hash] of batch) failed.set(hash, abort);
        continue;
      }
      try {
        if (this.deps.budget) {
          const tokens = batch.reduce((s, [, text]) => s + estimateTokens(text), 0);
          await this.deps.budget.ensure(
            embeddingCostInr(model, tokens, this.deps.usdInrRate) ?? 0,
            {
              purpose: 'embeddings',
              provider: this.deps.provider.name,
              model,
              promptVersion: null,
            },
          );
        }
        const res = await withRetry(
          () => this.deps.provider.embed(batch.map(([, text]) => text)),
          this.deps.retry,
        );
        if (res.vectors.length !== batch.length) {
          throw new AppError(
            'INVALID_RESPONSE',
            `Expected ${batch.length} vectors, got ${res.vectors.length}`,
          );
        }
        batch.forEach(([hash], k) => {
          const v = res.vectors[k];
          if (v) vectors.set(hash, v);
        });
        const cost = this.cost(res.model, res.usage.inputTokens, result);
        result.tokens += res.usage.inputTokens;
        result.estCostInr = round(result.estCostInr + cost, 4);
        result.chunks.embedded += batch.length;
        await this.deps.llmCalls.record({
          purpose: 'embeddings',
          provider: this.deps.provider.name,
          model: res.model,
          promptVersion: null,
          inputTokens: res.usage.inputTokens,
          outputTokens: 0,
          estCostInr: cost,
          latencyMs: res.latencyMs,
          cacheHit: false,
          status: 'OK',
          error: null,
        });
      } catch (error) {
        const e = toAppError(error);
        for (const [hash] of batch) failed.set(hash, e);
        // A budget refusal already wrote its own BUDGET_EXCEEDED row.
        if (e.code !== 'BUDGET_EXCEEDED') {
          await this.deps.llmCalls.record({
            purpose: 'embeddings',
            provider: this.deps.provider.name,
            model,
            promptVersion: null,
            inputTokens: 0,
            outputTokens: 0,
            estCostInr: 0,
            latencyMs: null,
            cacheHit: false,
            status: 'FAILED',
            error: `${e.code}: ${e.message}`,
          });
        }
        if (e.code === 'AUTH_FAILED' || e.code === 'UNSUPPORTED' || e.code === 'BUDGET_EXCEEDED') {
          abort = e;
          result.notes.push(`embedding aborted after ${e.code}: ${e.message}`);
        }
      }
    }
    return { vectors, failed };
  }

  private cost(model: string, tokens: number, result: EmbeddingRunResult): number {
    const inr = embeddingCostInr(model, tokens, this.deps.usdInrRate);
    if (inr !== null) return inr;
    const note = `no price entry for ${model}: cost recorded as ₹0`;
    if (!result.notes.includes(note)) result.notes.push(note);
    return 0;
  }
}
