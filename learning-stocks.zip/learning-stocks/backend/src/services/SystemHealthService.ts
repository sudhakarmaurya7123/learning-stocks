import type { LlmBudget } from '../ai/LlmBudget.js';
import type { AppConfig } from '../config/env.js';
import { pingDatabase, type Database } from '../database/db.js';
import type { WorkerLiveness } from '../jobs/PgBossQueue.js';
import type { LlmCallRepository } from '../repositories/LlmCallRepository.js';
import type { SystemLogRepository } from '../repositories/SystemLogRepository.js';
import { istToUtc, toIst } from '../utils/ist.js';
import type { MarketCalendarService } from './MarketCalendarService.js';

/** The service name each pipeline step logs under, whether a cron, a chain or a CLI ran it. */
const SERVICES = {
  market: 'MarketDataService',
  news: 'NewsService',
  fundamentals: 'FundamentalsService',
  evaluation: 'EvaluationService',
  aiAnalysis: 'AIAnalysisService',
} as const;

export interface SystemHealthDeps {
  config: AppConfig;
  db: Database;
  systemLogs: SystemLogRepository;
  llmCalls: LlmCallRepository;
  calendar: MarketCalendarService;
  budget: LlmBudget;
  /** Resolves worker liveness, or null when this process has no queue (e.g. a CLI). */
  workerLiveness: (() => Promise<WorkerLiveness>) | null;
  failureLimit?: number;
}

/** PRD §16's status payload: what is configured, what ran, and what is wrong. */
export class SystemHealthService {
  constructor(private readonly deps: SystemHealthDeps) {}

  async status(): Promise<Record<string, unknown>> {
    const now = new Date();
    const { config, systemLogs } = this.deps;
    /**
     * Every member degrades to null.
     *
     * This page is most needed when something is broken. `pingDatabase` never throws, but it
     * shared a Promise.all with queries that do — so an unreachable database made the whole
     * route 500 and the `database_status: 'down'` branch unreachable.
     */
    const soft = <T>(load: () => Promise<T>): Promise<T | null> => load().catch(() => null);

    // IST midnight today: the budget and the spend panel must agree on what "today" means, and
    // the market the operator is watching is an IST market.
    const sinceIst = istToUtc(toIst(now).date, '00:00:00');
    const [
      dbUp,
      market,
      news,
      fundamentals,
      evaluation,
      aiAnalysis,
      failures,
      marketStatus,
      jobs,
      usage,
    ] = await Promise.all([
      pingDatabase(this.deps.db),
      soft(() => systemLogs.lastSuccessful(SERVICES.market)),
      soft(() => systemLogs.lastSuccessful(SERVICES.news)),
      soft(() => systemLogs.lastSuccessful(SERVICES.fundamentals)),
      soft(() => systemLogs.lastSuccessful(SERVICES.evaluation)),
      soft(() => systemLogs.lastSuccessful(SERVICES.aiAnalysis)),
      soft(() => systemLogs.recentFailures(this.deps.failureLimit ?? 10)),
      soft(() => this.deps.calendar.status('NSE', now)),
      soft(() => systemLogs.lastRunPerJob()),
      soft(() => this.deps.llmCalls.usageSince(sinceIst)),
    ]);

    // The budget is read live rather than from a log row: a ceiling is a state, not a past event.
    const budget = await soft(() => this.deps.budget.status());
    const worker = this.deps.workerLiveness
      ? ((await soft(this.deps.workerLiveness)) ??
        ({ status: 'unknown', live: 0, last_heartbeat: null } satisfies WorkerLiveness))
      : ({ status: 'unknown', live: 0, last_heartbeat: null } satisfies WorkerLiveness);

    const stamp = (run: { finishedAt: Date | null } | null) =>
      run?.finishedAt?.toISOString() ?? null;

    return {
      data_mode: config.dataMode,
      database_status: dbUp ? 'up' : 'down',
      market_data_provider: config.providers.marketData,
      news_provider: config.providers.news,
      fundamentals_provider: config.providers.fundamentals,
      llm_provider: config.providers.llm,
      auth_mode: config.auth.mode,
      last_market_sync: stamp(market),
      last_news_sync: stamp(news),
      last_fundamentals_sync: stamp(fundamentals),
      last_evaluation: stamp(evaluation),
      last_ai_analysis: stamp(aiAnalysis),
      failed_jobs: (failures ?? []).map((f) => ({
        job_name: f.jobName,
        service: f.service,
        started_at: f.startedAt?.toISOString() ?? null,
        message: f.message,
      })),
      market_status:
        marketStatus === null
          ? null
          : {
              exchange: marketStatus.exchange,
              is_open: marketStatus.isOpen,
              phase: marketStatus.phase,
              holiday: marketStatus.holiday,
              next_open: marketStatus.nextOpen?.toISOString() ?? null,
            },
      llm_budget:
        budget === null
          ? null
          : {
              daily_budget_inr: budget.dailyBudgetInr,
              spent_today_inr: budget.spentTodayInr,
              remaining_inr: budget.remainingInr,
              // PRD §14's LLM_BUDGET_EXHAUSTED signal, read live from today's llm_calls.
              exhausted: budget.exhausted,
            },
      /**
       * PRD §3.4's cron table: one row per job, newest run, with records and duration.
       *
       * `records_processed` and `duration_ms` come straight from the run row, so the panel shows
       * what actually happened rather than a green tick that hides a run which processed nothing.
       */
      jobs: (jobs ?? []).map((j) => ({
        job_name: j.jobName,
        service: j.service,
        status: j.status,
        records_processed: j.recordsProcessed,
        duration_ms: j.executionTimeMs,
        started_at: j.startedAt?.toISOString() ?? null,
        finished_at: j.finishedAt?.toISOString() ?? null,
        message: j.message,
      })),
      // PRD §3.4: "LLM calls and spend vs daily budget", counted from IST midnight.
      llm_spend: {
        calls_today: usage?.calls ?? 0,
        input_tokens: usage?.inputTokens ?? 0,
        output_tokens: usage?.outputTokens ?? 0,
        spent_inr: usage?.spentInr ?? 0,
        budget_inr: config.llm.dailyBudgetInr,
        cache_hits: usage?.cacheHits ?? 0,
      },
      // A sync endpoint returns 202 immediately; without a worker, nothing will run it.
      worker,
      generated_at: now.toISOString(),
    };
  }
}
