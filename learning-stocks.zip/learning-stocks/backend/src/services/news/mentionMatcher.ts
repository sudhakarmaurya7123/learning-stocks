import type { InstrumentRef, Market, Stock } from '../../domain/types.js';

export interface MatchSubject {
  ref: InstrumentRef;
  symbol: string;
  name: string;
  aliases: readonly string[];
}

export interface MentionMatch {
  ref: InstrumentRef;
  symbol: string;
  relevance: number;
  matchedBy: string;
}

export interface MatchableArticle {
  title: string;
  description: string | null;
  content: string | null;
}

type Field = 'title' | 'description' | 'content';
type TermKind = 'name' | 'alias' | 'symbol';

const FIELD_WEIGHT: Readonly<Record<Field, number>> = { title: 1, description: 0.75, content: 0.6 };
const KIND_WEIGHT: Readonly<Record<TermKind, number>> = { name: 1, alias: 0.9, symbol: 0.85 };
const REPEAT_BONUS = 0.05;
const MAX_REPEAT_BONUSES = 2;
const MIN_SYMBOL_LENGTH = 3;

/** Both sit below the seeded news_relevance_threshold (0.5): stored, but never sent for LLM sentiment. */
export const QUERY_ONLY_RELEVANCE = 0.4;
export const ROUNDUP_BODY_CAP = 0.45;
export const ROUNDUP_MIN_STOCKS = 4;

/**
 * A match followed by one of these names a different entity (SBI Life, L&T Finance, ITC Hotels, Nifty Midcap).
 * Matched CASE-SENSITIVELY: entity names are Title Case, while everyday words ("Nifty next week",
 * "RIL oil-to-chemicals", "HDFC Bank capital adequacy") must not suppress a real mention.
 */
export const EXCLUDED_NEXT_WORDS = [
  'Life',
  'Card',
  'Cards',
  'General Insurance',
  'Mutual Fund',
  'MF',
  'AMC',
  'Securities',
  'Insurance',
  'Pension',
  'Hotels',
  'Finance',
  'Housing Finance',
  'Capital Markets',
  'Ventures',
  'Africa',
  'Midcap',
  'Smallcap',
  'Microcap',
  'Next 50',
  'PSU Bank',
  'Private Bank',
  'Media',
  'Oil & Gas',
  'Infra',
  'Healthcare',
  'Consumption',
  'Commodities',
  'CPSE',
  'MNC',
  // Separately listed look-alikes: L&T Technology Services, L&T Infotech, ITC Infotech, SBI Funds, SPARC.
  'Technology Services',
  'Infotech',
  'Funds',
  'Advanced Research',
] as const;

const escapeRegex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const EXCLUDED_NEXT_SOURCE = `^\\s+(?:${EXCLUDED_NEXT_WORDS.map((w) => w.split(' ').map(escapeRegex).join('\\s+')).join('|')})(?![\\p{L}\\p{N}])`;
const NEXT_WORD = new RegExp(EXCLUDED_NEXT_SOURCE, 'u');
/** All-caps headlines ("SBI LIFE SHARES RISE") carry no case signal, so compare ignoring case there. */
const NEXT_WORD_ANY_CASE = new RegExp(EXCLUDED_NEXT_SOURCE, 'iu');
const NEXT_WORD_IS_UPPERCASE = /^\s+[^\s\p{Ll}]*\p{Lu}[^\s\p{Ll}]*(?:\s|$)/u;
/**
 * "Nifty 500" is another index. Applies to index names only, and not to "500-point" or "500 points":
 * "Sensex 500 points higher" and "Reliance Industries 500 crore" are real mentions.
 */
const NEXT_INDEX_NUMBER = /^\s+(?:100|200|500)(?![\p{L}\p{N}-])(?!\s*(?:points?|pts)\b)/iu;

/** Acronyms that are also everyday tax terms (TCS = tax collected at source, ITC = input tax credit). */
const AMBIGUOUS_TERMS: Readonly<Record<string, { before?: RegExp; after?: RegExp }>> = {
  TCS: {
    before: /\bTDS\s*(?:\/|&|and|,)\s*$/i,
    after: /^\s*(?:\/\s*TDS\b|\s(?:rates?|provisions?|collection|credit)\b)/i,
  },
  ITC: {
    before: /\binput tax credit\s*\(?\s*$/i,
    after: /^\s+(?:claims?|refunds?|reversals?|availment|mismatch|rules?|benefits?)\b/i,
  },
};
const LEGAL_SUFFIX = /[\s,]+(limited|ltd\.?)$/i;
const hasLowercase = (s: string) => /\p{Ll}/u.test(s);

export function coreCompanyName(name: string): string {
  return name.trim().replace(LEGAL_SUFFIX, '').trim();
}

export function subjectsFromInstruments(
  stocks: readonly Stock[],
  markets: readonly Market[],
): MatchSubject[] {
  const fromStock = (s: Stock): MatchSubject => ({
    ref: { kind: 'stock', id: s.id },
    symbol: s.symbol,
    name: coreCompanyName(s.companyName),
    aliases: s.aliases,
  });
  const fromMarket = (m: Market): MatchSubject => ({
    ref: { kind: 'market', id: m.id },
    symbol: m.symbol,
    name: m.name,
    aliases: m.aliases,
  });
  return [...stocks.map(fromStock), ...markets.map(fromMarket)];
}

interface Term {
  subject: number;
  kind: TermKind;
  text: string;
  pattern: RegExp;
}

interface Span {
  subject: number;
  kind: TermKind;
  field: Field;
  start: number;
  end: number;
}

function termPattern(text: string): RegExp {
  const body = text.trim().split(/\s+/).map(escapeRegex).join('\\s+');
  return new RegExp(
    `(?<![\\p{L}\\p{N}&])${body}(?![\\p{L}\\p{N}&])`,
    hasLowercase(text) ? 'giu' : 'gu',
  );
}

const round3 = (n: number) => Math.round(n * 1000) / 1000;

/** Deterministic, explainable instrument detection for news articles. */
export class MentionMatcher {
  private readonly terms: Term[] = [];

  constructor(private readonly subjects: readonly MatchSubject[]) {
    subjects.forEach((s, subject) => {
      const add = (text: string, kind: TermKind) => {
        if (text.trim() !== '')
          this.terms.push({ subject, kind, text: text.trim(), pattern: termPattern(text) });
      };
      add(s.name, 'name');
      for (const alias of s.aliases) add(alias, 'alias');
      if (s.symbol.length >= MIN_SYMBOL_LENGTH) add(s.symbol, 'symbol');
    });
  }

  /** True when the text around a match shows it names something else (a group company, another index, a tax term). */
  private excluded(term: Term, text: string, start: number, rest: string): boolean {
    if (NEXT_WORD.test(rest)) return true;
    if (NEXT_WORD_IS_UPPERCASE.test(rest) && NEXT_WORD_ANY_CASE.test(rest)) return true;
    if (this.subjects[term.subject]?.ref.kind === 'market' && NEXT_INDEX_NUMBER.test(rest))
      return true;
    const context = AMBIGUOUS_TERMS[term.text];
    return Boolean(
      context && (context.before?.test(text.slice(0, start)) || context.after?.test(rest)),
    );
  }

  match(article: MatchableArticle, queriedFor: readonly string[] = []): MentionMatch[] {
    const spans: Span[] = [];
    const fields: Array<[Field, string | null]> = [
      ['title', article.title],
      ['description', article.description],
      ['content', article.content],
    ];
    for (const [field, text] of fields) {
      if (!text) continue;
      const found: Span[] = [];
      for (const term of this.terms) {
        for (const m of text.matchAll(term.pattern)) {
          const start = m.index ?? 0;
          const end = start + m[0].length;
          const rest = text.slice(end);
          if (this.excluded(term, text, start, rest)) continue;
          found.push({ subject: term.subject, kind: term.kind, field, start, end });
        }
      }
      // Longest span wins where matches overlap ("Nifty Bank" beats "Nifty").
      found.sort((a, b) => b.end - b.start - (a.end - a.start) || a.start - b.start);
      const kept: Span[] = [];
      for (const s of found)
        if (kept.every((k) => s.end <= k.start || s.start >= k.end)) kept.push(s);
      spans.push(...kept);
    }

    const bySubject = new Map<
      number,
      { best: number; matchedBy: string; count: number; inTitle: boolean }
    >();
    for (const s of spans) {
      const score = FIELD_WEIGHT[s.field] * KIND_WEIGHT[s.kind];
      const current = bySubject.get(s.subject);
      if (!current) {
        bySubject.set(s.subject, {
          best: score,
          matchedBy: `${s.kind}:${s.field}`,
          count: 1,
          inTitle: s.field === 'title',
        });
        continue;
      }
      current.count += 1;
      current.inTitle ||= s.field === 'title';
      if (score > current.best) {
        current.best = score;
        current.matchedBy = `${s.kind}:${s.field}`;
      }
    }

    const stockCount = [...bySubject.keys()].filter(
      (i) => this.subjects[i]?.ref.kind === 'stock',
    ).length;
    const out: MentionMatch[] = [];
    for (const [i, m] of bySubject) {
      const subject = this.subjects[i];
      if (!subject) continue;
      let relevance = Math.min(
        1,
        m.best + REPEAT_BONUS * Math.min(m.count - 1, MAX_REPEAT_BONUSES),
      );
      if (subject.ref.kind === 'stock' && stockCount >= ROUNDUP_MIN_STOCKS && !m.inTitle) {
        relevance = Math.min(relevance, ROUNDUP_BODY_CAP);
      }
      out.push({
        ref: subject.ref,
        symbol: subject.symbol,
        relevance: round3(relevance),
        matchedBy: m.matchedBy,
      });
    }

    const named = new Set(out.map((o) => o.symbol));
    for (const symbol of new Set(queriedFor)) {
      if (named.has(symbol)) continue;
      const subject = this.subjects.find((s) => s.symbol === symbol && s.ref.kind === 'stock');
      if (subject)
        out.push({ ref: subject.ref, symbol, relevance: QUERY_ONLY_RELEVANCE, matchedBy: 'query' });
    }
    return out.sort((a, b) => b.relevance - a.relevance || a.symbol.localeCompare(b.symbol));
  }
}
