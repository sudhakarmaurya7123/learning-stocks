import type { Logger } from 'pino';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import type { NewsMention } from '../../domain/news.js';
import type { Stock } from '../../domain/types.js';
import type {
  NewsFetchResult,
  NewsProvider,
  NewsSubject,
  SourceFailure,
} from '../../providers/news/types.js';
import type { MarketRepository } from '../../repositories/MarketRepository.js';
import type { NewsRepository } from '../../repositories/NewsRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { mapWithConcurrency } from '../../utils/concurrency.js';
import { toAppError } from '../../utils/errors.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import {
  type ArticleDropReason,
  normalizeArticles,
  type TaggedRawArticle,
} from './articleNormalizer.js';
import { coreCompanyName, MentionMatcher, subjectsFromInstruments } from './mentionMatcher.js';

const DEFAULT_PER_QUERY_LIMIT = 50;

export interface NewsSyncRequest {
  jobName: string;
  since: Date;
  /** Stocks to query by name. Omit for all active stocks; [] for market feeds only. */
  symbols?: readonly string[];
  includeMarket?: boolean;
  perQueryLimit?: number;
}

export interface NewsSyncResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  dataMode: DataMode;
  since: Date;
  queries: { total: number; succeeded: number; failed: number };
  articles: { fetched: number; new: number; existing: number; dropped: number };
  mentions: number;
  droppedByReason: Partial<Record<ArticleDropReason, number>>;
  failures: SourceFailure[];
  notes: string[];
}

export interface NewsServiceDeps {
  provider: NewsProvider;
  stocks: StockRepository;
  markets: MarketRepository;
  news: NewsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  retry?: RetryOptions;
  concurrency?: number;
}

interface Query {
  label: string;
  queriedFor: string[];
  run: () => Promise<NewsFetchResult>;
}

const toSubject = (s: Stock): NewsSubject => ({
  symbol: s.symbol,
  name: coreCompanyName(s.companyName),
  aliases: s.aliases,
});
const sum = (rec: Partial<Record<string, number>>) =>
  Object.values(rec).reduce<number>((a, v) => a + (v ?? 0), 0);

export class NewsService {
  private readonly now: () => Date;

  constructor(private readonly deps: NewsServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async sync(request: NewsSyncRequest): Promise<NewsSyncResult> {
    const { provider, systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({
      service: 'NewsService',
      jobName: request.jobName,
      operation: 'sync:news',
    });
    const result: NewsSyncResult = {
      runId,
      status: 'SUCCESS',
      provider: provider.name,
      dataMode: this.deps.dataMode,
      since: request.since,
      queries: { total: 0, succeeded: 0, failed: 0 },
      articles: { fetched: 0, new: 0, existing: 0, dropped: 0 },
      mentions: 0,
      droppedByReason: {},
      failures: [],
      notes: [],
    };
    let runError: unknown;

    try {
      const [stocks, markets] = await Promise.all([
        this.deps.stocks.listActive(),
        this.deps.markets.listActive(),
      ]);
      const matcher = new MentionMatcher(subjectsFromInstruments(stocks, markets));
      const targets = this.targets(stocks, request, result);
      const queries = this.queries(targets, request);
      result.queries.total = queries.length;

      const tagged: TaggedRawArticle[] = [];
      await mapWithConcurrency(queries, this.deps.concurrency ?? 2, async (query) => {
        try {
          const fetched = await withRetry(query.run, this.deps.retry);
          for (const article of fetched.articles)
            tagged.push({ article, queriedFor: query.queriedFor });
          result.failures.push(...fetched.failures);
          result.queries.succeeded += 1;
        } catch (error) {
          const e = toAppError(error);
          result.failures.push({ source: query.label, code: e.code, message: e.message });
          result.queries.failed += 1;
          logger.warn({ query: query.label, code: e.code }, 'news query failed');
        }
      });

      result.articles.fetched = tagged.length;
      const normalized = normalizeArticles(tagged, {
        dataMode: this.deps.dataMode,
        now,
        since: request.since,
      });
      result.droppedByReason = normalized.dropped;
      result.articles.dropped = sum(normalized.dropped);
      if (normalized.articles.length > 0) {
        const { ids, inserted } = await this.deps.news.saveArticles(normalized.articles);
        result.articles.new = inserted;
        result.articles.existing = ids.length - inserted;
        const mentions: NewsMention[] = [];
        normalized.articles.forEach((article, i) => {
          const newsId = ids[i];
          if (!newsId) return;
          for (const m of matcher.match(article, article.queriedFor)) {
            mentions.push({ newsId, ref: m.ref, relevance: m.relevance, matchedBy: m.matchedBy });
          }
        });
        result.mentions = await this.deps.news.saveMentions(mentions);
      }
      result.status =
        result.queries.succeeded === 0
          ? 'FAILED'
          : result.failures.length > 0
            ? 'PARTIAL'
            : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.articles.fetched,
          inserted: result.articles.new,
          skipped: result.articles.existing + result.articles.dropped,
          failed: result.queries.failed,
        },
        message: this.summary(result),
        ...(runError === undefined ? {} : { error: runError }),
        details: {
          failures: result.failures,
          dropped: result.droppedByReason,
          mentions: result.mentions,
          notes: result.notes,
          provider: provider.name,
        },
      });
    }
    logger.info(
      { runId, status: result.status, new: result.articles.new, mentions: result.mentions },
      'news sync finished',
    );
    return result;
  }

  private targets(stocks: Stock[], request: NewsSyncRequest, result: NewsSyncResult): Stock[] {
    if (!request.symbols) return stocks;
    const wanted = new Set(request.symbols.map((s) => s.trim().toUpperCase()).filter(Boolean));
    const targets = stocks.filter((s) => wanted.has(s.symbol));
    const missing = [...wanted].filter((s) => !targets.some((t) => t.symbol === s));
    if (missing.length > 0)
      result.notes.push(`unknown or inactive stock symbols: ${missing.join(', ')}`);
    return targets;
  }

  private queries(targets: Stock[], request: NewsSyncRequest): Query[] {
    const { provider } = this.deps;
    const limit = request.perQueryLimit ?? DEFAULT_PER_QUERY_LIMIT;
    const queries: Query[] = [];
    if (request.includeMarket !== false) {
      queries.push({
        label: 'market',
        queriedFor: [],
        run: () => provider.fetchMarketNews({ since: request.since, limit }),
      });
    }
    const size = Math.max(1, provider.capabilities().maxInstrumentsPerQuery);
    for (let i = 0; i < targets.length; i += size) {
      const group = targets.slice(i, i + size);
      const [only] = group;
      queries.push({
        label: group.map((s) => s.symbol).join(','),
        // Only a single-instrument query proves the article was "about" that instrument.
        queriedFor: group.length === 1 && only ? [only.symbol] : [],
        run: () =>
          provider.fetchForInstruments({
            subjects: group.map(toSubject),
            since: request.since,
            limit,
          }),
      });
    }
    return queries;
  }

  private summary(r: NewsSyncResult): string {
    const failed = r.failures.map((f) => `${f.source} (${f.code})`).join(', ');
    return (
      `${r.queries.succeeded}/${r.queries.total} queries ok; ${r.articles.new} new, ${r.articles.existing} already stored, ` +
      `${r.articles.dropped} dropped; ${r.mentions} mentions${failed ? `; failed: ${failed}` : ''}`
    );
  }
}
