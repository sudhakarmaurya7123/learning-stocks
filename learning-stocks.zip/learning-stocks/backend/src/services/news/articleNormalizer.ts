import type { DataMode } from '../../domain/enums.js';
import type { NewsArticle } from '../../domain/news.js';
import type { RawArticle } from '../../providers/news/types.js';
import { canonicalizeUrl, cleanText, contentHash, normalizeForHash, sourceKey } from './text.js';

/** title matches the DB check; the rest keep rows and LLM context bounded. */
export const ARTICLE_LIMITS = {
  title: 1000,
  description: 2000,
  content: 20_000,
  author: 200,
} as const;
const FUTURE_TOLERANCE_MS = 5 * 60_000;
/** A description that is the title plus at most this many characters (e.g. a publisher name) adds nothing. */
const REDUNDANT_SUFFIX_MAX = 40;

export type ArticleDropReason =
  | 'MISSING_TITLE'
  | 'INVALID_URL'
  | 'INVALID_DATE'
  | 'FUTURE_DATE'
  | 'TOO_OLD'
  | 'DUPLICATE_IN_BATCH';

/** queriedFor: internal symbols whose single-instrument query returned the article. */
export interface TaggedRawArticle {
  article: RawArticle;
  queriedFor: readonly string[];
}

export interface NormalizedArticle extends NewsArticle {
  queriedFor: string[];
}

export interface NormalizeArticlesContext {
  dataMode: DataMode;
  now: Date;
  since: Date;
}

export interface NormalizeArticlesResult {
  articles: NormalizedArticle[];
  dropped: Partial<Record<ArticleDropReason, number>>;
}

function bump(counts: Partial<Record<ArticleDropReason, number>>, key: ArticleDropReason): void {
  counts[key] = (counts[key] ?? 0) + 1;
}

function redundant(title: string, description: string): boolean {
  const t = normalizeForHash(title);
  const d = normalizeForHash(description);
  return d === t || (d.startsWith(t) && d.length - t.length <= REDUNDANT_SUFFIX_MAX);
}

/**
 * Validates provider articles. Never repairs: an article without a usable title, URL or
 * publish date is dropped (a missing date is never replaced by the fetch time).
 */
export function normalizeArticles(
  raw: readonly TaggedRawArticle[],
  ctx: NormalizeArticlesContext,
): NormalizeArticlesResult {
  const dropped: NormalizeArticlesResult['dropped'] = {};
  const articles: NormalizedArticle[] = [];
  const byHash = new Map<string, NormalizedArticle>();
  const byUrl = new Map<string, NormalizedArticle>();

  for (const { article: a, queriedFor } of raw) {
    const title = cleanText(a.title, ARTICLE_LIMITS.title);
    if (!title) {
      bump(dropped, 'MISSING_TITLE');
      continue;
    }
    const sourceUrl = a.url ? canonicalizeUrl(a.url) : null;
    const source = sourceUrl
      ? ((a.publisherUrl ? sourceKey(a.publisherUrl) : null) ?? sourceKey(sourceUrl))
      : null;
    if (!sourceUrl || !source) {
      bump(dropped, 'INVALID_URL');
      continue;
    }
    const publishedAt = a.publishedAt;
    if (!publishedAt || Number.isNaN(publishedAt.getTime())) {
      bump(dropped, 'INVALID_DATE');
      continue;
    }
    if (publishedAt.getTime() > ctx.now.getTime() + FUTURE_TOLERANCE_MS) {
      bump(dropped, 'FUTURE_DATE');
      continue;
    }
    if (publishedAt < ctx.since) {
      bump(dropped, 'TOO_OLD');
      continue;
    }

    const hash = contentHash(title, source, publishedAt);
    const existing = byHash.get(hash) ?? byUrl.get(sourceUrl);
    if (existing) {
      bump(dropped, 'DUPLICATE_IN_BATCH');
      // Remember this copy's keys too, so a third copy matching only them still merges.
      byHash.set(hash, existing);
      byUrl.set(sourceUrl, existing);
      for (const symbol of queriedFor)
        if (!existing.queriedFor.includes(symbol)) existing.queriedFor.push(symbol);
      continue;
    }
    const description = cleanText(a.description, ARTICLE_LIMITS.description);
    const article: NormalizedArticle = {
      dataMode: ctx.dataMode,
      title,
      description: description && !redundant(title, description) ? description : null,
      content: cleanText(a.content, ARTICLE_LIMITS.content),
      source,
      sourceUrl,
      author: cleanText(a.author, ARTICLE_LIMITS.author),
      publishedAt,
      language: a.language?.split('-')[0]?.toLowerCase() || 'en',
      contentHash: hash,
      queriedFor: [...new Set(queriedFor)],
    };
    byHash.set(hash, article);
    byUrl.set(sourceUrl, article);
    articles.push(article);
  }

  articles.sort((x, y) => y.publishedAt.getTime() - x.publishedAt.getTime());
  return { articles, dropped };
}
