import type { SnapshotField, StatementField } from '../../domain/fundamentals.js';

type Column = readonly [precision: number, scale: number];

/** numeric(p,s) of each column (migration 20261005000500). */
export const SNAPSHOT_COLUMNS: Readonly<Record<SnapshotField, Column>> = {
  marketCap: [20, 2],
  pe: [10, 2],
  pb: [10, 2],
  epsTtm: [18, 4],
  roe: [8, 2],
  roce: [8, 2],
  debtToEquity: [10, 4],
  dividendYield: [8, 4],
  operatingMargin: [8, 2],
  netMargin: [8, 2],
  freeCashFlow: [20, 2],
  revenueTtm: [20, 2],
  netProfitTtm: [20, 2],
  revenueGrowthYoy: [8, 2],
  profitGrowthYoy: [8, 2],
  bookValuePerShare: [18, 4],
  beta: [8, 4],
};

export const STATEMENT_COLUMNS: Readonly<Record<StatementField, Column>> = {
  revenue: [20, 2],
  operatingProfit: [20, 2],
  netProfit: [20, 2],
  eps: [18, 4],
  totalDebt: [20, 2],
  totalEquity: [20, 2],
  cashFromOperations: [20, 2],
  capex: [20, 2],
};

/** A value that is not finite or would overflow numeric(p,s) becomes null instead of failing the whole insert. */
export function fitNumeric(
  value: number | null | undefined,
  precision: number,
  scale: number,
): number | null {
  if (value === null || value === undefined || !Number.isFinite(value)) return null;
  const factor = 10 ** scale;
  const rounded = Math.round(value * factor) / factor;
  return Math.abs(rounded) < 10 ** (precision - scale) ? rounded : null;
}

export function fitMetrics<F extends string>(
  metrics: Readonly<Record<F, number | null>>,
  columns: Readonly<Record<F, Column>>,
): { metrics: Record<F, number | null>; outOfRange: F[] } {
  const out = { ...metrics } as Record<F, number | null>;
  const outOfRange: F[] = [];
  for (const field of Object.keys(columns) as F[]) {
    const value = metrics[field];
    const [precision, scale] = columns[field];
    const fitted = fitNumeric(value, precision, scale);
    if (value !== null && fitted === null) outOfRange.push(field);
    out[field] = fitted;
  }
  return { metrics: out, outOfRange };
}
