import type { Logger } from 'pino';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import { REPORTING_CURRENCY_FIELDS, type SnapshotMetrics } from '../../domain/fundamentals.js';
import type { FundamentalsProvider } from '../../providers/fundamentals/types.js';
import type { ProviderInstrumentRef } from '../../providers/market/types.js';
import type { FundamentalsRepository } from '../../repositories/FundamentalsRepository.js';
import type {
  ProviderSymbolEntry,
  ProviderSymbolRepository,
} from '../../repositories/ProviderSymbolRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { mapWithConcurrency } from '../../utils/concurrency.js';
import { AppError, toAppError } from '../../utils/errors.js';
import { toIst } from '../../utils/ist.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import type { InstrumentFailure } from '../marketData/MarketDataService.js';
import { fitMetrics, SNAPSHOT_COLUMNS, STATEMENT_COLUMNS } from './numeric.js';

const HOME_CURRENCY = 'INR';

export interface FundamentalsSyncRequest {
  jobName: string;
  symbols?: readonly string[];
  includeStatements?: boolean;
}

export interface FundamentalsSyncResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  dataMode: DataMode;
  asOf: string;
  stocks: { total: number; succeeded: number; failed: number };
  snapshots: { inserted: number; updated: number };
  /** skipped = statement rows not stored because they were reported in a non-INR currency. */
  statements: { inserted: number; updated: number; skipped: number };
  failures: InstrumentFailure[];
  notes: string[];
}

export interface FundamentalsServiceDeps {
  provider: FundamentalsProvider;
  providerSymbols: ProviderSymbolRepository;
  stocks: StockRepository;
  fundamentals: FundamentalsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  retry?: RetryOptions;
  concurrency?: number;
}

export class FundamentalsService {
  private readonly now: () => Date;

  constructor(private readonly deps: FundamentalsServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async sync(request: FundamentalsSyncRequest): Promise<FundamentalsSyncResult> {
    const { provider, systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({
      service: 'FundamentalsService',
      jobName: request.jobName,
      operation: 'sync:fundamentals',
    });
    const result: FundamentalsSyncResult = {
      runId,
      status: 'SUCCESS',
      provider: provider.name,
      dataMode: this.deps.dataMode,
      asOf: toIst(now).date,
      stocks: { total: 0, succeeded: 0, failed: 0 },
      snapshots: { inserted: 0, updated: 0 },
      statements: { inserted: 0, updated: 0, skipped: 0 },
      failures: [],
      notes: [],
    };
    let fetched = 0;
    let runError: unknown;

    try {
      const entries = (
        await this.deps.providerSymbols.listByProvider(provider.name, request.symbols)
      ).filter((e) => e.kind === 'stock');
      if (request.symbols) {
        const found = new Set(entries.map((e) => e.symbol));
        const missing = request.symbols
          .map((s) => s.trim().toUpperCase())
          .filter((s) => s && !found.has(s));
        if (missing.length > 0)
          result.notes.push(
            `no fundamentals for indices or unknown symbols: ${missing.join(', ')}`,
          );
      }
      result.stocks.total = entries.length;
      if (entries.length === 0) throw new AppError('VALIDATION', 'No stocks to sync');

      await mapWithConcurrency(entries, this.deps.concurrency ?? 2, async (entry) => {
        try {
          // Await first: `fetched += await …` reads `fetched` before the await and loses concurrent updates.
          const count = await this.syncStock(entry, request, result);
          fetched += count;
          result.stocks.succeeded += 1;
        } catch (error) {
          const e = toAppError(error);
          result.failures.push({
            symbol: entry.symbol,
            providerSymbol: entry.providerSymbol,
            code: e.code,
            message: e.message,
          });
          logger.warn({ symbol: entry.symbol, code: e.code }, 'fundamentals sync failed for stock');
        }
      });
      result.stocks.failed = result.failures.length;
      result.status =
        result.stocks.succeeded === 0
          ? 'FAILED'
          : result.failures.length > 0
            ? 'PARTIAL'
            : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched,
          inserted: result.snapshots.inserted + result.statements.inserted,
          skipped: result.snapshots.updated + result.statements.updated + result.statements.skipped,
          failed: result.stocks.failed,
        },
        message: this.summary(result),
        ...(runError === undefined ? {} : { error: runError }),
        details: {
          failures: result.failures,
          notes: result.notes,
          provider: provider.name,
          snapshots: result.snapshots,
          statements: result.statements,
        },
      });
    }
    logger.info(
      { runId, status: result.status, stocks: result.stocks },
      'fundamentals sync finished',
    );
    return result;
  }

  /** Returns the number of records fetched for this stock. */
  private async syncStock(
    entry: ProviderSymbolEntry,
    request: FundamentalsSyncRequest,
    result: FundamentalsSyncResult,
  ): Promise<number> {
    const { provider, fundamentals, dataMode } = this.deps;
    const stock = await this.deps.stocks.findBySymbol(entry.symbol, entry.exchange);
    if (!stock) throw new AppError('NOT_FOUND', `Stock ${entry.symbol} not found`);
    const ref: ProviderInstrumentRef = {
      providerSymbol: entry.providerSymbol,
      exchange: entry.exchange,
      kind: 'stock',
    };

    const snapshot = await withRetry(() => provider.getSnapshot(ref), this.deps.retry);
    let fetched = 1;
    const metrics: SnapshotMetrics = { ...snapshot.metrics };
    if (snapshot.reportingCurrency !== HOME_CURRENCY) {
      for (const field of REPORTING_CURRENCY_FIELDS) metrics[field] = null;
      result.notes.push(
        `${entry.symbol}: financials reported in ${snapshot.reportingCurrency ?? 'an unknown currency'}; revenue, profit and cash-flow amounts left empty`,
      );
    }
    const fitted = fitMetrics(metrics, SNAPSHOT_COLUMNS);
    if (fitted.outOfRange.length > 0)
      result.notes.push(
        `${entry.symbol}: out-of-range values stored as null: ${fitted.outOfRange.join(', ')}`,
      );
    const outcome = await fundamentals.upsertSnapshot({
      stockId: stock.id,
      dataMode,
      asOf: toIst(snapshot.asOf).date,
      source: provider.name,
      metrics: fitted.metrics,
      raw: snapshot.raw,
    });
    result.snapshots[outcome] += 1;

    if (request.includeStatements === false) return fetched;
    for (const period of provider.capabilities().statementPeriods) {
      const res = await withRetry(() => provider.getStatements(ref, period), this.deps.retry);
      fetched += res.statements.length;
      if (res.reportingCurrency !== HOME_CURRENCY) {
        result.statements.skipped += res.statements.length;
        if (res.statements.length > 0)
          result.notes.push(
            `${entry.symbol}: ${res.statements.length} ${period.toLowerCase()} statements in ${res.reportingCurrency ?? 'an unknown currency'} skipped`,
          );
        continue;
      }
      const records = res.statements.map((s) => {
        const f = fitMetrics(s.metrics, STATEMENT_COLUMNS);
        if (f.outOfRange.length > 0)
          result.notes.push(
            `${entry.symbol} ${s.periodEnd}: out-of-range values stored as null: ${f.outOfRange.join(', ')}`,
          );
        return {
          stockId: stock.id,
          dataMode,
          periodType: s.periodType,
          periodEnd: s.periodEnd,
          source: provider.name,
          metrics: f.metrics,
          raw: s.raw,
        };
      });
      const { inserted, updated } = await fundamentals.upsertStatements(records);
      result.statements.inserted += inserted;
      result.statements.updated += updated;
    }
    return fetched;
  }

  private summary(r: FundamentalsSyncResult): string {
    const failed = r.failures.map((f) => `${f.symbol} (${f.code})`).join(', ');
    return (
      `${r.stocks.succeeded}/${r.stocks.total} stocks ok; snapshots ${r.snapshots.inserted} new, ${r.snapshots.updated} refreshed; ` +
      `statements ${r.statements.inserted} new, ${r.statements.updated} refreshed, ${r.statements.skipped} skipped (non-INR)` +
      (failed ? `; failed: ${failed}` : '')
    );
  }
}
