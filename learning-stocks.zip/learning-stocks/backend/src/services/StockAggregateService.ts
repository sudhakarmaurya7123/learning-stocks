import type { Logger } from 'pino';
import { z } from 'zod';
import type { DataMode } from '../domain/enums.js';
import type { TradingSessions } from '../domain/types.js';
import { toFundamentalsDto, type FundamentalsDto } from '../dto/fundamentals.js';
import { toSourceDtos } from '../dto/source.js';
import { toStockDto, type StockDto } from '../dto/stock.js';
import { freshness, type Cadence, type Freshness } from '../http/envelope.js';
import { istToUtc } from '../utils/ist.js';
import type { AppSettingsRepository } from '../repositories/AppSettingsRepository.js';
import type { EvaluationRepository } from '../repositories/EvaluationRepository.js';
import type { FundamentalsRepository } from '../repositories/FundamentalsRepository.js';
import type { MarketDataRepository } from '../repositories/MarketDataRepository.js';
import type { MarketRepository } from '../repositories/MarketRepository.js';
import type { MarketSummaryRepository } from '../repositories/MarketSummaryRepository.js';
import type { NewsRepository } from '../repositories/NewsRepository.js';
import type { StockAnalysisRepository } from '../repositories/StockAnalysisRepository.js';
import type { StockRepository } from '../repositories/StockRepository.js';
import type { TechnicalIndicatorRepository } from '../repositories/TechnicalIndicatorRepository.js';
import type { TradeSignalRepository } from '../repositories/TradeSignalRepository.js';

const DAY_MS = 86_400_000;
const NEWS_LIMIT = 10;
const SENTIMENT_WINDOW_DAYS = 30;
const BENCHMARK = 'NIFTY50';
const DEFAULT_STALENESS_MINUTES = 20;
/** Trailing windows the dashboard shows, in days. */
const PERFORMANCE_WINDOWS = { '1d': 1, '1w': 7, '1m': 31, '3m': 93, '1y': 366 } as const;
/**
 * Bars fetched for the performance windows: the longest window plus a margin.
 *
 * Fetching exactly 366 days leaves no bar at or before the 1-year cutoff, so the 1-year return
 * would always be null. The margin covers that boundary plus any stretch of closed days.
 */
const PERFORMANCE_LOOKBACK_DAYS = PERFORMANCE_WINDOWS['1y'] + 30;

export type PerformanceWindow = keyof typeof PERFORMANCE_WINDOWS;

export interface StockAggregate {
  stock: StockDto;
  quote: Record<string, unknown> | null;
  performance: Record<PerformanceWindow, number | null>;
  technical: Record<string, unknown> | null;
  fundamental: FundamentalsDto | null;
  valuation: Record<string, unknown> | null;
  decision: Record<string, unknown> | null;
  news: Array<Record<string, unknown>>;
  sentiment: Record<string, unknown> | null;
  ai_analysis: Record<string, unknown> | null;
  signal: Record<string, unknown> | null;
  market_context: Record<string, unknown> | null;
  data_freshness: Record<string, Freshness>;
}

export interface StockAggregateDeps {
  stocks: StockRepository;
  marketData: MarketDataRepository;
  technicalIndicators: TechnicalIndicatorRepository;
  fundamentals: FundamentalsRepository;
  evaluations: EvaluationRepository;
  news: NewsRepository;
  analyses: StockAnalysisRepository;
  signals: TradeSignalRepository;
  markets: MarketRepository;
  summaries: MarketSummaryRepository;
  settings: AppSettingsRepository;
  sessions: TradingSessions & {
    isOpen(exchange: 'NSE', at: Date): Promise<boolean>;
    /** The reference instant for judging a daily fact's freshness (finding I4). */
    lastCompleteSessionOpen(exchange: 'NSE', at: Date): Promise<Date | null>;
  };
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
}

/**
 * The whole decision for one stock in a single response (PRD §12).
 *
 * **Stored rows only.** This is a page-load path, so it must never reach the LLM: the retriever
 * embeds its query, which costs money per call, and PRD §14's first rule is that no page load
 * spends. Everything here was already written by Phases 3–8.
 *
 * Every section is independently nullable and resolved in isolation, because PRD §17 requires a
 * stock with no fundamentals, no news or no analysis to render rather than fail.
 */
export class StockAggregateService {
  constructor(private readonly deps: StockAggregateDeps) {}

  async build(symbol: string): Promise<StockAggregate | null> {
    const stock = await this.deps.stocks.findBySymbol(symbol);
    if (!stock) return null;

    const now = this.deps.now?.() ?? new Date();
    const marketOpen = await this.safe('market_open', () => this.deps.sessions.isOpen('NSE', now));
    const stalenessMinutes =
      (await this.safe('staleness', () =>
        this.deps.settings.get('quote_staleness_minutes', z.number().positive()),
      )) ?? DEFAULT_STALENESS_MINUTES;
    // Resolved once per request: the reference point for every daily section below.
    const lastCompleteSessionOpen = await this.safe('last_session', () =>
      this.deps.sessions.lastCompleteSessionOpen('NSE', now),
    );
    const fresh = (asOf: Date | null, cadence: Cadence = 'quote'): Freshness =>
      freshness(asOf, {
        now,
        marketOpen: marketOpen ?? false,
        stalenessMinutes,
        cadence,
        ...(lastCompleteSessionOpen === null ? {} : { lastCompleteSessionOpen }),
      });

    // Fetched together: one slow or broken section must not serialize behind the others.
    const [
      quote,
      bars,
      technical,
      snapshot,
      evaluation,
      news,
      sentimentPoints,
      analysis,
      signals,
      context,
    ] = await Promise.all([
      this.safe('quote', () =>
        this.deps.marketData.latestQuote({ kind: 'stock', id: stock.id }, this.deps.dataMode),
      ),
      this.safe('bars', () =>
        this.deps.marketData.getBars(
          { kind: 'stock', id: stock.id },
          this.deps.dataMode,
          '1d',
          new Date(now.getTime() - PERFORMANCE_LOOKBACK_DAYS * DAY_MS),
          now,
        ),
      ),
      this.safe('technical', () =>
        this.deps.technicalIndicators.latest(stock.id, this.deps.dataMode, '1d'),
      ),
      this.safe('fundamental', () =>
        this.deps.fundamentals.latestSnapshot(stock.id, this.deps.dataMode),
      ),
      this.safe('evaluation', () =>
        this.deps.evaluations.latestDetail(stock.id, this.deps.dataMode),
      ),
      this.safe('news', () =>
        this.deps.news.listForInstrument({ kind: 'stock', id: stock.id }, this.deps.dataMode, {
          limit: NEWS_LIMIT,
        }),
      ),
      this.safe('sentiment', () =>
        this.deps.news.sentimentsForStock(
          stock.id,
          this.deps.dataMode,
          new Date(now.getTime() - SENTIMENT_WINDOW_DAYS * DAY_MS),
        ),
      ),
      this.safe('ai_analysis', () => this.deps.analyses.latest(stock.id, this.deps.dataMode)),
      this.safe('signal', () => this.deps.signals.active(stock.id, this.deps.dataMode)),
      this.safe('market_context', () => this.marketContext()),
    ]);

    const scores = evaluation?.scores;
    return {
      stock: toStockDto(stock),
      quote:
        quote === null || quote === undefined
          ? null
          : {
              ts: quote.ts.toISOString(),
              timeframe: quote.timeframe,
              price: quote.price,
              change: quote.change,
              change_percent: quote.changePercent,
              volume: quote.volume,
              source: quote.source,
            },
      performance: this.performance(bars ?? [], quote?.price ?? null, quote?.ts ?? null, now),
      technical:
        technical === null || technical === undefined
          ? null
          : {
              ts: technical.ts.toISOString(),
              // The score comes from the stored evaluation, never recomputed here, so the API and
              // the decision engine cannot disagree.
              technical_score: scores?.technical ?? null,
              rsi_14: technical.values.rsi14,
              macd: technical.values.macd,
              macd_signal: technical.values.macdSignal,
              sma_20: technical.values.sma20,
              sma_50: technical.values.sma50,
              sma_200: technical.values.sma200,
              atr_14: technical.values.atr14,
              adx_14: technical.values.adx14,
              bollinger_upper: technical.values.bollingerUpper,
              bollinger_lower: technical.values.bollingerLower,
            },
      fundamental: snapshot === null || snapshot === undefined ? null : toFundamentalsDto(snapshot),
      valuation:
        evaluation === null || evaluation === undefined
          ? null
          : {
              label: evaluation.valuationLabel,
              valuation_score: scores?.valuation ?? null,
              quality_score: scores?.quality ?? null,
            },
      decision:
        evaluation === null || evaluation === undefined
          ? null
          : {
              evaluated_at: evaluation.evaluatedAt.toISOString(),
              data_as_of: evaluation.dataAsOf.toISOString(),
              scoring_config_version: evaluation.scoringConfigVersion,
              action_state: evaluation.actionState,
              recommendation_bias: evaluation.recommendationBias,
              trend: evaluation.trend,
              risk_level: evaluation.riskLevel,
              market_regime: evaluation.marketRegime,
              overall_score: evaluation.overallScore,
              risk_score: evaluation.riskScore,
              coverage: evaluation.coverage,
              entry_low: evaluation.entryLow,
              entry_high: evaluation.entryHigh,
              stop_loss: evaluation.stopLoss,
              target_1: evaluation.target1,
              target_2: evaluation.target2,
              risk_reward: evaluation.riskReward,
              position_size_hint: evaluation.positionSizeHint,
              invalidation: evaluation.invalidation,
            },
      news: (news ?? []).map((n) => ({
        title: n.title,
        source: n.source,
        source_url: n.sourceUrl,
        published_at: n.publishedAt.toISOString(),
        relevance: n.relevance,
      })),
      sentiment: this.sentiment(sentimentPoints ?? []),
      ai_analysis:
        analysis === null || analysis === undefined
          ? null
          : {
              analysis_time: analysis.analysisTime.toISOString(),
              status: analysis.status,
              sentiment: analysis.sentiment,
              sentiment_score: analysis.sentimentScore,
              confidence: analysis.confidence,
              trend: analysis.trend,
              risk_level: analysis.riskLevel,
              recommendation: analysis.recommendation,
              summary: analysis.summary,
              reasoning: analysis.reasoning,
              key_positive_factors: analysis.keyPositiveFactors,
              key_negative_factors: analysis.keyNegativeFactors,
              key_risks: analysis.keyRisks,
              catalysts: analysis.catalysts,
              facts: analysis.facts,
              interpretation: analysis.interpretation,
              insufficient_data: analysis.insufficientData,
              sources: toSourceDtos(analysis.sources),
              model: analysis.model,
            },
      signal: this.signal(signals ?? []),
      market_context: context ?? null,
      data_freshness: {
        quote: fresh(quote?.ts ?? null, 'quote'),
        // Daily facts, every one: each is derived from a daily bar, which is written only after
        // the close plus a settle. Judged on the quote threshold they read "stale" from 09:35
        // onward while being perfectly current (Phase 9 finding I4).
        evaluation: fresh(evaluation?.dataAsOf ?? null, 'daily'),
        technical: fresh(technical?.ts ?? null, 'daily'),
        fundamental: fresh(
          // asOf is a DATE column holding an IST calendar date. Parsing it as UTC midnight would
          // place the fact 5h30m later than it happened, reporting fundamentals as newer than
          // they are; istToUtc maps the IST day start to the right instant.
          snapshot === null || snapshot === undefined ? null : istToUtc(snapshot.asOf, '00:00:00'),
          'daily',
        ),
        // An article has no session, so it is aged in minutes like a quote.
        news: fresh(news?.[0]?.publishedAt ?? null, 'quote'),
        // dataAsOf is itself a daily-bar timestamp, so this is a daily fact too.
        ai_analysis: fresh(analysis?.dataAsOf ?? null, 'daily'),
      },
    };
  }

  /** Trailing returns in percent, from stored daily closes. null when history does not reach back. */
  private performance(
    bars: ReadonlyArray<{ ts: Date; close: number }>,
    latest: number | null,
    latestAsOf: Date | null,
    now: Date,
  ): Record<PerformanceWindow, number | null> {
    const newest = bars.at(-1);
    const current = latest ?? newest?.close ?? null;
    // When the price comes from a stored bar rather than a live quote, that bar's own timestamp
    // is how current it is.
    const currentAsOf = latest === null ? (newest?.ts ?? null) : latestAsOf;
    const out = {} as Record<PerformanceWindow, number | null>;
    for (const [key, days] of Object.entries(PERFORMANCE_WINDOWS) as Array<
      [PerformanceWindow, number]
    >) {
      const cutoff = now.getTime() - days * DAY_MS;
      // The newest bar at or before the cutoff: the price this window is measured from.
      const baseBar = [...bars].reverse().find((b) => b.ts.getTime() <= cutoff) ?? null;
      const base = baseBar?.close ?? null;
      /**
       * A window containing no price movement is unmeasurable, not flat (Phase 9 finding I2).
       *
       * With the market shut the current price IS the base close, so the arithmetic yields
       * exactly 0 and renders "0.00%" on a Sunday — read as a flat trading day. The test is
       * whether the current price is newer than the base bar, NOT whether another daily bar
       * exists after the cutoff: mid-session no daily bar has been written yet (they land after
       * close + settle), yet the live intraday quote is genuinely newer and today's move is real.
       */
      const moved =
        currentAsOf !== null && baseBar !== null && currentAsOf.getTime() > baseBar.ts.getTime();
      out[key] =
        current === null || base === null || base === 0 || !moved
          ? null
          : Math.round(((current - base) / base) * 10_000) / 100;
    }
    return out;
  }

  private sentiment(
    points: ReadonlyArray<{ sentimentScore: number; publishedAt: Date }>,
  ): Record<string, unknown> | null {
    if (points.length === 0) return null;
    const mean = points.reduce((s, p) => s + p.sentimentScore, 0) / points.length;
    return {
      window_days: SENTIMENT_WINDOW_DAYS,
      article_count: points.length,
      average_sentiment_score: Math.round(mean * 100) / 100,
    };
  }

  private signal(
    signals: ReadonlyArray<{
      id: string;
      signal: string;
      confidence: number;
      entryLow: number | null;
      entryHigh: number | null;
      stopLoss: number | null;
      targetPrice: number | null;
      target2: number | null;
      suggestedQuantity: number | null;
      validUntil: Date;
      status: string;
    }>,
  ): Record<string, unknown> | null {
    const active = signals[0];
    if (!active) return null;
    return {
      id: active.id,
      signal: active.signal,
      confidence: active.confidence,
      entry_low: active.entryLow,
      entry_high: active.entryHigh,
      stop_loss: active.stopLoss,
      target_price: active.targetPrice,
      target_2: active.target2,
      suggested_quantity: active.suggestedQuantity,
      valid_until: active.validUntil.toISOString(),
      status: active.status,
      // Stated on every signal: a signal is a suggestion, and no job or route ever places an order.
      requires_manual_action: true,
    };
  }

  private async marketContext(): Promise<Record<string, unknown> | null> {
    const market = await this.deps.markets.findBySymbol(BENCHMARK);
    if (!market) return null;
    const summary = await this.deps.summaries.latest(market.id, this.deps.dataMode);
    if (!summary) return null;
    return {
      market: BENCHMARK,
      sentiment: summary.sentiment,
      sentiment_score: summary.sentimentScore,
      regime: summary.regime,
      trend: summary.trend,
      risk_level: summary.riskLevel,
      summary: summary.summary,
      analysis_time: summary.analysisTime.toISOString(),
    };
  }

  /**
   * Resolves a section, or logs and yields null.
   *
   * One unavailable section (a dropped connection mid-query, a provider table not yet populated)
   * must not fail the whole page: PRD §17 lists these as normal states.
   */
  private async safe<T>(section: string, load: () => Promise<T>): Promise<T | null> {
    try {
      return await load();
    } catch (error) {
      this.deps.logger.warn({ err: error, section }, 'aggregate section unavailable');
      return null;
    }
  }
}
