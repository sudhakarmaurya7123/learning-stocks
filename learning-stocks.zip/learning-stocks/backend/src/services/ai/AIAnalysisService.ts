import type { Logger } from 'pino';
import { z } from 'zod';
import type { LlmGateway } from '../../ai/LlmGateway.js';
import {
  bannedPhraseIssues,
  biasIssues,
  capList,
  citationIssues,
  clampText,
  unknownRupeeIssues,
} from '../../ai/outputGuards.js';
import { loadPrompt, renderPrompt } from '../../ai/promptLoader.js';
import { SCHEMA_NAMES, type StockAnalysisOutput, StockAnalysisSchema } from '../../ai/schemas.js';
import { citedIds, sourcesFor } from '../../ai/sources.js';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import type { Stock } from '../../domain/types.js';
import { sha256Hex } from '../../rag/documents.js';
import type { AppSettingsRepository } from '../../repositories/AppSettingsRepository.js';
import type {
  EvaluationRepository,
  StoredEvaluationDetail,
} from '../../repositories/EvaluationRepository.js';
import type {
  StockAnalysisRecord,
  StockAnalysisRepository,
} from '../../repositories/StockAnalysisRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import type { StockContext, StockContextService } from '../rag/StockContextService.js';
import { round } from '../../technical/stats.js';
import { toAppError } from '../../utils/errors.js';

const PROMPT = 'stock_analysis_v1';
const DEFAULT_MIN_INTERVAL_MINUTES = 30;

export type AnalysisOutcome =
  'ANALYSED' | 'CACHED' | 'MIN_INTERVAL' | 'INSUFFICIENT_DATA' | 'FAILED' | 'BUDGET_EXHAUSTED';

export interface AnalysisRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  results: Array<{
    symbol: string;
    outcome: AnalysisOutcome;
    analysisId: string | null;
    message: string | null;
  }>;
  notes: string[];
}

export interface AIAnalysisServiceDeps {
  stocks: StockRepository;
  evaluations: EvaluationRepository;
  analyses: StockAnalysisRepository;
  context: StockContextService;
  gateway: LlmGateway;
  settings: AppSettingsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
}

const mean = (xs: ReadonlyArray<number | null>) => {
  const v = xs.filter((x): x is number => x !== null);
  return v.length === 0 ? null : round(v.reduce((s, x) => s + x, 0) / v.length, 2);
};

/** PRD §9.2: the model explains the evaluation; every number, the trend, risk level and bias come from code. */
export class AIAnalysisService {
  constructor(private readonly deps: AIAnalysisServiceDeps) {}

  async run(request: {
    jobName: string;
    symbols?: readonly string[];
    force?: boolean;
  }): Promise<AnalysisRunResult> {
    const { systemLogs, logger } = this.deps;
    const runId = await systemLogs.startRun({
      service: 'AIAnalysisService',
      jobName: request.jobName,
      operation: request.force ? 'analyze:force' : 'analyze',
    });
    const result: AnalysisRunResult = { runId, status: 'SUCCESS', results: [], notes: [] };
    let runError: unknown;
    try {
      const stocks = await this.resolve(request.symbols, result);
      const intervalMin =
        (await this.deps.settings.get('analysis_min_interval_minutes', z.number().min(0))) ??
        DEFAULT_MIN_INTERVAL_MINUTES;
      let budgetExhausted = false;
      for (const stock of stocks) {
        if (budgetExhausted) {
          result.results.push({
            symbol: stock.symbol,
            outcome: 'BUDGET_EXHAUSTED',
            analysisId: null,
            message: null,
          });
          continue;
        }
        const r = await this.analyse(stock, request.force ?? false, intervalMin * 60_000);
        if (r.outcome === 'BUDGET_EXHAUSTED') {
          budgetExhausted = true;
          result.notes.push('LLM_BUDGET_EXHAUSTED: cached analyses are served until IST midnight');
        }
        result.results.push({ symbol: stock.symbol, ...r });
      }
      const outcomes = result.results.map((x) => x.outcome);
      result.status = outcomes.includes('FAILED')
        ? outcomes.some((o) => o === 'ANALYSED' || o === 'CACHED')
          ? 'PARTIAL'
          : 'FAILED'
        : outcomes.length > 0 && outcomes.every((o) => o === 'BUDGET_EXHAUSTED')
          ? 'SKIPPED'
          : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      const count = (o: AnalysisOutcome) => result.results.filter((x) => x.outcome === o).length;
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.results.length,
          inserted: count('ANALYSED') + count('INSUFFICIENT_DATA'),
          skipped: count('CACHED') + count('MIN_INTERVAL') + count('BUDGET_EXHAUSTED'),
          failed: count('FAILED'),
        },
        message: result.results.map((x) => `${x.symbol}:${x.outcome}`).join(', '),
        ...(runError === undefined ? {} : { error: runError }),
        details: { results: result.results, notes: result.notes },
      });
    }
    logger.info({ runId, status: result.status }, 'AI analysis run finished');
    return result;
  }

  private async resolve(
    symbols: readonly string[] | undefined,
    result: AnalysisRunResult,
  ): Promise<Stock[]> {
    if (!symbols) return this.deps.stocks.listActive();
    const out: Stock[] = [];
    for (const s of symbols) {
      const stock = await this.deps.stocks.findBySymbol(s.trim().toUpperCase());
      if (stock) out.push(stock);
      else result.notes.push(`unknown symbol ${s}`);
    }
    return out;
  }

  private async analyse(
    stock: Stock,
    force: boolean,
    intervalMs: number,
  ): Promise<{ outcome: AnalysisOutcome; analysisId: string | null; message: string | null }> {
    const { dataMode, analyses, gateway } = this.deps;
    const now = this.deps.now?.() ?? new Date();
    const ctx = await this.deps.context.build(stock.symbol); // previous analysis excluded: it must not feed the next hash
    const evaluation = await this.deps.evaluations.latestDetail(stock.id, dataMode);
    const template = loadPrompt(PROMPT);
    const inputHash = sha256Hex(
      [template.templateHash, ctx.contextHash, gateway.chatModel].join('|'),
    );
    if (!force) {
      const usable = await analyses.findUsable(stock.id, dataMode, inputHash, template.version);
      if (usable) return { outcome: 'CACHED', analysisId: usable.id, message: null };
    }
    const base = {
      stockId: stock.id,
      evaluationId: evaluation?.id ?? null,
      dataMode,
      dataAsOf: evaluation?.dataAsOf ?? now,
      inputHash,
      promptVersion: template.version,
    };

    if (!evaluation || evaluation.actionState === 'INSUFFICIENT_DATA') {
      const missing = evaluation
        ? ['evaluation: INSUFFICIENT_DATA (not enough or stale daily bars)', ...ctx.missing]
        : ['evaluation: none stored (run pnpm evaluate)', ...ctx.missing];
      const saved = await analyses.save(
        {
          ...empty(base, 'INSUFFICIENT_DATA', 'none'),
          summary: 'Insufficient data for an AI analysis.',
          insufficientData: missing,
        },
        { replace: force },
      );
      return { outcome: 'INSUFFICIENT_DATA', analysisId: saved.id, message: null };
    }

    // 0 disables the gate (also immune to clock skew between app and database).
    if (!force && intervalMs > 0) {
      const last = await analyses.latest(stock.id, dataMode);
      if (last && now.getTime() - last.analysisTime.getTime() < intervalMs)
        return { outcome: 'MIN_INTERVAL', analysisId: last.id, message: null };
    }

    try {
      const res = await gateway.complete({
        purpose: 'stock_analysis',
        prompt: renderPrompt(template, { context: ctx.text }),
        schema: StockAnalysisSchema,
        schemaName: SCHEMA_NAMES.stockAnalysis,
        maxOutputTokens: 1800,
        validate: (d) => [
          ...bannedPhraseIssues(d),
          ...unknownRupeeIssues(d, ctx.text),
          ...citationIssues(d.facts, d, ctx.ids),
          ...biasIssues(d.sentiment, evaluation.recommendationBias),
        ],
      });
      const saved = await analyses.save(okRecord(base, res.data, res.model, evaluation, ctx), {
        replace: force,
      });
      return { outcome: 'ANALYSED', analysisId: saved.id, message: null };
    } catch (error) {
      const e = toAppError(error);
      if (e.code === 'BUDGET_EXCEEDED')
        return { outcome: 'BUDGET_EXHAUSTED', analysisId: null, message: e.message };
      const saved = await analyses.save(empty(base, 'FAILED', gateway.chatModel), {
        replace: force,
      });
      return { outcome: 'FAILED', analysisId: saved.id, message: `${e.code}: ${e.message}` };
    }
  }
}

type Base = Pick<
  StockAnalysisRecord,
  'stockId' | 'evaluationId' | 'dataMode' | 'dataAsOf' | 'inputHash' | 'promptVersion'
>;

function empty(
  base: Base,
  status: 'FAILED' | 'INSUFFICIENT_DATA',
  model: string,
): StockAnalysisRecord {
  return {
    ...base,
    status,
    model,
    sentiment: null,
    sentimentScore: null,
    confidence: null,
    technicalScore: null,
    fundamentalScore: null,
    newsScore: null,
    momentumScore: null,
    riskScore: null,
    overallScore: null,
    trend: null,
    riskLevel: null,
    recommendation: null,
    summary: null,
    reasoning: [],
    keyPositiveFactors: [],
    keyNegativeFactors: [],
    keyRisks: [],
    catalysts: [],
    invalidationConditions: [],
    facts: [],
    interpretation: [],
    insufficientData: [],
    sources: [],
  };
}

function okRecord(
  base: Base,
  d: StockAnalysisOutput,
  model: string,
  ev: StoredEvaluationDetail,
  ctx: StockContext,
): StockAnalysisRecord {
  const cap = ev.coverage === null ? 100 : Math.round(ev.coverage * 100);
  const facts = d.facts.slice(0, 10).map((f) => ({
    statement: clampText(f.statement, 400),
    source_ids: f.source_ids
      .map((id) => id.trim().replace(/^\[|\]$/g, ''))
      .filter((id) => ctx.ids.has(id)),
  }));
  const invalidation = [
    ...new Set([...(ev.invalidation ? [ev.invalidation] : []), ...d.invalidation_conditions]),
  ];
  return {
    ...base,
    status: 'OK',
    model,
    sentiment: d.sentiment,
    sentimentScore: d.sentiment_score,
    confidence: Math.min(d.confidence, cap),
    // Code-owned (PRD §9.2): overwritten from the evaluation whatever the model wrote.
    technicalScore: ev.scores.technical,
    fundamentalScore: mean([ev.scores.quality, ev.scores.valuation]),
    newsScore: ev.scores.news,
    momentumScore: ev.scores.momentum,
    riskScore: ev.riskScore,
    overallScore: ev.overallScore,
    trend: ev.trend,
    riskLevel: ev.riskLevel,
    recommendation: ev.recommendationBias,
    summary: clampText(d.summary, 1200),
    reasoning: capList(d.reasoning),
    keyPositiveFactors: capList(d.positive_factors),
    keyNegativeFactors: capList(d.negative_factors),
    keyRisks: capList(d.key_risks),
    catalysts: capList(d.catalysts),
    invalidationConditions: capList(invalidation),
    facts,
    interpretation: capList(d.interpretation),
    insufficientData: capList(d.insufficient_data),
    sources: sourcesFor(citedIds(d, facts), ctx.blocks, ctx.documents),
  };
}
