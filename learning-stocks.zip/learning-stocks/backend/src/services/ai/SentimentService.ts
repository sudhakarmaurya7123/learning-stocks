import type { Logger } from 'pino';
import { z } from 'zod';
import type { LlmGateway } from '../../ai/LlmGateway.js';
import {
  bannedPhraseIssues,
  capList,
  clampText,
  unknownRupeeIssues,
} from '../../ai/outputGuards.js';
import { loadPrompt, type PromptTemplate, renderPrompt } from '../../ai/promptLoader.js';
import { NewsSentimentSchema, SCHEMA_NAMES } from '../../ai/schemas.js';
import type { DataMode, JobStatus } from '../../domain/enums.js';
import { sanitizeDocument } from '../../rag/contextBuilder.js';
import { newsDocumentText } from '../../rag/documents.js';
import type { AppSettingsRepository } from '../../repositories/AppSettingsRepository.js';
import type {
  NewsAnalysisRepository,
  SentimentTarget,
} from '../../repositories/NewsAnalysisRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { type ErrorCode, toAppError } from '../../utils/errors.js';

export const DEFAULT_MAX_ARTICLES = 50;
const ARTICLE_CHARS = 4000;
const DEFAULT_RELEVANCE_THRESHOLD = 0.5;

export interface SentimentRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  pending: number;
  analysed: number;
  budgetExhausted: boolean;
  failures: Array<{ newsId: string; stockId: string | null; code: ErrorCode; message: string }>;
  notes: string[];
}

export interface SentimentServiceDeps {
  gateway: LlmGateway;
  analyses: NewsAnalysisRepository;
  settings: AppSettingsRepository;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
}

/** PRD §9.3 / §14: one sentiment per (article, subject) and prompt version; weak matches never reach the model. */
export class SentimentService {
  constructor(private readonly deps: SentimentServiceDeps) {}

  async run(request: { jobName: string; maxArticles?: number }): Promise<SentimentRunResult> {
    const { systemLogs, logger } = this.deps;
    const runId = await systemLogs.startRun({
      service: 'SentimentService',
      jobName: request.jobName,
      operation: 'sentiment',
    });
    const result: SentimentRunResult = {
      runId,
      status: 'SUCCESS',
      pending: 0,
      analysed: 0,
      budgetExhausted: false,
      failures: [],
      notes: [],
    };
    let runError: unknown;
    try {
      const threshold =
        (await this.deps.settings.get('news_relevance_threshold', z.number().min(0).max(1))) ??
        DEFAULT_RELEVANCE_THRESHOLD;
      const template = loadPrompt('news_sentiment_v1');
      const targets = await this.deps.analyses.pending(
        this.deps.dataMode,
        template.version,
        threshold,
        request.maxArticles ?? DEFAULT_MAX_ARTICLES,
      );
      result.pending = targets.length;
      for (const target of targets) {
        try {
          await this.analyse(target, template);
          result.analysed += 1;
        } catch (error) {
          const e = toAppError(error);
          if (e.code === 'BUDGET_EXCEEDED') {
            result.budgetExhausted = true;
            result.notes.push(
              'LLM_BUDGET_EXHAUSTED: remaining articles are analysed after the budget resets (IST midnight)',
            );
            break;
          }
          result.failures.push({
            newsId: target.newsId,
            stockId: target.stockId,
            code: e.code,
            message: e.message,
          });
        }
      }
      result.status =
        result.failures.length === 0 && !result.budgetExhausted
          ? 'SUCCESS'
          : result.analysed > 0
            ? 'PARTIAL'
            : result.budgetExhausted && result.failures.length === 0
              ? 'SKIPPED'
              : 'FAILED';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.pending,
          inserted: result.analysed,
          skipped: 0,
          failed: result.failures.length,
        },
        message: `${result.analysed}/${result.pending} article sentiments${result.budgetExhausted ? '; budget exhausted' : ''}`,
        ...(runError === undefined ? {} : { error: runError }),
        details: { failures: result.failures.slice(0, 50), notes: result.notes },
      });
    }
    logger.info(
      { runId, status: result.status, analysed: result.analysed },
      'sentiment run finished',
    );
    return result;
  }

  private async analyse(t: SentimentTarget, template: PromptTemplate): Promise<void> {
    const subject = t.stockId
      ? `${t.companyName ?? t.symbol ?? 'the company'} (${t.symbol ?? 'n/a'})`
      : 'the Indian stock market (NIFTY 50 and SENSEX)';
    // Article text is untrusted: quoted between markers, IDs and markers neutralised.
    const article = sanitizeDocument(newsDocumentText(t), ARTICLE_CHARS);
    const res = await this.deps.gateway.complete({
      purpose: 'news_sentiment',
      prompt: renderPrompt(template, { subject, article }),
      schema: NewsSentimentSchema,
      schemaName: SCHEMA_NAMES.newsSentiment,
      maxOutputTokens: 600,
      validate: (d) => [...bannedPhraseIssues(d), ...unknownRupeeIssues(d, article)],
    });
    const d = res.data;
    await this.deps.analyses.insert({
      newsId: t.newsId,
      stockId: t.stockId,
      sentiment: d.sentiment,
      sentimentScore: d.sentiment_score,
      confidence: d.confidence,
      relevanceScore: d.relevance_score,
      impactLevel: d.impact_level,
      summary: clampText(d.summary, 600),
      positiveFactors: capList(d.positive_factors),
      negativeFactors: capList(d.negative_factors),
      reasoning: capList(d.reasoning),
      model: res.model,
      promptVersion: template.version,
    });
  }
}
