import type { LlmGateway } from '../../ai/LlmGateway.js';
import {
  bannedPhraseIssues,
  capList,
  citationIssues,
  clampText,
  unknownRupeeIssues,
} from '../../ai/outputGuards.js';
import { loadPrompt, renderPrompt } from '../../ai/promptLoader.js';
import { type QaAnswer, QaAnswerSchema, SCHEMA_NAMES } from '../../ai/schemas.js';
import { citedIds, sourcesFor } from '../../ai/sources.js';
import type { SourceRef } from '../../domain/ai.js';
import type { DataMode } from '../../domain/enums.js';
import { sanitizeDocument } from '../../rag/contextBuilder.js';
import { sha256Hex } from '../../rag/documents.js';
import type { QaRepository } from '../../repositories/QaRepository.js';
import { AppError } from '../../utils/errors.js';
import type { StockContextService } from '../rag/StockContextService.js';

export const MAX_QUESTION_CHARS = 500;

export function normaliseQuestion(q: string): string {
  return q
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[?!.]+$/, '')
    .trim();
}

export interface QaResult {
  symbol: string;
  answer: QaAnswer;
  sources: SourceRef[];
  cached: boolean;
  model: string;
  contextHash: string;
}

export interface QAServiceDeps {
  context: StockContextService;
  qa: QaRepository;
  gateway: LlmGateway;
  dataMode: DataMode;
}

/** PRD §3.2 RAG assistant: answers only from the stock's context, cited; cached per (stock, question, context). */
export class QAService {
  constructor(private readonly deps: QAServiceDeps) {}

  async ask(symbol: string, question: string): Promise<QaResult> {
    const q = question.trim();
    if (q.length === 0 || q.length > MAX_QUESTION_CHARS) {
      throw new AppError('VALIDATION', `Question must be 1–${MAX_QUESTION_CHARS} characters`);
    }
    const normalised = normaliseQuestion(q);
    // Retrieval uses the normalised question so equivalent questions share a context (and the cache).
    const ctx = await this.deps.context.build(symbol, {
      query: normalised,
      includePreviousAnalysis: true,
    });
    const template = loadPrompt('stock_qa_v1');
    const questionHash = sha256Hex(normalised);
    const cached = await this.deps.qa.findCached(
      ctx.stockId,
      this.deps.dataMode,
      questionHash,
      ctx.contextHash,
      template.version,
    );
    const parsed = cached ? QaAnswerSchema.safeParse(cached.answer) : null;
    if (cached && parsed?.success) {
      return {
        symbol: ctx.symbol,
        answer: parsed.data,
        sources: cached.sources,
        cached: true,
        model: cached.model,
        contextHash: ctx.contextHash,
      };
    }
    const res = await this.deps.gateway.complete({
      purpose: 'stock_qa',
      prompt: renderPrompt(template, {
        question: sanitizeDocument(q, MAX_QUESTION_CHARS),
        context: ctx.text,
      }),
      schema: QaAnswerSchema,
      schemaName: SCHEMA_NAMES.stockQa,
      maxOutputTokens: 900,
      validate: (d) => [
        ...bannedPhraseIssues(d),
        ...unknownRupeeIssues(d, ctx.text),
        ...citationIssues(d.facts, d, ctx.ids),
      ],
    });
    const facts = res.data.facts.slice(0, 10).map((f) => ({
      statement: clampText(f.statement, 400),
      source_ids: f.source_ids
        .map((id) => id.trim().replace(/^\[|\]$/g, ''))
        .filter((id) => ctx.ids.has(id)),
    }));
    const answer: QaAnswer = {
      answer: clampText(res.data.answer, 2000),
      facts,
      interpretation: capList(res.data.interpretation),
      insufficient_data: capList(res.data.insufficient_data),
    };
    const sources = sourcesFor(citedIds(answer, facts), ctx.blocks, ctx.documents);
    await this.deps.qa.insert({
      stockId: ctx.stockId,
      dataMode: this.deps.dataMode,
      question: q,
      questionHash,
      contextHash: ctx.contextHash,
      answer,
      sources,
      model: res.model,
      promptVersion: template.version,
    });
    return {
      symbol: ctx.symbol,
      answer,
      sources,
      cached: false,
      model: res.model,
      contextHash: ctx.contextHash,
    };
  }
}
