import type { Logger } from 'pino';
import type { LlmGateway } from '../../ai/LlmGateway.js';
import {
  bannedPhraseIssues,
  capList,
  citationIssues,
  unknownRupeeIssues,
} from '../../ai/outputGuards.js';
import { loadPrompt, renderPrompt } from '../../ai/promptLoader.js';
import { SCHEMA_NAMES, TradeSignalNarrativeSchema } from '../../ai/schemas.js';
import type { ActionState, DataMode, Exchange, JobStatus } from '../../domain/enums.js';
import type { Stock, TradingSessions } from '../../domain/types.js';
import type {
  EvaluationRepository,
  StoredEvaluationDetail,
} from '../../repositories/EvaluationRepository.js';
import type { StockAnalysisRepository } from '../../repositories/StockAnalysisRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import type { TradeSignalRepository } from '../../repositories/TradeSignalRepository.js';
import { round } from '../../technical/stats.js';
import { formatInr } from '../../utils/format.js';
import { addDays, toIst } from '../../utils/ist.js';
import type { StockContextService } from '../rag/StockContextService.js';

const DAY_MS = 86_400_000;
const SESSION_SEARCH_DAYS = 10;

/** PRD §8.5: BUY for BUY_ZONE, SELL for REDUCE (held paper position); no signal otherwise. */
export function signalFor(state: ActionState): 'BUY' | 'SELL' | null {
  return state === 'BUY_ZONE' ? 'BUY' : state === 'REDUCE' ? 'SELL' : null;
}

/** Close of the first trading session after `after`'s IST date (holidays and weekends skipped). */
export async function nextSessionClose(
  sessions: TradingSessions,
  exchange: Exchange,
  after: Date,
): Promise<Date | null> {
  let date = addDays(toIst(after).date, 1);
  for (let i = 0; i < SESSION_SEARCH_DAYS; i += 1) {
    const s = await sessions.sessionOn(exchange, date);
    if (s) return s.close;
    date = addDays(date, 1);
  }
  return null;
}

export type SignalOutcome = 'CREATED' | 'EXISTS' | 'NONE' | 'SKIPPED';

export interface SignalRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  created: number;
  invalidated: number;
  expired: number;
  narrativeFallbacks: number;
  results: Array<{
    symbol: string;
    outcome: SignalOutcome;
    signalId: string | null;
    message: string | null;
  }>;
  notes: string[];
}

export interface TradeSignalServiceDeps {
  stocks: StockRepository;
  evaluations: EvaluationRepository;
  analyses: StockAnalysisRepository;
  signals: TradeSignalRepository;
  context: StockContextService;
  gateway: LlmGateway;
  sessions: TradingSessions;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
}

/** Paper-trade signals: type, prices and quantity from the evaluation; the LLM writes only the narrative. Never trades. */
export class TradeSignalService {
  constructor(private readonly deps: TradeSignalServiceDeps) {}

  async run(request: { jobName: string; symbols?: readonly string[] }): Promise<SignalRunResult> {
    const { systemLogs, logger, dataMode, signals } = this.deps;
    const now = this.deps.now?.() ?? new Date();
    const runId = await systemLogs.startRun({
      service: 'TradeSignalService',
      jobName: request.jobName,
      operation: 'signals',
    });
    const result: SignalRunResult = {
      runId,
      status: 'SUCCESS',
      created: 0,
      invalidated: 0,
      expired: 0,
      narrativeFallbacks: 0,
      results: [],
      notes: [],
    };
    let runError: unknown;
    try {
      result.expired = await signals.expire(dataMode, now);
      const stocks = request.symbols
        ? (
            await Promise.all(
              request.symbols.map((s) => this.deps.stocks.findBySymbol(s.trim().toUpperCase())),
            )
          ).filter((s): s is Stock => s !== null)
        : await this.deps.stocks.listActive();
      for (const stock of stocks)
        result.results.push({ symbol: stock.symbol, ...(await this.forStock(stock, now, result)) });
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.results.length,
          inserted: result.created,
          skipped: result.invalidated + result.expired,
          failed: 0,
        },
        message: `${result.created} created, ${result.invalidated} invalidated, ${result.expired} expired, ${result.narrativeFallbacks} deterministic narratives`,
        ...(runError === undefined ? {} : { error: runError }),
        details: { results: result.results, notes: result.notes },
      });
    }
    logger.info({ runId, created: result.created }, 'signal run finished');
    return result;
  }

  private async forStock(
    stock: Stock,
    now: Date,
    result: SignalRunResult,
  ): Promise<{ outcome: SignalOutcome; signalId: string | null; message: string | null }> {
    const { dataMode, signals } = this.deps;
    const ev = await this.deps.evaluations.latestDetail(stock.id, dataMode);
    const active = await signals.active(stock.id, dataMode);
    const stale = active.filter((s) => s.evaluationId !== (ev?.id ?? null));
    await signals.setStatus(
      stale.map((s) => s.id),
      'INVALIDATED',
    );
    result.invalidated += stale.length;
    const type = ev ? signalFor(ev.actionState) : null;
    if (!ev || !type) return { outcome: 'NONE', signalId: null, message: null };
    const current = active.find((s) => s.evaluationId === ev.id);
    if (current) return { outcome: 'EXISTS', signalId: current.id, message: null };
    if (type === 'BUY' && (ev.entryLow === null || ev.entryHigh === null || ev.stopLoss === null)) {
      return {
        outcome: 'SKIPPED',
        signalId: null,
        message: 'BUY_ZONE without a complete entry zone and stop',
      };
    }
    const validUntil =
      (await nextSessionClose(this.deps.sessions, stock.exchange, ev.dataAsOf)) ??
      new Date(ev.dataAsOf.getTime() + 3 * DAY_MS);
    if (validUntil <= now)
      return {
        outcome: 'SKIPPED',
        signalId: null,
        message: 'evaluation too old: the signal would already be expired',
      };
    const analysis = await this.deps.analyses.latest(stock.id, dataMode, { okOnly: true });
    const fromAnalysis =
      analysis?.evaluationId === ev.id && analysis.confidence !== null ? analysis.confidence : null;
    const reasoning = await this.narrative(stock, ev, type, result);
    const id = await signals.create({
      stockId: stock.id,
      analysisId: analysis?.evaluationId === ev.id ? analysis.id : null,
      evaluationId: ev.id,
      dataMode,
      signal: type,
      confidence: fromAnalysis ?? Math.round(ev.overallScore ?? 50),
      entryPrice:
        type === 'BUY' && ev.entryLow !== null && ev.entryHigh !== null
          ? round((ev.entryLow + ev.entryHigh) / 2, 2)
          : null,
      entryLow: type === 'BUY' ? ev.entryLow : null,
      entryHigh: type === 'BUY' ? ev.entryHigh : null,
      targetPrice: type === 'BUY' ? ev.target1 : null,
      target2: type === 'BUY' ? ev.target2 : null,
      stopLoss: type === 'BUY' ? ev.stopLoss : null,
      riskRewardRatio: type === 'BUY' ? ev.riskReward : null,
      suggestedQuantity: type === 'BUY' ? ev.positionSizeHint : null,
      reasoning,
      validUntil,
    });
    result.created += 1;
    return { outcome: 'CREATED', signalId: id, message: null };
  }

  /** LLM narrative when possible; deterministic reasoning on any failure (the signal itself never depends on the LLM). */
  private async narrative(
    stock: Stock,
    ev: StoredEvaluationDetail,
    type: 'BUY' | 'SELL',
    result: SignalRunResult,
  ): Promise<string[]> {
    try {
      const ctx = await this.deps.context.build(stock.symbol);
      const res = await this.deps.gateway.complete({
        purpose: 'trade_signal',
        prompt: renderPrompt(loadPrompt('trade_signal_v1'), { signal: type, context: ctx.text }),
        schema: TradeSignalNarrativeSchema,
        schemaName: SCHEMA_NAMES.tradeSignal,
        maxOutputTokens: 700,
        validate: (d) => [
          ...bannedPhraseIssues(d),
          ...unknownRupeeIssues(d, ctx.text),
          ...citationIssues(d.facts, d, ctx.ids),
        ],
      });
      const lines = capList(res.data.reasoning, 6);
      if (lines.length > 0) return lines;
    } catch (error) {
      result.notes.push(
        `${stock.symbol}: narrative fallback (${error instanceof Error ? error.message : String(error)})`,
      );
    }
    result.narrativeFallbacks += 1;
    const inr = (x: number | null) => (x === null ? 'n/a' : formatInr(x));
    return [
      `Computed action state ${ev.actionState} with ${ev.recommendationBias ?? 'no'} bias (paper trade only).`,
      type === 'BUY'
        ? `Entry zone ${inr(ev.entryLow)} to ${inr(ev.entryHigh)}; stop-loss ${inr(ev.stopLoss)}; first target ${inr(ev.target1)}; risk:reward ${ev.riskReward === null ? 'n/a' : ev.riskReward.toFixed(2)}.`
        : 'The evaluation indicates reducing the paper position.',
      `Invalidation: ${ev.invalidation ?? 'n/a'}`,
    ];
  }
}
