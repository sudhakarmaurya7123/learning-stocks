import type { Logger } from 'pino';
import type { LlmGateway } from '../../ai/LlmGateway.js';
import {
  buildMarketContext,
  type MarketContextInput,
  vixRiskLevel,
} from '../../ai/marketContext.js';
import {
  bannedPhraseIssues,
  capList,
  citationIssues,
  clampText,
  sectorIssues,
  unknownRupeeIssues,
} from '../../ai/outputGuards.js';
import { loadPrompt, renderPrompt } from '../../ai/promptLoader.js';
import { MarketSummarySchema, SCHEMA_NAMES } from '../../ai/schemas.js';
import { citedIds, sourcesFor } from '../../ai/sources.js';
import type { ActionState, DataMode, JobStatus, Trend } from '../../domain/enums.js';
import { sha256Hex } from '../../rag/documents.js';
import type { Retriever } from '../../rag/retriever.js';
import type { EvaluationRepository } from '../../repositories/EvaluationRepository.js';
import type { MarketDataRepository } from '../../repositories/MarketDataRepository.js';
import type { MarketRepository } from '../../repositories/MarketRepository.js';
import type { MarketSummaryRepository } from '../../repositories/MarketSummaryRepository.js';
import type { NewsAnalysisRepository } from '../../repositories/NewsAnalysisRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { returnPct } from '../../technical/stats.js';
import { toAppError } from '../../utils/errors.js';
import { toIst } from '../../utils/ist.js';
import { parseEvaluationInputs } from '../rag/StockContextService.js';

const DAY_MS = 86_400_000;
export const MARKET_INDICES = ['NIFTY50', 'SENSEX', 'BANKNIFTY', 'NIFTYIT', 'NIFTYPHARMA'] as const;
const MARKET_QUERY = 'Indian stock market outlook: NIFTY 50, SENSEX, sectors, drivers and risks';

export type MarketSummaryOutcome =
  'GENERATED' | 'CACHED' | 'INSUFFICIENT_DATA' | 'FAILED' | 'BUDGET_EXHAUSTED';

export interface MarketSummaryRunResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  outcome: MarketSummaryOutcome;
  summaryId: string | null;
  notes: string[];
}

export interface MarketSummaryServiceDeps {
  markets: MarketRepository;
  stocks: StockRepository;
  marketData: MarketDataRepository;
  evaluations: EvaluationRepository;
  newsAnalyses: NewsAnalysisRepository;
  summaries: MarketSummaryRepository;
  retriever: Retriever;
  gateway: LlmGateway;
  systemLogs: SystemLogRepository;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
}

/** PRD §3.1 / §9.3: AI market sentiment over deterministic market context; regime, trend and risk come from code. */
export class MarketSummaryService {
  constructor(private readonly deps: MarketSummaryServiceDeps) {}

  async run(request: { jobName: string; force?: boolean }): Promise<MarketSummaryRunResult> {
    const { systemLogs, logger, dataMode } = this.deps;
    const runId = await systemLogs.startRun({
      service: 'MarketSummaryService',
      jobName: request.jobName,
      operation: 'market-summary',
    });
    const result: MarketSummaryRunResult = {
      runId,
      status: 'SUCCESS',
      outcome: 'GENERATED',
      summaryId: null,
      notes: [],
    };
    let runError: unknown;
    try {
      const now = this.deps.now?.() ?? new Date();
      const nifty = await this.deps.markets.findBySymbol('NIFTY50');
      const evals = await this.deps.evaluations.latestForAll(dataMode);
      if (!nifty || evals.length === 0) {
        result.outcome = 'INSUFFICIENT_DATA';
        result.status = 'SKIPPED';
        result.notes.push(
          nifty ? 'no evaluations stored: run pnpm evaluate first' : 'NIFTY 50 is not configured',
        );
        return result;
      }
      const input = await this.gather(evals, now);
      const ctx = buildMarketContext(input);
      const template = loadPrompt('market_analysis_v1');
      const inputHash = sha256Hex(
        [template.templateHash, ctx.contextHash, this.deps.gateway.chatModel].join('|'),
      );
      if (!request.force) {
        const cached = await this.deps.summaries.findByHash(
          nifty.id,
          dataMode,
          inputHash,
          template.version,
        );
        if (cached) {
          result.outcome = 'CACHED';
          result.summaryId = cached.id;
          return result;
        }
      }
      try {
        const res = await this.deps.gateway.complete({
          purpose: 'market_summary',
          prompt: renderPrompt(template, { context: ctx.text }),
          schema: MarketSummarySchema,
          schemaName: SCHEMA_NAMES.marketSummary,
          maxOutputTokens: 1200,
          validate: (d) => [
            ...bannedPhraseIssues(d),
            ...unknownRupeeIssues(d, ctx.text),
            ...citationIssues(d.facts, d, ctx.ids),
            ...sectorIssues([...d.sectors_positive, ...d.sectors_negative], ctx.sectors),
          ],
        });
        const d = res.data;
        const facts = d.facts.slice(0, 10);
        const saved = await this.deps.summaries.insert({
          marketId: nifty.id,
          dataMode,
          dataAsOf: input.regime?.asOf ?? now,
          sentiment: d.sentiment,
          sentimentScore: d.sentiment_score,
          confidence: d.confidence,
          trend: input.regime?.niftyTrend ?? null,
          regime: input.regime?.regime ?? null,
          riskLevel: vixRiskLevel(input.regime?.vix ?? null),
          summary: clampText(d.summary, 1200),
          keyDrivers: capList(d.key_drivers),
          keyRisks: capList(d.key_risks),
          sectorsPositive: capList(d.sectors_positive, 8),
          sectorsNegative: capList(d.sectors_negative, 8),
          sources: sourcesFor(citedIds(d, facts), ctx.blocks, input.documents),
          inputHash,
          model: res.model,
          promptVersion: template.version,
        });
        result.summaryId = saved.id;
      } catch (error) {
        const e = toAppError(error);
        if (e.code !== 'BUDGET_EXCEEDED') throw e;
        result.outcome = 'BUDGET_EXHAUSTED';
        result.status = 'SKIPPED';
        result.notes.push(
          'LLM_BUDGET_EXHAUSTED: the latest stored summary is served until IST midnight',
        );
      }
    } catch (error) {
      runError = error;
      result.outcome = 'FAILED';
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: 1,
          inserted: result.outcome === 'GENERATED' ? 1 : 0,
          skipped: result.outcome === 'GENERATED' ? 0 : 1,
          failed: result.outcome === 'FAILED' ? 1 : 0,
        },
        message: result.outcome,
        ...(runError === undefined ? {} : { error: runError }),
        details: { notes: result.notes },
      });
    }
    logger.info({ runId, outcome: result.outcome }, 'market summary run finished');
    return result;
  }

  private async gather(
    evals: Awaited<ReturnType<EvaluationRepository['latestForAll']>>,
    now: Date,
  ): Promise<MarketContextInput> {
    const { dataMode } = this.deps;
    const indices: MarketContextInput['indices'] = [];
    for (const symbol of MARKET_INDICES) {
      const market = await this.deps.markets.findBySymbol(symbol);
      if (!market) continue;
      const ref = { kind: 'market' as const, id: market.id };
      const quote = await this.deps.marketData.latestQuote(ref, dataMode);
      const bars = await this.deps.marketData.getBars(
        ref,
        dataMode,
        '1d',
        new Date(now.getTime() - 130 * DAY_MS),
        now,
      );
      const closes = bars.map((b) => ({ date: toIst(b.ts).date, close: b.close }));
      indices.push({
        symbol,
        name: market.name,
        price: quote?.price ?? null,
        changePercent: quote?.changePercent ?? null,
        asOf: quote?.ts ?? null,
        timeframe: quote?.timeframe ?? null,
        returnsPct: {
          w1: returnPct(closes, 5),
          m1: returnPct(closes, 21),
          m3: returnPct(closes, 63),
        },
      });
    }
    const newest = [...evals].sort((a, b) => b.dataAsOf.getTime() - a.dataAsOf.getTime())[0];
    const market = newest ? parseEvaluationInputs(newest.inputs).market : null;
    const stocks = new Map((await this.deps.stocks.listActive()).map((s) => [s.id, s]));
    const sectors = new Map<string, { trend: Trend | null; stocks: number }>();
    const byAction: Partial<Record<ActionState, number>> = {};
    const byTrend: Partial<Record<Trend, number>> = {};
    for (const e of evals) {
      byAction[e.actionState] = (byAction[e.actionState] ?? 0) + 1;
      if (e.trend) byTrend[e.trend] = (byTrend[e.trend] ?? 0) + 1;
      const sector = stocks.get(e.stockId)?.sector;
      if (!sector) continue;
      const entry = sectors.get(sector) ?? {
        trend: parseEvaluationInputs(e.inputs).sectorTrend,
        stocks: 0,
      };
      entry.stocks += 1;
      sectors.set(sector, entry);
    }
    const sentiments = await this.deps.newsAnalyses.marketSentiments(
      dataMode,
      new Date(now.getTime() - 7 * DAY_MS),
    );
    const avg =
      sentiments.length > 0
        ? sentiments.reduce((s, x) => s + x.sentimentScore, 0) / sentiments.length
        : null;
    const documents = await this.deps.retriever.retrieve({
      query: MARKET_QUERY,
      stockId: null,
      sourceTypes: ['NEWS'],
    });
    return {
      dataMode,
      indices,
      regime:
        newest && market
          ? {
              asOf: newest.dataAsOf,
              regime: market.regime,
              niftyTrend: market.niftyTrend,
              vix: market.vix,
            }
          : null,
      sectors: [...sectors.entries()]
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([sector, v]) => ({ sector, ...v })),
      breadth: newest
        ? { asOf: newest.dataAsOf, evaluated: evals.length, byAction, byTrend }
        : null,
      newsSentiment: sentiments[0]
        ? {
            asOf: sentiments[0].publishedAt,
            articles: sentiments.length,
            bullish: sentiments.filter((s) => s.sentiment === 'BULLISH').length,
            neutral: sentiments.filter((s) => s.sentiment === 'NEUTRAL').length,
            bearish: sentiments.filter((s) => s.sentiment === 'BEARISH').length,
            avgScore: avg,
          }
        : null,
      documents,
    };
  }
}
