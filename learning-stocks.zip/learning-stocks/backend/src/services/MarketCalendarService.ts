import type { Exchange } from '../domain/enums.js';
import type { Holiday, TradingSession, TradingSessions } from '../domain/types.js';
import type { Cache } from '../utils/cache.js';
import { addDays, isoWeekdayOf, istToUtc, toIst } from '../utils/ist.js';

export interface HolidayLookup {
  listBetween(exchange: Exchange, from: string, to: string): Promise<Holiday[]>;
}

export const REGULAR_SESSION = { open: '09:15:00', close: '15:30:00' } as const;
const SEARCH_DAYS = 30;
const HOLIDAY_TTL_MS = 60 * 60 * 1000;
/**
 * How long after the close a session's daily bar is considered final.
 *
 * Must match `DEFAULT_DAILY_SETTLE_MS` in services/marketData/barNormalizer.ts, which is what
 * actually withholds an unsettled daily bar from storage. It is restated rather than imported
 * because the calendar is a lower layer than the ingestion pipeline and must not depend on it;
 * barNormalizer.test.ts and this file's tests both pin the 30-minute value.
 */
const DAILY_SETTLE_MS = 30 * 60_000;

export type MarketPhase = 'OPEN' | 'CLOSED' | 'WEEKEND' | 'HOLIDAY';

export interface MarketStatus {
  exchange: Exchange;
  isOpen: boolean;
  phase: MarketPhase;
  holiday: string | null;
  nextOpen: Date | null;
  asOf: Date;
}

/** Canonical market calendar (SQL is_market_open / next_market_open mirror it; parity-tested). */
export class MarketCalendarService implements TradingSessions {
  constructor(
    private readonly holidays: HolidayLookup,
    private readonly cache: Cache,
  ) {}

  private holidaysFor(exchange: Exchange, year: string): Promise<Holiday[]> {
    return this.cache.getOrSet(`calendar:holidays:${exchange}:${year}`, HOLIDAY_TTL_MS, () =>
      this.holidays.listBetween(exchange, `${year}-01-01`, `${year}-12-31`),
    );
  }

  private async holidayOn(exchange: Exchange, date: string): Promise<Holiday | undefined> {
    return (await this.holidaysFor(exchange, date.slice(0, 4))).find((h) => h.date === date);
  }

  /** A year counts as covered once any holiday row exists for it (every exchange year has some). */
  async hasCalendar(exchange: Exchange, year: string): Promise<boolean> {
    return (await this.holidaysFor(exchange, year)).length > 0;
  }

  /** Session window for an IST date, or null when closed all day. */
  async sessionOn(exchange: Exchange, date: string): Promise<TradingSession | null> {
    const holiday = await this.holidayOn(exchange, date);
    if (holiday) {
      if (holiday.specialOpen === null || holiday.specialClose === null) return null;
      return {
        open: istToUtc(date, holiday.specialOpen),
        close: istToUtc(date, holiday.specialClose),
      };
    }
    if (isoWeekdayOf(date) >= 6) return null;
    return {
      open: istToUtc(date, REGULAR_SESSION.open),
      close: istToUtc(date, REGULAR_SESSION.close),
    };
  }

  async isOpen(exchange: Exchange, at: Date): Promise<boolean> {
    const session = await this.sessionOn(exchange, toIst(at).date);
    return session !== null && at >= session.open && at < session.close;
  }

  async nextOpen(exchange: Exchange, at: Date): Promise<Date | null> {
    const start = toIst(at).date;
    for (let i = 0; i <= SEARCH_DAYS; i += 1) {
      const session = await this.sessionOn(exchange, addDays(start, i));
      if (session && session.open > at) return session.open;
    }
    return null;
  }

  async isTradingDay(exchange: Exchange, date: string): Promise<boolean> {
    return (await this.sessionOn(exchange, date)) !== null;
  }

  /**
   * The open of the most recent session whose data has settled, or null if none is in range.
   *
   * This is the reference point for judging whether a *daily* fact is current. A duration cannot
   * answer that: daily bars are stored only after the close plus the settle window (Phase 3), so
   * during a session the newest stored bar is the previous session's — already over 24 hours old
   * at today's open, and 72 hours old on a Monday. Comparing against this instant instead reports
   * "fresh" for exactly the bars that are as current as a daily bar can be (Phase 9 finding I4).
   *
   * The settle window is honoured rather than just the close: inside it the provider may still
   * revise the closing auction, so the session is not yet a complete fact.
   */
  async lastCompleteSessionOpen(exchange: Exchange, at: Date): Promise<Date | null> {
    const start = toIst(at).date;
    for (let i = 0; i <= SEARCH_DAYS; i += 1) {
      const session = await this.sessionOn(exchange, addDays(start, -i));
      if (session && at.getTime() >= session.close.getTime() + DAILY_SETTLE_MS) return session.open;
    }
    return null;
  }

  async status(exchange: Exchange, at: Date): Promise<MarketStatus> {
    const { date, isoWeekday } = toIst(at);
    const isOpen = await this.isOpen(exchange, at);
    const holiday = await this.holidayOn(exchange, date);
    let phase: MarketPhase = 'CLOSED';
    if (isOpen) phase = 'OPEN';
    else if (holiday && holiday.specialOpen === null) phase = 'HOLIDAY';
    else if (!holiday && isoWeekday >= 6) phase = 'WEEKEND';
    return {
      exchange,
      isOpen,
      phase,
      holiday: holiday?.description ?? null,
      nextOpen: isOpen ? null : await this.nextOpen(exchange, at),
      asOf: at,
    };
  }
}
