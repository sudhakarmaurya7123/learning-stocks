import type { MarketDataProvider } from '../../providers/market/types.js';
import type { ProviderSymbolRepository } from '../../repositories/ProviderSymbolRepository.js';
import { isAppError } from '../../utils/errors.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';

const LOOKBACK_DAYS = 400;

export interface VerificationOutcome {
  symbol: string;
  providerSymbol: string;
  kind: 'stock' | 'market';
  verified: boolean;
  dailyBars: number;
  reason: string;
}

/** A mapping is verified only if the provider returns enough real daily history (not just a snapshot). */
export async function verifyProviderSymbols(deps: {
  provider: MarketDataProvider;
  providerSymbols: ProviderSymbolRepository;
  now: () => Date;
  minDailyBars?: number;
  symbols?: readonly string[];
  retry?: RetryOptions;
}): Promise<VerificationOutcome[]> {
  const minBars = deps.minDailyBars ?? 200;
  const entries = await deps.providerSymbols.listByProvider(deps.provider.name, deps.symbols);
  const outcomes: VerificationOutcome[] = [];
  for (const entry of entries) {
    const now = deps.now();
    let dailyBars = 0;
    let reason: string;
    try {
      const bars = await withRetry(
        () =>
          deps.provider.getHistorical(
            { providerSymbol: entry.providerSymbol, exchange: entry.exchange, kind: entry.kind },
            new Date(now.getTime() - LOOKBACK_DAYS * 86_400_000),
            now,
            '1d',
          ),
        deps.retry,
      );
      dailyBars = bars.filter((b) => b.close !== null).length;
      reason =
        dailyBars >= minBars
          ? 'OK'
          : `INSUFFICIENT_HISTORY (${dailyBars} daily bars, need ${minBars})`;
    } catch (error) {
      reason = isAppError(error) ? `${error.code}: ${error.message}` : `INTERNAL: ${String(error)}`;
    }
    const verified = reason === 'OK';
    await deps.providerSymbols.setVerified(deps.provider.name, entry.providerSymbol, verified);
    outcomes.push({
      symbol: entry.symbol,
      providerSymbol: entry.providerSymbol,
      kind: entry.kind,
      verified,
      dailyBars,
      reason,
    });
  }
  return outcomes;
}
