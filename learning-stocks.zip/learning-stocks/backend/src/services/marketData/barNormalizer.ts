import type { BarInterval, DataMode } from '../../domain/enums.js';
import type { Bar, InstrumentRef, TradingSession } from '../../domain/types.js';
import { INTERVAL_MS, type ProviderBar } from '../../providers/market/types.js';
import { istToUtc, toIst } from '../../utils/ist.js';

export type DropReason = 'EMPTY' | 'INCOMPLETE' | 'DUPLICATE_IN_BATCH' | 'HOLIDAY_PLACEHOLDER';
export type RejectReason =
  | 'NON_POSITIVE_PRICE'
  | 'OHLC_INCONSISTENT'
  | 'NEGATIVE_VOLUME'
  | 'FUTURE_TIMESTAMP'
  | 'NOT_A_TRADING_DAY'
  | 'OUTSIDE_SESSION';

/** Daily bars are final only this long after the close (providers revise the closing auction). */
export const DEFAULT_DAILY_SETTLE_MS = 30 * 60_000;

/** Intraday bars from delayed providers can still receive late trades just after they end. */
export const DEFAULT_INTRADAY_SETTLE_MS = 2 * 60_000;

const REGULAR_OPEN = '09:15:00';
const REGULAR_CLOSE = '15:30:00';

export interface NormalizeContext {
  instrument: InstrumentRef;
  dataMode: DataMode;
  source: string;
  timeframe: BarInterval;
  now: Date;
  sessionFor(date: string): TradingSession | null;
  /** False for dates whose year has no holiday calendar loaded: the provider's sessions are trusted. */
  calendarCovers?: (date: string) => boolean;
  dailySettleMs?: number;
  intradaySettleMs?: number;
}

export interface NormalizeResult {
  bars: Bar[];
  dropped: Partial<Record<DropReason, number>>;
  rejected: Partial<Record<RejectReason, number>>;
  /** Bars accepted on dates outside the loaded holiday calendar (provider authority). */
  uncalendared: number;
}

function bump<K extends string>(counts: Partial<Record<K, number>>, key: K): void {
  counts[key] = (counts[key] ?? 0) + 1;
}

/**
 * Validates and normalises provider bars (PRD §6.5). Never stores partial truth:
 * empty and in-progress bars are dropped; invalid bars are rejected and counted.
 * Daily bars are re-stamped at the session open of their IST date (bar ts = open time).
 */
export function normalizeBars(raw: readonly ProviderBar[], ctx: NormalizeContext): NormalizeResult {
  const dropped: NormalizeResult['dropped'] = {};
  const rejected: NormalizeResult['rejected'] = {};
  const byTs = new Map<number, Bar>();
  const settleMs = ctx.dailySettleMs ?? DEFAULT_DAILY_SETTLE_MS;
  const intradaySettleMs = ctx.intradaySettleMs ?? DEFAULT_INTRADAY_SETTLE_MS;
  let uncalendared = 0;
  const nowMs = ctx.now.getTime();

  for (const r of raw) {
    const { open, high, low, close } = r;
    if (open === null || high === null || low === null || close === null) {
      bump(dropped, 'EMPTY');
      continue;
    }
    if (![open, high, low, close].every((v) => Number.isFinite(v) && v > 0)) {
      bump(rejected, 'NON_POSITIVE_PRICE');
      continue;
    }
    if (high < Math.max(open, close, low) || low > Math.min(open, close)) {
      bump(rejected, 'OHLC_INCONSISTENT');
      continue;
    }
    const volume = r.volume ?? 0;
    if (!Number.isFinite(volume) || volume < 0) {
      bump(rejected, 'NEGATIVE_VOLUME');
      continue;
    }
    if (r.ts.getTime() > nowMs) {
      bump(rejected, 'FUTURE_TIMESTAMP');
      continue;
    }
    const date = toIst(r.ts).date;
    let session = ctx.sessionFor(date);
    if (!session) {
      // Providers (e.g. Yahoo) emit flat, zero-volume carry-forward bars on holidays: not data, not an error.
      const placeholder = open === high && high === low && low === close && volume === 0;
      if (placeholder) {
        bump(dropped, 'HOLIDAY_PLACEHOLDER');
        continue;
      }
      if (ctx.calendarCovers?.(date) ?? true) {
        bump(rejected, 'NOT_A_TRADING_DAY');
        continue;
      }
      // No holiday calendar for this year: a priced bar is evidence of a real (e.g. Budget-Saturday) session.
      session = { open: istToUtc(date, REGULAR_OPEN), close: istToUtc(date, REGULAR_CLOSE) };
      uncalendared += 1;
    }

    let ts: Date;
    if (ctx.timeframe === '1d') {
      ts = session.open;
      if (nowMs < session.close.getTime() + settleMs) {
        bump(dropped, 'INCOMPLETE');
        continue;
      }
    } else {
      if (r.ts < session.open || r.ts >= session.close) {
        bump(rejected, 'OUTSIDE_SESSION');
        continue;
      }
      ts = r.ts;
      const barEnd = Math.min(r.ts.getTime() + INTERVAL_MS[ctx.timeframe], session.close.getTime());
      if (nowMs < barEnd + intradaySettleMs) {
        bump(dropped, 'INCOMPLETE');
        continue;
      }
    }

    if (byTs.has(ts.getTime())) bump(dropped, 'DUPLICATE_IN_BATCH');
    byTs.set(ts.getTime(), {
      instrument: ctx.instrument,
      dataMode: ctx.dataMode,
      timeframe: ctx.timeframe,
      ts,
      open,
      high,
      low,
      close,
      adjustedClose: r.adjustedClose ?? null,
      volume: Math.round(volume),
      change: null,
      changePercent: null,
      vwap: null,
      source: ctx.source,
    });
  }

  const bars = [...byTs.values()].sort((a, b) => a.ts.getTime() - b.ts.getTime());
  return { bars, dropped, rejected, uncalendared };
}
