import type { Logger } from 'pino';
import type { BarInterval, DataMode, Exchange, JobStatus } from '../../domain/enums.js';
import type { InstrumentRef, TradingSession, TradingSessions } from '../../domain/types.js';
import type { MarketDataProvider, ProviderInstrumentRef } from '../../providers/market/types.js';
import type { MarketDataRepository } from '../../repositories/MarketDataRepository.js';
import type { MarketRepository } from '../../repositories/MarketRepository.js';
import type {
  ProviderSymbolEntry,
  ProviderSymbolRepository,
} from '../../repositories/ProviderSymbolRepository.js';
import type { StockRepository } from '../../repositories/StockRepository.js';
import type { SystemLogRepository } from '../../repositories/SystemLogRepository.js';
import { mapWithConcurrency } from '../../utils/concurrency.js';
import { AppError, type ErrorCode, isAppError } from '../../utils/errors.js';
import { addDays, toIst } from '../../utils/ist.js';
import { type RetryOptions, withRetry } from '../../utils/retry.js';
import {
  DEFAULT_DAILY_SETTLE_MS,
  type DropReason,
  normalizeBars,
  type RejectReason,
} from './barNormalizer.js';

const DAY_MS = 86_400_000;
const SESSION_LOOKBACK_DAYS = 14;

export interface SyncRequest {
  jobName: string;
  timeframe: BarInterval;
  from: Date;
  to: Date;
  /** Internal symbols (stocks and/or markets). Omit for all active instruments. */
  symbols?: readonly string[];
  includeIndices?: boolean;
}

export interface InstrumentFailure {
  symbol: string;
  providerSymbol: string;
  code: ErrorCode;
  message: string;
}

export interface SyncResult {
  runId: string;
  status: Exclude<JobStatus, 'STARTED'>;
  provider: string;
  dataMode: DataMode;
  timeframe: BarInterval;
  from: Date;
  to: Date;
  instruments: { total: number; succeeded: number; failed: number };
  bars: {
    fetched: number;
    inserted: number;
    duplicates: number;
    dropped: number;
    rejected: number;
  };
  droppedByReason: Partial<Record<DropReason, number>>;
  rejectedByReason: Partial<Record<RejectReason, number>>;
  failures: InstrumentFailure[];
  notes: string[];
}

export interface MarketDataServiceDeps {
  provider: MarketDataProvider;
  providerSymbols: ProviderSymbolRepository;
  stocks: StockRepository;
  markets: MarketRepository;
  marketData: MarketDataRepository;
  systemLogs: SystemLogRepository;
  sessions: TradingSessions;
  dataMode: DataMode;
  logger: Logger;
  now?: () => Date;
  retry?: RetryOptions;
  concurrency?: number;
  dailySettleMs?: number;
}

interface Target {
  entry: ProviderSymbolEntry;
  ref: InstrumentRef;
  providerRef: ProviderInstrumentRef;
}

function addCounts<K extends string>(
  into: Partial<Record<K, number>>,
  from: Partial<Record<K, number>>,
): void {
  for (const [key, value] of Object.entries(from) as Array<[K, number | undefined]>) {
    into[key] = (into[key] ?? 0) + (value ?? 0);
  }
}

const sumValues = (rec: Partial<Record<string, number>>): number =>
  Object.values(rec).reduce<number>((s, v) => s + (v ?? 0), 0);

export class MarketDataService {
  private readonly now: () => Date;

  constructor(private readonly deps: MarketDataServiceDeps) {
    this.now = deps.now ?? (() => new Date());
  }

  async sync(request: SyncRequest): Promise<SyncResult> {
    const { provider, systemLogs, logger } = this.deps;
    const now = this.now();
    const runId = await systemLogs.startRun({
      service: 'MarketDataService',
      jobName: request.jobName,
      operation: `sync:${request.timeframe}`,
    });
    const result: SyncResult = {
      runId,
      status: 'SUCCESS',
      provider: provider.name,
      dataMode: this.deps.dataMode,
      timeframe: request.timeframe,
      from: request.from,
      to: request.to < now ? request.to : now,
      instruments: { total: 0, succeeded: 0, failed: 0 },
      bars: { fetched: 0, inserted: 0, duplicates: 0, dropped: 0, rejected: 0 },
      droppedByReason: {},
      rejectedByReason: {},
      failures: [],
      notes: [],
    };
    let runError: unknown;

    try {
      const caps = provider.capabilities();
      if (!caps.intervals.includes(request.timeframe)) {
        throw new AppError(
          'UNSUPPORTED',
          `Provider ${provider.name} does not support ${request.timeframe} bars`,
        );
      }
      const lookback = caps.maxLookbackDays[request.timeframe];
      if (lookback !== undefined) {
        const earliest = new Date(now.getTime() - lookback * DAY_MS);
        if (result.from < earliest) {
          result.notes.push(
            `from clamped to ${earliest.toISOString()}: ${provider.name} keeps ${lookback} days of ${request.timeframe} data`,
          );
          result.from = earliest;
        }
      }

      const targets = await this.resolveTargets(request, caps.exchanges, result);
      result.instruments.total = targets.length + result.failures.length;
      const { sessionMaps, coverage } = await this.loadSessions(targets, result.from, result.to);
      let uncalendared = 0;

      await mapWithConcurrency(targets, this.deps.concurrency ?? 4, async (target) => {
        try {
          const raw = await withRetry(
            () =>
              provider.getHistorical(target.providerRef, result.from, result.to, request.timeframe),
            this.deps.retry,
          );
          result.bars.fetched += raw.length;
          const sessions =
            sessionMaps.get(target.entry.exchange) ?? new Map<string, TradingSession | null>();
          const normalized = normalizeBars(raw, {
            instrument: target.ref,
            dataMode: this.deps.dataMode,
            source: provider.name,
            timeframe: request.timeframe,
            now,
            sessionFor: (date) => sessions.get(date) ?? null,
            calendarCovers: (date) =>
              coverage.get(target.entry.exchange)?.get(date.slice(0, 4)) ?? true,
            dailySettleMs: this.deps.dailySettleMs ?? DEFAULT_DAILY_SETTLE_MS,
          });
          uncalendared += normalized.uncalendared;
          addCounts(result.droppedByReason, normalized.dropped);
          addCounts(result.rejectedByReason, normalized.rejected);
          const { inserted, skipped } = await this.deps.marketData.insertBars(normalized.bars);
          // Always recompute (not only for new rows) so earlier NULL/stale changes heal.
          await this.deps.marketData.recomputeChanges(
            target.ref,
            this.deps.dataMode,
            provider.name,
            result.from,
            result.to,
          );
          result.bars.inserted += inserted;
          result.bars.duplicates += skipped;
          result.instruments.succeeded += 1;
        } catch (error) {
          const e = isAppError(error)
            ? error
            : new AppError('INTERNAL', error instanceof Error ? error.message : String(error));
          result.failures.push({
            symbol: target.entry.symbol,
            providerSymbol: target.entry.providerSymbol,
            code: e.code,
            message: e.message,
          });
          logger.warn(
            { symbol: target.entry.symbol, code: e.code },
            'market data sync failed for instrument',
          );
        }
      });

      if (uncalendared > 0) {
        result.notes.push(
          `${uncalendared} bars fall on dates with no holiday calendar loaded; accepted as sessions reported by ${provider.name}`,
        );
      }
      result.instruments.failed = result.failures.length;
      result.bars.dropped = sumValues(result.droppedByReason);
      result.bars.rejected = sumValues(result.rejectedByReason);
      result.status =
        result.instruments.total === 0 || result.instruments.succeeded === 0
          ? 'FAILED'
          : result.failures.length > 0 || result.bars.rejected > 0
            ? 'PARTIAL'
            : 'SUCCESS';
    } catch (error) {
      runError = error;
      result.status = 'FAILED';
      result.notes.push(error instanceof Error ? error.message : String(error));
    } finally {
      await systemLogs.finishRun(runId, {
        status: result.status,
        counts: {
          fetched: result.bars.fetched,
          inserted: result.bars.inserted,
          skipped: result.bars.duplicates + result.bars.dropped,
          failed: result.bars.rejected,
        },
        message: this.summary(result),
        ...(runError === undefined ? {} : { error: runError }),
        details: {
          failures: result.failures,
          rejected: result.rejectedByReason,
          dropped: result.droppedByReason,
          notes: result.notes,
          provider: provider.name,
          timeframe: request.timeframe,
        },
      });
    }
    logger.info(
      {
        runId,
        status: result.status,
        inserted: result.bars.inserted,
        failed: result.instruments.failed,
      },
      'market data sync finished',
    );
    return result;
  }

  private async resolveTargets(
    request: SyncRequest,
    exchanges: readonly Exchange[],
    result: SyncResult,
  ): Promise<Target[]> {
    let entries = await this.deps.providerSymbols.listByProvider(
      this.deps.provider.name,
      request.symbols,
    );
    if (request.includeIndices === false) entries = entries.filter((e) => e.kind === 'stock');
    if (request.symbols) {
      const found = new Set(entries.map((e) => e.symbol));
      const missing = request.symbols.map((s) => s.toUpperCase()).filter((s) => !found.has(s));
      if (missing.length > 0)
        result.notes.push(
          `unknown or unmapped symbols for ${this.deps.provider.name}: ${missing.join(', ')}`,
        );
    }
    const targets: Target[] = [];
    for (const entry of entries) {
      if (!exchanges.includes(entry.exchange)) {
        result.failures.push({
          symbol: entry.symbol,
          providerSymbol: entry.providerSymbol,
          code: 'UNSUPPORTED',
          message: `${this.deps.provider.name} does not cover ${entry.exchange}`,
        });
        continue;
      }
      const instrument =
        entry.kind === 'stock'
          ? await this.deps.stocks.findBySymbol(entry.symbol, entry.exchange)
          : await this.deps.markets.findBySymbol(entry.symbol);
      if (!instrument) continue;
      targets.push({
        entry,
        ref:
          entry.kind === 'stock'
            ? { kind: 'stock', id: instrument.id }
            : { kind: 'market', id: instrument.id },
        providerRef: {
          providerSymbol: entry.providerSymbol,
          exchange: entry.exchange,
          kind: entry.kind,
        },
      });
    }
    return targets;
  }

  private async loadSessions(
    targets: Target[],
    from: Date,
    to: Date,
  ): Promise<{
    sessionMaps: Map<Exchange, Map<string, TradingSession | null>>;
    coverage: Map<Exchange, Map<string, boolean>>;
  }> {
    const sessionMaps = new Map<Exchange, Map<string, TradingSession | null>>();
    const coverage = new Map<Exchange, Map<string, boolean>>();
    const last = toIst(to).date;
    for (const exchange of new Set(targets.map((t) => t.entry.exchange))) {
      const days = new Map<string, TradingSession | null>();
      const years = new Map<string, boolean>();
      for (
        let d = addDays(toIst(from).date, -SESSION_LOOKBACK_DAYS);
        d <= last;
        d = addDays(d, 1)
      ) {
        days.set(d, await this.deps.sessions.sessionOn(exchange, d));
        const year = d.slice(0, 4);
        if (!years.has(year)) years.set(year, await this.deps.sessions.hasCalendar(exchange, year));
      }
      sessionMaps.set(exchange, days);
      coverage.set(exchange, years);
    }
    return { sessionMaps, coverage };
  }

  private summary(r: SyncResult): string {
    const failed = r.failures.map((f) => `${f.symbol} (${f.code})`).join(', ');
    return (
      `${r.instruments.succeeded}/${r.instruments.total} instruments ok; ${r.bars.inserted} inserted, ${r.bars.duplicates} duplicates, ` +
      `${r.bars.dropped} dropped, ${r.bars.rejected} rejected${failed ? `; failed: ${failed}` : ''}`
    );
  }
}
