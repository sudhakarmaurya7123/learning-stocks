import type { JobStatus } from '../domain/enums.js';
import type { RunCounts } from '../repositories/SystemLogRepository.js';

/** Every job the worker knows. PRD §13, plus the chained-only steps that table implies. */
export const JOB_NAMES = [
  'market.sync.intraday',
  'market.sync.eod',
  'fundamentals.sync',
  'news.sync',
  'embeddings.generate',
  'news.sentiment',
  'evaluation.compute',
  'ai.stock.analyze',
  'ai.market.summary',
  'ai.daily.summary',
  'signals.generate',
  'signals.expire',
  'holidays.check',
] as const;

export type JobName = (typeof JOB_NAMES)[number];

/**
 * What a job is told. `origin` names the parent that chained it, which is how
 * `evaluation.compute` knows whether to continue to AI analysis (only the EOD path does).
 */
export interface JobPayload {
  origin?: string;
  symbols?: readonly string[];
  /**
   * Bypasses the AI services' hash cache and min-interval (POST /ai/regenerate only).
   *
   * Deliberately NOT a gate bypass: handlers pass this straight to the AI services, so reusing
   * it for manual triggers would make one click force-regenerate every stock.
   */
  force?: boolean;
  /** An operator pressed a button: bypasses a *calendar* refusal, never an availability one. */
  manual?: boolean;
}

/** A gate's verdict. A refusal carries the reason, which is what gets logged on the SKIPPED row. */
export type GateResult =
  | { run: true }
  /**
   * `kind` says what sort of refusal this is, because a manual trigger may override one and not
   * the other. It lives on the refusal rather than the gate: allGates composes gates of different
   * kinds, so a composed gate has no single kind, but a refusal always comes from exactly one.
   */
  | { run: false; kind: 'calendar' | 'availability'; reason: string };

export interface JobOutcome {
  status: Exclude<JobStatus, 'STARTED'>;
  /** The service's own system_logs run id, or null when no service ran. */
  runId: string | null;
  message: string;
  /** Follow-ups to enqueue. Empty when the job ends the chain. */
  next: Array<{ name: JobName; data?: JobPayload; singletonKey?: string }>;
  /** Counts for a job with no service of its own (the service's row carries them otherwise). */
  counts?: RunCounts;
  /**
   * The handler judged the run worse than its service did, so the already-closed service row
   * must be corrected. Without this the override would live only in memory, and
   * `/system-status` — which reads `system_logs` and nothing else — would report a clean run.
   */
  amended?: boolean;
}

export interface ScheduleEntry {
  name: JobName;
  cron: string;
  /** 'once' recovers an occurrence missed while the worker was down; 'skip' lets it go. */
  missed: 'skip' | 'once';
  data?: JobPayload;
}

/**
 * The only queue abstraction the rest of the codebase may depend on: Phase 9's sync endpoints
 * enqueue through this, so no route or service ever imports pg-boss.
 *
 * `enqueue` resolves to `null` when the send was deduplicated — a run of this job is already
 * queued, so there is nothing to add. That is the queue working as intended, not a failure.
 */
export interface JobQueue {
  start(): Promise<void>;
  stop(): Promise<void>;
  ensureQueues(names: readonly JobName[]): Promise<void>;
  enqueue(
    name: JobName,
    data?: JobPayload,
    options?: { singletonKey?: string },
  ): Promise<string | null>;
  /** Declarative: an entry absent from `entries` is unscheduled. */
  applySchedules(entries: readonly ScheduleEntry[]): Promise<void>;
  work(name: JobName, handler: (payload: JobPayload) => Promise<void>): Promise<void>;
}
