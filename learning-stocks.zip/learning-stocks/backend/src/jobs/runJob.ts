import type { Logger } from 'pino';
import type { RunCounts, SystemLogRepository } from '../repositories/SystemLogRepository.js';
import { toAppError } from '../utils/errors.js';
import type { Gate } from './gates.js';
import type { JobName, JobOutcome, JobPayload, JobQueue } from './types.js';

export interface JobDefinition {
  name: JobName;
  /** Checked before the handler. A refusal is a SKIPPED run, not a failure. */
  gate?: Gate;
  run(payload: JobPayload, at: Date): Promise<JobOutcome>;
}

export interface RunJobDeps {
  definition: JobDefinition;
  payload: JobPayload;
  queue: JobQueue;
  systemLogs: SystemLogRepository;
  logger: Logger;
  now?: () => Date;
}

const NO_COUNTS: RunCounts = { fetched: 0, inserted: 0, skipped: 0, failed: 0 };
const SERVICE = 'JobRunner';

/**
 * The single execution path for every job: gate, run, chain, log.
 *
 * Logging contract (PRD §13, one row per run): the services already write their own system_logs
 * row and handlers pass the queue name as their jobName, so that row IS this job's row. We write
 * one ourselves only when nobody else will — a gate skip, a service-less job, or a crash before
 * the service opened its run — otherwise /system-status would see two rows per run.
 */
export async function runJob(deps: RunJobDeps): Promise<JobOutcome> {
  const { definition, payload, queue, systemLogs, logger } = deps;
  const at = deps.now?.() ?? new Date();
  const log = logger.child({ job: definition.name });

  let outcome: JobOutcome;
  // The gate runs inside the try: gates are not pure. tradingDayGate and intradayWindowGate
  // query exchange_holidays, so a database outage makes them throw — and 10 of the 13 jobs have
  // a gate. Outside the try that error would escape with nothing written, which is the very
  // thing the FAILED-row path exists to prevent.
  try {
    if (definition.gate) {
      const gate = await definition.gate(at);
      // An operator pressing "Sync Market" on a Saturday should get a sync, not a SKIP they have
      // to interpret. Only a CALENDAR refusal yields: a disabled provider cannot be forced, and
      // the LLM budget is not a gate at all (the gateway throws), so neither is reachable here.
      const overridden = !gate.run && gate.kind === 'calendar' && payload.manual === true;
      if (!gate.run && !overridden) {
        await logOwnRun(systemLogs, definition.name, 'SKIPPED', gate.reason, NO_COUNTS);
        log.info({ reason: gate.reason, kind: gate.kind }, 'job skipped by gate');
        // A skipped job chains nothing: a holiday must not trigger an evaluation or an AI run.
        return { status: 'SKIPPED', runId: null, message: gate.reason, next: [] };
      }
    }
    outcome = await definition.run(payload, at);
  } catch (error) {
    const e = toAppError(error);
    // Nothing logged this: the gate or the handler died before a service opened its run.
    await logOwnRun(systemLogs, definition.name, 'FAILED', e.message, NO_COUNTS, e);
    log.error({ err: e }, 'job crashed');
    return { status: 'FAILED', runId: null, message: e.message, next: [] };
  }

  if (outcome.runId === null) {
    await logOwnRun(
      systemLogs,
      definition.name,
      outcome.status,
      outcome.message,
      outcome.counts ?? NO_COUNTS,
    );
  } else if (outcome.amended) {
    // The handler overrode the service's verdict (EOD found no settled bar, say). The service
    // already closed its row as SUCCESS, so without this the override exists only in memory —
    // and /system-status, which reads this table, would report a clean run.
    await systemLogs.amendRun(outcome.runId, { status: outcome.status, message: outcome.message });
  }

  // A FAILED run produced nothing worth propagating; PARTIAL did (some instruments succeeded).
  if (outcome.status !== 'FAILED' && outcome.status !== 'SKIPPED') {
    for (const next of outcome.next) {
      const id = await queue.enqueue(
        next.name,
        next.data ?? {},
        next.singletonKey === undefined ? {} : { singletonKey: next.singletonKey },
      );
      log.info({ next: next.name, deduplicated: id === null }, 'chained follow-up job');
    }
  }
  log.info({ status: outcome.status, runId: outcome.runId }, 'job finished');
  return outcome;
}

async function logOwnRun(
  systemLogs: SystemLogRepository,
  jobName: JobName,
  status: Exclude<JobOutcome['status'], 'STARTED'>,
  message: string,
  counts: RunCounts,
  error?: unknown,
): Promise<void> {
  const runId = await systemLogs.startRun({ service: SERVICE, jobName, operation: jobName });
  await systemLogs.finishRun(runId, {
    status,
    counts,
    message,
    ...(error === undefined ? {} : { error }),
  });
}
