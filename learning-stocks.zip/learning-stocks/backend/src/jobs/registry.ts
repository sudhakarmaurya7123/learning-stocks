import type { Container } from '../container.js';
import { AppError } from '../utils/errors.js';
import { dailySummaryJob, marketSummaryJob, signalsJob, stockAnalysisJob } from './handlers/ai.js';
import { evaluationJob, newsSentimentJob } from './handlers/analysis.js';
import { embeddingsJob, fundamentalsSyncJob, newsSyncJob } from './handlers/data.js';
import { expireSignalsJob, holidayCheckJob } from './handlers/maintenance.js';
import { eodSyncJob, intradaySyncJob } from './handlers/market.js';
import type { JobDefinition } from './runJob.js';
import { JOB_NAMES, type JobName } from './types.js';

/** Name → definition. A data table: no job logic lives here, and nothing here touches a database. */
export function createRegistry(c: Container): Record<JobName, JobDefinition> {
  const definitions = [
    intradaySyncJob(c),
    eodSyncJob(c),
    newsSyncJob(c),
    fundamentalsSyncJob(c),
    embeddingsJob(c),
    evaluationJob(c),
    newsSentimentJob(c),
    stockAnalysisJob(c),
    marketSummaryJob(c),
    dailySummaryJob(c),
    signalsJob(c),
    expireSignalsJob(c),
    holidayCheckJob(c),
  ];
  const registry = Object.fromEntries(definitions.map((d) => [d.name, d])) as Record<
    JobName,
    JobDefinition
  >;
  for (const name of JOB_NAMES) {
    // A job the worker schedules but cannot run would fail every tick, so fail at startup.
    if (!registry[name]) throw new AppError('INTERNAL', `No job definition for ${name}`);
  }
  return registry;
}
