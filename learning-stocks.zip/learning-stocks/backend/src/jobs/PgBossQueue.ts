// The ONLY file in this codebase that imports pg-boss. Everything else depends on JobQueue, so
// Phase 9's sync endpoints can enqueue without taking on the queue implementation.
// Note: pg-boss 12 exports a named class, not a default (verified against 12.37.0).
import { PgBoss } from 'pg-boss';
import type { Logger } from 'pino';
import { AppError } from '../utils/errors.js';
import type { JobName, JobPayload, JobQueue, ScheduleEntry } from './types.js';

export interface PgBossQueueOptions {
  connectionString: string;
  schema: string;
  logger: Logger;
  /** Timezone every cron expression is evaluated in (PRD §13: Asia/Kolkata). */
  tz: string;
  /**
   * Run the cron timekeeper. The API passes false: the worker is the single instance that fires
   * schedules (PRD §18), and a second timekeeper would double-send every job.
   */
  schedule?: boolean;
  /** Run maintenance (archival, expiry). The worker owns it; the API passes false. */
  supervise?: boolean;
}

/** A worker is considered live if it heartbeat within this window. */
const WORKER_HEARTBEAT_WINDOW_SECONDS = 120;

export interface WorkerLiveness {
  status: 'live' | 'down' | 'unknown';
  live: number;
  last_heartbeat: string | null;
}

/**
 * Every queue is `stately`: one job active plus one queued, further sends deduplicated.
 *
 * `exclusive` would drop a follow-up enqueued while a run is in flight — and that queued run is
 * the one with fresh data. Measured against 12.37.0 with one job held active: `exclusive` drops
 * the 1st queued job, `stately` keeps the 1st and drops the 2nd.
 */
const QUEUE_DEFAULTS = {
  policy: 'stately',
  // Services already retry provider calls and report FAILED/PARTIAL instead of throwing, and
  // runJob catches whatever still escapes. So this is reached only when *logging* the failure
  // also fails — the database is unreachable — which is exactly when a retry is right.
  retryLimit: 1,
  retryDelay: 30,
  retryBackoff: true,
  // A full EOD sync over 32 instruments plus its chain can take minutes.
  expireInSeconds: 20 * 60,
} as const;

export class PgBossQueue implements JobQueue {
  private boss: PgBoss | null = null;
  /**
   * The in-flight start, so concurrent callers await one instance.
   *
   * Guarding on `this.boss` alone is not enough: it is assigned only after `await boss.start()`,
   * so two concurrent first callers each constructed and started a PgBoss and one was overwritten
   * and orphaned — holding a connection pool nothing could ever close.
   */
  private starting: Promise<void> | null = null;

  constructor(private readonly options: PgBossQueueOptions) {}

  private get instance(): PgBoss {
    if (!this.boss) throw new AppError('INTERNAL', 'Job queue used before start()');
    return this.boss;
  }

  async start(): Promise<void> {
    if (this.boss) return;
    this.starting ??= this.open();
    try {
      await this.starting;
    } finally {
      // Cleared either way: a failed start must be retryable, not permanently poisoned.
      this.starting = null;
    }
  }

  private async open(): Promise<void> {
    const boss = new PgBoss({
      connectionString: this.options.connectionString,
      schema: this.options.schema,
      // `supabase db reset` drops the schema, so installation is unconditional and idempotent.
      migrate: true,
      createSchema: true,
      ...(this.options.schedule === undefined ? {} : { schedule: this.options.schedule }),
      ...(this.options.supervise === undefined ? {} : { supervise: this.options.supervise }),
    });
    // pg-boss reports background failures (maintenance, cron) through events, never by throwing.
    boss.on('error', (error) => this.options.logger.error({ err: error }, 'job queue error'));
    boss.on('warning', (warning) => this.options.logger.warn({ warning }, 'job queue warning'));
    await boss.start();
    this.boss = boss;
    this.options.logger.info(
      { schema: this.options.schema, version: await boss.schemaVersion() },
      'job queue started',
    );
  }

  async stop(): Promise<void> {
    // Wait for an in-flight start, or a shutdown racing it would leave the new instance running.
    if (this.starting) await this.starting.catch(() => undefined);
    if (!this.boss) return;
    // graceful: let in-flight handlers finish rather than orphaning an active job, which the
    // monitor would later retry. (pg-boss 12 renamed v10's `wait` to `graceful`.)
    await this.boss.stop({ graceful: true, close: true });
    this.boss = null;
  }

  /** Idempotent: a worker restart calls this unconditionally (verified against 12.37.0). */
  async ensureQueues(names: readonly JobName[]): Promise<void> {
    for (const name of names) await this.instance.createQueue(name, { ...QUEUE_DEFAULTS });
  }

  async enqueue(
    name: JobName,
    data: JobPayload = {},
    options: { singletonKey?: string } = {},
  ): Promise<string | null> {
    // Connect on first use: the API constructs this queue eagerly in the container but most
    // requests never touch it, and an unused pool would be a connection per server for nothing.
    await this.start();
    await this.ensureQueues([name]);
    return this.instance.send(name, data, {
      ...(options.singletonKey === undefined ? {} : { singletonKey: options.singletonKey }),
    });
  }

  /** Declarative: entries not in the table are unscheduled, so removing a row removes the cron. */
  async applySchedules(entries: readonly ScheduleEntry[]): Promise<void> {
    const boss = this.instance;
    const wanted = new Set(entries.map((e) => e.name as string));
    for (const existing of await boss.getSchedules()) {
      if (!wanted.has(existing.name)) await boss.unschedule(existing.name);
    }
    for (const entry of entries) {
      // schedule() upserts on (name, key) with key defaulting to '': the same call with a new
      // cron replaces it in place. Two entries for one name would silently collapse to the last,
      // which is why DEFAULT_SCHEDULES holds exactly one entry per job.
      await boss.schedule(entry.name, entry.cron, entry.data ?? {}, {
        tz: this.options.tz,
        missed: entry.missed,
      });
    }
  }

  /** The underlying connection, for the liveness query. */
  db(): ReturnType<PgBoss['getDb']> {
    return this.instance.getDb();
  }

  async work(name: JobName, handler: (payload: JobPayload) => Promise<void>): Promise<void> {
    await this.instance.work<JobPayload>(name, { batchSize: 1 }, async (jobs) => {
      for (const job of jobs) await handler(job.data ?? {});
    });
  }
}

/**
 * Is a worker running? (Review Focus 5: a 202 must not promise work nobody will do.)
 *
 * Counting rows in `instance` would be wrong twice over: an API-style instance registers itself
 * there with a live heartbeat (measured), and a crashed worker leaves its row behind. So the query
 * asks for an instance that runs the timekeeper, has not shut down cleanly, and is still beating.
 *
 * Deliberately a class method rather than part of JobQueue: adding it to the interface would
 * break Phase 8's fakes (fakeQueue, recordingQueue, and the dry queue in cli/job.ts).
 */
export async function workerLiveness(queue: PgBossQueue, schema: string): Promise<WorkerLiveness> {
  try {
    // The API's queue connects lazily, so a status call before any enqueue would otherwise hit
    // "used before start()" and report 'unknown' while a worker was plainly running.
    await queue.start();
    const { rows } = await queue.db().executeSql(
      `select count(*)::int as live, max(heartbeat_on) as last_heartbeat
         from ${schema}.instance
        where schedule = true
          and stopped_on is null
          and heartbeat_on > now() - interval '${WORKER_HEARTBEAT_WINDOW_SECONDS} seconds'`,
    );
    const row = rows[0] as { live?: number; last_heartbeat?: Date | null } | undefined;
    const live = row?.live ?? 0;
    const beat = row?.last_heartbeat ?? null;
    return {
      status: live > 0 ? 'live' : 'down',
      live,
      last_heartbeat: beat instanceof Date ? beat.toISOString() : null,
    };
  } catch {
    // Worker liveness is a nicety on a status page; it must never take /system-status down.
    return { status: 'unknown', live: 0, last_heartbeat: null };
  }
}
