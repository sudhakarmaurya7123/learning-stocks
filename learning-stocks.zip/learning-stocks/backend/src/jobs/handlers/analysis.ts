import type { Container } from '../../container.js';
import { DEFAULT_MAX_ARTICLES } from '../../services/ai/SentimentService.js';
import { AppError } from '../../utils/errors.js';
import { enabledGate } from '../gates.js';
import type { JobDefinition } from '../runJob.js';
import type { JobOutcome } from '../types.js';

export function evaluationJob(c: Container): JobDefinition {
  return {
    name: 'evaluation.compute',
    // No gate: recomputing from whatever bars exist is always safe and always cheap. It is also
    // reached by chain from three parents, and the parent already gated.
    async run(payload): Promise<JobOutcome> {
      const r = await c.services.evaluation.run({
        jobName: 'evaluation.compute',
        ...(payload.symbols ? { symbols: payload.symbols } : {}),
      });
      // PRD §13: the AI analysis chain hangs off the EOD run. During the session it has its own
      // 30-minute schedule, so chaining it from every intraday tick would bypass that interval
      // and spend the budget 12x faster for no new information.
      const next: JobOutcome['next'] =
        payload.origin === 'eod' ? [{ name: 'ai.stock.analyze', data: { origin: 'eod' } }] : [];
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.evaluations.inserted} new, ${r.evaluations.unchanged} unchanged; ${r.indicatorRows} indicator rows`,
        next,
      };
    },
  };
}

export function newsSentimentJob(c: Container): JobDefinition {
  return {
    name: 'news.sentiment',
    gate: enabledGate('AI services', c.services.ai),
    async run(): Promise<JobOutcome> {
      const ai = c.services.ai;
      if (!ai) throw new AppError('INTERNAL', 'news.sentiment ran without AI services');
      const r = await ai.sentiment.run({
        jobName: 'news.sentiment',
        maxArticles: DEFAULT_MAX_ARTICLES,
      });
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.analysed} of ${r.pending} pending (article, subject) pairs analysed${
          r.budgetExhausted ? '; daily LLM budget reached' : ''
        }`,
        next: [],
      };
    },
  };
}
