import type { Container } from '../../container.js';
import { AppError } from '../../utils/errors.js';
import { toIst } from '../../utils/ist.js';
import { allGates, enabledGate, type Gate, tradingDayGate } from '../gates.js';
import type { JobDefinition } from '../runJob.js';
import type { JobOutcome } from '../types.js';

/**
 * Every AI job needs the LLM configured *and* a trading day.
 *
 * PRD §13 schedules these "every 30 min in session". Without the trading-day gate a weekday
 * holiday would run 12 analyses and 12 market summaries against nothing new — and because
 * news.sync keeps running, the retrieved context keeps changing, so the input hash keeps changing
 * and the service's own cache would not stop it. In LIVE mode that is real money on a closed
 * market. It is tradingDayGate rather than a session gate because ai.stock.analyze is also
 * chained after the close from EOD.
 */
const aiGate = (c: Container) =>
  allGates(enabledGate('AI services', c.services.ai), tradingDayGate(c.services.calendar, 'NSE'));

export function stockAnalysisJob(c: Container): JobDefinition {
  return {
    name: 'ai.stock.analyze',
    gate: aiGate(c),
    async run(payload): Promise<JobOutcome> {
      const ai = c.services.ai;
      if (!ai) throw new AppError('INTERNAL', 'ai.stock.analyze ran without AI services');
      const r = await ai.analysis.run({
        jobName: 'ai.stock.analyze',
        ...(payload.symbols ? { symbols: payload.symbols } : {}),
        ...(payload.force === undefined ? {} : { force: payload.force }),
      });
      const count = (outcome: string) => r.results.filter((x) => x.outcome === outcome).length;
      const overBudget = count('BUDGET_EXHAUSTED');
      return {
        status: r.status,
        runId: r.runId,
        // A budget ceiling is a state, not a failed run: /system-status reads it from
        // LlmBudget.status(), so this only reports what happened.
        message: `${count('ANALYSED')} analysed, ${count('CACHED')} cached, ${count('MIN_INTERVAL')} within min interval${
          overBudget > 0 ? `, ${overBudget} over budget` : ''
        }`,
        // Still chained when today's analyses were capped: evaluations from earlier analyses can
        // be signal-worthy.
        next: [{ name: 'signals.generate' }],
      };
    },
  };
}

export function marketSummaryJob(c: Container): JobDefinition {
  return {
    name: 'ai.market.summary',
    gate: aiGate(c),
    async run(payload): Promise<JobOutcome> {
      const ai = c.services.ai;
      if (!ai) throw new AppError('INTERNAL', 'ai.market.summary ran without AI services');
      const r = await ai.marketSummary.run({
        jobName: 'ai.market.summary',
        force: payload.force ?? false,
      });
      return { status: r.status, runId: r.runId, message: r.outcome, next: [] };
    },
  };
}

/**
 * The close this run is for has just happened.
 *
 * `missed: 'once'` carries no occurrence identity — a recovered job gets the schedule's data and
 * nothing else — so a 16:15 summary missed during an overnight outage arrives the next morning
 * with `at` = now. Since this is the one LLM path that deliberately forces past the hash cache,
 * running it then would spend real money stamping a mid-morning summary as a day's close. The
 * window has to cover a late catch-up on the same evening without reaching the next session.
 */
const AFTER_CLOSE_WINDOW_MS = 3 * 60 * 60_000;

function afterTodaysCloseGate(c: Container): Gate {
  return async (at) => {
    const session = await c.services.calendar.sessionOn('NSE', toIst(at).date);
    if (!session)
      return {
        run: false,
        kind: 'calendar',
        reason: `NSE is closed all day on ${toIst(at).date} (IST)`,
      };
    const sinceClose = at.getTime() - session.close.getTime();
    if (sinceClose < 0)
      // 'availability', not 'calendar': this gate exists to stop a FORCED end-of-day summary
      // being generated at the wrong time, so a manual click must not bypass it.
      return {
        run: false,
        kind: 'availability',
        reason: `the ${toIst(at).date} session has not closed yet`,
      };
    if (sinceClose > AFTER_CLOSE_WINDOW_MS) {
      return {
        run: false,
        kind: 'availability',
        reason: `more than ${AFTER_CLOSE_WINDOW_MS / 3_600_000}h past the ${toIst(at).date} close: not forcing a stale end-of-day summary`,
      };
    }
    return { run: true };
  };
}

export function dailySummaryJob(c: Container): JobDefinition {
  return {
    name: 'ai.daily.summary',
    // afterTodaysCloseGate subsumes the trading-day check, so aiGate's is not repeated.
    gate: allGates(enabledGate('AI services', c.services.ai), afterTodaysCloseGate(c)),
    async run(): Promise<JobOutcome> {
      const ai = c.services.ai;
      if (!ai) throw new AppError('INTERNAL', 'ai.daily.summary ran without AI services');
      // force: the day must close with a summary stamped after the close, even when the hash
      // matches the last in-session run. PRD §13 lists this job but never defines a separate
      // artifact, so it is the end-of-day market summary (see the plan's Deviation 2).
      const r = await ai.marketSummary.run({ jobName: 'ai.daily.summary', force: true });
      return {
        status: r.status,
        runId: r.runId,
        message: `end-of-day market summary: ${r.outcome}`,
        next: [],
      };
    },
  };
}

export function signalsJob(c: Container): JobDefinition {
  return {
    name: 'signals.generate',
    gate: enabledGate('AI services', c.services.ai),
    async run(payload): Promise<JobOutcome> {
      const ai = c.services.ai;
      if (!ai) throw new AppError('INTERNAL', 'signals.generate ran without AI services');
      const r = await ai.signals.run({
        jobName: 'signals.generate',
        ...(payload.symbols ? { symbols: payload.symbols } : {}),
      });
      return {
        status: r.status,
        runId: r.runId,
        // Signals are suggestions: nothing here places an order, whatever auto_paper_trade says.
        message: `${r.created} created, ${r.invalidated} invalidated, ${r.expired} expired`,
        next: [],
      };
    },
  };
}
