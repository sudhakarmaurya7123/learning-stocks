import type { Container } from '../../container.js';
import type { Exchange } from '../../domain/enums.js';
import type { TradingSession, TradingSessions } from '../../domain/types.js';
import { DEFAULT_DAILY_SETTLE_MS } from '../../services/marketData/barNormalizer.js';
import { addDays, toIst } from '../../utils/ist.js';
import { intradayWindowGate, tradingDayGate } from '../gates.js';
import type { JobDefinition } from '../runJob.js';
import type { JobOutcome } from '../types.js';

const FIVE_MIN_MS = 5 * 60_000;
/** Trailing window per intraday run: covers a missed tick, and re-inserting a stored bar is a no-op. */
const INTRADAY_WINDOW_MS = 30 * 60_000;
/** EOD looks back far enough to backfill days the worker was down, and special sessions. */
const EOD_LOOKBACK_DAYS = 10;
/** How far back to search for a settled session before giving up (long weekends, holiday runs). */
const SETTLED_SEARCH_DAYS = 10;

/**
 * The most recent session whose close has fully settled, or null when there is none in range.
 *
 * Asking "does today have a bar?" instead would raise a false PARTIAL every time a missed:'once'
 * catch-up fires on a morning that has not traded yet — a Monday after a weekend down.
 */
export async function lastSettledSession(
  sessions: TradingSessions,
  exchange: Exchange,
  at: Date,
  settleMs: number = DEFAULT_DAILY_SETTLE_MS,
): Promise<{ date: string; session: TradingSession } | null> {
  let date = toIst(at).date;
  for (let i = 0; i <= SETTLED_SEARCH_DAYS; i += 1) {
    const session = await sessions.sessionOn(exchange, date);
    if (session && session.close.getTime() + settleMs <= at.getTime()) return { date, session };
    date = addDays(date, -1);
  }
  return null;
}

export function intradaySyncJob(c: Container): JobDefinition {
  return {
    name: 'market.sync.intraday',
    gate: intradayWindowGate(c.services.calendar, 'NSE', FIVE_MIN_MS),
    async run(_payload, at): Promise<JobOutcome> {
      const r = await c.services.marketData.sync({
        jobName: 'market.sync.intraday',
        timeframe: '5m',
        from: new Date(at.getTime() - INTRADAY_WINDOW_MS),
        to: at,
        includeIndices: true,
      });
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.bars.inserted} bars inserted, ${r.bars.duplicates} already stored`,
        next: [
          { name: 'evaluation.compute', data: { origin: 'intraday' }, singletonKey: 'intraday' },
        ],
      };
    },
  };
}

export function eodSyncJob(c: Container): JobDefinition {
  return {
    name: 'market.sync.eod',
    gate: tradingDayGate(c.services.calendar, 'NSE'),
    async run(_payload, at): Promise<JobOutcome> {
      const r = await c.services.marketData.sync({
        jobName: 'market.sync.eod',
        timeframe: '1d',
        // A multi-day window backfills days the worker was down and special sessions, which the
        // Mon-Fri cron never fires on (Muhurat trading is a Sunday).
        from: new Date(at.getTime() - EOD_LOOKBACK_DAYS * 86_400_000),
        to: at,
        includeIndices: true,
      });
      // Guard against the settle race: a daily bar is final only at close + 30 min, so a run on
      // that boundary can silently drop today's bar while still reporting SUCCESS — and the chain
      // would then evaluate yesterday's close with the AI explaining it as today's.
      const settled = await lastSettledSession(c.services.calendar, 'NSE', at);
      if (
        settled &&
        !(await c.repositories.marketData.hasDailyBarOn(settled.date, c.config.dataMode))
      ) {
        return {
          // amended: the service closed its own row as SUCCESS for its own work. This verdict is
          // about whether the result is usable, and it has to reach system_logs.
          status: 'PARTIAL',
          amended: true,
          runId: r.runId,
          message: `no settled daily bar stored for ${settled.date} (IST) after the EOD sync; not chaining the evaluation — tomorrow's ${EOD_LOOKBACK_DAYS}-day backfill will pick it up`,
          // Chain nothing: a stale evaluation and a stale AI analysis are worse than none.
          next: [],
        };
      }
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.bars.inserted} daily bars inserted for ${r.instruments.succeeded}/${r.instruments.total} instruments`,
        next: [{ name: 'evaluation.compute', data: { origin: 'eod' }, singletonKey: 'eod' }],
      };
    },
  };
}
