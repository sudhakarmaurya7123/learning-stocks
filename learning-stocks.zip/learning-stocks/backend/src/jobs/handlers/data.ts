import type { Container } from '../../container.js';
import { DEFAULT_MAX_DOCUMENTS } from '../../services/rag/EmbeddingService.js';
import { AppError } from '../../utils/errors.js';
import { enabledGate } from '../gates.js';
import type { JobDefinition } from '../runJob.js';
import type { JobOutcome } from '../types.js';

const DAY_MS = 86_400_000;
const NEWS_PER_QUERY_LIMIT = 50;

export function newsSyncJob(c: Container): JobDefinition {
  return {
    name: 'news.sync',
    gate: enabledGate('news provider', c.services.news),
    async run(payload, at): Promise<JobOutcome> {
      const service = c.services.news;
      if (!service) throw new AppError('INTERNAL', 'news.sync ran without a news service');
      const r = await service.sync({
        jobName: 'news.sync',
        // A day's overlap: duplicate articles are dropped by content hash, so re-reading is free
        // and a missed run heals itself.
        since: new Date(at.getTime() - DAY_MS),
        ...(payload.symbols ? { symbols: payload.symbols } : {}),
        includeMarket: true,
        perQueryLimit: NEWS_PER_QUERY_LIMIT,
      });
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.articles.new} new of ${r.articles.fetched} fetched; ${r.mentions} mentions`,
        next: [{ name: 'embeddings.generate' }],
      };
    },
  };
}

export function fundamentalsSyncJob(c: Container): JobDefinition {
  return {
    name: 'fundamentals.sync',
    gate: enabledGate('fundamentals provider', c.services.fundamentals),
    async run(payload): Promise<JobOutcome> {
      const service = c.services.fundamentals;
      if (!service)
        throw new AppError('INTERNAL', 'fundamentals.sync ran without a fundamentals service');
      const r = await service.sync({
        jobName: 'fundamentals.sync',
        ...(payload.symbols ? { symbols: payload.symbols } : {}),
        includeStatements: true,
      });
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.snapshots.inserted} new and ${r.snapshots.updated} refreshed snapshots for ${r.stocks.succeeded}/${r.stocks.total} stocks`,
        next: [
          {
            name: 'evaluation.compute',
            data: { origin: 'fundamentals' },
            // Its own key, so this never collapses into the EOD continuation — only that one
            // chains the AI analysis.
            singletonKey: 'fundamentals',
          },
        ],
      };
    },
  };
}

export function embeddingsJob(c: Container): JobDefinition {
  return {
    name: 'embeddings.generate',
    gate: enabledGate('embeddings (LLM provider)', c.services.embeddings),
    async run(): Promise<JobOutcome> {
      const service = c.services.embeddings;
      if (!service)
        throw new AppError('INTERNAL', 'embeddings.generate ran without an embedding service');
      const r = await service.run({
        jobName: 'embeddings.generate',
        sources: ['NEWS', 'FINANCIALS'],
        maxDocuments: DEFAULT_MAX_DOCUMENTS,
      });
      return {
        status: r.status,
        runId: r.runId,
        message: `${r.documents.written}/${r.documents.planned} documents, ${r.chunks.embedded} chunks embedded, ₹${r.estCostInr.toFixed(4)}`,
        next: [{ name: 'news.sentiment' }],
      };
    },
  };
}
