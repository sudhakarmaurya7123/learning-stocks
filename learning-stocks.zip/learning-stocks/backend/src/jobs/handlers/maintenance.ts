import type { Container } from '../../container.js';
import type { Exchange } from '../../domain/enums.js';
import { toIst } from '../../utils/ist.js';
import type { JobDefinition } from '../runJob.js';
import type { JobOutcome } from '../types.js';

const NO_COUNTS = { fetched: 0, inserted: 0, skipped: 0, failed: 0 } as const;
const EXCHANGES: readonly Exchange[] = ['NSE', 'BSE'];

export function expireSignalsJob(c: Container): JobDefinition {
  return {
    name: 'signals.expire',
    // No gate: expiring a stale signal is correct on a holiday too.
    async run(_payload, at): Promise<JobOutcome> {
      const expired = await c.repositories.tradeSignals.expire(c.config.dataMode, at);
      return {
        status: 'SUCCESS',
        runId: null,
        next: [],
        message: `${expired} signal(s) expired`,
        counts: { ...NO_COUNTS },
      };
    },
  };
}

export function holidayCheckJob(c: Container): JobDefinition {
  return {
    name: 'holidays.check',
    async run(_payload, at): Promise<JobOutcome> {
      // The IST year, not the UTC one: on 2026-12-31T19:00Z it is already 2027 in Mumbai, and a
      // check that asked about 2026 then would report success on the day the calendar ran out.
      const year = toIst(at).date.slice(0, 4);
      const next = String(Number(year) + 1);
      const missing: string[] = [];
      for (const exchange of EXCHANGES) {
        // Warn about next year from the start of this one: a calendar discovered missing in
        // January is fixable, one discovered on January 1st is already wrong.
        for (const check of [year, next]) {
          if (!(await c.services.calendar.hasCalendar(exchange, check)))
            missing.push(`${exchange} ${check}`);
        }
      }
      return {
        status: missing.length === 0 ? 'SUCCESS' : 'PARTIAL',
        runId: null,
        next: [],
        message:
          missing.length === 0
            ? `holiday calendars present for ${year} and ${next}`
            : `missing holiday calendar(s): ${missing.join(', ')} — load them before the year turns`,
        counts: { ...NO_COUNTS, failed: missing.length },
      };
    },
  };
}
