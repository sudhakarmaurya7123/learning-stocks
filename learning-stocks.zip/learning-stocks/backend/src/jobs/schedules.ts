import { z } from 'zod';
import type { AppSettingsRepository } from '../repositories/AppSettingsRepository.js';
import { AppError } from '../utils/errors.js';
import { JOB_NAMES, type JobName, type ScheduleEntry } from './types.js';

/**
 * PRD §13, evaluated in Asia/Kolkata.
 *
 * Exactly one entry per job: pg-boss keys schedules on (name, key) and `key` defaults to '', so a
 * second entry for the same name would silently replace the first (measured against 12.37.0).
 *
 * The intraday expression covers 09:00-15:30 every 5 minutes. The 09:00/09:10 ticks and
 * 15:35-15:55 fall outside the session and the intraday gate skips them, which is where that
 * judgment belongs: the gate knows about holidays and special sessions, a cron string does not.
 *
 * Chained jobs (evaluation.compute, embeddings.generate, news.sentiment, signals.generate) are
 * deliberately absent: they run when their input changes, not on a clock.
 */
export const DEFAULT_SCHEDULES: readonly ScheduleEntry[] = [
  { name: 'market.sync.intraday', cron: '*/5 9-15 * * 1-5', missed: 'skip' },
  // 16:05, not 16:00: a daily bar is final at close + 30 min settle = 16:00 exactly, so a 16:00
  // run races the settle window and can silently drop today's bar (see Deviation 3).
  { name: 'market.sync.eod', cron: '5 16 * * 1-5', missed: 'once' },
  { name: 'fundamentals.sync', cron: '0 18 * * *', missed: 'once' },
  { name: 'news.sync', cron: '*/10 * * * *', missed: 'skip' },
  { name: 'ai.stock.analyze', cron: '*/30 10-15 * * 1-5', missed: 'skip' },
  { name: 'ai.market.summary', cron: '*/30 10-15 * * 1-5', missed: 'skip' },
  { name: 'ai.daily.summary', cron: '15 16 * * 1-5', missed: 'once' },
  { name: 'signals.expire', cron: '*/15 * * * *', missed: 'skip' },
  { name: 'holidays.check', cron: '0 9 * * 1', missed: 'once' },
];

const names = DEFAULT_SCHEDULES.map((s) => s.name);
if (new Set(names).size !== names.length) {
  throw new AppError(
    'INTERNAL',
    'DEFAULT_SCHEDULES has two entries for one job: pg-boss keys schedules on (name, key) and would keep only the last',
  );
}

/**
 * A cron string per job name, replacing that job's default. `null` disables the job entirely.
 * Example value: `{"news.sync": "0,20,40 * * * *", "ai.market.summary": null}`.
 */
const OVERRIDES = z.record(z.string(), z.string().min(1).nullable());

export interface ScheduleSettings {
  get<T>(key: string, schema: z.ZodType<T>): Promise<T | null>;
}

/** PRD §13: "intervals are configurable in app_settings". Code holds the defaults. */
export async function loadSchedules(
  settings: ScheduleSettings | AppSettingsRepository,
): Promise<readonly ScheduleEntry[]> {
  const overrides = await settings.get('job_schedules', OVERRIDES);
  if (!overrides) return DEFAULT_SCHEDULES;
  for (const key of Object.keys(overrides)) {
    if (!(JOB_NAMES as readonly string[]).includes(key)) {
      throw new AppError('INTERNAL', `app_settings.job_schedules names an unknown job: ${key}`, {
        details: { job: key },
      });
    }
  }
  // One entry per job, so an override is a straight substitution and null removes the job.
  return DEFAULT_SCHEDULES.flatMap((entry) => {
    if (!(entry.name in overrides)) return [entry];
    const cron = overrides[entry.name as JobName];
    return cron === null || cron === undefined ? [] : [{ ...entry, cron }];
  });
}
