import type { Exchange } from '../domain/enums.js';
import type { TradingSessions } from '../domain/types.js';
import { toIst } from '../utils/ist.js';
import type { GateResult } from './types.js';

export type Gate = (at: Date) => Promise<GateResult>;

const RUN: GateResult = { run: true };

/** The exchange is open for business on the IST date of `at` (weekday, not a full holiday). */
export function tradingDayGate(sessions: TradingSessions, exchange: Exchange): Gate {
  return async (at) => {
    const { date } = toIst(at);
    const session = await sessions.sessionOn(exchange, date);
    return session
      ? RUN
      : { run: false, kind: 'calendar', reason: `${exchange} is closed all day on ${date} (IST)` };
  };
}

/**
 * The interval ending at `at` overlapped a trading session.
 *
 * Gating on isOpen(at) would lose the end of every session: the session is [09:15, 15:30), so
 * isOpen() is already false at 15:30 — and the 15:30 tick is the only one that can collect the
 * 15:25 bar, which is still incomplete at 15:25. Overlap of [at - interval, at) is the honest
 * question: "did the period this run covers contain any trading?"
 */
export function intradayWindowGate(
  sessions: TradingSessions,
  exchange: Exchange,
  intervalMs: number,
): Gate {
  return async (at) => {
    const from = new Date(at.getTime() - intervalMs);
    // The window can straddle midnight IST, so check both dates.
    for (const date of new Set([toIst(from).date, toIst(at).date])) {
      const session = await sessions.sessionOn(exchange, date);
      if (session && from < session.close && at > session.open) return RUN;
    }
    return {
      run: false,
      kind: 'calendar',
      reason: `no ${exchange} session in the ${Math.round(intervalMs / 60_000)} min before ${at.toISOString()}`,
    };
  };
}

/** A configured-away dependency (NEWS_PROVIDER=none, LLM_PROVIDER=none) is a skip, not a failure. */
export function enabledGate(label: string, value: unknown): Gate {
  return async () =>
    value ? RUN : { run: false, kind: 'availability', reason: `${label} is disabled` };
}

export function allGates(...gates: readonly Gate[]): Gate {
  return async (at) => {
    for (const gate of gates) {
      const result = await gate(at);
      if (!result.run) return result;
    }
    return RUN;
  };
}
