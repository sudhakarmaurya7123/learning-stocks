import { z } from 'zod';
import { AppError } from '../utils/errors.js';

export const FACTOR_NAMES = [
  'technical',
  'quality',
  'valuation',
  'news',
  'momentum',
  'market_context',
] as const;
export type FactorName = (typeof FACTOR_NAMES)[number];
export type FactorWeights = Record<FactorName, number>;

const weight = z.number().nonnegative();
const WeightsSchema = z.object({
  technical: weight,
  quality: weight,
  valuation: weight,
  news: weight,
  momentum: weight,
  market_context: weight,
});

/** scoring_configs.thresholds. Keys added after v1 have defaults so older configs stay valid. */
const ThresholdsSchema = z.object({
  buy_overall_min: z.number(),
  strong_buy_overall_min: z.number(),
  avoid_overall_max: z.number(),
  strong_sell_overall_max: z.number(),
  extended_above_sma50_pct: z.number(),
  rsi_overbought: z.number(),
  min_risk_reward: z.number(),
  stop_atr_multiple: z.number().positive(),
  entry_atr_width: z.number().nonnegative(),
  risk_per_trade_pct: z.number().positive(),
  min_daily_bars: z.number().int().positive(),
  valuation_low_pctile: z.number(),
  valuation_high_pctile: z.number(),
  min_sector_peers: z.number().int().positive(),
  news_half_life_days: z.number().positive(),
  vix_risk_on_max: z.number().default(20),
  vix_risk_off_min: z.number().default(25),
  weak_quality_max: z.number().default(40),
  max_stale_sessions: z.number().int().nonnegative().default(3),
});

export interface ScoringThresholds {
  buyOverallMin: number;
  strongBuyOverallMin: number;
  avoidOverallMax: number;
  strongSellOverallMax: number;
  extendedAboveSma50Pct: number;
  rsiOverbought: number;
  minRiskReward: number;
  stopAtrMultiple: number;
  entryAtrWidth: number;
  riskPerTradePct: number;
  minDailyBars: number;
  valuationLowPctile: number;
  valuationHighPctile: number;
  minSectorPeers: number;
  newsHalfLifeDays: number;
  vixRiskOnMax: number;
  vixRiskOffMin: number;
  weakQualityMax: number;
  maxStaleSessions: number;
}

export interface ScoringConfig {
  version: string;
  weights: FactorWeights;
  thresholds: ScoringThresholds;
}

export function parseScoringConfig(row: {
  version: string;
  weights: unknown;
  thresholds: unknown;
}): ScoringConfig {
  const weights = WeightsSchema.safeParse(row.weights);
  const thresholds = ThresholdsSchema.safeParse(row.thresholds);
  if (!weights.success || !thresholds.success) {
    const error = weights.success ? thresholds.error : weights.error;
    throw new AppError(
      'INTERNAL',
      `scoring_configs ${row.version} is invalid:\n${z.prettifyError(error ?? new z.ZodError([]))}`,
      {
        details: { version: row.version },
      },
    );
  }
  const t = thresholds.data;
  return {
    version: row.version,
    weights: weights.data,
    thresholds: {
      buyOverallMin: t.buy_overall_min,
      strongBuyOverallMin: t.strong_buy_overall_min,
      avoidOverallMax: t.avoid_overall_max,
      strongSellOverallMax: t.strong_sell_overall_max,
      extendedAboveSma50Pct: t.extended_above_sma50_pct,
      rsiOverbought: t.rsi_overbought,
      minRiskReward: t.min_risk_reward,
      stopAtrMultiple: t.stop_atr_multiple,
      entryAtrWidth: t.entry_atr_width,
      riskPerTradePct: t.risk_per_trade_pct,
      minDailyBars: t.min_daily_bars,
      valuationLowPctile: t.valuation_low_pctile,
      valuationHighPctile: t.valuation_high_pctile,
      minSectorPeers: t.min_sector_peers,
      newsHalfLifeDays: t.news_half_life_days,
      vixRiskOnMax: t.vix_risk_on_max,
      vixRiskOffMin: t.vix_risk_off_min,
      weakQualityMax: t.weak_quality_max,
      maxStaleSessions: t.max_stale_sessions,
    },
  };
}
