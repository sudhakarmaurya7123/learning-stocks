import type { MarketRegime, RiskLevel, Trend } from '../domain/enums.js';
import { FACTOR_NAMES, type FactorName, type FactorWeights } from './config.js';
import { clampScore, interpolate, round, weightedMean } from '../technical/stats.js';
import { MARKET_CONTEXT, MOMENTUM, QUALITY, RISK, TECHNICAL, VALUATION } from './rubrics.js';

export interface FactorResult {
  score: number | null;
  /** Each component's 0–100 score (null = unavailable), for explainability. */
  components: Record<string, number | null>;
}

const DAY_MS = 86_400_000;
const pt = (x: number | null, points: Parameters<typeof interpolate>[1]): number | null =>
  x === null ? null : interpolate(x, points);
const finish = (
  components: Record<string, number | null>,
  weights: Record<string, number>,
): FactorResult => {
  const mean = weightedMean(
    Object.entries(weights).map(([k, w]) => [components[k] ?? null, w] as const),
  );
  const rounded = Object.fromEntries(
    Object.entries(components).map(([k, v]) => [k, v === null ? null : round(v, 2)]),
  );
  return { score: mean === null ? null : clampScore(mean), components: rounded };
};
const trendScore = (t: Trend | null) => (t === null ? null : TECHNICAL.trend[t]);

export interface TechnicalInputs {
  close: number | null;
  prevClose: number | null;
  volume: number | null;
  volumeSma20: number | null;
  trend: Trend | null;
  rsi14: number | null;
  macd: number | null;
  macdSignal: number | null;
  adx14: number | null;
}

export function technicalScore(i: TechnicalInputs): FactorResult {
  const macd =
    i.macd === null || i.macdSignal === null
      ? null
      : i.macd > i.macdSignal
        ? i.macd >= 0
          ? 100
          : 65
        : i.macd <= 0
          ? 0
          : 35;
  const direction = i.trend === 'UPTREND' ? 1 : i.trend === 'DOWNTREND' ? -1 : 0;
  const adx =
    i.adx14 === null || i.trend === null
      ? null
      : 50 + 50 * direction * interpolate(i.adx14, TECHNICAL.adxStrength);
  let volume: number | null = null;
  if (
    i.volume !== null &&
    i.volumeSma20 !== null &&
    i.volumeSma20 > 0 &&
    i.close !== null &&
    i.prevClose !== null
  ) {
    const ratio = i.volume / i.volumeSma20;
    volume = interpolate(ratio, i.close > i.prevClose ? TECHNICAL.volumeUp : TECHNICAL.volumeDown);
  }
  return finish(
    { trend: trendScore(i.trend), macd, rsi: pt(i.rsi14, TECHNICAL.rsi), adx, volume },
    TECHNICAL.weights,
  );
}

export interface QualityInputs {
  roe: number | null;
  roce: number | null;
  debtToEquity: number | null;
  /** Banks/NBFCs: leverage is the business, so D/E is not scored (PRD §8.2). */
  isFinancial: boolean;
  /** Annual net margins in percent, oldest first. */
  netMargins: readonly number[];
  /** Annual YoY growth in percent, oldest first. */
  revenueGrowth: readonly number[];
  profitGrowth: readonly number[];
}

export function qualityScore(i: QualityInputs): FactorResult {
  const margins = i.netMargins;
  const lastMargin = margins[margins.length - 1];
  const prevMargin = margins[margins.length - 2];
  const marginTrend =
    lastMargin !== undefined && prevMargin !== undefined
      ? interpolate(lastMargin - prevMargin, QUALITY.marginTrend)
      : null;
  const years = Math.min(QUALITY.growthYears, i.revenueGrowth.length);
  let growthConsistency: number | null = null;
  if (years >= 2) {
    const rev = i.revenueGrowth.slice(-years);
    const offset = i.profitGrowth.length - years;
    let good = 0;
    rev.forEach((g, k) => {
      const profit = i.profitGrowth[offset + k];
      if (g > 0 && (profit === undefined || profit > 0)) good += 1;
    });
    growthConsistency = (good / years) * 100;
  }
  return finish(
    {
      roe: pt(i.roe, QUALITY.returnOnCapital),
      roce: pt(i.roce, QUALITY.returnOnCapital),
      debtToEquity: i.isFinancial ? null : pt(i.debtToEquity, QUALITY.debtToEquity),
      marginTrend,
      growthConsistency,
    },
    QUALITY.weights,
  );
}

export interface ValuationScoreInputs {
  ownPercentile: number | null;
  sectorPercentile: number | null;
  currentPe: number | null;
}

export function valuationScore(i: ValuationScoreInputs): FactorResult {
  return finish(
    {
      ownHistory: i.ownPercentile === null ? null : 100 - i.ownPercentile,
      sector: i.sectorPercentile === null ? null : 100 - i.sectorPercentile,
      earningsYield:
        i.currentPe !== null && i.currentPe > 0
          ? interpolate(100 / i.currentPe, VALUATION.earningsYield)
          : null,
    },
    VALUATION.weights,
  );
}

export interface NewsSentimentPoint {
  /** 0–100, 50 = neutral (news_ai_analysis.sentiment_score). */
  sentimentScore: number;
  relevance: number;
  publishedAt: Date;
}

export function newsScore(
  points: readonly NewsSentimentPoint[],
  now: Date,
  halfLifeDays: number,
): FactorResult {
  const parts = points.map((p) => {
    const ageDays = Math.max(0, (now.getTime() - p.publishedAt.getTime()) / DAY_MS);
    return [p.sentimentScore, p.relevance * 0.5 ** (ageDays / halfLifeDays)] as const;
  });
  const mean = weightedMean(parts);
  return {
    score: mean === null ? null : clampScore(mean),
    components: { articles: points.length },
  };
}

export interface MomentumInputs {
  return1m: number | null;
  return3m: number | null;
  return6m: number | null;
  rsVsNifty: number | null;
  rsVsSector: number | null;
}

export function momentumScore(i: MomentumInputs): FactorResult {
  return finish(
    {
      return1m: pt(i.return1m, MOMENTUM.return1m),
      return3m: pt(i.return3m, MOMENTUM.return3m),
      return6m: pt(i.return6m, MOMENTUM.return6m),
      rsVsNifty: pt(i.rsVsNifty, MOMENTUM.relativeStrength),
      rsVsSector: pt(i.rsVsSector, MOMENTUM.relativeStrength),
    },
    MOMENTUM.weights,
  );
}

export interface MarketContextInputs {
  regime: MarketRegime | null;
  sectorTrend: Trend | null;
  vix: number | null;
}

export function marketContextScore(i: MarketContextInputs): FactorResult {
  return finish(
    {
      regime: i.regime === null ? null : MARKET_CONTEXT.regime[i.regime],
      sectorTrend: trendScore(i.sectorTrend),
      vix: pt(i.vix, MARKET_CONTEXT.vix),
    },
    MARKET_CONTEXT.weights,
  );
}

/** PRD §8.2: missing factors are dropped and the weights renormalised; coverage = share of weight available. */
export function overallScore(
  factors: Record<FactorName, number | null>,
  weights: FactorWeights,
): { overall: number | null; available: FactorName[]; coverage: number } {
  const available = FACTOR_NAMES.filter((f) => factors[f] !== null && weights[f] > 0);
  const total = FACTOR_NAMES.reduce((s, f) => s + weights[f], 0);
  const covered = available.reduce((s, f) => s + weights[f], 0);
  const mean = weightedMean(FACTOR_NAMES.map((f) => [factors[f], weights[f]] as const));
  return {
    overall: mean === null ? null : clampScore(mean),
    available,
    coverage: total > 0 ? round(covered / total, 4) : 0,
  };
}

export interface RiskInputs {
  atrPct: number | null;
  beta: number | null;
  maxDrawdownPct: number | null;
  stopDistancePct: number | null;
}

/** Separate from the factors: higher = riskier (PRD §8.2). */
export function riskScore(i: RiskInputs): FactorResult & { level: RiskLevel | null } {
  const result = finish(
    {
      atrPct: pt(i.atrPct, RISK.atrPct),
      beta: pt(i.beta, RISK.beta),
      maxDrawdown: pt(i.maxDrawdownPct, RISK.maxDrawdown),
      stopDistance: pt(i.stopDistancePct, RISK.stopDistance),
    },
    RISK.weights,
  );
  const s = result.score;
  const level: RiskLevel | null =
    s === null
      ? null
      : s < RISK.levels.LOW
        ? 'LOW'
        : s < RISK.levels.MEDIUM
          ? 'MEDIUM'
          : s < RISK.levels.HIGH
            ? 'HIGH'
            : 'VERY_HIGH';
  return { ...result, level };
}
