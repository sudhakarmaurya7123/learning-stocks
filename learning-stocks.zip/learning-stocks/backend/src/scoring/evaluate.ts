import { createHash } from 'node:crypto';
import type {
  ActionState,
  DataMode,
  MarketRegime,
  RecommendationBias,
  RiskLevel,
  SignalType,
  Trend,
  ValuationLabel,
} from '../domain/enums.js';
import type { SnapshotMetrics } from '../domain/fundamentals.js';
import type { ScoringConfig } from './config.js';
import {
  computeIndicatorSeries,
  type IndicatorPoint,
  type OhlcvBar,
} from '../technical/indicators.js';
import { computeLevels, type TradeLevels } from '../technical/levels.js';
import {
  beta,
  type DatedClose,
  maxDrawdownPct,
  relativeStrength,
  returnPct,
  round,
} from '../technical/stats.js';
import { classifyTrend, SMA200_SLOPE_LOOKBACK } from '../technical/trend.js';
import { toIst } from '../utils/ist.js';
import { type Decision, decide } from './DecisionEngine.js';
import { MOMENTUM, ENGINE_VERSION } from './rubrics.js';
import {
  marketContextScore,
  momentumScore,
  type NewsSentimentPoint,
  newsScore,
  overallScore,
  qualityScore,
  riskScore,
  technicalScore,
  valuationScore,
} from './ScoringEngine.js';
import { epsHistoryFromStatements, valuate } from './ValuationEngine.js';

/** Sectors where leverage is the business model: D/E is not scored (PRD §8.2). */
export const FINANCIAL_SECTORS: ReadonlySet<string> = new Set(['Financial Services']);
const DRAWDOWN_SESSIONS = 250;

export interface StatementRow {
  periodEnd: string;
  revenue: number | null;
  netProfit: number | null;
  eps: number | null;
}

export interface MarketContext {
  nifty: readonly DatedClose[];
  niftyTrend: Trend | null;
  regime: MarketRegime | null;
  vix: number | null;
}

export interface EvaluationInputs {
  stock: { id: string; symbol: string; sector: string | null };
  dataMode: DataMode;
  /** Daily bars, oldest first. */
  bars: readonly OhlcvBar[];
  stale: boolean;
  market: MarketContext;
  sector: { closes: readonly DatedClose[]; trend: Trend | null } | null;
  fundamentals: {
    asOf: string | null;
    snapshot: SnapshotMetrics | null;
    quarterly: readonly StatementRow[];
    annual: readonly StatementRow[];
  };
  peerPes: readonly number[];
  news: readonly NewsSentimentPoint[];
  holdsPosition: boolean;
  capital: number;
  config: ScoringConfig;
  now: Date;
}

export interface EvaluationRecord {
  stockId: string;
  dataMode: DataMode;
  dataAsOf: Date;
  scoringConfigVersion: string;
  scores: {
    technical: number | null;
    quality: number | null;
    valuation: number | null;
    news: number | null;
    momentum: number | null;
    marketContext: number | null;
    overall: number | null;
    risk: number | null;
  };
  riskLevel: RiskLevel | null;
  trend: Trend | null;
  valuationLabel: ValuationLabel;
  marketRegime: MarketRegime | null;
  actionState: ActionState;
  recommendationBias: RecommendationBias | null;
  paperSignal: SignalType;
  trade: TradeLevels | null;
  invalidation: string;
  factorsAvailable: Record<string, unknown>;
  inputs: Record<string, unknown>;
  inputHash: string;
}

export interface EvaluationBuild {
  record: EvaluationRecord;
  indicatorSeries: IndicatorPoint[];
  decision: Decision;
}

/** Stable JSON: keys sorted at every level, numbers rounded to 6 decimals, Dates as ISO, undefined dropped. */
export function canonicalJson(value: unknown): string {
  const normalise = (v: unknown): unknown => {
    if (v instanceof Date) return v.toISOString();
    if (typeof v === 'number') return Number.isFinite(v) ? round(v, 6) : null;
    if (Array.isArray(v)) return v.map(normalise);
    if (v && typeof v === 'object') {
      const out: Record<string, unknown> = {};
      for (const key of Object.keys(v).sort()) {
        const item = (v as Record<string, unknown>)[key];
        if (item !== undefined) out[key] = normalise(item);
      }
      return out;
    }
    return v;
  };
  return JSON.stringify(normalise(value));
}

export const datedCloses = (bars: readonly OhlcvBar[]): DatedClose[] =>
  bars.map((b) => ({ date: toIst(b.ts).date, close: b.close }));

/** Trend of any instrument from its daily bars (used for NIFTY 50 and sector indices). */
export function trendOf(bars: readonly OhlcvBar[]): Trend | null {
  const series = computeIndicatorSeries(bars);
  const last = series.at(-1)?.values;
  return classifyTrend({
    close: bars.at(-1)?.close ?? null,
    sma50: last?.sma50 ?? null,
    sma200: last?.sma200 ?? null,
    sma200Prev: series.at(-1 - SMA200_SLOPE_LOOKBACK)?.values.sma200 ?? null,
  });
}

function annualGrowth(rows: readonly StatementRow[], key: 'revenue' | 'netProfit'): number[] {
  const out: number[] = [];
  for (let k = 1; k < rows.length; k += 1) {
    const prev = rows[k - 1]?.[key];
    const cur = rows[k]?.[key];
    if (prev !== null && prev !== undefined && cur !== null && cur !== undefined && prev > 0)
      out.push((cur / prev - 1) * 100);
  }
  return out;
}

/** Composes all engines into one stock evaluation. Pure: same inputs → same record and hash. */
export function buildEvaluation(i: EvaluationInputs): EvaluationBuild {
  const t = i.config.thresholds;
  const series = computeIndicatorSeries(i.bars);
  const v = series.at(-1)?.values ?? null;
  const lastBar = i.bars.at(-1) ?? null;
  const price = lastBar?.close ?? null;
  const closes = datedCloses(i.bars);
  const trend = classifyTrend({
    close: price,
    sma50: v?.sma50 ?? null,
    sma200: v?.sma200 ?? null,
    sma200Prev: series.at(-1 - SMA200_SLOPE_LOOKBACK)?.values.sma200 ?? null,
  });

  const levels =
    price === null
      ? null
      : computeLevels({
          bars: i.bars,
          price,
          atr: v?.atr14 ?? null,
          sma20: v?.sma20 ?? null,
          sma50: v?.sma50 ?? null,
          sma200: v?.sma200 ?? null,
          trend,
          capital: i.capital,
          riskPct: t.riskPerTradePct,
          stopAtrMultiple: t.stopAtrMultiple,
          entryAtrWidth: t.entryAtrWidth,
        });
  const trade = levels?.trade ?? null;

  const annual = [...i.fundamentals.annual].sort((a, b) => a.periodEnd.localeCompare(b.periodEnd));
  const snapshot = i.fundamentals.snapshot;
  const valuation = valuate({
    closes,
    epsHistory: epsHistoryFromStatements(i.fundamentals.quarterly, annual),
    snapshotPe: snapshot?.pe ?? null,
    peerPes: i.peerPes,
    thresholds: {
      lowPctile: t.valuationLowPctile,
      highPctile: t.valuationHighPctile,
      minSectorPeers: t.minSectorPeers,
    },
  });

  const technical = technicalScore({
    close: price,
    prevClose: i.bars.at(-2)?.close ?? null,
    volume: lastBar?.volume ?? null,
    volumeSma20: v?.volumeSma20 ?? null,
    trend,
    rsi14: v?.rsi14 ?? null,
    macd: v?.macd ?? null,
    macdSignal: v?.macdSignal ?? null,
    adx14: v?.adx14 ?? null,
  });
  const quality = qualityScore({
    roe: snapshot?.roe ?? null,
    roce: snapshot?.roce ?? null,
    debtToEquity: snapshot?.debtToEquity ?? null,
    isFinancial: i.stock.sector !== null && FINANCIAL_SECTORS.has(i.stock.sector),
    netMargins: annual.flatMap((r) =>
      r.revenue !== null && r.revenue > 0 && r.netProfit !== null
        ? [(r.netProfit / r.revenue) * 100]
        : [],
    ),
    revenueGrowth: annualGrowth(annual, 'revenue'),
    profitGrowth: annualGrowth(annual, 'netProfit'),
  });
  const valuationFactor = valuationScore({
    ownPercentile: valuation.ownPercentile,
    sectorPercentile: valuation.sectorPercentile,
    currentPe: valuation.currentPe,
  });
  const news = newsScore(i.news, i.now, t.newsHalfLifeDays);
  const momentum = momentumScore({
    return1m: returnPct(closes, MOMENTUM.sessions.m1),
    return3m: returnPct(closes, MOMENTUM.sessions.m3),
    return6m: returnPct(closes, MOMENTUM.sessions.m6),
    rsVsNifty: relativeStrength(closes, i.market.nifty, MOMENTUM.sessions.m6),
    rsVsSector: i.sector ? relativeStrength(closes, i.sector.closes, MOMENTUM.sessions.m6) : null,
  });
  const market = marketContextScore({
    regime: i.market.regime,
    sectorTrend: i.sector?.trend ?? null,
    vix: i.market.vix,
  });

  const factors = {
    technical: technical.score,
    quality: quality.score,
    valuation: valuationFactor.score,
    news: news.score,
    momentum: momentum.score,
    market_context: market.score,
  };
  const overall = overallScore(factors, i.config.weights);
  const entryMid = trade ? (trade.entryLow + trade.entryHigh) / 2 : null;
  const risk = riskScore({
    atrPct: v?.atr14 !== null && v?.atr14 !== undefined && price ? (v.atr14 / price) * 100 : null,
    beta: beta(closes, i.market.nifty),
    maxDrawdownPct: maxDrawdownPct(closes.slice(-DRAWDOWN_SESSIONS).map((c) => c.close)),
    stopDistancePct: trade && entryMid ? ((entryMid - trade.stop) / entryMid) * 100 : null,
  });

  const decision = decide(
    {
      dailyBars: i.bars.length,
      price,
      stale: i.stale,
      lastBarDate: lastBar ? toIst(lastBar.ts).date : null,
      overall: overall.overall,
      qualityScore: quality.score,
      trend,
      regime: i.market.regime,
      valuationLabel: valuation.label,
      sma50: v?.sma50 ?? null,
      sma200: v?.sma200 ?? null,
      rsi14: v?.rsi14 ?? null,
      atr14: v?.atr14 ?? null,
      trade,
      holdsPosition: i.holdsPosition,
    },
    t,
  );

  // Everything the result depends on (never the wall clock unless news decay uses it).
  const inputs: Record<string, unknown> = {
    engineVersion: ENGINE_VERSION,
    configVersion: i.config.version,
    weights: i.config.weights,
    thresholds: t,
    lastBar: lastBar ? { ts: lastBar.ts, close: lastBar.close, volume: lastBar.volume } : null,
    dailyBars: i.bars.length,
    stale: i.stale,
    indicators: v,
    trend,
    market: { niftyTrend: i.market.niftyTrend, regime: i.market.regime, vix: i.market.vix },
    sectorTrend: i.sector?.trend ?? null,
    fundamentalsAsOf: i.fundamentals.asOf,
    snapshot,
    valuation,
    peerPes: i.peerPes,
    news: i.news.length > 0 ? { asOfDate: toIst(i.now).date, points: i.news } : null,
    holdsPosition: i.holdsPosition,
    capital: i.capital,
    levels: levels
      ? {
          trade,
          reason: levels.reason,
          supports: levels.supports.slice(0, 3),
          resistances: levels.resistances.slice(0, 3),
        }
      : null,
    factors: {
      technical,
      quality,
      valuation: valuationFactor,
      news,
      momentum,
      market_context: market,
    },
    risk: { components: risk.components },
    decision: { rule: decision.rule, reason: decision.reason },
  };

  const record: EvaluationRecord = {
    stockId: i.stock.id,
    dataMode: i.dataMode,
    dataAsOf: lastBar?.ts ?? i.now,
    scoringConfigVersion: i.config.version,
    scores: {
      technical: technical.score,
      quality: quality.score,
      valuation: valuationFactor.score,
      news: news.score,
      momentum: momentum.score,
      marketContext: market.score,
      overall: overall.overall,
      risk: risk.score,
    },
    riskLevel: risk.level,
    trend,
    valuationLabel: valuation.label,
    marketRegime: i.market.regime,
    actionState: decision.actionState,
    recommendationBias: decision.bias,
    paperSignal: decision.paperSignal,
    // Rule 1 (insufficient/stale data): never store prices derived from untrustworthy bars.
    trade: decision.rule === 1 ? null : trade,
    invalidation: decision.invalidation,
    factorsAvailable: {
      ...Object.fromEntries(Object.entries(factors).map(([k, s]) => [k, s !== null])),
      coverage: overall.coverage,
    },
    inputs,
    inputHash: createHash('sha256').update(canonicalJson(inputs)).digest('hex'),
  };
  return { record, indicatorSeries: series, decision };
}
