/**
 * Scoring rubrics (PRD §8.2). Breakpoints are (input, score) pairs joined piecewise-linearly and clamped.
 * Changing anything here changes evaluations: bump ENGINE_VERSION so input hashes change too.
 */
export const ENGINE_VERSION = 'engine-1';

type Points = ReadonlyArray<readonly [number, number]>;

export const TECHNICAL = {
  weights: { trend: 0.35, macd: 0.2, rsi: 0.2, adx: 0.15, volume: 0.1 },
  trend: { UPTREND: 100, SIDEWAYS: 50, DOWNTREND: 0 },
  /** RSI 55–65 is healthy momentum; above 75 is stretched, below 30 is weak. */
  rsi: [
    [0, 10],
    [30, 25],
    [45, 55],
    [55, 90],
    [65, 100],
    [75, 60],
    [85, 20],
    [100, 10],
  ] as Points,
  /** ADX below 15 = no trend; at 25+ the trend direction counts fully. */
  adxStrength: [
    [15, 0],
    [25, 1],
  ] as Points,
  volumeUp: [
    [0.5, 50],
    [1, 60],
    [1.5, 85],
    [2, 100],
  ] as Points,
  volumeDown: [
    [0.5, 50],
    [1, 40],
    [1.5, 15],
    [2, 0],
  ] as Points,
} as const;

export const QUALITY = {
  weights: { roe: 0.3, roce: 0.15, debtToEquity: 0.2, marginTrend: 0.15, growthConsistency: 0.2 },
  returnOnCapital: [
    [0, 0],
    [8, 30],
    [12, 55],
    [18, 85],
    [25, 100],
  ] as Points,
  debtToEquity: [
    [0, 100],
    [0.5, 90],
    [1, 65],
    [2, 30],
    [3, 10],
  ] as Points,
  /** Change in net margin, percentage points, latest year vs the year before. */
  marginTrend: [
    [-3, 10],
    [0, 55],
    [3, 100],
  ] as Points,
  growthYears: 4,
} as const;

export const VALUATION = {
  weights: { ownHistory: 0.4, sector: 0.4, earningsYield: 0.2 },
  /** Earnings yield (100 / P/E) in percent. */
  earningsYield: [
    [2, 0],
    [5, 50],
    [8, 100],
  ] as Points,
} as const;

export const MOMENTUM = {
  weights: { return1m: 0.2, return3m: 0.25, return6m: 0.25, rsVsNifty: 0.15, rsVsSector: 0.15 },
  return1m: [
    [-15, 0],
    [0, 50],
    [15, 100],
  ] as Points,
  return3m: [
    [-25, 0],
    [0, 50],
    [25, 100],
  ] as Points,
  return6m: [
    [-35, 0],
    [0, 50],
    [35, 100],
  ] as Points,
  relativeStrength: [
    [-20, 0],
    [0, 50],
    [20, 100],
  ] as Points,
  sessions: { m1: 21, m3: 63, m6: 126 },
} as const;

export const MARKET_CONTEXT = {
  weights: { regime: 0.5, sectorTrend: 0.25, vix: 0.25 },
  regime: { RISK_ON: 100, NEUTRAL: 50, RISK_OFF: 0 },
  /** India VIX: ~11–15 calm, 20+ nervous, 25+ stressed. */
  vix: [
    [11, 100],
    [15, 75],
    [20, 45],
    [25, 20],
    [35, 0],
  ] as Points,
} as const;

export const RISK = {
  weights: { atrPct: 0.3, beta: 0.25, maxDrawdown: 0.25, stopDistance: 0.2 },
  atrPct: [
    [1, 10],
    [2, 35],
    [3, 60],
    [5, 90],
  ] as Points,
  beta: [
    [0.5, 15],
    [1, 40],
    [1.5, 70],
    [2, 90],
  ] as Points,
  maxDrawdown: [
    [10, 15],
    [20, 40],
    [35, 70],
    [50, 95],
  ] as Points,
  stopDistance: [
    [3, 20],
    [6, 45],
    [10, 70],
    [15, 90],
  ] as Points,
  /** Upper bounds (exclusive) for LOW, MEDIUM, HIGH; anything above is VERY_HIGH. */
  levels: { LOW: 35, MEDIUM: 55, HIGH: 75 },
} as const;
