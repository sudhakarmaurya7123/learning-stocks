import type {
  ActionState,
  MarketRegime,
  RecommendationBias,
  SignalType,
  Trend,
  ValuationLabel,
} from '../domain/enums.js';
import type { ScoringThresholds } from './config.js';
import type { TradeLevels } from '../technical/levels.js';
import { formatInr } from '../utils/format.js';

export interface DecisionInput {
  dailyBars: number;
  price: number | null;
  /** True when the last daily bar is older than thresholds.maxStaleSessions completed sessions. */
  stale: boolean;
  lastBarDate: string | null;
  overall: number | null;
  qualityScore: number | null;
  trend: Trend | null;
  regime: MarketRegime | null;
  valuationLabel: ValuationLabel;
  sma50: number | null;
  sma200: number | null;
  rsi14: number | null;
  atr14: number | null;
  trade: TradeLevels | null;
  holdsPosition: boolean;
}

export interface Decision {
  actionState: ActionState;
  bias: RecommendationBias | null;
  paperSignal: SignalType;
  rule: 1 | 2 | 3 | 4 | 5 | 6;
  reason: string;
  /** What would make this view wrong, with a computed price. Bias language only (PRD §1). */
  invalidation: string;
}

const make = (
  actionState: ActionState,
  bias: RecommendationBias | null,
  paperSignal: SignalType,
  rule: Decision['rule'],
  reason: string,
  invalidation: string,
): Decision => ({ actionState, bias, paperSignal, rule, reason, invalidation });

/** PRD §8.5 ordered rule table: the first matching rule wins. */
export function decide(i: DecisionInput, t: ScoringThresholds): Decision {
  const { price, overall, trade } = i;

  // Rule 1: not enough trustworthy data to hold any view.
  if (i.dailyBars < t.minDailyBars || price === null || overall === null || i.stale) {
    const why = i.stale
      ? `price data is stale (last daily bar ${i.lastBarDate ?? 'unknown'})`
      : price === null
        ? 'no current price'
        : i.dailyBars < t.minDailyBars
          ? `only ${i.dailyBars} of ${t.minDailyBars} daily bars`
          : 'no factor scores available';
    return make(
      'INSUFFICIENT_DATA',
      null,
      'HOLD',
      1,
      why,
      `No bias: ${why}. Re-evaluate after fresh data is synced.`,
    );
  }

  // Rule 2: weak overall, or a downtrend in a risk-off market with weak quality.
  const weakQuality = i.qualityScore !== null && i.qualityScore < t.weakQualityMax;
  if (
    overall < t.avoidOverallMax ||
    (i.trend === 'DOWNTREND' && i.regime === 'RISK_OFF' && weakQuality)
  ) {
    const level = i.sma200 ?? i.sma50 ?? price;
    const invalidation = `Reconsider only after a daily close above ${formatInr(level)}${i.sma200 !== null ? ' (200-day average)' : ''}.`;
    if (i.holdsPosition)
      return make(
        'REDUCE',
        'SELL_BIAS',
        'SELL',
        2,
        'weak setup while a paper position is held',
        invalidation,
      );
    return make(
      'AVOID',
      overall < t.strongSellOverallMax ? 'STRONG_SELL_BIAS' : 'SELL_BIAS',
      'HOLD',
      2,
      'weak overall setup',
      invalidation,
    );
  }

  // Rule 3: trend not confirmed.
  if (i.trend === 'DOWNTREND' || (i.sma200 !== null && price < i.sma200)) {
    const below200 = i.sma200 !== null && price < i.sma200;
    const level = below200 ? i.sma200 : (i.sma50 ?? i.sma200);
    const invalidation =
      level === null
        ? 'Needs a confirmed uptrend before a buy bias.'
        : `Needs a daily close above ${formatInr(level)} (${below200 ? '200' : '50'}-day average) to confirm the trend.`;
    return make(
      'WAIT_FOR_CONFIRMATION',
      'HOLD_BIAS',
      'HOLD',
      3,
      'trend not confirmed',
      invalidation,
    );
  }

  // Rule 4: price extended.
  const extended =
    (i.sma50 !== null && price > i.sma50 * (1 + t.extendedAboveSma50Pct / 100)) ||
    (i.rsi14 !== null && i.rsi14 > t.rsiOverbought) ||
    (trade !== null && i.atr14 !== null && price > trade.entryHigh + i.atr14);
  if (extended) {
    const invalidation = trade
      ? `Re-evaluate on a pullback into ${formatInr(trade.entryLow)}–${formatInr(trade.entryHigh)}; the setup fails below ${formatInr(trade.stop)}.`
      : `Re-evaluate on a pullback toward the 50-day average near ${formatInr(i.sma50 ?? price)}.`;
    return make('WAIT_FOR_PULLBACK', 'HOLD_BIAS', 'HOLD', 4, 'price extended', invalidation);
  }

  // Rule 5: buy zone.
  if (
    overall >= t.buyOverallMin &&
    i.valuationLabel !== 'OVERVALUED' &&
    trade !== null &&
    price >= trade.entryLow &&
    price <= trade.entryHigh &&
    i.regime !== 'RISK_OFF' &&
    trade.riskReward >= t.minRiskReward
  ) {
    return make(
      'BUY_ZONE',
      overall >= t.strongBuyOverallMin ? 'STRONG_BUY_BIAS' : 'BUY_BIAS',
      'BUY',
      5,
      'all buy-zone conditions met',
      `Bias invalid on a daily close below ${formatInr(trade.stop)} (stop-loss).`,
    );
  }

  // Rule 6: hold.
  const invalidation = trade
    ? `Reassess on a daily close below ${formatInr(trade.stop)}.`
    : i.sma50 !== null
      ? `Reassess on a daily close below the 50-day average near ${formatInr(i.sma50)}.`
      : 'Reassess when more data is available.';
  return make('HOLD', 'HOLD_BIAS', 'HOLD', 6, 'no rule triggered a change', invalidation);
}
