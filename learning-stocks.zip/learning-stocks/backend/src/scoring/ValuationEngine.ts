import type { ValuationLabel } from '../domain/enums.js';
import { addDays } from '../utils/ist.js';
import { type DatedClose, percentileRank } from '../technical/stats.js';

/** Results are published after the period ends; EPS is usable only from then on (no look-ahead). */
export const QUARTER_RESULTS_LAG_DAYS = 45;
export const ANNUAL_RESULTS_LAG_DAYS = 60;
/** About one trading year of P/E observations before own history is trusted. */
export const MIN_PE_HISTORY = 250;
/** Own-history P/E must agree with the provider's P/E within this fraction (bonus/split basis check). */
export const PE_CROSSCHECK_TOLERANCE = 0.25;
/**
 * Implied share count (net profit ÷ EPS) moving by more than this factor between consecutive EPS points
 * means the per-share basis changed (bonus, split, merger). Organic growth never moves the share count.
 */
export const SHARE_COUNT_CHANGE_MAX = 1.25;

/** True when consecutive EPS points imply a different share count (EPS basis changed). */
export function hasEpsBasisBreak(eps: readonly EpsPoint[]): boolean {
  const withShares = [...eps]
    .filter((p): p is EpsPoint & { shares: number } => p.shares !== null && p.shares > 0)
    .sort((a, b) => a.availableOn.localeCompare(b.availableOn));
  for (let k = 1; k < withShares.length; k += 1) {
    const prev = withShares[k - 1]?.shares ?? 0;
    const cur = withShares[k]?.shares ?? 0;
    const ratio = cur / prev;
    if (ratio > SHARE_COUNT_CHANGE_MAX || ratio < 1 / SHARE_COUNT_CHANGE_MAX) return true;
  }
  return false;
}
const MAX_QUARTER_GAP_DAYS = 100;

export interface EpsPoint {
  /** IST date from which this trailing-twelve-month EPS was public. */
  availableOn: string;
  epsTtm: number;
  /** Implied share count (net profit ÷ EPS); null when net profit is unknown. */
  shares: number | null;
}

export interface StatementEps {
  periodEnd: string;
  eps: number | null;
  netProfit?: number | null;
}

/** Shares implied by profit and EPS of the same period; null when unknown or of opposite sign. */
function impliedShares(netProfit: number | null | undefined, eps: number): number | null {
  if (netProfit === null || netProfit === undefined || eps === 0) return null;
  const shares = netProfit / eps;
  return shares > 0 ? shares : null;
}

const dayGap = (a: string, b: string) =>
  (Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000;

/** TTM EPS points: rolling sums of 4 consecutive quarters, plus annual EPS (fiscal-year TTM). */
export function epsHistoryFromStatements(
  quarterly: readonly StatementEps[],
  annual: readonly StatementEps[],
): EpsPoint[] {
  const q = quarterly
    .filter((s): s is StatementEps & { eps: number } => s.eps !== null)
    .sort((a, b) => a.periodEnd.localeCompare(b.periodEnd));
  const points: EpsPoint[] = [];
  for (let i = 3; i < q.length; i += 1) {
    const window = q.slice(i - 3, i + 1);
    const consecutive = window.every(
      (s, k) =>
        k === 0 ||
        dayGap(window[k - 1]?.periodEnd ?? s.periodEnd, s.periodEnd) <= MAX_QUARTER_GAP_DAYS,
    );
    const last = window[3];
    if (consecutive && last) {
      const epsTtm = window.reduce((s, x) => s + x.eps, 0);
      const profits = window.map((x) => x.netProfit);
      const profitTtm = profits.every((x): x is number => x !== null && x !== undefined)
        ? profits.reduce((s, x) => s + x, 0)
        : null;
      points.push({
        availableOn: addDays(last.periodEnd, QUARTER_RESULTS_LAG_DAYS),
        epsTtm,
        shares: impliedShares(profitTtm, epsTtm),
      });
    }
  }
  for (const a of annual) {
    if (a.eps !== null)
      points.push({
        availableOn: addDays(a.periodEnd, ANNUAL_RESULTS_LAG_DAYS),
        epsTtm: a.eps,
        shares: impliedShares(a.netProfit, a.eps),
      });
  }
  return points.sort((a, b) => a.availableOn.localeCompare(b.availableOn));
}

export interface ValuationThresholds {
  lowPctile: number;
  highPctile: number;
  minSectorPeers: number;
}

export interface ValuationInput {
  closes: readonly DatedClose[];
  epsHistory: readonly EpsPoint[];
  /** Provider's current P/E (snapshot); used as the current P/E when no EPS history exists. */
  snapshotPe: number | null;
  /** Current P/E of other companies in the same sector (positive values only). */
  peerPes: readonly number[];
  thresholds: ValuationThresholds;
}

export interface ValuationResult {
  label: ValuationLabel;
  currentPe: number | null;
  ownPercentile: number | null;
  sectorPercentile: number | null;
  peersUsed: number;
  historyPoints: number;
  notes: string[];
}

/** P/E series: each close ÷ the latest TTM EPS public on that date (positive EPS only). */
function peSeries(closes: readonly DatedClose[], eps: readonly EpsPoint[]): number[] {
  const sorted = [...eps].sort((a, b) => a.availableOn.localeCompare(b.availableOn));
  const out: number[] = [];
  let k = -1;
  for (const c of closes) {
    while (k + 1 < sorted.length && (sorted[k + 1]?.availableOn ?? '') <= c.date) k += 1;
    const e = sorted[k]?.epsTtm;
    if (e !== undefined && e > 0) out.push(c.close / e);
  }
  return out;
}

/** PRD §8.3. The LLM never estimates fair value; neither does this engine. */
export function valuate(input: ValuationInput): ValuationResult {
  const notes: string[] = [];
  const series = peSeries(input.closes, input.epsHistory);
  // Current P/E = last close ÷ the EPS in effect on that date. A company whose latest EPS is ≤ 0 has no
  // P/E (never fall back to an older positive one). Without any published EPS, use the provider's P/E.
  const lastClose = input.closes[input.closes.length - 1];
  const epsNow = lastClose
    ? [...input.epsHistory]
        .filter((p) => p.availableOn <= lastClose.date)
        .sort((a, b) => a.availableOn.localeCompare(b.availableOn))
        .at(-1)
    : undefined;
  const snapshotPe = input.snapshotPe !== null && input.snapshotPe > 0 ? input.snapshotPe : null;
  const currentPe =
    epsNow === undefined
      ? snapshotPe
      : lastClose && epsNow.epsTtm > 0
        ? lastClose.close / epsNow.epsTtm
        : null;
  const peers = input.peerPes.filter((p) => p > 0);

  if (currentPe === null) {
    notes.push('no positive earnings: P/E is undefined');
    return {
      label: 'INSUFFICIENT_DATA',
      currentPe: null,
      ownPercentile: null,
      sectorPercentile: null,
      peersUsed: peers.length,
      historyPoints: series.length,
      notes,
    };
  }

  let ownPercentile: number | null = null;
  if (series.length < MIN_PE_HISTORY) {
    notes.push(`own P/E history too short (${series.length} of ${MIN_PE_HISTORY} days)`);
  } else if (hasEpsBasisBreak(input.epsHistory)) {
    notes.push(
      'implied share count changed between EPS reports (bonus, split or merger); EPS basis differs, own P/E history not used',
    );
  } else if (
    input.snapshotPe !== null &&
    input.snapshotPe > 0 &&
    Math.abs(currentPe - input.snapshotPe) / input.snapshotPe > PE_CROSSCHECK_TOLERANCE
  ) {
    notes.push(
      `own P/E history (${currentPe.toFixed(1)}) disagrees with provider P/E (${input.snapshotPe.toFixed(1)}); possible bonus/split basis mismatch, history not used`,
    );
  } else {
    ownPercentile = percentileRank(series, currentPe);
  }

  let sectorPercentile: number | null = null;
  if (peers.length >= input.thresholds.minSectorPeers) {
    sectorPercentile = percentileRank(peers, currentPe);
  } else {
    notes.push(
      `sector comparison needs ${input.thresholds.minSectorPeers} peers with P/E (have ${peers.length})`,
    );
  }

  const views = [ownPercentile, sectorPercentile].filter((v): v is number => v !== null);
  const combined = views.length > 0 ? views.reduce((s, v) => s + v, 0) / views.length : null;
  const label: ValuationLabel =
    combined === null
      ? 'INSUFFICIENT_DATA'
      : combined <= input.thresholds.lowPctile
        ? 'UNDERVALUED'
        : combined >= input.thresholds.highPctile
          ? 'OVERVALUED'
          : 'FAIR';
  return {
    label,
    currentPe,
    ownPercentile,
    sectorPercentile,
    peersUsed: peers.length,
    historyPoints: series.length,
    notes,
  };
}
