import type { DataMode } from './enums.js';

/**
 * Units, as stored (Phase 5 reads them this way):
 * - percentages: 13.8 = 13.8 % (roe, roce, dividendYield, operatingMargin, netMargin, revenueGrowthYoy, profitGrowthYoy)
 * - debtToEquity is a ratio: 0.46 = debt is 46 % of equity
 * - money is absolute INR (marketCap, freeCashFlow, revenueTtm, netProfitTtm, statement amounts); per-share values in INR
 * - capex is as reported: an outflow is negative
 * null = unavailable from the source. Never estimated.
 */
export const SNAPSHOT_FIELDS = [
  'marketCap',
  'pe',
  'pb',
  'epsTtm',
  'roe',
  'roce',
  'debtToEquity',
  'dividendYield',
  'operatingMargin',
  'netMargin',
  'freeCashFlow',
  'revenueTtm',
  'netProfitTtm',
  'revenueGrowthYoy',
  'profitGrowthYoy',
  'bookValuePerShare',
  'beta',
] as const;
export type SnapshotField = (typeof SNAPSHOT_FIELDS)[number];
export type SnapshotMetrics = Record<SnapshotField, number | null>;

/** Absolute amounts in the company's reporting currency. Stored only when that currency is INR. */
export const REPORTING_CURRENCY_FIELDS: readonly SnapshotField[] = [
  'freeCashFlow',
  'revenueTtm',
  'netProfitTtm',
];

export const STATEMENT_FIELDS = [
  'revenue',
  'operatingProfit',
  'netProfit',
  'eps',
  'totalDebt',
  'totalEquity',
  'cashFromOperations',
  'capex',
] as const;
export type StatementField = (typeof STATEMENT_FIELDS)[number];
export type StatementMetrics = Record<StatementField, number | null>;

export type StatementPeriod = 'QUARTERLY' | 'ANNUAL';

export interface FundamentalSnapshotRecord {
  stockId: string;
  dataMode: DataMode;
  /** IST calendar date (YYYY-MM-DD). One snapshot per stock per day per source. */
  asOf: string;
  source: string;
  metrics: SnapshotMetrics;
  raw: Record<string, unknown>;
}

export interface FinancialStatementRecord {
  stockId: string;
  dataMode: DataMode;
  periodType: StatementPeriod;
  periodEnd: string;
  source: string;
  metrics: StatementMetrics;
  raw: Record<string, unknown>;
}

export const emptySnapshotMetrics = (): SnapshotMetrics =>
  Object.fromEntries(SNAPSHOT_FIELDS.map((f) => [f, null])) as SnapshotMetrics;
export const emptyStatementMetrics = (): StatementMetrics =>
  Object.fromEntries(STATEMENT_FIELDS.map((f) => [f, null])) as StatementMetrics;
