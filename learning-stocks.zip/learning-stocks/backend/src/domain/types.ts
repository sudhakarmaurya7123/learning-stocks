import type { BarInterval, DataMode, Exchange, MarketType } from './enums.js';

export interface Stock {
  id: string;
  symbol: string;
  companyName: string;
  exchange: Exchange;
  isin: string | null;
  isinVerified: boolean;
  sector: string | null;
  industry: string | null;
  marketCap: number | null;
  currency: string;
  isActive: boolean;
  /** Extra names for news matching (e.g. 'RIL', 'L&T'). */
  aliases: string[];
}

export interface Market {
  id: string;
  symbol: string;
  name: string;
  exchange: Exchange;
  marketType: MarketType;
  sector: string | null;
  isActive: boolean;
  aliases: string[];
}

export type InstrumentRef = { kind: 'stock'; id: string } | { kind: 'market'; id: string };

export interface ProviderInstrument<T> {
  instrument: T;
  providerSymbol: string;
  verified: boolean;
}

/** One trading-calendar exception. date is the IST calendar date (YYYY-MM-DD). */
export interface Holiday {
  exchange: Exchange;
  date: string;
  description: string;
  specialOpen: string | null;
  specialClose: string | null;
}

/**
 * OHLCV bar. Convention: ts = the bar's OPEN time as a UTC instant.
 * Daily bars are stamped at that day's session open (09:15 IST, or a special session's open).
 */
export interface Bar {
  instrument: InstrumentRef;
  dataMode: DataMode;
  timeframe: BarInterval;
  ts: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  adjustedClose: number | null;
  volume: number;
  change: number | null;
  changePercent: number | null;
  vwap: number | null;
  source: string;
}

export interface LatestQuote {
  instrument: InstrumentRef;
  dataMode: DataMode;
  timeframe: BarInterval;
  ts: Date;
  price: number;
  change: number | null;
  changePercent: number | null;
  volume: number;
  source: string;
}

export interface TradingSession {
  open: Date;
  close: Date;
}

/** Trading-session lookup by IST calendar date; null when the exchange is closed all day. */
export interface TradingSessions {
  sessionOn(exchange: Exchange, date: string): Promise<TradingSession | null>;
  /** True when exchange holidays are loaded for this year (otherwise weekday-only assumptions apply). */
  hasCalendar(exchange: Exchange, year: string): Promise<boolean>;
}
