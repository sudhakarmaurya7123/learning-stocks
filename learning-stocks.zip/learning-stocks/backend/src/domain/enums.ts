export const EXCHANGES = ['NSE', 'BSE'] as const;
export type Exchange = (typeof EXCHANGES)[number];
export const MARKET_TYPES = ['BROAD_INDEX', 'SECTOR_INDEX', 'VOLATILITY'] as const;
export type MarketType = (typeof MARKET_TYPES)[number];
export const DATA_MODES = ['MOCK', 'LIVE'] as const;
export type DataMode = (typeof DATA_MODES)[number];
export const BAR_INTERVALS = ['1m', '5m', '15m', '1d'] as const;
export type BarInterval = (typeof BAR_INTERVALS)[number];
export const SENTIMENTS = ['BULLISH', 'NEUTRAL', 'BEARISH'] as const;
export type Sentiment = (typeof SENTIMENTS)[number];
export const IMPACT_LEVELS = ['LOW', 'MEDIUM', 'HIGH'] as const;
export const TRENDS = ['UPTREND', 'SIDEWAYS', 'DOWNTREND'] as const;
export const RISK_LEVELS = ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'] as const;
export const RECOMMENDATION_BIASES = [
  'STRONG_BUY_BIAS',
  'BUY_BIAS',
  'HOLD_BIAS',
  'SELL_BIAS',
  'STRONG_SELL_BIAS',
] as const;
export const ACTION_STATES = [
  'BUY_ZONE',
  'WAIT_FOR_PULLBACK',
  'WAIT_FOR_CONFIRMATION',
  'HOLD',
  'REDUCE',
  'AVOID',
  'INSUFFICIENT_DATA',
] as const;
export const VALUATION_LABELS = ['UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA'] as const;
export const MARKET_REGIMES = ['RISK_ON', 'NEUTRAL', 'RISK_OFF'] as const;
export const TRADE_SIDES = ['BUY', 'SELL'] as const;
export const ORDER_STATUSES = ['PENDING', 'EXECUTED', 'REJECTED', 'CANCELLED'] as const;
export const ORDER_SOURCES = ['MANUAL', 'AI_SIGNAL'] as const;
export const SIGNAL_TYPES = ['BUY', 'SELL', 'HOLD'] as const;
export const SIGNAL_STATUSES = ['ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED'] as const;
export const PERIOD_TYPES = ['QUARTERLY', 'ANNUAL', 'TTM'] as const;
export const LINK_TYPES = ['BENCHMARK', 'SECTOR_INDEX', 'CONSTITUENT'] as const;
export const USER_ROLES = ['OWNER', 'ADMIN', 'VIEWER'] as const;
export const JOB_STATUSES = ['STARTED', 'SUCCESS', 'PARTIAL', 'FAILED', 'SKIPPED'] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];
export const ANALYSIS_STATUSES = ['OK', 'FAILED', 'INSUFFICIENT_DATA'] as const;

/** Postgres enum name -> labels. The integration test asserts an exact match with the DB. */
export const DB_ENUMS = {
  exchange_code: EXCHANGES,
  market_type: MARKET_TYPES,
  data_mode: DATA_MODES,
  bar_interval: BAR_INTERVALS,
  sentiment: SENTIMENTS,
  impact_level: IMPACT_LEVELS,
  trend: TRENDS,
  risk_level: RISK_LEVELS,
  recommendation_bias: RECOMMENDATION_BIASES,
  action_state: ACTION_STATES,
  valuation_label: VALUATION_LABELS,
  market_regime: MARKET_REGIMES,
  trade_side: TRADE_SIDES,
  order_status: ORDER_STATUSES,
  order_source: ORDER_SOURCES,
  signal_type: SIGNAL_TYPES,
  signal_status: SIGNAL_STATUSES,
  period_type: PERIOD_TYPES,
  link_type: LINK_TYPES,
  user_role: USER_ROLES,
  job_status: JOB_STATUSES,
  analysis_status: ANALYSIS_STATUSES,
} as const;

export type Trend = (typeof TRENDS)[number];
export type RiskLevel = (typeof RISK_LEVELS)[number];
export type RecommendationBias = (typeof RECOMMENDATION_BIASES)[number];
export type ActionState = (typeof ACTION_STATES)[number];
export type ValuationLabel = (typeof VALUATION_LABELS)[number];
export type MarketRegime = (typeof MARKET_REGIMES)[number];
export type SignalType = (typeof SIGNAL_TYPES)[number];
export type ImpactLevel = (typeof IMPACT_LEVELS)[number];
export type UserRole = (typeof USER_ROLES)[number];
