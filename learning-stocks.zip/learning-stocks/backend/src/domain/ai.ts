/** A cited context block as stored with an AI output (so the UI can link facts to their sources). */
export interface SourceRef {
  id: string;
  kind: string;
  title: string;
  asOf: string | null;
  url: string | null;
}

export interface AnalysisFact {
  statement: string;
  source_ids: string[];
}
