import type { DataMode } from './enums.js';
import type { InstrumentRef } from './types.js';

/** A validated article ready to store. source = publisher host, e.g. 'business-standard.com'. */
export interface NewsArticle {
  dataMode: DataMode;
  title: string;
  description: string | null;
  content: string | null;
  source: string;
  sourceUrl: string;
  author: string | null;
  publishedAt: Date;
  language: string;
  contentHash: string;
}

/** matchedBy explains the score, e.g. 'name:title', 'alias:description', 'query'. */
export interface NewsMention {
  newsId: string;
  ref: InstrumentRef;
  relevance: number;
  matchedBy: string;
}

export interface NewsItem {
  id: string;
  title: string;
  description: string | null;
  source: string;
  sourceUrl: string;
  publishedAt: Date;
  relevance: number;
  matchedBy: string;
}
