import { AppError } from './errors.js';

export interface HttpRequest {
  url: string;
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  body?: unknown;
  timeoutMs?: number;
  /** On status >= 400, keep the first N chars of the body in error details (for APIs that explain errors there). */
  errorBodyChars?: number;
}

export interface HttpTextResponse {
  status: number;
  headers: Headers;
  text: string;
}

const DEFAULT_TIMEOUT_MS = 10_000;

/** origin + path only: query strings often carry API keys. */
export function redactUrl(url: string): string {
  try {
    const u = new URL(url);
    return `${u.origin}${u.pathname}`;
  } catch {
    return '[invalid-url]';
  }
}

function parseRetryAfter(value: string | null): number | undefined {
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
  const at = Date.parse(value);
  return Number.isNaN(at) ? undefined : Math.max(0, at - Date.now());
}

function safeCause(cause: unknown): { name: string; code: string | null } {
  const name = cause instanceof Error ? cause.name : typeof cause;
  const inner = cause instanceof Error ? cause.cause : undefined;
  const code =
    inner && typeof inner === 'object' && 'code' in inner && typeof inner.code === 'string'
      ? inner.code
      : null;
  return { name, code };
}

export async function httpRequest(req: HttpRequest): Promise<HttpTextResponse> {
  const target = redactUrl(req.url);
  const timeoutMs = req.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  let response: Response;
  try {
    const init: RequestInit = {
      method: req.method ?? 'GET',
      headers: { accept: 'application/json', ...req.headers },
      signal: AbortSignal.timeout(timeoutMs),
    };
    if (req.body !== undefined) {
      init.body = JSON.stringify(req.body);
      init.headers = { ...init.headers, 'content-type': 'application/json' };
    }
    response = await fetch(req.url, init);
  } catch (cause) {
    if (cause instanceof DOMException && cause.name === 'TimeoutError') {
      throw new AppError('TIMEOUT', `Request to ${target} timed out after ${timeoutMs} ms`, {
        details: { url: target, timeoutMs },
      });
    }
    // The raw cause can embed the full URL (with query-string keys); keep only safe fields.
    throw new AppError('NETWORK', `Network error calling ${target}`, {
      cause: safeCause(cause),
      details: { url: target },
    });
  }

  let errorBody: string | undefined;
  if (response.status >= 400) {
    if (req.errorBodyChars !== undefined && req.errorBodyChars > 0) {
      errorBody = (await response.text().catch(() => '')).slice(0, req.errorBodyChars);
    } else {
      await response.body?.cancel().catch(() => undefined);
    }
  }
  const details: Record<string, unknown> = { url: target, status: response.status };
  if (errorBody) details.body = errorBody;
  if (response.status === 401 || response.status === 403) {
    throw new AppError('AUTH_FAILED', `Authentication failed calling ${target}`, { details });
  }
  if (response.status === 429) {
    const retryAfterMs = parseRetryAfter(response.headers.get('retry-after'));
    throw new AppError(
      'RATE_LIMITED',
      `Rate limited by ${target}`,
      retryAfterMs === undefined ? { details } : { details, retryAfterMs },
    );
  }
  if (response.status >= 500) {
    throw new AppError('PROVIDER_DOWN', `Provider error ${response.status} from ${target}`, {
      details,
    });
  }
  if (response.status >= 400) {
    throw new AppError('INVALID_RESPONSE', `Unexpected status ${response.status} from ${target}`, {
      details,
    });
  }
  try {
    return { status: response.status, headers: response.headers, text: await response.text() };
  } catch (cause) {
    if (
      cause instanceof DOMException &&
      (cause.name === 'TimeoutError' || cause.name === 'AbortError')
    ) {
      throw new AppError(
        'TIMEOUT',
        `Reading the response from ${target} timed out after ${timeoutMs} ms`,
        {
          details: { url: target, timeoutMs },
        },
      );
    }
    throw new AppError('NETWORK', `Connection lost while reading ${target}`, {
      cause: safeCause(cause),
      details: { url: target },
    });
  }
}

export async function httpJson<T = unknown>(
  req: HttpRequest,
): Promise<{ status: number; headers: Headers; data: T }> {
  const res = await httpRequest(req);
  const target = redactUrl(req.url);
  if (res.text.trim() === '') {
    throw new AppError('EMPTY_RESPONSE', `Empty response from ${target}`, {
      details: { url: target, status: res.status },
    });
  }
  try {
    return { status: res.status, headers: res.headers, data: JSON.parse(res.text) as T };
  } catch (cause) {
    throw new AppError('INVALID_RESPONSE', `Malformed JSON from ${target}`, {
      cause,
      details: { url: target },
    });
  }
}
