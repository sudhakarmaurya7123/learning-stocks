export const ERROR_CODES = [
  'TIMEOUT',
  'RATE_LIMITED',
  'AUTH_FAILED',
  'INVALID_RESPONSE',
  'EMPTY_RESPONSE',
  'NETWORK',
  'PROVIDER_DOWN',
  'UNSUPPORTED',
  'BUDGET_EXCEEDED',
  'VALIDATION',
  'UNAUTHORIZED',
  'FORBIDDEN',
  'NOT_FOUND',
  'CONFLICT',
  'INTERNAL',
] as const;
export type ErrorCode = (typeof ERROR_CODES)[number];

const RETRYABLE: ReadonlySet<ErrorCode> = new Set<ErrorCode>([
  'TIMEOUT',
  'RATE_LIMITED',
  'NETWORK',
  'PROVIDER_DOWN',
]);

// Upstream (provider) failures surface as 5xx: the fault is not the API caller's.
const HTTP_STATUS: Readonly<Record<ErrorCode, number>> = {
  TIMEOUT: 504,
  RATE_LIMITED: 429,
  AUTH_FAILED: 502,
  INVALID_RESPONSE: 502,
  EMPTY_RESPONSE: 502,
  NETWORK: 502,
  PROVIDER_DOWN: 503,
  UNSUPPORTED: 501,
  BUDGET_EXCEEDED: 429,
  VALIDATION: 400,
  // Client-side auth failures. Distinct from AUTH_FAILED, which means a *provider* rejected us
  // and is therefore a 502: a missing bearer token is not an upstream outage.
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INTERNAL: 500,
};

export interface AppErrorOptions {
  cause?: unknown;
  details?: Record<string, unknown>;
  retryAfterMs?: number;
}

export class AppError extends Error {
  override readonly name = 'AppError';
  readonly code: ErrorCode;
  readonly details: Record<string, unknown> | undefined;
  readonly retryAfterMs: number | undefined;

  constructor(code: ErrorCode, message: string, options: AppErrorOptions = {}) {
    super(message, { cause: options.cause });
    this.code = code;
    this.details = options.details;
    this.retryAfterMs = options.retryAfterMs;
  }

  get retryable(): boolean {
    return RETRYABLE.has(this.code);
  }

  get httpStatus(): number {
    return HTTP_STATUS[this.code];
  }
}

export function isAppError(error: unknown): error is AppError {
  return error instanceof AppError;
}

/** Normalises any thrown value: AppErrors pass through, anything else is an INTERNAL error (a bug). */
export function toAppError(error: unknown): AppError {
  if (isAppError(error)) return error;
  return new AppError('INTERNAL', error instanceof Error ? error.message : String(error), {
    cause: error,
  });
}
