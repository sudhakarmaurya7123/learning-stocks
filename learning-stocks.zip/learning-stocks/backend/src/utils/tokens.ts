/** Rough token count for English text (~4 characters per token). For chunk sizing and mock usage only, never billing. */
export const estimateTokens = (text: string): number => Math.ceil(text.length / 4);
