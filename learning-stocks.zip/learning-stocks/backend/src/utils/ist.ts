/** Asia/Kolkata is a fixed +05:30 offset (no DST), so arithmetic is exact. */
export const IST_OFFSET_MS = 330 * 60 * 1000;
const DAY_MS = 86_400_000;

export function toIst(at: Date): { date: string; msOfDay: number; isoWeekday: number } {
  const shifted = new Date(at.getTime() + IST_OFFSET_MS);
  const msOfDay =
    shifted.getTime() -
    Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate());
  return {
    date: shifted.toISOString().slice(0, 10),
    msOfDay,
    isoWeekday: ((shifted.getUTCDay() + 6) % 7) + 1,
  };
}

function parseDate(date: string): [number, number, number] {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  if (!m) throw new TypeError(`Invalid date ${date}, expected YYYY-MM-DD`);
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}

function parseTime(time: string): number {
  const m = /^(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(time);
  if (!m) throw new TypeError(`Invalid time ${time}, expected HH:MM[:SS]`);
  return (Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3] ?? 0)) * 1000;
}

/** IST wall-clock date + time -> UTC instant. */
export function istToUtc(date: string, time: string): Date {
  const [y, mo, d] = parseDate(date);
  return new Date(Date.UTC(y, mo - 1, d) + parseTime(time) - IST_OFFSET_MS);
}

export function addDays(date: string, days: number): string {
  const [y, mo, d] = parseDate(date);
  return new Date(Date.UTC(y, mo - 1, d) + days * DAY_MS).toISOString().slice(0, 10);
}

export function isoWeekdayOf(date: string): number {
  const [y, mo, d] = parseDate(date);
  return ((new Date(Date.UTC(y, mo - 1, d)).getUTCDay() + 6) % 7) + 1;
}
