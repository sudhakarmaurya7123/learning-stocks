import pino, { type DestinationStream, type Logger } from 'pino';

export const REDACT_PATHS = [
  'apiKey',
  '*.apiKey',
  'password',
  '*.password',
  'token',
  '*.token',
  'authorization',
  '*.authorization',
  'req.headers.authorization',
  '*.headers.authorization',
  'req.headers.cookie',
  'secrets',
  '*.secrets',
  'OPENAI_API_KEY',
  'NEWS_API_KEY',
  'SUPABASE_SERVICE_ROLE_KEY',
  'JWT_SECRET',
  'headers["x-api-key"]',
  '*.headers["x-api-key"]',
  'req.headers["x-api-key"]',
];

export interface LoggerOptions {
  level: string;
  destination?: DestinationStream;
}

export function createLogger(options: LoggerOptions): Logger {
  const config = {
    level: options.level,
    base: { service: 'backend' },
    redact: { paths: REDACT_PATHS, censor: '[REDACTED]' },
    timestamp: pino.stdTimeFunctions.isoTime,
  };
  return options.destination ? pino(config, options.destination) : pino(config);
}
