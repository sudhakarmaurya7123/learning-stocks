const INR = new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** ₹ with Indian digit grouping: 1234567.5 → ₹12,34,567.50. */
export function formatInr(value: number): string {
  return `₹${INR.format(value)}`;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Rupees → ₹ crore (1 crore = 1,00,00,000) with Indian grouping. */
export function formatInrCrore(rupees: number): string {
  return `₹${INR.format(rupees / 10_000_000)} crore`;
}

/** 'YYYY-MM-DD' → '30 Jun 2026'. */
export function formatDate(isoDate: string): string {
  const [y, m, d] = isoDate.split('-');
  return `${d} ${MONTHS[Number(m) - 1] ?? m} ${y}`;
}
