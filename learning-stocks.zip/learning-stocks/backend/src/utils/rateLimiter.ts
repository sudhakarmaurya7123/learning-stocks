export interface RateLimiter {
  acquire(): Promise<void>;
}

export interface RateLimiterOptions {
  ratePerSecond: number;
  burst?: number;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Token bucket. Callers are served in arrival order. */
export function createRateLimiter(options: RateLimiterOptions): RateLimiter {
  if (!(options.ratePerSecond > 0)) throw new RangeError('ratePerSecond must be > 0');
  const capacity = Math.max(1, options.burst ?? 1);
  const refillPerMs = options.ratePerSecond / 1000;
  const now = options.now ?? Date.now;
  const sleep = options.sleep ?? defaultSleep;
  let tokens = capacity;
  let last = now();
  let queue: Promise<void> = Promise.resolve();

  const take = async (): Promise<void> => {
    for (;;) {
      const t = now();
      tokens = Math.min(capacity, tokens + (t - last) * refillPerMs);
      last = t;
      if (tokens >= 1) {
        tokens -= 1;
        return;
      }
      await sleep(Math.ceil((1 - tokens) / refillPerMs));
    }
  };

  return {
    acquire() {
      const next = queue.then(take);
      queue = next.catch(() => undefined);
      return next;
    },
  };
}
