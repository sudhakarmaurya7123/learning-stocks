import { buildApp } from './app.js';
import { loadDotEnv } from './config/dotenv.js';
import { readConfigOrExit } from './config/readConfig.js';
import { createContainer } from './container.js';

loadDotEnv();
const config = readConfigOrExit(process.env);
const container = createContainer(config);
const app = await buildApp(container);
await app.listen({ host: config.host, port: config.port });
container.logger.info(
  { dataMode: config.dataMode, providers: config.providers },
  'backend started',
);

const shutdown = async (signal: string) => {
  container.logger.info({ signal }, 'shutting down');
  await app.close();
  await container.close();
  process.exit(0);
};
process.once('SIGINT', () => void shutdown('SIGINT'));
process.once('SIGTERM', () => void shutdown('SIGTERM'));
