import { z } from 'zod';
import { type ChatPrice, chatPrice, EMBEDDING_PRICES_USD_PER_M } from '../providers/llm/pricing.js';

export class ConfigError extends Error {
  override readonly name = 'ConfigError';
}

const flag = z.stringbool();

/** Local Supabase (pnpm db:start). Used when DATABASE_URL is unset outside production. */
export const LOCAL_DATABASE_URL = 'postgresql://postgres:postgres@127.0.0.1:54322/postgres';

/** Hosts where an unauthenticated API reaches only this machine. */
const LOOPBACK_HOSTS: ReadonlySet<string> = new Set(['127.0.0.1', 'localhost', '::1']);

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  HOST: z.string().min(1).default('127.0.0.1'),
  PORT: z.coerce.number().int().min(1).max(65_535).default(4000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  DATABASE_URL: z
    .string()
    .regex(/^postgres(ql)?:\/\//, 'must be a postgres:// URL')
    .optional(),
  SUPABASE_URL: z.url().optional(),
  SUPABASE_ANON_KEY: z.string().optional(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().optional(),
  JWT_SECRET: z.string().optional(),
  MOCK_DATA: flag.default(true),
  MARKET_DATA_PROVIDER: z.enum(['mock', 'yahoo']).default('mock'),
  NEWS_PROVIDER: z.enum(['mock', 'rss', 'newsapi', 'none']).default('mock'),
  FUNDAMENTALS_PROVIDER: z.enum(['mock', 'yahoo', 'none']).default('mock'),
  LLM_PROVIDER: z.enum(['mock', 'openai', 'none']).default('mock'),
  NEWS_API_KEY: z.string().optional(),
  OPENAI_API_KEY: z.string().optional(),
  LLM_MODEL: z.string().optional(),
  EMBEDDING_MODEL: z.string().default('text-embedding-3-small'),
  EMBEDDING_DIMENSIONS: z.coerce
    .number()
    .int()
    .refine((d) => d === 1536, {
      message: 'must be 1536 to match document_embeddings.embedding vector(1536)',
    })
    .default(1536),
  LLM_DAILY_BUDGET_INR: z.coerce.number().nonnegative().default(100),
  USD_INR_RATE: z.coerce.number().positive().default(88),
  LLM_PRICE_INPUT_USD_PER_M: z.coerce.number().nonnegative().optional(),
  LLM_PRICE_OUTPUT_USD_PER_M: z.coerce.number().nonnegative().optional(),
  AUTO_PAPER_TRADE: flag.default(false),
  AUTH_MODE: z.enum(['jwt', 'none']).default('jwt'),
  CORS_ORIGIN: z.string().min(1).default('http://127.0.0.1:3000'),
  WORKER_QUEUE_SCHEMA: z.string().min(1).default('pgboss'),
  WORKER_TIMEZONE: z.string().min(1).default('Asia/Kolkata'),
});

type Env = z.infer<typeof EnvSchema>;

export interface AppConfig {
  env: Env['NODE_ENV'];
  host: string;
  port: number;
  logLevel: Env['LOG_LEVEL'];
  databaseUrl: string;
  dataMode: 'MOCK' | 'LIVE';
  providers: {
    marketData: Env['MARKET_DATA_PROVIDER'];
    news: Env['NEWS_PROVIDER'];
    fundamentals: Env['FUNDAMENTALS_PROVIDER'];
    llm: Env['LLM_PROVIDER'];
  };
  supabase: { url: string | null; anonKey: string | null };
  secrets: {
    openaiApiKey: string | null;
    newsApiKey: string | null;
    supabaseServiceRoleKey: string | null;
    jwtSecret: string | null;
  };
  llm: {
    model: string | null;
    embeddingModel: string;
    embeddingDimensions: number;
    dailyBudgetInr: number;
    /** ₹ per US$ for llm_calls cost estimates. */
    usdInrRate: number;
    /** LLM_PRICE_INPUT/OUTPUT_USD_PER_M: chat price for a model missing from the price table. */
    priceOverride: ChatPrice | null;
  };
  autoPaperTrade: boolean;
  auth: {
    /** 'none' answers every request as OWNER: local development only, refused in live mode. */
    mode: 'jwt' | 'none';
    /** HS256 shared secret (local Supabase). Wins over JWKS when both are set. */
    secret: string | null;
    /** JWKS endpoint derived from SUPABASE_URL, for the cloud path. */
    jwksUrl: string | null;
    issuer: string | null;
    audience: string;
  };
  corsOrigin: string;
  worker: {
    /** pg-boss owns this schema; it is not part of our migrations and db:reset drops it. */
    queueSchema: string;
    /** Timezone every job cron is evaluated in (PRD §13). */
    timezone: string;
  };
}

function withoutBlanks(env: Record<string, string | undefined>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(env)) {
    if (value !== undefined && value.trim() !== '') out[key] = value.trim();
  }
  return out;
}

function liveModeProblems(e: Env, priceOverride: ChatPrice | null): string[] {
  const problems: string[] = [];
  const selected = {
    MARKET_DATA_PROVIDER: e.MARKET_DATA_PROVIDER,
    NEWS_PROVIDER: e.NEWS_PROVIDER,
    FUNDAMENTALS_PROVIDER: e.FUNDAMENTALS_PROVIDER,
    LLM_PROVIDER: e.LLM_PROVIDER,
  };
  for (const [key, value] of Object.entries(selected)) {
    if (value === 'mock') problems.push(`${key}=mock requires MOCK_DATA=true`);
  }
  if (e.LLM_PROVIDER === 'openai' && !e.OPENAI_API_KEY)
    problems.push('OPENAI_API_KEY is required when LLM_PROVIDER=openai');
  if (e.LLM_PROVIDER === 'openai' && !e.LLM_MODEL)
    problems.push('LLM_MODEL is required when LLM_PROVIDER=openai');
  if (e.LLM_PROVIDER === 'openai' && EMBEDDING_PRICES_USD_PER_M[e.EMBEDDING_MODEL] === undefined)
    problems.push(
      `EMBEDDING_MODEL=${e.EMBEDDING_MODEL} has no price entry in providers/llm/pricing.ts; add one so embedding spend is recorded`,
    );
  if (e.LLM_PROVIDER === 'openai' && e.LLM_MODEL && chatPrice(e.LLM_MODEL, priceOverride) === null)
    problems.push(
      `LLM_MODEL=${e.LLM_MODEL} has no price entry in providers/llm/pricing.ts; set LLM_PRICE_INPUT_USD_PER_M and LLM_PRICE_OUTPUT_USD_PER_M`,
    );
  if (e.NEWS_PROVIDER === 'newsapi' && !e.NEWS_API_KEY)
    problems.push('NEWS_API_KEY is required when NEWS_PROVIDER=newsapi');
  return problems;
}

export function loadConfig(rawEnv: Record<string, string | undefined>): AppConfig {
  const parsed = EnvSchema.safeParse(withoutBlanks(rawEnv));
  if (!parsed.success) {
    throw new ConfigError(`Invalid configuration:\n${z.prettifyError(parsed.error)}`);
  }
  const e = parsed.data;
  if (!e.DATABASE_URL && e.NODE_ENV === 'production') {
    throw new ConfigError('Invalid configuration:\n- DATABASE_URL is required in production');
  }
  const hasIn = e.LLM_PRICE_INPUT_USD_PER_M !== undefined;
  const hasOut = e.LLM_PRICE_OUTPUT_USD_PER_M !== undefined;
  if (hasIn !== hasOut) {
    throw new ConfigError(
      'Invalid configuration:\n- set both LLM_PRICE_INPUT_USD_PER_M and LLM_PRICE_OUTPUT_USD_PER_M, or neither',
    );
  }
  const priceOverride =
    e.LLM_PRICE_INPUT_USD_PER_M !== undefined && e.LLM_PRICE_OUTPUT_USD_PER_M !== undefined
      ? { input: e.LLM_PRICE_INPUT_USD_PER_M, output: e.LLM_PRICE_OUTPUT_USD_PER_M }
      : null;
  if (!e.MOCK_DATA) {
    const problems = liveModeProblems(e, priceOverride);
    if (problems.length > 0)
      throw new ConfigError(`Invalid configuration:\n- ${problems.join('\n- ')}`);
  }
  // AUTH_MODE=none answers every request as OWNER, so it is fenced to a local mock-mode run. Both
  // checks apply in either data mode: an unauthenticated API reachable off-host is an open door.
  if (e.AUTH_MODE === 'none') {
    const problems: string[] = [];
    if (!e.MOCK_DATA)
      problems.push(
        'AUTH_MODE=none is refused with MOCK_DATA=false (live data must be authenticated)',
      );
    if (!LOOPBACK_HOSTS.has(e.HOST))
      problems.push(
        `AUTH_MODE=none is refused with HOST=${e.HOST}: bind 127.0.0.1 or set AUTH_MODE=jwt`,
      );
    if (problems.length > 0)
      throw new ConfigError(`Invalid configuration:\n- ${problems.join('\n- ')}`);
  }
  const mock = e.MOCK_DATA;
  return {
    env: e.NODE_ENV,
    host: e.HOST,
    port: e.PORT,
    logLevel: e.LOG_LEVEL,
    databaseUrl: e.DATABASE_URL ?? LOCAL_DATABASE_URL,
    dataMode: mock ? 'MOCK' : 'LIVE',
    providers: {
      marketData: mock ? 'mock' : e.MARKET_DATA_PROVIDER,
      news: mock ? 'mock' : e.NEWS_PROVIDER,
      fundamentals: mock ? 'mock' : e.FUNDAMENTALS_PROVIDER,
      llm: mock ? 'mock' : e.LLM_PROVIDER,
    },
    supabase: { url: e.SUPABASE_URL ?? null, anonKey: e.SUPABASE_ANON_KEY ?? null },
    secrets: {
      openaiApiKey: e.OPENAI_API_KEY ?? null,
      newsApiKey: e.NEWS_API_KEY ?? null,
      supabaseServiceRoleKey: e.SUPABASE_SERVICE_ROLE_KEY ?? null,
      jwtSecret: e.JWT_SECRET ?? null,
    },
    llm: {
      model: e.LLM_MODEL ?? null,
      embeddingModel: e.EMBEDDING_MODEL,
      embeddingDimensions: e.EMBEDDING_DIMENSIONS,
      dailyBudgetInr: e.LLM_DAILY_BUDGET_INR,
      usdInrRate: e.USD_INR_RATE,
      priceOverride,
    },
    autoPaperTrade: e.AUTO_PAPER_TRADE,
    auth: {
      mode: e.AUTH_MODE,
      secret: e.JWT_SECRET ?? null,
      jwksUrl:
        e.SUPABASE_URL === undefined ? null : `${e.SUPABASE_URL}/auth/v1/.well-known/jwks.json`,
      issuer: e.SUPABASE_URL === undefined ? null : `${e.SUPABASE_URL}/auth/v1`,
      audience: 'authenticated',
    },
    corsOrigin: e.CORS_ORIGIN,
    worker: { queueSchema: e.WORKER_QUEUE_SCHEMA, timezone: e.WORKER_TIMEZONE },
  };
}
