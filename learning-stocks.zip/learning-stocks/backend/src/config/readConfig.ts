import { type AppConfig, ConfigError, loadConfig } from './env.js';

/** Loads config or prints the problems and exits (process entrypoints only). */
export function readConfigOrExit(env: Record<string, string | undefined>): AppConfig {
  try {
    return loadConfig(env);
  } catch (error) {
    if (error instanceof ConfigError) {
      console.error(error.message);
      process.exit(1);
    }
    throw error;
  }
}
