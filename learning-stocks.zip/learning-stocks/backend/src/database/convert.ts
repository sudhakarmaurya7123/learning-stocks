/** pg returns numeric and int8 as strings; repositories convert explicitly at the boundary. */
export function toNumber(value: string | number | bigint | null | undefined): number | null {
  if (value === null || value === undefined) return null;
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n)) throw new TypeError(`Value ${String(value)} is not a number`);
  return n;
}

export function requireNumber(
  value: string | number | bigint | null | undefined,
  field: string,
): number {
  const n = toNumber(value);
  if (n === null) throw new TypeError(`Expected a number for ${field}, got null`);
  return n;
}
