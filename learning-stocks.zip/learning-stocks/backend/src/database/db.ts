import { Kysely, PostgresDialect, sql } from 'kysely';
import pg from 'pg';
import type { DB } from './types.generated.js';

// DATE -> 'YYYY-MM-DD' string. The default parser builds a local-midnight Date, which shifts
// the day on hosts west of UTC. Matches kysely-codegen --date-parser string.
const PG_DATE_OID = 1082;
pg.types.setTypeParser(PG_DATE_OID, (value: string) => value);

export type Database = Kysely<DB>;

export function createDatabase(connectionString: string, options: { max?: number } = {}): Database {
  const pool = new pg.Pool({
    connectionString,
    max: options.max ?? 10,
    connectionTimeoutMillis: 5000,
  });
  return new Kysely<DB>({ dialect: new PostgresDialect({ pool }) });
}

export async function pingDatabase(db: Database, timeoutMs = 2000): Promise<boolean> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<false>((resolve) => {
    timer = setTimeout(() => resolve(false), timeoutMs);
  });
  const probe = sql`select 1`.execute(db).then(
    () => true as const,
    () => false as const,
  );
  try {
    return await Promise.race([probe, timeout]);
  } finally {
    clearTimeout(timer);
  }
}
