import type { RecommendationBias, Sentiment } from '../domain/enums.js';
import { type CitedFact, validateCitations } from '../rag/citationValidator.js';

/** PRD §1 banned phrases (and close variants). Any match → one regeneration, then FAILED. */
export const BANNED_PATTERNS: ReadonlyArray<{ label: string; re: RegExp }> = [
  {
    label: 'guaranteed',
    re: /\bguaranteed\b|\bguarantees?\s+(returns?|profits?|gains?|success)\b/i,
  },
  { label: 'will definitely', re: /\bwill\s+definitely\b/i },
  { label: 'sure-shot', re: /\bsure[\s-]*shot\b/i },
  {
    label: 'certain to rise/fall',
    re: /\bcertain\s+to\s+(rise|fall|go\s+up|go\s+down|increase|decrease|gain|drop|climb|crash)\b/i,
  },
  { label: 'risk-free', re: /\brisk[\s-]*free\b/i },
];

export function collectStrings(value: unknown, out: string[] = []): string[] {
  if (typeof value === 'string') out.push(value);
  else if (Array.isArray(value)) for (const v of value) collectStrings(v, out);
  else if (value && typeof value === 'object')
    for (const v of Object.values(value)) collectStrings(v, out);
  return out;
}

export function bannedPhraseIssues(output: unknown): string[] {
  const issues = new Set<string>();
  for (const text of collectStrings(output)) {
    for (const p of BANNED_PATTERNS) {
      if (p.re.test(text))
        issues.add(
          `banned phrase "${p.label}": rewrite with bias language (e.g. "indicates a bullish bias")`,
        );
    }
  }
  return [...issues];
}

const NUMBER = /-?\d[\d,]*(?:\.\d+)?/g;
const RUPEE = /₹\s*(-?\d[\d,]*(?:\.\d+)?)/g;
const toNumber = (s: string) => Number(s.replace(/,/g, ''));

/** "Do not invent prices": every ₹ amount in the output must match a number in the context within 1%. */
export function unknownRupeeIssues(output: unknown, contextText: string): string[] {
  const known = [...contextText.matchAll(NUMBER)]
    .map((m) => toNumber(m[0]))
    .filter(Number.isFinite);
  const issues = new Set<string>();
  for (const text of collectStrings(output)) {
    for (const m of text.matchAll(RUPEE)) {
      const raw = m[1] ?? '';
      const value = toNumber(raw);
      if (!Number.isFinite(value)) continue;
      const found = known.some((k) => Math.abs(k - value) <= Math.max(0.01, Math.abs(k) * 0.01));
      if (!found)
        issues.add(`₹${raw} does not appear in the context: quote only amounts from the context`);
    }
  }
  return [...issues];
}

export function citationIssues(
  facts: readonly CitedFact[],
  output: unknown,
  issued: ReadonlySet<string>,
): string[] {
  const r = validateCitations({ facts, texts: collectStrings(output) }, issued);
  return r.unknownIds.length > 0
    ? [
        `unknown source IDs ${r.unknownIds.join(', ')}: cite only block IDs that appear in the context`,
      ]
    : [];
}

const BUY: ReadonlySet<RecommendationBias> = new Set(['BUY_BIAS', 'STRONG_BUY_BIAS']);
const SELL: ReadonlySet<RecommendationBias> = new Set(['SELL_BIAS', 'STRONG_SELL_BIAS']);

/** The model explains the computed bias; it must not argue the opposite direction. */
export function biasIssues(sentiment: Sentiment, bias: RecommendationBias | null): string[] {
  if (bias && SELL.has(bias) && sentiment === 'BULLISH')
    return [
      `sentiment BULLISH contradicts the computed ${bias}: use NEUTRAL or BEARISH and explain the computed bias`,
    ];
  if (bias && BUY.has(bias) && sentiment === 'BEARISH')
    return [
      `sentiment BEARISH contradicts the computed ${bias}: use NEUTRAL or BULLISH and explain the computed bias`,
    ];
  return [];
}

export function sectorIssues(sectors: readonly string[], allowed: ReadonlySet<string>): string[] {
  const unknown = sectors.filter((s) => !allowed.has(s));
  return unknown.length > 0
    ? [`unknown sectors ${unknown.join(', ')}: choose only from the sectors listed in block S1`]
    : [];
}

export const clampText = (s: string, n: number): string =>
  s.length <= n ? s : `${s.slice(0, n - 1)}…`;
export const capList = (xs: readonly string[], n = 10, len = 300): string[] =>
  xs.slice(0, n).map((x) => clampText(x, len));
