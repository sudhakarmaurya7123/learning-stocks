import { z } from 'zod';
import type { AppSettingsRepository } from '../repositories/AppSettingsRepository.js';
import type { LlmCallRepository } from '../repositories/LlmCallRepository.js';
import { round } from '../technical/stats.js';
import { AppError } from '../utils/errors.js';
import { istToUtc, toIst } from '../utils/ist.js';

export interface BudgetCall {
  purpose: string;
  provider: string;
  model: string;
  promptVersion: string | null;
}

/** Anything that must check the daily ₹ budget before a paid model call. */
export interface BudgetGate {
  ensure(estimateInr: number, call: BudgetCall): Promise<void>;
}

export interface BudgetStatus {
  dailyBudgetInr: number;
  spentTodayInr: number;
  remainingInr: number;
  exhausted: boolean;
  /** IST midnight of the current day. */
  dayStart: Date;
}

export interface LlmBudgetDeps {
  llmCalls: Pick<LlmCallRepository, 'record' | 'spentSince'>;
  settings: AppSettingsRepository;
  /** LLM_DAILY_BUDGET_INR: used only when app_settings has no llm_daily_budget_inr row. */
  defaultDailyInr: number;
  now?: () => Date;
}

/** PRD §14: daily ₹ cap on estimated spend, counted from IST midnight across every model call. */
export class LlmBudget implements BudgetGate {
  constructor(private readonly deps: LlmBudgetDeps) {}

  async status(): Promise<BudgetStatus> {
    const now = this.deps.now?.() ?? new Date();
    const dayStart = istToUtc(toIst(now).date, '00:00');
    const daily =
      (await this.deps.settings.get('llm_daily_budget_inr', z.coerce.number().nonnegative())) ??
      this.deps.defaultDailyInr;
    const spent = round(await this.deps.llmCalls.spentSince(dayStart), 4);
    const remaining = round(Math.max(0, daily - spent), 4);
    return {
      dailyBudgetInr: daily,
      spentTodayInr: spent,
      remainingInr: remaining,
      exhausted: spent >= daily,
      dayStart,
    };
  }

  async ensure(estimateInr: number, call: BudgetCall): Promise<void> {
    const s = await this.status();
    if (s.spentTodayInr + estimateInr <= s.dailyBudgetInr) return;
    await this.deps.llmCalls.record({
      ...call,
      inputTokens: 0,
      outputTokens: 0,
      estCostInr: 0,
      latencyMs: null,
      cacheHit: false,
      status: 'BUDGET_EXCEEDED',
      error: `estimate ₹${estimateInr.toFixed(4)} exceeds remaining ₹${s.remainingInr.toFixed(4)}`,
    });
    throw new AppError(
      'BUDGET_EXCEEDED',
      `Daily LLM budget ₹${s.dailyBudgetInr} reached (spent ₹${s.spentTodayInr.toFixed(2)}); cached results only until IST midnight`,
      {
        details: { dailyBudgetInr: s.dailyBudgetInr, spentTodayInr: s.spentTodayInr, estimateInr },
      },
    );
  }
}
