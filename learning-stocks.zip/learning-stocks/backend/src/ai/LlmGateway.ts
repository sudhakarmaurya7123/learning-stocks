import type { z } from 'zod';
import { type ChatPrice, chatCostInr } from '../providers/llm/pricing.js';
import type { LLMProvider } from '../providers/llm/types.js';
import type { LlmCallRepository } from '../repositories/LlmCallRepository.js';
import { AppError, toAppError } from '../utils/errors.js';
import { type RetryOptions, withRetry } from '../utils/retry.js';
import { estimateTokens } from '../utils/tokens.js';
import type { BudgetGate } from './LlmBudget.js';
import type { RenderedPrompt } from './promptLoader.js';

const MAX_ATTEMPTS = 2; // first answer + one repair (PRD §9.2)
const REPAIR_RAW_CHARS = 4000;

export interface GatewayCall<T> {
  purpose: string;
  prompt: RenderedPrompt;
  schema: z.ZodType<T>;
  schemaName: string;
  maxOutputTokens: number;
  /** Extra checks beyond the schema; each returned string is fed back to the model in the repair attempt. */
  validate?: (data: T) => string[];
}

export interface GatewayResult<T> {
  data: T;
  model: string;
  attempts: number;
  costInr: number;
}

export interface LlmGatewayDeps {
  provider: LLMProvider;
  llmCalls: Pick<LlmCallRepository, 'record'>;
  budget: BudgetGate;
  usdInrRate: number;
  priceOverride: ChatPrice | null;
  retry?: RetryOptions;
}

function usageOf(
  details: Record<string, unknown> | undefined,
): { inputTokens: number; outputTokens: number } | null {
  const u = details?.usage;
  if (!u || typeof u !== 'object') return null;
  const { inputTokens, outputTokens } = u as Record<string, unknown>;
  return typeof inputTokens === 'number' && typeof outputTokens === 'number'
    ? { inputTokens, outputTokens }
    : null;
}

/** The only way chat models are called: budget gate, retries, validation, one repair, an llm_calls row per attempt. */
export class LlmGateway {
  constructor(private readonly deps: LlmGatewayDeps) {}

  get chatModel(): string {
    return this.deps.provider.chatModel ?? 'none';
  }

  async complete<T>(call: GatewayCall<T>): Promise<GatewayResult<T>> {
    const { provider } = this.deps;
    let user = call.prompt.user;
    let issues: string[] = [];
    let costInr = 0;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
      const meta = {
        purpose: call.purpose,
        provider: provider.name,
        model: this.chatModel,
        promptVersion: call.prompt.version,
      };
      const estimate = this.cost(
        this.chatModel,
        estimateTokens(call.prompt.system + user),
        call.maxOutputTokens,
      );
      await this.deps.budget.ensure(estimate, meta);
      let raw: string;
      try {
        const res = await withRetry(
          () =>
            provider.completeStructured({
              system: call.prompt.system,
              user,
              schema: call.schema,
              schemaName: call.schemaName,
              maxOutputTokens: call.maxOutputTokens,
            }),
          this.deps.retry,
        );
        const cost = this.cost(res.model, res.usage.inputTokens, res.usage.outputTokens);
        costInr += cost;
        issues = call.validate ? call.validate(res.data) : [];
        await this.deps.llmCalls.record({
          ...meta,
          model: res.model,
          inputTokens: res.usage.inputTokens,
          outputTokens: res.usage.outputTokens,
          estCostInr: cost,
          latencyMs: res.latencyMs,
          cacheHit: false,
          status: issues.length === 0 ? 'OK' : 'INVALID_OUTPUT',
          error: issues.length === 0 ? null : issues.join('; '),
        });
        if (issues.length === 0)
          return { data: res.data, model: res.model, attempts: attempt, costInr };
        raw = JSON.stringify(res.data);
      } catch (error) {
        const e = toAppError(error);
        const usage = usageOf(e.details);
        const cost = usage ? this.cost(this.chatModel, usage.inputTokens, usage.outputTokens) : 0;
        costInr += cost;
        const repairable = e.code === 'INVALID_RESPONSE' && typeof e.details?.raw === 'string';
        await this.deps.llmCalls.record({
          ...meta,
          inputTokens: usage?.inputTokens ?? 0,
          outputTokens: usage?.outputTokens ?? 0,
          estCostInr: cost,
          latencyMs: null,
          cacheHit: false,
          status: repairable ? 'INVALID_OUTPUT' : 'FAILED',
          error: `${e.code}: ${e.message}`,
        });
        if (!repairable) throw e;
        const detailIssues = Array.isArray(e.details?.issues)
          ? e.details.issues.filter((x): x is string => typeof x === 'string')
          : [];
        issues = [...detailIssues, e.message];
        raw = String(e.details?.raw);
      }
      user = [
        call.prompt.user,
        '',
        'Your previous answer was rejected for these reasons:',
        ...issues.map((i) => `- ${i}`),
        'Previous answer (for reference only):',
        raw.slice(0, REPAIR_RAW_CHARS),
        'Return a corrected answer that fixes every issue and follows all rules.',
      ].join('\n');
    }
    throw new AppError(
      'INVALID_RESPONSE',
      `Model output failed validation after one repair: ${issues.join('; ')}`,
      {
        details: { purpose: call.purpose, issues },
      },
    );
  }

  /**
   * Never coerce an unknown price to ₹0: that would record zero spend and let the daily budget pass
   * every call. An unpriced model (e.g. a new dated snapshot) is a configuration error.
   */
  private cost(model: string, inputTokens: number, outputTokens: number): number {
    const inr = chatCostInr(
      model,
      inputTokens,
      outputTokens,
      this.deps.usdInrRate,
      this.deps.priceOverride,
    );
    if (inr === null) {
      throw new AppError(
        'INTERNAL',
        `No price for chat model ${model}: add it to providers/llm/pricing.ts or set LLM_PRICE_INPUT_USD_PER_M and LLM_PRICE_OUTPUT_USD_PER_M`,
        { details: { model } },
      );
    }
    return inr;
  }
}
