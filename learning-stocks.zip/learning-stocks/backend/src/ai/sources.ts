import type { AnalysisFact, SourceRef } from '../domain/ai.js';
import type { ContextBlock } from '../rag/contextBuilder.js';
import type { RankedDocument } from '../rag/retriever.js';
import { collectStrings } from './outputGuards.js';

const INLINE_GROUP = /\[([A-Z]\d+(?:\s*,\s*[A-Z]\d+)*)\]/g;
const order = (id: string) => [id.charCodeAt(0), Number(id.slice(1))] as const;

/** Every block ID the output relies on (facts' source_ids and inline [X1] / [X1, Y2] references). */
export function citedIds(output: unknown, facts: readonly AnalysisFact[]): string[] {
  const ids = new Set<string>();
  for (const f of facts) for (const id of f.source_ids) ids.add(id.trim().replace(/^\[|\]$/g, ''));
  for (const text of collectStrings(output)) {
    for (const m of text.matchAll(INLINE_GROUP))
      for (const id of (m[1] ?? '').split(',')) ids.add(id.trim());
  }
  return [...ids]
    .filter((id) => /^[A-Z]\d+$/.test(id))
    .sort((a, b) => order(a)[0] - order(b)[0] || order(a)[1] - order(b)[1]);
}

/** Cited blocks as stored sources; retrieved documents carry their title and URL. Unknown IDs are dropped. */
export function sourcesFor(
  ids: readonly string[],
  blocks: readonly ContextBlock[],
  documents: readonly RankedDocument[],
): SourceRef[] {
  return ids.flatMap((id) => {
    const block = blocks.find((b) => b.id === id);
    if (!block) return [];
    const doc = block.kind === 'DOCUMENT' ? documents[Number(id.slice(1)) - 1] : undefined;
    const title = typeof doc?.metadata.title === 'string' ? doc.metadata.title : block.title;
    const url = typeof doc?.metadata.sourceUrl === 'string' ? doc.metadata.sourceUrl : null;
    return [
      { id, kind: block.kind, title, asOf: block.asOf ? block.asOf.toISOString() : null, url },
    ];
  });
}
