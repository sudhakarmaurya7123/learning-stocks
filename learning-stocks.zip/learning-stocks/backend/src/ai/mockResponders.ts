import type { MockResponder } from '../providers/llm/mock/MockLLMProvider.js';
import { SCHEMA_NAMES } from './schemas.js';

/** MOCK only: deterministic outputs derived from the prompt that pass every output guard. */
const blockIds = (text: string): string[] => [
  ...new Set([...text.matchAll(/^\[([A-Z]\d+)\]/gm)].map((m) => m[1] ?? '')),
];
const between = (text: string, begin: string, end: string): string => {
  const a = text.indexOf(begin);
  const b = text.indexOf(end, a + begin.length);
  return a < 0 || b < 0 ? '' : text.slice(a + begin.length, b).trim();
};
const POSITIVE =
  /\b(rise|rises|rising|gain|gains|jumps?|surges?|wins?|beats?|record|upgraded?|strong|higher|outperforms?|rally|rallies)\b/i;
const NEGATIVE =
  /\b(fall|falls|falling|drops?|slips?|declines?|plunges?|query|probe|penalty|downgraded?|weak|lower|loss|losses|drags?)\b/i;
const BIAS = /bias (STRONG_BUY_BIAS|BUY_BIAS|HOLD_BIAS|SELL_BIAS|STRONG_SELL_BIAS)/;
const REGIME = /Regime (RISK_ON|NEUTRAL|RISK_OFF)/;

function sentimentFromBias(user: string): 'BULLISH' | 'NEUTRAL' | 'BEARISH' {
  const bias = BIAS.exec(user)?.[1] ?? '';
  return bias.includes('BUY') ? 'BULLISH' : bias.includes('SELL') ? 'BEARISH' : 'NEUTRAL';
}

function missing(user: string): string[] {
  const line = /Missing \(INSUFFICIENT_DATA\): (.+)/.exec(user)?.[1] ?? 'none';
  return line === 'none' ? [] : line.split(', ').map((m) => `[MOCK] ${m}`);
}

function facts(
  user: string,
  prefer: readonly string[],
): Array<{ statement: string; source_ids: string[] }> {
  const ids = blockIds(user);
  return prefer
    .filter((id) => ids.includes(id))
    .map((id) => ({ statement: `[MOCK] Evidence summarised in block ${id}.`, source_ids: [id] }));
}

const score = (s: 'BULLISH' | 'NEUTRAL' | 'BEARISH') =>
  s === 'BULLISH' ? 65 : s === 'BEARISH' ? 35 : 50;

const newsSentiment: MockResponder = (req) => {
  const article = between(req.user, '<<<BEGIN ARTICLE>>>', '<<<END ARTICLE>>>');
  const title = article.split('\n')[0] ?? '';
  const pos = POSITIVE.test(title);
  const neg = NEGATIVE.test(title);
  const sentiment = pos && !neg ? 'BULLISH' : neg && !pos ? 'BEARISH' : 'NEUTRAL';
  return {
    sentiment,
    sentiment_score: score(sentiment),
    confidence: 60,
    relevance_score: 0.8,
    impact_level: 'MEDIUM',
    summary: `[MOCK] ${title}`.trim(),
    positive_factors: pos ? ['[MOCK] positive wording in the headline'] : [],
    negative_factors: neg ? ['[MOCK] negative wording in the headline'] : [],
    reasoning: ['[MOCK] Keyword-based sentiment for offline testing.'],
  };
};

const stockAnalysis: MockResponder = (req) => {
  const sentiment = sentimentFromBias(req.user);
  return {
    sentiment,
    sentiment_score: score(sentiment),
    confidence: 50,
    technical_score: null,
    fundamental_score: null,
    news_score: null,
    momentum_score: null,
    risk_score: null,
    overall_score: null,
    trend: null,
    risk_level: null,
    recommendation: null,
    summary: `[MOCK] AI analysis indicates a ${sentiment.toLowerCase()} bias based on the available market, technical, fundamental and news data.`,
    reasoning: ['[MOCK] The computed action state and bias in block E1 drive this view.'],
    positive_factors: [],
    negative_factors: [],
    key_risks: ['[MOCK] Market and sector conditions can change quickly.'],
    catalysts: [],
    invalidation_conditions: ['[MOCK] See the computed invalidation in block E1.'],
    facts: facts(req.user, ['E1', 'N1']),
    interpretation: ['[MOCK] Offline deterministic analysis.'],
    insufficient_data: missing(req.user),
  };
};

const marketSummary: MockResponder = (req) => {
  const regime = REGIME.exec(req.user)?.[1] ?? 'NEUTRAL';
  const sentiment =
    regime === 'RISK_ON' ? 'BULLISH' : regime === 'RISK_OFF' ? 'BEARISH' : 'NEUTRAL';
  return {
    sentiment,
    sentiment_score: score(sentiment),
    confidence: 50,
    trend: null,
    regime: null,
    risk_level: null,
    summary: `[MOCK] AI analysis indicates a ${sentiment.toLowerCase()} market bias based on the computed regime and breadth.`,
    key_drivers: ['[MOCK] Computed market regime (block M1).'],
    key_risks: ['[MOCK] Volatility can rise quickly.'],
    sectors_positive: [],
    sectors_negative: [],
    facts: facts(req.user, ['M1', 'B1', 'N1']),
  };
};

const tradeSignal: MockResponder = (req) => ({
  reasoning: [
    '[MOCK] Paper trade only: the signal follows the computed action state in block E1.',
    '[MOCK] The entry zone, stop-loss and targets come from code; see block E1.',
  ],
  facts: facts(req.user, ['E1']),
});

// Never echoes the question: user text could carry ₹ amounts or banned phrases into the output.
const stockQa: MockResponder = (req) => ({
  answer:
    '[MOCK] Offline answer based only on the supplied context; a live model gives a full answer.',
  facts: facts(req.user, ['E1', 'N1']),
  interpretation: [],
  insufficient_data: missing(req.user),
});

export function mockResponders(): Record<string, MockResponder> {
  return {
    [SCHEMA_NAMES.newsSentiment]: newsSentiment,
    [SCHEMA_NAMES.stockAnalysis]: stockAnalysis,
    [SCHEMA_NAMES.marketSummary]: marketSummary,
    [SCHEMA_NAMES.tradeSignal]: tradeSignal,
    [SCHEMA_NAMES.stockQa]: stockQa,
  };
}
