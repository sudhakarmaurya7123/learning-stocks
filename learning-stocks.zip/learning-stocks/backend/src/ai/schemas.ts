import { z } from 'zod';
import {
  IMPACT_LEVELS,
  MARKET_REGIMES,
  RECOMMENDATION_BIASES,
  RISK_LEVELS,
  SENTIMENTS,
  TRENDS,
} from '../domain/enums.js';

/** Strict-structured-output safe: enums, number bounds, required + nullable only (lengths are clamped on store). */
const score = z.number().int().min(0).max(100);
const nullableScore = score.nullable();
const phrases = z.array(z.string());

export const SCHEMA_NAMES = {
  newsSentiment: 'news_sentiment',
  stockAnalysis: 'stock_analysis',
  marketSummary: 'market_summary',
  tradeSignal: 'trade_signal',
  stockQa: 'stock_qa',
} as const;

export const CitedFactSchema = z.object({ statement: z.string(), source_ids: z.array(z.string()) });

export const NewsSentimentSchema = z.object({
  sentiment: z.enum(SENTIMENTS),
  sentiment_score: score,
  confidence: score,
  relevance_score: z.number().min(0).max(1),
  impact_level: z.enum(IMPACT_LEVELS),
  summary: z.string(),
  positive_factors: phrases,
  negative_factors: phrases,
  reasoning: phrases,
});

/** PRD §9.2. Numeric scores, trend, risk_level and recommendation are overwritten from the evaluation. */
export const StockAnalysisSchema = z.object({
  sentiment: z.enum(SENTIMENTS),
  sentiment_score: score,
  confidence: score,
  technical_score: nullableScore,
  fundamental_score: nullableScore,
  news_score: nullableScore,
  momentum_score: nullableScore,
  risk_score: nullableScore,
  overall_score: nullableScore,
  trend: z.enum(TRENDS).nullable(),
  risk_level: z.enum(RISK_LEVELS).nullable(),
  recommendation: z.enum(RECOMMENDATION_BIASES).nullable(),
  summary: z.string(),
  reasoning: phrases,
  positive_factors: phrases,
  negative_factors: phrases,
  key_risks: phrases,
  catalysts: phrases,
  invalidation_conditions: phrases,
  facts: z.array(CitedFactSchema),
  interpretation: phrases,
  insufficient_data: phrases,
});

/** PRD §9.3. trend, regime and risk_level are overwritten from deterministic market context. */
export const MarketSummarySchema = z.object({
  sentiment: z.enum(SENTIMENTS),
  sentiment_score: score,
  confidence: score,
  trend: z.enum(TRENDS).nullable(),
  regime: z.enum(MARKET_REGIMES).nullable(),
  risk_level: z.enum(RISK_LEVELS).nullable(),
  summary: z.string(),
  key_drivers: phrases,
  key_risks: phrases,
  sectors_positive: phrases,
  sectors_negative: phrases,
  facts: z.array(CitedFactSchema),
});

/** Narrative only: signal, prices and quantity come from the evaluation. */
export const TradeSignalNarrativeSchema = z.object({
  reasoning: phrases,
  facts: z.array(CitedFactSchema),
});

export const QaAnswerSchema = z.object({
  answer: z.string(),
  facts: z.array(CitedFactSchema),
  interpretation: phrases,
  insufficient_data: phrases,
});

export type NewsSentimentOutput = z.infer<typeof NewsSentimentSchema>;
export type StockAnalysisOutput = z.infer<typeof StockAnalysisSchema>;
export type MarketSummaryOutput = z.infer<typeof MarketSummarySchema>;
export type TradeSignalNarrative = z.infer<typeof TradeSignalNarrativeSchema>;
export type QaAnswer = z.infer<typeof QaAnswerSchema>;
