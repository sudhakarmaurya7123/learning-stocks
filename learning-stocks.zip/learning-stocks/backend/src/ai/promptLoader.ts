import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { REPO_ROOT } from '../config/dotenv.js';
import { sha256Hex } from '../rag/documents.js';
import { AppError } from '../utils/errors.js';

export const PROMPT_NAMES = [
  'news_sentiment_v1',
  'stock_analysis_v1',
  'market_analysis_v1',
  'trade_signal_v1',
  'stock_qa_v1',
] as const;
export type PromptName = (typeof PROMPT_NAMES)[number];
export const PROMPTS_DIR = resolve(REPO_ROOT, 'backend/prompts');
const SHARED_RULES_FILE = 'shared_rules_v1.txt';

export interface PromptTemplate {
  /** Stored on every output (prompt_version). */
  version: PromptName;
  /** sha256 of the system (shared rules inlined) + user template: part of every input_hash. */
  templateHash: string;
  system: string;
  user: string;
}
export type RenderedPrompt = PromptTemplate;

const cache = new Map<string, PromptTemplate>();

/** File format: optional header lines, then "### SYSTEM", then "### USER". {{shared_rules}} is inlined. */
export function loadPrompt(name: PromptName, dir: string = PROMPTS_DIR): PromptTemplate {
  const key = `${dir}|${name}`;
  const cached = cache.get(key);
  if (cached) return cached;
  const raw = readFileSync(resolve(dir, `${name}.txt`), 'utf8');
  const sys = raw.indexOf('### SYSTEM');
  const usr = raw.indexOf('### USER');
  if (sys < 0 || usr < sys)
    throw new AppError('INTERNAL', `Prompt ${name} needs "### SYSTEM" then "### USER" sections`);
  const shared = readFileSync(resolve(dir, SHARED_RULES_FILE), 'utf8').trim();
  const system = raw
    .slice(sys + '### SYSTEM'.length, usr)
    .trim()
    .replace('{{shared_rules}}', shared);
  const user = raw.slice(usr + '### USER'.length).trim();
  const template: PromptTemplate = {
    version: name,
    templateHash: sha256Hex(`${system}\u0000${user}`),
    system,
    user,
  };
  cache.set(key, template);
  return template;
}

export function renderPrompt(
  template: PromptTemplate,
  vars: Readonly<Record<string, string>>,
): RenderedPrompt {
  const user = template.user.replace(/\{\{(\w+)\}\}/g, (_m, name: string) => {
    const value = vars[name];
    if (value === undefined)
      throw new AppError('INTERNAL', `missing prompt variable: ${name} (${template.version})`);
    return value;
  });
  return { ...template, user };
}
