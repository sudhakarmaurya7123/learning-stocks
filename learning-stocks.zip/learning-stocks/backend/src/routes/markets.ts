import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Container } from '../container.js';
import { freshness, meta, ok } from '../http/envelope.js';
import { limit } from '../http/rateLimit.js';
import { parseQuery } from '../http/validate.js';
import { quoteStalenessMinutes } from './stale.js';

/** The index whose AI summary represents "the market" (PRD §3.1). */
const BENCHMARK = 'NIFTY50';

/**
 * `coerce`, because a query string is text; capped, because an uncapped limit is a table scan
 * an authenticated caller can ask for 120 times a minute.
 */
const newsQuery = z.object({ limit: z.coerce.number().int().min(1).max(100).default(20) }).strict();

export async function marketRoutes(app: FastifyInstance, c: Container): Promise<void> {
  const mode = c.config.dataMode;

  app.get('/markets', { config: { rateLimit: limit('reads') } }, async () => {
    const now = new Date();
    const markets = await c.repositories.markets.listActive();
    const quotes = await Promise.all(
      markets.map((m) => c.repositories.marketData.latestQuote({ kind: 'market', id: m.id }, mode)),
    );
    const data = markets.map((m, i) => {
      const q = quotes[i] ?? null;
      return {
        symbol: m.symbol,
        name: m.name,
        exchange: m.exchange,
        market_type: m.marketType,
        quote:
          q === null
            ? null
            : {
                ts: q.ts.toISOString(),
                price: q.price,
                change: q.change,
                change_percent: q.changePercent,
                volume: q.volume,
                source: q.source,
              },
      };
    });
    // The freshest index quote stands for the card row as a whole.
    const newest = quotes.reduce<Date | null>(
      (acc, q) => (q === null ? acc : acc === null || q.ts > acc ? q.ts : acc),
      null,
    );
    const marketOpen = await c.services.calendar.isOpen('NSE', now);
    const stalenessMinutes = await quoteStalenessMinutes(c);
    return ok(data, meta(mode, now, freshness(newest, { now, marketOpen, stalenessMinutes })));
  });

  /**
   * The dashboard's "Latest News" feed (PRD §3.1): newest articles across every stock.
   *
   * A read of stored rows, like every other GET here — it never fetches from a provider and never
   * calls the LLM.
   */
  app.get('/news', { config: { rateLimit: limit('reads') } }, async (request) => {
    const now = new Date();
    const q = parseQuery(newsQuery, request.query);
    const items = await c.repositories.news.listRecent(mode, { limit: q.limit });
    const marketOpen = await c.services.calendar.isOpen('NSE', now);
    const stalenessMinutes = await quoteStalenessMinutes(c);
    const data = items.map((n) => ({
      title: n.title,
      description: n.description,
      source: n.source,
      source_url: n.sourceUrl,
      published_at: n.publishedAt.toISOString(),
      linked_symbols: n.linkedSymbols,
      // Null until the sentiment job has scored the article: a headline with no badge, not a
      // hidden headline.
      sentiment: n.sentiment,
      sentiment_score: n.sentimentScore,
      impact_level: n.impactLevel,
    }));
    return ok(
      data,
      meta(
        mode,
        now,
        freshness(items[0]?.publishedAt ?? null, { now, marketOpen, stalenessMinutes }),
      ),
    );
  });

  app.get('/market-status', { config: { rateLimit: limit('reads') } }, async () => {
    const now = new Date();
    const s = await c.services.calendar.status('NSE', now);
    return ok(
      {
        exchange: s.exchange,
        is_open: s.isOpen,
        phase: s.phase,
        holiday: s.holiday,
        next_open: s.nextOpen?.toISOString() ?? null,
        as_of: s.asOf.toISOString(),
      },
      meta(mode, now),
    );
  });

  app.get('/market-summary', { config: { rateLimit: limit('reads') } }, async () => {
    const now = new Date();
    const market = await c.repositories.markets.findBySymbol(BENCHMARK);
    const summary = market ? await c.repositories.marketSummaries.latest(market.id, mode) : null;
    const marketOpen = await c.services.calendar.isOpen('NSE', now);
    const stalenessMinutes = await quoteStalenessMinutes(c);
    const lastCompleteSessionOpen = await c.services.calendar.lastCompleteSessionOpen('NSE', now);
    // null, not 404: "no summary generated yet" is a normal state on a fresh database, and the
    // dashboard renders an empty panel rather than an error.
    const data =
      summary === null
        ? null
        : {
            market: BENCHMARK,
            analysis_time: summary.analysisTime.toISOString(),
            data_as_of: summary.dataAsOf.toISOString(),
            sentiment: summary.sentiment,
            sentiment_score: summary.sentimentScore,
            confidence: summary.confidence,
            trend: summary.trend,
            regime: summary.regime,
            risk_level: summary.riskLevel,
            summary: summary.summary,
            key_drivers: summary.keyDrivers,
            key_risks: summary.keyRisks,
            sectors_positive: summary.sectorsPositive,
            sectors_negative: summary.sectorsNegative,
            model: summary.model,
          };
    return ok(
      data,
      meta(
        mode,
        now,
        freshness(summary?.dataAsOf ?? null, {
          now,
          marketOpen,
          stalenessMinutes,
          // The market summary is computed from daily data, so it is current until the next
          // completed session rather than for 20 minutes (Phase 9 finding I4).
          cadence: 'daily',
          ...(lastCompleteSessionOpen === null ? {} : { lastCompleteSessionOpen }),
        }),
      ),
    );
  });
}
