import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Container } from '../container.js';
import { ACTION_STATES } from '../domain/enums.js';
import type { Stock } from '../domain/types.js';
import { toFundamentalsDto } from '../dto/fundamentals.js';
import { toSourceDtos } from '../dto/source.js';
import { toStockDto } from '../dto/stock.js';
import { freshness, meta, ok, type Cadence, type Freshness } from '../http/envelope.js';
import { limit } from '../http/rateLimit.js';
import { historyRoutes } from './history.js';
import { parseParams, parseQuery } from '../http/validate.js';
import { AppError } from '../utils/errors.js';
import { quoteStalenessMinutes } from './stale.js';

const DAY_MS = 86_400_000;
/** PRD §14: quotes cache for 30 s. The dashboard polls them far more often than they change. */
const QUOTE_TTL_MS = 30_000;
const NEWS_LIMIT = 20;
const SENTIMENT_WINDOW_DAYS = 30;

const symbolParams = z.object({ symbol: z.string().min(1).max(32) }).strict();

const listQuery = z
  .object({
    query: z.string().min(1).max(64).optional(),
    sector: z.string().min(1).max(128).optional(),
    action: z.enum(ACTION_STATES).optional(),
  })
  .strict();

export async function stockRoutes(app: FastifyInstance, c: Container): Promise<void> {
  const mode = c.config.dataMode;

  /** Resolves a path symbol to a stock, or 404s. The symbol is the public identifier. */
  const requireStock = async (raw: unknown): Promise<Stock> => {
    const { symbol } = parseParams(symbolParams, raw);
    const stock = await c.repositories.stocks.findBySymbol(symbol);
    if (!stock) {
      throw new AppError('NOT_FOUND', `No stock ${symbol.toUpperCase()}`, {
        details: { symbol: symbol.toUpperCase() },
      });
    }
    return stock;
  };

  /**
   * Freshness for one route's newest fact.
   *
   * `cadence` matters: a quote ages in minutes, while a daily fact (indicators, evaluation,
   * fundamentals, analysis) is current until the next completed session — daily bars are written
   * only after the close plus a settle, so judging them on the quote threshold reported "stale"
   * from 09:35 onward on data that was perfectly current (Phase 9 finding I4).
   */
  const freshnessFor = async (
    asOf: Date | null,
    now: Date,
    cadence: Cadence = 'quote',
  ): Promise<Freshness> => {
    const lastCompleteSessionOpen =
      cadence === 'daily' ? await c.services.calendar.lastCompleteSessionOpen('NSE', now) : null;
    return freshness(asOf, {
      now,
      marketOpen: await c.services.calendar.isOpen('NSE', now),
      stalenessMinutes: await quoteStalenessMinutes(c),
      cadence,
      ...(lastCompleteSessionOpen === null ? {} : { lastCompleteSessionOpen }),
    });
  };

  app.get('/stocks', { config: { rateLimit: limit('reads') } }, async (request) => {
    const now = new Date();
    const q = parseQuery(listQuery, request.query);
    const rows = await c.repositories.stocks.listWithFilters({
      mode,
      ...(q.query === undefined ? {} : { query: q.query }),
      ...(q.sector === undefined ? {} : { sector: q.sector }),
      ...(q.action === undefined ? {} : { action: q.action }),
    });
    const data = rows.map((r) => ({
      ...toStockDto(r.stock),
      evaluation:
        r.evaluation === null
          ? null
          : {
              action_state: r.evaluation.actionState,
              recommendation_bias: r.evaluation.recommendationBias,
              overall_score: r.evaluation.overallScore,
              risk_level: r.evaluation.riskLevel,
              evaluated_at: r.evaluation.evaluatedAt.toISOString(),
            },
      // PRD §3.1's remaining table columns, on the row so the dashboard needs one request for
      // twenty stocks rather than twenty aggregate calls against a 120/min budget. Null where
      // unknown, never 0: an unevaluated stock must not rank as the worst one.
      quote:
        r.quote === null
          ? null
          : {
              price: r.quote.price,
              change_percent: r.quote.changePercent,
              ts: r.quote.ts.toISOString(),
            },
      valuation_label: r.valuationLabel,
      risk_reward: r.riskReward,
      sentiment_score: r.sentimentScore,
      scores:
        r.scores === null
          ? null
          : {
              technical: r.scores.technical,
              quality: r.scores.quality,
              valuation: r.scores.valuation,
              news: r.scores.news,
              momentum: r.scores.momentum,
            },
    }));
    return ok(data, meta(mode, now));
  });

  app.get('/stocks/:symbol/quote', { config: { rateLimit: limit('reads') } }, async (request) => {
    const now = new Date();
    const stock = await requireStock(request.params);
    // Keyed on the resolved symbol, so /RELIANCE and /reliance share one entry.
    const quote = await c.cache.getOrSet(`quote:${mode}:${stock.symbol}`, QUOTE_TTL_MS, () =>
      c.repositories.marketData.latestQuote({ kind: 'stock', id: stock.id }, mode),
    );
    const data =
      quote === null
        ? null
        : {
            symbol: stock.symbol,
            ts: quote.ts.toISOString(),
            timeframe: quote.timeframe,
            price: quote.price,
            change: quote.change,
            change_percent: quote.changePercent,
            volume: quote.volume,
            source: quote.source,
          };
    return ok(data, meta(mode, now, await freshnessFor(quote?.ts ?? null, now)));
  });

  historyRoutes(app, c, { requireStock, freshnessFor });

  app.get(
    '/stocks/:symbol/technical',
    { config: { rateLimit: limit('reads') } },
    async (request) => {
      const now = new Date();
      const stock = await requireStock(request.params);
      const latest = await c.repositories.technicalIndicators.latest(stock.id, mode, '1d');
      const evaluation = await c.repositories.evaluations.latestDetail(stock.id, mode);
      const data =
        latest === null
          ? null
          : {
              symbol: stock.symbol,
              ts: latest.ts.toISOString(),
              timeframe: '1d',
              // The score is the engine's, read back from the stored evaluation — never
              // recomputed here, so the API and the decision can never disagree.
              technical_score: evaluation?.scores.technical ?? null,
              indicators: {
                sma_20: latest.values.sma20,
                sma_50: latest.values.sma50,
                sma_200: latest.values.sma200,
                ema_20: latest.values.ema20,
                ema_50: latest.values.ema50,
                ema_200: latest.values.ema200,
                rsi_14: latest.values.rsi14,
                macd: latest.values.macd,
                macd_signal: latest.values.macdSignal,
                macd_histogram: latest.values.macdHistogram,
                bollinger_upper: latest.values.bollingerUpper,
                bollinger_middle: latest.values.bollingerMiddle,
                bollinger_lower: latest.values.bollingerLower,
                atr_14: latest.values.atr14,
                adx_14: latest.values.adx14,
                stoch_k: latest.values.stochK,
                stoch_d: latest.values.stochD,
                volume_sma_20: latest.values.volumeSma20,
              },
            };
      return ok(data, meta(mode, now, await freshnessFor(latest?.ts ?? null, now, 'daily')));
    },
  );

  app.get(
    '/stocks/:symbol/fundamentals',
    { config: { rateLimit: limit('reads') } },
    async (request) => {
      const now = new Date();
      const stock = await requireStock(request.params);
      const snapshot = await c.repositories.fundamentals.latestSnapshot(stock.id, mode);
      // Quarterly: the series a dashboard charts. Annuals are available the same way if needed.
      const statements = await c.repositories.fundamentals.listStatements(
        stock.id,
        mode,
        'QUARTERLY',
        8,
      );
      return ok(
        {
          symbol: stock.symbol,
          snapshot: snapshot === null ? null : toFundamentalsDto(snapshot),
          statements: statements.map((s) => ({
            period_type: s.periodType,
            period_end: s.periodEnd,
            source: s.source,
            revenue: s.metrics.revenue,
            operating_profit: s.metrics.operatingProfit,
            net_profit: s.metrics.netProfit,
            eps: s.metrics.eps,
            total_debt: s.metrics.totalDebt,
            total_equity: s.metrics.totalEquity,
            cash_from_operations: s.metrics.cashFromOperations,
            capex: s.metrics.capex,
          })),
        },
        meta(mode, now),
      );
    },
  );

  app.get(
    '/stocks/:symbol/evaluation',
    { config: { rateLimit: limit('reads') } },
    async (request) => {
      const now = new Date();
      const stock = await requireStock(request.params);
      const e = await c.repositories.evaluations.latestDetail(stock.id, mode);
      const data =
        e === null
          ? null
          : {
              symbol: stock.symbol,
              evaluated_at: e.evaluatedAt.toISOString(),
              data_as_of: e.dataAsOf.toISOString(),
              scoring_config_version: e.scoringConfigVersion,
              action_state: e.actionState,
              recommendation_bias: e.recommendationBias,
              trend: e.trend,
              valuation_label: e.valuationLabel,
              market_regime: e.marketRegime,
              risk_level: e.riskLevel,
              scores: {
                technical: e.scores.technical,
                quality: e.scores.quality,
                valuation: e.scores.valuation,
                news: e.scores.news,
                momentum: e.scores.momentum,
                market_context: e.scores.marketContext,
                overall: e.overallScore,
                risk: e.riskScore,
              },
              coverage: e.coverage,
              levels: {
                entry_low: e.entryLow,
                entry_high: e.entryHigh,
                stop_loss: e.stopLoss,
                target_1: e.target1,
                target_2: e.target2,
                risk_reward: e.riskReward,
                position_size_hint: e.positionSizeHint,
              },
              invalidation: e.invalidation,
            };
      return ok(data, meta(mode, now, await freshnessFor(e?.dataAsOf ?? null, now, 'daily')));
    },
  );

  app.get('/stocks/:symbol/news', { config: { rateLimit: limit('reads') } }, async (request) => {
    const now = new Date();
    const stock = await requireStock(request.params);
    const items = await c.repositories.news.listForStockWithSentiment(stock.id, mode, {
      limit: NEWS_LIMIT,
    });
    return ok(
      {
        symbol: stock.symbol,
        // Articles and their per-stock AI sentiment live in separate tables (news /
        // news_ai_analysis) and the sentiment job runs separately, so the sentiment fields are
        // present and null until it has. PRD §3.2's news panel shows sentiment, impact and the
        // AI summary per headline, which is why they are joined here rather than left to the
        // aggregate-only /sentiment endpoint.
        articles: items.map((n) => ({
          title: n.title,
          description: n.description,
          source: n.source,
          source_url: n.sourceUrl,
          published_at: n.publishedAt.toISOString(),
          relevance: n.relevance,
          matched_by: n.matchedBy,
          sentiment: n.sentiment,
          sentiment_score: n.sentimentScore,
          impact_level: n.impactLevel,
          ai_summary: n.aiSummary,
        })),
      },
      meta(mode, now, await freshnessFor(items[0]?.publishedAt ?? null, now)),
    );
  });

  app.get(
    '/stocks/:symbol/sentiment',
    { config: { rateLimit: limit('reads') } },
    async (request) => {
      const now = new Date();
      const stock = await requireStock(request.params);
      const since = new Date(now.getTime() - SENTIMENT_WINDOW_DAYS * DAY_MS);
      const points = await c.repositories.news.sentimentsForStock(stock.id, mode, since);
      const scores = points.map((p) => p.sentimentScore);
      const average =
        scores.length === 0
          ? null
          : Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 100) / 100;
      return ok(
        {
          symbol: stock.symbol,
          window_days: SENTIMENT_WINDOW_DAYS,
          article_count: points.length,
          // A plain mean of stored per-article scores. The decision engine's own news factor
          // (which decays by age) lives in the evaluation; this is the raw read.
          average_sentiment_score: average,
        },
        meta(mode, now, await freshnessFor(points[0]?.publishedAt ?? null, now)),
      );
    },
  );

  const analysisHandler = (compact: boolean) => async (request: { params: unknown }) => {
    const now = new Date();
    const stock = await requireStock(request.params);
    const a = await c.repositories.stockAnalyses.latest(stock.id, mode);
    if (a === null) return ok(null, meta(mode, now, await freshnessFor(null, now, 'daily')));
    const base = {
      symbol: stock.symbol,
      analysis_time: a.analysisTime.toISOString(),
      data_as_of: a.dataAsOf.toISOString(),
      status: a.status,
      sentiment: a.sentiment,
      sentiment_score: a.sentimentScore,
      confidence: a.confidence,
      overall_score: a.overallScore,
      trend: a.trend,
      risk_level: a.riskLevel,
      recommendation: a.recommendation,
      summary: a.summary,
    };
    const data = compact
      ? base
      : {
          ...base,
          scores: {
            technical: a.technicalScore,
            fundamental: a.fundamentalScore,
            news: a.newsScore,
            momentum: a.momentumScore,
            risk: a.riskScore,
          },
          reasoning: a.reasoning,
          key_positive_factors: a.keyPositiveFactors,
          key_negative_factors: a.keyNegativeFactors,
          key_risks: a.keyRisks,
          catalysts: a.catalysts,
          invalidation_conditions: a.invalidationConditions,
          facts: a.facts,
          interpretation: a.interpretation,
          insufficient_data: a.insufficientData,
          sources: toSourceDtos(a.sources),
          model: a.model,
          prompt_version: a.promptVersion,
        };
    return ok(data, meta(mode, now, await freshnessFor(a.dataAsOf, now, 'daily')));
  };

  app.get(
    '/stocks/:symbol/analysis',
    { config: { rateLimit: limit('reads') } },
    analysisHandler(false),
  );
  app.get(
    '/stocks/:symbol/ai-summary',
    { config: { rateLimit: limit('reads') } },
    analysisHandler(true),
  );
}
