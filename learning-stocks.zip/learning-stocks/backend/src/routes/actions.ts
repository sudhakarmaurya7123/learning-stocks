import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Container } from '../container.js';
import { JOB_NAMES, type JobName, type JobPayload } from '../jobs/types.js';
import { toSourceDtos } from '../dto/source.js';
import { meta, ok } from '../http/envelope.js';
import { requireAdmin } from '../http/auth.js';
import { limit } from '../http/rateLimit.js';
import { parseBody, parseParams } from '../http/validate.js';
import { AppError } from '../utils/errors.js';

/**
 * A manual trigger carries `manual: true`, which bypasses a *calendar* gate so pressing
 * "Sync Market" on a Saturday does something — and never an availability gate or the LLM budget.
 * It deliberately does NOT carry `force`: handlers pass `force` straight to the AI services,
 * where it bypasses the hash cache, so one click would force-regenerate every stock.
 */
const MANUAL: JobPayload = { origin: 'api', manual: true };
/**
 * A manual send's dedup key, derived from what was asked for.
 *
 * It must differ from a cron send's key ('') so a manual trigger never collapses into a queued
 * scheduled job — and it must differ *between* manual requests that ask for different things.
 * A single shared 'manual' key made `POST /sync/market {symbols:['TCS']}` dedup into a queued
 * RELIANCE sync and answer 202 already_queued, so TCS was never synced (reproduced against
 * pg-boss 12.37.0, whose `stately` policy is unique on (name, state, coalesce(singleton_key,''))).
 * Two identical requests still collapse, which is what a double-click should do.
 */
const manualKey = (symbols?: readonly string[]): string =>
  symbols === undefined || symbols.length === 0
    ? 'manual'
    : `manual:${[...symbols]
        .map((s) => s.trim().toUpperCase())
        .sort()
        .join(',')}`;

const symbolsBody = z
  .object({ symbols: z.array(z.string().min(1).max(32)).min(1).max(50).optional() })
  .strict();
const symbolBody = z.object({ symbol: z.string().min(1).max(32) }).strict();
const jobParams = z.object({ name: z.string().min(1).max(64) }).strict();
const qaParams = z.object({ symbol: z.string().min(1).max(32) }).strict();
const qaBody = z.object({ question: z.string().trim().min(1).max(500) }).strict();

export async function actionRoutes(app: FastifyInstance, c: Container): Promise<void> {
  const mode = c.config.dataMode;

  const enqueue = async (name: JobName, symbols?: readonly string[]) => {
    const queue = c.services.jobs;
    if (!queue) {
      throw new AppError('UNSUPPORTED', 'No job queue is configured in this process');
    }
    const data: JobPayload = { ...MANUAL, ...(symbols === undefined ? {} : { symbols }) };
    const jobId = await queue.enqueue(name, data, { singletonKey: manualKey(symbols) });
    // null = deduplicated: a run is already queued, which is the queue working as intended.
    // Still 202, but the body says so — a bare null job_id reads as a lost request.
    return { job: name, job_id: jobId, already_queued: jobId === null };
  };

  const syncRoute = (
    path: string,
    id: 'sync.market' | 'sync.news' | 'sync.fundamentals',
    job: JobName,
  ) =>
    app.post(path, { config: { rateLimit: limit(id) } }, async (request, reply) => {
      requireAdmin(request);
      const body = parseBody(symbolsBody, request.body ?? {});
      const result = await enqueue(job, body.symbols);
      return reply.code(202).send(ok(result, meta(mode)));
    });

  syncRoute('/sync/market', 'sync.market', 'market.sync.eod');
  syncRoute('/sync/news', 'sync.news', 'news.sync');
  syncRoute('/sync/fundamentals', 'sync.fundamentals', 'fundamentals.sync');

  app.post(
    '/jobs/:name/run',
    { config: { rateLimit: limit('jobs.run') } },
    async (request, reply) => {
      requireAdmin(request);
      const { name } = parseParams(jobParams, request.params);
      if (!(JOB_NAMES as readonly string[]).includes(name)) {
        throw new AppError('VALIDATION', `Unknown job ${name}`, {
          details: { job: name, known: JOB_NAMES },
        });
      }
      const result = await enqueue(name as JobName);
      return reply.code(202).send(ok(result, meta(mode)));
    },
  );

  const aiRoute = (path: string, id: 'ai.analyze' | 'ai.regenerate', force: boolean) =>
    app.post(path, { config: { rateLimit: limit(id) } }, async (request) => {
      requireAdmin(request);
      const ai = c.services.ai;
      // 501, not 500: LLM_PROVIDER=none is a configuration, not a crash.
      if (!ai) throw new AppError('UNSUPPORTED', 'AI features are disabled (LLM_PROVIDER=none)');
      const { symbol } = parseBody(symbolBody, request.body ?? {});
      const stock = await c.repositories.stocks.findBySymbol(symbol);
      if (!stock) throw new AppError('NOT_FOUND', `No stock ${symbol.toUpperCase()}`);
      // Synchronous: the caller wants the answer, not a job id. The service's own hash,
      // min-interval and budget gates still apply; `force` skips only the first two, and
      // BUDGET_EXCEEDED surfaces as its existing 429.
      const result = await ai.analysis.run({
        jobName: path === '/ai/regenerate' ? 'api.ai-regenerate' : 'api.ai-analyze',
        symbols: [stock.symbol],
        force,
      });
      return ok(
        {
          symbol: stock.symbol,
          status: result.status,
          outcome: result.results[0]?.outcome ?? null,
          message: result.results[0]?.message ?? null,
          notes: result.notes,
        },
        meta(mode),
      );
    });

  aiRoute('/ai/analyze', 'ai.analyze', false);
  aiRoute('/ai/regenerate', 'ai.regenerate', true);

  app.post('/stocks/:symbol/qa', { config: { rateLimit: limit('qa') } }, async (request) => {
    // Not admin-only: asking a question is a read-shaped action any authenticated user may take.
    const ai = c.services.ai;
    if (!ai) throw new AppError('UNSUPPORTED', 'AI features are disabled (LLM_PROVIDER=none)');
    const { symbol } = parseParams(qaParams, request.params);
    const { question } = parseBody(qaBody, request.body ?? {});
    const answer = await ai.qa.ask(symbol, question);
    return ok(
      {
        symbol: symbol.toUpperCase(),
        question,
        answer: answer.answer,
        sources: toSourceDtos(answer.sources),
        cached: answer.cached,
      },
      meta(mode),
    );
  });
}
