import type { FastifyInstance } from 'fastify';
import type { Container } from '../container.js';
import { meta, ok } from '../http/envelope.js';
import { limit } from '../http/rateLimit.js';

export async function systemStatusRoutes(app: FastifyInstance, c: Container): Promise<void> {
  app.get('/system-status', { config: { rateLimit: limit('reads') } }, async () =>
    ok(await c.services.systemHealth.status(), meta(c.config.dataMode)),
  );
}
