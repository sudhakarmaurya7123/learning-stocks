import type { FastifyInstance } from 'fastify';
import type { Container } from '../container.js';
import { pingDatabase } from '../database/db.js';
import { meta, ok } from '../http/envelope.js';

const VERSION = '0.2.0';

export async function healthRoutes(app: FastifyInstance, c: Container): Promise<void> {
  app.get('/health', async (_request, reply) => {
    const now = new Date();
    const dbUp = await pingDatabase(c.db);
    let market: Record<string, unknown> | null = null;
    if (dbUp) {
      const s = await c.services.calendar.status('NSE', now);
      market = {
        exchange: s.exchange,
        is_open: s.isOpen,
        phase: s.phase,
        holiday: s.holiday,
        next_open: s.nextOpen ? s.nextOpen.toISOString() : null,
      };
    }
    const body = ok(
      {
        status: dbUp ? 'ok' : 'degraded',
        database: dbUp ? 'up' : 'down',
        data_mode: c.config.dataMode,
        providers: {
          market_data: c.config.providers.marketData,
          news: c.config.providers.news,
          fundamentals: c.config.providers.fundamentals,
          llm: c.config.providers.llm,
        },
        market,
        version: VERSION,
      },
      meta(c.config.dataMode, now),
    );
    return reply.code(dbUp ? 200 : 503).send(body);
  });
}
