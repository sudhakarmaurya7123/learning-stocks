import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Container } from '../container.js';
import { meta, ok } from '../http/envelope.js';
import { limit } from '../http/rateLimit.js';
import { parseParams } from '../http/validate.js';
import { AppError } from '../utils/errors.js';

const AGGREGATE_TTL_MS = 60_000;
const symbolParams = z.object({ symbol: z.string().min(1).max(32) }).strict();

export async function aggregateRoutes(app: FastifyInstance, c: Container): Promise<void> {
  const mode = c.config.dataMode;

  app.get('/stocks/:symbol', { config: { rateLimit: limit('reads') } }, async (request) => {
    const now = new Date();
    const { symbol } = parseParams(symbolParams, request.params);
    const key = `aggregate:${mode}:${symbol.trim().toUpperCase()}`;
    // 60s TTL (PRD §14). Not invalidated on job completion: the worker is a separate process
    // with its own cache and cannot reach this one, so a TTL is the honest mechanism.
    const aggregate = await c.cache.getOrSet(key, AGGREGATE_TTL_MS, () =>
      c.services.aggregate.build(symbol),
    );
    if (aggregate === null) {
      throw new AppError('NOT_FOUND', `No stock ${symbol.toUpperCase()}`, {
        details: { symbol: symbol.toUpperCase() },
      });
    }
    return ok(aggregate, meta(mode, now, aggregate.data_freshness.quote));
  });
}
