import { z } from 'zod';
import type { Container } from '../container.js';

const DEFAULT_STALENESS_MINUTES = 20;
const SETTING = 'quote_staleness_minutes';

/**
 * The staleness threshold freshness() judges against (PRD §11).
 *
 * Read from app_settings so the owner can change it without a restart; the code default is the
 * fallback when the row is missing.
 */
export async function quoteStalenessMinutes(c: Container): Promise<number> {
  const value = await c.repositories.settings.get(SETTING, z.number().positive());
  return value ?? DEFAULT_STALENESS_MINUTES;
}
