import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Container } from '../container.js';
import type { BarInterval } from '../domain/enums.js';
import type { Stock } from '../domain/types.js';
import { toQuoteDto } from '../dto/market.js';
import { meta, ok, type Freshness } from '../http/envelope.js';
import { limit } from '../http/rateLimit.js';
import { parseQuery } from '../http/validate.js';
import { AppError } from '../utils/errors.js';

const DAY_MS = 86_400_000;

/**
 * Which intervals each range may be served at.
 *
 * This is where Phase 3's provider lookback limits become an API contract: Yahoo keeps only ~60
 * days of 5m/15m bars, so `range=5Y&interval=5m` cannot be answered honestly. A 400 is kinder
 * than a chart that silently covers a different period than its label claims.
 */
export const RANGE_RULES: Readonly<
  Record<string, { days: number; intervals: readonly BarInterval[] }>
> = {
  '1D': { days: 1, intervals: ['5m', '15m'] },
  '1W': { days: 7, intervals: ['15m', '1d'] },
  '1M': { days: 31, intervals: ['15m', '1d'] },
  '3M': { days: 93, intervals: ['1d'] },
  '6M': { days: 186, intervals: ['1d'] },
  '1Y': { days: 366, intervals: ['1d'] },
  '5Y': { days: 1830, intervals: ['1d'] },
};

const historyQuery = z
  .object({
    range: z.enum(Object.keys(RANGE_RULES) as [string, ...string[]]).default('1Y'),
    interval: z.enum(['5m', '15m', '1d']).optional(),
  })
  .strict();

type Mas = { sma20: number | null; sma50: number | null; sma200: number | null };
const EMPTY_MAS: Mas = { sma20: null, sma50: null, sma200: null };

export interface HistoryRouteDeps {
  requireStock: (raw: unknown) => Promise<Stock>;
  freshnessFor: (asOf: Date | null, now: Date) => Promise<Freshness>;
}

/**
 * The chart's data: candles plus the moving-average overlays (PRD §3.2).
 *
 * Its own module because it owns the range/interval rules and the overlay alignment, which
 * together are as much code as the rest of the stock reads put together.
 */
export function historyRoutes(app: FastifyInstance, c: Container, deps: HistoryRouteDeps): void {
  const mode = c.config.dataMode;

  app.get('/stocks/:symbol/history', { config: { rateLimit: limit('reads') } }, async (request) => {
    const now = new Date();
    const stock = await deps.requireStock(request.params);
    const q = parseQuery(historyQuery, request.query);
    const rule = RANGE_RULES[q.range];
    if (!rule) throw new AppError('VALIDATION', `Unsupported range ${q.range}`);
    const interval = q.interval ?? rule.intervals[rule.intervals.length - 1];
    if (interval === undefined || !rule.intervals.includes(interval)) {
      throw new AppError(
        'VALIDATION',
        `range=${q.range} cannot be served at interval=${String(interval)}; use one of ${rule.intervals.join(', ')}`,
        { details: { range: q.range, allowed: rule.intervals } },
      );
    }
    const bars = await c.repositories.marketData.getBars(
      { kind: 'stock', id: stock.id },
      mode,
      interval,
      new Date(now.getTime() - rule.days * DAY_MS),
      now,
    );
    const last = bars.at(-1)?.ts ?? null;

    /**
     * SMA overlays, one point per bar.
     *
     * Indicators are computed on the daily series, so an intraday range gets empty overlays
     * rather than a daily SMA stretched across a 5-minute axis. On a daily range the series keep
     * the bars' own timestamps and carry null where no indicator row exists — dropping those
     * points instead would silently shift the line against the candles.
     *
     * These are the STORED values the decision engine scored, never recomputed here, so the
     * overlay cannot drift away from the decision card.
     */
    const daily = interval === '1d';
    const rows =
      daily && bars.length > 0
        ? await c.repositories.technicalIndicators.movingAveragesBetween(
            stock.id,
            mode,
            '1d',
            bars[0]?.ts ?? now,
            last ?? now,
          )
        : [];
    const byTs = new Map(rows.map((r) => [r.ts.getTime(), r]));
    const series = (pick: (r: Mas) => number | null) =>
      daily
        ? bars.map((b) => ({
            ts: b.ts.toISOString(),
            value: pick(byTs.get(b.ts.getTime()) ?? EMPTY_MAS),
          }))
        : [];

    return ok(
      {
        symbol: stock.symbol,
        range: q.range,
        interval,
        bars: bars.map(toQuoteDto),
        indicators: {
          sma_20: series((r) => r.sma20),
          sma_50: series((r) => r.sma50),
          sma_200: series((r) => r.sma200),
        },
      },
      meta(mode, now, await deps.freshnessFor(last, now)),
    );
  });
}
