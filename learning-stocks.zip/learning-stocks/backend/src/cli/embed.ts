import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { DEFAULT_MAX_DOCUMENTS, type EmbeddableSource } from '../services/rag/EmbeddingService.js';

const SOURCES: readonly EmbeddableSource[] = ['NEWS', 'FINANCIALS'];

function usage(message: string): never {
  console.error(
    `${message}\nUsage: pnpm embed [--sources news,financials] [--max ${DEFAULT_MAX_DOCUMENTS}]`,
  );
  process.exit(2);
}

loadDotEnv();
const { values } = parseArgs({ options: { sources: { type: 'string' }, max: { type: 'string' } } });
const sources = values.sources
  ? values.sources.split(',').map((s) => s.trim().toUpperCase())
  : [...SOURCES];
const unknown = sources.filter((s) => !(SOURCES as readonly string[]).includes(s));
if (unknown.length > 0) usage(`Unknown source(s): ${unknown.join(', ')}`);
const max = values.max === undefined ? DEFAULT_MAX_DOCUMENTS : Number(values.max);
if (!Number.isInteger(max) || max <= 0) usage('--max must be a positive integer');

const container = createContainer(readConfigOrExit(process.env));
try {
  const service = container.services.embeddings;
  if (!service) {
    console.error('LLM_PROVIDER=none: embeddings are disabled.');
    process.exitCode = 1;
  } else {
    const r = await service.run({
      jobName: 'cli.embed',
      sources: sources as EmbeddableSource[],
      maxDocuments: max,
    });
    console.log(`[${r.dataMode}] ${r.provider} ${r.model} embed: ${r.status}`);
    console.log(
      `  documents: ${r.documents.written}/${r.documents.planned} written, ${r.documents.failed} failed`,
    );
    console.log(
      `  chunks: ${r.chunks.unique} unique, ${r.chunks.reused} reused, ${r.chunks.embedded} embedded; rows written ${r.rowsWritten}`,
    );
    console.log(`  tokens ${r.tokens}; estimated cost ₹${r.estCostInr.toFixed(4)}`);
    for (const f of r.failures.slice(0, 10))
      console.log(`  FAILED ${f.sourceType} ${f.sourceId}: ${f.code} ${f.message}`);
    if (r.failures.length > 10)
      console.log(`  … ${r.failures.length - 10} more failures (see system_logs)`);
    for (const note of r.notes) console.log(`  note: ${note}`);
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
