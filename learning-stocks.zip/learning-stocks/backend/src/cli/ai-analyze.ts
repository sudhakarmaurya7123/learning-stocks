import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const { values } = parseArgs({
  options: { symbols: { type: 'string' }, force: { type: 'boolean', default: false } },
});

const container = createContainer(readConfigOrExit(process.env));
try {
  const ai = container.services.ai;
  if (!ai) {
    console.error('LLM_PROVIDER=none: AI features are disabled.');
    process.exitCode = 1;
  } else {
    const symbols = values.symbols
      ?.split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const r = await ai.analysis.run({
      jobName: 'cli.ai-analyze',
      force: values.force,
      ...(symbols ? { symbols } : {}),
    });
    console.log(`[${container.config.dataMode}] AI analysis: ${r.status}`);
    for (const x of r.results) {
      console.log(`  ${x.symbol.padEnd(12)} ${x.outcome}${x.message ? `  ${x.message}` : ''}`);
    }
    for (const n of r.notes) console.log(`  note: ${n}`);
    console.log('AI analysis explains the computed evaluation; it is not investment advice.');
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
