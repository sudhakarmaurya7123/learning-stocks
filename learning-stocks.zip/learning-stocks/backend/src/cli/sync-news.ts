import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

const DAY_MS = 86_400_000;

function usage(message: string): never {
  console.error(
    `${message}\nUsage: pnpm sync:news [--days 1-30] [--symbols RELIANCE,TCS] [--no-market] [--limit 1-100]`,
  );
  process.exit(2);
}

loadDotEnv();
const { values } = parseArgs({
  options: {
    days: { type: 'string', default: '2' },
    symbols: { type: 'string' },
    'no-market': { type: 'boolean', default: false },
    limit: { type: 'string', default: '50' },
  },
});
const days = Number(values.days);
if (!Number.isInteger(days) || days < 1 || days > 30)
  usage('--days must be a whole number from 1 to 30');
const limit = Number(values.limit);
if (!Number.isInteger(limit) || limit < 1 || limit > 100)
  usage('--limit must be a whole number from 1 to 100');

const container = createContainer(readConfigOrExit(process.env));
try {
  const service = container.services.news;
  if (!service) {
    console.log('News is disabled (NEWS_PROVIDER=none). Nothing to do.');
  } else {
    const r = await service.sync({
      jobName: 'cli.sync-news',
      since: new Date(Date.now() - days * DAY_MS),
      ...(values.symbols
        ? {
            symbols: values.symbols
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
          }
        : {}),
      includeMarket: !values['no-market'],
      perQueryLimit: limit,
    });
    console.log(`[${r.dataMode}] ${r.provider} news sync: ${r.status}`);
    console.log(`  queries: ${r.queries.succeeded}/${r.queries.total} ok`);
    console.log(
      `  articles: fetched ${r.articles.fetched}, new ${r.articles.new}, already stored ${r.articles.existing}, dropped ${r.articles.dropped}`,
    );
    console.log(`  mentions saved: ${r.mentions}`);
    for (const f of r.failures) console.log(`  FAILED ${f.source}: ${f.code} ${f.message}`);
    for (const n of r.notes) console.log(`  note: ${n}`);
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
