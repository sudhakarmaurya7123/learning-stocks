import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const { values } = parseArgs({
  options: { symbols: { type: 'string' }, 'no-statements': { type: 'boolean', default: false } },
});

const container = createContainer(readConfigOrExit(process.env));
try {
  const service = container.services.fundamentals;
  if (!service) {
    console.log('Fundamentals are disabled (FUNDAMENTALS_PROVIDER=none). Nothing to do.');
  } else {
    const r = await service.sync({
      jobName: 'cli.sync-fundamentals',
      ...(values.symbols
        ? {
            symbols: values.symbols
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
          }
        : {}),
      includeStatements: !values['no-statements'],
    });
    console.log(
      `[${r.dataMode}] ${r.provider} fundamentals sync (as of ${r.asOf} IST): ${r.status}`,
    );
    console.log(`  stocks: ${r.stocks.succeeded}/${r.stocks.total} ok`);
    console.log(`  snapshots: new ${r.snapshots.inserted}, refreshed ${r.snapshots.updated}`);
    console.log(
      `  statements: new ${r.statements.inserted}, refreshed ${r.statements.updated}, skipped (non-INR) ${r.statements.skipped}`,
    );
    for (const f of r.failures)
      console.log(`  FAILED ${f.symbol} (${f.providerSymbol}): ${f.code} ${f.message}`);
    for (const n of r.notes) console.log(`  note: ${n}`);
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
