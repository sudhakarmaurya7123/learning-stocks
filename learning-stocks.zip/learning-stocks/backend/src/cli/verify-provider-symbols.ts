import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { createRateLimiter } from '../utils/rateLimiter.js';
import { createYahooClient } from '../providers/market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from '../providers/market/yahoo/YahooMarketDataProvider.js';
import { verifyProviderSymbols } from '../services/marketData/verifyProviderSymbols.js';

// Verifies the yahoo ticker mappings against live Yahoo (network). Stores no market data.
loadDotEnv();
const container = createContainer(readConfigOrExit(process.env));
try {
  const provider = new YahooMarketDataProvider(
    createYahooClient(),
    createRateLimiter({ ratePerSecond: 2, burst: 2 }),
  );
  const outcomes = await verifyProviderSymbols({
    provider,
    providerSymbols: container.repositories.providerSymbols,
    now: () => new Date(),
  });
  for (const o of outcomes) {
    console.log(
      `${o.verified ? 'OK  ' : 'FAIL'}  ${o.symbol.padEnd(16)} ${o.providerSymbol.padEnd(22)} ${String(o.dailyBars).padStart(4)} bars  ${o.reason}`,
    );
  }
  const bad = outcomes.filter((o) => !o.verified).length;
  console.log(`\n${outcomes.length - bad}/${outcomes.length} yahoo mappings verified.`);
} finally {
  await container.close();
}
