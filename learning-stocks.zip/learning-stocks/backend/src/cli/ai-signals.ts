import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { formatInr } from '../utils/format.js';
import { istStamp } from '../rag/contextBuilder.js';

loadDotEnv();
const { values } = parseArgs({ options: { symbols: { type: 'string' } } });

const container = createContainer(readConfigOrExit(process.env));
try {
  const ai = container.services.ai;
  if (!ai) {
    console.error('LLM_PROVIDER=none: AI features are disabled.');
    process.exitCode = 1;
  } else {
    const symbols = values.symbols
      ?.split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const r = await ai.signals.run({ jobName: 'cli.ai-signals', ...(symbols ? { symbols } : {}) });
    console.log(
      `[${container.config.dataMode}] paper trade signals: ${r.status}; ${r.created} created, ${r.invalidated} invalidated, ${r.expired} expired, ${r.narrativeFallbacks} deterministic narratives`,
    );
    const inr = (x: number | null) => (x === null ? 'n/a' : formatInr(x));
    for (const x of r.results.filter((y) => y.outcome === 'CREATED' || y.outcome === 'SKIPPED')) {
      if (x.outcome === 'SKIPPED') {
        console.log(`  ${x.symbol}: skipped (${x.message ?? ''})`);
        continue;
      }
      const stock = await container.repositories.stocks.findBySymbol(x.symbol);
      const s = stock
        ? (
            await container.repositories.tradeSignals.active(stock.id, container.config.dataMode)
          ).find((y) => y.id === x.signalId)
        : undefined;
      if (s) {
        console.log(
          `  ${x.symbol} ${s.signal}: entry ${inr(s.entryLow)}–${inr(s.entryHigh)}, stop ${inr(s.stopLoss)}, targets ${inr(s.targetPrice)} / ${inr(s.target2)}, qty ${s.suggestedQuantity ?? 'n/a'}, valid until ${istStamp(s.validUntil)}`,
        );
      }
    }
    for (const n of r.notes) console.log(`  note: ${n}`);
    console.log('Paper trading only: signals never place orders.');
  }
} finally {
  await container.close();
}
