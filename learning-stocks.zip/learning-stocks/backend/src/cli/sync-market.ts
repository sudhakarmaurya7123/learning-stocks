import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { BAR_INTERVALS, type BarInterval } from '../domain/enums.js';

const DEFAULT_DAYS: Record<BarInterval, number> = { '1d': 1825, '15m': 5, '5m': 5, '1m': 2 };

function usage(message: string): never {
  console.error(
    `${message}\nUsage: pnpm sync:market [--timeframe 1d|5m|15m|1m] [--days N] [--symbols RELIANCE,TCS] [--no-indices] [--if-open]`,
  );
  process.exit(2);
}

loadDotEnv();
const { values } = parseArgs({
  options: {
    timeframe: { type: 'string', default: '1d' },
    days: { type: 'string' },
    symbols: { type: 'string' },
    'no-indices': { type: 'boolean', default: false },
    'if-open': { type: 'boolean', default: false },
  },
});
const timeframe = values.timeframe;
if (!(BAR_INTERVALS as readonly string[]).includes(timeframe))
  usage(`Unknown timeframe ${timeframe}`);
const tf = timeframe as BarInterval;
const days = values.days === undefined ? DEFAULT_DAYS[tf] : Number(values.days);
if (!Number.isFinite(days) || days <= 0) usage(`--days must be a positive number`);

const config = readConfigOrExit(process.env);
const container = createContainer(config);
try {
  const now = new Date();
  if (values['if-open'] && !(await container.services.calendar.isOpen('NSE', now))) {
    console.log('NSE is closed; nothing to sync (--if-open).');
  } else {
    const result = await container.services.marketData.sync({
      jobName: 'cli.sync-market',
      timeframe: tf,
      from: new Date(now.getTime() - days * 86_400_000),
      to: now,
      ...(values.symbols
        ? {
            symbols: values.symbols
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
          }
        : {}),
      includeIndices: !values['no-indices'],
    });
    console.log(
      `[${result.dataMode}] ${result.provider} ${result.timeframe} sync: ${result.status}`,
    );
    console.log(`  instruments: ${result.instruments.succeeded}/${result.instruments.total} ok`);
    console.log(
      `  bars: fetched ${result.bars.fetched}, inserted ${result.bars.inserted}, duplicates ${result.bars.duplicates}, dropped ${result.bars.dropped}, rejected ${result.bars.rejected}`,
    );
    for (const f of result.failures)
      console.log(`  FAILED ${f.symbol} (${f.providerSymbol}): ${f.code} ${f.message}`);
    for (const n of result.notes) console.log(`  note: ${n}`);
    process.exitCode = result.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
