import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const { values } = parseArgs({ options: { force: { type: 'boolean', default: false } } });

const container = createContainer(readConfigOrExit(process.env));
try {
  const ai = container.services.ai;
  if (!ai) {
    console.error('LLM_PROVIDER=none: AI features are disabled.');
    process.exitCode = 1;
  } else {
    const r = await ai.marketSummary.run({ jobName: 'cli.ai-market', force: values.force });
    console.log(`[${container.config.dataMode}] market summary: ${r.outcome} (${r.status})`);
    for (const n of r.notes) console.log(`  note: ${n}`);
    const nifty = await container.repositories.markets.findBySymbol('NIFTY50');
    const latest = nifty
      ? await container.repositories.marketSummaries.latest(nifty.id, container.config.dataMode)
      : null;
    if (latest) {
      console.log(
        `  AI Sentiment ${latest.sentiment} (score ${latest.sentimentScore}, confidence ${latest.confidence}); regime ${latest.regime ?? 'n/a'}; trend ${latest.trend ?? 'n/a'}; risk ${latest.riskLevel ?? 'n/a'}`,
      );
      console.log(`  ${latest.summary}`);
      for (const d of latest.keyDrivers) console.log(`  + ${d}`);
      for (const k of latest.keyRisks) console.log(`  - ${k}`);
    }
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
