import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { DEFAULT_MAX_ARTICLES } from '../services/ai/SentimentService.js';

loadDotEnv();
const { values } = parseArgs({ options: { max: { type: 'string' } } });
const max = values.max === undefined ? DEFAULT_MAX_ARTICLES : Number(values.max);
if (!Number.isInteger(max) || max <= 0) {
  console.error('Usage: pnpm ai:sentiment [--max N]');
  process.exit(2);
}

const container = createContainer(readConfigOrExit(process.env));
try {
  const ai = container.services.ai;
  if (!ai) {
    console.error('LLM_PROVIDER=none: AI features are disabled.');
    process.exitCode = 1;
  } else {
    const r = await ai.sentiment.run({ jobName: 'cli.ai-sentiment', maxArticles: max });
    console.log(`[${container.config.dataMode}] news sentiment: ${r.status}`);
    console.log(`  analysed ${r.analysed} of ${r.pending} pending (article, subject) pairs`);
    for (const f of r.failures.slice(0, 10))
      console.log(`  FAILED news ${f.newsId}: ${f.code} ${f.message}`);
    for (const n of r.notes) console.log(`  note: ${n}`);
    process.exitCode = r.status === 'FAILED' ? 1 : 0;
  }
} finally {
  await container.close();
}
