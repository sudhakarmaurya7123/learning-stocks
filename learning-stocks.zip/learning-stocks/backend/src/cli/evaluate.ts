import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { ENGINE_VERSION } from '../scoring/rubrics.js';
import { formatInr } from '../utils/format.js';

loadDotEnv();
const { values } = parseArgs({ options: { symbols: { type: 'string' } } });

const container = createContainer(readConfigOrExit(process.env));
try {
  const r = await container.services.evaluation.run({
    jobName: 'cli.evaluate',
    ...(values.symbols
      ? {
          symbols: values.symbols
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean),
        }
      : {}),
  });
  console.log(
    `[${r.dataMode}] evaluation (config ${r.configVersion ?? '?'}, ${ENGINE_VERSION}), market regime ${r.regime ?? 'unknown'}: ${r.status}`,
  );
  console.log(
    `  ${r.stocks.succeeded}/${r.stocks.total} stocks; ${r.evaluations.inserted} new, ${r.evaluations.unchanged} unchanged; ${r.indicatorRows} indicator rows`,
  );
  const pad = (s: string, n: number) => s.padEnd(n);
  console.log(
    `  ${pad('SYMBOL', 11)}${pad('STATE', 23)}${pad('BIAS', 17)}${pad('SCORE', 7)}${pad('PRICE', 13)}${pad('ENTRY', 25)}${pad('STOP', 13)}${pad('T1', 13)}R:R`,
  );
  for (const s of r.summaries) {
    const t = s.trade;
    console.log(
      `  ${pad(s.symbol, 11)}${pad(s.actionState, 23)}${pad(s.bias ?? '-', 17)}${pad(s.overall?.toFixed(1) ?? '-', 7)}` +
        `${pad(s.price === null ? '-' : formatInr(s.price), 13)}${pad(t ? `${formatInr(t.entryLow)}–${formatInr(t.entryHigh)}` : '-', 25)}` +
        `${pad(t ? formatInr(t.stop) : '-', 13)}${pad(t ? formatInr(t.target1) : '-', 13)}${t ? t.riskReward.toFixed(2) : '-'}`,
    );
    console.log(`    ↳ ${s.invalidation}`);
  }
  for (const f of r.failures) console.log(`  FAILED ${f.symbol}: ${f.code} ${f.message}`);
  for (const n of r.notes) console.log(`  note: ${n}`);
  console.log(
    '  AI-free deterministic analysis for personal research and paper trading only. Not investment advice.',
  );
  process.exitCode = r.status === 'FAILED' ? 1 : 0;
} finally {
  await container.close();
}
