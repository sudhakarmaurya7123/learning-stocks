import { sql } from 'kysely';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const container = createContainer(readConfigOrExit(process.env));
try {
  const s = await container.services.budget.status();
  console.log(
    `LLM budget today (from ${s.dayStart.toISOString()}): spent ₹${s.spentTodayInr.toFixed(4)} of ₹${s.dailyBudgetInr} (remaining ₹${s.remainingInr.toFixed(4)})${s.exhausted ? ' — LLM_BUDGET_EXHAUSTED' : ''}`,
  );
  const rows = await container.db
    .selectFrom('llm_calls')
    .select([
      'purpose',
      'status',
      sql<string>`count(*)::text`.as('calls'),
      sql<string>`coalesce(sum(est_cost_inr), 0)::text`.as('inr'),
    ])
    .where('created_at', '>=', s.dayStart)
    .groupBy(['purpose', 'status'])
    .orderBy('purpose')
    .execute();
  for (const r of rows) {
    console.log(
      `  ${r.purpose.padEnd(18)} ${r.status.padEnd(16)} ${r.calls.padStart(5)} calls  ₹${Number(r.inr).toFixed(4)}`,
    );
  }
  console.log(
    'Estimates only (USD list prices × USD_INR_RATE); the authoritative bill is your OpenAI usage page.',
  );
} finally {
  await container.close();
}
