import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const { positionals } = parseArgs({ allowPositionals: true, options: {} });
const [symbol, question] = positionals;
if (!symbol || !question) {
  console.error('Usage: pnpm ai:ask SYMBOL "question"');
  process.exit(2);
}

const container = createContainer(readConfigOrExit(process.env));
try {
  const ai = container.services.ai;
  if (!ai) {
    console.error('LLM_PROVIDER=none: AI features are disabled.');
    process.exitCode = 1;
  } else {
    const r = await ai.qa.ask(symbol, question);
    console.log(`[${container.config.dataMode}] ${r.symbol}${r.cached ? ' (cached)' : ''}`);
    console.log(r.answer.answer);
    console.log('FACTS:');
    for (const f of r.answer.facts) console.log(`  - ${f.statement} [${f.source_ids.join(', ')}]`);
    if (r.answer.interpretation.length > 0) console.log('INTERPRETATION:');
    for (const i of r.answer.interpretation) console.log(`  - ${i}`);
    if (r.answer.insufficient_data.length > 0) console.log('INSUFFICIENT DATA:');
    for (const i of r.answer.insufficient_data) console.log(`  - ${i}`);
    console.log('SOURCES:');
    for (const s of r.sources) console.log(`  [${s.id}] ${s.title}${s.url ? ` ${s.url}` : ''}`);
  }
} finally {
  await container.close();
}
