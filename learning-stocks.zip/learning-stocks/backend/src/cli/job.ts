import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';
import { createRegistry } from '../jobs/registry.js';
import { runJob } from '../jobs/runJob.js';
import { JOB_NAMES, type JobName, type JobPayload, type JobQueue } from '../jobs/types.js';

function usage(message: string): never {
  console.error(
    `${message}\nUsage: pnpm job <name> [--symbols RELIANCE,TCS] [--force] [--origin eod]\n\nJobs:\n${JOB_NAMES.map(
      (n) => `  ${n}`,
    ).join('\n')}`,
  );
  process.exit(2);
}

loadDotEnv();
const { values, positionals } = parseArgs({
  allowPositionals: true,
  options: {
    symbols: { type: 'string' },
    force: { type: 'boolean', default: false },
    origin: { type: 'string' },
  },
});
const name = positionals[0];
if (name === undefined) usage('Which job?');
if (!(JOB_NAMES as readonly string[]).includes(name)) usage(`Unknown job ${name}`);

const symbols = values.symbols
  ?.split(',')
  .map((s) => s.trim())
  .filter(Boolean);
const payload: JobPayload = {
  ...(symbols ? { symbols } : {}),
  ...(values.force ? { force: true } : {}),
  ...(values.origin === undefined ? {} : { origin: values.origin }),
};

const container = createContainer(readConfigOrExit(process.env));
try {
  // A manual run never kicks off a cascade: it prints what the worker would have chained and
  // leaves the decision to the operator. PRD §12's POST /jobs/:name/run will use the same path.
  const chained: string[] = [];
  const dryQueue: JobQueue = {
    start: async () => undefined,
    stop: async () => undefined,
    ensureQueues: async () => undefined,
    applySchedules: async () => undefined,
    work: async () => undefined,
    enqueue: async (next) => {
      chained.push(next);
      return null;
    },
  };
  const outcome = await runJob({
    definition: createRegistry(container)[name as JobName],
    payload,
    queue: dryQueue,
    systemLogs: container.repositories.systemLogs,
    logger: container.logger,
  });
  console.log(`[${container.config.dataMode}] ${name}: ${outcome.status}`);
  console.log(`  ${outcome.message}`);
  if (outcome.runId) console.log(`  system_logs run: ${outcome.runId}`);
  if (chained.length > 0) {
    console.log(`  would chain (not enqueued here): ${chained.join(', ')}`);
    console.log(`  run them yourself with: ${chained.map((c) => `pnpm job ${c}`).join(' && ')}`);
  }
  process.exitCode = outcome.status === 'FAILED' ? 1 : 0;
} finally {
  await container.close();
}
