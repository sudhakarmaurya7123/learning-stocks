import { parseArgs } from 'node:util';
import { loadDotEnv } from '../config/dotenv.js';
import { readConfigOrExit } from '../config/readConfig.js';
import { createContainer } from '../container.js';

loadDotEnv();
const { values, positionals } = parseArgs({
  allowPositionals: true,
  options: { query: { type: 'string' }, 'no-market': { type: 'boolean', default: false } },
});
const symbol = positionals[0];
if (!symbol) {
  console.error('Usage: pnpm rag:context SYMBOL [--query "question"] [--no-market]');
  process.exit(2);
}

const container = createContainer(readConfigOrExit(process.env));
try {
  const service = container.services.stockContext;
  if (!service) {
    console.error('LLM_PROVIDER=none: retrieval is disabled.');
    process.exitCode = 1;
  } else {
    const ctx = await service.build(symbol, {
      ...(values.query ? { query: values.query } : {}),
      includeMarket: !values['no-market'],
    });
    console.log(ctx.text);
    console.log(
      `\ncontext hash ${ctx.contextHash}; ${ctx.documents.length} documents; blocks ${[...ctx.ids].join(' ')}`,
    );
  }
} finally {
  await container.close();
}
