/** One daily close keyed by its IST trading date (YYYY-MM-DD). Series are ascending by date. */
export interface DatedClose {
  date: string;
  close: number;
}

export const round = (x: number, decimals: number): number => {
  const f = 10 ** decimals;
  return Math.round(x * f) / f;
};

export const clampScore = (x: number): number => round(Math.min(100, Math.max(0, x)), 2);

/** Piecewise-linear interpolation through ascending (x, y) points, clamped beyond the ends. */
export function interpolate(x: number, points: ReadonlyArray<readonly [number, number]>): number {
  const first = points[0];
  const last = points[points.length - 1];
  if (!first || !last) throw new RangeError('interpolate needs at least one point');
  if (x <= first[0]) return first[1];
  if (x >= last[0]) return last[1];
  for (let i = 1; i < points.length; i += 1) {
    const a = points[i - 1];
    const b = points[i];
    if (a && b && x <= b[0]) return a[1] + ((x - a[0]) / (b[0] - a[0])) * (b[1] - a[1]);
  }
  return last[1];
}

/** Share of values ≤ x, in percent. */
export function percentileRank(values: readonly number[], x: number): number | null {
  if (values.length === 0) return null;
  return (values.filter((v) => v <= x).length / values.length) * 100;
}

/** Weighted mean of the parts that are present; null when none are. */
export function weightedMean(
  parts: ReadonlyArray<readonly [number | null, number]>,
): number | null {
  let sum = 0;
  let weights = 0;
  for (const [value, weight] of parts) {
    if (value === null || weight <= 0) continue;
    sum += value * weight;
    weights += weight;
  }
  return weights > 0 ? sum / weights : null;
}

export function returnPct(series: readonly DatedClose[], sessionsBack: number): number | null {
  const last = series[series.length - 1];
  const base = series[series.length - 1 - sessionsBack];
  if (!last || !base || base.close <= 0) return null;
  return (last.close / base.close - 1) * 100;
}

/** Return from the close on (or the last one before) fromDate to the latest close. */
export function returnSince(series: readonly DatedClose[], fromDate: string): number | null {
  const last = series[series.length - 1];
  let base: DatedClose | undefined;
  for (const point of series) {
    if (point.date > fromDate) break;
    base = point;
  }
  if (!last || !base || base.close <= 0) return null;
  return (last.close / base.close - 1) * 100;
}

/** Stock return minus index return over the same calendar window (date-aligned). */
export function relativeStrength(
  stock: readonly DatedClose[],
  index: readonly DatedClose[],
  sessionsBack: number,
): number | null {
  const from = stock[stock.length - 1 - sessionsBack];
  if (!from) return null;
  const s = returnSince(stock, from.date);
  const i = returnSince(index, from.date);
  return s === null || i === null ? null : s - i;
}

function commonCloses(a: readonly DatedClose[], b: readonly DatedClose[]): Array<[number, number]> {
  const byDate = new Map(b.map((p) => [p.date, p.close]));
  const out: Array<[number, number]> = [];
  for (const p of a) {
    const other = byDate.get(p.date);
    if (other !== undefined) out.push([p.close, other]);
  }
  return out;
}

const MIN_BETA_RETURNS = 120;

/** Beta of stock vs index from daily returns on dates both series traded. */
export function beta(
  stock: readonly DatedClose[],
  index: readonly DatedClose[],
  sessions = 250,
): number | null {
  const pairs = commonCloses(stock, index).slice(-(sessions + 1));
  const rs: number[] = [];
  const ri: number[] = [];
  for (let k = 1; k < pairs.length; k += 1) {
    const prev = pairs[k - 1];
    const cur = pairs[k];
    if (!prev || !cur || prev[0] <= 0 || prev[1] <= 0) continue;
    rs.push(cur[0] / prev[0] - 1);
    ri.push(cur[1] / prev[1] - 1);
  }
  if (rs.length < MIN_BETA_RETURNS) return null;
  const mean = (xs: number[]) => xs.reduce((s, x) => s + x, 0) / xs.length;
  const ms = mean(rs);
  const mi = mean(ri);
  let cov = 0;
  let varI = 0;
  for (let k = 0; k < rs.length; k += 1) {
    const di = (ri[k] ?? 0) - mi;
    cov += ((rs[k] ?? 0) - ms) * di;
    varI += di * di;
  }
  return varI > 0 ? cov / varI : null;
}

/** Largest peak-to-trough fall, in percent (positive). */
export function maxDrawdownPct(closes: readonly number[]): number | null {
  if (closes.length === 0) return null;
  let peak = closes[0] ?? 0;
  let worst = 0;
  for (const c of closes) {
    peak = Math.max(peak, c);
    if (peak > 0) worst = Math.max(worst, (peak - c) / peak);
  }
  return worst * 100;
}
