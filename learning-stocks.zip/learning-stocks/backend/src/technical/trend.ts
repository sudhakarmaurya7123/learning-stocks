import type { MarketRegime, Trend } from '../domain/enums.js';

/** SMA200 slope = SMA200 now vs this many sessions earlier. */
export const SMA200_SLOPE_LOOKBACK = 20;

export interface TrendInputs {
  close: number | null;
  sma50: number | null;
  sma200: number | null;
  sma200Prev: number | null;
}

/** UPTREND: close > SMA50 > SMA200 with SMA200 rising; DOWNTREND: the mirror; otherwise SIDEWAYS. */
export function classifyTrend(i: TrendInputs): Trend | null {
  const { close, sma50, sma200, sma200Prev } = i;
  if (close === null || sma50 === null || sma200 === null || sma200Prev === null) return null;
  if (close > sma50 && sma50 > sma200 && sma200 > sma200Prev) return 'UPTREND';
  if (close < sma50 && sma50 < sma200 && sma200 < sma200Prev) return 'DOWNTREND';
  return 'SIDEWAYS';
}

export interface RegimeThresholds {
  vixRiskOnMax: number;
  vixRiskOffMin: number;
}

/** Market regime from the NIFTY 50 trend and India VIX. */
export function classifyRegime(
  i: { niftyTrend: Trend | null; vix: number | null },
  t: RegimeThresholds,
): MarketRegime | null {
  if (i.niftyTrend === null && i.vix === null) return null;
  if (i.niftyTrend === 'DOWNTREND' || (i.vix !== null && i.vix >= t.vixRiskOffMin))
    return 'RISK_OFF';
  if (i.niftyTrend === 'UPTREND' && (i.vix === null || i.vix < t.vixRiskOnMax)) return 'RISK_ON';
  return 'NEUTRAL';
}
