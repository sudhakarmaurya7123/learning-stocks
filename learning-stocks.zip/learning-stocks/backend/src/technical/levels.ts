import type { Trend } from '../domain/enums.js';
import { round } from './stats.js';

export const PIVOT_LOOKBACK = 5;
export const LEVEL_WINDOW = 250;
/** A target must clear the entry zone by at least this many ATRs to count as resistance. */
export const MIN_TARGET_GAP_ATR = 1;
/** A swing zone must be tested this often to be a target; structural levels (SMA, 52W) always count. */
export const MIN_TARGET_TOUCHES = 2;
/** Within this many ATRs of the 52-week high, price is at its highs: no overhead supply there. */
export const AT_HIGHS_ATR = 1;
/** stock_evaluations.risk_reward is numeric(8,2). */
export const MAX_RISK_REWARD = 999_999.99;

export interface LevelBar {
  high: number;
  low: number;
  close: number;
}

export interface Zone {
  low: number;
  high: number;
  mid: number;
  touches: number;
  sources: string[];
}

export interface TradeLevels {
  basis: 'SUPPORT' | 'PULLBACK_BAND';
  entryLow: number;
  entryHigh: number;
  stop: number;
  target1: number;
  target2: number;
  riskReward: number;
  positionSizeHint: number;
}

export interface LevelsInput {
  /** Daily bars, oldest first. */
  bars: readonly LevelBar[];
  price: number;
  atr: number | null;
  sma20: number | null;
  sma50: number | null;
  sma200: number | null;
  trend: Trend | null;
  capital: number;
  riskPct: number;
  stopAtrMultiple: number;
  entryAtrWidth: number;
}

export interface LevelsResult {
  supports: Zone[];
  resistances: Zone[];
  trade: TradeLevels | null;
  reason: string | null;
}

/** Strict local extremes with n bars on each side (the last n bars cannot be confirmed yet). */
export function swingPivots(
  bars: readonly LevelBar[],
  n: number,
): { highs: number[]; lows: number[] } {
  const highs: number[] = [];
  const lows: number[] = [];
  for (let i = n; i < bars.length - n; i += 1) {
    const bar = bars[i];
    if (!bar) continue;
    let isHigh = true;
    let isLow = true;
    for (let j = i - n; j <= i + n; j += 1) {
      const other = bars[j];
      if (j === i || !other) continue;
      if (other.high >= bar.high) isHigh = false;
      if (other.low <= bar.low) isLow = false;
    }
    if (isHigh) highs.push(bar.high);
    if (isLow) lows.push(bar.low);
  }
  return { highs, lows };
}

/** Groups sorted levels whose gap to the previous level is within `width`. */
export function clusterZones(
  levels: readonly number[],
  width: number,
  sources: readonly string[] = [],
): Zone[] {
  const tagged = levels.map((price, i) => ({ price, source: sources[i] }));
  tagged.sort((a, b) => a.price - b.price);
  const zones: Zone[] = [];
  let current: { prices: number[]; sources: Set<string> } | null = null;
  const flush = () => {
    if (!current) return;
    const low = Math.min(...current.prices);
    const high = Math.max(...current.prices);
    zones.push({
      low: round(low, 4),
      high: round(high, 4),
      mid: round((low + high) / 2, 4),
      touches: current.prices.length,
      sources: [...current.sources],
    });
  };
  for (const t of tagged) {
    const last = current?.prices[current.prices.length - 1];
    if (current && last !== undefined && t.price - last <= width) {
      current.prices.push(t.price);
    } else {
      flush();
      current = { prices: [t.price], sources: new Set() };
    }
    if (t.source) current.sources.add(t.source);
  }
  flush();
  return zones;
}

const none = (supports: Zone[], resistances: Zone[], reason: string): LevelsResult => ({
  supports,
  resistances,
  trade: null,
  reason,
});

/** PRD §8.4: zones → entry zone, stop, targets, R:R and a position-size hint. */
export function computeLevels(input: LevelsInput): LevelsResult {
  const { atr, price } = input;
  if (atr === null || !(atr > 0)) return none([], [], 'ATR unavailable');
  const window = input.bars.slice(-LEVEL_WINDOW);
  if (window.length < 2 * PIVOT_LOOKBACK + 1)
    return none([], [], 'not enough history for swing levels');

  const pivots = swingPivots(window, PIVOT_LOOKBACK);
  const levels: number[] = [];
  const sources: string[] = [];
  const add = (value: number | null, source: string) => {
    if (value !== null && value > 0) {
      levels.push(value);
      sources.push(source);
    }
  };
  for (const h of pivots.highs) add(h, 'SWING_HIGH');
  for (const l of pivots.lows) add(l, 'SWING_LOW');
  add(input.sma50, 'SMA50');
  add(input.sma200, 'SMA200');
  const high52 = Math.max(...window.map((b) => b.high));
  if (price < high52 - AT_HIGHS_ATR * atr) add(high52, '52W_HIGH');
  add(Math.min(...window.map((b) => b.low)), '52W_LOW');

  const zones = clusterZones(levels, 0.5 * atr, sources);
  const supports = zones.filter((z) => z.mid <= price).sort((a, b) => b.mid - a.mid);
  const resistances = zones.filter((z) => z.mid > price).sort((a, b) => a.low - b.low);

  let basis: TradeLevels['basis'];
  let entryLow: number;
  let entryHigh: number;
  if (input.trend === 'UPTREND' && input.sma20 !== null && input.sma50 !== null) {
    basis = 'PULLBACK_BAND';
    entryLow = Math.min(input.sma20, input.sma50);
    entryHigh = Math.max(input.sma20, input.sma50);
  } else {
    const nearest = supports[0];
    if (!nearest) return none(supports, resistances, 'no support below price');
    basis = 'SUPPORT';
    entryLow = nearest.mid;
    entryHigh = nearest.mid + input.entryAtrWidth * atr;
  }

  const stop = entryLow - input.stopAtrMultiple * atr;
  if (!(entryLow > 0) || !(stop > 0))
    return none(
      supports,
      resistances,
      'stop would be at or below zero (ATR too wide for this price)',
    );
  const mid = (entryLow + entryHigh) / 2;
  const risk = mid - stop;

  const significant = (z: Zone) =>
    z.touches >= MIN_TARGET_TOUCHES || z.sources.some((src) => !src.startsWith('SWING_'));
  const above = resistances.filter(
    (z) => z.low > entryHigh + MIN_TARGET_GAP_ATR * atr && significant(z),
  );
  const t1Zone = above[0];
  const target1 = t1Zone ? t1Zone.low : mid + 2 * risk;
  const t2Zone = above.find((z) => z.low > target1);
  const target2 = t2Zone
    ? t2Zone.low
    : t1Zone
      ? Math.max(mid + 3 * risk, target1 + risk)
      : mid + 3 * risk;
  const riskReward = round((target1 - mid) / risk, 2);
  if (!(riskReward >= 0) || riskReward > MAX_RISK_REWARD)
    return none(supports, resistances, 'risk too small to size a trade');

  const bySize = Math.floor(((input.riskPct / 100) * input.capital) / risk);
  const affordable = Math.floor(input.capital / entryHigh);
  return {
    supports,
    resistances,
    reason: null,
    trade: {
      basis,
      entryLow: round(entryLow, 2),
      entryHigh: round(entryHigh, 2),
      stop: round(stop, 2),
      target1: round(target1, 2),
      target2: round(target2, 2),
      riskReward,
      positionSizeHint: Math.max(0, Math.min(bySize, affordable)),
    },
  };
}
