import {
  ADX,
  ATR,
  BollingerBands,
  EMA,
  MACD,
  RSI,
  SMA,
  StochasticOscillator,
} from 'trading-signals';

export interface OhlcvBar {
  ts: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IndicatorValues {
  sma20: number | null;
  sma50: number | null;
  sma200: number | null;
  ema20: number | null;
  ema50: number | null;
  ema200: number | null;
  rsi14: number | null;
  macd: number | null;
  macdSignal: number | null;
  macdHistogram: number | null;
  bollingerUpper: number | null;
  bollingerMiddle: number | null;
  bollingerLower: number | null;
  atr14: number | null;
  adx14: number | null;
  stochK: number | null;
  stochD: number | null;
  volumeSma20: number | null;
}

/** Classic floor pivots from the previous bar. */
export interface ClassicPivots {
  p: number;
  r1: number;
  s1: number;
  r2: number;
  s2: number;
}

export interface IndicatorPoint {
  ts: Date;
  values: IndicatorValues;
  pivots: ClassicPivots | null;
  /** Session VWAP (intraday only); null for daily bars and zero-volume instruments. */
  vwap: number | null;
}

const r4 = (n: number) => Math.round(n * 10_000) / 10_000;

function pivotsFrom(prev: OhlcvBar): ClassicPivots {
  const p = (prev.high + prev.low + prev.close) / 3;
  const range = prev.high - prev.low;
  return {
    p: r4(p),
    r1: r4(2 * p - prev.low),
    s1: r4(2 * p - prev.high),
    r2: r4(p + range),
    s2: r4(p - range),
  };
}

interface Stable {
  readonly isStable: boolean;
}
const finite = (value: number | null | undefined): number | null =>
  typeof value === 'number' && Number.isFinite(value) ? value : null;
/**
 * trading-signals returns values before an indicator is stable (EMA from bar 0); we never use those.
 * Non-finite values (e.g. NaN from zero-range, circuit-locked bars) become null: Postgres would reject them.
 */
const stable = (indicator: Stable, value: number | null | undefined): number | null =>
  indicator.isStable ? finite(value) : null;

/**
 * PRD §8.1 indicators for every bar (oldest first). An indicator is null until it has enough
 * history — never extrapolated. Verified against textbook and reference values in tests.
 */
export function computeIndicatorSeries(
  bars: readonly OhlcvBar[],
  options: { sessionKey?: (ts: Date) => string } = {},
): IndicatorPoint[] {
  const sma20 = new SMA(20);
  const sma50 = new SMA(50);
  const sma200 = new SMA(200);
  const ema20 = new EMA(20);
  const ema50 = new EMA(50);
  const ema200 = new EMA(200);
  const rsi14 = new RSI(14);
  const macd = new MACD(new EMA(12), new EMA(26), new EMA(9));
  const bollinger = new BollingerBands(20, 2);
  const atr14 = new ATR(14);
  const adx14 = new ADX(14);
  const stoch = new StochasticOscillator({ kPeriod: 14, kSlowingPeriod: 1, dPeriod: 3 });
  const volumeSma20 = new SMA(20);

  let session: string | null = null;
  let cumPv = 0;
  let cumVolume = 0;

  return bars.map((bar, i) => {
    const candle = { high: bar.high, low: bar.low, close: bar.close };
    const m = macd.update(bar.close, false);
    const bb = bollinger.update(bar.close, false);
    const st = stoch.update(candle, false);
    const signalReady = macd.isStable && macd.signal.isStable;
    const values: IndicatorValues = {
      sma20: stable(sma20, sma20.update(bar.close, false)),
      sma50: stable(sma50, sma50.update(bar.close, false)),
      sma200: stable(sma200, sma200.update(bar.close, false)),
      ema20: stable(ema20, ema20.update(bar.close, false)),
      ema50: stable(ema50, ema50.update(bar.close, false)),
      ema200: stable(ema200, ema200.update(bar.close, false)),
      rsi14: stable(rsi14, rsi14.update(bar.close, false)),
      macd: stable(macd, m?.macd),
      macdSignal: signalReady ? finite(m?.signal) : null,
      macdHistogram: signalReady ? finite(m?.histogram) : null,
      bollingerUpper: stable(bollinger, bb?.upper),
      bollingerMiddle: stable(bollinger, bb?.middle),
      bollingerLower: stable(bollinger, bb?.lower),
      atr14: stable(atr14, atr14.update(candle, false)),
      adx14: stable(adx14, adx14.update(candle, false)),
      stochK: stable(stoch, st?.stochK),
      stochD: stable(stoch, st?.stochD),
      volumeSma20: stable(volumeSma20, volumeSma20.update(bar.volume, false)),
    };

    let vwap: number | null = null;
    if (options.sessionKey) {
      const key = options.sessionKey(bar.ts);
      if (key !== session) {
        session = key;
        cumPv = 0;
        cumVolume = 0;
      }
      cumPv += ((bar.high + bar.low + bar.close) / 3) * bar.volume;
      cumVolume += bar.volume;
      vwap = cumVolume > 0 ? r4(cumPv / cumVolume) : null;
    }
    const prev = bars[i - 1];
    return { ts: bar.ts, values, pivots: prev ? pivotsFrom(prev) : null, vwap };
  });
}
