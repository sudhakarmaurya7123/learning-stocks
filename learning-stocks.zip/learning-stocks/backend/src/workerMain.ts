import { loadDotEnv } from './config/dotenv.js';
import { readConfigOrExit } from './config/readConfig.js';
import { createContainer } from './container.js';
import { startWorker } from './worker.js';

// The worker process (PRD §18): one instance, separate from the API. `worker.ts` stays importable
// so tests can start and stop it without a process.
loadDotEnv();
const config = readConfigOrExit(process.env);
const container = createContainer(config);
const worker = await startWorker(container);

let shuttingDown = false;
const shutdown = async (signal: string) => {
  if (shuttingDown) return;
  shuttingDown = true;
  container.logger.info({ signal }, 'stopping worker');
  // Graceful: let in-flight handlers finish rather than orphaning an active job.
  await worker.stop();
  await container.close();
  process.exit(0);
};
process.once('SIGINT', () => void shutdown('SIGINT'));
process.once('SIGTERM', () => void shutdown('SIGTERM'));
