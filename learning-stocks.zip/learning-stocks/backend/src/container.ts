import type { Logger } from 'pino';
import { LlmBudget } from './ai/LlmBudget.js';
import { LlmGateway } from './ai/LlmGateway.js';
import type { AppConfig } from './config/env.js';
import { createDatabase, type Database } from './database/db.js';
import { createProviders, type Providers } from './providers/factory.js';
import type { FundamentalsProvider } from './providers/fundamentals/types.js';
import type { LLMProvider } from './providers/llm/types.js';
import type { MarketDataProvider } from './providers/market/types.js';
import type { NewsProvider } from './providers/news/types.js';
import { Retriever } from './rag/retriever.js';
import { AppSettingsRepository } from './repositories/AppSettingsRepository.js';
import { EmbeddingRepository } from './repositories/EmbeddingRepository.js';
import { EvaluationRepository } from './repositories/EvaluationRepository.js';
import { FundamentalsRepository } from './repositories/FundamentalsRepository.js';
import { HolidayRepository } from './repositories/HolidayRepository.js';
import { LlmCallRepository } from './repositories/LlmCallRepository.js';
import { MarketDataRepository } from './repositories/MarketDataRepository.js';
import { MarketRepository } from './repositories/MarketRepository.js';
import { MarketSummaryRepository } from './repositories/MarketSummaryRepository.js';
import { NewsAnalysisRepository } from './repositories/NewsAnalysisRepository.js';
import { NewsRepository } from './repositories/NewsRepository.js';
import { PaperPositionRepository } from './repositories/PaperPositionRepository.js';
import { ProviderSymbolRepository } from './repositories/ProviderSymbolRepository.js';
import { QaRepository } from './repositories/QaRepository.js';
import { ScoringConfigRepository } from './repositories/ScoringConfigRepository.js';
import { StockAnalysisRepository } from './repositories/StockAnalysisRepository.js';
import { StockRepository } from './repositories/StockRepository.js';
import { SystemLogRepository } from './repositories/SystemLogRepository.js';
import { TechnicalIndicatorRepository } from './repositories/TechnicalIndicatorRepository.js';
import { TradeSignalRepository } from './repositories/TradeSignalRepository.js';
import { UserProfileRepository } from './repositories/UserProfileRepository.js';
import { AIAnalysisService } from './services/ai/AIAnalysisService.js';
import { MarketSummaryService } from './services/ai/MarketSummaryService.js';
import { QAService } from './services/ai/QAService.js';
import { SentimentService } from './services/ai/SentimentService.js';
import { TradeSignalService } from './services/ai/TradeSignalService.js';
import { EvaluationService } from './services/EvaluationService.js';
import { FundamentalsService } from './services/fundamentals/FundamentalsService.js';
import { MarketCalendarService } from './services/MarketCalendarService.js';
import { PgBossQueue, workerLiveness } from './jobs/PgBossQueue.js';
import type { JobQueue } from './jobs/types.js';
import { StockAggregateService } from './services/StockAggregateService.js';
import { SystemHealthService } from './services/SystemHealthService.js';
import { MarketDataService } from './services/marketData/MarketDataService.js';
import { NewsService } from './services/news/NewsService.js';
import { EmbeddingService } from './services/rag/EmbeddingService.js';
import { StockContextService } from './services/rag/StockContextService.js';
import { type Cache, MemoryCache } from './utils/cache.js';
import { createLogger } from './utils/logger.js';

export interface Container {
  config: AppConfig;
  logger: Logger;
  db: Database;
  cache: Cache;
  repositories: {
    stocks: StockRepository;
    markets: MarketRepository;
    holidays: HolidayRepository;
    settings: AppSettingsRepository;
    marketData: MarketDataRepository;
    systemLogs: SystemLogRepository;
    providerSymbols: ProviderSymbolRepository;
    news: NewsRepository;
    fundamentals: FundamentalsRepository;
    scoringConfigs: ScoringConfigRepository;
    technicalIndicators: TechnicalIndicatorRepository;
    evaluations: EvaluationRepository;
    paperPositions: PaperPositionRepository;
    embeddings: EmbeddingRepository;
    llmCalls: LlmCallRepository;
    newsAnalyses: NewsAnalysisRepository;
    stockAnalyses: StockAnalysisRepository;
    marketSummaries: MarketSummaryRepository;
    tradeSignals: TradeSignalRepository;
    qa: QaRepository;
    userProfiles: UserProfileRepository;
  };
  providers: Providers;
  services: {
    calendar: MarketCalendarService;
    /** PRD §12 aggregate. Stored rows only: never calls the LLM (no page load spends). */
    aggregate: StockAggregateService;
    marketData: MarketDataService;
    /** null when NEWS_PROVIDER=none. */
    news: NewsService | null;
    /** null when FUNDAMENTALS_PROVIDER=none. */
    fundamentals: FundamentalsService | null;
    evaluation: EvaluationService;
    /** null when LLM_PROVIDER=none (as are retriever and stockContext). */
    embeddings: EmbeddingService | null;
    retriever: Retriever | null;
    stockContext: StockContextService | null;
    /** Daily ₹ LLM budget (PRD §14). */
    budget: LlmBudget;
    /** PRD §16 status payload. */
    systemHealth: SystemHealthService;
    /**
     * The queue the API enqueues through. Constructed with schedule/supervise off: the worker is
     * the single instance that fires crons (PRD §18). null when no queue is available.
     */
    jobs: JobQueue | null;
    /** null when LLM_PROVIDER=none. Never called on page load: CLIs and jobs only. */
    ai: {
      sentiment: SentimentService;
      analysis: AIAnalysisService;
      marketSummary: MarketSummaryService;
      signals: TradeSignalService;
      qa: QAService;
    } | null;
  };
  close(): Promise<void>;
}

export interface ContainerOverrides {
  logger?: Logger;
  db?: Database;
  cache?: Cache;
  marketDataProvider?: MarketDataProvider;
  newsProvider?: NewsProvider | null;
  fundamentalsProvider?: FundamentalsProvider | null;
  llmProvider?: LLMProvider | null;
  /** A recording fake, so route tests never open a real pg-boss connection. */
  jobQueue?: JobQueue | null;
}

/** Composition root: the only place concrete implementations are chosen. */
export function createContainer(config: AppConfig, overrides: ContainerOverrides = {}): Container {
  const logger = overrides.logger ?? createLogger({ level: config.logLevel });
  // Remember whether we created the pool: destroying a caller's pool (a test transaction, or a
  // shared pool across tests) would leave the next user with a dead driver.
  const ownsDb = overrides.db === undefined;
  const db = overrides.db ?? createDatabase(config.databaseUrl);
  const cache = overrides.cache ?? new MemoryCache();

  const repositories = {
    stocks: new StockRepository(db),
    markets: new MarketRepository(db),
    holidays: new HolidayRepository(db),
    settings: new AppSettingsRepository(db),
    marketData: new MarketDataRepository(db),
    systemLogs: new SystemLogRepository(db),
    providerSymbols: new ProviderSymbolRepository(db),
    news: new NewsRepository(db),
    fundamentals: new FundamentalsRepository(db),
    scoringConfigs: new ScoringConfigRepository(db),
    technicalIndicators: new TechnicalIndicatorRepository(db),
    evaluations: new EvaluationRepository(db),
    paperPositions: new PaperPositionRepository(db),
    embeddings: new EmbeddingRepository(db),
    llmCalls: new LlmCallRepository(db),
    newsAnalyses: new NewsAnalysisRepository(db),
    stockAnalyses: new StockAnalysisRepository(db),
    marketSummaries: new MarketSummaryRepository(db),
    tradeSignals: new TradeSignalRepository(db),
    qa: new QaRepository(db),
    userProfiles: new UserProfileRepository(db),
  };
  const calendar = new MarketCalendarService(repositories.holidays, cache);
  const built = createProviders(config, { sessions: calendar });
  const providers: Providers = {
    marketData: overrides.marketDataProvider ?? built.marketData,
    news: overrides.newsProvider !== undefined ? overrides.newsProvider : built.news,
    fundamentals:
      overrides.fundamentalsProvider !== undefined
        ? overrides.fundamentalsProvider
        : built.fundamentals,
    llm: overrides.llmProvider !== undefined ? overrides.llmProvider : built.llm,
  };
  const budget = new LlmBudget({
    llmCalls: repositories.llmCalls,
    settings: repositories.settings,
    defaultDailyInr: config.llm.dailyBudgetInr,
  });
  const gateway = providers.llm
    ? new LlmGateway({
        provider: providers.llm,
        llmCalls: repositories.llmCalls,
        budget,
        usdInrRate: config.llm.usdInrRate,
        priceOverride: config.llm.priceOverride,
      })
    : null;
  const retriever = providers.llm
    ? new Retriever({
        provider: providers.llm,
        embeddings: repositories.embeddings,
        llmCalls: repositories.llmCalls,
        cache,
        dataMode: config.dataMode,
        usdInrRate: config.llm.usdInrRate,
        budget,
      })
    : null;
  const stockContext = retriever
    ? new StockContextService({
        stocks: repositories.stocks,
        marketData: repositories.marketData,
        evaluations: repositories.evaluations,
        fundamentals: repositories.fundamentals,
        retriever,
        analyses: repositories.stockAnalyses,
        dataMode: config.dataMode,
      })
    : null;
  const shared = { systemLogs: repositories.systemLogs, dataMode: config.dataMode, logger };
  // The API process enqueues and never works a queue: no cron timekeeper, no maintenance.
  const apiQueue =
    overrides.jobQueue !== undefined
      ? overrides.jobQueue
      : new PgBossQueue({
          connectionString: config.databaseUrl,
          schema: config.worker.queueSchema,
          logger,
          tz: config.worker.timezone,
          schedule: false,
          supervise: false,
        });

  return {
    config,
    logger,
    db,
    cache,
    repositories,
    providers,
    services: {
      calendar,
      aggregate: new StockAggregateService({
        stocks: repositories.stocks,
        marketData: repositories.marketData,
        technicalIndicators: repositories.technicalIndicators,
        fundamentals: repositories.fundamentals,
        evaluations: repositories.evaluations,
        news: repositories.news,
        analyses: repositories.stockAnalyses,
        signals: repositories.tradeSignals,
        markets: repositories.markets,
        summaries: repositories.marketSummaries,
        settings: repositories.settings,
        sessions: calendar,
        dataMode: config.dataMode,
        logger,
      }),
      marketData: new MarketDataService({
        provider: providers.marketData,
        providerSymbols: repositories.providerSymbols,
        stocks: repositories.stocks,
        markets: repositories.markets,
        marketData: repositories.marketData,
        systemLogs: repositories.systemLogs,
        sessions: calendar,
        dataMode: config.dataMode,
        logger,
      }),
      news: providers.news
        ? new NewsService({
            provider: providers.news,
            stocks: repositories.stocks,
            markets: repositories.markets,
            news: repositories.news,
            systemLogs: repositories.systemLogs,
            dataMode: config.dataMode,
            logger,
          })
        : null,
      fundamentals: providers.fundamentals
        ? new FundamentalsService({
            provider: providers.fundamentals,
            providerSymbols: repositories.providerSymbols,
            stocks: repositories.stocks,
            fundamentals: repositories.fundamentals,
            systemLogs: repositories.systemLogs,
            dataMode: config.dataMode,
            logger,
          })
        : null,
      evaluation: new EvaluationService({
        stocks: repositories.stocks,
        markets: repositories.markets,
        marketData: repositories.marketData,
        fundamentals: repositories.fundamentals,
        news: repositories.news,
        positions: repositories.paperPositions,
        configs: repositories.scoringConfigs,
        settings: repositories.settings,
        evaluations: repositories.evaluations,
        indicators: repositories.technicalIndicators,
        systemLogs: repositories.systemLogs,
        sessions: calendar,
        dataMode: config.dataMode,
        logger,
      }),
      embeddings: providers.llm
        ? new EmbeddingService({
            provider: providers.llm,
            embeddings: repositories.embeddings,
            llmCalls: repositories.llmCalls,
            stocks: repositories.stocks,
            fundamentals: repositories.fundamentals,
            settings: repositories.settings,
            systemLogs: repositories.systemLogs,
            dataMode: config.dataMode,
            logger,
            usdInrRate: config.llm.usdInrRate,
            budget,
          })
        : null,
      retriever,
      stockContext,
      budget,
      systemHealth: new SystemHealthService({
        config,
        db,
        systemLogs: repositories.systemLogs,
        llmCalls: repositories.llmCalls,
        calendar,
        budget,
        workerLiveness:
          apiQueue instanceof PgBossQueue
            ? () => workerLiveness(apiQueue, config.worker.queueSchema)
            : null,
      }),
      jobs: apiQueue,
      ai:
        gateway && stockContext && retriever
          ? {
              sentiment: new SentimentService({
                ...shared,
                gateway,
                analyses: repositories.newsAnalyses,
                settings: repositories.settings,
              }),
              analysis: new AIAnalysisService({
                ...shared,
                stocks: repositories.stocks,
                evaluations: repositories.evaluations,
                analyses: repositories.stockAnalyses,
                context: stockContext,
                gateway,
                settings: repositories.settings,
              }),
              marketSummary: new MarketSummaryService({
                ...shared,
                markets: repositories.markets,
                stocks: repositories.stocks,
                marketData: repositories.marketData,
                evaluations: repositories.evaluations,
                newsAnalyses: repositories.newsAnalyses,
                summaries: repositories.marketSummaries,
                retriever,
                gateway,
              }),
              signals: new TradeSignalService({
                ...shared,
                stocks: repositories.stocks,
                evaluations: repositories.evaluations,
                analyses: repositories.stockAnalyses,
                signals: repositories.tradeSignals,
                context: stockContext,
                gateway,
                sessions: calendar,
              }),
              qa: new QAService({
                context: stockContext,
                qa: repositories.qa,
                gateway,
                dataMode: config.dataMode,
              }),
            }
          : null,
    },
    close: async () => {
      // Stop the queue we built, or a lazily-started pg-boss pool survives shutdown and the
      // process cannot exit. A caller-supplied queue belongs to the caller.
      if (overrides.jobQueue === undefined && apiQueue !== null) await apiQueue.stop();
      if (ownsDb) await db.destroy();
    },
  };
}
