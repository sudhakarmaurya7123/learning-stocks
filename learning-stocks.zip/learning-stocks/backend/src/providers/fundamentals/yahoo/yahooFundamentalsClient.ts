import type { YahooFinanceInstance } from '../../yahoo/instance.js';

/** Our narrow view of yahoo-finance2 fundamentals. Units exactly as Yahoo sends them (fractions, D/E in %). */
export interface YahooSummary {
  exchange: string | null;
  financialCurrency: string | null;
  marketCap: number | null;
  trailingPE: number | null;
  priceToBook: number | null;
  trailingEps: number | null;
  returnOnEquity: number | null;
  debtToEquity: number | null;
  dividendYield: number | null;
  operatingMargins: number | null;
  profitMargins: number | null;
  freeCashflow: number | null;
  totalRevenue: number | null;
  netIncomeToCommon: number | null;
  revenueGrowth: number | null;
  earningsGrowth: number | null;
  bookValue: number | null;
  beta: number | null;
}

export interface YahooStatementRow {
  date: Date;
  periodType: string | null;
  /** Every finite numeric field of the row (totalRevenue, dilutedEPS, …). */
  values: Record<string, number>;
}

export interface YahooFundamentalsClient {
  summary(symbol: string): Promise<YahooSummary>;
  timeSeries(
    symbol: string,
    type: 'annual' | 'quarterly',
    period1: Date,
  ): Promise<YahooStatementRow[]>;
}

const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

export function createYahooFundamentalsClient(yf: YahooFinanceInstance): YahooFundamentalsClient {
  return {
    async summary(symbol) {
      const q = await yf.quoteSummary(symbol, {
        modules: ['price', 'summaryDetail', 'defaultKeyStatistics', 'financialData'],
      });
      const sd = q.summaryDetail;
      const ks = q.defaultKeyStatistics;
      const fd = q.financialData;
      return {
        exchange: q.price?.exchange ?? null,
        financialCurrency: fd?.financialCurrency ?? null,
        marketCap: num(q.price?.marketCap ?? sd?.marketCap),
        trailingPE: num(sd?.trailingPE),
        priceToBook: num(ks?.priceToBook),
        trailingEps: num(ks?.trailingEps),
        returnOnEquity: num(fd?.returnOnEquity),
        debtToEquity: num(fd?.debtToEquity),
        dividendYield: num(sd?.dividendYield),
        operatingMargins: num(fd?.operatingMargins),
        profitMargins: num(fd?.profitMargins ?? ks?.profitMargins),
        freeCashflow: num(fd?.freeCashflow),
        totalRevenue: num(fd?.totalRevenue),
        netIncomeToCommon: num(ks?.netIncomeToCommon),
        revenueGrowth: num(fd?.revenueGrowth),
        earningsGrowth: num(fd?.earningsGrowth),
        bookValue: num(ks?.bookValue),
        beta: num(sd?.beta ?? ks?.beta),
      };
    },
    async timeSeries(symbol, type, period1) {
      const rows = await yf.fundamentalsTimeSeries(symbol, { period1, type, module: 'all' });
      return rows.map((r) => {
        const record = r as Record<string, unknown>;
        const values: Record<string, number> = {};
        for (const [key, value] of Object.entries(record)) {
          const n = num(value);
          if (n !== null) values[key] = n;
        }
        const date = record.date instanceof Date ? record.date : new Date(String(record.date));
        return {
          date,
          periodType: typeof record.periodType === 'string' ? record.periodType : null,
          values,
        };
      });
    },
  };
}
