import {
  SNAPSHOT_FIELDS,
  type SnapshotMetrics,
  type StatementMetrics,
  type StatementPeriod,
} from '../../../domain/fundamentals.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import {
  assertIndianListing,
  mapYahooError,
  withYahooDeadline,
} from '../../market/yahoo/errors.js';
import type { ProviderInstrumentRef } from '../../market/types.js';
import type {
  FundamentalsCapabilities,
  FundamentalsProvider,
  ProviderFundamentalSnapshot,
  ProviderStatements,
} from '../types.js';
import type { YahooFundamentalsClient, YahooSummary } from './yahooFundamentalsClient.js';

const DAY_MS = 86_400_000;
const DEFAULT_TIMEOUT_MS = 10_000;
const CURRENCY_TTL_MS = 6 * 3_600_000;
const HISTORY_DAYS: Readonly<Record<StatementPeriod, number>> = {
  ANNUAL: 6 * 366,
  QUARTERLY: 3 * 366,
};
const PERIOD_TYPE: Readonly<Record<StatementPeriod, string>> = { ANNUAL: '12M', QUARTERLY: '3M' };
const pct = (v: number | null): number | null => (v === null ? null : v * 100);

/** Unofficial Yahoo Finance fundamentals. Converts to our units (domain/fundamentals.ts); ROCE not provided. */
export class YahooFundamentalsProvider implements FundamentalsProvider {
  readonly name = 'yahoo';
  private readonly currencies = new Map<string, { currency: string | null; at: number }>();
  private readonly timeoutMs: number;

  constructor(
    private readonly client: YahooFundamentalsClient,
    private readonly limiter: RateLimiter,
    private readonly now: () => Date = () => new Date(),
    options: { timeoutMs?: number } = {},
  ) {
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  capabilities(): FundamentalsCapabilities {
    return {
      fields: SNAPSHOT_FIELDS.filter((f) => f !== 'roce'),
      statementPeriods: ['QUARTERLY', 'ANNUAL'],
    };
  }

  async getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot> {
    const s = await this.summary(ref.providerSymbol);
    const metrics: SnapshotMetrics = {
      marketCap: s.marketCap,
      pe: s.trailingPE,
      pb: s.priceToBook,
      epsTtm: s.trailingEps,
      roe: pct(s.returnOnEquity),
      roce: null,
      debtToEquity: s.debtToEquity === null ? null : s.debtToEquity / 100,
      dividendYield: pct(s.dividendYield),
      operatingMargin: pct(s.operatingMargins),
      netMargin: pct(s.profitMargins),
      freeCashFlow: s.freeCashflow,
      revenueTtm: s.totalRevenue,
      netProfitTtm: s.netIncomeToCommon,
      revenueGrowthYoy: pct(s.revenueGrowth),
      profitGrowthYoy: pct(s.earningsGrowth),
      bookValuePerShare: s.bookValue,
      beta: s.beta,
    };
    return { asOf: this.now(), reportingCurrency: s.financialCurrency, metrics, raw: { ...s } };
  }

  async getStatements(
    ref: ProviderInstrumentRef,
    period: StatementPeriod,
  ): Promise<ProviderStatements> {
    const symbol = ref.providerSymbol;
    const reportingCurrency = await this.reportingCurrency(symbol);
    await this.limiter.acquire();
    let rows;
    try {
      rows = await withYahooDeadline(
        this.client.timeSeries(
          symbol,
          period === 'ANNUAL' ? 'annual' : 'quarterly',
          new Date(this.now().getTime() - HISTORY_DAYS[period] * DAY_MS),
        ),
        symbol,
        this.timeoutMs,
      );
    } catch (error) {
      throw mapYahooError(error, symbol);
    }
    const statements = rows
      .filter((r) => r.periodType === PERIOD_TYPE[period])
      .map((r) => {
        const v = r.values;
        const metrics: StatementMetrics = {
          revenue: v.totalRevenue ?? null,
          operatingProfit: v.operatingIncome ?? null,
          netProfit: v.netIncomeCommonStockholders ?? v.netIncome ?? null,
          eps: v.dilutedEPS ?? null,
          totalDebt: v.totalDebt ?? null,
          totalEquity: v.stockholdersEquity ?? null,
          cashFromOperations: v.operatingCashFlow ?? null,
          capex: v.capitalExpenditure ?? null,
        };
        return {
          periodType: period,
          periodEnd: r.date.toISOString().slice(0, 10),
          metrics,
          raw: { ...v },
        };
      })
      .filter((s) => Object.values(s.metrics).some((x) => x !== null));
    return { reportingCurrency, statements };
  }

  private async summary(symbol: string): Promise<YahooSummary> {
    await this.limiter.acquire();
    let s: YahooSummary;
    try {
      s = await withYahooDeadline(this.client.summary(symbol), symbol, this.timeoutMs);
    } catch (error) {
      throw mapYahooError(error, symbol);
    }
    assertIndianListing(s.exchange, symbol);
    this.currencies.set(symbol, { currency: s.financialCurrency, at: this.now().getTime() });
    return s;
  }

  private async reportingCurrency(symbol: string): Promise<string | null> {
    const cached = this.currencies.get(symbol);
    if (cached && this.now().getTime() - cached.at < CURRENCY_TTL_MS) return cached.currency;
    return (await this.summary(symbol)).financialCurrency;
  }
}
