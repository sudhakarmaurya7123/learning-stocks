import type {
  SnapshotField,
  SnapshotMetrics,
  StatementMetrics,
  StatementPeriod,
} from '../../domain/fundamentals.js';
import type { ProviderInstrumentRef } from '../market/types.js';

export interface FundamentalsCapabilities {
  /** Fields the source can supply at all; other fields are always null ("not provided by source"). */
  fields: readonly SnapshotField[];
  statementPeriods: readonly StatementPeriod[];
}

export interface ProviderFundamentalSnapshot {
  asOf: Date;
  /** Currency of the company's financial statements (INFY on Yahoo: USD). Per-share/price fields are in INR. */
  reportingCurrency: string | null;
  metrics: SnapshotMetrics;
  raw: Record<string, unknown>;
}

export interface ProviderStatement {
  periodType: StatementPeriod;
  /** YYYY-MM-DD */
  periodEnd: string;
  metrics: StatementMetrics;
  raw: Record<string, unknown>;
}

export interface ProviderStatements {
  reportingCurrency: string | null;
  statements: ProviderStatement[];
}

/** All fundamentals enter the system through this interface. Units: see domain/fundamentals.ts. */
export interface FundamentalsProvider {
  readonly name: string;
  capabilities(): FundamentalsCapabilities;
  getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot>;
  getStatements(ref: ProviderInstrumentRef, period: StatementPeriod): Promise<ProviderStatements>;
}
