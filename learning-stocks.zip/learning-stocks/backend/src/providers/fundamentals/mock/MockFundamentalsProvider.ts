import {
  SNAPSHOT_FIELDS,
  type SnapshotMetrics,
  type StatementMetrics,
  type StatementPeriod,
} from '../../../domain/fundamentals.js';
import { addDays, toIst } from '../../../utils/ist.js';
import { profileFor } from '../../market/mock/fixtures.js';
import { rngFor } from '../../market/mock/random.js';
import type { ProviderInstrumentRef } from '../../market/types.js';
import type {
  FundamentalsCapabilities,
  FundamentalsProvider,
  ProviderFundamentalSnapshot,
  ProviderStatement,
  ProviderStatements,
} from '../types.js';

const QUARTER_ENDS = ['03-31', '06-30', '09-30', '12-31'] as const;
const QUARTERS = 8;
const YEARS = 5;
const QUARTER_LAG_DAYS = 45;
const ANNUAL_LAG_DAYS = 60;
const ANCHOR_YEAR = 2015;
/** Banks/NBFCs: leverage is their business, so D/E and ROCE are not meaningful (PRD §8.2). */
const FINANCIAL_SECTORS = new Set(['banks', 'financials']);

export type PriceLookup = (ref: ProviderInstrumentRef) => Promise<number | null>;

interface Params {
  financial: boolean;
  shares: number;
  baseRevenue: number;
  growth: number;
  opMargin: number;
  leverage: number;
  equityMultiple: number;
  capexRatio: number;
  dividendYield: number;
  beta: number;
}

function recentQuarterEnds(last: string, count: number): string[] {
  const out: string[] = [];
  for (let y = Number(last.slice(0, 4)); out.length < count; y -= 1) {
    for (const end of [...QUARTER_ENDS].reverse()) {
      const d = `${y}-${end}`;
      if (d <= last && out.length < count) out.push(d);
    }
  }
  return out.reverse();
}

const quarterIndex = (end: string) =>
  (Number(end.slice(0, 4)) - ANCHOR_YEAR) * 4 +
  QUARTER_ENDS.indexOf(end.slice(5) as (typeof QUARTER_ENDS)[number]);

/**
 * MOCK fundamentals: deterministic per symbol, internally consistent (TTM = sum of the last 4 quarters,
 * a fiscal year = its 4 quarters, P/E = price / TTM EPS). Synthetic; stored only with data_mode = MOCK.
 */
export class MockFundamentalsProvider implements FundamentalsProvider {
  readonly name = 'mock';

  constructor(
    private readonly price: PriceLookup = async () => null,
    private readonly now: () => Date = () => new Date(),
  ) {}

  capabilities(): FundamentalsCapabilities {
    return { fields: SNAPSHOT_FIELDS, statementPeriods: ['QUARTERLY', 'ANNUAL'] };
  }

  async getSnapshot(ref: ProviderInstrumentRef): Promise<ProviderFundamentalSnapshot> {
    const symbol = ref.providerSymbol;
    const p = this.params(symbol);
    const quarters = this.quarters(symbol);
    const years = this.years(symbol);
    const last4 = quarters.slice(-4);
    const ttm = (f: keyof StatementMetrics) => last4.reduce((s, q) => s + (q.metrics[f] ?? 0), 0);
    const revenueTtm = ttm('revenue');
    const netProfitTtm = ttm('netProfit');
    const epsTtm = ttm('eps');
    const latest = quarters.at(-1)?.metrics;
    const equity = latest?.totalEquity ?? 0;
    const debt = latest?.totalDebt ?? 0;
    const bookValuePerShare = equity / p.shares;
    const [previous, current] = years.slice(-2);
    const growth = (f: 'revenue' | 'netProfit') => {
      const a = previous?.metrics[f];
      const b = current?.metrics[f];
      return a && b ? (b / a - 1) * 100 : null;
    };
    const price = await this.price(ref);
    const metrics: SnapshotMetrics = {
      marketCap: price === null ? null : price * p.shares,
      pe: price !== null && epsTtm > 0 ? price / epsTtm : null,
      pb: price !== null && bookValuePerShare > 0 ? price / bookValuePerShare : null,
      epsTtm,
      roe: (netProfitTtm / equity) * 100,
      roce: p.financial ? null : (ttm('operatingProfit') / (equity + debt)) * 100,
      debtToEquity: p.financial ? null : debt / equity,
      dividendYield: p.dividendYield,
      operatingMargin: (ttm('operatingProfit') / revenueTtm) * 100,
      netMargin: (netProfitTtm / revenueTtm) * 100,
      freeCashFlow: ttm('cashFromOperations') + ttm('capex'),
      revenueTtm,
      netProfitTtm,
      revenueGrowthYoy: growth('revenue'),
      profitGrowthYoy: growth('netProfit'),
      bookValuePerShare,
      beta: p.beta,
    };
    return { asOf: this.now(), reportingCurrency: 'INR', metrics, raw: { mock: true } };
  }

  async getStatements(
    ref: ProviderInstrumentRef,
    period: StatementPeriod,
  ): Promise<ProviderStatements> {
    const statements =
      period === 'QUARTERLY' ? this.quarters(ref.providerSymbol) : this.years(ref.providerSymbol);
    return { reportingCurrency: 'INR', statements };
  }

  private quarters(symbol: string): ProviderStatement[] {
    const last = addDays(toIst(this.now()).date, -QUARTER_LAG_DAYS);
    return recentQuarterEnds(last, QUARTERS).map((end) => this.quarter(symbol, end));
  }

  private years(symbol: string): ProviderStatement[] {
    const last = addDays(toIst(this.now()).date, -ANNUAL_LAG_DAYS);
    const fyEnds = recentQuarterEnds(last, QUARTERS * 3)
      .filter((d) => d.endsWith('-03-31'))
      .slice(-YEARS);
    return fyEnds.map((fyEnd) => {
      const year = Number(fyEnd.slice(0, 4));
      const qs = [`${year - 1}-06-30`, `${year - 1}-09-30`, `${year - 1}-12-31`, fyEnd].map(
        (e) => this.quarter(symbol, e).metrics,
      );
      const flow = (f: keyof StatementMetrics) => qs.reduce((s, q) => s + (q[f] ?? 0), 0);
      const close = qs[3];
      const metrics: StatementMetrics = {
        revenue: flow('revenue'),
        operatingProfit: flow('operatingProfit'),
        netProfit: flow('netProfit'),
        eps: flow('eps'),
        totalDebt: close?.totalDebt ?? null,
        totalEquity: close?.totalEquity ?? null,
        cashFromOperations: flow('cashFromOperations'),
        capex: flow('capex'),
      };
      return { periodType: 'ANNUAL' as const, periodEnd: fyEnd, metrics, raw: { mock: true } };
    });
  }

  private quarter(symbol: string, end: string): ProviderStatement {
    const p = this.params(symbol);
    const rng = rngFor('fundamentals', symbol, end);
    const scale = (1 + p.growth) ** quarterIndex(end);
    const revenue = p.baseRevenue * scale * (0.96 + 0.08 * rng());
    const operatingProfit = revenue * (p.opMargin + 0.02 * (rng() - 0.5));
    const netProfit = operatingProfit * 0.72;
    const totalEquity = p.baseRevenue * p.equityMultiple * scale;
    const metrics: StatementMetrics = {
      revenue,
      operatingProfit,
      netProfit,
      eps: netProfit / p.shares,
      totalDebt: totalEquity * p.leverage,
      totalEquity,
      cashFromOperations: netProfit * (1.1 + 0.2 * rng()),
      capex: -revenue * p.capexRatio,
    };
    return { periodType: 'QUARTERLY', periodEnd: end, metrics, raw: { mock: true } };
  }

  private params(symbol: string): Params {
    const rng = rngFor('fundamentals-params', symbol);
    const financial = FINANCIAL_SECTORS.has(profileFor(symbol).sector);
    return {
      financial,
      shares: Math.round(5e8 + rng() * 1e10),
      baseRevenue: 5e9 + rng() * 2e11,
      growth: 0.01 + rng() * 0.03,
      opMargin: financial ? 0.3 + 0.1 * rng() : 0.1 + 0.2 * rng(),
      leverage: financial ? 1 : 0.1 + 1.2 * rng(),
      equityMultiple: 2 + 4 * rng(),
      capexRatio: 0.03 + 0.1 * rng(),
      dividendYield: 0.2 + 2.8 * rng(),
      beta: 0.5 + 0.9 * rng(),
    };
  }
}
