import type { BarInterval } from '../../../domain/enums.js';
import type { TradingSession, TradingSessions } from '../../../domain/types.js';
import { AppError } from '../../../utils/errors.js';
import { addDays, isoWeekdayOf, toIst } from '../../../utils/ist.js';
import type {
  MarketDataProvider,
  ProviderBar,
  ProviderCapabilities,
  ProviderInstrumentRef,
  ProviderQuote,
} from '../types.js';
import { MOCK_ANCHOR_DATE, type MockProfile, profileFor } from './fixtures.js';
import { normal, rngFor } from './random.js';

const FIVE_MIN_MS = 300_000;
const MARKET_DRIFT = 0.0003;
const MARKET_VOL = 0.009;
const SECTOR_VOL = 0.006;
const GAP_VOL = 0.003;
const WICK = 0.0007;
const QUOTE_LOOKBACK_DAYS = 10;

interface DayState {
  open: number;
  close: number;
  prevClose: number;
  volume: number;
}

interface Series {
  lastDate: string;
  byDate: Map<string, DayState>;
}

function aggregate(bars: ProviderBar[], ts: Date): ProviderBar {
  const first = bars[0];
  const last = bars[bars.length - 1];
  if (!first || !last) throw new Error('cannot aggregate an empty bar list');
  return {
    ts,
    open: first.open,
    close: last.close,
    high: Math.max(...bars.map((b) => b.high ?? -Infinity)),
    low: Math.min(...bars.map((b) => b.low ?? Infinity)),
    adjustedClose: last.close,
    volume: bars.reduce((sum, b) => sum + (b.volume ?? 0), 0),
  };
}

/**
 * MOCK provider: deterministic, sector-correlated simulation (market + sector + idiosyncratic factors).
 * Prices are synthetic and must only ever be stored with data_mode = MOCK.
 */
export class MockMarketDataProvider implements MarketDataProvider {
  readonly name = 'mock';
  private readonly series = new Map<string, Series>();

  constructor(
    private readonly sessions: TradingSessions,
    private readonly now: () => Date = () => new Date(),
  ) {}

  capabilities(): ProviderCapabilities {
    return {
      exchanges: ['NSE', 'BSE'],
      intervals: ['5m', '15m', '1d'],
      latency: 'realtime',
      maxLookbackDays: {},
    };
  }

  async getHistorical(
    ref: ProviderInstrumentRef,
    from: Date,
    to: Date,
    interval: BarInterval,
  ): Promise<ProviderBar[]> {
    if (interval === '1m') {
      throw new AppError('UNSUPPORTED', 'Mock provider does not generate 1m bars', {
        details: { provider: this.name },
      });
    }
    const now = this.now();
    const end = to < now ? to : now;
    const out: ProviderBar[] = [];
    const startDate = toIst(from).date;
    let date = startDate < MOCK_ANCHOR_DATE ? MOCK_ANCHOR_DATE : startDate;
    const lastDate = toIst(end).date;
    while (date <= lastDate) {
      const session = await this.sessions.sessionOn(ref.exchange, date);
      if (session) {
        const fiveMin = this.intradayBars(ref.providerSymbol, date, session);
        const bars =
          interval === '1d'
            ? [aggregate(fiveMin, session.open)]
            : interval === '15m'
              ? this.group(fiveMin, 3)
              : fiveMin;
        for (const bar of bars) {
          if (bar.ts >= from && bar.ts <= end) out.push(bar);
        }
      }
      date = addDays(date, 1);
    }
    return out;
  }

  async getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote> {
    const now = this.now();
    let date = toIst(now).date;
    for (let i = 0; i < QUOTE_LOOKBACK_DAYS; i += 1) {
      const session = await this.sessions.sessionOn(ref.exchange, date);
      if (session && session.open <= now) {
        const started = this.intradayBars(ref.providerSymbol, date, session).filter(
          (b) => b.ts <= now,
        );
        const last = started[started.length - 1];
        if (last?.close) {
          const asOf = new Date(Math.min(now.getTime(), last.ts.getTime() + FIVE_MIN_MS));
          return {
            price: last.close,
            asOf,
            previousClose: this.dayState(ref.providerSymbol, date).prevClose,
            currency: 'INR',
          };
        }
      }
      date = addDays(date, -1);
    }
    throw new AppError(
      'EMPTY_RESPONSE',
      `No mock session in the last ${QUOTE_LOOKBACK_DAYS} days`,
      { details: { provider: this.name } },
    );
  }

  private group(bars: ProviderBar[], size: number): ProviderBar[] {
    const out: ProviderBar[] = [];
    for (let i = 0; i < bars.length; i += size) {
      const chunk = bars.slice(i, i + size);
      const first = chunk[0];
      if (first) out.push(aggregate(chunk, first.ts));
    }
    return out;
  }

  private intradayBars(symbol: string, date: string, session: TradingSession): ProviderBar[] {
    const profile = profileFor(symbol);
    const day = this.dayState(symbol, date);
    const steps = Math.max(
      1,
      Math.floor((session.close.getTime() - session.open.getTime()) / FIVE_MIN_MS),
    );
    const rng = rngFor('intraday', symbol, date);
    const walk: number[] = [0];
    for (let k = 1; k <= steps; k += 1) walk.push((walk[k - 1] ?? 0) + normal(rng));
    const end = walk[steps] ?? 0;
    const stepVol =
      ((profile.kind === 'volatility' ? 0.02 : Math.max(profile.dailyVol, 0.004)) * 0.6) /
      Math.sqrt(steps);
    const lo = Math.log(day.open);
    const lc = Math.log(day.close);
    // Brownian bridge from the day's open to its close.
    const prices = walk.map((w, k) =>
      Math.exp(lo + (k / steps) * (lc - lo) + (w - (k / steps) * end) * stepVol),
    );
    const weights = Array.from({ length: steps }, (_, k) =>
      steps === 1 ? 1 : 1 + 1.5 * ((2 * k) / (steps - 1) - 1) ** 2,
    );
    const weightSum = weights.reduce((a, b) => a + b, 0);
    return Array.from({ length: steps }, (_, k) => {
      const open = prices[k] ?? day.open;
      const close = prices[k + 1] ?? day.close;
      return {
        ts: new Date(session.open.getTime() + k * FIVE_MIN_MS),
        open,
        close,
        high: Math.max(open, close) * (1 + Math.abs(normal(rng)) * WICK),
        low: Math.min(open, close) * (1 - Math.abs(normal(rng)) * WICK),
        adjustedClose: null,
        volume: Math.round((day.volume * (weights[k] ?? 1)) / weightSum),
      };
    });
  }

  /** Daily state for every calendar day since the anchor (weekends move at 20% scale). Cached per symbol. */
  private dayState(symbol: string, date: string): DayState {
    const profile = profileFor(symbol);
    let series = this.series.get(symbol);
    if (!series) {
      series = { lastDate: addDays(MOCK_ANCHOR_DATE, -1), byDate: new Map() };
      this.series.set(symbol, series);
    }
    while (series.lastDate < date) {
      const next = addDays(series.lastDate, 1);
      const prevClose = series.byDate.get(series.lastDate)?.close ?? profile.base;
      series.byDate.set(next, this.step(symbol, profile, next, prevClose));
      series.lastDate = next;
    }
    const state = series.byDate.get(date);
    if (!state) throw new AppError('INTERNAL', `Mock series has no state for ${symbol} on ${date}`);
    return state;
  }

  private step(symbol: string, p: MockProfile, date: string, prevClose: number): DayState {
    const scale = isoWeekdayOf(date) >= 6 ? 0.2 : 1;
    const market = MARKET_DRIFT + normal(rngFor('market', date)) * MARKET_VOL;
    const sector = normal(rngFor('sector', p.sector, date)) * SECTOR_VOL;
    const idio = normal(rngFor('idio', symbol, date)) * p.dailyVol;
    const gap = normal(rngFor('gap', symbol, date)) * GAP_VOL * scale;
    const close =
      p.kind === 'volatility'
        ? Math.min(
            45,
            Math.max(
              9,
              prevClose +
                0.1 * (p.base - prevClose) -
                250 * market * scale +
                idio * prevClose * scale,
            ),
          )
        : prevClose * Math.exp((p.beta * market + sector + idio) * scale);
    const volume =
      p.avgVolume > 0
        ? Math.round(p.avgVolume * Math.exp(normal(rngFor('volume', symbol, date)) * 0.35) * scale)
        : 0;
    return { open: prevClose * Math.exp(gap), close, prevClose, volume };
  }
}
