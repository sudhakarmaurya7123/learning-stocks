import { hashString } from './random.js';

/**
 * MOCK DATA ONLY: synthetic simulator settings, NOT real prices.
 * `base` is the simulated level on MOCK_ANCHOR_DATE; the walk drifts from there.
 */
export interface MockProfile {
  base: number;
  sector: string;
  beta: number;
  dailyVol: number;
  avgVolume: number;
  kind: 'equity' | 'index' | 'volatility';
}

export const MOCK_ANCHOR_DATE = '2019-01-01';

const eq = (
  base: number,
  sector: string,
  beta: number,
  dailyVol: number,
  avgVolume: number,
): MockProfile => ({ base, sector, beta, dailyVol, avgVolume, kind: 'equity' });
const ix = (base: number, sector: string, beta: number): MockProfile => ({
  base,
  sector,
  beta,
  dailyVol: 0.003,
  avgVolume: 0,
  kind: 'index',
});

export const MOCK_PROFILES: Readonly<Record<string, MockProfile>> = {
  RELIANCE: eq(1100, 'energy', 1.0, 0.014, 9_000_000),
  TCS: eq(1900, 'it', 0.8, 0.013, 2_500_000),
  INFY: eq(700, 'it', 0.9, 0.015, 6_000_000),
  WIPRO: eq(300, 'it', 0.9, 0.016, 8_000_000),
  HCLTECH: eq(1000, 'it', 0.85, 0.015, 3_000_000),
  HDFCBANK: eq(1050, 'banks', 1.0, 0.012, 10_000_000),
  ICICIBANK: eq(360, 'banks', 1.15, 0.016, 14_000_000),
  SBIN: eq(290, 'banks', 1.25, 0.018, 18_000_000),
  AXISBANK: eq(620, 'banks', 1.2, 0.017, 8_000_000),
  KOTAKBANK: eq(1250, 'banks', 1.0, 0.014, 4_000_000),
  BAJFINANCE: eq(2600, 'financials', 1.3, 0.02, 1_500_000),
  BHARTIARTL: eq(320, 'telecom', 0.8, 0.015, 7_000_000),
  ITC: eq(280, 'fmcg', 0.6, 0.012, 15_000_000),
  HINDUNILVR: eq(1800, 'fmcg', 0.55, 0.011, 1_800_000),
  LT: eq(1300, 'infra', 1.1, 0.015, 2_500_000),
  ADANIPORTS: eq(380, 'infra', 1.3, 0.021, 6_000_000),
  MARUTI: eq(7500, 'auto', 0.9, 0.015, 600_000),
  SUNPHARMA: eq(430, 'pharma', 0.7, 0.015, 5_000_000),
  TITAN: eq(950, 'consumer', 1.0, 0.016, 2_000_000),
  ADANIENT: eq(1100, 'metals', 1.4, 0.025, 3_000_000),
  NIFTY50: ix(10800, 'market', 1.0),
  SENSEX: ix(36000, 'market', 1.0),
  BANKNIFTY: ix(27000, 'banks', 1.1),
  NIFTYFINSERVICE: ix(11000, 'financials', 1.15),
  NIFTYIT: ix(14000, 'it', 0.85),
  NIFTYPHARMA: ix(8500, 'pharma', 0.7),
  NIFTYAUTO: ix(7800, 'auto', 0.95),
  NIFTYFMCG: ix(30000, 'fmcg', 0.6),
  NIFTYMETAL: ix(3000, 'metals', 1.3),
  NIFTYREALTY: ix(250, 'realty', 1.4),
  NIFTYENERGY: ix(15000, 'energy', 1.0),
  INDIAVIX: {
    base: 15,
    sector: 'volatility',
    beta: 0,
    dailyVol: 0.05,
    avgVolume: 0,
    kind: 'volatility',
  },
};

/** Profile for a symbol; unknown symbols get a stable synthetic equity profile so new listings work in mock mode. */
export function profileFor(symbol: string): MockProfile {
  const known = MOCK_PROFILES[symbol];
  if (known) return known;
  const h = hashString(symbol);
  return eq(
    100 + (h % 2900),
    'other',
    0.8 + ((h >>> 8) % 60) / 100,
    0.012 + ((h >>> 16) % 10) / 1000,
    500_000 + (h % 5_000_000),
  );
}
