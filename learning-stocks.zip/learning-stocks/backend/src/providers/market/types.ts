import type { BarInterval, Exchange } from '../../domain/enums.js';

export interface ProviderInstrumentRef {
  providerSymbol: string;
  exchange: Exchange;
  kind: 'stock' | 'market';
}

export interface ProviderCapabilities {
  exchanges: readonly Exchange[];
  intervals: readonly BarInterval[];
  latency: 'realtime' | 'delayed' | 'eod';
  /** Oldest data the provider keeps per interval, in days. Absent = unlimited. */
  maxLookbackDays: Partial<Record<BarInterval, number>>;
}

/** A bar exactly as the provider reported it (nulls allowed). The normalizer decides what is stored. */
export interface ProviderBar {
  ts: Date;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  adjustedClose: number | null;
  volume: number | null;
}

export interface ProviderQuote {
  price: number;
  asOf: Date;
  previousClose: number | null;
  currency: string | null;
}

/** All market data enters the system through this interface. Providers never touch the database. */
export interface MarketDataProvider {
  readonly name: string;
  capabilities(): ProviderCapabilities;
  getHistorical(
    ref: ProviderInstrumentRef,
    from: Date,
    to: Date,
    interval: BarInterval,
  ): Promise<ProviderBar[]>;
  getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote>;
}

export const INTERVAL_MS: Readonly<Record<BarInterval, number>> = {
  '1m': 60_000,
  '5m': 300_000,
  '15m': 900_000,
  '1d': 86_400_000,
};
