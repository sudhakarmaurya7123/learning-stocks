import { AppError } from '../../../utils/errors.js';

/** Maps yahoo-finance2 failures onto our taxonomy. Upstream messages are not copied (they can contain URLs). */
export function mapYahooError(error: unknown, symbol: string): AppError {
  if (error instanceof AppError) return error;
  const name = error instanceof Error ? error.name : 'Unknown';
  const message = error instanceof Error ? error.message : String(error);
  const details = { provider: 'yahoo', symbol, upstream: name };
  if (/no data found|delisted|not found/i.test(message)) {
    return new AppError('UNSUPPORTED', `Yahoo has no data for ${symbol}`, { details });
  }
  if (/too many requests|\b429\b/i.test(message)) {
    return new AppError('RATE_LIMITED', `Yahoo rate limit hit for ${symbol}`, { details });
  }
  if (
    name === 'FailedYahooValidationError' ||
    name === 'InvalidOptionsError' ||
    name === 'BadRequestError' ||
    /must be within|not available for/i.test(message)
  ) {
    return new AppError('INVALID_RESPONSE', `Yahoo could not serve the request for ${symbol}`, {
      details,
    });
  }
  if (/timed? ?out|timeout/i.test(message)) {
    return new AppError('TIMEOUT', `Yahoo timed out for ${symbol}`, { details });
  }
  if (/fetch failed|econnreset|econnrefused|enotfound|eai_again|network/i.test(message)) {
    return new AppError('NETWORK', `Network error reaching Yahoo for ${symbol}`, { details });
  }
  if (/unauthorized|forbidden|\b40[13]\b/i.test(message)) {
    return new AppError('AUTH_FAILED', `Yahoo refused the request for ${symbol}`, { details });
  }
  return new AppError('PROVIDER_DOWN', `Yahoo request failed for ${symbol}`, { details });
}

/** Yahoo exchange codes for Indian listings (NSI = NSE). */
const INDIAN_EXCHANGES = new Set(['NSI', 'BSE']);

export function assertIndianListing(exchange: string | null, symbol: string): void {
  if (exchange === null) {
    throw new AppError('INVALID_RESPONSE', `Yahoo did not report an exchange for ${symbol}`, {
      details: { provider: 'yahoo', symbol },
    });
  }
  if (!INDIAN_EXCHANGES.has(exchange)) {
    throw new AppError('UNSUPPORTED', `${symbol} is listed on ${exchange}, not NSE/BSE`, {
      details: { provider: 'yahoo', symbol, exchange },
    });
  }
}

/** PRD §6.4: every provider call is bounded. yahoo-finance2 has no per-call timeout, so race a deadline. */
export function withYahooDeadline<T>(
  work: Promise<T>,
  symbol: string,
  timeoutMs: number,
): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  const deadline = new Promise<never>((_, reject) => {
    timer = setTimeout(
      () =>
        reject(
          new AppError('TIMEOUT', `Yahoo did not answer for ${symbol} within ${timeoutMs} ms`, {
            details: { provider: 'yahoo', symbol, timeoutMs },
          }),
        ),
      timeoutMs,
    );
  });
  return Promise.race([work, deadline]).finally(() => clearTimeout(timer));
}
