import type { BarInterval } from '../../../domain/enums.js';
import { AppError } from '../../../utils/errors.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import type {
  MarketDataProvider,
  ProviderBar,
  ProviderCapabilities,
  ProviderInstrumentRef,
  ProviderQuote,
} from '../types.js';
import { assertIndianListing, mapYahooError, withYahooDeadline } from './errors.js';
import type { YahooClient } from './yahooClient.js';

const DEFAULT_TIMEOUT_MS = 10_000;

/** Unofficial Yahoo Finance data: delayed, best-effort. Rate-limited per call. */
export class YahooMarketDataProvider implements MarketDataProvider {
  readonly name = 'yahoo';

  private readonly timeoutMs: number;

  constructor(
    private readonly client: YahooClient,
    private readonly limiter: RateLimiter,
    options: { timeoutMs?: number } = {},
  ) {
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  private withDeadline<T>(work: Promise<T>, symbol: string): Promise<T> {
    return withYahooDeadline(work, symbol, this.timeoutMs);
  }

  capabilities(): ProviderCapabilities {
    return {
      exchanges: ['NSE', 'BSE'],
      intervals: ['1m', '5m', '15m', '1d'],
      latency: 'delayed',
      maxLookbackDays: { '1m': 7, '5m': 59, '15m': 59 },
    };
  }

  async getHistorical(
    ref: ProviderInstrumentRef,
    from: Date,
    to: Date,
    interval: BarInterval,
  ): Promise<ProviderBar[]> {
    await this.limiter.acquire();
    let chart;
    try {
      chart = await this.withDeadline(
        this.client.chart(ref.providerSymbol, { period1: from, period2: to, interval }),
        ref.providerSymbol,
      );
    } catch (error) {
      throw mapYahooError(error, ref.providerSymbol);
    }
    assertIndianListing(chart.exchangeName, ref.providerSymbol);
    return chart.quotes.map((q) => ({
      ts: q.date,
      open: q.open,
      high: q.high,
      low: q.low,
      close: q.close,
      adjustedClose: q.adjclose,
      volume: q.volume,
    }));
  }

  async getQuote(ref: ProviderInstrumentRef): Promise<ProviderQuote> {
    await this.limiter.acquire();
    let snapshot;
    try {
      snapshot = await this.withDeadline(this.client.quote(ref.providerSymbol), ref.providerSymbol);
    } catch (error) {
      throw mapYahooError(error, ref.providerSymbol);
    }
    assertIndianListing(snapshot.exchange, ref.providerSymbol);
    if (snapshot.price === null || snapshot.time === null) {
      throw new AppError('EMPTY_RESPONSE', `Yahoo returned no price for ${ref.providerSymbol}`, {
        details: { provider: 'yahoo', symbol: ref.providerSymbol },
      });
    }
    return {
      price: snapshot.price,
      asOf: snapshot.time,
      previousClose: snapshot.previousClose,
      currency: snapshot.currency,
    };
  }
}
