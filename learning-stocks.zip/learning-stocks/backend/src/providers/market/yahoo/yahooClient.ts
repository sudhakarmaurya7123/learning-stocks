import { createYahooFinance, type YahooFinanceInstance } from '../../yahoo/instance.js';

/** Our narrow view of yahoo-finance2. The library's own types never leave this file. */
export interface YahooChartQuote {
  date: Date;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  adjclose: number | null;
  volume: number | null;
}

export interface YahooChart {
  exchangeName: string | null;
  currency: string | null;
  quotes: YahooChartQuote[];
}

export interface YahooSnapshot {
  price: number | null;
  time: Date | null;
  previousClose: number | null;
  currency: string | null;
  exchange: string | null;
}

export type YahooInterval = '1m' | '5m' | '15m' | '1d';

export interface YahooClient {
  chart(
    symbol: string,
    options: { period1: Date; period2: Date; interval: YahooInterval },
  ): Promise<YahooChart>;
  quote(symbol: string): Promise<YahooSnapshot>;
}

export function createYahooClient(yf: YahooFinanceInstance = createYahooFinance()): YahooClient {
  return {
    async chart(symbol, options) {
      const result = await yf.chart(symbol, options);
      return {
        exchangeName: result.meta.exchangeName ?? null,
        currency: result.meta.currency ?? null,
        quotes: result.quotes.map((q) => ({
          date: q.date,
          open: q.open ?? null,
          high: q.high ?? null,
          low: q.low ?? null,
          close: q.close ?? null,
          adjclose: q.adjclose ?? null,
          volume: q.volume ?? null,
        })),
      };
    },
    async quote(symbol) {
      const q = await yf.quote(symbol);
      return {
        price: q.regularMarketPrice ?? null,
        time: q.regularMarketTime ?? null,
        previousClose: q.regularMarketPreviousClose ?? null,
        currency: q.currency ?? null,
        exchange: q.exchange ?? null,
      };
    },
  };
}
