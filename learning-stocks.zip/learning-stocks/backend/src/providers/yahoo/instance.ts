import YahooFinance from 'yahoo-finance2';

export type YahooFinanceInstance = InstanceType<typeof YahooFinance>;

/** One instance per process: market and fundamentals adapters share its session (cookie/crumb). */
export function createYahooFinance(): YahooFinanceInstance {
  return new YahooFinance({ suppressNotices: ['yahooSurvey'] });
}
