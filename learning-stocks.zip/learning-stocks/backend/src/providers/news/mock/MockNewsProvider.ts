import { addDays, istToUtc, toIst } from '../../../utils/ist.js';
import { hashString, rngFor } from '../../market/mock/random.js';
import type {
  InstrumentNewsQuery,
  MarketNewsQuery,
  NewsCapabilities,
  NewsFetchResult,
  NewsProvider,
  RawArticle,
} from '../types.js';

const MOCK_HOST = 'https://mock-news.invalid';
const INSTRUMENT_DAILY_PROBABILITY = 0.5;
const MARKET_ARTICLES_PER_DAY = 2;

/** MOCK DATA ONLY: qualitative synthetic headlines. No numbers, no real events. */
const INSTRUMENT_TEMPLATES = [
  'shares gain after an upbeat business update',
  'wins a large new order, says company',
  'rises as brokerages turn more positive',
  'shares slip as margins come under pressure',
  'falls after a regulatory query',
  'declines on cautious demand commentary',
  'to announce quarterly results next week',
  'board to consider fundraising proposal',
  'holds annual general meeting',
] as const;

const MARKET_TEMPLATES = [
  'Sensex and Nifty end higher led by banks',
  'Nifty slips as IT stocks drag',
  'India VIX rises as markets turn cautious',
  'Nifty Bank outperforms as lenders gain',
  'Markets end flat ahead of RBI policy',
  'Sensex falls as metal stocks weaken',
] as const;

const pick = <T>(items: readonly [T, ...T[]], rng: () => number): T =>
  items[Math.floor(rng() * items.length)] ?? items[0];

/** MOCK provider: deterministic per (symbol, IST date); every title starts with "[MOCK]". */
export class MockNewsProvider implements NewsProvider {
  readonly name = 'mock';

  constructor(private readonly now: () => Date = () => new Date()) {}

  capabilities(): NewsCapabilities {
    return { maxInstrumentsPerQuery: 1, latency: 'realtime' };
  }

  async fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult> {
    const out: RawArticle[] = [];
    for (const subject of query.subjects) {
      for (const date of this.dates(query.since)) {
        const rng = rngFor('news', subject.symbol, date);
        if (rng() >= INSTRUMENT_DAILY_PROBABILITY) continue;
        out.push(
          this.article(
            `${subject.name} ${pick(INSTRUMENT_TEMPLATES, rng)}`,
            subject.symbol.toLowerCase(),
            date,
            rng,
          ),
        );
      }
    }
    return { articles: this.window(out, query.since, query.limit), failures: [] };
  }

  async fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult> {
    const out: RawArticle[] = [];
    for (const date of this.dates(query.since)) {
      for (let i = 0; i < MARKET_ARTICLES_PER_DAY; i += 1) {
        const rng = rngFor('market-news', date, String(i));
        out.push(this.article(pick(MARKET_TEMPLATES, rng), 'markets', date, rng));
      }
    }
    return { articles: this.window(out, query.since, query.limit), failures: [] };
  }

  private dates(since: Date): string[] {
    const last = toIst(this.now()).date;
    const out: string[] = [];
    for (let d = toIst(since).date; d <= last; d = addDays(d, 1)) out.push(d);
    return out;
  }

  private article(headline: string, section: string, date: string, rng: () => number): RawArticle {
    const minute = 8 * 60 + Math.floor(rng() * 13 * 60); // 08:00–20:59 IST
    const time = `${String(Math.floor(minute / 60)).padStart(2, '0')}:${String(minute % 60).padStart(2, '0')}`;
    const title = `[MOCK] ${headline}`;
    return {
      title,
      url: `${MOCK_HOST}/${section}/${date}/${hashString(`${title}|${date}`).toString(16)}`,
      description: '[MOCK] Synthetic article generated for testing. It is not real news.',
      content: null,
      author: null,
      publishedAt: istToUtc(date, time),
      publisherUrl: MOCK_HOST,
      language: 'en',
    };
  }

  private window(articles: RawArticle[], since: Date, limit: number): RawArticle[] {
    const now = this.now();
    return articles
      .filter((a) => a.publishedAt !== null && a.publishedAt >= since && a.publishedAt <= now)
      .sort((a, b) => (b.publishedAt?.getTime() ?? 0) - (a.publishedAt?.getTime() ?? 0))
      .slice(0, limit);
  }
}
