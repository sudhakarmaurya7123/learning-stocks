import { z } from 'zod';
import { AppError, isAppError } from '../../../utils/errors.js';
import { type HttpRequest, httpJson } from '../../../utils/http.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import type {
  InstrumentNewsQuery,
  MarketNewsQuery,
  NewsCapabilities,
  NewsFetchResult,
  NewsProvider,
  NewsSubject,
  RawArticle,
} from '../types.js';

const ENDPOINT = 'https://newsapi.org/v2/everything';
const MAX_QUERY_LENGTH = 500;
const MAX_PAGE_SIZE = 100;
const QUOTA_RETRY_AFTER_MS = 3_600_000;
export const NEWSAPI_MARKET_QUERY = 'Sensex OR Nifty';

const ArticleSchema = z.object({
  author: z.string().nullish(),
  title: z.string().nullish(),
  description: z.string().nullish(),
  url: z.string().nullish(),
  publishedAt: z.string().nullish(),
  content: z.string().nullish(),
});
const ResponseSchema = z.discriminatedUnion('status', [
  z.object({ status: z.literal('ok'), articles: z.array(ArticleSchema) }),
  z.object({ status: z.literal('error'), code: z.string(), message: z.string().optional() }),
]);

const AUTH_CODES = new Set(['apiKeyDisabled', 'apiKeyInvalid', 'apiKeyMissing']);

/** On the free tier any rate limit is the daily quota: a long Retry-After makes withRetry fail fast instead of burning requests. */
const quotaError = (details: Record<string, unknown>) =>
  new AppError('RATE_LIMITED', 'NewsAPI rate limit or daily quota reached', {
    details,
    retryAfterMs: QUOTA_RETRY_AFTER_MS,
  });

function errorFor(code: string): AppError {
  const details = { provider: 'newsapi', upstreamCode: code };
  if (AUTH_CODES.has(code))
    return new AppError('AUTH_FAILED', `NewsAPI rejected the API key (${code})`, { details });
  if (code === 'apiKeyExhausted' || code === 'rateLimited') return quotaError(details);
  return new AppError('INVALID_RESPONSE', `NewsAPI error ${code}`, { details });
}

export function buildInstrumentQuery(subjects: readonly NewsSubject[]): string {
  const q = subjects.map((s) => `"${s.name.replace(/"/g, '')}"`).join(' OR ');
  if (q.length > MAX_QUERY_LENGTH) {
    throw new AppError(
      'INTERNAL',
      `NewsAPI query too long (${q.length} > ${MAX_QUERY_LENGTH}); lower maxInstrumentsPerQuery`,
    );
  }
  return q;
}

const TRUNCATION_MARKER = /\s*…?\s*\[\+\d+ chars\]\s*$/;

function toRaw(a: z.infer<typeof ArticleSchema>): RawArticle {
  const ts = a.publishedAt ? Date.parse(a.publishedAt) : Number.NaN;
  return {
    title: a.title ?? null,
    url: a.url ?? null,
    description: a.description ?? null,
    content: a.content ? a.content.replace(TRUNCATION_MARKER, '') : null,
    author: a.author ?? null,
    publishedAt: Number.isNaN(ts) ? null : new Date(ts),
    publisherUrl: null,
    language: 'en',
  };
}

export interface NewsApiProviderOptions {
  fetchJson?: (req: HttpRequest) => Promise<{ data: unknown }>;
}

/** newsapi.org. Free tier: 100 requests/day, articles delayed 24 h, one month of search. Key sent as a header. */
export class NewsApiProvider implements NewsProvider {
  readonly name = 'newsapi';
  private readonly fetchJson: (req: HttpRequest) => Promise<{ data: unknown }>;

  constructor(
    private readonly apiKey: string,
    private readonly limiter: RateLimiter,
    options: NewsApiProviderOptions = {},
  ) {
    this.fetchJson = options.fetchJson ?? httpJson;
  }

  capabilities(): NewsCapabilities {
    return { maxInstrumentsPerQuery: 10, latency: 'delayed' };
  }

  fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult> {
    return this.search(buildInstrumentQuery(query.subjects), query.since, query.limit);
  }

  fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult> {
    return this.search(NEWSAPI_MARKET_QUERY, query.since, query.limit);
  }

  private async search(q: string, since: Date, limit: number): Promise<NewsFetchResult> {
    await this.limiter.acquire();
    const params = new URLSearchParams({
      q,
      searchIn: 'title,description',
      language: 'en',
      sortBy: 'publishedAt',
      from: since.toISOString(),
      pageSize: String(Math.min(Math.max(limit, 1), MAX_PAGE_SIZE)),
    });
    let data: unknown;
    try {
      ({ data } = await this.fetchJson({
        url: `${ENDPOINT}?${params.toString()}`,
        headers: { 'x-api-key': this.apiKey },
      }));
    } catch (error) {
      if (isAppError(error) && error.code === 'RATE_LIMITED')
        throw quotaError({ provider: 'newsapi', status: 429 });
      throw error;
    }
    const parsed = ResponseSchema.safeParse(data);
    if (!parsed.success) {
      throw new AppError('INVALID_RESPONSE', 'NewsAPI returned an unexpected body', {
        details: { provider: 'newsapi' },
      });
    }
    if (parsed.data.status === 'error') throw errorFor(parsed.data.code);
    const articles = parsed.data.articles
      .filter((a) => a.title !== '[Removed]' && a.url !== 'https://removed.com')
      .map(toRaw);
    return { articles, failures: [] };
  }
}
