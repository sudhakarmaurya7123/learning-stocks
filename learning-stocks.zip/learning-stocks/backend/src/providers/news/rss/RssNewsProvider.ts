import { AppError, isAppError, toAppError } from '../../../utils/errors.js';
import { httpRequest } from '../../../utils/http.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import type {
  InstrumentNewsQuery,
  MarketNewsQuery,
  NewsCapabilities,
  NewsFetchResult,
  NewsProvider,
  RawArticle,
  SourceFailure,
} from '../types.js';
import { type FeedItem, parseRssFeed } from './feedParser.js';

export interface RssFeed {
  name: string;
  url: string;
}

/** Live and India-focused as of 2026-10-05. Moneycontrol's feed is excluded: stale since 2024. Personal use only. */
export const DEFAULT_MARKET_FEEDS: readonly RssFeed[] = [
  {
    name: 'Economic Times Markets',
    url: 'https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms',
  },
  { name: 'Mint Markets', url: 'https://www.livemint.com/rss/markets' },
  {
    name: 'Business Standard Markets',
    url: 'https://www.business-standard.com/rss/markets-106.rss',
  },
];

export const RSS_USER_AGENT = 'Mozilla/5.0 (compatible; learning-stocks/1.0; personal research)';
const ACCEPT = 'application/rss+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.1';
const DAY_MS = 86_400_000;
const MAX_SEARCH_DAYS = 30;

export function googleNewsSearchUrl(query: string, days: number): string {
  const params = new URLSearchParams({
    q: `${query} when:${days}d`,
    hl: 'en-IN',
    gl: 'IN',
    ceid: 'IN:en',
  });
  return `https://news.google.com/rss/search?${params.toString()}`;
}

function toRaw(item: FeedItem): RawArticle {
  let title = item.title;
  // Google News appends " - Publisher" to every title; strip it so copies hash alike.
  const suffix = item.sourceName ? ` - ${item.sourceName}` : null;
  if (title && suffix && title.endsWith(suffix)) title = title.slice(0, -suffix.length).trim();
  const ts = item.pubDate ? Date.parse(item.pubDate) : Number.NaN;
  return {
    title,
    url: item.link,
    description: item.description,
    content: null,
    author: item.author,
    publishedAt: Number.isNaN(ts) ? null : new Date(ts),
    publisherUrl: item.sourceUrl,
    language: null,
  };
}

const newest = (articles: RawArticle[], limit: number) =>
  [...articles]
    .sort((a, b) => (b.publishedAt?.getTime() ?? 0) - (a.publishedAt?.getTime() ?? 0))
    .slice(0, limit);

export interface RssNewsProviderOptions {
  fetchText?: (url: string) => Promise<string>;
  marketFeeds?: readonly RssFeed[];
  now?: () => Date;
}

/** Google News search per company + Indian market feeds. Personal, non-commercial use. */
export class RssNewsProvider implements NewsProvider {
  readonly name = 'rss';
  private readonly fetchText: (url: string) => Promise<string>;
  private readonly feeds: readonly RssFeed[];
  private readonly now: () => Date;

  constructor(
    private readonly limiter: RateLimiter,
    options: RssNewsProviderOptions = {},
  ) {
    this.fetchText =
      options.fetchText ??
      (async (url) =>
        (await httpRequest({ url, headers: { accept: ACCEPT, 'user-agent': RSS_USER_AGENT } }))
          .text);
    this.feeds = options.marketFeeds ?? DEFAULT_MARKET_FEEDS;
    this.now = options.now ?? (() => new Date());
  }

  capabilities(): NewsCapabilities {
    return { maxInstrumentsPerQuery: 1, latency: 'realtime' };
  }

  async fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult> {
    const [subject, ...rest] = query.subjects;
    if (!subject || rest.length > 0)
      throw new AppError('INTERNAL', 'RSS search takes exactly one instrument per query');
    const days = Math.min(
      MAX_SEARCH_DAYS,
      Math.max(1, Math.ceil((this.now().getTime() - query.since.getTime()) / DAY_MS)),
    );
    const items = await this.read({
      name: `Google News ${subject.symbol}`,
      url: googleNewsSearchUrl(`"${subject.name}"`, days),
    });
    return { articles: newest(items.map(toRaw), query.limit), failures: [] };
  }

  async fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult> {
    const articles: RawArticle[] = [];
    const failures: SourceFailure[] = [];
    for (const feed of this.feeds) {
      try {
        articles.push(...newest((await this.read(feed)).map(toRaw), query.limit));
      } catch (error) {
        const e = toAppError(error);
        failures.push({ source: feed.name, code: e.code, message: e.message });
      }
    }
    const [first] = failures;
    if (first && failures.length === this.feeds.length) {
      throw new AppError(first.code, `All ${failures.length} market feeds failed`, {
        details: { failures },
      });
    }
    return { articles, failures };
  }

  private async read(feed: RssFeed): Promise<FeedItem[]> {
    await this.limiter.acquire();
    let body: string;
    try {
      body = await this.fetchText(feed.url);
    } catch (error) {
      // Feeds need no key: a 401/403 means the site blocked us, not that a credential is wrong.
      if (isAppError(error) && error.code === 'AUTH_FAILED') {
        throw new AppError('PROVIDER_DOWN', `${feed.name} blocked the request`, {
          details: { feed: feed.name },
        });
      }
      throw error;
    }
    return parseRssFeed(body, feed.name);
  }
}
