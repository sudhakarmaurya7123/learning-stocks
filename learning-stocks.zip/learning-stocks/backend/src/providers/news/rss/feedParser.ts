import { XMLParser } from 'fast-xml-parser';
import { AppError } from '../../../utils/errors.js';

export interface FeedItem {
  title: string | null;
  link: string | null;
  description: string | null;
  pubDate: string | null;
  author: string | null;
  /** Google News <source>: publisher name and home page. */
  sourceName: string | null;
  sourceUrl: string | null;
}

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  // Keep every value a string: a title like "2026" must not become a number.
  parseTagValue: false,
  parseAttributeValue: false,
  trimValues: true,
  processEntities: true,
  htmlEntities: true,
  // A feed with one item must still yield an array.
  isArray: (_name: string, jpath: unknown) => jpath === 'rss.channel.item',
});

type XmlNode = Record<string, unknown>;
const isNode = (v: unknown): v is XmlNode =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

function text(value: unknown): string | null {
  if (typeof value === 'string') return value.trim() === '' ? null : value.trim();
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (isNode(value)) return text(value['#text']);
  return null;
}

const attr = (value: unknown, name: string): string | null =>
  isNode(value) ? text(value[`@_${name}`]) : null;

/** Parses an RSS 2.0 document. Anything else (e.g. an HTML bot-block page) is INVALID_RESPONSE. */
export function parseRssFeed(xml: string, feedName: string): FeedItem[] {
  let doc: unknown;
  try {
    doc = parser.parse(xml);
  } catch (cause) {
    throw new AppError('INVALID_RESPONSE', `${feedName} returned malformed XML`, {
      cause,
      details: { feed: feedName },
    });
  }
  const rss = isNode(doc) ? doc.rss : undefined;
  if (!isNode(rss) || !('channel' in rss)) {
    throw new AppError('INVALID_RESPONSE', `${feedName} did not return an RSS 2.0 feed`, {
      details: { feed: feedName },
    });
  }
  const channel = rss.channel;
  const items = isNode(channel) && Array.isArray(channel.item) ? channel.item : [];
  return items.filter(isNode).map((item) => ({
    title: text(item.title),
    link: text(item.link),
    description: text(item.description),
    pubDate: text(item.pubDate),
    author: text(item.author) ?? text(item['dc:creator']),
    sourceName: text(item.source),
    sourceUrl: attr(item.source, 'url'),
  }));
}
