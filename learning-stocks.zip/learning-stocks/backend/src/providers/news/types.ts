import type { ErrorCode } from '../../utils/errors.js';

/** What a provider needs to search news for one instrument. name = company name without "Limited". */
export interface NewsSubject {
  symbol: string;
  name: string;
  aliases: readonly string[];
}

export interface NewsCapabilities {
  /** Instruments one fetchForInstruments call may cover (NewsAPI batches to save its daily quota). */
  maxInstrumentsPerQuery: number;
  /** Free NewsAPI delays articles by 24 h. */
  latency: 'realtime' | 'delayed';
}

export interface InstrumentNewsQuery {
  subjects: readonly NewsSubject[];
  since: Date;
  limit: number;
}

export interface MarketNewsQuery {
  since: Date;
  limit: number;
}

/** An article exactly as the provider reported it. The normalizer decides what is stored. */
export interface RawArticle {
  title: string | null;
  url: string | null;
  /** May contain HTML. */
  description: string | null;
  content: string | null;
  author: string | null;
  publishedAt: Date | null;
  /** Publisher home page (Google News <source url>); falls back to the article URL's host. */
  publisherUrl: string | null;
  language: string | null;
}

export interface SourceFailure {
  source: string;
  code: ErrorCode;
  message: string;
}

/** Partial results are normal for multi-feed providers: one dead feed must not hide the others. */
export interface NewsFetchResult {
  articles: RawArticle[];
  failures: SourceFailure[];
}

/** All news enters the system through this interface. Providers never touch the database. */
export interface NewsProvider {
  readonly name: string;
  capabilities(): NewsCapabilities;
  fetchForInstruments(query: InstrumentNewsQuery): Promise<NewsFetchResult>;
  fetchMarketNews(query: MarketNewsQuery): Promise<NewsFetchResult>;
}
