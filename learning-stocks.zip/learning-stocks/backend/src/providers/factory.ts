import type { AppConfig } from '../config/env.js';
import type { TradingSessions } from '../domain/types.js';
import { AppError } from '../utils/errors.js';
import { createRateLimiter, type RateLimiter } from '../utils/rateLimiter.js';
import { MockFundamentalsProvider } from './fundamentals/mock/MockFundamentalsProvider.js';
import type { FundamentalsProvider } from './fundamentals/types.js';
import { mockResponders } from '../ai/mockResponders.js';
import { MockLLMProvider } from './llm/mock/MockLLMProvider.js';
import { OpenAIProvider } from './llm/openai/OpenAIProvider.js';
import type { LLMProvider } from './llm/types.js';
import { createYahooFundamentalsClient } from './fundamentals/yahoo/yahooFundamentalsClient.js';
import { YahooFundamentalsProvider } from './fundamentals/yahoo/YahooFundamentalsProvider.js';
import { MockMarketDataProvider } from './market/mock/MockMarketDataProvider.js';
import type { MarketDataProvider } from './market/types.js';
import { createYahooClient } from './market/yahoo/yahooClient.js';
import { YahooMarketDataProvider } from './market/yahoo/YahooMarketDataProvider.js';
import { MockNewsProvider } from './news/mock/MockNewsProvider.js';
import { NewsApiProvider } from './news/newsapi/NewsApiProvider.js';
import { RssNewsProvider } from './news/rss/RssNewsProvider.js';
import type { NewsProvider } from './news/types.js';
import { createYahooFinance, type YahooFinanceInstance } from './yahoo/instance.js';

export interface Providers {
  marketData: MarketDataProvider;
  /** null = feature disabled (NEWS_PROVIDER=none). */
  news: NewsProvider | null;
  fundamentals: FundamentalsProvider | null;
  /** null = AI features disabled (LLM_PROVIDER=none). */
  llm: LLMProvider | null;
}

/** The only place adapters are chosen. Yahoo adapters share one client session and one 2 req/s budget. */
export function createProviders(config: AppConfig, deps: { sessions: TradingSessions }): Providers {
  let yahoo: { yf: YahooFinanceInstance; limiter: RateLimiter } | undefined;
  const sharedYahoo = () =>
    (yahoo ??= {
      yf: createYahooFinance(),
      limiter: createRateLimiter({ ratePerSecond: 2, burst: 2 }),
    });

  let marketData: MarketDataProvider;
  switch (config.providers.marketData) {
    case 'mock':
      marketData = new MockMarketDataProvider(deps.sessions);
      break;
    case 'yahoo':
      marketData = new YahooMarketDataProvider(
        createYahooClient(sharedYahoo().yf),
        sharedYahoo().limiter,
      );
      break;
  }

  let news: NewsProvider | null;
  switch (config.providers.news) {
    case 'mock':
      news = new MockNewsProvider();
      break;
    case 'rss':
      news = new RssNewsProvider(createRateLimiter({ ratePerSecond: 1, burst: 2 }));
      break;
    case 'newsapi': {
      const key = config.secrets.newsApiKey;
      if (!key)
        throw new AppError('INTERNAL', 'NEWS_API_KEY is required for NEWS_PROVIDER=newsapi');
      news = new NewsApiProvider(key, createRateLimiter({ ratePerSecond: 1, burst: 1 }));
      break;
    }
    case 'none':
      news = null;
      break;
  }

  let fundamentals: FundamentalsProvider | null;
  switch (config.providers.fundamentals) {
    case 'mock':
      // Mock P/E and P/B use the mock market price, so MOCK valuation stays internally consistent.
      fundamentals = new MockFundamentalsProvider(async (ref) => {
        try {
          return (await marketData.getQuote(ref)).price;
        } catch {
          return null;
        }
      });
      break;
    case 'yahoo':
      fundamentals = new YahooFundamentalsProvider(
        createYahooFundamentalsClient(sharedYahoo().yf),
        sharedYahoo().limiter,
      );
      break;
    case 'none':
      fundamentals = null;
      break;
  }

  let llm: LLMProvider | null;
  switch (config.providers.llm) {
    case 'mock':
      llm = new MockLLMProvider({ responders: mockResponders() });
      break;
    case 'openai': {
      const key = config.secrets.openaiApiKey;
      if (!key)
        throw new AppError('INTERNAL', 'OPENAI_API_KEY is required for LLM_PROVIDER=openai');
      llm = new OpenAIProvider({
        apiKey: key,
        chatModel: config.llm.model,
        embeddingModel: config.llm.embeddingModel,
        limiter: createRateLimiter({ ratePerSecond: 5, burst: 5 }),
      });
      break;
    }
    case 'none':
      llm = null;
      break;
  }
  return { marketData, news, fundamentals, llm };
}
