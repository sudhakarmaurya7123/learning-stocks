import { z } from 'zod';
import { AppError } from '../../utils/errors.js';

type Json = Record<string, unknown>;
const isObject = (v: unknown): v is Json =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * JSON Schema for OpenAI Structured Outputs (strict): every object closed, every property required.
 * "May be absent" must be modelled as .nullable() so the model answers null explicitly.
 */
export function toStrictJsonSchema(schema: z.ZodType): Json {
  const root = z.toJSONSchema(schema, { io: 'output' }) as Json;
  delete root.$schema;
  const visit = (node: unknown, path: string): void => {
    if (Array.isArray(node)) {
      for (const item of node) visit(item, path);
      return;
    }
    if (!isObject(node)) return;
    if (node.type === 'object') {
      if (!isObject(node.properties)) {
        throw new AppError(
          'INTERNAL',
          `Schema ${path} is an open object (record); strict structured output needs fixed keys`,
        );
      }
      const required = new Set(Array.isArray(node.required) ? node.required : []);
      for (const [key, child] of Object.entries(node.properties)) {
        if (!required.has(key)) {
          throw new AppError(
            'INTERNAL',
            `Schema property ${path}.${key} is optional; use .nullable() for strict structured output`,
          );
        }
        visit(child, `${path}.${key}`);
      }
      node.additionalProperties = false;
    }
    for (const [key, child] of Object.entries(node)) {
      if (key !== 'properties') visit(child, path);
    }
  };
  visit(root, '$');
  return root;
}
