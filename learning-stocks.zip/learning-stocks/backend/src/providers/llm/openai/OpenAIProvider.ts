import { z } from 'zod';
import { AppError, toAppError } from '../../../utils/errors.js';
import { type HttpRequest, httpJson } from '../../../utils/http.js';
import type { RateLimiter } from '../../../utils/rateLimiter.js';
import { toStrictJsonSchema } from '../jsonSchema.js';
import {
  EMBEDDING_DIMENSIONS,
  type EmbeddingResult,
  type LLMProvider,
  type StructuredRequest,
  type StructuredResult,
} from '../types.js';

const BASE_URL = 'https://api.openai.com/v1';
const EMBED_BATCH = 64;
const ERROR_BODY_CHARS = 2000;
const DEFAULT_TIMEOUT_MS = 60_000;

const EmbeddingsResponse = z.object({
  model: z.string(),
  data: z.array(z.object({ index: z.number().int(), embedding: z.array(z.number()) })),
  usage: z.object({ prompt_tokens: z.number().int() }),
});
const ChatResponse = z.object({
  model: z.string(),
  choices: z
    .array(
      z.object({
        finish_reason: z.string().nullable(),
        message: z.object({ content: z.string().nullable(), refusal: z.string().nullish() }),
      }),
    )
    .min(1),
  usage: z.object({ prompt_tokens: z.number().int(), completion_tokens: z.number().int() }),
});

export interface OpenAIProviderOptions {
  apiKey: string;
  chatModel: string | null;
  embeddingModel: string;
  limiter: RateLimiter;
  fetchJson?: (req: HttpRequest) => Promise<{ data: unknown }>;
  timeoutMs?: number;
}

/** Maps transport errors using OpenAI's error body; the body itself never leaves this function. */
export function mapOpenAIError(error: unknown): AppError {
  const e = toAppError(error);
  const body = typeof e.details?.body === 'string' ? e.details.body : null;
  let upstreamCode: string | null = null;
  let upstreamMessage: string | null = null;
  if (body) {
    try {
      const parsed = JSON.parse(body) as {
        error?: { code?: unknown; type?: unknown; message?: unknown };
      };
      const code = parsed.error?.code ?? parsed.error?.type;
      upstreamCode = typeof code === 'string' ? code : null;
      upstreamMessage =
        typeof parsed.error?.message === 'string' ? parsed.error.message.slice(0, 300) : null;
    } catch {
      // not JSON: keep the transport error as is
    }
  }
  const details = { provider: 'openai', status: e.details?.status ?? null, upstreamCode };
  if (upstreamCode === 'insufficient_quota') {
    return new AppError(
      'AUTH_FAILED',
      'OpenAI quota exhausted: add credit or raise the usage limit',
      { details },
    );
  }
  if (e.code === 'INVALID_RESPONSE' && upstreamMessage) {
    return new AppError('INVALID_RESPONSE', `OpenAI rejected the request: ${upstreamMessage}`, {
      details,
    });
  }
  return new AppError(e.code, e.message, {
    details,
    ...(e.retryAfterMs === undefined ? {} : { retryAfterMs: e.retryAfterMs }),
  });
}

const invalid = (message: string, details: Record<string, unknown> = {}) =>
  new AppError('INVALID_RESPONSE', message, { details: { provider: 'openai', ...details } });

/** OpenAI over HTTPS. The key travels only in the authorization header; never in URLs, logs or error details. */
export class OpenAIProvider implements LLMProvider {
  readonly name = 'openai';
  readonly chatModel: string | null;
  readonly embeddingModel: string;
  readonly embeddingDimensions = EMBEDDING_DIMENSIONS;
  private readonly fetchJson: (req: HttpRequest) => Promise<{ data: unknown }>;

  constructor(private readonly options: OpenAIProviderOptions) {
    this.chatModel = options.chatModel;
    this.embeddingModel = options.embeddingModel;
    this.fetchJson = options.fetchJson ?? httpJson;
  }

  async embed(texts: readonly string[]): Promise<EmbeddingResult> {
    const started = Date.now();
    const vectors: number[][] = [];
    let inputTokens = 0;
    let model = this.embeddingModel;
    for (let i = 0; i < texts.length; i += EMBED_BATCH) {
      const batch = texts.slice(i, i + EMBED_BATCH);
      const data = await this.post('/embeddings', {
        model: this.embeddingModel,
        input: batch,
        encoding_format: 'float',
        ...(this.embeddingModel.startsWith('text-embedding-3')
          ? { dimensions: EMBEDDING_DIMENSIONS }
          : {}),
      });
      const parsed = EmbeddingsResponse.safeParse(data);
      if (!parsed.success) throw invalid('Unexpected embeddings response shape');
      const sorted = [...parsed.data.data].sort((a, b) => a.index - b.index);
      if (sorted.length !== batch.length)
        throw invalid(`Expected ${batch.length} embeddings, got ${sorted.length}`);
      for (const item of sorted) {
        if (item.embedding.length !== EMBEDDING_DIMENSIONS) {
          throw invalid(
            `Embedding has ${item.embedding.length} dimensions, expected ${EMBEDDING_DIMENSIONS}`,
          );
        }
        vectors.push(item.embedding);
      }
      inputTokens += parsed.data.usage.prompt_tokens;
      model = parsed.data.model;
    }
    return {
      vectors,
      model,
      usage: { inputTokens, outputTokens: 0 },
      latencyMs: Date.now() - started,
    };
  }

  async completeStructured<T>(req: StructuredRequest<T>): Promise<StructuredResult<T>> {
    const model = req.model ?? this.chatModel;
    if (!model)
      throw new AppError('UNSUPPORTED', 'No chat model configured (LLM_MODEL)', {
        details: { provider: 'openai' },
      });
    const started = Date.now();
    const data = await this.post('/chat/completions', {
      model,
      messages: [
        { role: 'system', content: req.system },
        { role: 'user', content: req.user },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: { name: req.schemaName, strict: true, schema: toStrictJsonSchema(req.schema) },
      },
      ...(req.temperature === undefined ? {} : { temperature: req.temperature }),
      ...(req.maxOutputTokens === undefined ? {} : { max_completion_tokens: req.maxOutputTokens }),
    });
    const parsed = ChatResponse.safeParse(data);
    if (!parsed.success) throw invalid('Unexpected chat completion response shape');
    // Tokens are billed even when the output is unusable: every error below carries usage for llm_calls.
    const usage = {
      inputTokens: parsed.data.usage.prompt_tokens,
      outputTokens: parsed.data.usage.completion_tokens,
    };
    const choice = parsed.data.choices[0];
    const message = choice?.message;
    if (message?.refusal)
      throw invalid('The model refused to answer', {
        refusal: message.refusal.slice(0, 300),
        usage,
      });
    if (choice?.finish_reason === 'length')
      throw invalid('Output truncated (max tokens reached)', {
        raw: (message?.content ?? '').slice(0, 2000),
        usage,
      });
    const content = message?.content ?? null;
    if (content === null || content.trim() === '') {
      throw new AppError('EMPTY_RESPONSE', 'The model returned no content', {
        details: { provider: 'openai', usage },
      });
    }
    let json: unknown;
    try {
      json = JSON.parse(content);
    } catch {
      throw invalid('Model output is not JSON', { raw: content.slice(0, 2000), usage });
    }
    const out = req.schema.safeParse(json);
    if (!out.success) {
      throw invalid(`Model output does not match ${req.schemaName}`, {
        schemaName: req.schemaName,
        issues: out.error.issues.slice(0, 5).map((i) => `${i.path.join('.')}: ${i.message}`),
        raw: content.slice(0, 2000),
        usage,
      });
    }
    return {
      data: out.data,
      model: parsed.data.model,
      usage,
      latencyMs: Date.now() - started,
    };
  }

  private async post(path: string, body: Record<string, unknown>): Promise<unknown> {
    await this.options.limiter.acquire();
    try {
      const res = await this.fetchJson({
        url: `${BASE_URL}${path}`,
        method: 'POST',
        headers: { authorization: `Bearer ${this.options.apiKey}` },
        body,
        timeoutMs: this.options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
        errorBodyChars: ERROR_BODY_CHARS,
      });
      return res.data;
    } catch (error) {
      throw mapOpenAIError(error);
    }
  }
}
