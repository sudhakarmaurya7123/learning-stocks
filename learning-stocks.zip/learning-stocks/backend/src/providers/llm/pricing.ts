import { round } from '../../technical/stats.js';

/**
 * Last known OpenAI list prices, USD per 1M input tokens. NOT verified against the live pricing page:
 * check openai.com/api/pricing and update. Estimates only; the authoritative bill is OpenAI's usage page.
 */
export const EMBEDDING_PRICES_USD_PER_M: Readonly<Record<string, number>> = {
  'text-embedding-3-small': 0.02,
  'text-embedding-3-large': 0.13,
  'text-embedding-ada-002': 0.1,
  // MOCK: free, deterministic
  'mock-hash-embedding-v1': 0,
};

export function embeddingCostInr(model: string, tokens: number, usdInr: number): number | null {
  const usdPerM = EMBEDDING_PRICES_USD_PER_M[model];
  return usdPerM === undefined ? null : round((tokens / 1_000_000) * usdPerM * usdInr, 4);
}

/** USD per 1M tokens. */
export interface ChatPrice {
  input: number;
  output: number;
}

/**
 * Last known OpenAI chat list prices (USD per 1M tokens). NOT verified against the live pricing page:
 * check openai.com/api/pricing; unknown or newer models need LLM_PRICE_INPUT/OUTPUT_USD_PER_M.
 */
export const CHAT_PRICES_USD_PER_M: Readonly<Record<string, ChatPrice>> = {
  'mock-chat-v1': { input: 0, output: 0 }, // MOCK: free, deterministic
  'gpt-5': { input: 1.25, output: 10 },
  'gpt-5-mini': { input: 0.25, output: 2 },
  'gpt-5-nano': { input: 0.05, output: 0.4 },
  'gpt-4.1': { input: 2, output: 8 },
  'gpt-4.1-mini': { input: 0.4, output: 1.6 },
  'gpt-4.1-nano': { input: 0.1, output: 0.4 },
  'gpt-4o': { input: 2.5, output: 10 },
  'gpt-4o-mini': { input: 0.15, output: 0.6 },
};

/** Responses name dated snapshots (gpt-5-mini-2025-08-07): match the longest key that equals or prefixes the model. */
export function chatPrice(model: string, override?: ChatPrice | null): ChatPrice | null {
  if (override) return override;
  let best: string | null = null;
  for (const key of Object.keys(CHAT_PRICES_USD_PER_M)) {
    if (
      (model === key || model.startsWith(`${key}-`)) &&
      (best === null || key.length > best.length)
    )
      best = key;
  }
  return best === null ? null : (CHAT_PRICES_USD_PER_M[best] ?? null);
}

export function chatCostInr(
  model: string,
  inputTokens: number,
  outputTokens: number,
  usdInr: number,
  override?: ChatPrice | null,
): number | null {
  const p = chatPrice(model, override);
  return p === null
    ? null
    : round(((inputTokens * p.input + outputTokens * p.output) / 1_000_000) * usdInr, 4);
}
