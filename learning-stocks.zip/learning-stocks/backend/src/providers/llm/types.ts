import type { z } from 'zod';

/** document_embeddings.embedding is vector(1536); every provider must return exactly this length. */
export const EMBEDDING_DIMENSIONS = 1536;

export interface LlmUsage {
  inputTokens: number;
  outputTokens: number;
}

export interface StructuredRequest<T> {
  system: string;
  user: string;
  schema: z.ZodType<T>;
  /** Stable name of the output contract, e.g. 'stock_analysis'. */
  schemaName: string;
  model?: string;
  temperature?: number;
  maxOutputTokens?: number;
}

export interface StructuredResult<T> {
  data: T;
  model: string;
  usage: LlmUsage;
  latencyMs: number;
}

export interface EmbeddingResult {
  /** One vector per input text, in input order. */
  vectors: number[][];
  model: string;
  usage: LlmUsage;
  latencyMs: number;
}

/** All model access goes through this interface. Business code never imports a vendor adapter. */
export interface LLMProvider {
  readonly name: string;
  /** null when the adapter is configured for embeddings only. */
  readonly chatModel: string | null;
  readonly embeddingModel: string;
  readonly embeddingDimensions: number;
  completeStructured<T>(req: StructuredRequest<T>): Promise<StructuredResult<T>>;
  embed(texts: readonly string[]): Promise<EmbeddingResult>;
}
