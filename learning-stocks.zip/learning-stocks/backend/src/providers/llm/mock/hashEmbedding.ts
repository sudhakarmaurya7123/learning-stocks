import { hashString } from '../../market/mock/random.js';
import { EMBEDDING_DIMENSIONS } from '../types.js';

const STOPWORDS = new Set([
  'the',
  'a',
  'an',
  'and',
  'or',
  'of',
  'to',
  'in',
  'on',
  'for',
  'with',
  'at',
  'by',
  'from',
  'is',
  'are',
  'was',
  'were',
  'be',
  'as',
  'its',
  'it',
  'this',
  'that',
  'has',
  'have',
  'will',
  'after',
  'over',
]);

/** MOCK embedding: signed feature hashing of lower-cased word tokens, L2-normalised. Similarity = word overlap. */
export function hashEmbedding(text: string, dims = EMBEDDING_DIMENSIONS): number[] {
  const v = new Array<number>(dims).fill(0);
  for (const token of text.toLowerCase().match(/[a-z0-9]+/g) ?? []) {
    if (token.length < 2 || STOPWORDS.has(token)) continue;
    const h = hashString(token);
    const i = h % dims;
    v[i] = (v[i] ?? 0) + (h >>> 31 === 1 ? -1 : 1);
  }
  const norm = Math.hypot(...v);
  if (norm === 0) {
    v[0] = 1;
    return v;
  }
  return v.map((x) => x / norm);
}
