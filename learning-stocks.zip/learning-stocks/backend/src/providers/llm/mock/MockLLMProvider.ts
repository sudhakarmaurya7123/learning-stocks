import { AppError } from '../../../utils/errors.js';
import { estimateTokens } from '../../../utils/tokens.js';
import { toStrictJsonSchema } from '../jsonSchema.js';
import {
  EMBEDDING_DIMENSIONS,
  type EmbeddingResult,
  type LLMProvider,
  type StructuredRequest,
  type StructuredResult,
} from '../types.js';
import { hashEmbedding } from './hashEmbedding.js';
import { sampleFromJsonSchema } from './sample.js';

export type MockResponder = (req: { system: string; user: string; schemaName: string }) => unknown;

export interface MockLLMOptions {
  /** Per-schema canned logic (Phase 7 registers analysis responders). Unregistered schemas get a schema-derived sample. */
  responders?: Readonly<Record<string, MockResponder>>;
}

/** MOCK provider: no network, deterministic. Output is validated exactly like a real provider's. */
export class MockLLMProvider implements LLMProvider {
  readonly name = 'mock';
  readonly chatModel = 'mock-chat-v1';
  readonly embeddingModel = 'mock-hash-embedding-v1';
  readonly embeddingDimensions = EMBEDDING_DIMENSIONS;

  constructor(private readonly options: MockLLMOptions = {}) {}

  async completeStructured<T>(req: StructuredRequest<T>): Promise<StructuredResult<T>> {
    const started = Date.now();
    const responder = this.options.responders?.[req.schemaName];
    const raw = responder ? responder(req) : sampleFromJsonSchema(toStrictJsonSchema(req.schema));
    const parsed = req.schema.safeParse(raw);
    if (!parsed.success) {
      throw new AppError(
        'INVALID_RESPONSE',
        `Mock output for ${req.schemaName} does not match its schema`,
        {
          details: {
            provider: this.name,
            schemaName: req.schemaName,
            issues: parsed.error.issues.slice(0, 5).map((i) => `${i.path.join('.')}: ${i.message}`),
            raw: JSON.stringify(raw).slice(0, 2000),
          },
        },
      );
    }
    return {
      data: parsed.data,
      model: this.chatModel,
      usage: {
        inputTokens: estimateTokens(req.system + req.user),
        outputTokens: estimateTokens(JSON.stringify(raw)),
      },
      latencyMs: Date.now() - started,
    };
  }

  async embed(texts: readonly string[]): Promise<EmbeddingResult> {
    const started = Date.now();
    return {
      vectors: texts.map((t) => hashEmbedding(t, this.embeddingDimensions)),
      model: this.embeddingModel,
      usage: { inputTokens: texts.reduce((s, t) => s + estimateTokens(t), 0), outputTokens: 0 },
      latencyMs: Date.now() - started,
    };
  }
}
