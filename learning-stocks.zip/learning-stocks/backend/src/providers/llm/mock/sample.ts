type Json = Record<string, unknown>;
const isObject = (v: unknown): v is Json =>
  typeof v === 'object' && v !== null && !Array.isArray(v);
const num = (v: unknown, fallback: number) => (typeof v === 'number' ? v : fallback);

/** Smallest plausible value satisfying a (strict) JSON Schema: first enum value, 50 clamped to bounds, minItems copies. */
export function sampleFromJsonSchema(node: unknown, defs: Json = {}): unknown {
  if (!isObject(node)) return null;
  const localDefs = isObject(node.$defs) ? { ...defs, ...node.$defs } : defs;
  if ('const' in node) return node.const;
  if (Array.isArray(node.enum)) return node.enum[0] ?? null;
  if (typeof node.$ref === 'string')
    return sampleFromJsonSchema(localDefs[node.$ref.replace('#/$defs/', '')], localDefs);
  const options = Array.isArray(node.anyOf)
    ? node.anyOf
    : Array.isArray(node.oneOf)
      ? node.oneOf
      : null;
  if (options) {
    const nonNull = options.find((o) => !(isObject(o) && o.type === 'null'));
    return sampleFromJsonSchema(nonNull ?? options[0], localDefs);
  }
  // Nullable primitives come as a type array, e.g. ['number', 'null']: sample the non-null type.
  const type = Array.isArray(node.type)
    ? (node.type.find((t) => t !== 'null') ?? 'null')
    : node.type;
  switch (type) {
    case 'object':
      return Object.fromEntries(
        Object.entries(isObject(node.properties) ? node.properties : {}).map(([k, v]) => [
          k,
          sampleFromJsonSchema(v, localDefs),
        ]),
      );
    case 'array':
      return Array.from({ length: num(node.minItems, 0) }, () =>
        sampleFromJsonSchema(node.items, localDefs),
      );
    case 'string':
      return 'MOCK'.padEnd(num(node.minLength, 0), '.');
    case 'integer':
    case 'number':
      return Math.min(num(node.maximum, Infinity), Math.max(num(node.minimum, -Infinity), 50));
    case 'boolean':
      return false;
    default:
      return null;
  }
}
