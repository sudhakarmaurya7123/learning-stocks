import type { BudgetGate } from '../ai/LlmBudget.js';
import type { DataMode } from '../domain/enums.js';
import { embeddingCostInr } from '../providers/llm/pricing.js';
import type { LLMProvider } from '../providers/llm/types.js';
import type {
  EmbeddingRepository,
  MatchedDocument,
  SourceType,
} from '../repositories/EmbeddingRepository.js';
import type { LlmCallRepository } from '../repositories/LlmCallRepository.js';
import type { Cache } from '../utils/cache.js';
import { AppError, toAppError } from '../utils/errors.js';
import { estimateTokens } from '../utils/tokens.js';
import { cosine } from '../utils/vector.js';
import { sha256Hex } from './documents.js';

const DAY_MS = 86_400_000;

/** PRD §10 retrieval settings (financials use a longer window: see Deviation 3). */
export const RETRIEVAL = {
  candidates: 24,
  final: 8,
  mmrLambda: 0.7,
  news: { windowDays: 180, halfLifeDays: 30 },
  financials: { windowDays: 550, halfLifeDays: 365, k: 4 },
  marketK: 8,
  /** Market-level documents allowed in a stock's final results (they must not crowd out its own). */
  marketMax: 2,
  queryCacheTtlMs: 24 * 3_600_000,
} as const;

export interface RankedDocument extends MatchedDocument {
  recency: number;
  relevance: number;
  score: number;
}

export function recencyDecay(publishedAt: Date | null, now: Date, halfLifeDays: number): number {
  if (!publishedAt) return 0.5;
  const ageDays = (now.getTime() - publishedAt.getTime()) / DAY_MS;
  return ageDays <= 0 ? 1 : 0.5 ** (ageDays / halfLifeDays);
}

const halfLife = (t: SourceType) =>
  t === 'FINANCIALS' ? RETRIEVAL.financials.halfLifeDays : RETRIEVAL.news.halfLifeDays;

/** score = similarity × recency × mention relevance (1 when the document has no relevance, e.g. financials). */
export function rerank(docs: readonly MatchedDocument[], now: Date): RankedDocument[] {
  return docs
    .map((d) => {
      const raw = d.metadata.relevance;
      const relevance = typeof raw === 'number' ? Math.min(1, Math.max(0, raw)) : 1;
      const recency = recencyDecay(d.publishedAt, now, halfLife(d.sourceType));
      return { ...d, recency, relevance, score: Math.max(0, d.similarity) * recency * relevance };
    })
    .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
}

/** Maximal marginal relevance: λ·(score / top score) − (1 − λ)·(max cosine to already chosen). */
export function mmr(
  ranked: readonly RankedDocument[],
  vectors: ReadonlyMap<string, readonly number[]>,
  k: number,
  lambda: number = RETRIEVAL.mmrLambda,
): RankedDocument[] {
  const top = ranked[0]?.score ?? 0;
  const pool = [...ranked];
  const chosen: RankedDocument[] = [];
  while (chosen.length < k && pool.length > 0) {
    let bestIndex = 0;
    let bestValue = -Infinity;
    pool.forEach((d, i) => {
      const v = vectors.get(d.id);
      const redundancy = v
        ? Math.max(
            0,
            ...chosen.map((c) => {
              const cv = vectors.get(c.id);
              return cv ? cosine(v, cv) : 0;
            }),
          )
        : 0;
      const value = lambda * (top > 0 ? d.score / top : 0) - (1 - lambda) * redundancy;
      if (value > bestValue) {
        bestValue = value;
        bestIndex = i;
      }
    });
    const [pick] = pool.splice(bestIndex, 1);
    if (pick) chosen.push(pick);
  }
  return chosen;
}

/** One document per (source, text): an article stored for several stocks must not take several slots. */
export function dedupeDocuments(docs: readonly MatchedDocument[]): MatchedDocument[] {
  const best = new Map<string, MatchedDocument>();
  for (const d of docs) {
    const key = `${d.sourceType}|${d.sourceId}|${d.content}`;
    const seen = best.get(key);
    if (!seen || d.similarity > seen.similarity) best.set(key, d);
  }
  return [...best.values()];
}

/**
 * Context order must not depend on the clock: scores decay with time, so order by facts that do not
 * (stock documents first, newest first, then id). Keeps contextHash stable while the data is unchanged.
 */
export function orderForContext(docs: readonly RankedDocument[]): RankedDocument[] {
  const t = (d: RankedDocument) => d.publishedAt?.getTime() ?? 0;
  return [...docs].sort(
    (a, b) =>
      Number(a.stockId === null) - Number(b.stockId === null) ||
      t(b) - t(a) ||
      a.id.localeCompare(b.id),
  );
}

export interface RetrieveRequest {
  query: string;
  /** null = all documents (market-wide question). */
  stockId: string | null;
  /** Add market-level documents (stock_id null) to a stock's results. */
  includeMarket?: boolean;
  /** Default: both. The stock context uses NEWS only (latest results come from the DB as structured blocks). */
  sourceTypes?: readonly ('NEWS' | 'FINANCIALS')[];
  k?: number;
}

export interface RetrieverDeps {
  provider: LLMProvider;
  embeddings: EmbeddingRepository;
  llmCalls: LlmCallRepository;
  cache: Cache;
  dataMode: DataMode;
  usdInrRate: number;
  now?: () => Date;
  /** Daily ₹ budget gate for uncached query embeddings. */
  budget?: BudgetGate;
}

export class Retriever {
  constructor(private readonly deps: RetrieverDeps) {}

  async retrieve(req: RetrieveRequest): Promise<RankedDocument[]> {
    const now = this.deps.now?.() ?? new Date();
    const query = await this.queryVector(req.query);
    const since = (days: number) => new Date(now.getTime() - days * DAY_MS);
    const base = {
      query,
      dataMode: this.deps.dataMode,
      embeddingModel: this.deps.provider.embeddingModel,
    };
    const types = req.sourceTypes ?? ['NEWS', 'FINANCIALS'];
    const searches: Array<Promise<MatchedDocument[]>> = [];
    if (types.includes('NEWS')) {
      searches.push(
        this.deps.embeddings.match({
          ...base,
          stockId: req.stockId,
          since: since(RETRIEVAL.news.windowDays),
          k: RETRIEVAL.candidates,
          sourceTypes: ['NEWS'],
        }),
      );
    }
    if (req.stockId !== null && types.includes('FINANCIALS')) {
      searches.push(
        this.deps.embeddings.match({
          ...base,
          stockId: req.stockId,
          since: since(RETRIEVAL.financials.windowDays),
          k: RETRIEVAL.financials.k,
          sourceTypes: ['FINANCIALS'],
        }),
      );
    }
    if (req.stockId !== null) {
      if (req.includeMarket && types.includes('NEWS')) {
        searches.push(
          this.deps.embeddings.match({
            ...base,
            stockId: null,
            marketOnly: true,
            since: since(RETRIEVAL.news.windowDays),
            k: RETRIEVAL.marketK,
            sourceTypes: ['NEWS'],
          }),
        );
      }
    }
    const merged = new Map<string, MatchedDocument>();
    for (const batch of await Promise.all(searches)) for (const d of batch) merged.set(d.id, d);
    let marketKept = 0;
    const ranked = rerank(dedupeDocuments([...merged.values()]), now)
      .filter((d) => {
        // For a stock, market-level news is context only: keep the best few.
        if (req.stockId === null || d.stockId !== null) return true;
        marketKept += 1;
        return marketKept <= RETRIEVAL.marketMax;
      })
      .slice(0, RETRIEVAL.candidates);
    const vectors = await this.deps.embeddings.vectorsByIds(ranked.map((d) => d.id));
    return orderForContext(mmr(ranked, vectors, req.k ?? RETRIEVAL.final));
  }

  /** Query vectors are cached per (mode, model, text) so repeated questions cost one embedding. */
  private queryVector(text: string): Promise<number[]> {
    const { provider, cache, dataMode } = this.deps;
    const key = `rag:query:${dataMode}:${provider.embeddingModel}:${sha256Hex(text)}`;
    return cache.getOrSet(key, RETRIEVAL.queryCacheTtlMs, async () => {
      try {
        if (this.deps.budget) {
          await this.deps.budget.ensure(
            embeddingCostInr(provider.embeddingModel, estimateTokens(text), this.deps.usdInrRate) ??
              0,
            {
              purpose: 'query_embedding',
              provider: provider.name,
              model: provider.embeddingModel,
              promptVersion: null,
            },
          );
        }
        const res = await provider.embed([text]);
        const v = res.vectors[0];
        if (!v) throw new AppError('EMPTY_RESPONSE', 'No query embedding returned');
        await this.deps.llmCalls.record({
          purpose: 'query_embedding',
          provider: provider.name,
          model: res.model,
          promptVersion: null,
          inputTokens: res.usage.inputTokens,
          outputTokens: 0,
          estCostInr: embeddingCostInr(res.model, res.usage.inputTokens, this.deps.usdInrRate) ?? 0,
          latencyMs: res.latencyMs,
          cacheHit: false,
          status: 'OK',
          error: null,
        });
        return v;
      } catch (error) {
        const e = toAppError(error);
        if (e.code !== 'BUDGET_EXCEEDED') {
          await this.deps.llmCalls.record({
            purpose: 'query_embedding',
            provider: provider.name,
            model: provider.embeddingModel,
            promptVersion: null,
            inputTokens: 0,
            outputTokens: 0,
            estCostInr: 0,
            latencyMs: null,
            cacheHit: false,
            status: 'FAILED',
            error: `${e.code}: ${e.message}`,
          });
        }
        throw e;
      }
    });
  }
}
