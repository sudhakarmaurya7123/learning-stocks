const INLINE_GROUP = /\[([A-Z]\d+(?:\s*,\s*[A-Z]\d+)*)\]/g;
const normalise = (id: string) => id.trim().replace(/^\[/, '').replace(/\]$/, '');

export interface CitedFact {
  statement: string;
  source_ids: readonly string[];
}

export interface CitationReport {
  /** false when any cited ID was never issued by the context builder. */
  valid: boolean;
  unknownIds: string[];
  /** Facts without any citation: flagged, not rejected (PRD §10). */
  uncitedFacts: string[];
}

/** Every ID the model cites must be one the context builder issued; anything else is fabricated. */
export function validateCitations(
  output: { facts: readonly CitedFact[]; texts?: readonly string[] },
  issued: ReadonlySet<string>,
): CitationReport {
  const unknown = new Set<string>();
  const uncited: string[] = [];
  const check = (id: string) => {
    if (!issued.has(id)) unknown.add(id);
  };
  const scan = (text: string) => {
    for (const m of text.matchAll(INLINE_GROUP))
      for (const id of (m[1] ?? '').split(',')) check(id.trim());
  };
  for (const f of output.facts) {
    const ids = f.source_ids.map(normalise).filter((id) => id.length > 0);
    if (ids.length === 0) uncited.push(f.statement);
    ids.forEach(check);
    scan(f.statement);
  }
  for (const t of output.texts ?? []) scan(t);
  return { valid: unknown.size === 0, unknownIds: [...unknown].sort(), uncitedFacts: uncited };
}
