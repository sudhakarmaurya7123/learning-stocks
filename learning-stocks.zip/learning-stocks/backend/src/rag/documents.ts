import { createHash } from 'node:crypto';
import type { StatementMetrics, StatementPeriod } from '../domain/fundamentals.js';
import { ANNUAL_RESULTS_LAG_DAYS, QUARTER_RESULTS_LAG_DAYS } from '../scoring/ValuationEngine.js';
import { formatDate, formatInr, formatInrCrore } from '../utils/format.js';
import { addDays } from '../utils/ist.js';

export const sha256Hex = (text: string): string => createHash('sha256').update(text).digest('hex');

export function newsDocumentText(a: {
  title: string;
  description: string | null;
  content: string | null;
}): string {
  const parts = [a.title.trim()];
  const description = a.description?.trim() ?? '';
  const content = a.content?.trim() ?? '';
  if (content && description && content.startsWith(description)) parts.push(content);
  else {
    if (description) parts.push(description);
    if (content && content !== description) parts.push(content);
  }
  return parts.filter((p) => p.length > 0).join('\n\n');
}

export interface StatementDocInput {
  symbol: string;
  companyName: string;
  periodType: StatementPeriod;
  periodEnd: string;
  source: string;
  metrics: StatementMetrics;
  /** Same period one year earlier (for YoY), when stored. */
  prior: { periodEnd: string; metrics: StatementMetrics } | null;
}

const LINES: ReadonlyArray<{
  key: keyof StatementMetrics;
  label: string;
  money: 'crore' | 'rupees';
}> = [
  { key: 'revenue', label: 'Revenue', money: 'crore' },
  { key: 'operatingProfit', label: 'Operating profit', money: 'crore' },
  { key: 'netProfit', label: 'Net profit', money: 'crore' },
  { key: 'eps', label: 'EPS', money: 'rupees' },
  { key: 'totalDebt', label: 'Total debt', money: 'crore' },
  { key: 'totalEquity', label: 'Total equity', money: 'crore' },
  { key: 'cashFromOperations', label: 'Cash from operations', money: 'crore' },
  { key: 'capex', label: 'Capex', money: 'crore' },
];

/** Deterministic text for one financial statement: numbers verbatim from the DB, nothing inferred. */
export function financialsDocumentText(i: StatementDocInput): string {
  const span =
    i.periodType === 'QUARTERLY'
      ? 'quarterly results for the quarter'
      : 'annual results for the year';
  const out = [
    `${i.symbol} (${i.companyName}): ${span} ended ${formatDate(i.periodEnd)} (source: ${i.source}).`,
  ];
  const missing: string[] = [];
  for (const line of LINES) {
    const value = i.metrics[line.key];
    if (value === null) {
      missing.push(line.label.toLowerCase());
      continue;
    }
    const fmt = (x: number) => (line.money === 'crore' ? formatInrCrore(x) : formatInr(x));
    const base = i.prior?.metrics[line.key] ?? null;
    let text = `${line.label}: ${fmt(value)}`;
    if (base !== null && base > 0) {
      const pct = ((value - base) / base) * 100;
      text += ` (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}% YoY vs ${fmt(base)})`;
    } else if (base !== null) {
      text += ` (vs ${fmt(base)} a year earlier)`;
    }
    out.push(`${text}.`);
  }
  if (missing.length > 0) out.push(`Not reported: ${missing.join(', ')}.`);
  return out.join('\n');
}

/** Results are public only after the reporting lag (same rule as the valuation engine). */
export function statementAvailableOn(periodType: StatementPeriod, periodEnd: string): string {
  return addDays(
    periodEnd,
    periodType === 'QUARTERLY' ? QUARTER_RESULTS_LAG_DAYS : ANNUAL_RESULTS_LAG_DAYS,
  );
}

const YOY_TOLERANCE_DAYS = 20;

/** The statement for the same period one year earlier (±20 days), if stored. */
export function findYearAgo<T extends { periodEnd: string }>(
  rows: readonly T[],
  periodEnd: string,
): T | null {
  const target = Date.parse(`${periodEnd}T00:00:00Z`);
  return (
    rows.find(
      (p) =>
        Math.abs((target - Date.parse(`${p.periodEnd}T00:00:00Z`)) / 86_400_000 - 365) <=
        YOY_TOLERANCE_DAYS,
    ) ?? null
  );
}
