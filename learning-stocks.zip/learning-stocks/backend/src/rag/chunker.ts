import { estimateTokens } from '../utils/tokens.js';

export const CHUNK_MAX_TOKENS = 500;
export const CHUNK_OVERLAP_TOKENS = 50;

export interface ChunkOptions {
  maxTokens?: number;
  overlapTokens?: number;
}

/** Word-boundary windows of ≤ maxTokens (estimated), each starting with ~overlapTokens of the previous window. */
export function chunkText(text: string, options: ChunkOptions = {}): string[] {
  const max = options.maxTokens ?? CHUNK_MAX_TOKENS;
  const overlap = options.overlapTokens ?? CHUNK_OVERLAP_TOKENS;
  if (!(max > 0) || overlap < 0 || overlap >= max)
    throw new RangeError('chunkText needs 0 <= overlapTokens < maxTokens');
  const words = text.split(/\s+/).filter((w) => w.length > 0);
  // Cost of a word plus its joining space.
  const cost = (i: number) => estimateTokens(`${words[i] ?? ''} `);
  const chunks: string[] = [];
  let start = 0;
  while (start < words.length) {
    let end = start;
    let tokens = 0;
    while (end < words.length && (end === start || tokens + cost(end) <= max)) {
      tokens += cost(end);
      end += 1;
    }
    chunks.push(words.slice(start, end).join(' '));
    if (end >= words.length) break;
    let next = end;
    let carried = 0;
    while (next > start + 1 && carried + cost(next - 1) <= overlap) {
      carried += cost(next - 1);
      next -= 1;
    }
    start = next;
  }
  return chunks;
}
