import type { Bar } from '../domain/types.js';

export interface QuoteDto {
  ts: string;
  timeframe: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  /** null = not computed for this bar, which is not the same as zero. */
  change: number | null;
  change_percent: number | null;
  vwap: number | null;
  source: string;
}

export function toQuoteDto(b: Bar): QuoteDto {
  return {
    ts: b.ts.toISOString(),
    timeframe: b.timeframe,
    open: b.open,
    high: b.high,
    low: b.low,
    close: b.close,
    volume: b.volume,
    change: b.change,
    change_percent: b.changePercent,
    vwap: b.vwap,
    source: b.source,
  };
}
