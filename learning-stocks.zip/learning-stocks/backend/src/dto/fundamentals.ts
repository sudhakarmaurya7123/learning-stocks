import {
  type FundamentalSnapshotRecord,
  SNAPSHOT_FIELDS,
  type SnapshotField,
} from '../domain/fundamentals.js';

/** camelCase metric name → the snake_case key it goes out as. */
const snake = (field: string): string => field.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);

export type FundamentalsDto = {
  as_of: string;
  source: string;
} & Record<string, number | null | string>;

/**
 * The latest snapshot, metric by metric.
 *
 * Every field in SNAPSHOT_FIELDS is always present, `null` when the provider did not supply it:
 * null means "unavailable", 0 means "the ratio is zero", and a dropped key renders as undefined
 * and silently blanks a panel. The provider's `raw` blob is deliberately not exposed — it holds
 * whatever the upstream sent and is a debugging aid, not a wire contract.
 */
export function toFundamentalsDto(r: FundamentalSnapshotRecord): FundamentalsDto {
  const metrics: Record<string, number | null> = {};
  for (const field of SNAPSHOT_FIELDS) {
    metrics[snake(field)] = r.metrics[field as SnapshotField];
  }
  return { as_of: r.asOf, source: r.source, ...metrics };
}
