import type { SourceRef } from '../domain/ai.js';

/** A citation as the wire carries it: snake_case, like every other key in the envelope. */
export interface SourceDto {
  id: string;
  url: string | null;
  as_of: string | null;
  kind: string;
  title: string | null;
}

/**
 * Maps a stored citation onto the wire shape.
 *
 * `SourceRef` is persisted as jsonb and uses camelCase `asOf`, so passing the array straight
 * through put one camelCase key inside an otherwise snake_case payload — a bug every consumer
 * inherits, and one the browser cannot parse against the shared contract. Three routes expose
 * citations (the aggregate, /analysis and /qa), so the mapping lives here rather than being
 * repeated and drifting.
 */
export const toSourceDto = (s: SourceRef): SourceDto => ({
  id: s.id,
  url: s.url ?? null,
  as_of: s.asOf ?? null,
  kind: s.kind,
  title: s.title ?? null,
});

export const toSourceDtos = (sources: readonly SourceRef[]): SourceDto[] =>
  sources.map(toSourceDto);
