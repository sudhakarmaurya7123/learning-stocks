import type { Stock } from '../domain/types.js';

/**
 * A stock as the wire sees it: snake_case, no internal id.
 *
 * The public identifier is the symbol. Exposing the row uuid invites it into URLs and bookmarks,
 * and then it cannot be changed.
 */
export interface StockDto {
  symbol: string;
  company_name: string;
  exchange: string;
  isin: string | null;
  isin_verified: boolean;
  sector: string | null;
  industry: string | null;
  market_cap: number | null;
  currency: string;
}

export function toStockDto(s: Stock): StockDto {
  return {
    symbol: s.symbol,
    company_name: s.companyName,
    exchange: s.exchange,
    isin: s.isin,
    isin_verified: s.isinVerified,
    sector: s.sector,
    industry: s.industry,
    market_cap: s.marketCap,
    currency: s.currency,
  };
}
