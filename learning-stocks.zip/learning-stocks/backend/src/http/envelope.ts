import type { DataMode } from '../domain/enums.js';
import type { ErrorCode } from '../utils/errors.js';

export interface Freshness {
  as_of: string | null;
  age_seconds: number | null;
  stale: boolean;
  market_open: boolean;
  /** Which threshold judged `stale`, so the UI can explain a badge rather than only colour it. */
  cadence: Cadence;
}

/**
 * Which kind of fact is being judged.
 *
 * `quote` ages in minutes against `app_settings.quote_staleness_minutes`. `daily` cannot be judged
 * by a duration at all: daily bars are written only after the close plus a settle, so mid-session
 * the newest one is the previous session's — over 24h old at today's open and 72h old on a Monday.
 * Judging it on the quote threshold made every indicator, evaluation and fundamentals panel read
 * "stale" from 09:35 onward while being perfectly current (Phase 9 finding I4).
 */
export type Cadence = 'quote' | 'daily';

export interface FreshnessOptions {
  now: Date;
  marketOpen: boolean;
  /** app_settings.quote_staleness_minutes (PRD §11); the threshold for `cadence: 'quote'`. */
  stalenessMinutes: number;
  /** Defaults to 'quote', so every pre-existing caller keeps its behaviour. */
  cadence?: Cadence;
  /**
   * The open of the most recent completed session, from MarketCalendarService.
   *
   * Optional: a caller that cannot resolve it (a CLI, or a calendar read that degraded) falls back
   * to the quote threshold rather than throwing. A freshness badge must never be the reason a page
   * fails.
   */
  lastCompleteSessionOpen?: Date;
}

/**
 * How old the newest stored fact is, and whether that is a problem.
 *
 * `stale` is only ever true while the market is open: Friday's close on a Sunday is not stale, it
 * is final, and flagging it would make every weekend look like an outage.
 */
export function freshness(asOf: Date | null, o: FreshnessOptions): Freshness {
  const cadence: Cadence = o.cadence ?? 'quote';
  if (asOf === null) {
    return { as_of: null, age_seconds: null, stale: true, market_open: o.marketOpen, cadence };
  }
  const ageSeconds = Math.max(0, Math.round((o.now.getTime() - asOf.getTime()) / 1000));
  const overdue =
    cadence === 'daily' && o.lastCompleteSessionOpen !== undefined
      ? // A daily fact is current iff it covers the most recent completed session.
        asOf.getTime() < o.lastCompleteSessionOpen.getTime()
      : ageSeconds > o.stalenessMinutes * 60;
  return {
    as_of: asOf.toISOString(),
    age_seconds: ageSeconds,
    stale: o.marketOpen && overdue,
    market_open: o.marketOpen,
    cadence,
  };
}

export interface Meta {
  data_mode: DataMode;
  generated_at: string;
  /** How old the newest stored fact behind this response is (PRD §12). */
  freshness?: Freshness;
}

export function meta(dataMode: DataMode, now: Date = new Date(), f?: Freshness): Meta {
  // Spread rather than assign: exactOptionalPropertyTypes forbids an explicit undefined here.
  return {
    data_mode: dataMode,
    generated_at: now.toISOString(),
    ...(f === undefined ? {} : { freshness: f }),
  };
}

export function ok<T>(data: T, m: Meta): { data: T; meta: Meta } {
  return { data, meta: m };
}

export function errorBody(code: ErrorCode, message: string, details?: Record<string, unknown>) {
  return { error: details ? { code, message, details } : { code, message } };
}
