import { createRemoteJWKSet, jwtVerify } from 'jose';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import type { Logger } from 'pino';
import type { AppConfig } from '../config/env.js';
import type { UserRole } from '../domain/enums.js';
import type { UserProfileRepository } from '../repositories/UserProfileRepository.js';
import type { Cache } from '../utils/cache.js';
import { AppError } from '../utils/errors.js';

/** Supabase signs access tokens HS256 with the project secret; the cloud path is JWKS. */
const ALGORITHMS = ['HS256', 'RS256', 'ES256'] as const;
const ROLE_CACHE_MS = 30_000;
const ADMIN_ROLES: ReadonlySet<UserRole> = new Set<UserRole>(['OWNER', 'ADMIN']);

/** The synthetic user AUTH_MODE=none answers as. Not a real auth.users id by design. */
export const DEV_USER_ID = '00000000-0000-0000-0000-0000000000de';

export interface AuthenticatedUser {
  id: string;
  role: UserRole;
  email: string | null;
}

declare module 'fastify' {
  interface FastifyRequest {
    user?: AuthenticatedUser;
  }
}

export interface VerifyOptions {
  secret: string | null;
  jwksUrl: string | null;
  issuer: string | null;
  audience: string;
}

export type JwtKey = Uint8Array | ReturnType<typeof createRemoteJWKSet>;

export function keyFor(o: VerifyOptions): JwtKey {
  // The secret wins when both are set: a local HS256 token cannot verify against JWKS, and the
  // local Supabase stack signs with the secret.
  if (o.secret !== null) return new TextEncoder().encode(o.secret);
  if (o.jwksUrl !== null) return createRemoteJWKSet(new URL(o.jwksUrl));
  throw new AppError('INTERNAL', 'No JWT verification material configured');
}

export async function verifyToken(
  token: string,
  o: VerifyOptions,
  /**
   * A key built once by the caller.
   *
   * jose's createRemoteJWKSet keeps its cache in closure state, so constructing a fresh one per
   * request discards the JWKS cache and issues an outbound fetch on every authenticated call —
   * and because auth throws before the rate limiter, forged tokens could drive that loop
   * unthrottled. registerAuth builds it once; this default keeps the function usable on its own.
   */
  key: JwtKey = keyFor(o),
): Promise<{ sub: string; email: string | null }> {
  try {
    const { payload } = await jwtVerify(token, key, {
      // Pinning the algorithms is what defeats the `alg: none` confusion attack.
      algorithms: [...ALGORITHMS],
      audience: o.audience,
      // Pinning the issuer stops a token minted by another project being accepted.
      ...(o.issuer === null ? {} : { issuer: o.issuer }),
    });
    if (typeof payload.sub !== 'string' || payload.sub === '') {
      throw new AppError('UNAUTHORIZED', 'Token has no subject');
    }
    return { sub: payload.sub, email: typeof payload.email === 'string' ? payload.email : null };
  } catch (error) {
    if (error instanceof AppError) throw error;
    // No details: errorBody serializes them, so `{reason: 'JWTExpired'}` versus
    // `{reason: 'JWSSignatureVerificationFailed'}` would tell an attacker whether a forged
    // signature was the only thing wrong. The reason goes to the log, not the response.
    throw new AppError('UNAUTHORIZED', 'Invalid or expired token');
  }
}

/** Throws unless the request's user may run admin actions (PRD §12's † routes). */
export function requireAdmin(request: FastifyRequest): AuthenticatedUser {
  const user = request.user;
  if (!user) throw new AppError('UNAUTHORIZED', 'Authentication required');
  if (!ADMIN_ROLES.has(user.role)) {
    throw new AppError('FORBIDDEN', 'This action requires the OWNER or ADMIN role', {
      details: { role: user.role },
    });
  }
  return user;
}

export interface AuthPluginDeps {
  config: AppConfig;
  profiles: UserProfileRepository;
  cache: Cache;
  logger: Logger;
}

function bearer(request: FastifyRequest): string {
  const header = request.headers.authorization;
  if (typeof header !== 'string' || !header.startsWith('Bearer ')) {
    throw new AppError('UNAUTHORIZED', 'Missing bearer token');
  }
  const token = header.slice('Bearer '.length).trim();
  if (token === '') throw new AppError('UNAUTHORIZED', 'Missing bearer token');
  return token;
}

/**
 * Registers the authentication preHandler on this scope.
 *
 * preHandler, not onRequest: the rate limiter's key generator also runs in preHandler and must
 * see `request.user`, or every caller shares one IP bucket (measured against @fastify/rate-limit
 * 11.2.0). Registering auth first in the same phase is what orders them.
 */
export function registerAuth(app: FastifyInstance, deps: AuthPluginDeps): void {
  const { config, profiles, cache, logger } = deps;

  if (config.auth.mode === 'none') {
    // Loud on every start: an unauthenticated API is a development convenience, not a default.
    logger.warn(
      { host: config.host },
      'AUTH_MODE=none: every request is treated as OWNER. Local development only.',
    );
    app.addHook('preHandler', async (request) => {
      request.user = { id: DEV_USER_ID, role: 'OWNER', email: null };
    });
    return;
  }

  // Fail at construction, not per request: a server that cannot verify tokens must not boot.
  if (config.auth.secret === null && config.auth.jwksUrl === null) {
    throw new AppError(
      'INTERNAL',
      'AUTH_MODE=jwt needs JWT_SECRET (local Supabase) or SUPABASE_URL (JWKS). Set one, or use AUTH_MODE=none for local development.',
    );
  }

  const verifyOptions: VerifyOptions = {
    secret: config.auth.secret,
    jwksUrl: config.auth.jwksUrl,
    issuer: config.auth.issuer,
    audience: config.auth.audience,
  };
  // Once per server: a per-request JWKS set refetches the keys on every call.
  const key = keyFor(verifyOptions);

  app.addHook('preHandler', async (request) => {
    const { sub, email } = await verifyToken(bearer(request), verifyOptions, key);
    // Cached briefly: a role change takes effect within 30s, which beats a query per request.
    const role = await cache.getOrSet(`role:${sub}`, ROLE_CACHE_MS, () => profiles.findRole(sub));
    if (role === null) {
      // A valid token is identity, not authorization. Defaulting to VIEWER here would let anyone
      // who can sign up read the whole research desk.
      throw new AppError('FORBIDDEN', 'No profile for this account', { details: { userId: sub } });
    }
    request.user = { id: sub, role, email };
  });
}
