import type { FastifyError, FastifyInstance } from 'fastify';
import { type ErrorCode, isAppError } from '../utils/errors.js';
import { errorBody } from './envelope.js';

function codeForStatus(status: number): ErrorCode {
  if (status === 401) return 'UNAUTHORIZED';
  if (status === 403) return 'FORBIDDEN';
  if (status === 404) return 'NOT_FOUND';
  if (status === 409) return 'CONFLICT';
  if (status === 429) return 'RATE_LIMITED';
  return 'VALIDATION';
}

export function registerErrorHandling(app: FastifyInstance): void {
  app.setErrorHandler((error: FastifyError, request, reply) => {
    if (isAppError(error)) {
      if (error.httpStatus >= 500) request.log.error({ err: error }, error.message);
      return reply.code(error.httpStatus).send(errorBody(error.code, error.message, error.details));
    }
    // Framework 4xx (bad JSON, 415, 413, schema validation, later 401/429 plugins) keep their status.
    const status = typeof error.statusCode === 'number' ? error.statusCode : 500;
    if (status >= 400 && status < 500) {
      request.log.warn({ statusCode: status, code: error.code }, error.message);
      return reply.code(status).send(errorBody(codeForStatus(status), error.message));
    }
    request.log.error({ err: error }, 'unhandled error');
    return reply.code(500).send(errorBody('INTERNAL', 'Internal server error'));
  });

  app.setNotFoundHandler((request, reply) =>
    reply
      .code(404)
      .send(
        errorBody('NOT_FOUND', `Route ${request.method} ${request.url.split('?')[0]} not found`),
      ),
  );
}
