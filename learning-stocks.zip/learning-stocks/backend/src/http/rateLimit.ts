import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import type { FastifyInstance } from 'fastify';
import type { AppConfig } from '../config/env.js';

/**
 * PRD §12, keyed per user (see registerHttpPlugins).
 *
 * @fastify/rate-limit keys on (key, route), so two routes sharing `limit('reads')` each get their
 * own 120/min counter rather than sharing one — which is the weaker reading, and the one a caller
 * will actually experience.
 */
export const RATE_LIMITS = {
  reads: { max: 120, timeWindow: '1 minute' },
  'sync.market': { max: 6, timeWindow: '1 hour' },
  'sync.news': { max: 6, timeWindow: '1 hour' },
  'sync.fundamentals': { max: 4, timeWindow: '1 day' },
  'jobs.run': { max: 10, timeWindow: '1 hour' },
  'ai.analyze': { max: 20, timeWindow: '1 hour' },
  'ai.regenerate': { max: 5, timeWindow: '1 hour' },
  qa: { max: 30, timeWindow: '1 hour' },
} as const;

export type RateLimitId = keyof typeof RATE_LIMITS;

/** The per-route `config.rateLimit` object a route spreads into its options. */
export const limit = (id: RateLimitId): { max: number; timeWindow: string } => ({
  ...RATE_LIMITS[id],
});

export async function registerHttpPlugins(app: FastifyInstance, config: AppConfig): Promise<void> {
  // The API serves JSON, never documents, so a CSP would only constrain responses nobody renders.
  await app.register(helmet, { contentSecurityPolicy: false });
  await app.register(cors, { origin: [config.corsOrigin], credentials: true });
  await app.register(rateLimit, {
    // Only routes that opt in are limited; an unlisted route is not silently capped.
    global: false,
    // preHandler, not the default onRequest: the key generator must run AFTER auth or it sees no
    // user, and every caller then shares one IP bucket (measured against 11.2.0).
    hook: 'preHandler',
    keyGenerator: (request) => request.user?.id ?? request.ip,
  });
}
