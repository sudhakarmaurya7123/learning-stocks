// `z` is used at runtime for treeifyError, so this is a value import, not a type-only one.
import { z } from 'zod';
import { AppError } from '../utils/errors.js';

/**
 * Parses one part of a request, turning a schema failure into our VALIDATION error (400) with the
 * offending field path in `details`.
 *
 * A caller who sent `?limit=abc` needs to know which field was wrong; a bare "invalid request"
 * makes them guess. zod's tree carries the paths, so it is passed through as data.
 */
function parse<T>(schema: z.ZodType<T>, value: unknown, part: string): T {
  const result = schema.safeParse(value);
  if (result.success) return result.data;
  throw new AppError('VALIDATION', `Invalid ${part}`, {
    details: { issues: z.treeifyError(result.error) },
  });
}

export const parseParams = <T>(schema: z.ZodType<T>, value: unknown): T =>
  parse(schema, value, 'path parameters');

export const parseQuery = <T>(schema: z.ZodType<T>, value: unknown): T =>
  parse(schema, value, 'query parameters');

export const parseBody = <T>(schema: z.ZodType<T>, value: unknown): T =>
  parse(schema, value, 'request body');
