import type { Container } from './container.js';
import { PgBossQueue } from './jobs/PgBossQueue.js';
import { createRegistry } from './jobs/registry.js';
import { runJob } from './jobs/runJob.js';
import { loadSchedules } from './jobs/schedules.js';
import { JOB_NAMES, type JobName, type JobPayload, type JobQueue } from './jobs/types.js';

export interface RunningWorker {
  queue: JobQueue;
  stop(): Promise<void>;
}

export interface StartWorkerOptions {
  /**
   * Replaces what each queue's worker does when a job arrives. The default runs the real job.
   *
   * This exists because pg-boss fires a cron pass immediately on start and matches any occurrence
   * in the preceding 60 seconds, so merely starting a worker can execute a due job. A test that
   * only wants to assert the queue and schedule rows passes a no-op here rather than running the
   * real pipeline against whatever database it is pointed at.
   */
  handler?: (name: JobName) => (payload: JobPayload) => Promise<void>;
}

/**
 * The single worker process (PRD §18). Every tick and every chained job goes through runJob, so
 * gates, chaining and logging behave identically whether a cron, a chain or an operator started it.
 */
export async function startWorker(
  container: Container,
  options: StartWorkerOptions = {},
): Promise<RunningWorker> {
  const { logger, config } = container;
  const queue = new PgBossQueue({
    connectionString: config.databaseUrl,
    schema: config.worker.queueSchema,
    logger,
    tz: config.worker.timezone,
  });
  await queue.start();
  await queue.ensureQueues(JOB_NAMES);

  const registry = createRegistry(container);
  const handler =
    options.handler ??
    ((name: JobName) => async (payload: JobPayload) => {
      await runJob({
        definition: registry[name],
        payload,
        queue,
        systemLogs: container.repositories.systemLogs,
        logger,
      });
    });
  for (const name of JOB_NAMES) await queue.work(name, handler(name));

  const schedules = await loadSchedules(container.repositories.settings);
  await queue.applySchedules(schedules);
  logger.info(
    {
      dataMode: config.dataMode,
      jobs: JOB_NAMES.length,
      schedules: schedules.length,
      tz: config.worker.timezone,
    },
    'worker started',
  );
  return { queue, stop: () => queue.stop() };
}
