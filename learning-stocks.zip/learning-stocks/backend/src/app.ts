import { randomUUID } from 'node:crypto';
import Fastify, { type FastifyBaseLogger, type FastifyInstance } from 'fastify';
import type { Container } from './container.js';
import { registerAuth } from './http/auth.js';
import { registerErrorHandling } from './http/errorHandler.js';
import { registerHttpPlugins } from './http/rateLimit.js';
import { healthRoutes } from './routes/health.js';
import { actionRoutes } from './routes/actions.js';
import { aggregateRoutes } from './routes/aggregate.js';
import { marketRoutes } from './routes/markets.js';
import { stockRoutes } from './routes/stocks.js';
import { systemStatusRoutes } from './routes/systemStatus.js';

export interface BuildAppOptions {
  /**
   * Extra routes registered inside the authenticated scope, so they inherit the auth preHandler.
   *
   * Fastify encapsulates hooks per plugin scope, so a route added to the returned instance would
   * NOT be authenticated. Tests use this to exercise the auth and rate-limit plugins without
   * depending on routes from a later task.
   */
  extraRoutes?: (api: FastifyInstance) => Promise<void> | void;
}

export async function buildApp(
  c: Container,
  options: BuildAppOptions = {},
): Promise<FastifyInstance> {
  // pino's Logger is a FastifyBaseLogger; typing it as such keeps the default FastifyInstance generics.
  const logger: FastifyBaseLogger = c.logger;
  const app = Fastify({ loggerInstance: logger, genReqId: () => randomUUID() });
  registerErrorHandling(app);
  await registerHttpPlugins(app, c.config);
  // /api/health stays public: a load balancer cannot present a token, and Phase 2's tests call it
  // untokened. Everything else lives in the authenticated scope below.
  await app.register(async (api) => healthRoutes(api, c), { prefix: '/api' });
  await app.register(
    async (api) => {
      registerAuth(api, {
        config: c.config,
        profiles: c.repositories.userProfiles,
        cache: c.cache,
        logger: c.logger,
      });
      await marketRoutes(api, c);
      await stockRoutes(api, c);
      await aggregateRoutes(api, c);
      await actionRoutes(api, c);
      await systemStatusRoutes(api, c);
      await options.extraRoutes?.(api);
    },
    { prefix: '/api' },
  );
  return app;
}
