import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { requireNumber, toNumber } from '../database/convert.js';
import type { DataMode, ImpactLevel, Sentiment } from '../domain/enums.js';
import type { NewsArticle, NewsItem, NewsMention } from '../domain/news.js';
import type { InstrumentRef } from '../domain/types.js';
import type { NewsSentimentPoint } from '../scoring/ScoringEngine.js';
import { AppError } from '../utils/errors.js';

const CHUNK = 200;

/** An article plus the AI sentiment stored for one stock. Null fields = the job has not run. */
export interface ScoredNewsItem extends NewsItem {
  sentiment: Sentiment | null;
  sentimentScore: number | null;
  impactLevel: ImpactLevel | null;
  aiSummary: string | null;
}

/** An article in the market-wide feed, with the stocks it mentions. */
export interface MarketNewsItem {
  id: string;
  title: string;
  description: string | null;
  source: string;
  sourceUrl: string;
  publishedAt: Date;
  linkedSymbols: string[];
  sentiment: Sentiment | null;
  sentimentScore: number | null;
  impactLevel: ImpactLevel | null;
}

function chunks<T>(items: readonly T[]): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += CHUNK) out.push(items.slice(i, i + CHUNK));
  return out;
}

export class NewsRepository {
  constructor(private readonly db: Database) {}

  /**
   * Inserts new articles; existing ones (same content_hash OR same source_url within the data mode)
   * are left untouched. Returns the stored id for every input, so mentions can attach to either.
   */
  async saveArticles(
    articles: readonly NewsArticle[],
  ): Promise<{ ids: string[]; inserted: number }> {
    const [first] = articles;
    if (!first) return { ids: [], inserted: 0 };
    const mode = first.dataMode;
    if (articles.some((a) => a.dataMode !== mode))
      throw new AppError('INTERNAL', 'saveArticles needs a single data mode per call');

    const byHash = new Map<string, string>();
    const byUrl = new Map<string, string>();
    const remember = (r: { id: string; content_hash: string; source_url: string }) => {
      byHash.set(r.content_hash, r.id);
      byUrl.set(r.source_url, r.id);
    };
    let inserted = 0;
    for (const chunk of chunks(articles)) {
      const rows = await this.db
        .insertInto('news')
        .values(
          chunk.map((a) => ({
            data_mode: a.dataMode,
            title: a.title,
            description: a.description,
            content: a.content,
            source: a.source,
            source_url: a.sourceUrl,
            author: a.author,
            published_at: a.publishedAt,
            language: a.language,
            content_hash: a.contentHash,
          })),
        )
        .onConflict((oc) => oc.doNothing())
        .returning(['id', 'content_hash', 'source_url'])
        .execute();
      inserted += rows.length;
      rows.forEach(remember);
    }

    const unresolved = articles.filter(
      (a) => !byHash.has(a.contentHash) && !byUrl.has(a.sourceUrl),
    );
    for (const chunk of chunks(unresolved)) {
      const rows = await this.db
        .selectFrom('news')
        .select(['id', 'content_hash', 'source_url'])
        .where('data_mode', '=', mode)
        .where((eb) =>
          eb.or([
            eb(
              'content_hash',
              'in',
              chunk.map((a) => a.contentHash),
            ),
            eb(
              'source_url',
              'in',
              chunk.map((a) => a.sourceUrl),
            ),
          ]),
        )
        .execute();
      rows.forEach(remember);
    }

    const ids = articles.map((a) => byHash.get(a.contentHash) ?? byUrl.get(a.sourceUrl));
    const resolved = ids.filter((id): id is string => id !== undefined);
    if (resolved.length !== articles.length)
      throw new AppError('INTERNAL', 'Could not resolve stored ids for every article');
    return { ids: resolved, inserted };
  }

  /** Upserts mentions; an existing mention keeps the higher relevance (and its matched_by). */
  async saveMentions(mentions: readonly NewsMention[]): Promise<number> {
    const best = new Map<string, NewsMention>();
    for (const m of mentions) {
      const key = `${m.newsId}|${m.ref.kind}|${m.ref.id}`;
      const current = best.get(key);
      if (!current || m.relevance > current.relevance) best.set(key, m);
    }
    let saved = 0;
    for (const kind of ['stock', 'market'] as const) {
      const column = kind === 'stock' ? 'stock_id' : 'market_id';
      const rows = [...best.values()].filter((m) => m.ref.kind === kind);
      for (const chunk of chunks(rows)) {
        const result = await this.db
          .insertInto('news_mentions')
          .values(
            chunk.map((m) => ({
              news_id: m.newsId,
              stock_id: kind === 'stock' ? m.ref.id : null,
              market_id: kind === 'market' ? m.ref.id : null,
              relevance_score: m.relevance,
              matched_by: m.matchedBy,
            })),
          )
          .onConflict((oc) =>
            oc
              .columns(['news_id', column])
              .where(column, 'is not', null)
              .doUpdateSet({
                relevance_score: sql`greatest(news_mentions.relevance_score, excluded.relevance_score)`,
                matched_by: sql`case when excluded.relevance_score > news_mentions.relevance_score
                                   then excluded.matched_by else news_mentions.matched_by end`,
              }),
          )
          .returning('id')
          .execute();
        saved += result.length;
      }
    }
    return saved;
  }

  async listForInstrument(
    ref: InstrumentRef,
    mode: DataMode,
    options: { since?: Date; limit?: number; minRelevance?: number } = {},
  ): Promise<NewsItem[]> {
    let query = this.db
      .selectFrom('news_mentions as m')
      .innerJoin('news as n', 'n.id', 'm.news_id')
      .select([
        'n.id',
        'n.title',
        'n.description',
        'n.source',
        'n.source_url',
        'n.published_at',
        'm.relevance_score',
        'm.matched_by',
      ])
      .where(ref.kind === 'stock' ? 'm.stock_id' : 'm.market_id', '=', ref.id)
      .where('n.data_mode', '=', mode)
      .where('m.relevance_score', '>=', String(options.minRelevance ?? 0));
    if (options.since) query = query.where('n.published_at', '>=', options.since);
    const rows = await query
      .orderBy('n.published_at', 'desc')
      .limit(Math.min(Math.max(options.limit ?? 20, 1), 100))
      .execute();
    return rows.map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description,
      source: r.source,
      sourceUrl: r.source_url,
      publishedAt: r.published_at,
      relevance: requireNumber(r.relevance_score, 'relevance_score'),
      matchedBy: r.matched_by,
    }));
  }

  /**
   * Articles about one stock with their stored AI sentiment (PRD §3.2's news panel).
   *
   * The sentiment is a LEFT join on purpose: `news_ai_analysis` is written by a separate job, so
   * an article that exists but has not been scored yet is normal. Its sentiment fields come back
   * null rather than the article being hidden — a headline with no badge beats a missing headline.
   */
  async listForStockWithSentiment(
    stockId: string,
    mode: DataMode,
    options: { limit?: number } = {},
  ): Promise<ScoredNewsItem[]> {
    // distinctOn inside a subquery: a re-scored article has several rows, and only the newest is
    // the current opinion.
    const latestScore = this.db
      .selectFrom('news_ai_analysis')
      .select(['news_id', 'sentiment', 'sentiment_score', 'impact_level', 'summary'])
      .distinctOn('news_id')
      .where('stock_id', '=', stockId)
      .orderBy('news_id')
      .orderBy('created_at', 'desc')
      .orderBy('prompt_version', 'desc')
      .as('a');

    const rows = await this.db
      .selectFrom('news_mentions as m')
      .innerJoin('news as n', 'n.id', 'm.news_id')
      .leftJoin(latestScore, (join) => join.onRef('a.news_id', '=', 'n.id'))
      .select([
        'n.id',
        'n.title',
        'n.description',
        'n.source',
        'n.source_url',
        'n.published_at',
        'm.relevance_score',
        'm.matched_by',
        'a.sentiment',
        'a.sentiment_score',
        'a.impact_level',
        'a.summary as ai_summary',
      ])
      .where('m.stock_id', '=', stockId)
      .where('n.data_mode', '=', mode)
      .orderBy('n.published_at', 'desc')
      .limit(Math.min(Math.max(options.limit ?? 20, 1), 100))
      .execute();

    return rows.map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description,
      source: r.source,
      sourceUrl: r.source_url,
      publishedAt: r.published_at,
      relevance: requireNumber(r.relevance_score, 'relevance_score'),
      matchedBy: r.matched_by,
      sentiment: r.sentiment,
      sentimentScore: toNumber(r.sentiment_score),
      impactLevel: r.impact_level,
      aiSummary: r.ai_summary,
    }));
  }

  /**
   * The newest articles across every instrument, for the dashboard's "Latest News" (PRD §3.1).
   *
   * One query, not one per stock: the dashboard shows a single reverse-chronological feed, and the
   * linked symbols are aggregated so a headline says which companies it concerns. An article
   * mentioning three stocks appears once, with three symbols.
   */
  async listRecent(mode: DataMode, options: { limit?: number } = {}): Promise<MarketNewsItem[]> {
    const limit = Math.min(Math.max(options.limit ?? 20, 1), 100);
    const rows = await this.db
      .selectFrom('news as n')
      .select((eb) => [
        'n.id',
        'n.title',
        'n.description',
        'n.source',
        'n.source_url',
        'n.published_at',
        // Aggregated in SQL rather than by a second round trip per article.
        sql<string[]>`coalesce(array(
          select distinct s.symbol
          from news_mentions m
          join stocks s on s.id = m.stock_id
          where m.news_id = n.id
          order by s.symbol
        ), '{}')`.as('linked_symbols'),
        // The strongest sentiment any stock's analysis assigned this article, so the feed can
        // show a badge without the caller knowing which stock it was scored against.
        eb
          .selectFrom('news_ai_analysis as a')
          .select('a.sentiment')
          .whereRef('a.news_id', '=', 'n.id')
          .orderBy('a.created_at', 'desc')
          .limit(1)
          .as('sentiment'),
        eb
          .selectFrom('news_ai_analysis as a')
          .select('a.sentiment_score')
          .whereRef('a.news_id', '=', 'n.id')
          .orderBy('a.created_at', 'desc')
          .limit(1)
          .as('sentiment_score'),
        eb
          .selectFrom('news_ai_analysis as a')
          .select('a.impact_level')
          .whereRef('a.news_id', '=', 'n.id')
          .orderBy('a.created_at', 'desc')
          .limit(1)
          .as('impact_level'),
      ])
      .where('n.data_mode', '=', mode)
      .orderBy('n.published_at', 'desc')
      .limit(limit)
      .execute();

    return rows.map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description,
      source: r.source,
      sourceUrl: r.source_url,
      publishedAt: r.published_at,
      linkedSymbols: r.linked_symbols,
      sentiment: r.sentiment ?? null,
      sentimentScore: toNumber(r.sentiment_score ?? null),
      impactLevel: r.impact_level ?? null,
    }));
  }

  /** LLM sentiment for a stock's articles since a date; the latest analysis per article (Phase 7 writes these). */
  async sentimentsForStock(
    stockId: string,
    mode: DataMode,
    since: Date,
  ): Promise<NewsSentimentPoint[]> {
    const rows = await this.db
      .selectFrom('news_ai_analysis as a')
      .innerJoin('news as n', 'n.id', 'a.news_id')
      .select(['a.news_id', 'a.sentiment_score', 'a.relevance_score', 'n.published_at'])
      .distinctOn('a.news_id')
      .where('a.stock_id', '=', stockId)
      .where('n.data_mode', '=', mode)
      .where('n.published_at', '>=', since)
      .orderBy('a.news_id')
      .orderBy('a.created_at', 'desc')
      .orderBy('a.prompt_version', 'desc')
      .execute();
    return rows.map((r) => ({
      sentimentScore: requireNumber(r.sentiment_score, 'sentiment_score'),
      relevance: requireNumber(r.relevance_score, 'relevance_score'),
      publishedAt: r.published_at,
    }));
  }
}
