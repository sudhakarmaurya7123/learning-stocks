import { type Selectable, sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type { SourceRef } from '../domain/ai.js';
import type { DataMode, MarketRegime, RiskLevel, Sentiment, Trend } from '../domain/enums.js';
import { AppError } from '../utils/errors.js';

const jsonb = (v: unknown) => sql<string>`${JSON.stringify(v)}::jsonb`;
const strings = (v: unknown): string[] =>
  Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [];

export interface MarketSummaryRecord {
  marketId: string;
  dataMode: DataMode;
  dataAsOf: Date;
  sentiment: Sentiment;
  sentimentScore: number;
  confidence: number;
  trend: Trend | null;
  regime: MarketRegime | null;
  riskLevel: RiskLevel | null;
  summary: string;
  keyDrivers: string[];
  keyRisks: string[];
  sectorsPositive: string[];
  sectorsNegative: string[];
  sources: SourceRef[];
  inputHash: string;
  model: string;
  promptVersion: string;
}

export interface StoredMarketSummary extends MarketSummaryRecord {
  id: string;
  analysisTime: Date;
}

function toStored(r: Selectable<DB['market_ai_summary']>): StoredMarketSummary {
  return {
    id: r.id,
    analysisTime: r.analysis_time,
    marketId: r.market_id,
    dataMode: r.data_mode,
    dataAsOf: r.data_as_of,
    sentiment: r.sentiment,
    sentimentScore: toNumber(r.sentiment_score) ?? 50,
    confidence: toNumber(r.confidence) ?? 0,
    trend: r.trend,
    regime: r.regime,
    riskLevel: r.risk_level,
    summary: r.summary,
    keyDrivers: strings(r.key_drivers),
    keyRisks: strings(r.key_risks),
    sectorsPositive: strings(r.sectors_positive),
    sectorsNegative: strings(r.sectors_negative),
    sources: Array.isArray(r.sources) ? (r.sources as unknown as SourceRef[]) : [],
    inputHash: r.input_hash,
    model: r.model,
    promptVersion: r.prompt_version,
  };
}

export class MarketSummaryRepository {
  constructor(private readonly db: Database) {}

  async findByHash(
    marketId: string,
    mode: DataMode,
    inputHash: string,
    promptVersion: string,
  ): Promise<StoredMarketSummary | null> {
    const r = await this.db
      .selectFrom('market_ai_summary')
      .selectAll()
      .where('market_id', '=', marketId)
      .where('data_mode', '=', mode)
      .where('input_hash', '=', inputHash)
      .where('prompt_version', '=', promptVersion)
      .executeTakeFirst();
    return r ? toStored(r) : null;
  }

  async latest(marketId: string, mode: DataMode): Promise<StoredMarketSummary | null> {
    const r = await this.db
      .selectFrom('market_ai_summary')
      .selectAll()
      .where('market_id', '=', marketId)
      .where('data_mode', '=', mode)
      .orderBy('analysis_time', 'desc')
      .limit(1)
      .executeTakeFirst();
    return r ? toStored(r) : null;
  }

  async insert(r: MarketSummaryRecord): Promise<{ id: string; inserted: boolean }> {
    const row = await this.db
      .insertInto('market_ai_summary')
      .values({
        market_id: r.marketId,
        data_mode: r.dataMode,
        data_as_of: r.dataAsOf,
        sentiment: r.sentiment,
        sentiment_score: r.sentimentScore,
        confidence: r.confidence,
        trend: r.trend,
        regime: r.regime,
        risk_level: r.riskLevel,
        summary: r.summary,
        key_drivers: jsonb(r.keyDrivers),
        key_risks: jsonb(r.keyRisks),
        sectors_positive: jsonb(r.sectorsPositive),
        sectors_negative: jsonb(r.sectorsNegative),
        sources: jsonb(r.sources),
        input_hash: r.inputHash,
        model: r.model,
        prompt_version: r.promptVersion,
        analysis_time: sql<Date>`clock_timestamp()`,
      })
      .onConflict((oc) => oc.doNothing())
      .returning('id')
      .executeTakeFirst();
    if (row) return { id: row.id, inserted: true };
    const existing = await this.findByHash(r.marketId, r.dataMode, r.inputHash, r.promptVersion);
    if (!existing)
      throw new AppError(
        'INTERNAL',
        'Market summary insert conflicted but no existing row was found',
      );
    return { id: existing.id, inserted: false };
  }
}
