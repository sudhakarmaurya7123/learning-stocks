import { type Selectable, sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type { AnalysisFact, SourceRef } from '../domain/ai.js';
import type { DataMode, RecommendationBias, RiskLevel, Sentiment, Trend } from '../domain/enums.js';
import { AppError } from '../utils/errors.js';

const jsonb = (v: unknown) => sql<string>`${JSON.stringify(v)}::jsonb`;
const strings = (v: unknown): string[] =>
  Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [];
const objects = <T>(v: unknown): T[] =>
  Array.isArray(v) ? (v.filter((x) => typeof x === 'object' && x !== null) as T[]) : [];

export type AnalysisStatus = 'OK' | 'FAILED' | 'INSUFFICIENT_DATA';

export interface StockAnalysisRecord {
  stockId: string;
  evaluationId: string | null;
  dataMode: DataMode;
  dataAsOf: Date;
  status: AnalysisStatus;
  sentiment: Sentiment | null;
  sentimentScore: number | null;
  confidence: number | null;
  technicalScore: number | null;
  fundamentalScore: number | null;
  newsScore: number | null;
  momentumScore: number | null;
  riskScore: number | null;
  overallScore: number | null;
  trend: Trend | null;
  riskLevel: RiskLevel | null;
  recommendation: RecommendationBias | null;
  summary: string | null;
  reasoning: string[];
  keyPositiveFactors: string[];
  keyNegativeFactors: string[];
  keyRisks: string[];
  catalysts: string[];
  invalidationConditions: string[];
  facts: AnalysisFact[];
  interpretation: string[];
  insufficientData: string[];
  sources: SourceRef[];
  inputHash: string;
  model: string;
  promptVersion: string;
}

export interface StoredStockAnalysis extends StockAnalysisRecord {
  id: string;
  analysisTime: Date;
}

type Row = Selectable<DB['stock_ai_analysis']>;

function toStored(r: Row): StoredStockAnalysis {
  return {
    id: r.id,
    analysisTime: r.analysis_time,
    stockId: r.stock_id,
    evaluationId: r.evaluation_id,
    dataMode: r.data_mode,
    dataAsOf: r.data_as_of,
    status: r.status,
    sentiment: r.sentiment,
    sentimentScore: toNumber(r.sentiment_score),
    confidence: toNumber(r.confidence),
    technicalScore: toNumber(r.technical_score),
    fundamentalScore: toNumber(r.fundamental_score),
    newsScore: toNumber(r.news_score),
    momentumScore: toNumber(r.momentum_score),
    riskScore: toNumber(r.risk_score),
    overallScore: toNumber(r.overall_score),
    trend: r.trend,
    riskLevel: r.risk_level,
    recommendation: r.recommendation,
    summary: r.summary,
    reasoning: strings(r.reasoning),
    keyPositiveFactors: strings(r.key_positive_factors),
    keyNegativeFactors: strings(r.key_negative_factors),
    keyRisks: strings(r.key_risks),
    catalysts: strings(r.catalysts),
    invalidationConditions: strings(r.invalidation_conditions),
    facts: objects<AnalysisFact>(r.facts),
    interpretation: strings(r.interpretation),
    insufficientData: strings(r.insufficient_data),
    sources: objects<SourceRef>(r.sources),
    inputHash: r.input_hash,
    model: r.model,
    promptVersion: r.prompt_version,
  };
}

export class StockAnalysisRepository {
  constructor(private readonly db: Database) {}

  /** A stored result that makes a new call unnecessary (OK or INSUFFICIENT_DATA; FAILED rows are retried). */
  async findUsable(
    stockId: string,
    mode: DataMode,
    inputHash: string,
    promptVersion: string,
  ): Promise<StoredStockAnalysis | null> {
    const r = await this.db
      .selectFrom('stock_ai_analysis')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('input_hash', '=', inputHash)
      .where('prompt_version', '=', promptVersion)
      .where('status', '<>', 'FAILED')
      .executeTakeFirst();
    return r ? toStored(r) : null;
  }

  async latest(
    stockId: string,
    mode: DataMode,
    options: { okOnly?: boolean } = {},
  ): Promise<StoredStockAnalysis | null> {
    let q = this.db
      .selectFrom('stock_ai_analysis')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode);
    if (options.okOnly) q = q.where('status', '=', 'OK');
    const r = await q
      .orderBy('analysis_time', 'desc')
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();
    return r ? toStored(r) : null;
  }

  /** Insert; on the same (stock, mode, hash, version) only a FAILED row is overwritten, unless `replace`. */
  async save(
    r: StockAnalysisRecord,
    options: { replace?: boolean } = {},
  ): Promise<{ id: string; written: boolean }> {
    const values = {
      evaluation_id: r.evaluationId,
      data_as_of: r.dataAsOf,
      status: r.status,
      sentiment: r.sentiment,
      sentiment_score: r.sentimentScore,
      confidence: r.confidence,
      technical_score: r.technicalScore,
      fundamental_score: r.fundamentalScore,
      news_score: r.newsScore,
      momentum_score: r.momentumScore,
      risk_score: r.riskScore,
      overall_score: r.overallScore,
      trend: r.trend,
      risk_level: r.riskLevel,
      recommendation: r.recommendation,
      summary: r.summary,
      reasoning: jsonb(r.reasoning),
      key_positive_factors: jsonb(r.keyPositiveFactors),
      key_negative_factors: jsonb(r.keyNegativeFactors),
      key_risks: jsonb(r.keyRisks),
      catalysts: jsonb(r.catalysts),
      invalidation_conditions: jsonb(r.invalidationConditions),
      facts: jsonb(r.facts),
      interpretation: jsonb(r.interpretation),
      insufficient_data: jsonb(r.insufficientData),
      sources: jsonb(r.sources),
      model: r.model,
      analysis_time: sql<Date>`clock_timestamp()`,
    };
    const row = await this.db
      .insertInto('stock_ai_analysis')
      .values({
        ...values,
        stock_id: r.stockId,
        data_mode: r.dataMode,
        input_hash: r.inputHash,
        prompt_version: r.promptVersion,
      })
      .onConflict((oc) => {
        const update = oc
          .columns(['stock_id', 'data_mode', 'input_hash', 'prompt_version'])
          .doUpdateSet(values);
        return options.replace ? update : update.where('stock_ai_analysis.status', '=', 'FAILED');
      })
      .returning('id')
      .executeTakeFirst();
    if (row) return { id: row.id, written: true };
    const existing = await this.db
      .selectFrom('stock_ai_analysis')
      .select('id')
      .where('stock_id', '=', r.stockId)
      .where('data_mode', '=', r.dataMode)
      .where('input_hash', '=', r.inputHash)
      .where('prompt_version', '=', r.promptVersion)
      .executeTakeFirst();
    if (!existing)
      throw new AppError('INTERNAL', 'Analysis upsert skipped but no existing row was found');
    return { id: existing.id, written: false };
  }
}
