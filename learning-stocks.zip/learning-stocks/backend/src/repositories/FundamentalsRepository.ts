import { sql } from 'kysely';
import type { Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type { DataMode } from '../domain/enums.js';
import type {
  FinancialStatementRecord,
  FundamentalSnapshotRecord,
  SnapshotMetrics,
  StatementMetrics,
  StatementPeriod,
} from '../domain/fundamentals.js';

const CHUNK = 200;

const snapshotColumns = (m: SnapshotMetrics) => ({
  market_cap: m.marketCap,
  pe: m.pe,
  pb: m.pb,
  eps_ttm: m.epsTtm,
  roe: m.roe,
  roce: m.roce,
  debt_to_equity: m.debtToEquity,
  dividend_yield: m.dividendYield,
  operating_margin: m.operatingMargin,
  net_margin: m.netMargin,
  free_cash_flow: m.freeCashFlow,
  revenue_ttm: m.revenueTtm,
  net_profit_ttm: m.netProfitTtm,
  revenue_growth_yoy: m.revenueGrowthYoy,
  profit_growth_yoy: m.profitGrowthYoy,
  book_value_per_share: m.bookValuePerShare,
  beta: m.beta,
});

const statementColumns = (m: StatementMetrics) => ({
  revenue: m.revenue,
  operating_profit: m.operatingProfit,
  net_profit: m.netProfit,
  eps: m.eps,
  total_debt: m.totalDebt,
  total_equity: m.totalEquity,
  cash_from_operations: m.cashFromOperations,
  capex: m.capex,
});

const jsonb = (value: Record<string, unknown>) => sql<string>`${JSON.stringify(value)}::jsonb`;
const asRecord = (value: unknown): Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};

function mapSnapshot(r: Selectable<DB['fundamental_snapshots']>): FundamentalSnapshotRecord {
  return {
    stockId: r.stock_id,
    dataMode: r.data_mode,
    asOf: r.as_of,
    source: r.source,
    raw: asRecord(r.raw),
    metrics: {
      marketCap: toNumber(r.market_cap),
      pe: toNumber(r.pe),
      pb: toNumber(r.pb),
      epsTtm: toNumber(r.eps_ttm),
      roe: toNumber(r.roe),
      roce: toNumber(r.roce),
      debtToEquity: toNumber(r.debt_to_equity),
      dividendYield: toNumber(r.dividend_yield),
      operatingMargin: toNumber(r.operating_margin),
      netMargin: toNumber(r.net_margin),
      freeCashFlow: toNumber(r.free_cash_flow),
      revenueTtm: toNumber(r.revenue_ttm),
      netProfitTtm: toNumber(r.net_profit_ttm),
      revenueGrowthYoy: toNumber(r.revenue_growth_yoy),
      profitGrowthYoy: toNumber(r.profit_growth_yoy),
      bookValuePerShare: toNumber(r.book_value_per_share),
      beta: toNumber(r.beta),
    },
  };
}

function mapStatement(r: Selectable<DB['financial_statements']>): FinancialStatementRecord {
  return {
    stockId: r.stock_id,
    dataMode: r.data_mode,
    periodType: r.period_type as StatementPeriod,
    periodEnd: r.period_end,
    source: r.source,
    raw: asRecord(r.raw),
    metrics: {
      revenue: toNumber(r.revenue),
      operatingProfit: toNumber(r.operating_profit),
      netProfit: toNumber(r.net_profit),
      eps: toNumber(r.eps),
      totalDebt: toNumber(r.total_debt),
      totalEquity: toNumber(r.total_equity),
      cashFromOperations: toNumber(r.cash_from_operations),
      capex: toNumber(r.capex),
    },
  };
}

/** Fundamentals are refreshed in place: one snapshot per stock per IST day; statements are restated. */
export class FundamentalsRepository {
  constructor(private readonly db: Database) {}

  async upsertSnapshot(r: FundamentalSnapshotRecord): Promise<'inserted' | 'updated'> {
    const columns = snapshotColumns(r.metrics);
    const row = await this.db
      .insertInto('fundamental_snapshots')
      .values({
        stock_id: r.stockId,
        data_mode: r.dataMode,
        as_of: r.asOf,
        source: r.source,
        ...columns,
        raw: jsonb(r.raw),
      })
      .onConflict((oc) =>
        oc
          .columns(['stock_id', 'data_mode', 'as_of', 'source'])
          .doUpdateSet({ ...columns, raw: jsonb(r.raw) }),
      )
      .returning(sql<boolean>`(xmax = 0)`.as('inserted'))
      .executeTakeFirstOrThrow();
    return row.inserted ? 'inserted' : 'updated';
  }

  async upsertStatements(
    records: readonly FinancialStatementRecord[],
  ): Promise<{ inserted: number; updated: number }> {
    // ON CONFLICT DO UPDATE cannot touch one row twice in a statement: last record per key wins.
    const unique = new Map<string, FinancialStatementRecord>();
    for (const r of records)
      unique.set(`${r.stockId}|${r.dataMode}|${r.periodType}|${r.periodEnd}|${r.source}`, r);
    const rows = [...unique.values()];
    let inserted = 0;
    let updated = 0;
    for (let i = 0; i < rows.length; i += CHUNK) {
      const result = await this.db
        .insertInto('financial_statements')
        .values(
          rows.slice(i, i + CHUNK).map((r) => ({
            stock_id: r.stockId,
            data_mode: r.dataMode,
            period_type: r.periodType,
            period_end: r.periodEnd,
            source: r.source,
            ...statementColumns(r.metrics),
            raw: jsonb(r.raw),
          })),
        )
        .onConflict((oc) =>
          oc
            .columns(['stock_id', 'data_mode', 'period_type', 'period_end', 'source'])
            .doUpdateSet((eb) => ({
              revenue: eb.ref('excluded.revenue'),
              operating_profit: eb.ref('excluded.operating_profit'),
              net_profit: eb.ref('excluded.net_profit'),
              eps: eb.ref('excluded.eps'),
              total_debt: eb.ref('excluded.total_debt'),
              total_equity: eb.ref('excluded.total_equity'),
              cash_from_operations: eb.ref('excluded.cash_from_operations'),
              capex: eb.ref('excluded.capex'),
              raw: eb.ref('excluded.raw'),
            })),
        )
        .returning(sql<boolean>`(xmax = 0)`.as('inserted'))
        .execute();
      for (const r of result) {
        if (r.inserted) inserted += 1;
        else updated += 1;
      }
    }
    return { inserted, updated };
  }

  async latestSnapshot(stockId: string, mode: DataMode): Promise<FundamentalSnapshotRecord | null> {
    const row = await this.db
      .selectFrom('fundamental_snapshots')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .orderBy('as_of', 'desc')
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();
    return row ? mapSnapshot(row) : null;
  }

  async listStatements(
    stockId: string,
    mode: DataMode,
    periodType: StatementPeriod,
    limit = 12,
  ): Promise<FinancialStatementRecord[]> {
    const rows = await this.db
      .selectFrom('financial_statements')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('period_type', '=', periodType)
      .orderBy('period_end', 'desc')
      .limit(Math.min(Math.max(limit, 1), 40))
      .execute();
    return rows.map(mapStatement);
  }

  /** As listStatements, with row ids (document sources reference statements by id). */
  async listStatementsWithIds(
    stockId: string,
    mode: DataMode,
    periodType: StatementPeriod,
    limit = 12,
  ): Promise<Array<FinancialStatementRecord & { id: string }>> {
    const rows = await this.db
      .selectFrom('financial_statements')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('period_type', '=', periodType)
      .orderBy('period_end', 'desc')
      .limit(Math.min(Math.max(limit, 1), 40))
      .execute();
    return rows.map((r) => ({ id: r.id, ...mapStatement(r) }));
  }

  /** Latest positive P/E of each other active stock in the sector (for sector-relative valuation). */
  async sectorPeerPes(sector: string, excludeStockId: string, mode: DataMode): Promise<number[]> {
    const rows = await this.db
      .selectFrom('fundamental_snapshots as f')
      .innerJoin('stocks as s', 's.id', 'f.stock_id')
      .select(['f.stock_id', 'f.pe'])
      .distinctOn('f.stock_id')
      .where('s.sector', '=', sector)
      .where('s.is_active', '=', true)
      .where('s.id', '!=', excludeStockId)
      .where('f.data_mode', '=', mode)
      .orderBy('f.stock_id')
      .orderBy('f.as_of', 'desc')
      .orderBy('f.created_at', 'desc')
      .execute();
    return rows.map((r) => toNumber(r.pe)).filter((pe): pe is number => pe !== null && pe > 0);
  }
}
