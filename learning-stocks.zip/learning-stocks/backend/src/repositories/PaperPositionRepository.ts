import type { Database } from '../database/db.js';
import type { DataMode } from '../domain/enums.js';

export class PaperPositionRepository {
  constructor(private readonly db: Database) {}

  /** True if any paper account in this data mode holds the stock (personal app: one owner). */
  async holdsPosition(stockId: string, mode: DataMode): Promise<boolean> {
    const row = await this.db
      .selectFrom('paper_positions as p')
      .innerJoin('paper_accounts as a', 'a.id', 'p.account_id')
      .select('p.id')
      .where('p.stock_id', '=', stockId)
      .where('a.data_mode', '=', mode)
      .limit(1)
      .executeTakeFirst();
    return row !== undefined;
  }
}
