import type { Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import type { DB } from '../database/types.generated.js';
import type { Market, ProviderInstrument } from '../domain/types.js';

type MarketRow = Selectable<DB['markets']>;

export function mapMarket(row: MarketRow): Market {
  return {
    id: row.id,
    symbol: row.symbol,
    name: row.name,
    exchange: row.exchange,
    marketType: row.market_type,
    sector: row.sector,
    isActive: row.is_active,
    aliases: row.aliases,
  };
}

export class MarketRepository {
  constructor(private readonly db: Database) {}

  async listActive(): Promise<Market[]> {
    const rows = await this.db
      .selectFrom('markets')
      .selectAll()
      .where('is_active', '=', true)
      .orderBy('symbol')
      .execute();
    return rows.map(mapMarket);
  }

  async findBySymbol(symbol: string): Promise<Market | null> {
    const row = await this.db
      .selectFrom('markets')
      .selectAll()
      .where('symbol', '=', symbol.trim().toUpperCase())
      .executeTakeFirst();
    return row ? mapMarket(row) : null;
  }

  async listWithProviderSymbol(provider: string): Promise<ProviderInstrument<Market>[]> {
    const rows = await this.db
      .selectFrom('markets as m')
      .innerJoin('provider_symbols as p', 'p.market_id', 'm.id')
      .selectAll('m')
      .select(['p.provider_symbol', 'p.verified'])
      .where('p.provider', '=', provider)
      .where('m.is_active', '=', true)
      .orderBy('m.symbol')
      .execute();
    return rows.map((r) => ({
      instrument: mapMarket(r),
      providerSymbol: r.provider_symbol,
      verified: r.verified,
    }));
  }

  async linksForStock(
    stockId: string,
  ): Promise<Array<{ market: Market; linkType: 'BENCHMARK' | 'SECTOR_INDEX' | 'CONSTITUENT' }>> {
    const rows = await this.db
      .selectFrom('stock_market_links as l')
      .innerJoin('markets as m', 'm.id', 'l.market_id')
      .selectAll('m')
      .select('l.link_type')
      .where('l.stock_id', '=', stockId)
      .where('m.is_active', '=', true)
      .orderBy('l.link_type')
      .orderBy('m.symbol')
      .execute();
    return rows.map((r) => ({ market: mapMarket(r), linkType: r.link_type }));
  }
}
