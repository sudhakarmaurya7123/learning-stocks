import type { Database } from '../database/db.js';
import { parseScoringConfig, type ScoringConfig } from '../scoring/config.js';
import { AppError } from '../utils/errors.js';

export class ScoringConfigRepository {
  constructor(private readonly db: Database) {}

  /** The single active config (a partial unique index guarantees at most one). */
  async getActive(): Promise<ScoringConfig> {
    const row = await this.db
      .selectFrom('scoring_configs')
      .select(['version', 'weights', 'thresholds'])
      .where('is_active', '=', true)
      .executeTakeFirst();
    if (!row) throw new AppError('NOT_FOUND', 'No active scoring config');
    return parseScoringConfig(row);
  }
}
