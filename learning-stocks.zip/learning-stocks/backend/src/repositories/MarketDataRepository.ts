import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { requireNumber, toNumber } from '../database/convert.js';
import type { BarInterval, DataMode } from '../domain/enums.js';
import type { Bar, InstrumentRef, LatestQuote } from '../domain/types.js';
import { AppError } from '../utils/errors.js';
import { addDays, istToUtc } from '../utils/ist.js';

const CHUNK = 500;

const ownerColumns = (ref: InstrumentRef) =>
  ref.kind === 'stock'
    ? { stock_id: ref.id, market_id: null }
    : { stock_id: null, market_id: ref.id };

export class MarketDataRepository {
  constructor(private readonly db: Database) {}

  async insertBars(bars: Bar[]): Promise<{ inserted: number; skipped: number }> {
    let inserted = 0;
    for (let i = 0; i < bars.length; i += CHUNK) {
      const chunk = bars.slice(i, i + CHUNK);
      const rows = await this.db
        .insertInto('market_data')
        .values(
          chunk.map((b) => ({
            ...ownerColumns(b.instrument),
            data_mode: b.dataMode,
            timeframe: b.timeframe,
            ts: b.ts,
            open: b.open,
            high: b.high,
            low: b.low,
            close: b.close,
            adjusted_close: b.adjustedClose,
            volume: b.volume,
            change: b.change,
            change_percent: b.changePercent,
            vwap: b.vwap,
            source: b.source,
          })),
        )
        .onConflict((oc) => oc.doNothing())
        .returning('id')
        .execute();
      inserted += rows.length;
    }
    return { inserted, skipped: bars.length - inserted };
  }

  async latestQuote(ref: InstrumentRef, mode: DataMode): Promise<LatestQuote | null> {
    const column = ref.kind === 'stock' ? 'stock_id' : 'market_id';
    const row = await this.db
      .selectFrom('v_latest_quotes')
      .selectAll()
      .where(column, '=', ref.id)
      .where('data_mode', '=', mode)
      .executeTakeFirst();
    if (!row) return null;
    if (
      row.ts === null ||
      row.timeframe === null ||
      row.source === null ||
      row.data_mode === null
    ) {
      throw new AppError('INTERNAL', 'v_latest_quotes returned an incomplete row', {
        details: { ref },
      });
    }
    return {
      instrument: ref,
      dataMode: row.data_mode,
      timeframe: row.timeframe,
      ts: row.ts,
      price: requireNumber(row.price, 'price'),
      change: toNumber(row.change),
      changePercent: toNumber(row.change_percent),
      volume: requireNumber(row.volume, 'volume'),
      source: row.source,
    };
  }

  /**
   * Does any instrument have a stored daily bar for this IST date?
   *
   * The EOD job asks this to catch a sync that silently missed the close: a daily bar is final
   * only at close + settle, so a run on that boundary can drop today's bar and still report
   * SUCCESS. Matched over the IST day rather than an exact session open, because a special
   * session does not open at 09:15.
   */
  async hasDailyBarOn(istDate: string, mode: DataMode): Promise<boolean> {
    const dayStart = istToUtc(istDate, '00:00:00');
    const dayEnd = istToUtc(addDays(istDate, 1), '00:00:00');
    const row = await this.db
      .selectFrom('market_data')
      .select(sql<number>`1`.as('one'))
      .where('data_mode', '=', mode)
      .where('timeframe', '=', '1d')
      .where('ts', '>=', dayStart)
      .where('ts', '<', dayEnd)
      .limit(1)
      .executeTakeFirst();
    return row !== undefined;
  }

  async getBars(
    ref: InstrumentRef,
    mode: DataMode,
    timeframe: BarInterval,
    from: Date,
    to: Date,
  ): Promise<Bar[]> {
    const column = ref.kind === 'stock' ? 'stock_id' : 'market_id';
    const rows = await this.db
      .selectFrom('market_data')
      .selectAll()
      .where(column, '=', ref.id)
      .where('data_mode', '=', mode)
      .where('timeframe', '=', timeframe)
      .where('ts', '>=', from)
      .where('ts', '<=', to)
      .orderBy('ts')
      .execute();
    return rows.map((r) => ({
      instrument: ref,
      dataMode: r.data_mode,
      timeframe: r.timeframe,
      ts: r.ts,
      open: requireNumber(r.open, 'open'),
      high: requireNumber(r.high, 'high'),
      low: requireNumber(r.low, 'low'),
      close: requireNumber(r.close, 'close'),
      adjustedClose: toNumber(r.adjusted_close),
      volume: requireNumber(r.volume, 'volume'),
      change: toNumber(r.change),
      changePercent: toNumber(r.change_percent),
      vwap: toNumber(r.vwap),
      source: r.source,
    }));
  }

  /**
   * Recomputes change / change_percent for one instrument+mode+source in [from, to], so values stored
   * before their previous close existed (first backfill, intraday-before-daily) heal on the next sync.
   * Daily: vs the previous stored daily close (ignored if more than 7 days back).
   * Intraday: vs the latest daily close before the bar's IST calendar day (within 7 days).
   */
  async recomputeChanges(
    ref: InstrumentRef,
    mode: DataMode,
    source: string,
    from: Date,
    to: Date,
  ): Promise<void> {
    const owner = sql.ref(ref.kind === 'stock' ? 'stock_id' : 'market_id');
    const lookbackFrom = new Date(from.getTime() - 14 * 86_400_000);
    await sql`
      with d as (
        select id, ts, close, lag(close) over w as prev_close, lag(ts) over w as prev_ts
          from public.market_data
         where ${owner} = ${ref.id} and data_mode = ${mode} and source = ${source} and timeframe = '1d'
           and ts >= ${lookbackFrom} and ts <= ${to}
        window w as (order by ts)
      )
      update public.market_data m
         set change = d.close - d.prev_close,
             change_percent = (d.close - d.prev_close) / d.prev_close * 100
        from d
       where m.id = d.id and m.ts >= ${from}
         and d.prev_close is not null and d.ts - d.prev_ts <= interval '7 days'`.execute(this.db);
    await sql`
      update public.market_data m
         set (change, change_percent) = (
           select m.close - d.close, (m.close - d.close) / d.close * 100
             from public.market_data d
            where d.${owner} = m.${owner} and d.data_mode = m.data_mode and d.source = m.source
              and d.timeframe = '1d'
              and d.ts < ((m.ts at time zone 'Asia/Kolkata')::date::timestamp at time zone 'Asia/Kolkata')
              and d.ts >= m.ts - interval '7 days'
            order by d.ts desc limit 1)
       where m.${owner} = ${ref.id} and m.data_mode = ${mode} and m.source = ${source}
         and m.timeframe <> '1d' and m.ts >= ${from} and m.ts <= ${to}`.execute(this.db);
  }
}
