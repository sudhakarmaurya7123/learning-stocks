import { sql } from 'kysely';
import type { Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import { requireNumber, toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type {
  ActionState,
  DataMode,
  Exchange,
  RecommendationBias,
  RiskLevel,
  ValuationLabel,
} from '../domain/enums.js';
import type { ProviderInstrument, Stock } from '../domain/types.js';

type StockRow = Selectable<DB['stocks']>;

export function mapStock(row: StockRow): Stock {
  return {
    id: row.id,
    symbol: row.symbol,
    companyName: row.company_name,
    exchange: row.exchange,
    isin: row.isin,
    isinVerified: row.isin_verified,
    sector: row.sector,
    industry: row.industry,
    marketCap: toNumber(row.market_cap),
    currency: row.currency,
    isActive: row.is_active,
    aliases: row.aliases,
  };
}

const escapeLike = (value: string) => value.replace(/[\\%_]/g, (c) => `\\${c}`);

/** A stock plus the headline numbers from its latest evaluation, for the list view. */
export interface StockListRow {
  stock: Stock;
  evaluation: {
    actionState: ActionState;
    recommendationBias: RecommendationBias | null;
    overallScore: number | null;
    riskLevel: RiskLevel | null;
    evaluatedAt: Date;
  } | null;
  /**
   * The columns PRD §3.1's "Worth Considering" table shows beyond the action state.
   *
   * They live on the row rather than behind a second request because the dashboard renders twenty
   * of these at once: fetching the full aggregate per row would be twenty requests against a
   * 120/min budget. Every field is null when unknown — never 0, which would rank an unevaluated
   * stock as the worst one.
   */
  quote: { price: number; changePercent: number | null; ts: Date } | null;
  valuationLabel: ValuationLabel | null;
  riskReward: number | null;
  sentimentScore: number | null;
  scores: {
    technical: number | null;
    quality: number | null;
    valuation: number | null;
    news: number | null;
    momentum: number | null;
  } | null;
}

export interface StockListFilters {
  mode: DataMode;
  query?: string;
  sector?: string;
  action?: ActionState;
}

export class StockRepository {
  constructor(private readonly db: Database) {}

  /**
   * Active stocks with their newest evaluation in one query (PRD §12 `/stocks`).
   *
   * A left join keeps a stock that has never been evaluated: a newly added instrument should
   * appear in the list, not vanish from the dashboard until the next worker run. `distinctOn`
   * collapses the many stored evaluations per stock down to the latest.
   */
  async listWithFilters(f: StockListFilters): Promise<StockListRow[]> {
    const latest = this.db
      .selectFrom('stock_evaluations')
      .select([
        'stock_id',
        'action_state',
        'recommendation_bias',
        'overall_score',
        'risk_level',
        'evaluated_at',
        'valuation_label',
        'risk_reward',
        'technical_score',
        'quality_score',
        'valuation_score',
        'news_score',
        'momentum_score',
      ])
      .distinctOn('stock_id')
      .where('data_mode', '=', f.mode)
      .orderBy('stock_id')
      .orderBy('evaluated_at', 'desc')
      .orderBy('created_at', 'desc')
      .as('e');

    let q = this.db
      .selectFrom('stocks as s')
      .leftJoin(latest, (join) => join.onRef('e.stock_id', '=', 's.id'))
      .selectAll('s')
      .select((eb) => [
        'e.action_state',
        'e.recommendation_bias',
        'e.overall_score',
        'e.risk_level',
        'e.evaluated_at',
        'e.valuation_label',
        'e.risk_reward',
        'e.technical_score',
        'e.quality_score',
        'e.valuation_score',
        'e.news_score',
        'e.momentum_score',
        // Correlated subqueries rather than N+1 round trips: one query serves the whole table.
        // The newest bar of ANY timeframe is the current price — intraday during a session,
        // the daily close afterwards.
        eb
          .selectFrom('market_data as md')
          .select('md.close')
          .whereRef('md.stock_id', '=', 's.id')
          .where('md.data_mode', '=', f.mode)
          .orderBy('md.ts', 'desc')
          .limit(1)
          .as('quote_price'),
        eb
          .selectFrom('market_data as md')
          .select('md.change_percent')
          .whereRef('md.stock_id', '=', 's.id')
          .where('md.data_mode', '=', f.mode)
          .orderBy('md.ts', 'desc')
          .limit(1)
          .as('quote_change_percent'),
        eb
          .selectFrom('market_data as md')
          .select('md.ts')
          .whereRef('md.stock_id', '=', 's.id')
          .where('md.data_mode', '=', f.mode)
          .orderBy('md.ts', 'desc')
          .limit(1)
          .as('quote_ts'),
        // The 30-day mean of stored per-article sentiment, matching /stocks/:symbol/sentiment.
        eb
          .selectFrom('news_ai_analysis as a')
          .innerJoin('news as n', 'n.id', 'a.news_id')
          .select(({ fn }) => fn.avg<string>('a.sentiment_score').as('avg'))
          .whereRef('a.stock_id', '=', 's.id')
          .where('n.data_mode', '=', f.mode)
          .where('n.published_at', '>=', sql<Date>`now() - interval '30 days'`)
          .as('sentiment_score'),
      ])
      .where('s.is_active', '=', true);

    if (f.query !== undefined) {
      const raw = f.query.trim();
      // A query of only LIKE metacharacters would otherwise match everything and look like it
      // worked. Treat it as no match rather than as a wildcard.
      if (raw.replace(/[%_\\]/g, '') === '') return [];
      const pattern = `%${escapeLike(raw)}%`;
      q = q.where((eb) =>
        eb.or([
          eb('s.symbol', 'like', pattern.toUpperCase()),
          // Company names are mixed case, so match case-insensitively.
          eb('s.company_name', 'ilike', pattern),
        ]),
      );
    }
    if (f.sector !== undefined) q = q.where('s.sector', '=', f.sector);
    if (f.action !== undefined) q = q.where('e.action_state', '=', f.action);

    const rows = await q.orderBy('s.symbol').execute();
    const round2 = (v: number | null): number | null =>
      v === null ? null : Math.round(v * 100) / 100;
    return rows.map((r) => ({
      stock: mapStock(r),
      evaluation:
        r.action_state === null || r.evaluated_at === null
          ? null
          : {
              actionState: r.action_state,
              recommendationBias: r.recommendation_bias,
              overallScore: toNumber(r.overall_score),
              riskLevel: r.risk_level,
              evaluatedAt: r.evaluated_at,
            },
      quote:
        r.quote_price === null || r.quote_ts === null
          ? null
          : {
              price: requireNumber(r.quote_price, 'close'),
              changePercent: toNumber(r.quote_change_percent),
              ts: r.quote_ts,
            },
      valuationLabel: r.valuation_label,
      riskReward: toNumber(r.risk_reward),
      sentimentScore: round2(toNumber(r.sentiment_score)),
      // One null object rather than five nulls: the table renders "—" across the score columns
      // when a stock has never been evaluated, which is a different state from scoring zero.
      scores:
        r.evaluated_at === null
          ? null
          : {
              technical: toNumber(r.technical_score),
              quality: toNumber(r.quality_score),
              valuation: toNumber(r.valuation_score),
              news: toNumber(r.news_score),
              momentum: toNumber(r.momentum_score),
            },
    }));
  }

  async listActive(): Promise<Stock[]> {
    const rows = await this.db
      .selectFrom('stocks')
      .selectAll()
      .where('is_active', '=', true)
      .orderBy('symbol')
      .execute();
    return rows.map(mapStock);
  }

  async findBySymbol(symbol: string, exchange: Exchange = 'NSE'): Promise<Stock | null> {
    const row = await this.db
      .selectFrom('stocks')
      .selectAll()
      .where('exchange', '=', exchange)
      .where('symbol', '=', symbol.trim().toUpperCase())
      .executeTakeFirst();
    return row ? mapStock(row) : null;
  }

  async search(query: string, limit = 10): Promise<Stock[]> {
    const q = query.trim();
    if (q.replace(/[%_\\]/g, '') === '') return [];
    const upper = q.toUpperCase();
    const prefix = `${escapeLike(upper)}%`;
    const contains = `%${escapeLike(q)}%`;
    const rows = await this.db
      .selectFrom('stocks')
      .selectAll()
      .where('is_active', '=', true)
      .where((eb) =>
        eb.or([
          eb('symbol', 'like', prefix),
          eb('company_name', 'ilike', contains),
          eb('isin', '=', upper),
        ]),
      )
      .orderBy(sql`case when symbol = ${upper} then 0 when symbol like ${prefix} then 1 else 2 end`)
      .orderBy('symbol')
      .limit(Math.min(Math.max(limit, 1), 50))
      .execute();
    return rows.map(mapStock);
  }

  async listWithProviderSymbol(provider: string): Promise<ProviderInstrument<Stock>[]> {
    const rows = await this.db
      .selectFrom('stocks as s')
      .innerJoin('provider_symbols as p', 'p.stock_id', 's.id')
      .selectAll('s')
      .select(['p.provider_symbol', 'p.verified'])
      .where('p.provider', '=', provider)
      .where('s.is_active', '=', true)
      .orderBy('s.symbol')
      .execute();
    return rows.map((r) => ({
      instrument: mapStock(r),
      providerSymbol: r.provider_symbol,
      verified: r.verified,
    }));
  }
}
