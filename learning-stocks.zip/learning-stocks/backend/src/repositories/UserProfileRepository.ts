import type { Database } from '../database/db.js';
import type { UserRole } from '../domain/enums.js';

export class UserProfileRepository {
  constructor(private readonly db: Database) {}

  /**
   * The app role for an authenticated user, or null when they have no profile.
   *
   * null is meaningful: a Supabase token proves who someone is, not what they may do. Phase 1's
   * `handle_new_user()` trigger creates this row on signup (first user OWNER, the rest VIEWER),
   * so a missing row means the account was never provisioned here.
   */
  async findRole(userId: string): Promise<UserRole | null> {
    const row = await this.db
      .selectFrom('user_profiles')
      .select('role')
      .where('user_id', '=', userId)
      .executeTakeFirst();
    return row?.role ?? null;
  }
}
