import type { Database } from '../database/db.js';
import type { Exchange } from '../domain/enums.js';
import type { Holiday } from '../domain/types.js';

export class HolidayRepository {
  constructor(private readonly db: Database) {}

  /** Inclusive [from, to] on IST calendar dates (YYYY-MM-DD). */
  async listBetween(exchange: Exchange, from: string, to: string): Promise<Holiday[]> {
    const rows = await this.db
      .selectFrom('exchange_holidays')
      .select(['exchange', 'holiday_date', 'description', 'special_open', 'special_close'])
      .where('exchange', '=', exchange)
      .where('segment', '=', 'EQUITY')
      .where('holiday_date', '>=', from)
      .where('holiday_date', '<=', to)
      .orderBy('holiday_date')
      .execute();
    return rows.map((r) => ({
      exchange: r.exchange,
      date: r.holiday_date,
      description: r.description,
      specialOpen: r.special_open,
      specialClose: r.special_close,
    }));
  }
}
