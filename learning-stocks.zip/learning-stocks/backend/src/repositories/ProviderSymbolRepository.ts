import type { Database } from '../database/db.js';
import type { Exchange } from '../domain/enums.js';
import { AppError } from '../utils/errors.js';

export interface ProviderSymbolEntry {
  provider: string;
  providerSymbol: string;
  verified: boolean;
  kind: 'stock' | 'market';
  symbol: string;
  exchange: Exchange;
}

export class ProviderSymbolRepository {
  constructor(private readonly db: Database) {}

  async listByProvider(
    provider: string,
    symbols?: readonly string[],
  ): Promise<ProviderSymbolEntry[]> {
    const wanted = symbols?.map((s) => s.trim().toUpperCase());
    let stockQuery = this.db
      .selectFrom('provider_symbols as p')
      .innerJoin('stocks as s', 's.id', 'p.stock_id')
      .select(['p.provider', 'p.provider_symbol', 'p.verified', 's.symbol', 's.exchange'])
      .where('p.provider', '=', provider)
      .where('s.is_active', '=', true);
    let marketQuery = this.db
      .selectFrom('provider_symbols as p')
      .innerJoin('markets as m', 'm.id', 'p.market_id')
      .select(['p.provider', 'p.provider_symbol', 'p.verified', 'm.symbol', 'm.exchange'])
      .where('p.provider', '=', provider)
      .where('m.is_active', '=', true);
    if (wanted) {
      if (wanted.length === 0) return [];
      stockQuery = stockQuery.where('s.symbol', 'in', wanted);
      marketQuery = marketQuery.where('m.symbol', 'in', wanted);
    }
    const [stocks, markets] = await Promise.all([
      stockQuery.orderBy('s.symbol').execute(),
      marketQuery.orderBy('m.symbol').execute(),
    ]);
    const map =
      (kind: 'stock' | 'market') =>
      (r: (typeof stocks)[number]): ProviderSymbolEntry => ({
        provider: r.provider,
        providerSymbol: r.provider_symbol,
        verified: r.verified,
        kind,
        symbol: r.symbol,
        exchange: r.exchange,
      });
    return [...stocks.map(map('stock')), ...markets.map(map('market'))];
  }

  async setVerified(provider: string, providerSymbol: string, verified: boolean): Promise<void> {
    const result = await this.db
      .updateTable('provider_symbols')
      .set({ verified })
      .where('provider', '=', provider)
      .where('provider_symbol', '=', providerSymbol)
      .executeTakeFirst();
    if (Number(result.numUpdatedRows) === 0) {
      throw new AppError('NOT_FOUND', `No ${provider} mapping for ${providerSymbol}`, {
        details: { provider, providerSymbol },
      });
    }
  }
}
