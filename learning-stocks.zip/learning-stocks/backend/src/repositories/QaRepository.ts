import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import type { SourceRef } from '../domain/ai.js';
import type { DataMode } from '../domain/enums.js';

export interface QaRecord {
  stockId: string;
  dataMode: DataMode;
  question: string;
  questionHash: string;
  contextHash: string;
  answer: unknown;
  sources: SourceRef[];
  model: string;
  promptVersion: string;
}

export interface StoredQa {
  id: string;
  answer: unknown;
  sources: SourceRef[];
  model: string;
  createdAt: Date;
}

/** PRD §10 Q&A cache: (stock, normalised question hash, context hash, prompt version). */
export class QaRepository {
  constructor(private readonly db: Database) {}

  async findCached(
    stockId: string,
    mode: DataMode,
    questionHash: string,
    contextHash: string,
    promptVersion: string,
  ): Promise<StoredQa | null> {
    const r = await this.db
      .selectFrom('ai_qa_log')
      .select(['id', 'answer', 'sources', 'model', 'created_at'])
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('question_hash', '=', questionHash)
      .where('context_hash', '=', contextHash)
      .where('prompt_version', '=', promptVersion)
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();
    return r
      ? {
          id: r.id,
          answer: r.answer,
          sources: Array.isArray(r.sources) ? (r.sources as unknown as SourceRef[]) : [],
          model: r.model,
          createdAt: r.created_at,
        }
      : null;
  }

  async insert(r: QaRecord): Promise<string> {
    const row = await this.db
      .insertInto('ai_qa_log')
      .values({
        stock_id: r.stockId,
        data_mode: r.dataMode,
        user_id: null,
        question: r.question,
        question_hash: r.questionHash,
        context_hash: r.contextHash,
        answer: sql<string>`${JSON.stringify(r.answer)}::jsonb`,
        sources: sql<string>`${JSON.stringify(r.sources)}::jsonb`,
        model: r.model,
        prompt_version: r.promptVersion,
      })
      .returning('id')
      .executeTakeFirstOrThrow();
    return row.id;
  }
}
