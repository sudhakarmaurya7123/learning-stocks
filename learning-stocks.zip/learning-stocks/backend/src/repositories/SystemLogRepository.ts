import { randomUUID } from 'node:crypto';
import { sql, type Selectable } from 'kysely';
import type { Database } from '../database/db.js';
import type { DB } from '../database/types.generated.js';
import type { JobStatus } from '../domain/enums.js';
import { AppError, isAppError } from '../utils/errors.js';

export interface JobRun {
  id: string;
  service: string;
  jobName: string | null;
  operation: string;
  status: JobStatus;
  message: string | null;
  recordsFetched: number;
  recordsInserted: number;
  recordsSkipped: number;
  recordsFailed: number;
  recordsProcessed: number;
  startedAt: Date | null;
  finishedAt: Date | null;
  executionTimeMs: number | null;
  errorDetails: unknown;
}

export interface RunCounts {
  fetched: number;
  inserted: number;
  skipped: number;
  failed: number;
}

function serializeError(error: unknown): Record<string, unknown> {
  if (isAppError(error))
    return { code: error.code, message: error.message, details: error.details ?? null };
  if (error instanceof Error) return { code: 'INTERNAL', message: error.message };
  return { code: 'INTERNAL', message: String(error) };
}

function mapRun(r: Selectable<DB['system_logs']>): JobRun {
  return {
    id: r.id,
    service: r.service,
    jobName: r.job_name,
    operation: r.operation,
    status: r.status,
    message: r.message,
    recordsFetched: r.records_fetched,
    recordsInserted: r.records_inserted,
    recordsSkipped: r.records_skipped,
    recordsFailed: r.records_failed,
    recordsProcessed: r.records_processed,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
    executionTimeMs: r.execution_time_ms,
    errorDetails: r.error_details,
  };
}

export class SystemLogRepository {
  constructor(private readonly db: Database) {}

  async startRun(input: { service: string; jobName: string; operation: string }): Promise<string> {
    const id = randomUUID();
    await this.db
      .insertInto('system_logs')
      .values({
        id,
        job_run_id: id,
        service: input.service,
        job_name: input.jobName,
        operation: input.operation,
        status: 'STARTED',
        // clock_timestamp(): distinct per run even inside one transaction (now() is per transaction).
        started_at: sql`clock_timestamp()`,
      })
      .execute();
    return id;
  }

  async finishRun(
    runId: string,
    result: {
      status: Exclude<JobStatus, 'STARTED'>;
      counts: RunCounts;
      message?: string;
      error?: unknown;
      details?: Record<string, unknown>;
    },
  ): Promise<void> {
    const { counts } = result;
    const updated = await this.db
      .updateTable('system_logs')
      .set({
        status: result.status,
        message: result.message ?? null,
        records_fetched: counts.fetched,
        records_inserted: counts.inserted,
        records_skipped: counts.skipped,
        records_failed: counts.failed,
        records_processed: counts.inserted + counts.skipped + counts.failed,
        finished_at: sql`clock_timestamp()`,
        execution_time_ms: sql`greatest(0, (extract(epoch from (clock_timestamp() - started_at)) * 1000)::int)`,
        error_details: (() => {
          const payload =
            result.error !== undefined && result.details !== undefined
              ? { ...serializeError(result.error), context: result.details }
              : result.error !== undefined
                ? serializeError(result.error)
                : result.details;
          return payload === undefined ? null : sql`${JSON.stringify(payload)}::jsonb`;
        })(),
      })
      .where('id', '=', runId)
      .executeTakeFirst();
    if (Number(updated.numUpdatedRows) === 0) {
      throw new AppError('NOT_FOUND', `Job run ${runId} not found`, { details: { runId } });
    }
  }

  /**
   * Corrects an already-finished run's verdict. Used when a job handler judges a run worse than
   * the service did — the service only knows its own work succeeded, the handler knows whether
   * the result is usable. Counts and timings are left alone; only the verdict changes.
   */
  async amendRun(
    runId: string,
    result: { status: Exclude<JobStatus, 'STARTED'>; message: string },
  ): Promise<void> {
    const updated = await this.db
      .updateTable('system_logs')
      .set({ status: result.status, message: result.message })
      .where('id', '=', runId)
      .executeTakeFirst();
    if (Number(updated.numUpdatedRows) === 0) {
      throw new AppError('NOT_FOUND', `Job run ${runId} not found`, { details: { runId } });
    }
  }

  /**
   * The newest run of a service that actually did work.
   *
   * SUCCESS or PARTIAL only: a SKIPPED row means the gate said no (market closed, provider off),
   * and reporting that as `last_market_sync` would tell the owner the data is current when
   * nothing was fetched. Matched on `service`, not `job_name`, so a CLI run
   * (`cli.sync-market`) counts — it is still a market sync.
   */
  async lastSuccessful(service: string): Promise<JobRun | null> {
    const row = await this.db
      .selectFrom('system_logs')
      .selectAll()
      .where('service', '=', service)
      .where('status', 'in', ['SUCCESS', 'PARTIAL'])
      .orderBy('finished_at', 'desc')
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();
    return row ? mapRun(row) : null;
  }

  /**
   * The newest run of each distinct job, for the admin page's cron table (PRD §3.4).
   *
   * One row per job, not per run: the table answers "when did each job last run, and how did it
   * go", so twenty rows of market.sync.intraday would bury the one job that is failing.
   */
  async lastRunPerJob(): Promise<JobRun[]> {
    const rows = await this.db
      .selectFrom('system_logs')
      .selectAll()
      .distinctOn('job_name')
      .where('job_name', 'is not', null)
      .orderBy('job_name')
      .orderBy('started_at', 'desc')
      .orderBy('created_at', 'desc')
      .execute();
    return rows.map(mapRun);
  }

  /** Recent runs that failed outright, for the admin failures list (PRD §16). */
  async recentFailures(limit = 10): Promise<JobRun[]> {
    const rows = await this.db
      .selectFrom('system_logs')
      .selectAll()
      .where('status', '=', 'FAILED')
      .orderBy('started_at', 'desc')
      .orderBy('created_at', 'desc')
      .limit(limit)
      .execute();
    return rows.map(mapRun);
  }

  async recentRuns(limit = 20): Promise<JobRun[]> {
    const rows = await this.db
      .selectFrom('system_logs')
      .selectAll()
      .orderBy('started_at', 'desc')
      .orderBy('created_at', 'desc')
      .limit(limit)
      .execute();
    return rows.map(mapRun);
  }
}
