import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { BarInterval, DataMode } from '../domain/enums.js';
import type { IndicatorPoint, IndicatorValues } from '../technical/indicators.js';
import { round } from '../technical/stats.js';

const CHUNK = 500;
const n4 = (v: number | null) => (v === null ? null : round(v, 4));
/** public.score columns are numeric(5,2) within 0–100. */
const n2 = (v: number | null) => (v === null ? null : round(Math.min(100, Math.max(0, v)), 2));

export class TechnicalIndicatorRepository {
  constructor(private readonly db: Database) {}

  /** Upserts the series: a re-run recomputes and overwrites (self-healing). Returns rows written. */
  async upsertSeries(
    stockId: string,
    mode: DataMode,
    timeframe: BarInterval,
    points: readonly IndicatorPoint[],
  ): Promise<number> {
    let written = 0;
    for (let i = 0; i < points.length; i += CHUNK) {
      const rows = points.slice(i, i + CHUNK).map(({ ts, values: v, pivots, vwap }) => ({
        stock_id: stockId,
        data_mode: mode,
        timeframe,
        ts,
        sma_20: n4(v.sma20),
        sma_50: n4(v.sma50),
        sma_200: n4(v.sma200),
        ema_20: n4(v.ema20),
        ema_50: n4(v.ema50),
        ema_200: n4(v.ema200),
        rsi_14: n2(v.rsi14),
        macd: n4(v.macd),
        macd_signal: n4(v.macdSignal),
        macd_histogram: n4(v.macdHistogram),
        bollinger_upper: n4(v.bollingerUpper),
        bollinger_middle: n4(v.bollingerMiddle),
        bollinger_lower: n4(v.bollingerLower),
        atr_14: n4(v.atr14),
        adx_14: n2(v.adx14),
        stoch_k: n2(v.stochK),
        stoch_d: n2(v.stochD),
        vwap: n4(vwap),
        volume_sma_20: v.volumeSma20 === null ? null : round(v.volumeSma20, 2),
        pivots: sql<string>`${JSON.stringify(pivots ?? {})}::jsonb`,
      }));
      const result = await this.db
        .insertInto('technical_indicators')
        .values(rows)
        .onConflict((oc) =>
          oc.columns(['stock_id', 'data_mode', 'timeframe', 'ts']).doUpdateSet((eb) => ({
            sma_20: eb.ref('excluded.sma_20'),
            sma_50: eb.ref('excluded.sma_50'),
            sma_200: eb.ref('excluded.sma_200'),
            ema_20: eb.ref('excluded.ema_20'),
            ema_50: eb.ref('excluded.ema_50'),
            ema_200: eb.ref('excluded.ema_200'),
            rsi_14: eb.ref('excluded.rsi_14'),
            macd: eb.ref('excluded.macd'),
            macd_signal: eb.ref('excluded.macd_signal'),
            macd_histogram: eb.ref('excluded.macd_histogram'),
            bollinger_upper: eb.ref('excluded.bollinger_upper'),
            bollinger_middle: eb.ref('excluded.bollinger_middle'),
            bollinger_lower: eb.ref('excluded.bollinger_lower'),
            atr_14: eb.ref('excluded.atr_14'),
            adx_14: eb.ref('excluded.adx_14'),
            stoch_k: eb.ref('excluded.stoch_k'),
            stoch_d: eb.ref('excluded.stoch_d'),
            vwap: eb.ref('excluded.vwap'),
            volume_sma_20: eb.ref('excluded.volume_sma_20'),
            pivots: eb.ref('excluded.pivots'),
          })),
        )
        .returning('id')
        .execute();
      written += result.length;
    }
    return written;
  }

  /**
   * The moving averages over a window, for the chart's overlay lines (PRD §3.2).
   *
   * Only the three SMAs: the chart draws those, and selecting every indicator column for a
   * five-year range would move a lot of numbers nobody plots. These are the STORED series — the
   * same ones the decision engine scored — so the overlay can never disagree with the decision
   * card, which recomputing in the browser would eventually do.
   */
  async movingAveragesBetween(
    stockId: string,
    mode: DataMode,
    timeframe: BarInterval,
    from: Date,
    to: Date,
  ): Promise<
    Array<{ ts: Date; sma20: number | null; sma50: number | null; sma200: number | null }>
  > {
    const rows = await this.db
      .selectFrom('technical_indicators')
      .select(['ts', 'sma_20', 'sma_50', 'sma_200'])
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('timeframe', '=', timeframe)
      .where('ts', '>=', from)
      .where('ts', '<=', to)
      .orderBy('ts', 'asc')
      .execute();
    return rows.map((r) => ({
      ts: r.ts,
      sma20: toNumber(r.sma_20),
      sma50: toNumber(r.sma_50),
      sma200: toNumber(r.sma_200),
    }));
  }

  async latest(
    stockId: string,
    mode: DataMode,
    timeframe: BarInterval,
  ): Promise<{ ts: Date; values: IndicatorValues } | null> {
    const r = await this.db
      .selectFrom('technical_indicators')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('timeframe', '=', timeframe)
      .orderBy('ts', 'desc')
      .limit(1)
      .executeTakeFirst();
    if (!r) return null;
    return {
      ts: r.ts,
      values: {
        sma20: toNumber(r.sma_20),
        sma50: toNumber(r.sma_50),
        sma200: toNumber(r.sma_200),
        ema20: toNumber(r.ema_20),
        ema50: toNumber(r.ema_50),
        ema200: toNumber(r.ema_200),
        rsi14: toNumber(r.rsi_14),
        macd: toNumber(r.macd),
        macdSignal: toNumber(r.macd_signal),
        macdHistogram: toNumber(r.macd_histogram),
        bollingerUpper: toNumber(r.bollinger_upper),
        bollingerMiddle: toNumber(r.bollinger_middle),
        bollingerLower: toNumber(r.bollinger_lower),
        atr14: toNumber(r.atr_14),
        adx14: toNumber(r.adx_14),
        stochK: toNumber(r.stoch_k),
        stochD: toNumber(r.stoch_d),
        volumeSma20: toNumber(r.volume_sma_20),
      },
    };
  }
}
