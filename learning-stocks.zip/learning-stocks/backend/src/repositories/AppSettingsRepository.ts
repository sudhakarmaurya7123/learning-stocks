import type { z } from 'zod';
import type { Database } from '../database/db.js';
import { AppError } from '../utils/errors.js';

export class AppSettingsRepository {
  constructor(private readonly db: Database) {}

  async get<T>(key: string, schema: z.ZodType<T>): Promise<T | null> {
    const row = await this.db
      .selectFrom('app_settings')
      .select('value')
      .where('key', '=', key)
      .executeTakeFirst();
    if (!row) return null;
    const parsed = schema.safeParse(row.value);
    if (!parsed.success) {
      throw new AppError('INTERNAL', `app_settings.${key} has an invalid value`, {
        details: { key },
      });
    }
    return parsed.data;
  }
}
