import { sql } from 'kysely';
import type { Database } from '../database/db.js';

export type LlmCallStatus = 'OK' | 'FAILED' | 'INVALID_OUTPUT' | 'BUDGET_EXCEEDED';

export interface LlmCallRecord {
  /** e.g. 'embeddings', 'query_embedding'; Phase 7 adds 'stock_analysis', 'news_sentiment', … */
  purpose: string;
  provider: string;
  model: string;
  promptVersion: string | null;
  inputTokens: number;
  outputTokens: number;
  estCostInr: number;
  latencyMs: number | null;
  cacheHit: boolean;
  status: LlmCallStatus;
  error: string | null;
}

/** One row per model call (tokens + ₹ estimate). The Phase 7 budget sums these. */
export class LlmCallRepository {
  constructor(private readonly db: Database) {}

  async record(r: LlmCallRecord): Promise<string> {
    const row = await this.db
      .insertInto('llm_calls')
      .values({
        purpose: r.purpose,
        provider: r.provider,
        model: r.model,
        prompt_version: r.promptVersion,
        input_tokens: r.inputTokens,
        output_tokens: r.outputTokens,
        est_cost_inr: String(r.estCostInr),
        latency_ms: r.latencyMs === null ? null : Math.round(r.latencyMs),
        cache_hit: r.cacheHit,
        status: r.status,
        error: r.error === null ? null : r.error.slice(0, 1000),
      })
      .returning('id')
      .executeTakeFirstOrThrow();
    return row.id;
  }

  /**
   * Call count, token totals, ₹ spent and cache hits since `since`, for the admin page (PRD §3.4).
   *
   * Aggregated in SQL: the point of the panel is "what has today cost", and summing rows in Node
   * would pull every call of the day across the wire to compute five numbers.
   */
  async usageSince(since: Date): Promise<{
    calls: number;
    inputTokens: number;
    outputTokens: number;
    spentInr: number;
    cacheHits: number;
  }> {
    const row = await this.db
      .selectFrom('llm_calls')
      .select([
        sql<string>`count(*)::text`.as('calls'),
        sql<string>`coalesce(sum(input_tokens), 0)::text`.as('input_tokens'),
        sql<string>`coalesce(sum(output_tokens), 0)::text`.as('output_tokens'),
        sql<string>`coalesce(sum(est_cost_inr), 0)::text`.as('spent_inr'),
        sql<string>`coalesce(sum(case when cache_hit then 1 else 0 end), 0)::text`.as('cache_hits'),
      ])
      .where('created_at', '>=', since)
      .executeTakeFirstOrThrow();
    return {
      calls: Number(row.calls),
      inputTokens: Number(row.input_tokens),
      outputTokens: Number(row.output_tokens),
      spentInr: Math.round(Number(row.spent_inr) * 100) / 100,
      cacheHits: Number(row.cache_hits),
    };
  }

  /** Estimated ₹ spent on calls created at or after `since` (all statuses). */
  async spentSince(since: Date): Promise<number> {
    const row = await this.db
      .selectFrom('llm_calls')
      .select(sql<string>`coalesce(sum(est_cost_inr), 0)::text`.as('total'))
      .where('created_at', '>=', since)
      .executeTakeFirstOrThrow();
    return Number(row.total);
  }
}
