import { type Selectable, sql } from 'kysely';
import type { Database } from '../database/db.js';
import type { DB } from '../database/types.generated.js';
import { toNumber } from '../database/convert.js';
import type {
  ActionState,
  DataMode,
  MarketRegime,
  RecommendationBias,
  RiskLevel,
  Trend,
  ValuationLabel,
} from '../domain/enums.js';
import type { EvaluationRecord } from '../scoring/evaluate.js';
import { AppError } from '../utils/errors.js';

export interface StoredEvaluation {
  id: string;
  evaluatedAt: Date;
  dataAsOf: Date;
  scoringConfigVersion: string;
  actionState: ActionState;
  recommendationBias: RecommendationBias | null;
  overallScore: number | null;
  riskLevel: RiskLevel | null;
  entryLow: number | null;
  entryHigh: number | null;
  stopLoss: number | null;
  target1: number | null;
  target2: number | null;
  riskReward: number | null;
  positionSizeHint: number | null;
  invalidation: string | null;
  inputHash: string;
}

export interface StoredEvaluationDetail extends StoredEvaluation {
  trend: Trend | null;
  valuationLabel: ValuationLabel;
  marketRegime: MarketRegime | null;
  riskScore: number | null;
  scores: {
    technical: number | null;
    quality: number | null;
    valuation: number | null;
    news: number | null;
    momentum: number | null;
    marketContext: number | null;
  };
  /** The engine's `inputs` jsonb (shape owned by scoring/evaluate.ts; parse defensively). */
  inputs: unknown;
  /** Share of factor weight with data (0–1), from factors_available.coverage. */
  coverage: number | null;
}

type EvaluationRow = Selectable<DB['stock_evaluations']>;

function toStored(r: EvaluationRow): StoredEvaluation {
  return {
    id: r.id,
    evaluatedAt: r.evaluated_at,
    dataAsOf: r.data_as_of,
    scoringConfigVersion: r.scoring_config_version,
    actionState: r.action_state,
    recommendationBias: r.recommendation_bias,
    overallScore: toNumber(r.overall_score),
    riskLevel: r.risk_level,
    entryLow: toNumber(r.entry_low),
    entryHigh: toNumber(r.entry_high),
    stopLoss: toNumber(r.stop_loss),
    target1: toNumber(r.target_1),
    target2: toNumber(r.target_2),
    riskReward: toNumber(r.risk_reward),
    positionSizeHint: r.position_size_hint,
    invalidation: r.invalidation,
    inputHash: r.input_hash,
  };
}

function toDetail(r: EvaluationRow): StoredEvaluationDetail {
  const fa = r.factors_available as unknown;
  const coverage =
    fa && typeof fa === 'object' ? (fa as Record<string, unknown>).coverage : undefined;
  return {
    ...toStored(r),
    trend: r.trend,
    valuationLabel: r.valuation_label,
    marketRegime: r.market_regime,
    riskScore: toNumber(r.risk_score),
    scores: {
      technical: toNumber(r.technical_score),
      quality: toNumber(r.quality_score),
      valuation: toNumber(r.valuation_score),
      news: toNumber(r.news_score),
      momentum: toNumber(r.momentum_score),
      marketContext: toNumber(r.market_context_score),
    },
    inputs: r.inputs,
    coverage: typeof coverage === 'number' ? coverage : null,
  };
}

const jsonb = (v: unknown) => sql<string>`${JSON.stringify(v)}::jsonb`;

export class EvaluationRepository {
  constructor(private readonly db: Database) {}

  /** One row per distinct input hash: unchanged inputs never create a new evaluation. */
  async insert(r: EvaluationRecord): Promise<{ id: string; inserted: boolean }> {
    const t = r.trade;
    const row = await this.db
      .insertInto('stock_evaluations')
      .values({
        stock_id: r.stockId,
        data_mode: r.dataMode,
        data_as_of: r.dataAsOf,
        scoring_config_version: r.scoringConfigVersion,
        technical_score: r.scores.technical,
        quality_score: r.scores.quality,
        valuation_score: r.scores.valuation,
        news_score: r.scores.news,
        momentum_score: r.scores.momentum,
        market_context_score: r.scores.marketContext,
        overall_score: r.scores.overall,
        risk_score: r.scores.risk,
        risk_level: r.riskLevel,
        trend: r.trend,
        valuation_label: r.valuationLabel,
        market_regime: r.marketRegime,
        action_state: r.actionState,
        recommendation_bias: r.recommendationBias,
        entry_low: t?.entryLow ?? null,
        entry_high: t?.entryHigh ?? null,
        stop_loss: t?.stop ?? null,
        target_1: t?.target1 ?? null,
        target_2: t?.target2 ?? null,
        risk_reward: t?.riskReward ?? null,
        position_size_hint: t?.positionSizeHint ?? null,
        invalidation: r.invalidation,
        // clock_timestamp(): distinct per row even inside one transaction, so latest() is deterministic.
        evaluated_at: sql`clock_timestamp()`,
        factors_available: jsonb(r.factorsAvailable),
        inputs: jsonb(r.inputs),
        input_hash: r.inputHash,
      })
      .onConflict((oc) => oc.doNothing())
      .returning('id')
      .executeTakeFirst();
    if (row) return { id: row.id, inserted: true };
    const existing = await this.db
      .selectFrom('stock_evaluations')
      .select('id')
      .where('stock_id', '=', r.stockId)
      .where('data_mode', '=', r.dataMode)
      .where('input_hash', '=', r.inputHash)
      .executeTakeFirst();
    if (!existing)
      throw new AppError('INTERNAL', 'Evaluation insert conflicted but no existing row was found');
    return { id: existing.id, inserted: false };
  }

  async latest(stockId: string, mode: DataMode): Promise<StoredEvaluation | null> {
    const r = await this.db
      .selectFrom('stock_evaluations')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .orderBy('evaluated_at', 'desc')
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();
    return r ? toStored(r) : null;
  }

  /** Latest evaluation with factor scores and the stored engine inputs (for explanation and context). */
  async latestDetail(stockId: string, mode: DataMode): Promise<StoredEvaluationDetail | null> {
    const r = await this.db
      .selectFrom('stock_evaluations')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .orderBy('evaluated_at', 'desc')
      .orderBy('created_at', 'desc')
      .limit(1)
      .executeTakeFirst();
    return r ? toDetail(r) : null;
  }

  /** Latest evaluation of every stock in a mode (market breadth, signals). */
  async latestForAll(mode: DataMode): Promise<Array<StoredEvaluationDetail & { stockId: string }>> {
    const rows = await this.db
      .selectFrom('stock_evaluations')
      .selectAll()
      .distinctOn('stock_id')
      .where('data_mode', '=', mode)
      .orderBy('stock_id')
      .orderBy('evaluated_at', 'desc')
      .orderBy('created_at', 'desc')
      .execute();
    return rows.map((r) => ({ ...toDetail(r), stockId: r.stock_id }));
  }
}
