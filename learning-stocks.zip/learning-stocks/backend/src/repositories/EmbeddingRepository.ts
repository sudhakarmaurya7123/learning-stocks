import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DataMode } from '../domain/enums.js';
import { EMBEDDING_DIMENSIONS } from '../providers/llm/types.js';
import { AppError } from '../utils/errors.js';

export const SOURCE_TYPES = ['NEWS', 'FINANCIALS', 'AI_ANALYSIS', 'MARKET_SUMMARY'] as const;
export type SourceType = (typeof SOURCE_TYPES)[number];

export interface EmbeddingRow {
  dataMode: DataMode;
  sourceType: SourceType;
  sourceId: string;
  /** null = market-level document (no stock mention above the relevance threshold). */
  stockId: string | null;
  chunkIndex: number;
  content: string;
  contentHash: string;
  embedding: readonly number[];
  embeddingModel: string;
  metadata: Record<string, unknown>;
  publishedAt: Date | null;
}

export interface PendingNews {
  newsId: string;
  title: string;
  description: string | null;
  content: string | null;
  source: string;
  sourceUrl: string;
  publishedAt: Date;
  /** Only the targets that still lack a row for this model. */
  targets: Array<{ stockId: string | null; relevance: number | null }>;
}

export interface StoredChunk {
  sourceId: string;
  stockId: string | null;
  chunkIndex: number;
  contentHash: string;
}

export interface MatchParams {
  query: readonly number[];
  dataMode: DataMode;
  stockId: string | null;
  since: Date | null;
  k: number;
  sourceTypes: readonly SourceType[] | null;
  embeddingModel: string;
  marketOnly?: boolean;
}

export interface MatchedDocument {
  id: string;
  sourceType: SourceType;
  sourceId: string;
  stockId: string | null;
  content: string;
  metadata: Record<string, unknown>;
  publishedAt: Date | null;
  similarity: number;
}

const WRITE_CHUNK = 50;
export const toVectorLiteral = (v: readonly number[]): string => `[${v.join(',')}]`;
const parseVector = (text: string): number[] => JSON.parse(text) as number[];
const asRecord = (v: unknown): Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v) ? (v as Record<string, unknown>) : {};

export class EmbeddingRepository {
  constructor(private readonly db: Database) {}

  /**
   * News targets lacking a row for this model, newest first: one per stock mention ≥ threshold; else one
   * market-level target when a market mention ≥ threshold exists. Articles with neither are never embedded.
   */
  async pendingNews(
    mode: DataMode,
    model: string,
    minRelevance: number,
    limit: number,
  ): Promise<PendingNews[]> {
    const { rows: targets } = await sql<{
      news_id: string;
      stock_id: string | null;
      relevance: string | null;
    }>`
      with qualifying as (
        select m.news_id, m.stock_id, m.market_id, m.relevance_score
          from public.news_mentions m
          join public.news n on n.id = m.news_id
         where n.data_mode = ${mode} and m.relevance_score >= ${minRelevance}),
      targets as (
        select q.news_id, q.stock_id, q.relevance_score as relevance
          from qualifying q
         where q.stock_id is not null
        union all
        -- Market-level only for articles about an index/VIX and no stock; never for weak (query-only) matches.
        select q.news_id, null::uuid, max(q.relevance_score)
          from qualifying q
         where q.market_id is not null
           and not exists (select 1 from qualifying s where s.news_id = q.news_id and s.stock_id is not null)
         group by q.news_id)
      select t.news_id, t.stock_id, t.relevance::text as relevance
        from targets t
       where not exists (select 1 from public.document_embeddings d
                          where d.source_type = 'NEWS' and d.source_id = t.news_id and d.chunk_index = 0
                            and d.embedding_model = ${model}
                            and d.stock_id is not distinct from t.stock_id)`.execute(this.db);
    if (targets.length === 0) return [];
    const byNews = new Map<string, PendingNews['targets']>();
    for (const t of targets) {
      const list = byNews.get(t.news_id) ?? [];
      list.push({
        stockId: t.stock_id,
        relevance: t.relevance === null ? null : toNumber(t.relevance),
      });
      byNews.set(t.news_id, list);
    }
    const articles = await this.db
      .selectFrom('news')
      .select(['id', 'title', 'description', 'content', 'source', 'source_url', 'published_at'])
      .where('id', 'in', [...byNews.keys()])
      .orderBy('published_at', 'desc')
      .orderBy('id')
      .limit(Math.max(1, limit))
      .execute();
    return articles.map((a) => ({
      newsId: a.id,
      title: a.title,
      description: a.description,
      content: a.content,
      source: a.source,
      sourceUrl: a.source_url,
      publishedAt: a.published_at,
      targets: (byNews.get(a.id) ?? []).sort((x, y) =>
        (x.stockId ?? '').localeCompare(y.stockId ?? ''),
      ),
    }));
  }

  async chunkHashes(
    mode: DataMode,
    model: string,
    sourceType: SourceType,
    sourceIds: readonly string[],
  ): Promise<StoredChunk[]> {
    if (sourceIds.length === 0) return [];
    const rows = await this.db
      .selectFrom('document_embeddings')
      .select(['source_id', 'stock_id', 'chunk_index', 'content_hash'])
      .where('data_mode', '=', mode)
      .where('embedding_model', '=', model)
      .where('source_type', '=', sourceType)
      .where('source_id', 'in', [...sourceIds])
      .orderBy('source_id')
      .orderBy('stock_id')
      .orderBy('chunk_index')
      .execute();
    return rows.map((r) => ({
      sourceId: r.source_id,
      stockId: r.stock_id,
      chunkIndex: r.chunk_index,
      contentHash: r.content_hash,
    }));
  }

  /** Existing vectors for these chunk hashes (same mode and model): never embed the same text twice. */
  async vectorsByHash(
    mode: DataMode,
    model: string,
    hashes: readonly string[],
  ): Promise<Map<string, number[]>> {
    if (hashes.length === 0) return new Map();
    const rows = await this.db
      .selectFrom('document_embeddings')
      .select(['content_hash', sql<string>`embedding::text`.as('vector')])
      .distinctOn('content_hash')
      .where('data_mode', '=', mode)
      .where('embedding_model', '=', model)
      .where('content_hash', 'in', [...hashes])
      .orderBy('content_hash')
      .execute();
    return new Map(rows.map((r) => [r.content_hash, parseVector(r.vector)]));
  }

  async upsertChunks(rows: readonly EmbeddingRow[]): Promise<number> {
    for (const r of rows) {
      if (r.embedding.length !== EMBEDDING_DIMENSIONS) {
        throw new AppError(
          'INVALID_RESPONSE',
          `Embedding for ${r.sourceType}/${r.sourceId} has ${r.embedding.length} dimensions, expected ${EMBEDDING_DIMENSIONS}`,
        );
      }
    }
    let written = 0;
    for (let i = 0; i < rows.length; i += WRITE_CHUNK) {
      const result = await this.db
        .insertInto('document_embeddings')
        .values(
          rows.slice(i, i + WRITE_CHUNK).map((r) => ({
            data_mode: r.dataMode,
            source_type: r.sourceType,
            source_id: r.sourceId,
            stock_id: r.stockId,
            chunk_index: r.chunkIndex,
            content: r.content,
            content_hash: r.contentHash,
            embedding: sql<string>`${toVectorLiteral(r.embedding)}::extensions.vector`,
            embedding_model: r.embeddingModel,
            metadata: sql<string>`${JSON.stringify(r.metadata)}::jsonb`,
            published_at: r.publishedAt,
          })),
        )
        .onConflict((oc) =>
          oc.constraint('document_embeddings_chunk_stock_uq').doUpdateSet((eb) => ({
            content: eb.ref('excluded.content'),
            content_hash: eb.ref('excluded.content_hash'),
            embedding: eb.ref('excluded.embedding'),
            metadata: eb.ref('excluded.metadata'),
            published_at: eb.ref('excluded.published_at'),
          })),
        )
        .returning('id')
        .execute();
      written += result.length;
    }
    return written;
  }

  /** After re-chunking, drop chunk rows beyond the new chunk count for one (source, stock). */
  async deleteSurplusChunks(
    sourceType: SourceType,
    sourceId: string,
    stockId: string | null,
    model: string,
    keep: number,
  ): Promise<void> {
    await this.db
      .deleteFrom('document_embeddings')
      .where('source_type', '=', sourceType)
      .where('source_id', '=', sourceId)
      .where('embedding_model', '=', model)
      .where(sql<boolean>`stock_id is not distinct from ${stockId}::uuid`)
      .where('chunk_index', '>=', keep)
      .execute();
  }

  /** A source that now has stock rows no longer needs its market-level placeholder. */
  async deleteMarketRows(sourceType: SourceType, sourceId: string, model: string): Promise<void> {
    await this.db
      .deleteFrom('document_embeddings')
      .where('source_type', '=', sourceType)
      .where('source_id', '=', sourceId)
      .where('embedding_model', '=', model)
      .where('stock_id', 'is', null)
      .execute();
  }

  async match(p: MatchParams): Promise<MatchedDocument[]> {
    const types = p.sourceTypes ? sql`${[...p.sourceTypes]}::text[]` : sql`null::text[]`;
    const { rows } = await sql<{
      id: string;
      source_type: SourceType;
      source_id: string;
      stock_id: string | null;
      content: string;
      metadata: unknown;
      published_at: Date | null;
      similarity: number;
    }>`select * from public.match_documents(
          ${toVectorLiteral(p.query)}::extensions.vector, ${p.dataMode}::public.data_mode, ${p.stockId}::uuid,
          ${p.since}::timestamptz, ${p.k}::integer, ${types}, ${p.embeddingModel}::text, ${p.marketOnly ?? false}::boolean)`.execute(
      this.db,
    );
    return rows.map((r) => ({
      id: r.id,
      sourceType: r.source_type,
      sourceId: r.source_id,
      stockId: r.stock_id,
      content: r.content,
      metadata: asRecord(r.metadata),
      publishedAt: r.published_at,
      similarity: Number(r.similarity),
    }));
  }

  async vectorsByIds(ids: readonly string[]): Promise<Map<string, number[]>> {
    if (ids.length === 0) return new Map();
    const rows = await this.db
      .selectFrom('document_embeddings')
      .select(['id', sql<string>`embedding::text`.as('vector')])
      .where('id', 'in', [...ids])
      .execute();
    return new Map(rows.map((r) => [r.id, parseVector(r.vector)]));
  }
}
