import { sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DataMode, ImpactLevel, Sentiment } from '../domain/enums.js';

const jsonb = (v: unknown) => sql<string>`${JSON.stringify(v)}::jsonb`;

export interface SentimentTarget {
  newsId: string;
  /** null = market-level (an index/VIX mention and no qualifying stock mention). */
  stockId: string | null;
  symbol: string | null;
  companyName: string | null;
  relevance: number;
  title: string;
  description: string | null;
  content: string | null;
  source: string;
  publishedAt: Date;
}

export interface NewsSentimentRecord {
  newsId: string;
  stockId: string | null;
  sentiment: Sentiment;
  sentimentScore: number;
  confidence: number;
  relevanceScore: number;
  impactLevel: ImpactLevel;
  summary: string;
  positiveFactors: string[];
  negativeFactors: string[];
  reasoning: string[];
  model: string;
  promptVersion: string;
}

export class NewsAnalysisRepository {
  constructor(private readonly db: Database) {}

  /** (article, subject) pairs that still need sentiment under this prompt version; weak matches are never sent. */
  async pending(
    mode: DataMode,
    promptVersion: string,
    minRelevance: number,
    limit: number,
  ): Promise<SentimentTarget[]> {
    const { rows } = await sql<{
      news_id: string;
      stock_id: string | null;
      relevance: string;
      title: string;
      description: string | null;
      content: string | null;
      source: string;
      published_at: Date;
      symbol: string | null;
      company_name: string | null;
    }>`
      with qualifying as (
        select m.news_id, m.stock_id, m.market_id, m.relevance_score
          from public.news_mentions m
          join public.news n on n.id = m.news_id
         where n.data_mode = ${mode} and m.relevance_score >= ${minRelevance}),
      targets as (
        select q.news_id, q.stock_id, q.relevance_score as relevance from qualifying q where q.stock_id is not null
        union all
        select q.news_id, null::uuid, max(q.relevance_score)
          from qualifying q
         where q.market_id is not null
           and not exists (select 1 from qualifying s where s.news_id = q.news_id and s.stock_id is not null)
         group by q.news_id)
      select t.news_id, t.stock_id, t.relevance::text as relevance, n.title, n.description, n.content, n.source,
             n.published_at, s.symbol, s.company_name
        from targets t
        join public.news n on n.id = t.news_id
        left join public.stocks s on s.id = t.stock_id
       where not exists (select 1 from public.news_ai_analysis a
                          where a.news_id = t.news_id and a.stock_id is not distinct from t.stock_id
                            and a.prompt_version = ${promptVersion})
       order by n.published_at desc, t.news_id, t.stock_id nulls last
       limit ${Math.max(1, limit)}`.execute(this.db);
    return rows.map((r) => ({
      newsId: r.news_id,
      stockId: r.stock_id,
      symbol: r.symbol,
      companyName: r.company_name,
      relevance: toNumber(r.relevance) ?? 0,
      title: r.title,
      description: r.description,
      content: r.content,
      source: r.source,
      publishedAt: r.published_at,
    }));
  }

  async insert(r: NewsSentimentRecord): Promise<boolean> {
    const row = await this.db
      .insertInto('news_ai_analysis')
      .values({
        news_id: r.newsId,
        stock_id: r.stockId,
        sentiment: r.sentiment,
        sentiment_score: r.sentimentScore,
        confidence: r.confidence,
        relevance_score: r.relevanceScore,
        impact_level: r.impactLevel,
        summary: r.summary,
        positive_factors: jsonb(r.positiveFactors),
        negative_factors: jsonb(r.negativeFactors),
        reasoning: jsonb(r.reasoning),
        model: r.model,
        prompt_version: r.promptVersion,
      })
      .onConflict((oc) => oc.constraint('news_ai_analysis_once').doNothing())
      .returning('id')
      .executeTakeFirst();
    return row !== undefined;
  }

  /** Market-level (stock_id null) sentiment since a date: latest analysis per article. */
  async marketSentiments(
    mode: DataMode,
    since: Date,
  ): Promise<
    Array<{ sentiment: Sentiment; sentimentScore: number; relevance: number; publishedAt: Date }>
  > {
    const rows = await this.db
      .selectFrom('news_ai_analysis as a')
      .innerJoin('news as n', 'n.id', 'a.news_id')
      .select([
        'a.news_id',
        'a.sentiment',
        'a.sentiment_score',
        'a.relevance_score',
        'n.published_at',
      ])
      .distinctOn('a.news_id')
      .where('a.stock_id', 'is', null)
      .where('n.data_mode', '=', mode)
      .where('n.published_at', '>=', since)
      .orderBy('a.news_id')
      .orderBy('a.created_at', 'desc')
      .execute();
    return rows
      .map((r) => ({
        sentiment: r.sentiment,
        sentimentScore: toNumber(r.sentiment_score) ?? 50,
        relevance: toNumber(r.relevance_score) ?? 0,
        publishedAt: r.published_at,
      }))
      .sort((x, y) => y.publishedAt.getTime() - x.publishedAt.getTime());
  }
}
