import { type Selectable, sql } from 'kysely';
import type { Database } from '../database/db.js';
import { toNumber } from '../database/convert.js';
import type { DB } from '../database/types.generated.js';
import type { DataMode } from '../domain/enums.js';

export type SignalStatus = 'ACTIVE' | 'TRIGGERED' | 'EXPIRED' | 'INVALIDATED';

export interface TradeSignalRecord {
  stockId: string;
  analysisId: string | null;
  evaluationId: string | null;
  dataMode: DataMode;
  signal: 'BUY' | 'SELL';
  confidence: number;
  entryPrice: number | null;
  entryLow: number | null;
  entryHigh: number | null;
  targetPrice: number | null;
  target2: number | null;
  stopLoss: number | null;
  riskRewardRatio: number | null;
  suggestedQuantity: number | null;
  reasoning: string[];
  validUntil: Date;
}

export interface StoredTradeSignal extends TradeSignalRecord {
  id: string;
  status: SignalStatus;
  createdAt: Date;
}

function toStored(r: Selectable<DB['ai_trade_signals']>): StoredTradeSignal {
  return {
    id: r.id,
    status: r.status,
    createdAt: r.created_at,
    stockId: r.stock_id,
    analysisId: r.analysis_id,
    evaluationId: r.evaluation_id,
    dataMode: r.data_mode,
    signal: r.signal === 'SELL' ? 'SELL' : 'BUY',
    confidence: toNumber(r.confidence) ?? 0,
    entryPrice: toNumber(r.entry_price),
    entryLow: toNumber(r.entry_low),
    entryHigh: toNumber(r.entry_high),
    targetPrice: toNumber(r.target_price),
    target2: toNumber(r.target_2),
    stopLoss: toNumber(r.stop_loss),
    riskRewardRatio: toNumber(r.risk_reward_ratio),
    suggestedQuantity: r.suggested_quantity,
    reasoning: Array.isArray(r.reasoning)
      ? r.reasoning.filter((x): x is string => typeof x === 'string')
      : [],
    validUntil: r.valid_until,
  };
}

/** Paper-trade signal rows. Never places orders. */
export class TradeSignalRepository {
  constructor(private readonly db: Database) {}

  async active(stockId: string, mode: DataMode): Promise<StoredTradeSignal[]> {
    const rows = await this.db
      .selectFrom('ai_trade_signals')
      .selectAll()
      .where('stock_id', '=', stockId)
      .where('data_mode', '=', mode)
      .where('status', '=', 'ACTIVE')
      .orderBy('created_at', 'desc')
      .execute();
    return rows.map(toStored);
  }

  async create(r: TradeSignalRecord): Promise<string> {
    const row = await this.db
      .insertInto('ai_trade_signals')
      .values({
        stock_id: r.stockId,
        analysis_id: r.analysisId,
        evaluation_id: r.evaluationId,
        data_mode: r.dataMode,
        signal: r.signal,
        confidence: r.confidence,
        entry_price: r.entryPrice,
        entry_low: r.entryLow,
        entry_high: r.entryHigh,
        target_price: r.targetPrice,
        target_2: r.target2,
        stop_loss: r.stopLoss,
        risk_reward_ratio: r.riskRewardRatio,
        suggested_quantity: r.suggestedQuantity,
        reasoning: sql<string>`${JSON.stringify(r.reasoning)}::jsonb`,
        valid_until: r.validUntil,
      })
      .returning('id')
      .executeTakeFirstOrThrow();
    return row.id;
  }

  async setStatus(ids: readonly string[], status: SignalStatus): Promise<void> {
    if (ids.length === 0) return;
    await this.db
      .updateTable('ai_trade_signals')
      .set({ status })
      .where('id', 'in', [...ids])
      .execute();
  }

  async expire(mode: DataMode, now: Date): Promise<number> {
    const r = await this.db
      .updateTable('ai_trade_signals')
      .set({ status: 'EXPIRED' })
      .where('data_mode', '=', mode)
      .where('status', '=', 'ACTIVE')
      .where('valid_until', '<', now)
      .executeTakeFirst();
    return Number(r.numUpdatedRows);
  }
}
