# AI Stock Research & Paper Trading (India: NSE/BSE)

A personal research and decision-support platform for Indian stocks. Market data, technical indicators, fundamentals and news feed a deterministic scoring engine: entry zone, stop-loss, targets, risk/reward and an action state such as _buy zone_ or _wait for pullback_. An LLM explains those numbers with cited evidence. Ideas can be tested with ₹10,00,000 of virtual money.

> **Disclaimer:** AI analysis for personal research and paper trading only. Not investment advice. No outcome is guaranteed. No real orders are ever placed.

- Product spec: [PRD.md](PRD.md)
- Build plan and phase status: [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)
- Architecture: [docs/architecture.md](docs/architecture.md)
- Database: [docs/database.md](docs/database.md)

## Status

| Phase | What                                                                           | State   |
| ----- | ------------------------------------------------------------------------------ | ------- |
| 1     | Database (Supabase Postgres + pgvector, migrations, seeds, pgTAP tests)        | ✅      |
| 2     | Backend foundation (config, logging, DB layer, market calendar, health API)    | ✅      |
| 3     | Market data: mock simulator + Yahoo (NSE/BSE), validated ingestion, CLIs       | ✅      |
| 4     | News (mock/RSS/NewsAPI) + fundamentals (mock/Yahoo), mention matching, CLIs    | ✅      |
| 5     | Indicators, levels, valuation, factor scores, decision engine, `pnpm evaluate` | ✅      |
| 6     | Embeddings, retrieval, context builder, citation check, `pnpm embed`           | ✅      |
| 7     | AI sentiment, analysis, market summary, paper signals, Q&A, ₹ budget           | ✅      |
| 8     | Scheduled jobs: pg-boss worker on IST crons, calendar gates, chains, run log   | ✅      |
| 9     | REST API: 16 reads, 7 actions, JWT + roles, rate limits, aggregate, status     | ✅      |
| 10    | Dashboard UI                                                                   | ⏳ next |
| 11    | Paper trading                                                                  | ⏳      |

There is no web UI yet, but the API is complete: `pnpm dev` serves the whole research desk over HTTP, `pnpm worker` keeps it fresh on an IST schedule, and `GET /api/stocks/RELIANCE` returns the entire decision — quote, indicators, fundamentals, valuation, action state with entry/stop/targets, news, sentiment, AI analysis and market context — in one call.

## Prerequisites

- **Node.js ≥ 22.9**, **pnpm 11**, and **Docker Desktop** (running).

## Setup (once)

```bash
pnpm install
cp .env.example .env    # defaults run fully in mock mode; no API keys needed
```

## Run

```bash
pnpm db:start           # local Supabase in Docker (first run downloads images)
pnpm db:reset           # apply migrations + seed data (20 stocks, indices, 2026 holidays)
pnpm dev                # backend API on http://127.0.0.1:4000 (auto-reloads)
```

Check it:

```bash
curl http://127.0.0.1:4000/api/health
```

The response shows the database status, data mode (`MOCK`), the selected providers, and whether NSE is open right now (with the next session start).

**Supabase Studio** (browse tables, run SQL) is at http://127.0.0.1:54323. Stop the database with `pnpm db:stop`; data is kept until the next `pnpm db:reset`.

## Load market data

```bash
pnpm sync:market                                  # daily bars, last 5 years, all 20 stocks + 12 indices
pnpm sync:market --timeframe 5m --days 5          # intraday 5-minute bars (also 15m; Yahoo also 1m)
pnpm sync:market --symbols RELIANCE,TCS --days 30 # a subset (internal symbols)
pnpm sync:market --timeframe 5m --if-open         # only if NSE is open right now (for schedulers)
```

Each run prints a summary and writes one row to `system_logs`. Re-running is safe: existing bars are skipped, never duplicated. Only **completed** bars are stored: 5-minute bars once they end, and daily bars 30 minutes after the close. Invalid provider bars (bad OHLC, holiday bars with prices, bars outside the session) are rejected and counted. One failing symbol never stops the others.

In mock mode the data comes from a deterministic simulator (synthetic prices, labelled `MOCK`). For real NSE/BSE data from Yahoo Finance (unofficial and delayed), see live mode below.

### Verify the Yahoo symbol mappings

```bash
pnpm verify:symbols   # network: checks each yahoo ticker returns ≥ 200 days of real daily history
```

**Known limitation:** Yahoo has **no daily history** for six sector indices: NIFTY FMCG, NIFTY FINANCIAL SERVICES, NIFTY AUTO, NIFTY METAL, NIFTY REALTY and NIFTY ENERGY (only a same-day snapshot), so they are marked unverified. Their recent 5-minute bars are available, and each daily sync stores that day's snapshot, so daily history accumulates from now on. Stocks, NIFTY 50, SENSEX, BANK NIFTY, NIFTY IT, NIFTY PHARMA and INDIA VIX have full history (26/32 verified on 2026-10-05).

**Holiday calendar:** exchange holidays are loaded for 2026. For older years the system trusts the provider: a priced bar on a weekend (e.g. the Budget-Saturday session) is stored and the run notes it. Load past years' holidays with `scripts/nse/holidays-to-sql.mjs` to tighten validation.

## Load news and fundamentals

```bash
pnpm sync:news                               # last 2 days: market feeds + one search per stock
pnpm sync:news --days 7 --symbols RELIANCE,TCS
pnpm sync:news --no-market                   # stock searches only
pnpm sync:fundamentals                       # snapshot (P/E, ROE, margins…) + quarterly/annual results
pnpm sync:fundamentals --symbols RELIANCE --no-statements
```

Each article is linked to the stocks and indices it mentions, with a relevance score (0–1) and the reason (`name:title`, `alias:description`, `query`, …). The same story from two sources (e.g. Google News and the publisher's own feed) is stored once. Fundamentals are refreshed in place: one snapshot per stock per IST day, and results are updated if a company restates them. Every run writes one `system_logs` row; one failing feed or stock never stops the others.

Live sources (personal use):

```bash
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=rss FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none \
  pnpm sync:news --days 3 --symbols RELIANCE,HDFCBANK
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=rss FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none \
  pnpm sync:fundamentals --symbols RELIANCE,HDFCBANK,INFY
```

See them in Supabase Studio (SQL editor):

```sql
-- latest news per stock with relevance
select s.symbol, n.published_at at time zone 'Asia/Kolkata' as ist, m.relevance_score, m.matched_by, n.source, n.title
from news_mentions m join news n on n.id = m.news_id join stocks s on s.id = m.stock_id
where n.data_mode = 'LIVE' order by n.published_at desc limit 30;

-- latest fundamentals snapshot per stock
select distinct on (s.symbol) s.symbol, f.as_of, f.pe, f.pb, f.roe, f.debt_to_equity, f.dividend_yield, f.source
from fundamental_snapshots f join stocks s on s.id = f.stock_id
where f.data_mode = 'LIVE' order by s.symbol, f.as_of desc;
```

**Known limitations:**

- **Non-INR reporters.** Some companies report to Yahoo in another currency (INFY: USD). For them, revenue, profit and cash-flow amounts stay empty and quarterly/annual results are skipped; per-share and ratio fields (P/E, P/B, ROE, margins) are kept. The run notes it.
- **Yahoo has no ROCE**, so it stays empty (never estimated). Yahoo's revenue/profit growth is the latest quarter vs the same quarter a year ago.
- **Google News links** are Google redirect URLs.
- **RSS feeds** (Google News, Economic Times, Mint, Business Standard) are for personal use only.
- **NewsAPI free tier:** 100 requests/day, articles delayed 24 h. One full sync uses 3 requests (10 companies per query).

## Evaluate stocks

```bash
pnpm evaluate                          # all 20 stocks
pnpm evaluate --symbols RELIANCE,TCS   # a subset
```

Each row shows the action state, bias, overall score (0–100), latest daily close, entry zone, stop-loss, first target and risk/reward, followed by the **invalidation** line: what would make this view wrong, with the price.

| State                   | Meaning                                                                                                   |
| ----------------------- | --------------------------------------------------------------------------------------------------------- |
| `BUY_ZONE`              | All conditions met: good score, price inside the entry zone, R:R ≥ 2, not overvalued, market not risk-off |
| `WAIT_FOR_PULLBACK`     | Good stock, but the price is stretched (far above the 50-day average, RSI > 70, or above the entry zone)  |
| `WAIT_FOR_CONFIRMATION` | In a downtrend or below the 200-day average: wait for the trend to turn                                   |
| `HOLD`                  | Nothing compelling either way (e.g. R:R below 2, or price between zones)                                  |
| `AVOID` / `REDUCE`      | Weak overall setup (`REDUCE` if you hold a paper position)                                                |
| `INSUFFICIENT_DATA`     | Fewer than 200 daily bars, or the latest close is more than 3 sessions old; no levels are given           |

Every run computes indicators for the full daily history (`technical_indicators`), stores one evaluation per stock in `stock_evaluations` with all inputs and component scores (`inputs`), and writes one `system_logs` row. Unchanged inputs create no new row. Evaluations use the **latest daily close**; sync market data first.

For live data, sync about 700 days of daily bars first (the 200-day average needs history):

```bash
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm sync:market --days 700
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm sync:fundamentals
MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=none pnpm evaluate
```

Latest evaluation per stock in Studio:

```sql
select distinct on (s.symbol) s.symbol, e.action_state, e.recommendation_bias, e.overall_score, e.entry_low, e.entry_high,
       e.stop_loss, e.target_1, e.risk_reward, e.invalidation
from stock_evaluations e join stocks s on s.id = e.stock_id
where e.data_mode = 'LIVE' order by s.symbol, e.evaluated_at desc;
```

**Known limitations:**

- The **news factor is empty until Phase 7** (it needs LLM sentiment); the overall score uses the other five factors.
- In live mode, six sector indices have no Yahoo history, so their sector-trend and relative-strength inputs are empty.
- IT stocks have too few peers (3) for a sector valuation comparison; INFY's valuation uses Yahoo's current P/E.
- `BUY_ZONE` is deliberately rare: the rules require R:R ≥ 2 with a stop 1.5 × ATR below support. Thresholds live in `scoring_configs` (versioned) if you want to tune them.

## Embeddings and retrieval

Apply new migrations without wiping data (use this instead of `db:reset` once you have synced live data):

```bash
pnpm db:migrate
```

Embed stored news and financial-results summaries, then look at the context the AI will receive for a stock:

```bash
pnpm embed                                   # new or changed documents only (max 500 per run)
pnpm embed --sources financials --max 100
pnpm rag:context RELIANCE                    # numbered blocks + retrieved documents
pnpm rag:context RELIANCE --query "debt and refinancing risk" --no-market
```

- **What is embedded:** each article once per stock it is about (mention relevance ≥ `news_relevance_threshold`, 0.5), or once as market news when it is about an index/VIX. Articles with only weak (query-only) matches are not embedded. Each stock's last 8 quarterly and 5 annual statements become deterministic text summaries (₹ crore, YoY).
- **No duplicate spend:** identical text is embedded once and reused; a re-run embeds nothing new. A restated statement is re-embedded automatically.
- **The context** (`[Q1]` quote, `[P1]` performance, `[T1]` technicals, `[F1]` fundamentals, `[R1]`/`[R2]` latest quarterly/annual results, `[V1]` valuation, `[E1]` evaluation and levels, `[M1]` market context, `[N1…N8]` documents) carries an as-of time per block. Numbers come only from the structured blocks; retrieved text is quoted as data. Missing blocks are listed as `INSUFFICIENT_DATA`.
- **Live (OpenAI):** set `LLM_PROVIDER=openai`, `OPENAI_API_KEY` and `LLM_MODEL` in `.env`, then e.g.
  `MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=rss FUNDAMENTALS_PROVIDER=yahoo LLM_PROVIDER=openai pnpm embed`.
  Every call is recorded in `llm_calls` with tokens and an estimated ₹ cost (`USD_INR_RATE`, default 88). At the last known list price for `text-embedding-3-small` ($0.02 per 1M tokens — verify on OpenAI's pricing page) that is about ₹1.76 per 1M tokens; today's whole corpus is well under ₹1. `pnpm --filter @learning-stocks/backend test:live:openai` runs a tiny paid smoke test.

```sql
select purpose, status, count(*), sum(est_cost_inr) from llm_calls group by 1, 2;
select data_mode, source_type, embedding_model, count(*) from document_embeddings group by 1, 2, 3;
```

## AI analysis

The AI explains what the code computed; it never decides. Scores, trend, risk level, recommendation bias, regime, entry zone, stop-loss, targets and quantities always come from the evaluation, whatever the model writes. Outputs are labelled `[MOCK]` in mock mode.

Run in this order (each step is cheap to repeat — unchanged inputs make no model call):

```bash
pnpm sync:market && pnpm sync:news && pnpm sync:fundamentals
pnpm evaluate && pnpm embed
pnpm ai:sentiment            # news sentiment per article and stock (max 50 per run; repeat until 0 pending)
pnpm evaluate                # the news factor now has input
pnpm ai:analyze              # AI analysis per stock (--symbols RELIANCE,TCS, --force to regenerate)
pnpm ai:market               # AI market sentiment, regime and drivers
pnpm ai:signals              # paper trade signals (BUY_ZONE → BUY, REDUCE → SELL); never place orders
pnpm ai:ask RELIANCE "What is driving this stock?"
pnpm ai:budget               # today's spend vs the daily budget, by purpose
```

- **What is cached:** an analysis per `(stock, input hash, prompt version)` — the hash covers the prompt text, the context and the model; a market summary per input hash; a Q&A answer per `(stock, normalised question, context)`; a sentiment per `(article, stock, prompt version)`. Analyses wait at least `analysis_min_interval_minutes` (30) between runs unless forced. With news sentiment present, evaluations (and analyses) change once a day because news ages — about 20 analyses a day.
- **Guards:** every answer is checked for banned phrases ("guaranteed", "risk-free", …), ₹ amounts not in the context, citations of blocks that were not given, and a sentiment contradicting the computed bias. A failing answer gets one repair attempt; then the analysis is stored as `FAILED` (a later run with the same inputs replaces it).
- **Budget:** `app_settings.llm_daily_budget_inr` (₹100; editable without restart; `LLM_DAILY_BUDGET_INR` is only the fallback). The day starts at IST midnight and every call counts (chat, embeddings, query embeddings, repair attempts). When it is reached, calls stop, cached results are served, and `pnpm ai:budget` shows `LLM_BUDGET_EXHAUSTED`. Signals are still created, with a code-written explanation.
- **Live (OpenAI):** `LLM_PROVIDER=openai`, `OPENAI_API_KEY`, `LLM_MODEL` (e.g. `gpt-5-mini`). Models missing from the price table need `LLM_PRICE_INPUT_USD_PER_M` and `LLM_PRICE_OUTPUT_USD_PER_M`. Estimated costs at last known (unverified) list prices with a mini-class model: ≈ ₹0.06 per article sentiment, ≈ ₹0.30 per stock analysis, ≈ ₹0.3 per market summary, ≈ ₹0.2 per uncached question; the first live sentiment pass over ~245 articles ≈ ₹15. `pnpm --filter @learning-stocks/backend test:live:openai` checks that OpenAI accepts every output format (well under ₹1).

## Use the API

```bash
pnpm dev                                   # http://127.0.0.1:4000
curl -s localhost:4000/api/health | jq .
```

Reads need a token. For local work, put `AUTH_MODE=none` in `.env` and every request is treated as OWNER:

```bash
curl -s localhost:4000/api/stocks/RELIANCE | jq '.data | keys'
curl -s localhost:4000/api/stocks/RELIANCE | jq '.data.decision'
curl -s localhost:4000/api/system-status | jq '.data'
curl -s -X POST localhost:4000/api/sync/market -H 'content-type: application/json' -d '{}' | jq .
```

`AUTH_MODE=none` is fenced in: it is **refused** with `MOCK_DATA=false`, **refused** when `HOST` is not loopback, and logs a warning on every startup. It exists so the Phase 10 dashboard works before you set up auth — not as a way to run this open.

**For a real token**, sign up once through Supabase Auth. Phase 1's trigger makes the **first** user OWNER (everyone after is VIEWER) and creates both paper accounts, so there is nothing else to configure:

```bash
curl -s http://127.0.0.1:54321/auth/v1/signup \
  -H "apikey: $SUPABASE_ANON_KEY" -H 'content-type: application/json' \
  -d '{"email":"you@example.com","password":"a-long-password"}' | jq -r .access_token
# then
curl -s localhost:4000/api/stocks -H "Authorization: Bearer $TOKEN" | jq '.data[0]'
```

Then drop `AUTH_MODE` from `.env` (it defaults to `jwt`) and set `JWT_SECRET` (local) or leave `SUPABASE_URL` set (cloud JWKS).

A few things worth knowing:

- **No read route ever calls the LLM.** PRD §14's first rule is that a page load never spends money, and a test hits every GET route with an LLM provider that throws, asserting zero calls — so a future read route that reaches for the retriever fails in CI rather than on your OpenAI bill.
- **A sync returns `202` immediately.** If `worker.status` in `/system-status` is `down`, nothing will run it — start `pnpm worker`.
- **Missing data is a 200 with `null`.** A stock nobody has analysed yet renders an empty panel rather than an error.
- **Rate limits are per user**, not per IP, so one caller cannot exhaust another's quota.
- `/portfolio` and `/paper-trade/*` arrive in Phase 11. Nothing here places an order.

Full route table, error codes and examples: [docs/api.md](docs/api.md).

## Run the worker

`pnpm worker` runs everything above on a schedule, in `Asia/Kolkata`, so you do not drive the CLIs by hand. It is one process (`pnpm worker` in dev, `pnpm --filter @learning-stocks/backend start:worker` from a build) and it must be a single instance.

```bash
pnpm worker                  # Ctrl-C stops it; in-flight jobs finish first
pnpm job <name>              # run ONE job now, through the same gates and logging
pnpm job market.sync.eod
pnpm job ai.stock.analyze --symbols RELIANCE,TCS --force
```

`pnpm job` never cascades: it prints the follow-ups the worker would have queued and leaves them to you.

| Job                    | When (IST)                        | Only if                                   | Then runs                                  |
| ---------------------- | --------------------------------- | ----------------------------------------- | ------------------------------------------ |
| `market.sync.intraday` | every 5 min, 09:00–15:30 Mon–Fri  | the 5 min just ended overlapped a session | `evaluation.compute`                       |
| `market.sync.eod`      | 16:05 Mon–Fri                     | it is a trading day                       | `evaluation.compute`                       |
| `fundamentals.sync`    | 18:00 daily                       | the provider is configured                | `evaluation.compute`                       |
| `news.sync`            | every 10 min                      | the provider is configured                | `embeddings.generate` → `news.sentiment`   |
| `evaluation.compute`   | chained only                      | —                                         | `ai.stock.analyze`, **only after EOD**     |
| `ai.stock.analyze`     | every 30 min, 10:00–15:30 Mon–Fri | LLM configured, trading day               | `signals.generate`                         |
| `ai.market.summary`    | every 30 min, 10:00–15:30 Mon–Fri | LLM configured, trading day               | —                                          |
| `ai.daily.summary`     | 16:15 Mon–Fri                     | LLM configured, trading day               | —                                          |
| `signals.expire`       | every 15 min                      | —                                         | —                                          |
| `holidays.check`       | Mondays 09:00                     | —                                         | warns when next year's calendar is missing |

A few things worth knowing:

- **Nothing overlaps.** Each queue holds one running job plus at most one waiting, so a slow run delays its successor instead of racing it. Extra ticks are dropped, not piled up.
- **A closed market is a skip, not a failure.** Gated runs are recorded as `SKIPPED` with the reason, and they chain nothing — no AI analysis on a holiday.
- **Every run writes exactly one `system_logs` row** with counts, duration, status and errors:

  ```sql
  select job_name, status, records_inserted, message
  from system_logs order by started_at desc limit 20;
  ```

- **Intervals are editable without a restart of the schedule table**: set `app_settings.job_schedules` to a JSON object of job name → cron string, or `null` to disable a job, then restart the worker. Example: `{"news.sync": "0,30 * * * *", "ai.market.summary": null}`.
- **EOD waits for the close to settle.** A daily bar is final 30 minutes after the close, so EOD runs at 16:05 and then checks the bar actually landed. If it did not, the run is marked `PARTIAL` and the chain stops rather than evaluating yesterday's close as if it were today's.
- **The queue lives in its own `pgboss` schema**, created by the worker. It is not in our migrations, and `pnpm db:reset` drops it — the next start reinstalls it.
- **Crons fire on the database clock, not your laptop's.** If the two drift — Docker Desktop's VM is a common culprit — the worker logs a `Clock skew between this instance and the database server` warning and ticks fire late by that offset. Frequent jobs (`missed: 'skip'`) just drop the late occurrence; daily ones (`missed: 'once'`) still run. If you see that warning locally, restart Docker to resync the VM clock; on a server, run NTP.

**Before you point this at live data, read this.** In `MOCK_DATA=false` with an OpenAI key the worker spends against `llm_daily_budget_inr` every 30 minutes, unattended, with nobody watching the output. Everything in this phase was verified in mock mode only. Start with `LLM_PROVIDER=none`, watch `pnpm ai:budget` for a day, and raise the budget deliberately. Also note NewsAPI's free tier cannot sustain a 10-minute `news.sync` — use `NEWS_PROVIDER=rss`, or stretch the interval through `app_settings.job_schedules`.

## Mock vs live mode

- `MOCK_DATA=true` (default): every provider uses mock adapters. Everything stored is tagged `data_mode=MOCK` and never mixes with real data.
- `MOCK_DATA=false`: each provider must be a real one or `none` (feature switched off). The backend refuses to start if any is still `mock`, or if a selected provider's key is missing (e.g. `OPENAI_API_KEY` + `LLM_MODEL` for `openai`). `MARKET_DATA_PROVIDER` cannot be `none`.
- Live market data today (AI arrives in later phases):

  ```bash
  MOCK_DATA=false MARKET_DATA_PROVIDER=yahoo NEWS_PROVIDER=none FUNDAMENTALS_PROVIDER=none LLM_PROVIDER=none \
    pnpm sync:market --days 30
  ```

## Tests

```bash
pnpm db:test                                     # database (pgTAP)
pnpm test                                        # backend unit + integration (needs the DB running)
pnpm --filter @learning-stocks/backend test:unit # backend unit tests only (no DB)
pnpm --filter @learning-stocks/backend test:live # live Yahoo smoke test (network)
pnpm typecheck && pnpm lint && pnpm format:check
```

Backend tests always run with `TZ=UTC`, so timezone bugs surface even on an IST machine. Integration tests run inside rolled-back transactions and never change your data.

After changing a migration, regenerate the typed DB schema:

```bash
pnpm db:reset && pnpm --filter @learning-stocks/backend db:types
```

## Troubleshooting

| Symptom                                           | Fix                                                                                                   |
| ------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `Cannot connect to the Docker daemon`             | Start Docker Desktop, then `pnpm db:start`                                                            |
| `Integration tests need the local database`       | `pnpm db:start && pnpm db:reset`                                                                      |
| Backend prints `Invalid configuration:` and exits | Read the listed variables. Usually a live-mode provider is still `mock`, or a required key is missing |
| `/api/health` returns 503 `degraded`              | The database is not reachable. Run `pnpm db:start`                                                    |
| Port 54322 / 4000 already in use                  | Stop the other process, or change `PORT` in `.env`                                                    |
