'use client';

import { createClient, type Session, type SupabaseClient } from '@supabase/supabase-js';

/**
 * The browser holds the token and calls the API directly.
 *
 * No Next route handler proxies the API: a proxy would need the token server-side and would invite
 * a service-role key into the server bundle, which PRD §15 forbids. `@supabase/ssr` is unused for
 * the same reason — there is no server-rendered authenticated data here.
 *
 * Measured 2026-10-07: local GoTrue signs ES256 and the backend verifies it via JWKS, so login
 * works with JWT_SECRET unset, which is how .env ships.
 */
let client: SupabaseClient | null | undefined;

export function supabase(): SupabaseClient | null {
  if (client !== undefined) return client;
  const url = process.env['NEXT_PUBLIC_SUPABASE_URL'];
  const anonKey = process.env['NEXT_PUBLIC_SUPABASE_ANON_KEY'];
  // null rather than a throw: AUTH_MODE=none must work before the owner has configured Supabase
  // at all, and a hard failure here would blank a dashboard that does not need auth.
  client =
    typeof url === 'string' && url !== '' && typeof anonKey === 'string' && anonKey !== ''
      ? createClient(url, anonKey, {
          auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
        })
      : null;
  return client;
}

/** True when the browser has enough configuration to attempt a login at all. */
export const authConfigured = (): boolean => supabase() !== null;

export async function currentSession(): Promise<Session | null> {
  const sb = supabase();
  if (sb === null) return null;
  const { data } = await sb.auth.getSession();
  return data.session;
}

export async function signIn(email: string, password: string): Promise<{ error: string | null }> {
  const sb = supabase();
  if (sb === null) return { error: 'Supabase is not configured in this build.' };
  const { error } = await sb.auth.signInWithPassword({ email, password });
  return { error: error === null ? null : error.message };
}

/**
 * Creates an account.
 *
 * Phase 1's `handle_new_user()` trigger provisions the profile row, and **the first account ever
 * created becomes OWNER**; everyone after is VIEWER. There is no role-granting CLI — signing up
 * once is the whole setup.
 */
export async function signUp(email: string, password: string): Promise<{ error: string | null }> {
  const sb = supabase();
  if (sb === null) return { error: 'Supabase is not configured in this build.' };
  const { error } = await sb.auth.signUp({ email, password });
  return { error: error === null ? null : error.message };
}

export async function signOut(): Promise<void> {
  await supabase()?.auth.signOut();
}

export function onAuthChange(callback: (session: Session | null) => void): () => void {
  const sb = supabase();
  if (sb === null) return () => undefined;
  const { data } = sb.auth.onAuthStateChange((_event, session) => callback(session));
  return () => data.subscription.unsubscribe();
}
