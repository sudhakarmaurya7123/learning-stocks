/**
 * Every number and date on every page goes through this module.
 *
 * Two hazards it exists to close, both measured:
 *  - `Intl.NumberFormat.format(null)` returns `₹0.00`, so a metric the provider never supplied
 *    would render as a real price of zero. Same family: `Number(null) === 0`, `null ?? 0 === 0`.
 *  - An `Intl.DateTimeFormat` without an explicit `timeZone` uses the host's. The owner's machine
 *    is IST, so that bug is invisible to them and wrong for everyone else. Every formatter here
 *    pins Asia/Kolkata, and the tests run under TZ=UTC to prove it.
 */

/** What the UI shows instead of a number it does not have. */
export const UNAVAILABLE = '—';

const IST = 'Asia/Kolkata';
const LOCALE = 'en-IN';

/**
 * A value we can actually render.
 *
 * null, undefined, NaN and ±Infinity all mean "we do not have it" — and each of them formats as
 * something misleading if passed through.
 */
function usable(v: number | null | undefined): v is number {
  return typeof v === 'number' && Number.isFinite(v);
}

const inr = new Intl.NumberFormat(LOCALE, {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/** ₹ with Indian digit grouping (PRD §5: ₹10,00,000), or the unavailable marker. */
export function formatInr(value: number | null | undefined): string {
  return usable(value) ? inr.format(value) : UNAVAILABLE;
}

const CRORE = 10_000_000;
const LAKH = 100_000;

/**
 * ₹ in crore or lakh.
 *
 * Correct `en-IN` grouping of a market cap is `₹1,63,28,39,13,46,312.20` — accurate and unreadable
 * on a card. Scaled by magnitude so a negative keeps its sign and its unit.
 */
export function formatCompactInr(value: number | null | undefined): string {
  if (!usable(value)) return UNAVAILABLE;
  const magnitude = Math.abs(value);
  /**
   * The unit is the one the value reaches — except that rounding to 2dp can land on exactly 100
   * of the smaller unit, and "₹100.00 L" is a confusing way to write one crore. In that one case
   * the value is promoted.
   *
   * Checking only the raw threshold gives "₹100.00 L" for ₹99,99,999; checking only the rounded
   * figure gives "₹1.00 L" for ₹99,999, which has not reached a lakh at all.
   */
  const rounds = (unit: number): number => Math.round((magnitude / unit) * 100) / 100;
  if (magnitude >= CRORE || rounds(LAKH) >= 100) return `${inr.format(value / CRORE)} Cr`;
  if (magnitude >= LAKH || rounds(1) >= LAKH) return `${inr.format(value / LAKH)} L`;
  return inr.format(value);
}

/** A percentage with no forced sign: `0.00%` means "flat", `—` means "unmeasurable". */
export function formatPercent(value: number | null | undefined, digits = 2): string {
  return usable(value) ? `${value.toFixed(digits)}%` : UNAVAILABLE;
}

/**
 * A percentage with its direction.
 *
 * Zero gets no `+`: a flat day has no direction, and `+0.00%` reads as a gain.
 */
export function formatSignedPercent(value: number | null | undefined, digits = 2): string {
  if (!usable(value)) return UNAVAILABLE;
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toFixed(digits)}%`;
}

/** A grouped plain number (volumes, counts), or the unavailable marker. */
export function formatNumber(value: number | null | undefined, digits = 0): string {
  return usable(value)
    ? new Intl.NumberFormat(LOCALE, {
        minimumFractionDigits: digits,
        maximumFractionDigits: digits,
      }).format(value)
    : UNAVAILABLE;
}

/** A share count: whole numbers, grouped. */
export const formatQuantity = (value: number | null | undefined): string => formatNumber(value, 0);

/** Parses an API timestamp, or null when it is missing or malformed. */
function parse(iso: string | null | undefined): Date | null {
  if (typeof iso !== 'string' || iso === '') return null;
  const date = new Date(iso);
  // An unparseable string must never reach the page as "Invalid Date".
  return Number.isNaN(date.getTime()) ? null : date;
}

const dateTimeFmt = new Intl.DateTimeFormat(LOCALE, {
  timeZone: IST,
  dateStyle: 'medium',
  timeStyle: 'short',
});
const dateFmt = new Intl.DateTimeFormat(LOCALE, { timeZone: IST, dateStyle: 'medium' });
const timeFmt = new Intl.DateTimeFormat(LOCALE, { timeZone: IST, timeStyle: 'short' });

export interface IstOptions {
  /** Appends "IST", for a label a reader might otherwise mistake for their own timezone. */
  suffix?: boolean;
}

/** An instant as an IST date and time, e.g. `7 Oct 2026, 3:20 pm`. */
export function formatIstDateTime(
  iso: string | null | undefined,
  options: IstOptions = {},
): string {
  const date = parse(iso);
  if (date === null) return UNAVAILABLE;
  const text = dateTimeFmt.format(date);
  return options.suffix === true ? `${text} IST` : text;
}

/** An instant as an IST calendar date, e.g. `7 Oct 2026`. */
export function formatIstDate(iso: string | null | undefined): string {
  const date = parse(iso);
  return date === null ? UNAVAILABLE : dateFmt.format(date);
}

/** An instant as an IST clock time, e.g. `9:15 am`. Used for the chart's axis. */
export function formatIstTime(iso: string | null | undefined): string {
  const date = parse(iso);
  return date === null ? UNAVAILABLE : timeFmt.format(date);
}

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/**
 * How long ago something happened, for "Data updated X ago".
 *
 * `now` is a parameter rather than `Date.now()` so the result is deterministic in tests and the
 * caller controls when it is computed — reading the clock during render would hydrate differently
 * than it rendered, and React warns about exactly that.
 */
export function relativeAge(iso: string | null | undefined, now: Date): string {
  const date = parse(iso);
  if (date === null) return UNAVAILABLE;
  // Clamped at zero: a server clock slightly ahead of the browser must not read "-1 min ago".
  const age = Math.max(0, now.getTime() - date.getTime());
  if (age < MINUTE) return 'just now';
  if (age < HOUR) {
    const minutes = Math.floor(age / MINUTE);
    return `${minutes} min ago`;
  }
  if (age < DAY) {
    const hours = Math.floor(age / HOUR);
    return `${hours} hr ago`;
  }
  const days = Math.floor(age / DAY);
  return days === 1 ? '1 day ago' : `${days} days ago`;
}
