import type { z } from 'zod';

/**
 * A failed API call, carrying the backend's own error code.
 *
 * The code is what the UI branches on: `BUDGET_EXCEEDED` becomes "the daily AI budget is spent",
 * `UNSUPPORTED` becomes "AI features are switched off", `RATE_LIMITED` becomes "try again
 * shortly". Showing a raw status number tells the reader nothing they can act on.
 *
 * Two codes are ours rather than the server's:
 *  - `CONTRACT`: the response did not match the shared schema. A backend rename must surface as a
 *    named failure, not as `undefined` rendered into a panel.
 *  - `NETWORK`: fetch itself rejected (API down, wrong port, DNS).
 */
export class ApiFailure extends Error {
  constructor(
    readonly code: string,
    readonly status: number,
    message: string,
    readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'ApiFailure';
  }
}

export interface RequestOptions {
  /** The Supabase access token, or null for an API running with AUTH_MODE=none. */
  token?: string | null;
  /** Injected in tests; defaults to the global fetch. */
  fetchImpl?: typeof fetch;
  /** Overridden in tests; defaults to NEXT_PUBLIC_API_BASE_URL. */
  baseUrl?: string;
  signal?: AbortSignal;
}

export interface PostOptions extends RequestOptions {
  body?: unknown;
}

function resolveBaseUrl(explicit?: string): string {
  const base = explicit ?? process.env['NEXT_PUBLIC_API_BASE_URL'] ?? 'http://127.0.0.1:4000/api';
  // Trailing slash trimmed so `${base}${path}` cannot produce a double slash, which some proxies
  // treat as a different route.
  return base.endsWith('/') ? base.slice(0, -1) : base;
}

function headersFor(token: string | null | undefined, json: boolean): Headers {
  const headers = new Headers({ accept: 'application/json' });
  if (json) headers.set('content-type', 'application/json');
  // Set only when present: "Bearer null" would be a 401 from a server that would otherwise have
  // served the request, which is how AUTH_MODE=none has to keep working.
  if (typeof token === 'string' && token !== '') headers.set('authorization', `Bearer ${token}`);
  return headers;
}

/** Reads the body once and parses it defensively: a proxy's HTML error page must not throw. */
async function readBody(response: Response): Promise<unknown> {
  const text = await response.text();
  if (text === '') return null;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return null;
  }
}

function isErrorEnvelope(
  body: unknown,
): body is { error: { code: string; message: string; details?: Record<string, unknown> } } {
  if (typeof body !== 'object' || body === null || !('error' in body)) return false;
  const error = (body as { error: unknown }).error;
  return typeof error === 'object' && error !== null && 'code' in error && 'message' in error;
}

async function request<T>(
  path: string,
  schema: z.ZodType<T>,
  init: RequestInit,
  options: RequestOptions,
): Promise<T> {
  const url = `${resolveBaseUrl(options.baseUrl)}${path}`;
  const doFetch = options.fetchImpl ?? fetch;
  let response: Response;
  try {
    response = await doFetch(url, init);
  } catch (error) {
    throw new ApiFailure(
      'NETWORK',
      0,
      error instanceof Error ? `Cannot reach the API: ${error.message}` : 'Cannot reach the API',
    );
  }

  const body = await readBody(response);
  if (!response.ok) {
    if (isErrorEnvelope(body)) {
      throw new ApiFailure(
        body.error.code,
        response.status,
        body.error.message,
        body.error.details,
      );
    }
    throw new ApiFailure('INTERNAL', response.status, `Request failed (${response.status})`);
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    // The field path goes in the message: "violates its contract" with no field name costs an
    // hour of searching.
    const first = parsed.error.issues[0];
    const where = first === undefined ? 'unknown field' : first.path.join('.') || 'root';
    const why = first?.message ?? 'did not match the expected shape';
    throw new ApiFailure('CONTRACT', response.status, `${path} returned ${where}: ${why}`);
  }
  return parsed.data;
}

/**
 * A read.
 *
 * `cache: 'no-store'` on purpose: a research desk must never show a price the browser cached.
 * The backend already caches quotes for 30 s and aggregates for 60 s, which is where that
 * decision belongs.
 */
export function apiGet<T>(
  path: string,
  schema: z.ZodType<T>,
  options: RequestOptions = {},
): Promise<T> {
  return request(
    path,
    schema,
    {
      method: 'GET',
      headers: headersFor(options.token, false),
      cache: 'no-store',
      ...(options.signal === undefined ? {} : { signal: options.signal }),
    },
    options,
  );
}

/** An action. Every caller is a click — nothing here runs on mount (PRD §14). */
export function apiPost<T>(
  path: string,
  schema: z.ZodType<T>,
  options: PostOptions = {},
): Promise<T> {
  return request(
    path,
    schema,
    {
      method: 'POST',
      headers: headersFor(options.token, true),
      body: JSON.stringify(options.body ?? {}),
      cache: 'no-store',
      ...(options.signal === undefined ? {} : { signal: options.signal }),
    },
    options,
  );
}
