'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import type { z } from 'zod';
import { ApiFailure, apiGet } from './api';
import { currentSession, onAuthChange } from './auth';

export interface SessionState {
  session: Session | null;
  token: string | null;
  loading: boolean;
}

/**
 * The browser's session, if any.
 *
 * The app ROLE is deliberately not here: PRD §12 says the token's own `role` claim is always
 * `authenticated`, and the real role lives in `user_profiles`. The server stays the authority —
 * a page learns it is not an admin by being refused, not by trusting a claim.
 */
export function useSession(): SessionState {
  const [state, setState] = useState<SessionState>({
    session: null,
    token: null,
    loading: true,
  });

  useEffect(() => {
    let active = true;
    void currentSession().then((session) => {
      if (active) {
        setState({ session, token: session?.access_token ?? null, loading: false });
      }
    });
    const unsubscribe = onAuthChange((session) => {
      if (active) {
        setState({ session, token: session?.access_token ?? null, loading: false });
      }
    });
    return () => {
      active = false;
      unsubscribe();
    };
  }, []);

  return state;
}

export interface AsyncState<T> {
  data: T | null;
  error: ApiFailure | null;
  loading: boolean;
  reload: () => void;
}

/**
 * Fetches one API path and parses it through its shared schema.
 *
 * Every section of every page uses this, and each one fails independently: a dead
 * /market-summary must not blank the index cards, mirroring the backend's own per-section
 * isolation. `enabled` keeps a request from firing before the session is known.
 */
export function useApi<T>(
  path: string | null,
  schema: z.ZodType<T>,
  options: { token?: string | null; enabled?: boolean } = {},
): AsyncState<T> {
  const { token = null, enabled = true } = options;
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiFailure | null>(null);
  const [loading, setLoading] = useState(enabled && path !== null);
  const [nonce, setNonce] = useState(0);
  // Kept in a ref so the schema identity does not retrigger the effect: callers build schemas
  // inline, so a dependency on it would refetch on every render.
  const schemaRef = useRef(schema);
  schemaRef.current = schema;

  useEffect(() => {
    if (!enabled || path === null) {
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    let active = true;
    setLoading(true);
    apiGet(path, schemaRef.current, { token, signal: controller.signal })
      .then((result) => {
        if (!active) return;
        setData(result);
        setError(null);
      })
      .catch((caught: unknown) => {
        if (!active) return;
        // An abort is a navigation, not a failure: showing an error for it would flash a red
        // panel every time the user changes a filter.
        if (caught instanceof DOMException && caught.name === 'AbortError') return;
        setError(
          caught instanceof ApiFailure
            ? caught
            : new ApiFailure('INTERNAL', 0, caught instanceof Error ? caught.message : 'Failed'),
        );
        setData(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
      controller.abort();
    };
  }, [path, token, enabled, nonce]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { data, error, loading, reload };
}

/**
 * A clock for relative times, started after mount.
 *
 * `null` on the first render on purpose: computing `Date.now()` during render would produce
 * different HTML on the server than in the browser, and React warns about exactly that. Callers
 * render the absolute IST time until this arrives.
 */
export function useNow(intervalMs = 30_000): Date | null {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** True while the tab is visible, so a background tab stops polling and burning rate limit. */
export function useVisible(): boolean {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const onChange = () => setVisible(document.visibilityState === 'visible');
    onChange();
    document.addEventListener('visibilitychange', onChange);
    return () => document.removeEventListener('visibilitychange', onChange);
  }, []);
  return visible;
}
