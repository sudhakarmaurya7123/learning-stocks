'use client';

import type { NewsItem } from '@learning-stocks/shared';
import { formatIstDateTime } from '../lib/format';
import { Badge, type Tone } from './ui/Badge';
import { Card } from './ui/Card';
import { EmptyPanel } from './ui/EmptyPanel';

const SENTIMENT_TONE: Record<string, Tone> = { BULLISH: 'bull', BEARISH: 'bear', NEUTRAL: 'flat' };

/** PRD §3.1's "Latest News": headline, source, IST time, linked stocks and sentiment. */
export function NewsFeed({ items }: { items: readonly NewsItem[] }) {
  if (items.length === 0) {
    return (
      <Card title="Latest news">
        <EmptyPanel reason="No news stored yet." hint="Run `pnpm sync:news` or start the worker." />
      </Card>
    );
  }
  return (
    <Card title="Latest news">
      <ul className="divide-y divide-[var(--color-edge)]/60">
        {items.map((item) => (
          <li key={`${item.source_url ?? item.title}`} className="py-3 first:pt-0 last:pb-0">
            <div className="flex flex-wrap items-center gap-2">
              {item.sentiment !== null && (
                <Badge tone={SENTIMENT_TONE[item.sentiment] ?? 'flat'}>
                  {item.sentiment.toLowerCase()}
                </Badge>
              )}
              {item.impact_level !== null && <Badge tone="neutral">{item.impact_level}</Badge>}
              {item.linked_symbols.map((symbol) => (
                <span key={symbol} className="font-mono text-xs text-sky-400">
                  {symbol}
                </span>
              ))}
            </div>
            {item.source_url === null ? (
              <p className="mt-1 text-sm text-[var(--color-ink)]">{item.title}</p>
            ) : (
              <a
                href={item.source_url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-1 block text-sm text-[var(--color-ink)] hover:text-sky-400"
              >
                {item.title}
              </a>
            )}
            <p className="mt-1 text-xs text-[var(--color-ink-dim)]">
              {item.source} · {formatIstDateTime(item.published_at)} IST
            </p>
          </li>
        ))}
      </ul>
    </Card>
  );
}
