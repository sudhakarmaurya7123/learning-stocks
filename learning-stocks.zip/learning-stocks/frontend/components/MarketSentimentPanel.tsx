'use client';

import type { MarketSummary } from '@learning-stocks/shared';
import { formatNumber } from '../lib/format';
import { Badge, type Tone } from './ui/Badge';
import { Card } from './ui/Card';
import { EmptyPanel } from './ui/EmptyPanel';
import { Stat } from './ui/Stat';

const SENTIMENT_TONE: Record<string, Tone> = {
  BULLISH: 'bull',
  BEARISH: 'bear',
  NEUTRAL: 'flat',
};

const List = ({ title, items }: { title: string; items: readonly string[] }) =>
  items.length === 0 ? null : (
    <div>
      <div className="text-xs font-semibold text-[var(--color-ink-dim)]">{title}</div>
      <ul className="mt-1 space-y-1 text-sm">
        {items.map((item) => (
          <li key={item} className="text-[var(--color-ink)]">
            · {item}
          </li>
        ))}
      </ul>
    </div>
  );

/** PRD §3.1's AI market sentiment: bias, confidence, regime, drivers, risks and sectors. */
export function MarketSentimentPanel({
  summary,
  actions,
}: {
  summary: MarketSummary | null;
  actions?: React.ReactNode;
}) {
  if (summary === null) {
    return (
      <Card title="AI market sentiment" actions={actions}>
        <EmptyPanel
          reason="No market summary generated yet."
          hint="Run `pnpm job ai.market.summary`, or wait for the scheduled run."
        />
      </Card>
    );
  }
  return (
    <Card title="AI market sentiment" actions={actions}>
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={SENTIMENT_TONE[summary.sentiment ?? 'NEUTRAL'] ?? 'flat'}>
          {summary.sentiment ?? 'UNKNOWN'} bias
        </Badge>
        {summary.regime !== null && <Badge tone="neutral">{summary.regime}</Badge>}
        {summary.trend !== null && <Badge tone="neutral">{summary.trend}</Badge>}
        {summary.risk_level !== null && <Badge tone="warn">risk {summary.risk_level}</Badge>}
      </div>
      {summary.summary !== null && (
        <p className="mt-3 text-sm leading-relaxed text-[var(--color-ink)]">{summary.summary}</p>
      )}
      <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Stat label="Sentiment score" value={formatNumber(summary.sentiment_score, 0)} />
        <Stat label="Confidence" value={formatNumber(summary.confidence, 0)} />
        <Stat label="Model" value={summary.model ?? '—'} />
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <List title="Key drivers" items={summary.key_drivers} />
        <List title="Key risks" items={summary.key_risks} />
        <List title="Positive sectors" items={summary.sectors_positive} />
        <List title="Negative sectors" items={summary.sectors_negative} />
      </div>
    </Card>
  );
}
