import type { DataMode } from '@learning-stocks/shared';

/**
 * States plainly that the numbers are simulated.
 *
 * Mock prices look exactly like real ones, so without this a reader could take a synthetic chart
 * for a market fact. Renders nothing in LIVE mode.
 */
export function MockBanner({ dataMode }: { dataMode: DataMode | null | undefined }) {
  if (dataMode !== 'MOCK') return null;
  return (
    <div
      role="alert"
      className="border-b border-[var(--color-warn)]/40 bg-[var(--color-warn)]/15 px-4 py-2 text-center text-xs text-[var(--color-warn)]"
    >
      <strong className="font-semibold">Mock data.</strong> Every price, news item and AI output on
      this page is simulated for testing — not real market data.
    </div>
  );
}
