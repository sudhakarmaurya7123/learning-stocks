'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { StockListRow } from '@learning-stocks/shared';

/**
 * Search by symbol, company name or ISIN (PRD §3.1, success criterion 3).
 *
 * Filters the rows the dashboard already fetched rather than querying per keystroke: the list is
 * twenty stocks, and a request per character would spend the read budget for no new information.
 */
export function StockSearch({ rows }: { rows: readonly StockListRow[] }) {
  const router = useRouter();
  const [query, setQuery] = useState('');

  const matches = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (needle === '') return [];
    return rows
      .filter(
        (row) =>
          row.symbol.toLowerCase().includes(needle) ||
          row.company_name.toLowerCase().includes(needle) ||
          (row.isin !== null && row.isin.toLowerCase().includes(needle)),
      )
      .slice(0, 8);
  }, [rows, query]);

  return (
    <div className="relative w-full sm:w-72">
      <input
        type="search"
        role="searchbox"
        placeholder="Search symbol, company or ISIN"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === 'Enter' && matches[0] !== undefined) {
            router.push(`/stocks/${matches[0].symbol}`);
            setQuery('');
          }
        }}
        className="w-full rounded border border-[var(--color-edge)] bg-[var(--color-surface)] px-3 py-1.5 text-sm"
      />
      {matches.length > 0 && (
        <ul className="absolute z-10 mt-1 w-full overflow-hidden rounded border border-[var(--color-edge)] bg-[var(--color-surface-2)] shadow-lg">
          {matches.map((row) => (
            <li key={row.symbol}>
              <a
                href={`/stocks/${row.symbol}`}
                className="block px-3 py-2 text-sm hover:bg-[var(--color-edge)]"
              >
                <span className="font-mono">{row.symbol}</span>
                <span className="ml-2 text-xs text-[var(--color-ink-dim)]">{row.company_name}</span>
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
