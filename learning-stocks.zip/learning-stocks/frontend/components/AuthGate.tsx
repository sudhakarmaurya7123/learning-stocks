'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { EnvelopeSchema, MarketStatusSchema } from '@learning-stocks/shared';
import { ApiFailure, apiGet } from '../lib/api';
import { useSession } from '../lib/hooks';
import { SkeletonRows } from './ui/Skeleton';

type Verdict = 'checking' | 'allowed' | 'denied';

/**
 * Renders the app when the caller can actually read the API.
 *
 * Three states, and the third is the point: with a session, children render. With no session it
 * probes one authenticated read — if the API answers 200 it is running AUTH_MODE=none and the
 * dashboard works untokened, which is what makes local development possible before auth is set
 * up. Only a real refusal sends the reader to /login.
 */
export function AuthGate({ children }: { children: ReactNode }) {
  const router = useRouter();
  const { token, loading } = useSession();
  const [verdict, setVerdict] = useState<Verdict>('checking');

  useEffect(() => {
    if (loading) return;
    if (token !== null) {
      setVerdict('allowed');
      return;
    }
    let active = true;
    apiGet('/market-status', EnvelopeSchema(MarketStatusSchema), { token: null })
      .then(() => {
        if (active) setVerdict('allowed');
      })
      .catch((caught: unknown) => {
        if (!active) return;
        const unauthenticated =
          caught instanceof ApiFailure &&
          (caught.code === 'UNAUTHORIZED' || caught.code === 'FORBIDDEN');
        // A network failure is not an auth problem: sending the reader to a login page they
        // cannot use would hide "the API is not running", which is the real fault.
        setVerdict(unauthenticated ? 'denied' : 'allowed');
      });
    return () => {
      active = false;
    };
  }, [token, loading]);

  useEffect(() => {
    if (verdict === 'denied') router.push('/login');
  }, [verdict, router]);

  if (loading || verdict === 'checking') {
    return (
      <main className="mx-auto max-w-5xl p-8">
        <SkeletonRows rows={5} />
      </main>
    );
  }
  if (verdict === 'denied') {
    return (
      <main className="mx-auto max-w-lg p-8 text-sm text-[var(--color-ink-dim)]">
        Sign-in required. Redirecting…
      </main>
    );
  }
  return <>{children}</>;
}
