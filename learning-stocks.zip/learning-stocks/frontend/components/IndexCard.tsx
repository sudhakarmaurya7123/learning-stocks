'use client';

import Link from 'next/link';
import type { MarketCard } from '@learning-stocks/shared';
import { formatNumber, formatSignedPercent, UNAVAILABLE } from '../lib/format';
import { Badge, toneForChange } from './ui/Badge';

/** One index: level, change, change % (PRD §3.1). India VIX is a level, not a price. */
export function IndexCard({ card }: { card: MarketCard }) {
  const quote = card.quote;
  const tone = toneForChange(quote?.change_percent);
  const colour =
    tone === 'bull'
      ? 'text-[var(--color-bull)]'
      : tone === 'bear'
        ? 'text-[var(--color-bear)]'
        : 'text-[var(--color-ink)]';
  return (
    <Link
      href={`/stocks/${card.symbol}`}
      className="block rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-2)] p-3 transition hover:border-sky-700"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-xs text-[var(--color-ink-dim)]">{card.name}</div>
          <div className="font-mono text-xs text-[var(--color-flat)]">{card.symbol}</div>
        </div>
        {card.market_type === 'VOLATILITY' && <Badge tone="warn">VIX</Badge>}
      </div>
      {quote === null ? (
        // Not ₹0.00: an index with no stored quote has no level, and a zero would read as one.
        <div className="mt-2 text-sm text-[var(--color-ink-dim)]">{UNAVAILABLE} no quote yet</div>
      ) : (
        <div className="mt-2">
          <div className="text-lg font-semibold tabular-nums">{formatNumber(quote.price, 2)}</div>
          <div className={`text-sm tabular-nums ${colour}`}>
            {quote.change === null ? UNAVAILABLE : formatNumber(quote.change, 2)}{' '}
            <span className="text-xs">({formatSignedPercent(quote.change_percent)})</span>
          </div>
        </div>
      )}
    </Link>
  );
}
