'use client';

import type { ApiFailure } from '../lib/api';
import { Button } from './ui/Button';

/**
 * Turns a failed call into a sentence the reader can act on.
 *
 * A bare status code tells them nothing; the backend's own error code does. One panel failing
 * shows this and leaves the rest of the page alone.
 */
const MESSAGES: Record<string, string> = {
  UNAUTHORIZED: 'Your session has expired. Sign in again to continue.',
  FORBIDDEN: 'This account is not permitted to see this. An OWNER or ADMIN role is required.',
  NOT_FOUND: 'Not found.',
  RATE_LIMITED: 'Too many requests just now. Try again in a minute.',
  BUDGET_EXCEEDED: "Today's AI budget is spent. Stored results are still shown.",
  UNSUPPORTED: 'This feature is switched off by configuration.',
  CONTRACT: 'The API returned an unexpected shape. The frontend and backend are out of step.',
  NETWORK: 'Cannot reach the API. Is `pnpm dev` running on port 4000?',
};

export function ErrorNotice({ error, onRetry }: { error: ApiFailure; onRetry?: () => void }) {
  const explanation = MESSAGES[error.code] ?? error.message;
  return (
    <div className="rounded border border-[var(--color-bear)]/40 bg-[var(--color-bear)]/10 p-4">
      <p className="text-sm text-[var(--color-ink)]">{explanation}</p>
      <p className="mt-1 font-mono text-xs text-[var(--color-ink-dim)]">
        {error.code}
        {error.status > 0 && ` · ${error.status}`}
      </p>
      {onRetry !== undefined && (
        <div className="mt-3">
          <Button onClick={onRetry}>Try again</Button>
        </div>
      )}
    </div>
  );
}
