'use client';

import type { Freshness } from '@learning-stocks/shared';
import { formatIstDateTime, relativeAge, UNAVAILABLE } from '../lib/format';
import { Badge } from './ui/Badge';

/**
 * How old the data behind a panel is.
 *
 * `stale` comes from the API and is never recomputed here: the server knows the market calendar
 * and the per-section cadence (a daily indicator is current until the next session, a quote for
 * minutes). Re-deriving it from age in the browser would contradict the server on every weekend.
 */
export function FreshnessBadge({
  freshness,
  now,
  label,
}: {
  freshness: Freshness | null | undefined;
  now: Date | null;
  label?: string;
}) {
  if (freshness === null || freshness === undefined || freshness.as_of === null) {
    return (
      <span role="status" data-stale="true">
        <Badge tone="warn">no data</Badge>
      </span>
    );
  }
  // Before the clock mounts, show the absolute instant rather than a relative age computed during
  // render — that would hydrate differently than it rendered.
  const age = now === null ? formatIstDateTime(freshness.as_of) : relativeAge(freshness.as_of, now);
  const exact = formatIstDateTime(freshness.as_of, { suffix: true });
  return (
    <span role="status" data-stale={String(freshness.stale)} title={exact}>
      <Badge tone={freshness.stale ? 'warn' : 'neutral'}>
        {label !== undefined && `${label} `}
        {age === UNAVAILABLE ? 'no data' : age}
        {freshness.stale && ' · stale'}
      </Badge>
    </span>
  );
}
