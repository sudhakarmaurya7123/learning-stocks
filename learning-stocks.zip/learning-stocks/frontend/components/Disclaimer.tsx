/**
 * The persistent disclaimer (PRD §19).
 *
 * Personal use only: publishing buy/sell calls to others is regulated in India under SEBI's
 * Research Analyst rules. The wording avoids PRD §1's banned vocabulary — no "guaranteed",
 * nothing "certain to rise" — because the system expresses a bias with confidence, never a
 * prediction.
 */
export function Disclaimer() {
  return (
    <footer
      role="contentinfo"
      className="mt-10 border-t border-[var(--color-edge)] px-4 py-6 text-xs leading-relaxed text-[var(--color-ink-dim)]"
    >
      <p>
        <strong className="text-[var(--color-ink)]">Not investment advice.</strong> This is a
        personal-use research tool. It states biases with a confidence level from the data it has
        stored; it does not predict prices, and no output here is a recommendation to buy or sell.
      </p>
      <p className="mt-2">
        Trading is simulated. No order placed here reaches a broker or a real market, and nothing is
        ever traded without an explicit click.
      </p>
    </footer>
  );
}
