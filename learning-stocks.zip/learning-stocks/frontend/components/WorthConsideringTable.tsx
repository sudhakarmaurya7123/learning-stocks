'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import type { StockListRow } from '@learning-stocks/shared';
import { ACTION_STATES } from '@learning-stocks/shared';
import { formatInr, formatNumber, formatSignedPercent, UNAVAILABLE } from '../lib/format';
import { Badge, toneForChange, type Tone } from './ui/Badge';
import { Card } from './ui/Card';
import { EmptyPanel } from './ui/EmptyPanel';

const ACTION_TONE: Record<string, Tone> = {
  BUY_ZONE: 'bull',
  WAIT_FOR_PULLBACK: 'warn',
  WAIT_FOR_CONFIRMATION: 'warn',
  HOLD: 'flat',
  REDUCE: 'bear',
  AVOID: 'bear',
  INSUFFICIENT_DATA: 'neutral',
};

const VALUATION_TONE: Record<string, Tone> = {
  UNDERVALUED: 'bull',
  FAIR: 'flat',
  OVERVALUED: 'bear',
  INSUFFICIENT_DATA: 'neutral',
};

type SortKey = 'symbol' | 'price' | 'change' | 'overall' | 'technical' | 'news' | 'rr';

/** The value a column sorts on. null means unmeasurable, and sorts last in either direction. */
const sortValue = (row: StockListRow, key: SortKey): number | string | null => {
  switch (key) {
    case 'symbol':
      return row.symbol;
    case 'price':
      return row.quote?.price ?? null;
    case 'change':
      return row.quote?.change_percent ?? null;
    case 'overall':
      return row.evaluation?.overall_score ?? null;
    case 'technical':
      return row.scores?.technical ?? null;
    case 'news':
      return row.scores?.news ?? null;
    case 'rr':
      return row.risk_reward ?? null;
  }
};

const COLUMNS: ReadonlyArray<{ key: SortKey; label: string; numeric: boolean }> = [
  { key: 'symbol', label: 'Stock', numeric: false },
  { key: 'price', label: 'Price', numeric: true },
  { key: 'change', label: 'Change', numeric: true },
  { key: 'overall', label: 'Overall', numeric: true },
  { key: 'technical', label: 'Tech', numeric: true },
  { key: 'news', label: 'News', numeric: true },
  { key: 'rr', label: 'R:R', numeric: true },
];

/**
 * PRD §3.1's "Worth Considering" table: sortable and filterable.
 *
 * Every cell renders "—" when the value is unknown, never 0 — a stock the evaluation job has not
 * reached must not rank as the worst one, and a reader cannot tell a real zero from a gap.
 */
export function WorthConsideringTable({ rows }: { rows: readonly StockListRow[] }) {
  const [sortKey, setSortKey] = useState<SortKey>('overall');
  const [descending, setDescending] = useState(true);
  const [action, setAction] = useState<string>('');
  const [sector, setSector] = useState<string>('');

  const sectors = useMemo(
    () => [...new Set(rows.map((r) => r.sector).filter((s): s is string => s !== null))].sort(),
    [rows],
  );

  const visible = useMemo(() => {
    const filtered = rows.filter(
      (row) =>
        (action === '' || row.evaluation?.action_state === action) &&
        (sector === '' || row.sector === sector),
    );
    return [...filtered].sort((a, b) => {
      const left = sortValue(a, sortKey);
      const right = sortValue(b, sortKey);
      // Unmeasurable rows sink to the bottom whichever way the column is sorted: ranking a null
      // as a zero would present an unevaluated stock as the worst one on the desk.
      if (left === null && right === null) return a.symbol.localeCompare(b.symbol);
      if (left === null) return 1;
      if (right === null) return -1;
      const comparison =
        typeof left === 'string' && typeof right === 'string'
          ? left.localeCompare(right)
          : Number(left) - Number(right);
      return descending ? -comparison : comparison;
    });
  }, [rows, sortKey, descending, action, sector]);

  const toggle = (key: SortKey) => {
    if (key === sortKey) {
      setDescending((d) => !d);
      return;
    }
    setSortKey(key);
    setDescending(key !== 'symbol');
  };

  const filters = (
    <div className="flex flex-wrap items-center gap-2">
      <label className="text-xs text-[var(--color-ink-dim)]">
        Action
        <select
          aria-label="Action state"
          value={action}
          onChange={(event) => setAction(event.target.value)}
          className="ml-1 rounded border border-[var(--color-edge)] bg-[var(--color-surface)] px-2 py-1 text-xs text-[var(--color-ink)]"
        >
          <option value="">all</option>
          {ACTION_STATES.map((state) => (
            <option key={state} value={state}>
              {state.replaceAll('_', ' ').toLowerCase()}
            </option>
          ))}
        </select>
      </label>
      <label className="text-xs text-[var(--color-ink-dim)]">
        Sector
        <select
          aria-label="Sector"
          value={sector}
          onChange={(event) => setSector(event.target.value)}
          className="ml-1 rounded border border-[var(--color-edge)] bg-[var(--color-surface)] px-2 py-1 text-xs text-[var(--color-ink)]"
        >
          <option value="">all</option>
          {sectors.map((name) => (
            <option key={name} value={name}>
              {name}
            </option>
          ))}
        </select>
      </label>
    </div>
  );

  return (
    <Card title={`Worth considering (${visible.length})`} actions={filters}>
      {visible.length === 0 ? (
        <EmptyPanel reason="No stocks match these filters." />
      ) : (
        <div className="-mx-4 overflow-x-auto px-4">
          <table className="w-full min-w-[46rem] text-sm">
            <thead>
              <tr className="border-b border-[var(--color-edge)] text-xs text-[var(--color-ink-dim)]">
                {COLUMNS.map((column) => (
                  <th
                    key={column.key}
                    className={`py-2 font-medium ${column.numeric ? 'text-right' : 'text-left'}`}
                  >
                    <button
                      type="button"
                      onClick={() => toggle(column.key)}
                      className="hover:text-[var(--color-ink)]"
                    >
                      {column.label}
                      {sortKey === column.key && (descending ? ' ↓' : ' ↑')}
                    </button>
                  </th>
                ))}
                <th className="py-2 text-left font-medium">Action</th>
                <th className="py-2 text-left font-medium">Valuation</th>
                <th className="py-2 text-left font-medium">Risk</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((row) => (
                <tr
                  key={row.symbol}
                  data-symbol={row.symbol}
                  className="border-b border-[var(--color-edge)]/50 hover:bg-[var(--color-surface)]"
                >
                  <td className="py-2">
                    <Link href={`/stocks/${row.symbol}`} className="hover:text-sky-400">
                      <span className="font-mono font-medium">{row.symbol}</span>
                      <span className="ml-2 hidden text-xs text-[var(--color-ink-dim)] sm:inline">
                        {row.company_name}
                      </span>
                    </Link>
                  </td>
                  <td className="py-2 text-right tabular-nums">{formatInr(row.quote?.price)}</td>
                  <td
                    className={`py-2 text-right tabular-nums ${
                      toneForChange(row.quote?.change_percent) === 'bull'
                        ? 'text-[var(--color-bull)]'
                        : toneForChange(row.quote?.change_percent) === 'bear'
                          ? 'text-[var(--color-bear)]'
                          : ''
                    }`}
                  >
                    {formatSignedPercent(row.quote?.change_percent)}
                  </td>
                  <td className="py-2 text-right tabular-nums">
                    {formatNumber(row.evaluation?.overall_score, 0)}
                  </td>
                  <td className="py-2 text-right tabular-nums">
                    {formatNumber(row.scores?.technical, 0)}
                  </td>
                  <td className="py-2 text-right tabular-nums">
                    {formatNumber(row.scores?.news, 0)}
                  </td>
                  <td className="py-2 text-right tabular-nums">
                    {row.risk_reward === null ? UNAVAILABLE : row.risk_reward.toFixed(1)}
                  </td>
                  <td className="py-2">
                    {row.evaluation === null ? (
                      <span className="text-[var(--color-ink-dim)]">{UNAVAILABLE}</span>
                    ) : (
                      <Badge tone={ACTION_TONE[row.evaluation.action_state] ?? 'neutral'}>
                        {row.evaluation.action_state.replaceAll('_', ' ').toLowerCase()}
                      </Badge>
                    )}
                  </td>
                  <td className="py-2">
                    {row.valuation_label === null ? (
                      <span className="text-[var(--color-ink-dim)]">{UNAVAILABLE}</span>
                    ) : (
                      <Badge tone={VALUATION_TONE[row.valuation_label] ?? 'neutral'}>
                        {row.valuation_label.toLowerCase()}
                      </Badge>
                    )}
                  </td>
                  <td className="py-2">
                    {row.evaluation === null ? (
                      <span className="text-[var(--color-ink-dim)]">{UNAVAILABLE}</span>
                    ) : (
                      <Badge tone={row.evaluation.risk_level === 'LOW' ? 'flat' : 'warn'}>
                        {row.evaluation.risk_level.toLowerCase()}
                      </Badge>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
