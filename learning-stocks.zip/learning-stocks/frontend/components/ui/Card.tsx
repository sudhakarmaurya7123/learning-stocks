import type { ReactNode } from 'react';

export interface CardProps {
  title?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
  children: ReactNode;
  className?: string;
}

/** The standard panel: a titled box with an optional action slot on the right. */
export function Card({ title, actions, footer, children, className = '' }: CardProps) {
  return (
    <section
      className={`rounded-lg border border-[var(--color-edge)] bg-[var(--color-surface-2)] ${className}`}
    >
      {(title !== undefined || actions !== undefined) && (
        <header className="flex items-center justify-between gap-3 border-b border-[var(--color-edge)] px-4 py-3">
          <h2 className="text-sm font-semibold tracking-wide text-[var(--color-ink)]">{title}</h2>
          {actions !== undefined && <div className="flex items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className="p-4">{children}</div>
      {footer !== undefined && (
        <footer className="border-t border-[var(--color-edge)] px-4 py-2 text-xs text-[var(--color-ink-dim)]">
          {footer}
        </footer>
      )}
    </section>
  );
}
