import type { ReactNode } from 'react';

/** A labelled figure. The value is pre-formatted by the caller, so "—" flows through unchanged. */
export function Stat({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: 'bull' | 'bear' | 'flat';
}) {
  const colour =
    tone === 'bull'
      ? 'text-[var(--color-bull)]'
      : tone === 'bear'
        ? 'text-[var(--color-bear)]'
        : 'text-[var(--color-ink)]';
  return (
    <div className="min-w-0">
      <div className="text-xs text-[var(--color-ink-dim)]">{label}</div>
      <div className={`truncate text-base font-semibold tabular-nums ${colour}`}>{value}</div>
      {hint !== undefined && (
        <div className="truncate text-xs text-[var(--color-ink-dim)]">{hint}</div>
      )}
    </div>
  );
}
