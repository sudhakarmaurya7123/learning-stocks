'use client';

import type { ReactNode } from 'react';

export type Intent = 'primary' | 'secondary' | 'danger';

const INTENTS: Record<Intent, string> = {
  primary: 'bg-sky-600 hover:bg-sky-500 text-white border-sky-700',
  secondary:
    'bg-[var(--color-surface-2)] hover:bg-[var(--color-edge)] text-[var(--color-ink)] border-[var(--color-edge)]',
  danger: 'bg-[var(--color-bear)] hover:brightness-110 text-white border-[var(--color-bear)]',
};

export function Button({
  children,
  onClick,
  intent = 'secondary',
  disabled = false,
  type = 'button',
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  intent?: Intent;
  disabled?: boolean;
  type?: 'button' | 'submit';
  title?: string;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`rounded border px-3 py-1.5 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-50 ${INTENTS[intent]}`}
    >
      {children}
    </button>
  );
}
