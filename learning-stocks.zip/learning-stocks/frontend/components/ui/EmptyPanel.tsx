/**
 * What a panel shows when it has no data.
 *
 * It states the reason rather than rendering an empty box or a zero: PRD §3.2 requires
 * "Fundamental data unavailable", not a grid of ₹0.00, because a reader cannot tell a missing
 * metric from a real zero.
 */
export function EmptyPanel({ reason, hint }: { reason: string; hint?: string }) {
  return (
    <div className="rounded border border-dashed border-[var(--color-edge)] p-6 text-center">
      <p className="text-sm text-[var(--color-ink-dim)]">{reason}</p>
      {hint !== undefined && <p className="mt-1 text-xs text-[var(--color-flat)]">{hint}</p>}
    </div>
  );
}
