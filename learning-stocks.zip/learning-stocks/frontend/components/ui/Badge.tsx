import type { ReactNode } from 'react';

export type Tone = 'bull' | 'bear' | 'flat' | 'warn' | 'neutral';

const TONES: Record<Tone, string> = {
  bull: 'bg-[var(--color-bull)]/15 text-[var(--color-bull)] border-[var(--color-bull)]/30',
  bear: 'bg-[var(--color-bear)]/15 text-[var(--color-bear)] border-[var(--color-bear)]/30',
  flat: 'bg-[var(--color-flat)]/15 text-[var(--color-flat)] border-[var(--color-flat)]/30',
  warn: 'bg-[var(--color-warn)]/15 text-[var(--color-warn)] border-[var(--color-warn)]/30',
  neutral: 'bg-[var(--color-edge)] text-[var(--color-ink-dim)] border-[var(--color-edge)]',
};

/**
 * A small status pill.
 *
 * Colour is never the only signal: callers pair a tone with a sign or a word, because a red/green
 * difference is invisible to a colour-blind reader.
 */
export function Badge({
  tone = 'neutral',
  children,
  title,
}: {
  tone?: Tone;
  children: ReactNode;
  title?: string;
}) {
  return (
    <span
      title={title}
      className={`inline-flex items-center rounded border px-2 py-0.5 text-xs font-medium whitespace-nowrap ${TONES[tone]}`}
    >
      {children}
    </span>
  );
}

/** Maps a signed number to a tone, treating "no value" as flat rather than as a loss. */
export function toneForChange(value: number | null | undefined): Tone {
  if (typeof value !== 'number' || !Number.isFinite(value) || value === 0) return 'flat';
  return value > 0 ? 'bull' : 'bear';
}
