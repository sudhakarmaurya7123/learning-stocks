import type { MarketStatus as Status } from '@learning-stocks/shared';
import { formatIstDateTime } from '../lib/format';
import { Badge } from './ui/Badge';

/** Open / closed / holiday plus the next open, in IST (PRD §3.1). */
export function MarketStatusPill({ status }: { status: Status | null }) {
  if (status === null) return <Badge tone="neutral">market status unknown</Badge>;
  if (status.is_open) {
    return (
      <Badge tone="bull" title={`as of ${formatIstDateTime(status.as_of, { suffix: true })}`}>
        NSE open
      </Badge>
    );
  }
  const why =
    status.holiday !== null
      ? `holiday: ${status.holiday}`
      : status.phase === 'WEEKEND'
        ? 'weekend'
        : 'closed';
  const next =
    status.next_open === null ? '' : ` · opens ${formatIstDateTime(status.next_open)} IST`;
  return (
    <Badge tone="flat" title={`as of ${formatIstDateTime(status.as_of, { suffix: true })}`}>
      NSE {why}
      {next}
    </Badge>
  );
}
