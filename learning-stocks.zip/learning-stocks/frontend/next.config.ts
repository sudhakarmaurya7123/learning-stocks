import path from 'node:path';
import type { NextConfig } from 'next';

/**
 * Next 16 removed the `eslint` key from NextConfig, so linting is not configured here. The repo's
 * root `eslint .` already covers this directory (and its flat config ignores `.next/`), so there
 * is nothing to turn off — a duplicate run under Next's own rules is what we are avoiding, and
 * the key no longer exists to request it.
 */
const config: NextConfig = {
  reactStrictMode: true,
  // Never ship a type error.
  typescript: { ignoreBuildErrors: false },
  turbopack: {
    /**
     * The repo root, not this package.
     *
     * Turbopack walks upward for a workspace root and found an unrelated pnpm-workspace.yaml in
     * the home directory, outside this git repository. It has to be told — but it must be told
     * the REPO root: pnpm hoists `next` and the workspace packages into the root node_modules,
     * and anything outside the declared root is not compiled, so pinning this directory breaks
     * module resolution outright.
     */
    root: path.resolve(import.meta.dirname, '..'),
  },
};

export default config;
