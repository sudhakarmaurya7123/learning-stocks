import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Research Desk',
  description: 'Personal NSE/BSE research and paper-trading desk. Not investment advice.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
