'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { authConfigured, signIn, signUp } from '../../lib/auth';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Disclaimer } from '../../components/Disclaimer';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  if (!authConfigured()) {
    return (
      <main className="mx-auto max-w-lg p-8">
        <Card title="Supabase is not configured">
          <p className="text-sm text-[var(--color-ink-dim)]">
            Set these two values in{' '}
            <code className="text-[var(--color-ink)]">frontend/.env.local</code> and restart the dev
            server:
          </p>
          <pre className="mt-3 overflow-x-auto rounded bg-[var(--color-surface)] p-3 text-xs">
            NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321{'\n'}
            NEXT_PUBLIC_SUPABASE_ANON_KEY=&lt;the anon key from `pnpm exec supabase status`&gt;
          </pre>
          <p className="mt-3 text-sm text-[var(--color-ink-dim)]">
            For local work you can skip login entirely: set{' '}
            <code className="text-[var(--color-ink)]">AUTH_MODE=none</code> in the backend{' '}
            <code className="text-[var(--color-ink)]">.env</code>, which treats every request as
            OWNER on loopback with mock data.
          </p>
        </Card>
      </main>
    );
  }

  const submit = async (mode: 'in' | 'up') => {
    setBusy(true);
    setError(null);
    setNotice(null);
    const result = mode === 'in' ? await signIn(email, password) : await signUp(email, password);
    setBusy(false);
    if (result.error !== null) {
      setError(result.error);
      return;
    }
    if (mode === 'up') {
      setNotice('Account created. Signing you in…');
    }
    router.push('/');
  };

  return (
    <main className="mx-auto max-w-lg p-8">
      <h1 className="mb-6 text-2xl font-semibold">Research Desk</h1>
      <Card title="Sign in">
        <form
          className="space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            void submit('in');
          }}
        >
          <label className="block">
            <span className="text-xs text-[var(--color-ink-dim)]">Email</span>
            <input
              type="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              className="mt-1 w-full rounded border border-[var(--color-edge)] bg-[var(--color-surface)] px-3 py-2 text-sm"
            />
          </label>
          <label className="block">
            <span className="text-xs text-[var(--color-ink-dim)]">Password</span>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              className="mt-1 w-full rounded border border-[var(--color-edge)] bg-[var(--color-surface)] px-3 py-2 text-sm"
            />
          </label>
          {error !== null && <p className="text-sm text-[var(--color-bear)]">{error}</p>}
          {notice !== null && <p className="text-sm text-[var(--color-bull)]">{notice}</p>}
          <div className="flex items-center gap-2">
            <Button type="submit" intent="primary" disabled={busy}>
              {busy ? 'Working…' : 'Sign in'}
            </Button>
            <Button onClick={() => void submit('up')} disabled={busy}>
              Create account
            </Button>
          </div>
        </form>
        <p className="mt-4 text-xs text-[var(--color-ink-dim)]">
          <strong className="text-[var(--color-ink)]">
            The first account created becomes OWNER
          </strong>{' '}
          and can run syncs and AI jobs. Every account after that is a VIEWER, which can read
          everything but run nothing. There is no role-granting command — signing up once is the
          whole setup.
        </p>
      </Card>
      <Disclaimer />
    </main>
  );
}
