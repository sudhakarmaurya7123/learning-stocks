'use client';

import Link from 'next/link';
import { z } from 'zod';
import {
  EnvelopeSchema,
  MarketCardSchema,
  MarketStatusSchema,
  MarketSummarySchema,
  NewsItemSchema,
  StockListRowSchema,
} from '@learning-stocks/shared';
import { AuthGate } from '../components/AuthGate';
import { Disclaimer } from '../components/Disclaimer';
import { ErrorNotice } from '../components/ErrorNotice';
import { FreshnessBadge } from '../components/FreshnessBadge';
import { IndexCard } from '../components/IndexCard';
import { MarketSentimentPanel } from '../components/MarketSentimentPanel';
import { MarketStatusPill } from '../components/MarketStatus';
import { MockBanner } from '../components/MockBanner';
import { NewsFeed } from '../components/NewsFeed';
import { StockSearch } from '../components/StockSearch';
import { WorthConsideringTable } from '../components/WorthConsideringTable';
import { Card } from '../components/ui/Card';
import { SkeletonRows } from '../components/ui/Skeleton';
import { useApi, useNow, useSession } from '../lib/hooks';

// Built once at module scope: a schema rebuilt per render would be a new identity each time.
const MarketsEnvelope = EnvelopeSchema(z.array(MarketCardSchema));
const StatusEnvelope = EnvelopeSchema(MarketStatusSchema);
const SummaryEnvelope = EnvelopeSchema(MarketSummarySchema.nullable());
const StocksEnvelope = EnvelopeSchema(z.array(StockListRowSchema));
const NewsEnvelope = EnvelopeSchema(z.array(NewsItemSchema));

function Dashboard() {
  const { token, loading: sessionLoading } = useSession();
  const now = useNow();
  const ready = !sessionLoading;

  /**
   * Five independent reads.
   *
   * Each fails on its own, mirroring the backend's per-section isolation: a dead /market-summary
   * must not blank the index cards. PRD §14 — none of these spends money.
   */
  const markets = useApi('/markets', MarketsEnvelope, { token, enabled: ready });
  const status = useApi('/market-status', StatusEnvelope, { token, enabled: ready });
  const summary = useApi('/market-summary', SummaryEnvelope, { token, enabled: ready });
  const stocks = useApi('/stocks', StocksEnvelope, { token, enabled: ready });
  const news = useApi('/news?limit=10', NewsEnvelope, { token, enabled: ready });

  const dataMode = markets.data?.meta.data_mode ?? stocks.data?.meta.data_mode ?? null;

  return (
    <>
      <MockBanner dataMode={dataMode} />
      <header className="border-b border-[var(--color-edge)] px-4 py-3">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Link href="/" className="text-lg font-semibold">
              Research Desk
            </Link>
            <MarketStatusPill status={status.data?.data ?? null} />
          </div>
          <div className="flex items-center gap-3">
            <StockSearch rows={stocks.data?.data ?? []} />
            <Link
              href="/admin"
              className="text-sm text-[var(--color-ink-dim)] hover:text-[var(--color-ink)]"
            >
              Admin
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 p-4">
        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-semibold tracking-wide">Indices</h2>
            <FreshnessBadge freshness={markets.data?.meta.freshness} now={now} />
          </div>
          {markets.error !== null ? (
            <ErrorNotice error={markets.error} onRetry={markets.reload} />
          ) : markets.loading ? (
            <SkeletonRows rows={2} />
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {(markets.data?.data ?? []).map((card) => (
                <IndexCard key={card.symbol} card={card} />
              ))}
            </div>
          )}
        </section>

        {summary.error !== null ? (
          <Card title="AI market sentiment">
            <ErrorNotice error={summary.error} onRetry={summary.reload} />
          </Card>
        ) : summary.loading ? (
          <Card title="AI market sentiment">
            <SkeletonRows rows={3} />
          </Card>
        ) : (
          <MarketSentimentPanel
            summary={summary.data?.data ?? null}
            actions={<FreshnessBadge freshness={summary.data?.meta.freshness} now={now} />}
          />
        )}

        {stocks.error !== null ? (
          <Card title="Worth considering">
            <ErrorNotice error={stocks.error} onRetry={stocks.reload} />
          </Card>
        ) : stocks.loading ? (
          <Card title="Worth considering">
            <SkeletonRows rows={6} />
          </Card>
        ) : (
          <WorthConsideringTable rows={stocks.data?.data ?? []} />
        )}

        {news.error !== null ? (
          <Card title="Latest news">
            <ErrorNotice error={news.error} onRetry={news.reload} />
          </Card>
        ) : news.loading ? (
          <Card title="Latest news">
            <SkeletonRows rows={4} />
          </Card>
        ) : (
          <NewsFeed items={news.data?.data ?? []} />
        )}
      </main>
      <Disclaimer />
    </>
  );
}

export default function Home() {
  return (
    <AuthGate>
      <Dashboard />
    </AuthGate>
  );
}
