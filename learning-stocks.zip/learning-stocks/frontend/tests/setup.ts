// Adds toBeInTheDocument, toHaveAttribute and the rest of the DOM matchers.
import '@testing-library/jest-dom/vitest';
