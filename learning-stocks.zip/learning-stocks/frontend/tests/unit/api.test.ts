import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import { ApiFailure, apiGet, apiPost } from '../../lib/api';

const schema = z.object({
  data: z.object({ ok: z.boolean() }),
  meta: z.object({ data_mode: z.string(), generated_at: z.string() }),
});
const OK_BODY = { data: { ok: true }, meta: { data_mode: 'MOCK', generated_at: 'x' } };

const responder = (body: unknown, status = 200, type = 'application/json') =>
  vi.fn().mockResolvedValue(
    new Response(typeof body === 'string' ? body : JSON.stringify(body), {
      status,
      headers: { 'content-type': type },
    }),
  );

const base = 'http://127.0.0.1:4000/api';

describe('apiGet', () => {
  it('sends the bearer token and parses through the schema', async () => {
    const fetchImpl = responder(OK_BODY);
    const out = await apiGet('/health', schema, { token: 'tok-123', fetchImpl, baseUrl: base });
    expect(out.data.ok).toBe(true);
    const [url, init] = fetchImpl.mock.calls[0] as [string, RequestInit];
    expect(url).toBe(`${base}/health`);
    expect(new Headers(init.headers).get('authorization')).toBe('Bearer tok-123');
  });

  it('omits the header entirely when there is no token, so AUTH_MODE=none works', async () => {
    const fetchImpl = responder(OK_BODY);
    await apiGet('/health', schema, { token: null, fetchImpl, baseUrl: base });
    const [, init] = fetchImpl.mock.calls[0] as [string, RequestInit];
    // "Bearer null" would be a 401 on a server that would otherwise have served the request.
    expect(new Headers(init.headers).has('authorization')).toBe(false);
  });

  it('never caches a read, because a stale price is a wrong price', async () => {
    const fetchImpl = responder(OK_BODY);
    await apiGet('/health', schema, { fetchImpl, baseUrl: base });
    const [, init] = fetchImpl.mock.calls[0] as [string, RequestInit];
    expect(init.cache).toBe('no-store');
  });

  it('turns an error envelope into a typed failure, keeping the code', async () => {
    const fetchImpl = responder({ error: { code: 'NOT_FOUND', message: 'No stock NOPE' } }, 404);
    await expect(
      apiGet('/stocks/NOPE', schema, { fetchImpl, baseUrl: base }),
    ).rejects.toMatchObject({ code: 'NOT_FOUND', status: 404, message: 'No stock NOPE' });
  });

  it('carries the error details through, so a 400 can name the bad field', async () => {
    const fetchImpl = responder(
      {
        error: { code: 'VALIDATION', message: 'Invalid query parameters', details: { issues: {} } },
      },
      400,
    );
    const err = await apiGet('/stocks', schema, { fetchImpl, baseUrl: base }).catch(
      (e: unknown) => e,
    );
    expect(err).toBeInstanceOf(ApiFailure);
    expect((err as ApiFailure).details).toEqual({ issues: {} });
  });

  it('reports a contract violation as such, not as a render crash', async () => {
    // A backend rename must surface as a named failure here, not as `undefined` on screen.
    const fetchImpl = responder({
      data: { ok: 'yes' },
      meta: { data_mode: 'MOCK', generated_at: 'x' },
    });
    const err = await apiGet('/health', schema, { fetchImpl, baseUrl: base }).catch(
      (e: unknown) => e,
    );
    expect(err).toBeInstanceOf(ApiFailure);
    expect((err as ApiFailure).code).toBe('CONTRACT');
    // The message must name the offending field, or a drift takes an hour to find.
    expect((err as ApiFailure).message).toMatch(/ok/);
  });

  it('survives a non-JSON body (a proxy error page) without a parse error', async () => {
    const fetchImpl = responder('<html>502 Bad Gateway</html>', 502, 'text/html');
    await expect(apiGet('/health', schema, { fetchImpl, baseUrl: base })).rejects.toMatchObject({
      status: 502,
    });
  });

  it('reports a network failure as a failure, not an unhandled rejection', async () => {
    const fetchImpl = vi.fn().mockRejectedValue(new TypeError('fetch failed'));
    const err = await apiGet('/health', schema, { fetchImpl, baseUrl: base }).catch(
      (e: unknown) => e,
    );
    expect(err).toBeInstanceOf(ApiFailure);
    expect((err as ApiFailure).code).toBe('NETWORK');
  });

  it('builds the URL without doubling slashes', async () => {
    const fetchImpl = responder(OK_BODY);
    await apiGet('/health', schema, { fetchImpl, baseUrl: 'http://127.0.0.1:4000/api/' });
    expect((fetchImpl.mock.calls[0] as [string])[0]).toBe('http://127.0.0.1:4000/api/health');
  });
});

describe('apiPost', () => {
  it('sends JSON and the token, and parses the reply', async () => {
    const accepted = z.object({ data: z.object({ job_id: z.string().nullable() }) });
    const fetchImpl = responder({ data: { job_id: 'abc' } }, 202);
    const out = await apiPost('/sync/market', accepted, {
      body: { symbols: ['TCS'] },
      token: 'tok',
      fetchImpl,
      baseUrl: base,
    });
    expect(out.data.job_id).toBe('abc');
    const [, init] = fetchImpl.mock.calls[0] as [string, RequestInit];
    expect(init.method).toBe('POST');
    expect(new Headers(init.headers).get('content-type')).toBe('application/json');
    expect(init.body).toBe(JSON.stringify({ symbols: ['TCS'] }));
  });

  it('surfaces a budget refusal with its code, so the UI can explain it', async () => {
    const fetchImpl = responder(
      { error: { code: 'BUDGET_EXCEEDED', message: 'daily budget spent' } },
      429,
    );
    await expect(
      apiPost('/ai/analyze', schema, { body: {}, fetchImpl, baseUrl: base }),
    ).rejects.toMatchObject({ code: 'BUDGET_EXCEEDED', status: 429 });
  });
});
