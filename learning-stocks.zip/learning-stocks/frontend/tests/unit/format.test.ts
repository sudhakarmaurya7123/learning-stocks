import { describe, expect, it } from 'vitest';
import {
  UNAVAILABLE,
  formatCompactInr,
  formatInr,
  formatIstDate,
  formatIstDateTime,
  formatIstTime,
  formatNumber,
  formatPercent,
  formatSignedPercent,
  relativeAge,
} from '../../lib/format';

describe('formatInr', () => {
  it('uses Indian digit grouping', () => {
    // PRD §5: ₹10,00,000 — not ₹1,000,000. A Western grouping is a wrong number to the reader.
    expect(formatInr(1_000_000)).toBe('₹10,00,000.00');
    expect(formatInr(1639.7805)).toBe('₹1,639.78');
  });

  it('renders a missing value as unavailable, never ₹0.00', () => {
    // Measured: Intl.NumberFormat.format(null) returns "₹0.00". Without the guard, a metric the
    // provider never supplied renders as a real price of zero — a free company.
    expect(formatInr(null)).toBe(UNAVAILABLE);
    expect(formatInr(undefined)).toBe(UNAVAILABLE);
    expect(formatInr(Number.NaN)).toBe(UNAVAILABLE);
    expect(formatInr(Number.POSITIVE_INFINITY)).toBe(UNAVAILABLE);
    expect(formatInr(Number.NEGATIVE_INFINITY)).toBe(UNAVAILABLE);
  });

  it('still renders a real zero as a real zero', () => {
    // The guard must reject "no value", not the value 0: a zero dividend yield is a fact.
    expect(formatInr(0)).toBe('₹0.00');
  });

  it('keeps the sign on a negative', () => {
    expect(formatInr(-34.0428)).toBe('-₹34.04');
  });
});

describe('formatCompactInr', () => {
  it('uses crore and lakh, because a 16-digit market cap is unreadable', () => {
    // ₹1,63,28,39,13,46,312.20 is correct en-IN grouping and useless on a card.
    // 16,328,391,346,312 / 10^7 = 16,32,839.13.
    expect(formatCompactInr(16_328_391_346_312)).toBe('₹16,32,839.13 Cr');
    expect(formatCompactInr(500_000)).toBe('₹5.00 L');
    expect(formatCompactInr(1234)).toBe('₹1,234.00');
  });

  it('handles the unit boundaries exactly', () => {
    expect(formatCompactInr(99_999)).toBe('₹99,999.00');
    expect(formatCompactInr(100_000)).toBe('₹1.00 L');
    // 9,999,999 is 99.99999 lakh, which would round to "₹100.00 L" — a confusing way to write
    // one crore. The unit is picked from the rounded figure, so it promotes instead.
    expect(formatCompactInr(9_999_999)).toBe('₹1.00 Cr');
    expect(formatCompactInr(9_949_999)).toBe('₹99.50 L');
    expect(formatCompactInr(10_000_000)).toBe('₹1.00 Cr');
  });

  it('scales a negative by magnitude, keeping the sign', () => {
    expect(formatCompactInr(-10_000_000)).toBe('-₹1.00 Cr');
  });

  it('renders a missing value as unavailable', () => {
    expect(formatCompactInr(null)).toBe(UNAVAILABLE);
    expect(formatCompactInr(undefined)).toBe(UNAVAILABLE);
  });
});

describe('percentages', () => {
  it('distinguishes an unmeasurable window from a flat one', () => {
    // The API returns null when a window contains no price movement and 0 when it genuinely did
    // not move. Rendering both as "0.00%" destroys that distinction (Phase 9 finding I2).
    expect(formatPercent(null)).toBe(UNAVAILABLE);
    expect(formatPercent(undefined)).toBe(UNAVAILABLE);
    expect(formatPercent(0)).toBe('0.00%');
    expect(formatPercent(2.1201)).toBe('2.12%');
  });

  it('signs a change, because direction is the point', () => {
    expect(formatSignedPercent(2.1201)).toBe('+2.12%');
    expect(formatSignedPercent(-1.5)).toBe('-1.50%');
    // No "+0.00%": zero has no direction.
    expect(formatSignedPercent(0)).toBe('0.00%');
    expect(formatSignedPercent(null)).toBe(UNAVAILABLE);
  });
});

describe('formatNumber', () => {
  it('groups and rounds, and refuses a missing value', () => {
    expect(formatNumber(14_251_054)).toBe('1,42,51,054');
    expect(formatNumber(75.8, 1)).toBe('75.8');
    expect(formatNumber(null)).toBe(UNAVAILABLE);
    expect(formatNumber(0)).toBe('0');
  });
});

describe('IST rendering', () => {
  it('renders an instant in IST regardless of the host timezone', () => {
    // Tests run TZ=UTC and the owner's laptop is IST, so an omitted timeZone looks correct on
    // their machine and is wrong everywhere else. 09:50Z is 15:20 IST.
    expect(formatIstDateTime('2026-10-07T09:50:00.000Z')).toBe('7 Oct 2026, 3:20 pm');
    expect(formatIstTime('2026-10-07T03:45:00.000Z')).toBe('9:15 am');
    expect(formatIstDate('2026-10-07T20:00:00.000Z')).toBe('8 Oct 2026');
  });

  it('crosses the IST date boundary correctly', () => {
    // 19:30Z is 01:00 IST the NEXT day. A formatter that ignored the zone would name the wrong day.
    expect(formatIstDateTime('2026-10-07T19:30:00.000Z')).toBe('8 Oct 2026, 1:00 am');
  });

  it('marks the timezone when asked, so a reader never has to guess', () => {
    expect(formatIstDateTime('2026-10-07T09:50:00.000Z', { suffix: true })).toBe(
      '7 Oct 2026, 3:20 pm IST',
    );
  });

  it('renders a missing or unparseable timestamp as unavailable', () => {
    expect(formatIstDateTime(null)).toBe(UNAVAILABLE);
    expect(formatIstDateTime(undefined)).toBe(UNAVAILABLE);
    expect(formatIstDateTime('')).toBe(UNAVAILABLE);
    // A malformed string must not render "Invalid Date" into the page.
    expect(formatIstDateTime('not-a-date')).toBe(UNAVAILABLE);
    expect(formatIstTime('not-a-date')).toBe(UNAVAILABLE);
  });
});

describe('relativeAge', () => {
  const now = new Date('2026-10-07T10:00:00Z');

  it('reads as a human age, for "Data updated X ago"', () => {
    expect(relativeAge('2026-10-07T09:58:00Z', now)).toBe('2 min ago');
    expect(relativeAge('2026-10-07T09:00:00Z', now)).toBe('1 hr ago');
    expect(relativeAge('2026-10-07T06:00:00Z', now)).toBe('4 hr ago');
    expect(relativeAge('2026-10-06T09:00:00Z', now)).toBe('1 day ago');
    expect(relativeAge('2026-10-05T09:00:00Z', now)).toBe('2 days ago');
  });

  it('says "just now" rather than "0 min ago"', () => {
    expect(relativeAge('2026-10-07T09:59:50Z', now)).toBe('just now');
    expect(relativeAge('2026-10-07T10:00:00Z', now)).toBe('just now');
  });

  it('does not render a negative age from a clock skew', () => {
    // A server slightly ahead of the browser must not produce "-1 min ago".
    expect(relativeAge('2026-10-07T10:00:30Z', now)).toBe('just now');
  });

  it('renders a missing timestamp as unavailable', () => {
    expect(relativeAge(null, now)).toBe(UNAVAILABLE);
    expect(relativeAge('not-a-date', now)).toBe(UNAVAILABLE);
  });
});
