### Task 4: Auth — login, the bearer token, and the dev bypass

**Files:**
- Create: `frontend/lib/auth.ts`, `frontend/lib/hooks.ts`, `frontend/app/login/page.tsx`, `frontend/components/AuthGate.tsx`
- Modify: `frontend/app/layout.tsx`
- Test: `frontend/tests/unit/auth.test.ts`, `frontend/tests/components/authGate.test.tsx`, `backend/tests/integration/jwksAuth.test.ts`

**Interfaces — Produces:**
- `supabase()` — a lazily created browser client, or `null` when the env vars are absent
- `useSession()` — `{ session, token, role, loading }`, subscribed to `onAuthStateChange`
- `signIn(email, password)`, `signUp(email, password)`, `signOut()`
- `<AuthGate>` — renders children when authenticated or when the API is in `AUTH_MODE=none`, otherwise redirects to `/login`

**Ruling (made, not asked):** the browser holds the token and calls the API directly. No Next route handler proxies the API, because a proxy would need the token server-side and invites a service-role key into the server bundle. `@supabase/ssr` is not used for the same reason — there is no server-rendered authenticated data.

**Measured fact this task rests on (7):** local GoTrue signs **ES256** via JWKS and the backend already verifies it against issuer and audience. So login works with `JWT_SECRET` blank. **No existing backend test covers that path** — every one passes `jwksUrl: null` with a shared secret — so a regression there would only surface as "login is broken" in a browser. Step 1 closes that.

- [ ] **Step 1: Write the failing backend JWKS test**

`backend/tests/integration/jwksAuth.test.ts`. It must not depend on a running GoTrue, so it serves its own JWKS over loopback and signs with a matching ES256 key — proving the verifier accepts the algorithm, issuer and audience that the real token carries.

```ts
import { createServer, type Server } from 'node:http';
import { exportJWK, generateKeyPair, SignJWT } from 'jose';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { verifyToken, keyFor, type VerifyOptions } from '../../src/http/auth.js';

/**
 * The browser login path, which no other test covers.
 *
 * Measured against the real local stack on 2026-10-07: GoTrue signs ES256 and publishes one EC
 * key at /auth/v1/.well-known/jwks.json, so a browser token verifies with JWT_SECRET unset —
 * which is how .env ships. Every other auth test passes `jwksUrl: null` and a shared secret, so
 * an ES256 regression would reach the owner as "login is broken" with nothing red.
 */
describe('JWKS verification (the real browser login path)', () => {
  let server: Server;
  let origin: string;
  let signWith: (claims: Record<string, unknown>, over?: { issuer?: string; audience?: string }) => Promise<string>;
  let jwksHits = 0;
  let options: VerifyOptions;

  beforeAll(async () => {
    const { privateKey, publicKey } = await generateKeyPair('ES256');
    const jwk = { ...(await exportJWK(publicKey)), kid: 'test-key', alg: 'ES256', use: 'sig' };
    server = createServer((_req, res) => {
      jwksHits += 1;
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ keys: [jwk] }));
    });
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
    const address = server.address();
    const port = typeof address === 'object' && address !== null ? address.port : 0;
    origin = `http://127.0.0.1:${port}`;
    options = {
      secret: null,
      jwksUrl: `${origin}/auth/v1/.well-known/jwks.json`,
      issuer: `${origin}/auth/v1`,
      audience: 'authenticated',
    };
    // One signer, one key: every negative case changes exactly ONE claim, so a refusal can only
    // be the pin under test and never an incidental signature failure.
    signWith = (claims, over = {}) =>
      new SignJWT(claims)
        .setProtectedHeader({ alg: 'ES256', kid: 'test-key' })
        .setIssuer(over.issuer ?? `${origin}/auth/v1`)
        .setAudience(over.audience ?? 'authenticated')
        .setIssuedAt()
        .setExpirationTime('1h')
        .sign(privateKey);
  });

  afterAll(() => new Promise<void>((r) => server.close(() => r())));

  it('accepts an ES256 token fetched from JWKS, with no shared secret configured', async () => {
    const token = await signWith({ sub: 'user-1', role: 'authenticated', email: 'a@b.test' });
    const result = await verifyToken(token, options, keyFor(options));
    expect(result).toEqual({ sub: 'user-1', email: 'a@b.test' });
  });

  it('refuses a wrong issuer on an OTHERWISE VALID token', async () => {
    // Signed with THE SAME key the JWKS serves, so the signature verifies and the only thing
    // wrong is `iss`. Signing with a fresh key would fail on the signature instead, and the
    // test would pass with the issuer pin removed — proving nothing about the pin.
    const foreign = await signWith({ sub: 'user-1' }, { issuer: 'https://evil.example/auth/v1' });
    await expect(verifyToken(foreign, options, keyFor(options))).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
    // Control: the same claims with the right issuer DO verify, so the refusal above is the pin.
    await expect(verifyToken(await signWith({ sub: 'user-1' }), options, keyFor(options))).resolves.toMatchObject({ sub: 'user-1' });
  });

  it('refuses a wrong audience on an otherwise valid token', async () => {
    const wrongAud = await signWith({ sub: 'user-1' }, { audience: 'anon' });
    await expect(verifyToken(wrongAud, options, keyFor(options))).rejects.toMatchObject({ code: 'UNAUTHORIZED' });
  });

  it('fetches JWKS once across many authenticated requests, not once per request', async () => {
    // Auth runs before the rate limiter, so a per-request JWKS fetch is an unthrottled outbound
    // loop an attacker can drive. Measured with VALID tokens through the real app: a malformed
    // token never reaches key lookup, so asserting 0 fetches on garbage proves nothing.
    jwksHits = 0;
    await withRollback(db, async (trx) => {
      const c = createContainer(
        loadConfig({ AUTH_MODE: 'jwt', SUPABASE_URL: origin.replace('/auth/v1', '') }),
        { db: trx, logger: silentLogger, jobQueue: null },
      );
      const userId = await seedUser(trx, 'OWNER');
      const app = await buildApp(c);
      await app.ready();
      try {
        for (let i = 0; i < 3; i += 1) {
          const res = await app.inject({
            method: 'GET',
            url: '/api/market-status',
            headers: { authorization: `Bearer ${await signWith({ sub: userId, role: 'authenticated' })}` },
          });
          expect(res.statusCode).toBe(200);
        }
      } finally {
        await app.close();
        await c.close();
      }
    });
    // jose caches the key set in closure state; registerAuth builds it once per server.
    expect(jwksHits).toBe(1);
  });
});
```

`frontend/tests/unit/auth.test.ts` asserts `useSession` reads the token from a session, clears it on sign-out, and that `supabase()` returns `null` (rather than throwing) when the env vars are blank — because `AUTH_MODE=none` must work before the owner has configured Supabase at all.

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test -- jwksAuth` and `pnpm --filter @learning-stocks/frontend test -- auth`
Expected: FAIL (module missing; the JWKS test may already pass — if it does, say so and keep it as the regression guard rather than deleting it).

- [ ] **Step 3: Implement**

`lib/auth.ts` creates the client once with `createClient(url, anonKey, { auth: { persistSession: true, autoRefreshToken: true } })`, returning `null` if either env var is empty. `useSession` holds `{session, loading}`, calls `getSession()` on mount and subscribes to `onAuthStateChange`, unsubscribing on unmount.

The role comes from the **API**, not the token (PRD §12: the token's `role` is always `authenticated`). `useSession` therefore exposes `role: null` and the admin page learns the real role by calling `/system-status` and handling a 403 — the server stays the authority.

`app/login/page.tsx`: email + password, sign in and sign up, and a plain-language note that **the first account created becomes OWNER** and the rest are VIEWER. On success, redirect to `/`. On failure, show the message. If `supabase()` is null, the page explains which two env vars to set instead of rendering a dead form.

`<AuthGate>`: while `loading`, a skeleton. If there is a session, children. If not, it probes `/api/health` — public — and then one authenticated read; a 200 means the API is in `AUTH_MODE=none` and children render untokened. Otherwise it redirects to `/login`. This is what makes the dashboard usable before the owner sets up auth, which was the point of the Phase 9 decision.

- [ ] **Step 4: Run the gate.** Expected: PASS.
- [ ] **Step 5: Commit** `feat(frontend): Supabase login, bearer token plumbing, dev-bypass gate`

---

