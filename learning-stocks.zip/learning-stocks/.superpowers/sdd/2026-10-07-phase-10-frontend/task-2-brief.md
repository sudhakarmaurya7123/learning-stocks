### Task 2: The five additive backend reads, and the two deferred freshness findings

**Files:**
- Create: `backend/src/dto/news.ts`, `backend/src/dto/admin.ts`, `backend/src/repositories/LlmCallRepository.ts`
- Modify: `backend/src/http/envelope.ts`, `backend/src/repositories/{NewsRepository,StockRepository,SystemLogRepository}.ts`, `backend/src/routes/{stocks,markets,systemStatus}.ts`, `backend/src/services/StockAggregateService.ts`, `backend/src/container.ts`, `docs/api.md`
- Test: `backend/tests/unit/freshnessCadence.test.ts`, `backend/tests/integration/phase10Reads.test.ts`, and extend `backend/tests/integration/readsNeverSpend.test.ts`

**Interfaces — Produces:**
- `freshness(asOf, { ..., cadence })` where `cadence: 'quote' | 'daily' | 'news'` picks the threshold; `CADENCES` exported
- `GET /news?limit=` — market-wide feed (PRD §3.1 "Latest News")
- `GET /stocks` enriched: each row gains `quote`, `valuation_label`, `scores`, `risk_reward`, `sentiment_score`
- `GET /stocks/:symbol/news` articles gain `sentiment`, `sentiment_score`, `impact_level`, `ai_summary`
- `GET /stocks/:symbol/history` gains `indicators: { sma_20, sma_50, sma_200 }` aligned to the bars
- `GET /system-status` gains `jobs[]` (per-job last run: status, records, duration) and `llm_spend` (today's calls, tokens, ₹)

**Why these five and no more:** each closes a PRD §3 bullet that otherwise cannot be rendered (advisor's coverage matrix). All are reads of stored rows; none calls a provider or the LLM.

- [ ] **Step 1: Write the failing tests**

`backend/tests/unit/freshnessCadence.test.ts` — the two deferred findings, as tests.

**A fixed 24-hour threshold does not work, and the test below is why.** Daily bars are stored only
after the close plus a 30-minute settle (Phase 3 deviation 3), so mid-session the newest daily fact
is the *previous* session's bar — measured: on Oct 7 the stored `technical.as_of` is
`2026-10-06T03:45Z`. That bar is already more than 24h old at today's open, and on a Monday it is
72h old. A fixed window would therefore report "stale" exactly as often as the bug it replaces.
A daily fact is fresh iff it is at or after the open of the most recent **completed** session, which
needs the calendar.

```ts
import { describe, expect, it } from 'vitest';
import { freshness } from '../../src/http/envelope.js';

// 11:30 IST on Tuesday 2026-10-06, mid-session.
const NOW = new Date('2026-10-06T06:00:00Z');
// The open of the most recent COMPLETED session (Monday 2026-10-05, 09:15 IST), from the calendar.
const LAST_COMPLETE_OPEN = new Date('2026-10-05T03:45:00Z');
const open = { now: NOW, marketOpen: true, stalenessMinutes: 20, lastCompleteSessionOpen: LAST_COMPLETE_OPEN };

describe('freshness cadence (Phase 9 finding I4)', () => {
  it('treats the previous session\'s daily bar as fresh mid-session', () => {
    // THE finding: daily facts were judged against the 20-minute quote threshold, so every
    // indicator, evaluation and fundamentals panel read "stale" from 09:35 onward — while being
    // as current as a daily fact can be, because today's bar is not written until after close.
    const mondaysBar = new Date('2026-10-05T03:45:00Z');
    expect(freshness(mondaysBar, { ...open, cadence: 'quote' }).stale).toBe(true);
    expect(freshness(mondaysBar, { ...open, cadence: 'daily' }).stale).toBe(false);
  });

  it('is fresh across a weekend, where a 24-hour window would not be', () => {
    // Monday 11:30 IST with Friday's bar: 72h old and perfectly current. This case is the reason
    // the cadence is session-based rather than a fixed duration.
    const monday = new Date('2026-10-12T06:00:00Z');
    const fridaysBar = new Date('2026-10-09T03:45:00Z');
    expect(
      freshness(fridaysBar, { now: monday, marketOpen: true, stalenessMinutes: 20, lastCompleteSessionOpen: fridaysBar }).stale,
    ).toBe(false);
  });

  it('still calls a skipped session stale', () => {
    // Tuesday with Thursday's bar: a session was missed, which is a real problem worth flagging.
    const thursdaysBar = new Date('2026-10-01T03:45:00Z');
    expect(freshness(thursdaysBar, { ...open, cadence: 'daily' }).stale).toBe(true);
  });

  it('judges a quote on the quote threshold, unchanged', () => {
    expect(freshness(new Date('2026-10-06T05:50:00Z'), { ...open, cadence: 'quote' }).stale).toBe(false);
    expect(freshness(new Date('2026-10-06T05:20:00Z'), { ...open, cadence: 'quote' }).stale).toBe(true);
  });

  it('reports which cadence judged it, so the UI can explain the badge', () => {
    expect(freshness(NOW, { ...open, cadence: 'daily' }).cadence).toBe('daily');
  });

  it('never marks anything stale while the market is closed, whatever the cadence', () => {
    const closed = { ...open, marketOpen: false };
    const ancient = new Date('2026-01-01T03:45:00Z');
    for (const cadence of ['quote', 'daily'] as const) {
      expect(freshness(ancient, { ...closed, cadence }).stale).toBe(false);
    }
  });

  it('falls back to the quote threshold when the caller cannot supply a session', () => {
    // A CLI or a degraded calendar read has no session to compare against. Fall back rather than
    // throw: a freshness badge must never be the thing that fails a page.
    const { lastCompleteSessionOpen: _drop, ...noSession } = open;
    expect(freshness(new Date('2026-10-06T05:59:00Z'), { ...noSession, cadence: 'daily' }).stale).toBe(false);
  });
});
```

`backend/tests/integration/phase10Reads.test.ts` — the new routes, plus finding I2:

```ts
import { describe, expect, it } from 'vitest';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();

/** jobQueue: null and close() for the same reason as the contract test — see the note there. */
const get = async (url: string, seed?: (trx: Database) => Promise<void>) =>
  withRollback(db, async (trx) => {
    await seed?.(trx);
    const c = createContainer(loadConfig({ AUTH_MODE: 'none' }), { db: trx, logger: silentLogger, jobQueue: null });
    const app = await buildApp(c);
    await app.ready();
    try {
      const res = await app.inject({ method: 'GET', url });
      return { status: res.statusCode, body: res.json() as { data: unknown } };
    } finally {
      await app.close();
      await c.close();
    }
  });

describe('GET /news (market-wide)', () => {
  it('returns the newest articles across every stock, newest first', async () => {
    // Seeded, not ambient: `length > 0` against whatever the dev worker last wrote is a pass
    // that proves nothing, and Task 11 resets the database before running the suite.
    const { status, body } = await get('/api/news?limit=5', (trx) => seedNews(trx, 6));
    expect(status).toBe(200);
    const items = body.data as Array<{ published_at: string; linked_symbols: string[] }>;
    expect(items).toHaveLength(5);
    expect(items.length).toBeLessThanOrEqual(5);
    const times = items.map((i) => Date.parse(i.published_at));
    expect([...times].sort((a, b) => b - a)).toEqual(times);
    // PRD §3.1 wants the linked stocks on each headline.
    expect(Array.isArray(items[0]?.linked_symbols)).toBe(true);
  });

  it('rejects an absurd limit rather than scanning the table', async () => {
    expect((await get('/api/news?limit=5000')).status).toBe(400);
  });
});

describe('GET /stocks (enriched for the Worth Considering table)', () => {
  it('carries price, valuation and scores, so the table needs one request not twenty', async () => {
    const { body } = await get('/api/stocks');
    const rows = body.data as Array<Record<string, unknown>>;
    const row = rows.find((r) => r['symbol'] === 'RELIANCE');
    expect(row).toBeDefined();
    // PRD §3.1's columns: price, change %, action, valuation, scores, R:R, sentiment, risk.
    expect(row).toHaveProperty('quote');
    expect(row).toHaveProperty('valuation_label');
    expect(row).toHaveProperty('risk_reward');
    expect(row).toHaveProperty('sentiment_score');
    const scores = row?.['scores'] as Record<string, unknown>;
    expect(scores).toHaveProperty('technical');
    expect(scores).toHaveProperty('news');
  });

  it('still returns a stock with no evaluation, with nulls not omissions', async () => {
    const { body } = await get('/api/stocks?query=RELIANCE');
    const rows = body.data as Array<Record<string, unknown>>;
    expect(rows).toHaveLength(1);
    for (const k of ['quote', 'valuation_label', 'risk_reward', 'sentiment_score']) {
      expect(k in (rows[0] ?? {})).toBe(true);
    }
  });
});

describe('GET /stocks/:symbol/news (per-article AI sentiment)', () => {
  it('exposes the stored sentiment, impact and AI summary per article', async () => {
    const { body } = await get('/api/stocks/RELIANCE/news', (trx) => seedNewsWithSentiment(trx, 'RELIANCE'));
    const articles = (body.data as { articles: Array<Record<string, unknown>> }).articles;
    expect(articles.length).toBeGreaterThan(0);
    // news_ai_analysis holds these; Phase 9 deliberately did not expose them. PRD §3.2 needs them.
    for (const k of ['sentiment', 'sentiment_score', 'impact_level', 'ai_summary']) {
      expect(k in (articles[0] ?? {})).toBe(true);
    }
  });
});

describe('GET /stocks/:symbol/history (chart overlays)', () => {
  it('returns SMA series aligned to the bars, so the chart does not recompute them', async () => {
    const { body } = await get('/api/stocks/RELIANCE/history?range=1Y&interval=1d', (trx) => seedBarsAndIndicators(trx, 'RELIANCE', 300));
    const d = body.data as { bars: unknown[]; indicators: Record<string, Array<{ ts: string; value: number | null }>> };
    expect(d.bars.length).toBeGreaterThan(0);
    // One point per bar, aligned 1:1: the chart binds them directly without re-keying.
    for (const key of ['sma_20', 'sma_50', 'sma_200']) {
      expect(d.indicators[key]).toHaveLength(d.bars.length);
    }
    // Measured: indicators are backfilled 5 years, so a 1Y window starts INSIDE the warm-up
    // period and sma_20[0] is NOT null. Do not assert null on the first point of a trailing
    // window — assert the shape, and assert null only where the series genuinely has no value.
    const sma20 = d.indicators['sma_20'] ?? [];
    expect(sma20.every((pt) => pt.value === null || pt.value > 0)).toBe(true);
    expect(sma20.at(-1)?.value).toBeGreaterThan(0);
    // A bar with no stored indicator row yields null, never 0 — a 0 would draw the line on the axis.
    expect(sma20.some((pt) => pt.value === null) || sma20.length > 0).toBe(true);
  });
});

describe('GET /system-status (admin detail)', () => {
  it('reports per-job last run with records and duration, and today\'s LLM spend', async () => {
    const { body } = await get('/api/system-status');
    const d = body.data as { jobs: Array<Record<string, unknown>>; llm_spend: Record<string, unknown> };
    expect(Array.isArray(d.jobs)).toBe(true);
    const job = d.jobs[0];
    for (const k of ['job_name', 'status', 'records_processed', 'duration_ms', 'finished_at']) {
      expect(k in (job ?? {})).toBe(true);
    }
    // PRD §3.4: "LLM calls and spend vs daily budget".
    for (const k of ['calls_today', 'input_tokens', 'output_tokens', 'spent_inr', 'budget_inr']) {
      expect(k in d.llm_spend).toBe(true);
    }
  });
});

describe('performance (Phase 9 finding I2)', () => {
  it('keeps 1d measurable and equal to the quote move when a session is running', async () => {
    // The fix must not over-correct: during a session today's 1d return is real, and it must
    // agree with the quote the header shows, or the two panels contradict each other.
    // Measured 2026-10-07: 1d = 2.12 and quote.change_percent = 2.1201.
    const { body } = await get('/api/stocks/RELIANCE');
    const d = body.data as { performance: Record<string, number | null>; quote: { change_percent: number | null } | null };
    expect('1d' in d.performance).toBe(true);
    if (d.quote?.change_percent != null && d.performance['1d'] != null) {
      expect(d.performance['1d']).toBeCloseTo(d.quote.change_percent, 1);
    }
  });
});
```

The `1d`-on-a-Sunday case needs a fixed clock, so it belongs in a unit test over `StockAggregateService` with `now` injected (the deps already accept `now`). Add it to the existing `stockAggregateService.test.ts`:
```ts
  it('reports 1d as null on a day with no session, and keeps it measurable mid-session', async () => {
    // Sunday 2026-10-11, 12:00 IST. The newest quote IS Friday's close, so it is not newer than
    // the base bar's session and the arithmetic would give exactly 0 — which reads "flat today"
    // rather than "the market did not open".
    const sunday = buildService({ now: () => new Date('2026-10-11T06:30:00Z') });
    expect((await sunday.build('RELIANCE'))?.performance['1d']).toBeNull();
    // Longer windows still span real sessions and stay measurable.
    expect((await sunday.build('RELIANCE'))?.performance['1y']).not.toBeNull();

    // Pre-open Monday: a session is "today" but no tick has happened yet. Still null.
    const preOpen = buildService({ now: () => new Date('2026-10-12T02:30:00Z') });
    expect((await preOpen.build('RELIANCE'))?.performance['1d']).toBeNull();

    // Mid-session with an intraday quote newer than the last daily bar: measurable, and it must
    // agree with the quote's own change_percent.
    const midSession = buildService({ now: () => new Date('2026-10-12T06:00:00Z') });
    const agg = await midSession.build('RELIANCE');
    expect(agg?.performance['1d']).not.toBeNull();
  });
```
The mid-session case needs a seeded intraday bar newer than the newest daily bar; seed it in the
fixture rather than relying on whatever the dev worker last wrote.

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/backend test -- freshnessCadence phase10Reads`
Expected: FAIL — `cadence` is not an option, the routes 404, the fields are absent.

- [ ] **Step 3: Implement the cadence**

In `backend/src/http/envelope.ts`:
```ts
/**
 * How long a fact of each kind stays current.
 *
 * A quote goes stale in minutes. A daily fact cannot be judged by a duration at all: daily bars
 * are written only after the close plus a settle, so mid-session the newest one is yesterday's —
 * 24h+ old at today's open and 72h old on a Monday. It is fresh iff it is at or after the open of
 * the most recent COMPLETED session (Phase 9 finding I4).
 */
export type Cadence = 'quote' | 'daily';

export interface FreshnessOptions {
  now: Date;
  marketOpen: boolean;
  /** app_settings.quote_staleness_minutes (PRD §11); the threshold for `cadence: 'quote'`. */
  stalenessMinutes: number;
  /** Which kind of fact this is. Defaults to 'quote' so existing callers are unchanged. */
  cadence?: Cadence;
  /**
   * The open of the most recent completed session, from MarketCalendarService.
   *
   * Optional: a caller that cannot resolve it (a CLI, or a calendar read that degraded) falls
   * back to the quote threshold rather than throwing. A freshness badge must never be the
   * reason a page fails.
   */
  lastCompleteSessionOpen?: Date;
}

export function freshness(asOf: Date | null, o: FreshnessOptions): Freshness {
  const cadence = o.cadence ?? 'quote';
  if (asOf === null) {
    return { as_of: null, age_seconds: null, stale: true, market_open: o.marketOpen, cadence };
  }
  const ageSeconds = Math.max(0, Math.round((o.now.getTime() - asOf.getTime()) / 1000));
  const stale =
    cadence === 'daily' && o.lastCompleteSessionOpen !== undefined
      ? asOf.getTime() < o.lastCompleteSessionOpen.getTime()
      : ageSeconds > o.stalenessMinutes * 60;
  return {
    as_of: asOf.toISOString(),
    age_seconds: ageSeconds,
    // Still only ever stale while the market is open: Friday's close is not stale on a Sunday.
    stale: o.marketOpen && stale,
    market_open: o.marketOpen,
    cadence,
  };
}
```
`MarketCalendarService` needs `lastCompleteSessionOpen(exchange, at)`: the open of the newest session
whose close plus the daily settle is at or before `at`. Add it there with its own unit test
(mid-session → yesterday's open; Monday → Friday's open; after today's settle → today's open).

Then in `StockAggregateService.build`, pass the cadence per section: `quote` → `'quote'`;
`evaluation`, `technical`, `fundamental` **and `ai_analysis`** → `'daily'` (the analysis's freshness
is judged on `dataAsOf`, which is itself a daily-bar timestamp, so the news cadence would misjudge
it); `news` → `'quote'` with a generous threshold, since an article has no session. Do the same in
`routes/stocks.ts`'s `freshnessFor` (add a cadence parameter).

For finding I2, in `StockAggregateService.performance`, a window whose range contains no session is unmeasurable:
```ts
      // A window that contains no price movement cannot be measured: with the market shut, the
      // "current" price IS the base close, so the arithmetic yields exactly 0 and renders as a
      // flat trading day (Phase 9 finding I2). null says "no session in this window".
      //
      // The test is whether the CURRENT price is newer than the base bar's session, not whether
      // another daily bar exists after the cutoff: mid-session no daily bar has been written yet
      // (they land after close + settle), but the live 5m quote is genuinely newer, and today's
      // 1d return is real. Measured: 1d = 2.12 matches quote.change_percent exactly.
      const moved = currentAsOf !== null && baseBar !== null && currentAsOf.getTime() > baseBar.ts.getTime();
      out[key] = current === null || base === null || base === 0 || !moved
        ? null
        : Math.round(((current - base) / base) * 10_000) / 100;
```

- [ ] **Step 4: Implement the five reads**

Keep each one small and stored-rows-only.

- **`NewsRepository.listRecent(mode, limit)`** — newest articles across all instruments with their linked symbols (join `news_stocks` → `stocks`, aggregate symbols). Route `GET /news` in `markets.ts` with `limit` validated `z.coerce.number().int().min(1).max(100).default(20)`.
- **`StockRepository.listWithFilters`** — extend the existing `distinctOn('stock_id')` evaluation join to also select `valuation_label`, `risk_reward`, the factor `scores` jsonb and `risk_level`; left-join the latest daily bar per stock for `quote`, and the 30-day mean news sentiment. Prefer **one query with lateral joins** over N+1; if a lateral proves awkward in Kysely, two queries joined in memory is acceptable — record a ruling either way.
- **`NewsRepository.listForInstrument`** — left-join `news_ai_analysis` on `(news_id, stock_id)` and surface `sentiment`, `sentiment_score`, `impact_level`, `summary` as `ai_summary`. Null when the sentiment job has not run.
- **`/history` indicators** — read `technical_indicators` over the same window and emit `sma_20/50/200` as `{ts, value}` arrays aligned 1:1 with the bars (null where no stored indicator for that bar's `ts`). Do **not** compute them in the route: the stored series is the one the decision engine used.
- **`/system-status`** — `SystemLogRepository.lastRunPerJob()` (one row per `job_name`, newest, with `records_processed`/`execution_time_ms`) and a new `LlmCallRepository.spendToday()` (count, token sums, `sum(est_cost_inr)`), wired through `container.ts`. Both inside the existing `soft()` degradation so an unreachable DB still returns 200.

- [ ] **Step 5: Extend the no-spend proof**

In `backend/tests/integration/readsNeverSpend.test.ts`, add the new routes to the list it sweeps. That test builds a container whose LLM provider throws on any call; it is the standing proof of PRD §14's first rule, and a new read route that is not in its list is unproven.

- [ ] **Step 6: Run the gate**

Run: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`
Expected: PASS. Then update `docs/api.md` with the five additions and the cadence change, and extend the Task 1 schemas to cover the new fields (the contract test will fail until you do — that is the contract working).

- [ ] **Step 7: Commit** `feat(backend): market news, enriched list, chart overlays, admin detail; per-section freshness`

---

