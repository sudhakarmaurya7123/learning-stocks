# SDD ledger — plan: docs/superpowers/plans/2026-10-07-phase-10-frontend.md

Owner decisions (2026-10-07, "go with your recommendations"):
- Purge Mock Data: NOT built; page points at `pnpm db:reset`.
- No shadcn/ui: seven hand-written primitives; Recharts dropped.
- Freshness: fixed in the BACKEND (session-based daily cadence), accepting the /api semantics change.
- Earlier answers: additive read routes; shared zod contract; E2E outside the gate.

## Pre-flight scan (shared-interface edges)
| Producer | Consumer | Checked | Result |
|---|---|---|---|
| T1 zod schemas | T3 lib/api, T5-T10 panels | schema names exist in T1's Produces | clean |
| T1 FreshnessSchema.cadence `['quote','daily']` | T2 `export type Cadence` | enum values match both sides | clean |
| T2 NewsItemSchema + GET /news | T1 contract test | moved to T2 so T1's gate can pass | clean (fixed pre-execution) |
| T3 formatIstTime | T7 chart timeFormatter | produced in T3 Interfaces before T7 use | clean |
| T3 lib/format names | T5 primitives | formatInr/formatCompactInr/UNAVAILABLE/relativeAge all declared | clean |
| T2 lastCompleteSessionOpen | MarketCalendarService | new method; T2 Step 3 adds it with its own test | clean |
| T1 `exports` subpaths | backend NodeNext + Next Turbopack | measured fact 13; both verified in probe | clean |

Task 1: complete (commits f26552e..3016f60, tests: pnpm test → 576 passed, 9 skipped; gate green)
Task 1: Ruling: generated packages/shared/src/enums.ts mechanically from backend/src/domain/enums.ts
  instead of transcribing — my hand-written set was wrong in 4 of 9 arrays. Cost if wrong: the
  generator is a one-off script, so a future enum change needs the same regeneration (guarded by
  sharedEnums.test.ts, which fails loudly).
Task 1: Ruling: added dto/source.ts and applied it to a THIRD route (/qa in actions.ts) that the
  plan did not list — same camelCase leak, found by grep. Cost if wrong: none; it is the same fix.
Task 1: Ruling: parsed() carries its value out of withRollback via a closure variable, because the
  shared helper is typed Promise<void>. Cost if wrong: a cosmetic helper signature; behaviour is
  correct and the tests prove it.

Task 2 (in progress): findings I4 + I2 fixed, verified by sabotage.
  - I4: session-based `daily` cadence (MarketCalendarService.lastCompleteSessionOpen + Freshness.cadence).
    Sabotage (ignore cadence) → 2 failures naming the bug; restore → 382/382.
  - I2: `1d` null unless the current price is NEWER than the base bar. Sabotage (drop `moved`) → the
    Sunday and pre-open cases fail; restore → 596 pass.
Task 2: Ruling: DAILY_SETTLE_MS restated in MarketCalendarService rather than imported from
  barNormalizer — the calendar is a lower layer than the ingestion pipeline and must not depend on
  it. Cost if wrong: two constants to change together; both are pinned by tests.
Task 2: Ruling: /market-summary also uses the `daily` cadence (not in the plan's list) — it is
  computed from daily data, so the 20-minute threshold misjudged it too. Cost if wrong: none.
Task 2: Ruling: `news` keeps the `quote` cadence — an article has no session, so minutes is the
  honest measure. Cost if wrong: a news badge reads stale after 20 min; visible, not harmful.

Task 2: complete (commits 3016f60..3c38fe7, tests: pnpm test → 613 passed, 9 skipped; gate green, 0 lint errors)
Task 2: Ruling: extracted routes/history.ts because stocks.ts crossed the 400-line max-lines warning.
  The chart route owns the range/interval rules and overlay alignment — a separate concern. Cost if
  wrong: one more file to open when changing the chart contract.
Task 2: Ruling: /stocks enrichment uses correlated subqueries, not lateral joins (the plan allowed
  either). Measured live: one request returns all 20 rows with price+scores. Cost if wrong: if the
  universe grows to hundreds, revisit with a lateral or a view.
Task 2: Ruling: the `news` cadence stays 'quote' and the Cadence union is just quote|daily (the plan
  sketched a third 'news' value). An article has no session, so minutes is the honest measure and a
  third threshold would be unused machinery. Cost if wrong: a news badge reads stale after 20 min.
Task 2: Finding (not in the plan): the readsNeverSpend route-coverage guard from Phase 9 failed the
  moment /api/news existed, exactly as designed. Added to its sweep.
Task 2: Finding: news.content_hash is CHECK (~ '^[a-f0-9]{64}$'), so test seeds need a real sha256.

Task 3: complete (commits 3c38fe7..ee38245, tests: pnpm test → 30 frontend + 613 backend; gate green, 0 lint errors)
Task 3: Ruling: next.config.ts drops the `eslint` key — Next 16 REMOVED it from NextConfig
  (TS2353 at build). The root `eslint .` already lints frontend/. Cost if wrong: none.
Task 3: Ruling: turbopack.root = the REPO root, not the package. Unset, Turbopack picked up an
  unrelated pnpm-workspace.yaml in ~; pinned to frontend/, resolution broke because pnpm hoists
  `next` to the root node_modules. Cost if wrong: a build-time resolution error, immediately loud.
Task 3: Ruling: formatCompactInr picks its unit so a value rounding to 100 of the smaller unit
  promotes (₹99,99,999 → ₹1.00 Cr, not ₹100.00 L), while ₹99,999 stays in rupees. Found by my own
  boundary test. Cost if wrong: a cosmetic unit choice on one value in ten million.
Task 3: Ruling: @testing-library/user-event pinned to 14.6.7 — the plan's 14.7.0 is unpublished.
Task 3: Finding: Next 16 did NOT rewrite tsconfig.json, because it was written pre-settled
  (jsx: react-jsx, .next/dev/types in include). Measured fact 2 held.
