### Task 1: The shared contract (`packages/shared`)

**Files:**
- Create: `packages/shared/{package.json,tsconfig.json}`, `packages/shared/src/{index.ts,envelope.ts,market.ts,stock.ts,admin.ts}`
- Modify: `backend/src/services/StockAggregateService.ts` (`sources[].asOf` → `as_of`), `backend/package.json` (add the workspace dep), `backend/tsconfig.json` if a path mapping is needed
- Test: `backend/tests/integration/contract.test.ts`

**Interfaces — Produces:**
- `EnvelopeSchema<T>(data: ZodType<T>)`, `FreshnessSchema`, `MetaSchema`, `ApiErrorSchema`
- `MarketCardSchema`, `MarketStatusSchema`, `MarketSummarySchema` (`NewsItemSchema` lands in Task 2 with the route it describes)
- `StockListRowSchema`, `StockAggregateSchema` (13 sections), `QuoteSchema`, `HistorySchema`, `TechnicalSchema`, `FundamentalsSchema`, `EvaluationSchema`, `AnalysisSchema`, `SignalSchema`, `SentimentSchema`
- `SystemStatusSchema`, `JobRunSchema`, `LlmSpendSchema`
- `ActionAcceptedSchema` (`{job, job_id, already_queued}`), `QaAnswerSchema`
- Inferred types exported alongside each (`export type StockAggregate = z.infer<typeof StockAggregateSchema>`)

The schemas are **tolerant where the API is honest and strict where it is not**: every nullable section is `.nullable()`, numbers that pg returns as numeric are `z.number()`, and unknown extra keys are allowed (`.loose()` on objects that wrap jsonb) so a backend addition never breaks the browser. Required keys are required.

- [ ] **Step 1: Branch and write the failing contract test**

```bash
git checkout -b phase-10-frontend
```

`backend/tests/integration/contract.test.ts` — this is the test that makes the schemas a contract rather than a second opinion. It parses **real responses from the real app**, not fixtures.

```ts
import { describe, expect, it } from 'vitest';
import {
  ActionAcceptedSchema, EnvelopeSchema, HistorySchema, MarketCardSchema, MarketStatusSchema,
  MarketSummarySchema, StockAggregateSchema, StockListRowSchema, SystemStatusSchema,
} from '@learning-stocks/shared';
import { z } from 'zod';
import { buildApp } from '../../src/app.js';
import { loadConfig } from '../../src/config/env.js';
import { createContainer } from '../../src/container.js';
import { createTestDb, silentLogger, withRollback } from './helpers.js';

const db = createTestDb();

/**
 * Parses a live response through the shared schema the browser will use.
 *
 * `jobQueue: null` is load-bearing: /system-status resolves worker liveness, which calls
 * `queue.start()` on a real PgBossQueue (the Phase 9 T8 fix). Without the override every call
 * here would boot pg-boss against the test schema and leak a pool that SIGTERM cannot close —
 * the Phase 9 C1 defect, re-created in a helper. `close()` in the finally is the other half.
 */
async function parsed<T>(url: string, schema: z.ZodType<T>): Promise<T> {
  return withRollback(db, async (trx) => {
    const c = createContainer(loadConfig({ AUTH_MODE: 'none' }), {
      db: trx,
      logger: silentLogger,
      jobQueue: null,
    });
    const app = await buildApp(c);
    await app.ready();
    try {
      const res = await app.inject({ method: 'GET', url });
      expect(res.statusCode).toBe(200);
      const result = schema.safeParse(res.json());
      // The failure message must name the field, or a drift takes an hour to find.
      if (!result.success) throw new Error(`${url} violates its contract: ${JSON.stringify(z.treeifyError(result.error), null, 2)}`);
      return result.data;
    } finally {
      await app.close();
      await c.close();
    }
  });
}

describe('API responses satisfy the shared contract', () => {
  it('parses every read route the frontend calls', async () => {
    await parsed('/api/markets', EnvelopeSchema(z.array(MarketCardSchema)));
    await parsed('/api/market-status', EnvelopeSchema(MarketStatusSchema));
    await parsed('/api/market-summary', EnvelopeSchema(MarketSummarySchema.nullable()));
    await parsed('/api/stocks', EnvelopeSchema(z.array(StockListRowSchema)));
    await parsed('/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
    await parsed('/api/stocks/RELIANCE/history?range=6M&interval=1d', EnvelopeSchema(HistorySchema));
    await parsed('/api/system-status', EnvelopeSchema(SystemStatusSchema));
    // /api/news is Task 2's; its contract line is added there, so this task's gate can pass.
  });

  it('parses an aggregate whose every section is empty, which is a fresh database', async () => {
    // Deliberately NOT "12 of 13 sections are populated": that passes only because this dev
    // database has a worker filling it, and Task 11 runs `pnpm db:reset` before `pnpm test`.
    // The contract must hold on an empty database, which is the state a new checkout is in.
    const { data } = await parsed('/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
    expect(data.stock.symbol).toBe('RELIANCE');
    expect(Array.isArray(data.news)).toBe(true);
    for (const k of ['1d', '1w', '1m', '3m', '1y'] as const) expect(k in data.performance).toBe(true);
  });

  it('emits snake_case throughout, including inside jsonb passthroughs', async () => {
    // sources[] came back as camelCase `asOf` while every sibling key was snake_case: a jsonb
    // column passed straight through. One inconsistent key is a bug the browser inherits.
    // Seeded here rather than read from ambient data: an analysis row must exist for this to
    // assert anything, and `expect(length).toBeGreaterThan(0)` on an empty table is a pass
    // that proves nothing.
    await withRollback(db, async (trx) => {
      await seedAnalysisWithSources(trx, 'RELIANCE');
      const { data } = await parsedOn(trx, '/api/stocks/RELIANCE', EnvelopeSchema(StockAggregateSchema));
      const sources = data.ai_analysis?.sources ?? [];
      expect(sources.length).toBeGreaterThan(0);
      for (const src of sources) {
        expect(src).toHaveProperty('as_of');
        expect(src).not.toHaveProperty('asOf');
      }
    });
  });
});
```

- [ ] **Step 2: Run to verify it fails**

Run: `pnpm --filter @learning-stocks/backend test -- contract`
Expected: FAIL — `Cannot find module '@learning-stocks/shared'`.

- [ ] **Step 3: Create the package**

`packages/shared/package.json`:
```json
{
  "name": "@learning-stocks/shared",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "exports": { ".": "./src/index.ts" },
  "scripts": { "typecheck": "tsc -p tsconfig.json --noEmit" },
  "dependencies": { "zod": "4.6.5" }
}
```
`exports` points at the TypeScript source: both consumers compile it (backend via tsx/tsc, frontend via Next), so there is no build step and no stale `dist` to go out of sync.

**Every module gets its own subpath, and modules import each other by the package name** — this is
forced, not stylistic (measured fact 13): NodeNext requires `./envelope.js` and Turbopack rejects it,
so a relative import cannot satisfy both. Self-referencing package imports satisfy both:

```json
  "exports": {
    ".": "./src/index.ts",
    "./envelope": "./src/envelope.ts",
    "./market": "./src/market.ts",
    "./stock": "./src/stock.ts",
    "./admin": "./src/admin.ts"
  }
```
```ts
// packages/shared/src/stock.ts — by package name, never './envelope.js' or './envelope'
import { FreshnessSchema } from '@learning-stocks/shared/envelope';
```
A relative import added later breaks `pnpm build:web` and not `pnpm typecheck`, so the Task 3 build
step is what catches a regression here.

`packages/shared/tsconfig.json`:
```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": { "noEmit": true, "module": "preserve", "moduleResolution": "bundler" },
  "include": ["src"]
}
```

`packages/shared/src/envelope.ts`:
```ts
import { z } from 'zod';

/** PRD §12's freshness block: how old the newest stored fact is, and whether that is a problem. */
export const FreshnessSchema = z.object({
  as_of: z.string().nullable(),
  age_seconds: z.number().nullable(),
  stale: z.boolean(),
  market_open: z.boolean(),
  /** Which cadence judged `stale` (Task 2). Optional: older responses omit it. */
  cadence: z.enum(['quote', 'daily']).optional(),
});
export type Freshness = z.infer<typeof FreshnessSchema>;

export const MetaSchema = z.object({
  data_mode: z.enum(['MOCK', 'LIVE']),
  generated_at: z.string(),
  freshness: FreshnessSchema.optional(),
});
export type Meta = z.infer<typeof MetaSchema>;

/** Every successful response. Generic so each route states its own payload. */
export const EnvelopeSchema = <T extends z.ZodTypeAny>(data: T) =>
  z.object({ data, meta: MetaSchema });

export const ApiErrorSchema = z.object({
  error: z.object({
    code: z.enum([
      'VALIDATION', 'UNAUTHORIZED', 'FORBIDDEN', 'NOT_FOUND',
      'RATE_LIMITED', 'BUDGET_EXCEEDED', 'UNSUPPORTED', 'INTERNAL',
    ]),
    message: z.string(),
    details: z.record(z.string(), z.unknown()).optional(),
  }),
});
export type ApiError = z.infer<typeof ApiErrorSchema>;

/** A 202 from a sync or job route. `job_id: null` + `already_queued` is the queue deduplicating. */
export const ActionAcceptedSchema = z.object({
  job: z.string(),
  job_id: z.string().nullable(),
  already_queued: z.boolean(),
});
```

`packages/shared/src/market.ts`, `stock.ts` and `admin.ts` mirror the measured payloads exactly. Write them from the shapes in **docs/api.md** plus the live captures; the enums come from `backend/src/domain/enums.ts` (import them there? No — **restate them**, because `packages/shared` must not depend on the backend; the contract test is what keeps the two in step).

`packages/shared/src/stock.ts` (the longest; the rest follow the same style):
```ts
import { z } from 'zod';
import { FreshnessSchema } from '@learning-stocks/shared/envelope';

const num = z.number();
const nnum = z.number().nullable();

// Copied VERBATIM from backend/src/domain/enums.ts on 2026-10-07. Do not retype these from
// memory: an invented value that today's mock data never produces would pass the contract test
// and then throw ApiFailure('CONTRACT') on a live row, blanking the page. Step 4 adds a test
// asserting each array equals the backend's.
export const ACTION_STATES = [
  'BUY_ZONE', 'WAIT_FOR_PULLBACK', 'WAIT_FOR_CONFIRMATION', 'HOLD',
  'REDUCE', 'AVOID', 'INSUFFICIENT_DATA',
] as const;
export const RECOMMENDATION_BIASES = [
  'STRONG_BUY_BIAS', 'BUY_BIAS', 'HOLD_BIAS', 'SELL_BIAS', 'STRONG_SELL_BIAS',
] as const;
export const RISK_LEVELS = ['LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'] as const;
export const SENTIMENTS = ['BULLISH', 'NEUTRAL', 'BEARISH'] as const;
export const TRENDS = ['UPTREND', 'SIDEWAYS', 'DOWNTREND'] as const;
export const IMPACT_LEVELS = ['LOW', 'MEDIUM', 'HIGH'] as const;
export const VALUATION_LABELS = ['UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA'] as const;
export const MARKET_REGIMES = ['RISK_ON', 'NEUTRAL', 'RISK_OFF'] as const;
export const SIGNAL_STATUSES = ['ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED'] as const;

export const StockSchema = z.object({
  symbol: z.string(), company_name: z.string(), exchange: z.enum(['NSE', 'BSE']),
  isin: z.string().nullable(), isin_verified: z.boolean(),
  sector: z.string().nullable(), industry: z.string().nullable(),
  market_cap: nnum, currency: z.string(),
});

export const QuoteSchema = z.object({
  ts: z.string(), timeframe: z.string(), price: num,
  change: nnum, change_percent: nnum, volume: nnum, source: z.string(),
});

export const PerformanceSchema = z.object({
  // null, never 0: "we cannot measure it" and "it did not move" are different facts.
  '1d': nnum, '1w': nnum, '1m': nnum, '3m': nnum, '1y': nnum,
});

export const DecisionSchema = z.object({
  evaluated_at: z.string(), data_as_of: z.string(), scoring_config_version: z.string(),
  action_state: z.enum(ACTION_STATES), recommendation_bias: z.enum(RECOMMENDATION_BIASES),
  trend: z.enum(TRENDS), risk_level: z.enum(RISK_LEVELS),
  market_regime: z.enum(MARKET_REGIMES).nullable(),
  overall_score: nnum, risk_score: nnum, coverage: nnum,
  entry_low: nnum, entry_high: nnum, stop_loss: nnum, target_1: nnum, target_2: nnum,
  risk_reward: nnum, position_size_hint: nnum, invalidation: z.string().nullable(),
});

export const SourceSchema = z.object({
  id: z.string(), url: z.string().nullable(), as_of: z.string().nullable(),
  kind: z.string(), title: z.string().nullable(),
});

export const AnalysisSchema = z.looseObject({
  analysis_time: z.string(), status: z.string(),
  sentiment: z.enum(SENTIMENTS), sentiment_score: nnum, confidence: nnum,
  trend: z.enum(TRENDS).nullable(), risk_level: z.enum(RISK_LEVELS).nullable(),
  recommendation: z.enum(RECOMMENDATION_BIASES).nullable(), summary: z.string(),
  reasoning: z.array(z.string()),
  key_positive_factors: z.array(z.string()), key_negative_factors: z.array(z.string()),
  key_risks: z.array(z.string()), catalysts: z.array(z.string()),
  facts: z.array(z.looseObject({ statement: z.string(), source_ids: z.array(z.string()) })),
  interpretation: z.array(z.string()), insufficient_data: z.array(z.string()),
  sources: z.array(SourceSchema), model: z.string().nullable(),
});

export const SignalSchema = z.object({
  id: z.string(), signal: z.string(), confidence: nnum,
  entry_low: nnum, entry_high: nnum, stop_loss: nnum, target_price: nnum, target_2: nnum,
  suggested_quantity: nnum, valid_until: z.string(), status: z.string(),
  /** Always true: no job or route places an order (PRD §1, §11). */
  requires_manual_action: z.literal(true),
});

export const StockAggregateSchema = z.object({
  stock: StockSchema,
  quote: QuoteSchema.nullable(),
  performance: PerformanceSchema,
  technical: z.looseObject({ ts: z.string(), technical_score: nnum }).nullable(),
  fundamental: z.looseObject({ as_of: z.string(), source: z.string() }).nullable(),
  valuation: z.object({ label: z.enum(VALUATION_LABELS), valuation_score: nnum, quality_score: nnum }).nullable(),
  decision: DecisionSchema.nullable(),
  news: z.array(z.looseObject({ title: z.string(), source: z.string(), source_url: z.string().nullable(), published_at: z.string(), relevance: nnum })),
  sentiment: z.object({ window_days: num, article_count: num, average_sentiment_score: nnum }).nullable(),
  ai_analysis: AnalysisSchema.nullable(),
  signal: SignalSchema.nullable(),
  market_context: z.looseObject({ market: z.string(), sentiment: z.enum(SENTIMENTS) }).nullable(),
  data_freshness: z.record(z.string(), FreshnessSchema),
});
export type StockAggregate = z.infer<typeof StockAggregateSchema>;
```

`packages/shared/src/index.ts` re-exports all four modules.

Then: add `"@learning-stocks/shared": "workspace:*"` to `backend/package.json` dependencies and run `pnpm install`.

- [ ] **Step 4: Assert the shared enums match the backend's, then fix the camelCase leak**

`packages/shared` must not import from the backend (it is the dependency-free layer), so the two
copies are kept in step by a test rather than by the type system:

```ts
// backend/tests/unit/sharedEnums.test.ts
import { describe, expect, it } from 'vitest';
import * as shared from '@learning-stocks/shared';
import * as domain from '../../src/domain/enums.js';

describe('the shared contract enums match the domain enums', () => {
  // A value present in the domain but missing from the schema throws ApiFailure('CONTRACT') in
  // the browser and blanks the panel — and only for the rows that happen to carry it, so mock
  // data would never reveal it. RISK_LEVELS really has four values, not three.
  it.each([
    ['ACTION_STATES', shared.ACTION_STATES, domain.ACTION_STATES],
    ['RECOMMENDATION_BIASES', shared.RECOMMENDATION_BIASES, domain.RECOMMENDATION_BIASES],
    ['RISK_LEVELS', shared.RISK_LEVELS, domain.RISK_LEVELS],
    ['SENTIMENTS', shared.SENTIMENTS, domain.SENTIMENTS],
    ['TRENDS', shared.TRENDS, domain.TRENDS],
    ['IMPACT_LEVELS', shared.IMPACT_LEVELS, domain.IMPACT_LEVELS],
    ['VALUATION_LABELS', shared.VALUATION_LABELS, domain.VALUATION_LABELS],
    ['MARKET_REGIMES', shared.MARKET_REGIMES, domain.MARKET_REGIMES],
    ['SIGNAL_STATUSES', shared.SIGNAL_STATUSES, domain.SIGNAL_STATUSES],
  ])('%s', (_name, a, b) => {
    expect([...a]).toEqual([...b]);
  });
});
```

- [ ] **Step 5: Fix the camelCase leak**

In `StockAggregateService.ts`, the `ai_analysis.sources` passthrough maps the stored jsonb straight out. Map it explicitly:
```ts
              sources: analysis.sources.map((s) => ({
                id: s.id,
                url: s.url ?? null,
                // The stored jsonb uses camelCase; the wire is snake_case everywhere else.
                as_of: s.asOf ?? null,
                kind: s.kind,
                title: s.title ?? null,
              })),
```
Apply the same explicit mapping in `routes/stocks.ts`'s `analysisHandler`, which exposes `sources` too. Grep for other passthroughs before declaring this done: `rg -n 'sources|facts:|coverage' backend/src/routes backend/src/services`.

- [ ] **Step 6: Run the gate**

Run: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`
Expected: PASS, with `contract.test.ts` green. If a schema rejects a real response, **the schema is wrong unless the API is** — read the failure, decide which, and record a ruling.

Factor the helper into `parsedOn(trx, url, schema)` (used inside an existing transaction) with
`parsed(url, schema)` wrapping it in its own `withRollback`, so a seeding test and a bare test
share one code path. Write `seedAnalysisWithSources` against the real `stock_analyses` columns —
read the repository, do not guess the shape.

- [ ] **Step 7: Commit** `feat(shared): zod response contract parsed by both sides`

---

