### Task 3: Frontend scaffold, the formatting layer, and the API client

**Files:**
- Create: `frontend/{package.json,tsconfig.json,next.config.ts,postcss.config.mjs,vitest.config.ts,.env.example,.gitignore}`, `frontend/app/{layout.tsx,globals.css,page.tsx}`, `frontend/lib/{format.ts,api.ts}`
- Modify: root `package.json` (scripts), `.env.example` (fix the API URL origin), `.gitignore`
- Test: `frontend/tests/unit/{format.test.ts,api.test.ts}`

**Interfaces — Produces:**
- `formatInr(v: number | null | undefined, opts?): string`, `formatCompactInr` (Cr/L), `formatPercent`, `formatSignedPercent`, `formatNumber`, `formatQuantity`
- `formatIstDateTime(iso: string | null)`, `formatIstDate`, `formatIstTime`, `relativeAge(iso, now)`
- `UNAVAILABLE = '—'`
- `apiGet<T>(path, schema, token): Promise<T>`, `apiPost<T>(...)`, `ApiFailure` (carries `code`, `status`, `message`)
- `Consumes`: `@learning-stocks/shared` schemas from Task 1

**Why formatting is its own task with its own tests:** Review Focus 1 and 2 both live here. `Intl.format(null)` returns `₹0.00` and an omitted `timeZone` silently renders host-local time (measured facts 4 and 5). Every number and date on every page goes through this module, so one bug here is a wrong number everywhere.

- [ ] **Step 1: Write the failing tests**

`frontend/tests/unit/format.test.ts`:
```ts
import { describe, expect, it } from 'vitest';
import {
  UNAVAILABLE, formatCompactInr, formatInr, formatIstDateTime, formatPercent,
  formatSignedPercent, relativeAge,
} from '../../lib/format';

describe('formatInr', () => {
  it('uses Indian digit grouping', () => {
    // PRD §5: ₹10,00,000 — not ₹1,000,000. A Western grouping is a wrong number to the reader.
    expect(formatInr(1_000_000)).toBe('₹10,00,000.00');
    expect(formatInr(1639.7805)).toBe('₹1,639.78');
  });

  it('renders a missing value as unavailable, never ₹0.00', () => {
    // Intl.NumberFormat.format(null) returns "₹0.00" (measured). A missing P/E would then read
    // as a real price of zero, and an absent metric as a free company.
    expect(formatInr(null)).toBe(UNAVAILABLE);
    expect(formatInr(undefined)).toBe(UNAVAILABLE);
    expect(formatInr(Number.NaN)).toBe(UNAVAILABLE);
    expect(formatInr(Number.POSITIVE_INFINITY)).toBe(UNAVAILABLE);
    // A real zero is still a real zero.
    expect(formatInr(0)).toBe('₹0.00');
  });

  it('keeps the sign on a negative', () => {
    expect(formatInr(-34.0428)).toBe('-₹34.04');
  });
});

describe('formatCompactInr', () => {
  it('uses crore and lakh, because a 16-digit market cap is unreadable', () => {
    // ₹1,63,28,39,13,46,312.20 is correct grouping and useless on a card.
    expect(formatCompactInr(16_328_391_346_312)).toBe('₹16,32,839.13 Cr');
    expect(formatCompactInr(5_00_000)).toBe('₹5.00 L');
    expect(formatCompactInr(1234)).toBe('₹1,234.00');
    expect(formatCompactInr(null)).toBe(UNAVAILABLE);
  });
});

describe('formatPercent', () => {
  it('distinguishes a null window from a flat one', () => {
    // The backend returns null when a window spans no session and 0 when it genuinely did not
    // move. Rendering both as "0.00%" destroys that distinction (Phase 9 finding I2).
    expect(formatPercent(null)).toBe(UNAVAILABLE);
    expect(formatPercent(0)).toBe('0.00%');
    expect(formatSignedPercent(2.1201)).toBe('+2.12%');
    expect(formatSignedPercent(-1.5)).toBe('-1.50%');
    expect(formatSignedPercent(0)).toBe('0.00%');
  });
});

describe('IST rendering', () => {
  it('renders an instant in IST regardless of the host timezone', () => {
    // Tests run TZ=UTC and the owner's laptop is IST, so an omitted timeZone looks right on
    // their machine and is wrong everywhere else. 09:50Z is 15:20 IST.
    expect(formatIstDateTime('2026-10-07T09:50:00.000Z')).toBe('7 Oct 2026, 3:20 pm');
  });

  it('marks the timezone so a reader never has to guess', () => {
    expect(formatIstDateTime('2026-10-07T09:50:00.000Z', { suffix: true })).toMatch(/IST$/);
  });

  it('renders a missing timestamp as unavailable', () => {
    expect(formatIstDateTime(null)).toBe(UNAVAILABLE);
    expect(formatIstDateTime('not-a-date')).toBe(UNAVAILABLE);
  });
});

describe('relativeAge', () => {
  it('reads as a human age, for "Data updated X ago"', () => {
    const now = new Date('2026-10-07T10:00:00Z');
    expect(relativeAge('2026-10-07T09:58:00Z', now)).toBe('2 min ago');
    expect(relativeAge('2026-10-07T09:00:00Z', now)).toBe('1 hr ago');
    expect(relativeAge('2026-10-05T09:00:00Z', now)).toBe('2 days ago');
    expect(relativeAge('2026-10-07T09:59:50Z', now)).toBe('just now');
    expect(relativeAge(null, now)).toBe(UNAVAILABLE);
  });
});
```

`frontend/tests/unit/api.test.ts`:
```ts
import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import { ApiFailure, apiGet } from '../../lib/api';

const schema = z.object({ data: z.object({ ok: z.boolean() }), meta: z.object({ data_mode: z.string(), generated_at: z.string() }) });
const body = (b: unknown, status = 200) =>
  vi.fn().mockResolvedValue(new Response(JSON.stringify(b), { status, headers: { 'content-type': 'application/json' } }));

describe('apiGet', () => {
  it('sends the bearer token and parses through the schema', async () => {
    const fetchMock = body({ data: { ok: true }, meta: { data_mode: 'MOCK', generated_at: 'x' } });
    const out = await apiGet('/health', schema, { token: 'tok-123', fetchImpl: fetchMock });
    expect(out.data.ok).toBe(true);
    const init = fetchMock.mock.calls[0]?.[1] as RequestInit;
    expect(new Headers(init.headers).get('authorization')).toBe('Bearer tok-123');
  });

  it('omits the header entirely when there is no token, so AUTH_MODE=none works', async () => {
    const fetchMock = body({ data: { ok: true }, meta: { data_mode: 'MOCK', generated_at: 'x' } });
    await apiGet('/health', schema, { token: null, fetchImpl: fetchMock });
    const init = fetchMock.mock.calls[0]?.[1] as RequestInit;
    // "Bearer null" would be a 401 on a server that would otherwise have served the request.
    expect(new Headers(init.headers).has('authorization')).toBe(false);
  });

  it('turns an error envelope into a typed failure, keeping the code', async () => {
    const fetchMock = body({ error: { code: 'NOT_FOUND', message: 'No stock NOPE' } }, 404);
    await expect(apiGet('/stocks/NOPE', schema, { fetchImpl: fetchMock })).rejects.toMatchObject({
      code: 'NOT_FOUND', status: 404,
    });
  });

  it('reports a contract violation as such, not as a render crash', async () => {
    // A backend rename must surface as a named failure here, not as undefined on screen.
    const fetchMock = body({ data: { ok: 'yes' }, meta: { data_mode: 'MOCK', generated_at: 'x' } });
    const err = await apiGet('/health', schema, { fetchImpl: fetchMock }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ApiFailure);
    expect((err as ApiFailure).code).toBe('CONTRACT');
  });

  it('survives a non-JSON body (a proxy error page) without throwing a parse error', async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response('<html>502</html>', { status: 502 }));
    await expect(apiGet('/health', schema, { fetchImpl: fetchMock })).rejects.toMatchObject({ status: 502 });
  });
});
```

- [ ] **Step 2: Run to verify they fail**

Run: `pnpm --filter @learning-stocks/frontend test`
Expected: FAIL — the package does not exist yet.

- [ ] **Step 3: Scaffold the app by hand**

Do **not** run `create-next-app`: it writes its own lint, prettier and tsconfig choices over the repo's. Write the files.

`frontend/package.json`:
```json
{
  "name": "@learning-stocks/frontend",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "next dev -H 127.0.0.1 -p 3000",
    "build": "next build",
    "start": "next start -H 127.0.0.1 -p 3000",
    "typecheck": "tsc -p tsconfig.json --noEmit",
    "test": "TZ=UTC vitest run",
    "test:e2e": "playwright test"
  },
  "dependencies": {
    "@learning-stocks/shared": "workspace:*",
    "@supabase/supabase-js": "2.117.2",
    "lightweight-charts": "5.2.1",
    "next": "16.4.0",
    "react": "19.3.0",
    "react-dom": "19.3.0",
    "zod": "4.6.5"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "4.3.3",
    "@testing-library/jest-dom": "7.0.1",
    "@testing-library/react": "16.3.3",
    "@testing-library/user-event": "14.7.0",
    "@types/node": "22.20.5",
    "@types/react": "19.2.2",
    "@types/react-dom": "19.2.2",
    "@vitejs/plugin-react": "6.1.2",
    "jsdom": "30.1.2",
    "tailwindcss": "4.3.3",
    "vitest": "5.0.3"
  }
}
```
`-H 127.0.0.1` is load-bearing: `CORS_ORIGIN` is `http://127.0.0.1:3000`, and a page served from `localhost:3000` is a **different origin** that the API refuses (measured fact 9).

`frontend/tsconfig.json` — Next rewrites parts of this on first build (measured fact 2); write it in the shape it will settle into:
```json
{
  "compilerOptions": {
    "target": "ES2023",
    "lib": ["ES2023", "DOM", "DOM.Iterable"],
    "module": "preserve",
    "moduleResolution": "bundler",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "exactOptionalPropertyTypes": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "allowJs": true,
    "skipLibCheck": true,
    "incremental": true,
    "isolatedModules": true,
    "esModuleInterop": true,
    "resolveJsonModule": true,
    "plugins": [{ "name": "next" }],
    "paths": { "@/*": ["./*"] }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts", ".next/dev/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```
It deliberately does **not** extend `tsconfig.base.json`: that sets `module: NodeNext`, which Next rejects for app code. Strictness is restated instead.

`frontend/next.config.ts`:
```ts
import type { NextConfig } from 'next';

const config: NextConfig = {
  reactStrictMode: true,
  // The repo's root `eslint .` already lints this directory; Next's own run would duplicate it
  // with different rules.
  eslint: { ignoreDuringBuilds: true },
  // Fail the build on a type error rather than shipping it.
  typescript: { ignoreBuildErrors: false },
};
export default config;
```

`frontend/postcss.config.mjs`, `frontend/app/globals.css` (Tailwind 4, CSS-first — measured fact 3):
```css
@import 'tailwindcss';

@theme {
  --color-bull: #16a34a;
  --color-bear: #dc2626;
  --color-flat: #64748b;
  --color-warn: #d97706;
}

/* A research desk is read for long stretches; dark is the default and light is honoured. */
:root { color-scheme: dark light; }
```

`frontend/vitest.config.ts` with `@vitejs/plugin-react`, `environment: 'jsdom'`, `setupFiles` importing
`@testing-library/jest-dom/vitest`, and `projects` for `unit` and `components` — each with an
**explicit `include`**. Vitest's default include matches `**/*.spec.ts`, which would pull in
`e2e/*.spec.ts` and run Playwright specs under jsdom:
```ts
  projects: [
    { extends: true, test: { name: 'unit', include: ['tests/unit/**/*.test.ts'], environment: 'node' } },
    { extends: true, test: { name: 'components', include: ['tests/components/**/*.test.tsx'], environment: 'jsdom', setupFiles: ['./tests/setup.ts'] } },
  ],
```
Add `@playwright/test` to devDependencies in **this** task even though the specs arrive in Task 11:
`tsconfig.json` includes `**/*.ts`, so `pnpm typecheck` fails on a missing `@playwright/test` the
moment those files exist. Alternatively exclude `e2e` from the tsconfig — pick one, and record it.

`frontend/.env.example` (and a gitignored `.env.local` the owner fills):
```
# Next reads .env* from THIS directory, not the repo root.
# The origin must match the backend's CORS_ORIGIN exactly: 127.0.0.1, not localhost.
NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:4000/api
NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
# The anon/publishable key only. NEVER the service-role key: this file ships to the browser.
NEXT_PUBLIC_SUPABASE_ANON_KEY=
```
Add `frontend/.env.local` and `frontend/.next/` to `.gitignore`. Fix the root `.env.example`'s `NEXT_PUBLIC_API_BASE_URL` to `http://127.0.0.1:4000/api` (it currently says `localhost`, which CORS refuses), and note in a comment that the frontend reads its own `frontend/.env.local`.

- [ ] **Step 4: Implement `lib/format.ts`**

The null guard is the whole point of the module:
```ts
export const UNAVAILABLE = '—';

/** A value we can render. null, undefined, NaN and ±Infinity are all "we do not have it". */
const usable = (v: number | null | undefined): v is number => typeof v === 'number' && Number.isFinite(v);

const inr = new Intl.NumberFormat('en-IN', {
  style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2,
});

/**
 * ₹ with Indian digit grouping, or the unavailable marker.
 *
 * The guard is not defensive programming: Intl.NumberFormat.format(null) returns "₹0.00", so
 * without it a metric the provider never supplied renders as a real price of zero.
 */
export function formatInr(v: number | null | undefined): string {
  return usable(v) ? inr.format(v) : UNAVAILABLE;
}

const CRORE = 10_000_000;
const LAKH = 100_000;

/** Market caps in crore/lakh: correct en-IN grouping of a 16-digit number is unreadable. */
export function formatCompactInr(v: number | null | undefined): string {
  if (!usable(v)) return UNAVAILABLE;
  const abs = Math.abs(v);
  if (abs >= CRORE) return `${inr.format(v / CRORE)} Cr`;
  if (abs >= LAKH) return `${inr.format(v / LAKH)} L`;
  return inr.format(v);
}
```
Dates take an explicit `timeZone: 'Asia/Kolkata'` on every formatter — never the host default (measured fact 5) — and `relativeAge` takes `now` as a parameter so it is deterministic in tests and can be rendered without a hydration mismatch (Task 5 owns the client-only mount).

- [ ] **Step 5: Implement `lib/api.ts`**

```ts
export class ApiFailure extends Error {
  constructor(
    readonly code: string,
    readonly status: number,
    message: string,
    readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'ApiFailure';
  }
}
```
`apiGet` builds the URL from `NEXT_PUBLIC_API_BASE_URL`, sets `Authorization` **only when a token exists** (so `AUTH_MODE=none` works untokened), reads the body once as text and `JSON.parse`es defensively (a proxy's HTML error page must not throw a parse error), maps an `{error}` envelope to `ApiFailure` with its code, and parses success through the caller's schema — a `safeParse` failure becomes `ApiFailure('CONTRACT', …)`. `fetchImpl` is injectable for tests. Reads use `cache: 'no-store'`: a research desk must never show a cached price.

- [ ] **Step 6: Root scripts and install**

Root `package.json`: `"dev:web": "pnpm --filter @learning-stocks/frontend dev"`, `"build:web": "pnpm --filter @learning-stocks/frontend build"`, `"test:e2e": "pnpm --filter @learning-stocks/frontend test:e2e"`. `pnpm typecheck` and `pnpm test` already recurse with `--if-present`, so the new package joins the gate automatically.

Run `pnpm install`. If pnpm 11 blocks a postinstall build (`sharp`, `@swc/core`), add it to the root `allowBuilds` rather than disabling the check, and record a ruling.

- [ ] **Step 7: Run the gate**

Run: `pnpm format && pnpm typecheck && pnpm test && pnpm lint`
Expected: PASS. Then `pnpm --filter @learning-stocks/frontend build` once to let Next settle `tsconfig.json`, and re-run `pnpm typecheck` to confirm the settled file still passes.

- [ ] **Step 8: Commit** `feat(frontend): Next 16 scaffold, en-IN/IST formatting, typed API client`

---

