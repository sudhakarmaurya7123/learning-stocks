# Indian Stock Research Platform — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (recommended for Phase 1: strictly sequential tasks with owner checkpoints) or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a personal, AI-assisted NSE/BSE stock research, decision-support and paper-trading platform. This document plans all 14 phases and breaks Phase 1 (database) into detailed tasks.

**Architecture:** Supabase Postgres + pgvector is the foundation (SQL migrations are the schema of record). A Fastify backend and a pg-boss worker share service classes. Providers (market, news, fundamentals, LLM) sit behind interfaces. Deterministic engines compute indicators, scores, levels and action states; the LLM only explains them. The Next.js frontend renders backend DTOs.

**Tech Stack:** TypeScript (strict), Node ≥ 22, pnpm workspaces, Supabase CLI (local Docker), Postgres 15+ with pgvector ≥ 0.8 and pgTAP, Fastify, Kysely, zod, pino, pg-boss, Vitest, Next.js, Tailwind, shadcn/ui, lightweight-charts, OpenAI.

**Spec:** [PRD.md](PRD.md) is the source of truth. Read it before any task.

## Global Constraints

- Node ≥ 22, pnpm 11, TypeScript `~6.0` (typescript-eslint does not yet support TS 7).
- All timestamps `timestamptz` in UTC. Market logic uses `Asia/Kolkata`. Regular session is `[09:15, 15:30)` IST, Mon–Fri, minus `exchange_holidays`.
- Prices and money are `numeric(18,4)`. Scores are the `public.score` domain (0–100; 50 = neutral for sentiment).
- Every data-bearing table carries `data_mode` (`MOCK|LIVE`) inside its unique keys. Mock and live data never mix.
- Embeddings are `extensions.vector(1536)` (`text-embedding-3-small`).
- No hardcoded stock symbols in business logic. Instruments are seed data.
- No ISIN, holiday or fee value is typed from memory. Each comes from an official file or is entered by the user, otherwise it stays NULL/unverified.
- RLS is enabled on every public table. `anon`/`authenticated` have no table privileges. The backend connects as a privileged role.
- Banned output language: "guaranteed", "will definitely", "sure-shot", "risk-free", "certain to rise/fall".
- Commit messages end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.
- Each phase ends with tests green, a written report, and **a stop for owner approval**.

## Review Focus

- **UTC vs IST date boundary:** `2026-10-05 22:00 UTC` is 03:30 IST on Oct 6, so the market must report closed, and holidays are matched on the IST date, not the UTC date. Covered in Task 3.
- **Mock/live leakage:** a MOCK vector search must never return LIVE documents, and a LIVE quote must never use MOCK bars. Covered in Tasks 4 and 6.
- **Paper cash at the exact boundary:** a buy whose cost + fees equals available cash must execute and leave ₹0. One paisa more must be rejected with no cash change. Covered in Task 8.
- **Full exit then re-entry:** selling the whole position deletes it, and a later buy starts a fresh average cost (no stale average). Covered in Task 8.
- **Filtered vector search under-returning:** a stock filter with HNSW post-filtering must still return k rows when ≥ k matches exist. Covered in Task 6.

---

## Phase overview

| #   | Phase                         | Status  | Exit criteria                                                                                                                                                            |
| --- | ----------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 0   | Repo + docs                   | ✅ done | git repo, root configs, `.env.example`, PRD.md, this plan                                                                                                                |
| 1   | Database                      | ✅ done | `pnpm db:reset && pnpm db:test` green; seeds verified by the owner                                                                                                       |
| 2   | Backend foundation            | ✅ done | Fastify boots; `/api/health`; env validated; repositories tested against local DB; MarketCalendarService matches the SQL mirror                                          |
| 3   | Market provider               | ✅ done | Mock + Yahoo adapters behind `MarketDataProvider`; MarketDataService ingest with validation, dedupe, per-symbol isolation, retry, logging; Yahoo symbol mapping verified |
| 4   | News + fundamentals providers | ✅ done | Mock/RSS/NewsAPI news adapters; dedupe by hash and URL; mentions and relevance; Mock/Yahoo fundamentals with null-aware storage                                          |
| 5   | Technical + decision engine   | ✅ done | Indicators match reference values; LevelsService, ScoringEngine, ValuationEngine, DecisionEngine are pure and unit-tested; `stock_evaluations` written                   |
| 6   | RAG                           | ✅ done | LLMProvider (Mock + OpenAI); EmbeddingService; chunker; retriever with re-rank and MMR; context builder; citation validator                                              |
| 7   | AI analysis                   | ✅ done | Prompts v1; Sentiment, AIAnalysis, MarketSummary, TradeSignal, Q&A services; deterministic overwrite; hash gating; budget; `llm_calls`                                   |
| 8   | Jobs                          | ✅ done | pg-boss worker with IST schedules, calendar gates, chains, singleton keys; every run logged                                                                              |
| 9   | REST API                      | ✅ done | All PRD §12 routes; JWT + roles; rate limits; zod validation; caching; aggregate DTO                                                                                     |
| 10  | Frontend                      | outline | Dashboard, stock page (decision card, chart, panels, chat), admin page; no secrets in bundle                                                                             |
| 11  | Paper trading                 | outline | FeeCalculator, PaperTrading/Portfolio services, routes, UI; all PRD §11 rules                                                                                            |
| 12  | Integration/E2E               | outline | Full mock pipeline test; Playwright covers success criteria 1–26                                                                                                         |
| 13  | Hardening                     | outline | Security review, bundle secret scan, rate-limit and failure drills, provider-outage behaviour                                                                            |
| 14  | Deployment                    | outline | Supabase cloud push, API + worker + frontend deployed, README and docs/* complete                                                                                        |

Each outline phase gets its own detailed TDD task list (written with writing-plans and appended here) **when that phase starts**. That way it is based on the code that actually exists, not guesses.

### Phase 2 detailed plan

Phase 2 was planned and executed from its own file, [docs/superpowers/plans/2026-10-05-phase-2-backend.md](docs/superpowers/plans/2026-10-05-phase-2-backend.md), because the task tooling keys on `### Task N` headings, which Phase 1 already uses here. Later phases follow the same pattern: Phase 3 → [docs/superpowers/plans/2026-10-05-phase-3-market-data.md](docs/superpowers/plans/2026-10-05-phase-3-market-data.md); Phase 4 → [docs/superpowers/plans/2026-10-05-phase-4-news-fundamentals.md](docs/superpowers/plans/2026-10-05-phase-4-news-fundamentals.md); Phase 5 → [docs/superpowers/plans/2026-10-06-phase-5-decision-engine.md](docs/superpowers/plans/2026-10-06-phase-5-decision-engine.md); Phase 6 → [docs/superpowers/plans/2026-10-06-phase-6-rag.md](docs/superpowers/plans/2026-10-06-phase-6-rag.md); Phase 7 → [docs/superpowers/plans/2026-10-06-phase-7-ai-analysis.md](docs/superpowers/plans/2026-10-06-phase-7-ai-analysis.md); Phase 8 → [docs/superpowers/plans/2026-10-06-phase-8-jobs.md](docs/superpowers/plans/2026-10-06-phase-8-jobs.md); Phase 9 → [docs/superpowers/plans/2026-10-07-phase-9-rest-api.md](docs/superpowers/plans/2026-10-07-phase-9-rest-api.md).

### Phase 2–14 outlines

**Phase 2: Backend foundation.** `packages/shared` (enums mirrored from DB, zod DTOs). `backend/` package: `config/env.ts` (zod-validated env, fails fast), `utils/logger.ts` (pino), `utils/errors.ts` (AppError taxonomy from PRD §6.4), `utils/retry.ts` (`withRetry` with backoff + jitter, no retry on AUTH_FAILED), `utils/http.ts` (timeout), `utils/cache.ts` (`Cache` interface + LRU), `database/db.ts` (Kysely + `kysely-codegen` types), repositories (Stock, Market, MarketData, Technical, Fundamentals, News, Embedding, Evaluation, AIAnalysis, PaperTrade, Portfolio, SystemLog, AppSettings), `services/MarketCalendarService.ts` (tested against the same cases as the SQL `is_market_open`), `container.ts`, `server.ts` with `/api/health`.

**Phase 3: Market provider.** `providers/market/types.ts`, `MockMarketDataProvider` (seeded GBM, fixture base levels in `fixtures/mock-base-levels.json` labelled MOCK), `YahooMarketDataProvider` (`yahoo-finance2`, capabilities = delayed), `providers/factory.ts`. `MarketDataService.syncQuotes/syncHistory`: resolve provider symbols, validate (PRD §6.5), upsert with ON CONFLICT DO NOTHING, return `{fetched, inserted, skipped, failed, failures[]}`, write `system_logs`. Script `scripts/verify-provider-symbols.ts` flips `provider_symbols.verified`.

**Phase 4: News + fundamentals.** `NewsProvider` adapters (Mock, RSS via `rss-parser`, NewsAPI). `NewsService`: normalise, `content_hash = sha256(normalised title + source)`, URL canonicalisation, mention matching (symbol, company name, aliases) with relevance. `FundamentalsProvider` (Mock, Yahoo). `FundamentalsService` stores snapshots and statements; unsupported fields → null.

**Phase 5: Technical + decision engine.** `technical/indicators.ts` (wrap `technicalindicators`; reference-value tests), `technical/levels.ts`, `scoring/ScoringEngine.ts`, `scoring/ValuationEngine.ts`, `scoring/DecisionEngine.ts` (rule table PRD §8.5), `services/TechnicalAnalysisService.ts`, `services/EvaluationService.ts` (computes `input_hash`, writes `stock_evaluations`). All engines are pure functions over typed inputs.

**Phase 6: RAG.** `providers/llm/types.ts`, `MockLLMProvider`, `OpenAIProvider` (Structured Outputs, embeddings). `rag/chunker.ts`, `services/EmbeddingService.ts` (embed once per hash), `rag/retriever.ts` (match_documents → re-rank → MMR), `rag/contextBuilder.ts` (ID'd blocks), `rag/citationValidator.ts`.

**Phase 7: AI analysis.** `prompts/*_v1.txt`, `ai/promptLoader.ts`, `ai/schemas.ts`, `ai/outputGuards.ts` (banned phrases, deterministic overwrite), `services/SentimentService.ts`, `services/AIAnalysisService.ts`, `services/MarketSummaryService.ts`, `services/TradeSignalService.ts`, `services/QAService.ts`, `ai/llmBudget.ts`.

**Phase 8: Jobs.** ✅ done — `jobs/types.ts` (`JobQueue`), `jobs/PgBossQueue.ts` (the only pg-boss import), `jobs/gates.ts`, `jobs/runJob.ts` (gate → run → chain → log), `jobs/registry.ts`, `jobs/schedules.ts` (PRD §13 in IST), `jobs/handlers/*`, `worker.ts` + `workerMain.ts`, `pnpm job` CLI.

Three deviations from PRD §13 were approved for this phase; later phases should not re-litigate them:

1. **No separate `technical.compute` job.** `EvaluationService.run` already computes and stores the indicator rows, so `technical.compute → evaluation.compute` collapses into `evaluation.compute`.
2. **`ai.daily.summary` (16:15) is a forced market summary.** PRD §13 names the job but defines no artifact for it; it regenerates the market summary so the day closes with one stamped after the close. A distinct daily digest would need its own PRD section.
3. **EOD market sync runs at 16:05, not 16:00, and verifies the bar landed.** A daily bar is final at `close + 30 min` = 16:00 exactly, so a 16:00 run races the settle window; when the settled session has no stored bar the run is amended to `PARTIAL` and the chain stops.

Also: AI jobs are gated on the trading day (not only on the LLM being configured), because `news.sync` keeps changing the retrieved context and would otherwise spend the budget on a weekday holiday. Jobs do not retry on service failure — services already report `FAILED`/`PARTIAL` and log it.

**Phase 9: REST API.** ✅ done — `http/{auth,rateLimit,validate}.ts`, `routes/{markets,stocks,aggregate,actions,systemStatus}.ts`, `dto/*`, `services/StockAggregateService.ts` (PRD §12 aggregate), `services/SystemHealthService.ts`. Tests use Fastify `inject`. See [docs/api.md](docs/api.md).

Six deviations were approved for this phase; later phases should not re-litigate them:

1. **`AUTH_MODE=none`** answers every request as OWNER for local development. Refused with `MOCK_DATA=false`, refused off loopback, warns at startup. Full JWT + roles are implemented and tested as PRD §15 describes.
2. **`/portfolio` and `/paper-trade/*` belong to Phase 11**, next to the `FeeCalculator` and `PaperTradingService` that make them work. No Phase 9 route places an order.
3. **A deduplicated sync returns `202 {job_id: null, already_queued: true}`** rather than looking like a lost request.
4. **Manual triggers bypass calendar gates through a `manual` flag, never `force`.** `force` reaches the AI services' hash cache, so reusing it would make one click force-regenerate every stock; only `POST /ai/regenerate` sets it. `GateResult` now tags refusals `calendar` or `availability`.
5. **`meta.freshness` is market-aware**: `stale` is only true while the market is open, so Friday's close is not stale on a Sunday.
6. **Caching is TTL-only** (quotes 30 s, aggregates 60 s). The worker and API are separate processes with separate caches, so PRD §14's "invalidated on job completion" cannot run as written.

**Phase 10: Frontend.** Next.js app: `lib/api.ts`, `lib/format.ts` (`en-IN` ₹, IST), pages `/`, `/stocks/[symbol]`, `/portfolio`, `/admin`, components (IndexCard, DecisionCard, PriceChart, TechnicalPanel, FundamentalsPanel, AIAnalysisPanel, NewsPanel, QAChat, SignalCard, OrderBox, FreshnessBadge, MockBanner, Disclaimer).

**Phase 11: Paper trading.** `paperTrading/FeeCalculator.ts`, `paperTrading/PaperTradingService.ts` (staleness, market-closed, quantity rules → `execute_paper_order`), `paperTrading/PortfolioService.ts` (mark-to-market, P&L, vs NIFTY), routes and UI.

**Phase 12–14:** see the phase table. Detailed when they start.

---

## Phase 1: Database (detailed)

### File structure

```
supabase/
├── config.toml                                    # from `supabase init`; seed paths edited (Task 10)
├── migrations/
│   ├── 20261005000100_extensions_types.sql        # Task 1: extensions, enums, domains
│   ├── 20261005000200_reference.sql               # Task 2: updated_at fn, markets, stocks, provider_symbols, links, holidays
│   ├── 20261005000300_market_calendar.sql         # Task 3: is_market_open, next_market_open
│   ├── 20261005000400_market_data.sql             # Task 4: market_data, technical_indicators
│   ├── 20261005000500_fundamentals.sql            # Task 5: fundamental_snapshots, financial_statements
│   ├── 20261005000600_news_rag.sql                # Task 6: news, mentions, news_ai_analysis, embeddings, match_documents
│   ├── 20261005000700_config_ops.sql              # Task 7: app_settings, scoring_configs, system_logs, llm_calls
│   ├── 20261005000800_evaluation_ai.sql           # Task 7: stock_evaluations, stock_ai_analysis, market_ai_summary, ai_trade_signals, ai_qa_log
│   ├── 20261005000900_paper_trading.sql           # Task 8: profiles, fees, accounts, positions, orders, trades, triggers, execute_paper_order
│   └── 20261005001000_views_security.sql          # Task 9: views, RLS, privilege revokes
├── seeds/                                         # Task 10 (applied in lexical order)
│   ├── 01_markets.sql  02_stocks.sql  03_stock_isins.sql  04_provider_symbols.sql
│   ├── 05_stock_market_links.sql  06_holidays_2026.sql  07_config.sql
└── tests/database/                                # pgTAP, one file per task
    ├── 01_foundation.test.sql … 10_seed.test.sql
scripts/nse/isin-lookup.mjs  scripts/nse/holidays-to-sql.mjs   # Task 10
docs/database.md                                                # Task 11
```

### Commands used throughout

- Start the local stack once: `pnpm db:start` (first run pulls Docker images, which takes several minutes).
- After any migration or seed change: `pnpm db:reset` (drops the DB, reapplies all migrations and seeds).
- Run DB tests: `pnpm db:test` (pg_prove over `supabase/tests/**/*.sql`). A single file: `pnpm exec supabase test db supabase/tests/database/<file>`.
- Every pgTAP file starts with `begin; create extension if not exists pgtap with schema extensions;` and ends with `select * from finish(); rollback;`. Tests never leave data behind.

---

### Task 1: Supabase project, extensions, enums, domains

**Files:**

- Create: `supabase/config.toml` (via CLI), `supabase/migrations/20261005000100_extensions_types.sql`
- Modify: `package.json` (db:start excludes unused services)
- Test: `supabase/tests/database/01_foundation.test.sql`

**Interfaces:**

- Produces: enums `exchange_code, market_type, data_mode, bar_interval, sentiment, impact_level, trend, risk_level, recommendation_bias, action_state, valuation_label, market_regime, trade_side, order_status, order_source, signal_type, signal_status, period_type, link_type, user_role, job_status, analysis_status`; domains `public.score` (numeric(5,2) 0–100) and `public.price` (numeric(18,4) > 0).

- [ ] **Step 1: Initialise Supabase and trim the local stack**

```bash
pnpm exec supabase init < /dev/null   # stdin closed: declines the optional IDE-settings prompts
```

In `supabase/config.toml` set `project_id = "learning-stocks"`. In root `package.json` change the `db:start` script to:

```json
"db:start": "supabase start -x realtime,storage-api,imgproxy,edge-runtime,logflare,vector,supavisor"
```

Run `pnpm db:start`. Expected: the stack prints `DB URL: postgresql://postgres:postgres@127.0.0.1:54322/postgres`.

- [ ] **Step 2: Write the failing test** `supabase/tests/database/01_foundation.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

select has_extension('vector', 'pgvector installed');
select has_extension('pg_trgm', 'pg_trgm installed');
select ok(
  string_to_array((select extversion from pg_extension where extname = 'vector'), '.')::int[] >= array[0,8,0],
  'pgvector >= 0.8.0 (needed for hnsw.iterative_scan)'
);
select has_enum('public', 'data_mode', 'data_mode enum exists');
select enum_has_labels('public', 'action_state',
  array['BUY_ZONE','WAIT_FOR_PULLBACK','WAIT_FOR_CONFIRMATION','HOLD','REDUCE','AVOID','INSUFFICIENT_DATA']);
select enum_has_labels('public', 'recommendation_bias',
  array['STRONG_BUY_BIAS','BUY_BIAS','HOLD_BIAS','SELL_BIAS','STRONG_SELL_BIAS']);
select throws_ok($$select 100.01::public.score$$, '23514', null, 'score domain rejects > 100');
select throws_ok($$select 0::public.price$$, '23514', null, 'price domain rejects 0');

select * from finish();
rollback;
```

- [ ] **Step 3: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`has_enum` / pgvector assertions fail, `type "public.score" does not exist`).

- [ ] **Step 4: Write the migration** `supabase/migrations/20261005000100_extensions_types.sql`

```sql
-- Extensions -----------------------------------------------------------------
create extension if not exists vector with schema extensions;
create extension if not exists pg_trgm with schema extensions;

-- Enums (closed sets; mirrored in packages/shared) -----------------------------
create type public.exchange_code       as enum ('NSE', 'BSE');
create type public.market_type         as enum ('BROAD_INDEX', 'SECTOR_INDEX', 'VOLATILITY');
create type public.data_mode           as enum ('MOCK', 'LIVE');
create type public.bar_interval        as enum ('1m', '5m', '15m', '1d');
create type public.sentiment           as enum ('BULLISH', 'NEUTRAL', 'BEARISH');
create type public.impact_level        as enum ('LOW', 'MEDIUM', 'HIGH');
create type public.trend               as enum ('UPTREND', 'SIDEWAYS', 'DOWNTREND');
create type public.risk_level          as enum ('LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH');
create type public.recommendation_bias as enum ('STRONG_BUY_BIAS', 'BUY_BIAS', 'HOLD_BIAS', 'SELL_BIAS', 'STRONG_SELL_BIAS');
create type public.action_state        as enum ('BUY_ZONE', 'WAIT_FOR_PULLBACK', 'WAIT_FOR_CONFIRMATION', 'HOLD', 'REDUCE', 'AVOID', 'INSUFFICIENT_DATA');
create type public.valuation_label     as enum ('UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA');
create type public.market_regime       as enum ('RISK_ON', 'NEUTRAL', 'RISK_OFF');
create type public.trade_side          as enum ('BUY', 'SELL');
create type public.order_status        as enum ('PENDING', 'EXECUTED', 'REJECTED', 'CANCELLED');
create type public.order_source        as enum ('MANUAL', 'AI_SIGNAL');
create type public.signal_type         as enum ('BUY', 'SELL', 'HOLD');
create type public.signal_status       as enum ('ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED');
create type public.period_type         as enum ('QUARTERLY', 'ANNUAL', 'TTM');
create type public.link_type           as enum ('BENCHMARK', 'SECTOR_INDEX', 'CONSTITUENT');
create type public.user_role           as enum ('OWNER', 'ADMIN', 'VIEWER');
create type public.job_status          as enum ('STARTED', 'SUCCESS', 'PARTIAL', 'FAILED', 'SKIPPED');
create type public.analysis_status     as enum ('OK', 'FAILED', 'INSUFFICIENT_DATA');

-- Domains ----------------------------------------------------------------------
-- 0..100 score; for sentiment, 50 = neutral.
create domain public.score as numeric(5,2) check (value >= 0 and value <= 100);
-- Strictly positive INR price.
create domain public.price as numeric(18,4) check (value > 0);
```

- [ ] **Step 5: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `01_foundation.test.sql .. ok`, `All tests successful.`
If the pgvector version assertion fails, report the installed version to the owner. Task 6 then drops the `set hnsw.iterative_scan` clause and over-fetches instead.

- [ ] **Step 6: Commit**

```bash
git add supabase package.json
git commit -m "feat(db): supabase project, extensions, enums and domains" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 2: Reference tables (markets, stocks, provider symbols, links, holidays)

**Files:**

- Create: `supabase/migrations/20261005000200_reference.sql`
- Test: `supabase/tests/database/02_reference.test.sql`

**Interfaces:**

- Consumes: enums from Task 1.
- Produces: `public.set_updated_at()` trigger fn; tables `markets, stocks, provider_symbols, stock_market_links, exchange_holidays` (columns exactly as below).

- [ ] **Step 1: Write the failing test** `supabase/tests/database/02_reference.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(12);

select has_table('public', t, 'table ' || t) from unnest(array['markets','stocks','provider_symbols','stock_market_links','exchange_holidays']) t;

insert into public.stocks (symbol, company_name, exchange, sector) values ('TESTA', 'Test A Ltd', 'NSE', 'Testing');
insert into public.markets (symbol, name, exchange, market_type) values ('TESTIDX', 'Test Index', 'NSE', 'BROAD_INDEX');

select throws_ok($$insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Dup', 'NSE')$$,
  '23505', null, 'stock symbol unique per exchange');
select lives_ok($$insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Same co on BSE', 'BSE')$$,
  'same symbol allowed on another exchange');
select throws_ok($$insert into public.stocks (symbol, company_name, exchange, isin) values ('TESTB', 'Bad', 'NSE', 'US0378331005')$$,
  '23514', null, 'non-Indian ISIN rejected');
select throws_ok($$insert into public.stocks (symbol, company_name, exchange) values ('bad sym', 'Bad', 'NSE')$$,
  '23514', null, 'lowercase/space symbol rejected');

select throws_ok($$insert into public.provider_symbols (provider, stock_id, market_id, provider_symbol)
  values ('yahoo', (select id from public.stocks where symbol='TESTA' and exchange='NSE'),
                   (select id from public.markets where symbol='TESTIDX'), 'X')$$,
  '23514', null, 'provider symbol must have exactly one owner');
select throws_ok($$insert into public.provider_symbols (provider, provider_symbol) values ('yahoo', 'X')$$,
  '23514', null, 'provider symbol with no owner rejected');

select throws_ok($$insert into public.exchange_holidays (exchange, holiday_date, description, special_open)
  values ('NSE', '2026-12-31', 'half-specified special session', '18:00')$$,
  '23514', null, 'special session needs both open and close');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL in `02_reference.test.sql` (`relation "public.stocks" does not exist`).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005000200_reference.sql`

```sql
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := clock_timestamp();
  return new;
end $$;

create table public.markets (
  id          uuid primary key default gen_random_uuid(),
  symbol      text not null check (symbol ~ '^[A-Z0-9&_.-]{1,32}$'),
  name        text not null,
  exchange    public.exchange_code not null,
  market_type public.market_type not null,
  sector      text,
  description text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (exchange, symbol)
);

create table public.stocks (
  id            uuid primary key default gen_random_uuid(),
  symbol        text not null check (symbol ~ '^[A-Z0-9&_.-]{1,32}$'),
  company_name  text not null,
  exchange      public.exchange_code not null,
  isin          text check (isin ~ '^IN[A-Z0-9]{9}[0-9]$'),
  isin_verified boolean not null default false,
  sector        text,
  industry      text,
  market_cap    numeric(20,2) check (market_cap >= 0),
  currency      char(3) not null default 'INR',
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (exchange, symbol),
  constraint stocks_verified_isin_present check (not isin_verified or isin is not null)
);
create index stocks_isin_idx on public.stocks (isin);
create index stocks_company_name_trgm_idx on public.stocks using gin (company_name extensions.gin_trgm_ops);

create table public.provider_symbols (
  id              uuid primary key default gen_random_uuid(),
  provider        text not null check (provider ~ '^[a-z0-9_]+$'),
  stock_id        uuid references public.stocks (id) on delete cascade,
  market_id       uuid references public.markets (id) on delete cascade,
  provider_symbol text not null,
  verified        boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint provider_symbols_one_owner check (num_nonnulls(stock_id, market_id) = 1)
);
create unique index provider_symbols_stock_uq  on public.provider_symbols (provider, stock_id)  where stock_id is not null;
create unique index provider_symbols_market_uq on public.provider_symbols (provider, market_id) where market_id is not null;
create unique index provider_symbols_symbol_uq on public.provider_symbols (provider, provider_symbol);

create table public.stock_market_links (
  stock_id   uuid not null references public.stocks (id) on delete cascade,
  market_id  uuid not null references public.markets (id) on delete cascade,
  link_type  public.link_type not null,
  created_at timestamptz not null default now(),
  primary key (stock_id, market_id, link_type)
);
create index stock_market_links_market_idx on public.stock_market_links (market_id);

create table public.exchange_holidays (
  id            uuid primary key default gen_random_uuid(),
  exchange      public.exchange_code not null,
  holiday_date  date not null,
  description   text not null,
  segment       text not null default 'EQUITY',
  special_open  time,
  special_close time,
  source        text not null default 'manual',
  created_at    timestamptz not null default now(),
  unique (exchange, holiday_date, segment),
  constraint exchange_holidays_special_pair  check ((special_open is null) = (special_close is null)),
  constraint exchange_holidays_special_order check (special_open is null or special_open < special_close)
);

create trigger markets_updated_at          before update on public.markets          for each row execute function public.set_updated_at();
create trigger stocks_updated_at           before update on public.stocks           for each row execute function public.set_updated_at();
create trigger provider_symbols_updated_at before update on public.provider_symbols for each row execute function public.set_updated_at();
```

- [ ] **Step 4: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.`

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): reference tables for markets, stocks, provider symbols, holidays" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 3: Market calendar functions (IST session, holidays, special sessions)

**Files:**

- Create: `supabase/migrations/20261005000300_market_calendar.sql`
- Test: `supabase/tests/database/03_market_calendar.test.sql`

**Interfaces:**

- Consumes: `exchange_holidays` (Task 2).
- Produces: `public.is_market_open(p_exchange exchange_code, p_ts timestamptz) returns boolean` (session `[09:15, 15:30)` IST); `public.next_market_open(p_exchange exchange_code, p_ts timestamptz) returns timestamptz` (first session start strictly after `p_ts`, searching 30 days, else NULL). Phase 2's `MarketCalendarService` must give identical answers for these cases.

- [ ] **Step 1: Write the failing test** `supabase/tests/database/03_market_calendar.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(15);

-- Isolate from seeded holidays in the test window (rolled back at the end).
delete from public.exchange_holidays where holiday_date between '2026-10-05' and '2026-10-12';
insert into public.exchange_holidays (exchange, holiday_date, description) values ('NSE', '2026-10-07', 'TEST HOLIDAY (Wed)');
insert into public.exchange_holidays (exchange, holiday_date, description, special_open, special_close)
  values ('NSE', '2026-10-11', 'TEST SPECIAL SESSION (Sun)', '18:00', '19:00');

-- 2026-10-05 is a Monday.
select is(public.is_market_open('NSE', '2026-10-05 09:14:59+05:30'), false, '09:14:59 IST closed');
select is(public.is_market_open('NSE', '2026-10-05 09:15:00+05:30'), true,  '09:15 IST open');
select is(public.is_market_open('NSE', '2026-10-05 15:29:59+05:30'), true,  '15:29:59 IST open');
select is(public.is_market_open('NSE', '2026-10-05 15:30:00+05:30'), false, '15:30 IST closed');
select is(public.is_market_open('NSE', '2026-10-05 03:45:00+00'),    true,  '03:45 UTC = 09:15 IST open');
select is(public.is_market_open('NSE', '2026-10-05 22:00:00+00'),    false, '22:00 UTC = 03:30 IST next day closed');
select is(public.is_market_open('NSE', '2026-10-10 11:00:00+05:30'), false, 'Saturday closed');
select is(public.is_market_open('NSE', '2026-10-07 11:00:00+05:30'), false, 'holiday closed');
select is(public.is_market_open('BSE', '2026-10-07 11:00:00+05:30'), true,  'holiday is per-exchange');
select is(public.is_market_open('NSE', '2026-10-11 18:30:00+05:30'), true,  'special session open');
select is(public.is_market_open('NSE', '2026-10-11 17:59:00+05:30'), false, 'before special session closed');

select is(public.next_market_open('NSE', '2026-10-05 09:00:00+05:30'), '2026-10-05 09:15:00+05:30'::timestamptz, 'pre-open -> same day 09:15');
select is(public.next_market_open('NSE', '2026-10-05 16:00:00+05:30'), '2026-10-06 09:15:00+05:30'::timestamptz, 'after close -> next day');
select is(public.next_market_open('NSE', '2026-10-06 16:00:00+05:30'), '2026-10-08 09:15:00+05:30'::timestamptz, 'skips holiday');
select is(public.next_market_open('NSE', '2026-10-09 16:00:00+05:30'), '2026-10-11 18:00:00+05:30'::timestamptz, 'finds weekend special session');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`function public.is_market_open(...) does not exist`).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005000300_market_calendar.sql`

```sql
-- SQL mirror of MarketCalendarService (TS is canonical; keep both in sync).
-- Regular equity session: [09:15, 15:30) Asia/Kolkata, Mon-Fri, minus holidays.
-- A holiday row with special_open/special_close is a special session (e.g. Muhurat trading).

create or replace function public.is_market_open(p_exchange public.exchange_code, p_ts timestamptz)
returns boolean
language plpgsql stable
set search_path = public
as $$
declare
  v_local   timestamp := p_ts at time zone 'Asia/Kolkata';
  v_date    date      := v_local::date;
  v_time    time      := v_local::time;
  v_holiday public.exchange_holidays;
begin
  select * into v_holiday
    from public.exchange_holidays
   where exchange = p_exchange and segment = 'EQUITY' and holiday_date = v_date;

  if found then
    return v_holiday.special_open is not null
       and v_time >= v_holiday.special_open
       and v_time <  v_holiday.special_close;
  end if;

  if extract(isodow from v_date) in (6, 7) then
    return false;
  end if;

  return v_time >= time '09:15' and v_time < time '15:30';
end $$;

create or replace function public.next_market_open(p_exchange public.exchange_code, p_ts timestamptz)
returns timestamptz
language plpgsql stable
set search_path = public
as $$
declare
  v_start   date := (p_ts at time zone 'Asia/Kolkata')::date;
  v_day     date;
  v_holiday public.exchange_holidays;
  v_open    timestamptz;
begin
  for i in 0..30 loop
    v_day := v_start + i;

    select * into v_holiday
      from public.exchange_holidays
     where exchange = p_exchange and segment = 'EQUITY' and holiday_date = v_day;

    if found then
      v_open := case when v_holiday.special_open is null then null
                     else (v_day + v_holiday.special_open) at time zone 'Asia/Kolkata' end;
    elsif extract(isodow from v_day) in (6, 7) then
      v_open := null;
    else
      v_open := (v_day + time '09:15') at time zone 'Asia/Kolkata';
    end if;

    if v_open is not null and v_open > p_ts then
      return v_open;
    end if;
  end loop;

  return null;
end $$;
```

- [ ] **Step 4: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.`

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): IST market calendar functions with holiday and special sessions" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 4: Market data and technical indicators

**Files:**

- Create: `supabase/migrations/20261005000400_market_data.sql`
- Test: `supabase/tests/database/04_market_data.test.sql`

**Interfaces:**

- Consumes: `stocks`, `markets`, enums, `public.price`, `public.score`.
- Produces: `market_data(id, stock_id, market_id, data_mode, timeframe, ts, open, high, low, close, adjusted_close, volume, change, change_percent, vwap, source, created_at)`; `technical_indicators(id, stock_id, data_mode, timeframe, ts, sma_20, sma_50, sma_200, ema_20, ema_50, ema_200, rsi_14, macd, macd_signal, macd_histogram, bollinger_upper, bollinger_middle, bollinger_lower, atr_14, adx_14, stoch_k, stoch_d, vwap, volume_sma_20, pivots, created_at)`. The column is named `timeframe` (type `bar_interval`), because `interval` is an SQL keyword.

- [ ] **Step 1: Write the failing test** `supabase/tests/database/04_market_data.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(9);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');
insert into public.markets (symbol, name, exchange, market_type) values ('TESTIDX', 'Test Index', 'NSE', 'BROAD_INDEX');
create temp table ids as
  select (select id from public.stocks where symbol = 'TESTA') as stock_id,
         (select id from public.markets where symbol = 'TESTIDX') as market_id;

select lives_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 100, 105, 99, 104, 1000, 'mock' from ids$$, 'valid bar inserts');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 100, 105, 99, 104, 1000, 'mock' from ids$$,
  '23505', null, 'duplicate (stock, mode, timeframe, ts, source) rejected');
select lives_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'LIVE', '1d', '2026-10-05 10:00+05:30', 100, 105, 99, 104, 1000, 'yahoo' from ids$$, 'same ts in LIVE mode allowed');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 100, 98, 99, 99, 1000, 'mock' from ids$$,
  '23514', null, 'high < low rejected');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 106, 105, 99, 104, 1000, 'mock' from ids$$,
  '23514', null, 'open above high rejected');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 100, 105, 99, 104, -1, 'mock' from ids$$,
  '23514', null, 'negative volume rejected');
select throws_ok($$insert into public.market_data (stock_id, market_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, market_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 100, 105, 99, 104, 1, 'mock' from ids$$,
  '23514', null, 'bar with two owners rejected');

insert into public.technical_indicators (stock_id, data_mode, timeframe, ts, rsi_14)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 61 from ids;
select throws_ok($$insert into public.technical_indicators (stock_id, data_mode, timeframe, ts, rsi_14)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 62 from ids$$,
  '23505', null, 'duplicate indicator row rejected');
select throws_ok($$insert into public.technical_indicators (stock_id, data_mode, timeframe, ts, rsi_14)
  select stock_id, 'MOCK', '1d', '2026-10-07 10:00+05:30', 101 from ids$$,
  '23514', null, 'RSI > 100 rejected');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`relation "public.market_data" does not exist`).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005000400_market_data.sql`

```sql
create table public.market_data (
  id             uuid primary key default gen_random_uuid(),
  stock_id       uuid references public.stocks (id) on delete cascade,
  market_id      uuid references public.markets (id) on delete cascade,
  data_mode      public.data_mode not null,
  timeframe      public.bar_interval not null,
  ts             timestamptz not null,
  open           public.price not null,
  high           public.price not null,
  low            public.price not null,
  close          public.price not null,
  adjusted_close public.price,
  volume         bigint not null default 0 check (volume >= 0),
  change         numeric(18,4),
  change_percent numeric(9,4),
  vwap           public.price,
  source         text not null,
  created_at     timestamptz not null default now(),
  constraint market_data_one_owner check (num_nonnulls(stock_id, market_id) = 1),
  constraint market_data_ohlc check (high >= greatest(open, close, low) and low <= least(open, close))
);
-- Partial unique indexes: a plain UNIQUE over nullable owner columns would not deduplicate.
create unique index market_data_stock_uq  on public.market_data (stock_id,  data_mode, timeframe, ts, source) where stock_id  is not null;
create unique index market_data_market_uq on public.market_data (market_id, data_mode, timeframe, ts, source) where market_id is not null;
create index market_data_stock_latest_idx  on public.market_data (stock_id,  data_mode, timeframe, ts desc) where stock_id  is not null;
create index market_data_market_latest_idx on public.market_data (market_id, data_mode, timeframe, ts desc) where market_id is not null;

create table public.technical_indicators (
  id               uuid primary key default gen_random_uuid(),
  stock_id         uuid not null references public.stocks (id) on delete cascade,
  data_mode        public.data_mode not null,
  timeframe        public.bar_interval not null,
  ts               timestamptz not null,
  sma_20           numeric(18,4),
  sma_50           numeric(18,4),
  sma_200          numeric(18,4),
  ema_20           numeric(18,4),
  ema_50           numeric(18,4),
  ema_200          numeric(18,4),
  rsi_14           public.score,
  macd             numeric(18,4),
  macd_signal      numeric(18,4),
  macd_histogram   numeric(18,4),
  bollinger_upper  numeric(18,4),
  bollinger_middle numeric(18,4),
  bollinger_lower  numeric(18,4),
  atr_14           numeric(18,4) check (atr_14 >= 0),
  adx_14           public.score,
  stoch_k          public.score,
  stoch_d          public.score,
  vwap             numeric(18,4),
  volume_sma_20    numeric(20,2) check (volume_sma_20 >= 0),
  pivots           jsonb not null default '{}'::jsonb,
  created_at       timestamptz not null default now(),
  unique (stock_id, data_mode, timeframe, ts)
);
```

- [ ] **Step 4: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.`

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): market data and technical indicator tables with OHLC and dedupe constraints" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 5: Fundamentals

**Files:**

- Create: `supabase/migrations/20261005000500_fundamentals.sql`
- Test: `supabase/tests/database/05_fundamentals.test.sql`

**Interfaces:**

- Produces: `fundamental_snapshots(id, stock_id, data_mode, as_of, source, market_cap, pe, pb, eps_ttm, roe, roce, debt_to_equity, dividend_yield, operating_margin, net_margin, free_cash_flow, revenue_ttm, net_profit_ttm, revenue_growth_yoy, profit_growth_yoy, book_value_per_share, beta, raw, created_at)`; `financial_statements(id, stock_id, data_mode, period_type, period_end, source, revenue, operating_profit, net_profit, eps, total_debt, total_equity, cash_from_operations, capex, raw, created_at)`. Ratios are stored as percentages where the name implies it (roe 18.5 = 18.5%). Every metric is nullable.

- [ ] **Step 1: Write the failing test** `supabase/tests/database/05_fundamentals.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(4);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');

select lives_ok($$insert into public.fundamental_snapshots (stock_id, data_mode, as_of, source, pe)
  select id, 'MOCK', '2026-10-05', 'mock', 24.5 from public.stocks where symbol='TESTA'$$,
  'snapshot with only P/E (all else unavailable) inserts');
select throws_ok($$insert into public.fundamental_snapshots (stock_id, data_mode, as_of, source)
  select id, 'MOCK', '2026-10-05', 'mock' from public.stocks where symbol='TESTA'$$,
  '23505', null, 'duplicate snapshot per day/source rejected');
select lives_ok($$insert into public.financial_statements (stock_id, data_mode, period_type, period_end, source, revenue, net_profit)
  select id, 'MOCK', 'QUARTERLY', '2026-06-30', 'mock', 1000, 120 from public.stocks where symbol='TESTA'$$,
  'quarterly statement inserts');
select throws_ok($$insert into public.financial_statements (stock_id, data_mode, period_type, period_end, source)
  select id, 'MOCK', 'QUARTERLY', '2026-06-30', 'mock' from public.stocks where symbol='TESTA'$$,
  '23505', null, 'duplicate statement period rejected');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`relation "public.fundamental_snapshots" does not exist`).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005000500_fundamentals.sql`

```sql
-- All metrics nullable: unavailable data stays NULL and is shown as "unavailable". Never estimated.
create table public.fundamental_snapshots (
  id                   uuid primary key default gen_random_uuid(),
  stock_id             uuid not null references public.stocks (id) on delete cascade,
  data_mode            public.data_mode not null,
  as_of                date not null,
  source               text not null,
  market_cap           numeric(20,2),
  pe                   numeric(10,2),
  pb                   numeric(10,2),
  eps_ttm              numeric(18,4),
  roe                  numeric(8,2),
  roce                 numeric(8,2),
  debt_to_equity       numeric(10,4),
  dividend_yield       numeric(8,4),
  operating_margin     numeric(8,2),
  net_margin           numeric(8,2),
  free_cash_flow       numeric(20,2),
  revenue_ttm          numeric(20,2),
  net_profit_ttm       numeric(20,2),
  revenue_growth_yoy   numeric(8,2),
  profit_growth_yoy    numeric(8,2),
  book_value_per_share numeric(18,4),
  beta                 numeric(8,4),
  raw                  jsonb not null default '{}'::jsonb,
  created_at           timestamptz not null default now(),
  unique (stock_id, data_mode, as_of, source)
);

create table public.financial_statements (
  id                   uuid primary key default gen_random_uuid(),
  stock_id             uuid not null references public.stocks (id) on delete cascade,
  data_mode            public.data_mode not null,
  period_type          public.period_type not null,
  period_end           date not null,
  source               text not null,
  revenue              numeric(20,2),
  operating_profit     numeric(20,2),
  net_profit           numeric(20,2),
  eps                  numeric(18,4),
  total_debt           numeric(20,2),
  total_equity         numeric(20,2),
  cash_from_operations numeric(20,2),
  capex                numeric(20,2),
  raw                  jsonb not null default '{}'::jsonb,
  created_at           timestamptz not null default now(),
  unique (stock_id, data_mode, period_type, period_end, source)
);
create index financial_statements_lookup_idx on public.financial_statements (stock_id, data_mode, period_type, period_end desc);
```

- [ ] **Step 4: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.`

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): fundamentals snapshot and financial statement tables" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 6: News, mentions, news AI analysis, embeddings, `match_documents`

**Files:**

- Create: `supabase/migrations/20261005000600_news_rag.sql`
- Test: `supabase/tests/database/06_news_rag.test.sql`

**Interfaces:**

- Produces: `news`, `news_mentions`, `news_ai_analysis`, `document_embeddings` (columns below). The function signature is
  `public.match_documents(p_query_embedding extensions.vector(1536), p_data_mode data_mode, p_stock_id uuid default null, p_since timestamptz default null, p_k int default 8, p_source_types text[] default null) returns table(id uuid, source_type text, source_id uuid, stock_id uuid, content text, metadata jsonb, published_at timestamptz, similarity double precision)`, ordered most-similar first.

- [ ] **Step 1: Write the failing test** `supabase/tests/database/06_news_rag.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(10);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE'), ('TESTB', 'Test B Ltd', 'NSE');

-- 1536-d test vector with only the first two components set.
create function pg_temp.vec(a float8, b float8) returns extensions.vector
language sql immutable as $$
  select ((array[a, b] || array_fill(0::float8, array[1534]))::float8[])::extensions.vector(1536)
$$;

-- News dedupe ----------------------------------------------------------------
insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
values ('MOCK', 'A wins order', 'mock', 'https://example.test/a', '2026-10-05 08:00+05:30', repeat('a', 64));
select throws_ok($$insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
  values ('MOCK', 'A wins order (syndicated)', 'mock2', 'https://example.test/a-copy', now(), repeat('a', 64))$$,
  '23505', null, 'duplicate content_hash rejected');
select throws_ok($$insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
  values ('MOCK', 'Other', 'mock', 'https://example.test/a', now(), repeat('b', 64))$$,
  '23505', null, 'duplicate source_url rejected');
select throws_ok($$insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
  values ('MOCK', 'Bad hash', 'mock', 'https://example.test/c', now(), 'not-a-sha256')$$,
  '23514', null, 'content_hash must be sha256 hex');

-- news_ai_analysis dedupe incl. market-level (stock_id null) -------------------
insert into public.news_ai_analysis (news_id, stock_id, sentiment, sentiment_score, confidence, relevance_score, impact_level, summary, model, prompt_version)
select id, null, 'NEUTRAL', 50, 60, 0.5, 'LOW', 's', 'mock', 'news_sentiment_v1' from public.news where source_url = 'https://example.test/a';
select throws_ok($$insert into public.news_ai_analysis (news_id, stock_id, sentiment, sentiment_score, confidence, relevance_score, impact_level, summary, model, prompt_version)
  select id, null, 'NEUTRAL', 50, 60, 0.5, 'LOW', 's', 'mock', 'news_sentiment_v1' from public.news where source_url = 'https://example.test/a'$$,
  '23505', null, 'same (news, null stock, prompt_version) analysed only once');

-- Embeddings + match_documents ------------------------------------------------
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, v.content, md5(v.content), pg_temp.vec(1, v.b), 'test', '2026-10-01'
from public.stocks s, (values ('a-near', 0.1), ('a-mid', 0.5), ('a-far', 2.0)) v(content, b)
where s.symbol = 'TESTA';

select is(
  (select content from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), null, 3) limit 1),
  'a-near', 'nearest document first');

-- 50 closer docs for TESTB must not starve a TESTA-filtered query.
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'b-' || g, md5('b-' || g), pg_temp.vec(1, 0), 'test', '2026-10-01'
from public.stocks s, generate_series(1, 50) g where s.symbol = 'TESTB';
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'a-extra-' || g, md5('a-extra-' || g), pg_temp.vec(1, 1), 'test', '2026-10-01'
from public.stocks s, generate_series(1, 10) g where s.symbol = 'TESTA';

set local enable_seqscan = off; set local enable_sort = off;  -- force the HNSW index path so post-filtering is exercised
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), null, 5)),
  5, 'stock filter still returns k rows');
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), null, 5) m
    where m.stock_id <> (select id from public.stocks where symbol='TESTA')),
  0, 'stock filter returns only that stock');

insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'LIVE', 'NEWS', gen_random_uuid(), id, 'a-live', md5('a-live'), pg_temp.vec(1, 0), 'test', '2026-10-01' from public.stocks where symbol = 'TESTA';
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', null, null, 100) where content = 'a-live'),
  0, 'MOCK search never returns LIVE documents');

select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), '2026-10-02', 5)),
  0, 'since filter excludes older docs');

select throws_ok($$insert into public.document_embeddings (data_mode, source_type, source_id, content, content_hash, embedding, embedding_model)
  values ('MOCK', 'TWEET', gen_random_uuid(), 'x', 'x', pg_temp.vec(1,0), 'test')$$,
  '23514', null, 'unknown source_type rejected');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`relation "public.news" does not exist`).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005000600_news_rag.sql`

```sql
create table public.news (
  id           uuid primary key default gen_random_uuid(),
  data_mode    public.data_mode not null,
  title        text not null check (length(title) between 1 and 1000),
  description  text,
  content      text,
  source       text not null,
  source_url   text not null,
  author       text,
  published_at timestamptz not null,
  fetched_at   timestamptz not null default now(),
  language     text not null default 'en',
  content_hash text not null check (content_hash ~ '^[a-f0-9]{64}$'),
  created_at   timestamptz not null default now(),
  unique (data_mode, content_hash),
  unique (data_mode, source_url)
);
create index news_published_idx on public.news (data_mode, published_at desc);

create table public.news_mentions (
  id              uuid primary key default gen_random_uuid(),
  news_id         uuid not null references public.news (id) on delete cascade,
  stock_id        uuid references public.stocks (id) on delete cascade,
  market_id       uuid references public.markets (id) on delete cascade,
  relevance_score numeric(4,3) not null check (relevance_score between 0 and 1),
  matched_by      text not null,
  created_at      timestamptz not null default now(),
  constraint news_mentions_one_owner check (num_nonnulls(stock_id, market_id) = 1)
);
create unique index news_mentions_stock_uq  on public.news_mentions (news_id, stock_id)  where stock_id  is not null;
create unique index news_mentions_market_uq on public.news_mentions (news_id, market_id) where market_id is not null;
create index news_mentions_stock_idx  on public.news_mentions (stock_id)  where stock_id  is not null;
create index news_mentions_market_idx on public.news_mentions (market_id) where market_id is not null;

create table public.news_ai_analysis (
  id               uuid primary key default gen_random_uuid(),
  news_id          uuid not null references public.news (id) on delete cascade,
  stock_id         uuid references public.stocks (id) on delete cascade,
  sentiment        public.sentiment not null,
  sentiment_score  public.score not null,
  confidence       public.score not null,
  relevance_score  numeric(4,3) not null check (relevance_score between 0 and 1),
  impact_level     public.impact_level not null,
  summary          text not null,
  positive_factors jsonb not null default '[]'::jsonb,
  negative_factors jsonb not null default '[]'::jsonb,
  reasoning        jsonb not null default '[]'::jsonb,
  model            text not null,
  prompt_version   text not null,
  created_at       timestamptz not null default now(),
  constraint news_ai_analysis_once unique nulls not distinct (news_id, stock_id, prompt_version)
);
create index news_ai_analysis_stock_idx on public.news_ai_analysis (stock_id, created_at desc);

create table public.document_embeddings (
  id              uuid primary key default gen_random_uuid(),
  data_mode       public.data_mode not null,
  source_type     text not null check (source_type in ('NEWS', 'FINANCIALS', 'AI_ANALYSIS', 'MARKET_SUMMARY')),
  source_id       uuid not null,
  stock_id        uuid references public.stocks (id) on delete cascade,
  chunk_index     integer not null default 0 check (chunk_index >= 0),
  content         text not null,
  content_hash    text not null,
  embedding       extensions.vector(1536) not null,
  embedding_model text not null,
  metadata        jsonb not null default '{}'::jsonb,
  published_at    timestamptz,
  created_at      timestamptz not null default now(),
  unique (source_type, source_id, chunk_index, embedding_model)
);
create index document_embeddings_hnsw_idx on public.document_embeddings
  using hnsw (embedding extensions.vector_cosine_ops);
create index document_embeddings_filter_idx on public.document_embeddings (data_mode, stock_id, published_at desc);

-- Filtered cosine search. iterative_scan keeps scanning the HNSW graph until
-- enough rows pass the WHERE filters (pgvector >= 0.8), so a stock filter still yields k rows.
create or replace function public.match_documents(
  p_query_embedding extensions.vector(1536),
  p_data_mode       public.data_mode,
  p_stock_id        uuid        default null,
  p_since           timestamptz default null,
  p_k               integer     default 8,
  p_source_types    text[]      default null
)
returns table (
  id           uuid,
  source_type  text,
  source_id    uuid,
  stock_id     uuid,
  content      text,
  metadata     jsonb,
  published_at timestamptz,
  similarity   double precision
)
language sql stable
set search_path = public, extensions
set hnsw.iterative_scan = 'strict_order'
as $$
  select d.id, d.source_type, d.source_id, d.stock_id, d.content, d.metadata, d.published_at,
         1 - (d.embedding <=> p_query_embedding) as similarity
    from public.document_embeddings d
   where d.data_mode = p_data_mode
     and (p_stock_id is null or d.stock_id = p_stock_id)
     and (p_since is null or d.published_at >= p_since)
     and (p_source_types is null or d.source_type = any (p_source_types))
   order by d.embedding <=> p_query_embedding
   limit greatest(p_k, 1)
$$;
```

- [ ] **Step 4: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.` If the migration errors with `unrecognized configuration parameter "hnsw.iterative_scan"`, pgvector is < 0.8 (Task 1 test would also have failed). In that case remove that `set` line and change `limit greatest(p_k, 1)` to an outer query that over-fetches `p_k * 10` before filtering. Re-run.

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): news, mentions, news AI analysis, pgvector embeddings and match_documents" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 7: Config, ops, evaluation and AI tables

**Files:**

- Create: `supabase/migrations/20261005000700_config_ops.sql`, `supabase/migrations/20261005000800_evaluation_ai.sql`
- Test: `supabase/tests/database/07_evaluation_ai.test.sql`

**Interfaces:**

- Produces: `app_settings(key, value jsonb, description, updated_at)`; `scoring_configs(id, version, weights, thresholds, is_active, notes, created_at)` with at most one active row; `system_logs`; `llm_calls`; `stock_evaluations`; `stock_ai_analysis`; `market_ai_summary`; `ai_trade_signals`; `ai_qa_log` (columns below; names match PRD §7.6/§7.8).

- [ ] **Step 1: Write the failing test** `supabase/tests/database/07_evaluation_ai.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

select has_table('public', t, 'table ' || t)
  from unnest(array['app_settings','scoring_configs','system_logs','llm_calls']) t;

update public.scoring_configs set is_active = false;
insert into public.scoring_configs (version, weights, thresholds, is_active) values ('test-a', '{}', '{}', true);
select throws_ok($$insert into public.scoring_configs (version, weights, thresholds, is_active) values ('test-b', '{}', '{}', true)$$,
  '23505', null, 'only one active scoring config');

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');
insert into public.stock_evaluations (stock_id, data_mode, data_as_of, scoring_config_version, overall_score, action_state, input_hash)
select id, 'MOCK', now(), 'test-a', 72, 'BUY_ZONE', 'h1' from public.stocks where symbol = 'TESTA';

insert into public.stock_ai_analysis (stock_id, evaluation_id, data_mode, data_as_of, status, summary, input_hash, model, prompt_version)
select e.stock_id, e.id, 'MOCK', now(), 'OK', 's', 'h1', 'mock', 'stock_analysis_v1' from public.stock_evaluations e where input_hash = 'h1';
select throws_ok($$insert into public.stock_ai_analysis (stock_id, evaluation_id, data_mode, data_as_of, status, summary, input_hash, model, prompt_version)
  select e.stock_id, e.id, 'MOCK', now(), 'OK', 's', 'h1', 'mock', 'stock_analysis_v1' from public.stock_evaluations e where input_hash = 'h1'$$,
  '23505', null, 'identical input hash + prompt is not re-analysed (LLM cost guard)');

select throws_ok($$insert into public.stock_evaluations (stock_id, data_mode, data_as_of, scoring_config_version, overall_score, action_state, input_hash)
  select id, 'MOCK', now(), 'test-a', 120, 'HOLD', 'h2' from public.stocks where symbol = 'TESTA'$$,
  '23514', null, 'overall_score > 100 rejected');
select throws_ok($$insert into public.stock_evaluations (stock_id, data_mode, data_as_of, scoring_config_version, action_state, input_hash, entry_low, entry_high)
  select id, 'MOCK', now(), 'test-a', 'HOLD', 'h3', 110, 100 from public.stocks where symbol = 'TESTA'$$,
  '23514', null, 'entry_low > entry_high rejected');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`relation "public.app_settings" does not exist`).

- [ ] **Step 3: Write** `supabase/migrations/20261005000700_config_ops.sql`

```sql
create table public.app_settings (
  key         text primary key check (key ~ '^[a-z0-9_]+$'),
  value       jsonb not null,
  description text,
  updated_at  timestamptz not null default now()
);
create trigger app_settings_updated_at before update on public.app_settings for each row execute function public.set_updated_at();

create table public.scoring_configs (
  id         uuid primary key default gen_random_uuid(),
  version    text not null unique,
  weights    jsonb not null,
  thresholds jsonb not null,
  is_active  boolean not null default false,
  notes      text,
  created_at timestamptz not null default now()
);
create unique index scoring_configs_one_active on public.scoring_configs (is_active) where is_active;

create table public.system_logs (
  id                uuid primary key default gen_random_uuid(),
  job_run_id        uuid,
  service           text not null,
  job_name          text,
  operation         text not null,
  status            public.job_status not null,
  message           text,
  records_fetched   integer not null default 0 check (records_fetched   >= 0),
  records_inserted  integer not null default 0 check (records_inserted  >= 0),
  records_skipped   integer not null default 0 check (records_skipped   >= 0),
  records_failed    integer not null default 0 check (records_failed    >= 0),
  records_processed integer not null default 0 check (records_processed >= 0),
  started_at        timestamptz,
  finished_at       timestamptz,
  execution_time_ms integer check (execution_time_ms >= 0),
  error_details     jsonb,
  created_at        timestamptz not null default now()
);
create index system_logs_job_idx on public.system_logs (job_name, created_at desc);
create index system_logs_status_idx on public.system_logs (status, created_at desc);

create table public.llm_calls (
  id             uuid primary key default gen_random_uuid(),
  purpose        text not null,
  provider       text not null,
  model          text not null,
  prompt_version text,
  input_tokens   integer not null default 0 check (input_tokens  >= 0),
  output_tokens  integer not null default 0 check (output_tokens >= 0),
  est_cost_inr   numeric(12,4) not null default 0 check (est_cost_inr >= 0),
  latency_ms     integer check (latency_ms >= 0),
  cache_hit      boolean not null default false,
  status         text not null check (status in ('OK', 'FAILED', 'INVALID_OUTPUT', 'BUDGET_EXCEEDED')),
  error          text,
  created_at     timestamptz not null default now()
);
create index llm_calls_created_idx on public.llm_calls (created_at desc);
```

- [ ] **Step 4: Write** `supabase/migrations/20261005000800_evaluation_ai.sql`

```sql
-- Deterministic evaluation: computed by code, never by the LLM.
create table public.stock_evaluations (
  id                     uuid primary key default gen_random_uuid(),
  stock_id               uuid not null references public.stocks (id) on delete cascade,
  data_mode              public.data_mode not null,
  evaluated_at           timestamptz not null default now(),
  data_as_of             timestamptz not null,
  scoring_config_version text not null,
  technical_score        public.score,
  quality_score          public.score,
  valuation_score        public.score,
  news_score             public.score,
  momentum_score         public.score,
  market_context_score   public.score,
  overall_score          public.score,
  risk_score             public.score,
  risk_level             public.risk_level,
  trend                  public.trend,
  valuation_label        public.valuation_label not null default 'INSUFFICIENT_DATA',
  market_regime          public.market_regime,
  action_state           public.action_state not null,
  recommendation_bias    public.recommendation_bias,
  entry_low              public.price,
  entry_high             public.price,
  stop_loss              public.price,
  target_1               public.price,
  target_2               public.price,
  risk_reward            numeric(8,2) check (risk_reward >= 0),
  position_size_hint     integer check (position_size_hint >= 0),
  invalidation           text,
  factors_available      jsonb not null default '{}'::jsonb,
  inputs                 jsonb not null default '{}'::jsonb,
  input_hash             text not null,
  created_at             timestamptz not null default now(),
  unique (stock_id, data_mode, input_hash),
  constraint stock_evaluations_entry_order check (entry_low is null or entry_high is null or entry_low <= entry_high)
);
create index stock_evaluations_latest_idx on public.stock_evaluations (stock_id, data_mode, evaluated_at desc);

create table public.stock_ai_analysis (
  id                      uuid primary key default gen_random_uuid(),
  stock_id                uuid not null references public.stocks (id) on delete cascade,
  evaluation_id           uuid references public.stock_evaluations (id) on delete set null,
  data_mode               public.data_mode not null,
  analysis_time           timestamptz not null default now(),
  data_as_of              timestamptz not null,
  status                  public.analysis_status not null,
  sentiment               public.sentiment,
  sentiment_score         public.score,
  confidence              public.score,
  technical_score         public.score,
  fundamental_score       public.score,
  news_score              public.score,
  momentum_score          public.score,
  risk_score              public.score,
  overall_score           public.score,
  trend                   public.trend,
  risk_level              public.risk_level,
  recommendation          public.recommendation_bias,
  summary                 text,
  reasoning               jsonb not null default '[]'::jsonb,
  key_positive_factors    jsonb not null default '[]'::jsonb,
  key_negative_factors    jsonb not null default '[]'::jsonb,
  key_risks               jsonb not null default '[]'::jsonb,
  catalysts               jsonb not null default '[]'::jsonb,
  invalidation_conditions jsonb not null default '[]'::jsonb,
  facts                   jsonb not null default '[]'::jsonb,
  interpretation          jsonb not null default '[]'::jsonb,
  insufficient_data       jsonb not null default '[]'::jsonb,
  sources                 jsonb not null default '[]'::jsonb,
  input_hash              text not null,
  model                   text not null,
  prompt_version          text not null,
  created_at              timestamptz not null default now(),
  unique (stock_id, data_mode, input_hash, prompt_version)
);
create index stock_ai_analysis_latest_idx on public.stock_ai_analysis (stock_id, data_mode, analysis_time desc);

create table public.market_ai_summary (
  id               uuid primary key default gen_random_uuid(),
  market_id        uuid not null references public.markets (id) on delete cascade,
  data_mode        public.data_mode not null,
  analysis_time    timestamptz not null default now(),
  data_as_of       timestamptz not null,
  sentiment        public.sentiment not null,
  sentiment_score  public.score not null,
  confidence       public.score not null,
  trend            public.trend,
  regime           public.market_regime,
  risk_level       public.risk_level,
  summary          text not null,
  key_drivers      jsonb not null default '[]'::jsonb,
  key_risks        jsonb not null default '[]'::jsonb,
  sectors_positive jsonb not null default '[]'::jsonb,
  sectors_negative jsonb not null default '[]'::jsonb,
  sources          jsonb not null default '[]'::jsonb,
  input_hash       text not null,
  model            text not null,
  prompt_version   text not null,
  created_at       timestamptz not null default now(),
  unique (market_id, data_mode, input_hash, prompt_version)
);
create index market_ai_summary_latest_idx on public.market_ai_summary (market_id, data_mode, analysis_time desc);

create table public.ai_trade_signals (
  id                 uuid primary key default gen_random_uuid(),
  stock_id           uuid not null references public.stocks (id) on delete cascade,
  analysis_id        uuid references public.stock_ai_analysis (id) on delete set null,
  evaluation_id      uuid references public.stock_evaluations (id) on delete set null,
  data_mode          public.data_mode not null,
  signal             public.signal_type not null,
  confidence         public.score not null,
  entry_price        public.price,
  entry_low          public.price,
  entry_high         public.price,
  target_price       public.price,
  target_2           public.price,
  stop_loss          public.price,
  risk_reward_ratio  numeric(8,2) check (risk_reward_ratio >= 0),
  suggested_quantity integer check (suggested_quantity >= 0),
  reasoning          jsonb not null default '[]'::jsonb,
  valid_until        timestamptz not null,
  status             public.signal_status not null default 'ACTIVE',
  created_at         timestamptz not null default now()
);
create index ai_trade_signals_active_idx on public.ai_trade_signals (stock_id, data_mode, status, created_at desc);

create table public.ai_qa_log (
  id             uuid primary key default gen_random_uuid(),
  stock_id       uuid references public.stocks (id) on delete cascade,
  data_mode      public.data_mode not null,
  user_id        uuid,
  question       text not null check (length(question) between 1 and 500),
  question_hash  text not null,
  context_hash   text not null,
  answer         jsonb not null,
  sources        jsonb not null default '[]'::jsonb,
  model          text not null,
  prompt_version text not null,
  created_at     timestamptz not null default now()
);
create index ai_qa_log_cache_idx on public.ai_qa_log (stock_id, data_mode, question_hash, context_hash);
```

- [ ] **Step 5: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.`

- [ ] **Step 6: Commit**

```bash
git add supabase
git commit -m "feat(db): config, ops logging, deterministic evaluations and AI analysis tables" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 8: Paper trading schema, new-user trigger and atomic `execute_paper_order`

**Files:**

- Create: `supabase/migrations/20261005000900_paper_trading.sql`
- Test: `supabase/tests/database/08_paper_trading.test.sql`

**Interfaces:**

- Consumes: `app_settings` key `paper_initial_balance` (number; default 1000000 if absent), `ai_trade_signals`.
- Produces: `user_profiles`, `paper_fee_schedules`, `paper_accounts` (one per user × data_mode), `paper_positions`, `paper_orders`, `paper_trades`. The function signature is
  `public.execute_paper_order(p_account_id uuid, p_stock_id uuid, p_side trade_side, p_quantity integer, p_price numeric, p_fees numeric default 0, p_source order_source default 'MANUAL', p_signal_id uuid default null, p_price_as_of timestamptz default now()) returns public.paper_orders`.
  - Invalid qty, price or fees raise SQLSTATE `22023`.
  - Insufficient cash or holdings returns a REJECTED order with `reject_reason` `INSUFFICIENT_FUNDS` / `INSUFFICIENT_QUANTITY`; balances are unchanged.
  - Average cost includes buy fees. Realised P&L = (sell price − avg cost) × qty − sell fees. A position at qty 0 is deleted.

- [ ] **Step 1: Write the failing test** `supabase/tests/database/08_paper_trading.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(21);

create temp table expected as
  select case when exists (select 1 from public.user_profiles where role = 'OWNER') then 'VIEWER' else 'OWNER' end as first_role;

insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-0000000000a1', 'paper-a@test.local'),
  ('00000000-0000-0000-0000-0000000000a2', 'paper-b@test.local');
insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');

create temp table t as select
  (select id from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000a1' and data_mode = 'MOCK') as acc,
  (select id from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000a2' and data_mode = 'LIVE') as acc2,
  (select id from public.stocks where symbol = 'TESTA') as stock;

-- new-user trigger
select is((select role::text from public.user_profiles where user_id = '00000000-0000-0000-0000-0000000000a1'),
          (select first_role from expected), 'first user becomes OWNER (if none exists)');
select is((select role::text from public.user_profiles where user_id = '00000000-0000-0000-0000-0000000000a2'),
          'VIEWER', 'later users become VIEWER');
select is((select count(*)::int from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000a1'),
          2, 'one MOCK and one LIVE paper account');
select is((select available_cash from public.paper_accounts where id = (select acc from t)),
          1000000.0000::numeric, 'starting cash ₹10,00,000');

-- validation
select throws_ok($$select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 0, 100)$$,
  '22023', 'INVALID_QUANTITY', 'qty 0 rejected');
select throws_ok($$select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 1, 0)$$,
  '22023', 'INVALID_PRICE', 'price 0 rejected');

-- buy 10 @ 100 + 5 fees -> avg 100.5, cash 998995
select is((public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 10, 100, 5)).status::text,
  'EXECUTED', 'buy executes');
select is((select average_buy_price from public.paper_positions where account_id = (select acc from t)),
  100.5000::numeric, 'avg cost includes buy fees');
select is((select available_cash from public.paper_accounts where id = (select acc from t)),
  998995.0000::numeric, 'cash debited price*qty + fees');

-- buy 10 @ 110 + 5 -> avg (1005 + 1105)/20 = 105.5
select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 10, 110, 5);
select is((select average_buy_price from public.paper_positions where account_id = (select acc from t)),
  105.5000::numeric, 'weighted average cost');
select is((select quantity from public.paper_positions where account_id = (select acc from t)), 20, 'qty 20');

-- oversell rejected, nothing changes
select is((public.execute_paper_order((select acc from t), (select stock from t), 'SELL', 21, 120)).reject_reason,
  'INSUFFICIENT_QUANTITY', 'cannot sell more than held');
select is((select quantity from public.paper_positions where account_id = (select acc from t)), 20, 'qty unchanged after reject');

-- sell 5 @ 120 - 3 fees -> realised (120-105.5)*5 - 3 = 69.5
-- Call the volatile function exactly once in FROM; inside a WHERE it would run once per scanned row.
create temp table sell1 as
  select * from public.execute_paper_order((select acc from t), (select stock from t), 'SELL', 5, 120, 3);
select is((select realized_pnl from public.paper_trades where order_id = (select id from sell1)),
  69.5000::numeric, 'realised P&L on partial sell');

-- sell remaining 15 @ 100 -> realised -82.5; position deleted; account realised -13; cash 999987
select public.execute_paper_order((select acc from t), (select stock from t), 'SELL', 15, 100, 0);
select is((select count(*)::int from public.paper_positions where account_id = (select acc from t)), 0, 'full exit deletes position');
select is((select realized_pnl from public.paper_accounts where id = (select acc from t)), -13.0000::numeric, 'account realised P&L');
select is((select available_cash from public.paper_accounts where id = (select acc from t)), 999987.0000::numeric, 'cash reconciles');

-- re-entry starts a fresh average
select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 1, 200, 0);
select is((select average_buy_price from public.paper_positions where account_id = (select acc from t)),
  200.0000::numeric, 're-entry has fresh average cost');

-- cash boundary on the second account: cost + fees == cash executes; one paisa more is rejected
select is((public.execute_paper_order((select acc2 from t), (select stock from t), 'BUY', 1, 1000000.01, 0)).reject_reason,
  'INSUFFICIENT_FUNDS', 'one paisa over cash rejected');
select is((public.execute_paper_order((select acc2 from t), (select stock from t), 'BUY', 1, 999990, 10)).status::text,
  'EXECUTED', 'exact cash executes');
select is((select available_cash from public.paper_accounts where id = (select acc2 from t)), 0.0000::numeric, 'cash exactly zero');

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`relation "public.paper_accounts" does not exist`).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005000900_paper_trading.sql`

```sql
create table public.user_profiles (
  user_id      uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  role         public.user_role not null default 'VIEWER',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger user_profiles_updated_at before update on public.user_profiles for each row execute function public.set_updated_at();

-- Indian charges are configurable; seeded values must be verified by the owner.
create table public.paper_fee_schedules (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null unique,
  is_active          boolean not null default false,
  brokerage_pct      numeric(8,5) not null default 0 check (brokerage_pct      >= 0),
  brokerage_max      numeric(12,2)                  check (brokerage_max      >= 0),
  stt_buy_pct        numeric(8,5) not null default 0 check (stt_buy_pct        >= 0),
  stt_sell_pct       numeric(8,5) not null default 0 check (stt_sell_pct       >= 0),
  exchange_txn_pct   numeric(8,5) not null default 0 check (exchange_txn_pct   >= 0),
  sebi_fee_pct       numeric(8,5) not null default 0 check (sebi_fee_pct       >= 0),
  stamp_duty_buy_pct numeric(8,5) not null default 0 check (stamp_duty_buy_pct >= 0),
  gst_pct            numeric(8,5) not null default 0 check (gst_pct            >= 0),
  notes              text,
  created_at         timestamptz not null default now()
);
create unique index paper_fee_schedules_one_active on public.paper_fee_schedules (is_active) where is_active;

create table public.paper_accounts (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.user_profiles (user_id) on delete cascade,
  data_mode       public.data_mode not null,
  initial_balance numeric(18,4) not null check (initial_balance > 0),
  available_cash  numeric(18,4) not null check (available_cash >= 0),
  portfolio_value numeric(18,4) not null default 0,
  realized_pnl    numeric(18,4) not null default 0,
  total_pnl       numeric(18,4) not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (user_id, data_mode)
);
create trigger paper_accounts_updated_at before update on public.paper_accounts for each row execute function public.set_updated_at();

create table public.paper_positions (
  id                uuid primary key default gen_random_uuid(),
  account_id        uuid not null references public.paper_accounts (id) on delete cascade,
  stock_id          uuid not null references public.stocks (id),
  quantity          integer not null check (quantity > 0),
  average_buy_price numeric(18,4) not null check (average_buy_price > 0),
  current_price     numeric(18,4),
  unrealized_pnl    numeric(18,4) not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (account_id, stock_id)
);
create trigger paper_positions_updated_at before update on public.paper_positions for each row execute function public.set_updated_at();

create table public.paper_orders (
  id              uuid primary key default gen_random_uuid(),
  account_id      uuid not null references public.paper_accounts (id) on delete cascade,
  stock_id        uuid not null references public.stocks (id),
  order_type      public.trade_side not null,
  quantity        integer not null check (quantity > 0),
  requested_price numeric(18,4) check (requested_price > 0),
  executed_price  numeric(18,4) check (executed_price > 0),
  fees            numeric(18,4) not null default 0 check (fees >= 0),
  status          public.order_status not null,
  reject_reason   text,
  order_source    public.order_source not null default 'MANUAL',
  signal_id       uuid references public.ai_trade_signals (id) on delete set null,
  price_as_of     timestamptz,
  created_at      timestamptz not null default now(),
  executed_at     timestamptz,
  constraint paper_orders_reject_reason check ((status = 'REJECTED') = (reject_reason is not null))
);
create index paper_orders_account_idx on public.paper_orders (account_id, created_at desc);

create table public.paper_trades (
  id           uuid primary key default gen_random_uuid(),
  account_id   uuid not null references public.paper_accounts (id) on delete cascade,
  stock_id     uuid not null references public.stocks (id),
  order_id     uuid not null unique references public.paper_orders (id) on delete cascade,
  side         public.trade_side not null,
  quantity     integer not null check (quantity > 0),
  price        numeric(18,4) not null check (price > 0),
  fees         numeric(18,4) not null default 0 check (fees >= 0),
  realized_pnl numeric(18,4) not null default 0,
  created_at   timestamptz not null default now()
);
create index paper_trades_account_idx on public.paper_trades (account_id, created_at desc);

-- New auth user -> profile (first user is OWNER) + one paper account per data mode.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer
set search_path = public
as $$
declare
  v_balance numeric(18,4) := coalesce(
    (select (value #>> '{}')::numeric from public.app_settings where key = 'paper_initial_balance'), 1000000);
  v_role public.user_role := case
    when exists (select 1 from public.user_profiles where role = 'OWNER') then 'VIEWER'
    else 'OWNER' end;
begin
  insert into public.user_profiles (user_id, display_name, role) values (new.id, new.email, v_role);
  insert into public.paper_accounts (user_id, data_mode, initial_balance, available_cash, portfolio_value)
  values (new.id, 'MOCK', v_balance, v_balance, v_balance),
         (new.id, 'LIVE', v_balance, v_balance, v_balance);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Atomic paper execution. Row locks serialise concurrent orders per account and position.
create or replace function public.execute_paper_order(
  p_account_id  uuid,
  p_stock_id    uuid,
  p_side        public.trade_side,
  p_quantity    integer,
  p_price       numeric,
  p_fees        numeric             default 0,
  p_source      public.order_source default 'MANUAL',
  p_signal_id   uuid                default null,
  p_price_as_of timestamptz         default now()
) returns public.paper_orders
language plpgsql
set search_path = public
as $$
declare
  v_account  public.paper_accounts;
  v_position public.paper_positions;
  v_order    public.paper_orders;
  v_cost     numeric(18,4);
  v_proceeds numeric(18,4);
  v_realized numeric(18,4);
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'INVALID_QUANTITY' using errcode = '22023';
  end if;
  if p_price is null or p_price <= 0 then
    raise exception 'INVALID_PRICE' using errcode = '22023';
  end if;
  if p_fees is null or p_fees < 0 then
    raise exception 'INVALID_FEES' using errcode = '22023';
  end if;

  select * into v_account from public.paper_accounts where id = p_account_id for update;
  if not found then
    raise exception 'ACCOUNT_NOT_FOUND' using errcode = 'P0002';
  end if;

  select * into v_position
    from public.paper_positions
   where account_id = p_account_id and stock_id = p_stock_id
     for update;

  if p_side = 'BUY' then
    v_cost := p_quantity * p_price + p_fees;

    if v_cost > v_account.available_cash then
      insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, status, reject_reason, order_source, signal_id, price_as_of)
      values (p_account_id, p_stock_id, p_side, p_quantity, p_price, 'REJECTED', 'INSUFFICIENT_FUNDS', p_source, p_signal_id, p_price_as_of)
      returning * into v_order;
      return v_order;
    end if;

    insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, executed_price, fees, status, order_source, signal_id, price_as_of, executed_at)
    values (p_account_id, p_stock_id, p_side, p_quantity, p_price, p_price, p_fees, 'EXECUTED', p_source, p_signal_id, p_price_as_of, now())
    returning * into v_order;

    if v_position.id is null then
      insert into public.paper_positions (account_id, stock_id, quantity, average_buy_price, current_price)
      values (p_account_id, p_stock_id, p_quantity, round(v_cost / p_quantity, 4), p_price);
    else
      update public.paper_positions
         set average_buy_price = round((quantity * average_buy_price + v_cost) / (quantity + p_quantity), 4),
             quantity          = quantity + p_quantity,
             current_price     = p_price
       where id = v_position.id;
    end if;

    insert into public.paper_trades (account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl)
    values (p_account_id, p_stock_id, v_order.id, p_side, p_quantity, p_price, p_fees, 0);

    update public.paper_accounts set available_cash = available_cash - v_cost where id = p_account_id;

  else -- SELL (long-only: cannot exceed holdings)
    if v_position.id is null or v_position.quantity < p_quantity then
      insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, status, reject_reason, order_source, signal_id, price_as_of)
      values (p_account_id, p_stock_id, p_side, p_quantity, p_price, 'REJECTED', 'INSUFFICIENT_QUANTITY', p_source, p_signal_id, p_price_as_of)
      returning * into v_order;
      return v_order;
    end if;

    v_proceeds := p_quantity * p_price - p_fees;
    v_realized := (p_price - v_position.average_buy_price) * p_quantity - p_fees;

    insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, executed_price, fees, status, order_source, signal_id, price_as_of, executed_at)
    values (p_account_id, p_stock_id, p_side, p_quantity, p_price, p_price, p_fees, 'EXECUTED', p_source, p_signal_id, p_price_as_of, now())
    returning * into v_order;

    insert into public.paper_trades (account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl)
    values (p_account_id, p_stock_id, v_order.id, p_side, p_quantity, p_price, p_fees, v_realized);

    if v_position.quantity = p_quantity then
      delete from public.paper_positions where id = v_position.id;
    else
      update public.paper_positions
         set quantity = quantity - p_quantity, current_price = p_price
       where id = v_position.id;
    end if;

    update public.paper_accounts
       set available_cash = available_cash + v_proceeds,
           realized_pnl   = realized_pnl + v_realized
     where id = p_account_id;
  end if;

  return v_order;
end $$;
```

- [ ] **Step 4: Apply and run tests**

Run: `pnpm db:reset && pnpm db:test`
Expected: `All tests successful.`

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): paper trading schema, new-user provisioning and atomic execute_paper_order" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 9: Views and security lockdown (RLS + privileges)

**Files:**

- Create: `supabase/migrations/20261005001000_views_security.sql`
- Test: `supabase/tests/database/09_security.test.sql`

**Interfaces:**

- Produces: views `v_latest_quotes(stock_id, market_id, data_mode, timeframe, ts, price, change, change_percent, volume, source)`, `v_latest_stock_evaluation`, `v_latest_stock_ai_analysis` (status OK only).
- Security: RLS is on for every public table; `anon`/`authenticated` have no privileges on tables, views or `execute_paper_order`. This also holds for future tables via default privileges.

- [ ] **Step 1: Write the failing test** `supabase/tests/database/09_security.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

select has_view('public', 'v_latest_quotes', 'latest quotes view');
select has_view('public', 'v_latest_stock_evaluation', 'latest evaluation view');
select has_view('public', 'v_latest_stock_ai_analysis', 'latest AI analysis view');

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity),
  0, 'RLS enabled on every public table');

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');
insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
select id, 'MOCK', '1d', ts, 100, 101, 99, c, 10, 'mock' from public.stocks,
  (values ('2026-10-01 15:30+05:30'::timestamptz, 100), ('2026-10-02 15:30+05:30', 101)) v(ts, c)
where symbol = 'TESTA';
select is((select price::numeric from public.v_latest_quotes q join public.stocks s on s.id = q.stock_id
            where s.symbol = 'TESTA' and q.data_mode = 'MOCK'), 101.0000::numeric, 'latest quote is newest bar');

set local role anon;
select throws_ok($$select count(*) from public.stocks$$, '42501', null, 'anon cannot read tables');
select throws_ok($$select count(*) from public.v_latest_quotes$$, '42501', null, 'anon cannot read views');
reset role;

set local role authenticated;
select throws_ok($$select public.execute_paper_order(gen_random_uuid(), gen_random_uuid(), 'BUY', 1, 1)$$,
  '42501', null, 'browser roles cannot execute paper orders directly');
reset role;

select * from finish();
rollback;
```

- [ ] **Step 2: Run it to verify it fails**

Run: `pnpm db:test`
Expected: FAIL (`has_view` fails; RLS count > 0).

- [ ] **Step 3: Write the migration** `supabase/migrations/20261005001000_views_security.sql`

```sql
create view public.v_latest_quotes with (security_invoker = true) as
select distinct on (coalesce(stock_id, market_id), data_mode)
       stock_id, market_id, data_mode, timeframe, ts, close as price, change, change_percent, volume, source
  from public.market_data
 order by coalesce(stock_id, market_id), data_mode, ts desc, timeframe;

create view public.v_latest_stock_evaluation with (security_invoker = true) as
select distinct on (stock_id, data_mode) *
  from public.stock_evaluations
 order by stock_id, data_mode, evaluated_at desc;

create view public.v_latest_stock_ai_analysis with (security_invoker = true) as
select distinct on (stock_id, data_mode) *
  from public.stock_ai_analysis
 where status = 'OK'
 order by stock_id, data_mode, analysis_time desc;

-- Lockdown: the browser never touches tables. The backend connects as a privileged role.
do $$
declare r record;
begin
  for r in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', r.tablename);
  end loop;
end $$;

revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke all on tables    from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
```

Note: revoking execute from `public` on `handle_new_user` is safe. Triggers run regardless of EXECUTE privilege on the trigger function for the inserting role, and it is `security definer`.

- [ ] **Step 4: Apply and run the full suite**

Run: `pnpm db:reset && pnpm db:test`
Expected: all 9 files `ok`, `All tests successful.` Pay attention to tests 03 and 06, which call functions as `postgres`; they must still pass after the revokes.

- [ ] **Step 5: Commit**

```bash
git add supabase
git commit -m "feat(db): latest-value views, RLS everywhere and browser-role lockdown" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 10: Seed data (instruments, provider symbols, links, holidays, config) with owner verification

**Files:**

- Create: `supabase/seeds/01_markets.sql` … `07_config.sql`, `scripts/nse/isin-lookup.mjs`, `scripts/nse/holidays-to-sql.mjs`
- Modify: `supabase/config.toml` (`[db.seed] sql_paths`), `.gitignore` (`.cache/`), `eslint.config.js` (node globals for scripts)
- Test: `supabase/tests/database/10_seed.test.sql`

**Interfaces:**

- Produces seeded rows:
  - 12 markets (10 brief indices + NIFTY ENERGY for RELIANCE's sector context + INDIA VIX)
  - 20 NSE stocks
  - provider symbols for `mock` (verified) and `yahoo` (unverified until Phase 3)
  - a BENCHMARK link to NIFTY50 for every stock, plus sector-index links
  - 2026 holidays
  - `scoring_configs` v1 (active)
  - `app_settings`
  - two fee schedules (zero = active, india_delivery_estimate = inactive, pending verification)

- [ ] **Step 1: Write the failing test** `supabase/tests/database/10_seed.test.sql`

```sql
begin;
create extension if not exists pgtap with schema extensions;
select plan(11);

select is((select count(*)::int from public.stocks where exchange = 'NSE' and is_active), 20, '20 seeded NSE stocks');
select is((select count(*)::int from public.markets where is_active), 12, '12 seeded markets incl. VIX');
select is((select count(*)::int from public.markets where market_type = 'VOLATILITY'), 1, 'India VIX present');
select is((select count(*)::int from public.provider_symbols where provider = 'mock'), 32, 'mock mapping for every instrument');
select is((select count(*)::int from public.provider_symbols where provider = 'yahoo'), 32, 'yahoo mapping for every instrument');
select is((select count(*)::int from public.stocks s where not exists (
            select 1 from public.stock_market_links l join public.markets m on m.id = l.market_id
             where l.stock_id = s.id and l.link_type = 'BENCHMARK' and m.symbol = 'NIFTY50')),
  0, 'every stock benchmarked to NIFTY 50');
select ok((select count(*) from public.exchange_holidays where exchange = 'NSE' and extract(year from holiday_date) = 2026) >= 1,
  '2026 NSE holidays loaded');
select is((select count(*)::int from public.scoring_configs where is_active), 1, 'one active scoring config');
select is((select (weights->>'technical')::int + (weights->>'quality')::int + (weights->>'valuation')::int
                + (weights->>'news')::int + (weights->>'momentum')::int + (weights->>'market_context')::int
             from public.scoring_configs where is_active), 100, 'active weights sum to 100');
select is((select (value #>> '{}')::numeric from public.app_settings where key = 'paper_initial_balance'), 1000000::numeric, 'paper balance setting');
select is((select name from public.paper_fee_schedules where is_active), 'zero', 'zero-fee schedule active until owner verifies charges');

select * from finish();
rollback;
```

- [ ] **Step 2: Point the CLI at the seed folder and run the test to see it fail**

In `supabase/config.toml`, under `[db.seed]`:

```toml
enabled = true
sql_paths = ["./seeds/*.sql"]
```

Add `.cache/` to `.gitignore`.
Run: `pnpm db:reset && pnpm db:test`
Expected: FAIL in `10_seed.test.sql` (0 stocks).

- [ ] **Step 3: Write** `supabase/seeds/01_markets.sql`

```sql
insert into public.markets (symbol, name, exchange, market_type, sector, description) values
  ('NIFTY50',         'NIFTY 50',                 'NSE', 'BROAD_INDEX',  null,                              'NSE benchmark index of 50 large caps'),
  ('SENSEX',          'SENSEX',                   'BSE', 'BROAD_INDEX',  null,                              'BSE benchmark index of 30 large caps'),
  ('BANKNIFTY',       'NIFTY BANK',               'NSE', 'SECTOR_INDEX', 'Financial Services',              'Banking sector index'),
  ('NIFTYIT',         'NIFTY IT',                 'NSE', 'SECTOR_INDEX', 'Information Technology',          'IT sector index'),
  ('NIFTYPHARMA',     'NIFTY PHARMA',             'NSE', 'SECTOR_INDEX', 'Healthcare',                      'Pharma sector index'),
  ('NIFTYAUTO',       'NIFTY AUTO',               'NSE', 'SECTOR_INDEX', 'Automobile and Auto Components',  'Auto sector index'),
  ('NIFTYFMCG',       'NIFTY FMCG',               'NSE', 'SECTOR_INDEX', 'Fast Moving Consumer Goods',      'FMCG sector index'),
  ('NIFTYMETAL',      'NIFTY METAL',              'NSE', 'SECTOR_INDEX', 'Metals & Mining',                 'Metal sector index'),
  ('NIFTYREALTY',     'NIFTY REALTY',             'NSE', 'SECTOR_INDEX', 'Realty',                          'Realty sector index'),
  ('NIFTYFINSERVICE', 'NIFTY FINANCIAL SERVICES', 'NSE', 'SECTOR_INDEX', 'Financial Services',              'Financial services sector index'),
  ('NIFTYENERGY',     'NIFTY ENERGY',             'NSE', 'SECTOR_INDEX', 'Oil Gas & Consumable Fuels',      'Energy sector index'),
  ('INDIAVIX',        'INDIA VIX',                'NSE', 'VOLATILITY',   null,                              'Expected 30-day NIFTY volatility');
```

- [ ] **Step 4: Write** `supabase/seeds/02_stocks.sql` (company names are provisional; Step 6 replaces them with the official NSE names along with the ISINs)

```sql
insert into public.stocks (symbol, company_name, exchange, sector, industry) values
  ('RELIANCE',   'Reliance Industries Limited',        'NSE', 'Oil Gas & Consumable Fuels',     'Refineries & Marketing'),
  ('TCS',        'Tata Consultancy Services Limited',  'NSE', 'Information Technology',         'Computers - Software & Consulting'),
  ('INFY',       'Infosys Limited',                    'NSE', 'Information Technology',         'Computers - Software & Consulting'),
  ('HDFCBANK',   'HDFC Bank Limited',                  'NSE', 'Financial Services',             'Private Sector Bank'),
  ('ICICIBANK',  'ICICI Bank Limited',                 'NSE', 'Financial Services',             'Private Sector Bank'),
  ('SBIN',       'State Bank of India',                'NSE', 'Financial Services',             'Public Sector Bank'),
  ('BHARTIARTL', 'Bharti Airtel Limited',              'NSE', 'Telecommunication',              'Telecom - Cellular & Fixed line services'),
  ('ITC',        'ITC Limited',                        'NSE', 'Fast Moving Consumer Goods',     'Diversified FMCG'),
  ('LT',         'Larsen & Toubro Limited',            'NSE', 'Construction',                   'Civil Construction'),
  ('AXISBANK',   'Axis Bank Limited',                  'NSE', 'Financial Services',             'Private Sector Bank'),
  ('KOTAKBANK',  'Kotak Mahindra Bank Limited',        'NSE', 'Financial Services',             'Private Sector Bank'),
  ('MARUTI',     'Maruti Suzuki India Limited',        'NSE', 'Automobile and Auto Components', 'Passenger Cars & Utility Vehicles'),
  ('SUNPHARMA',  'Sun Pharmaceutical Industries Limited', 'NSE', 'Healthcare',                  'Pharmaceuticals'),
  ('HINDUNILVR', 'Hindustan Unilever Limited',         'NSE', 'Fast Moving Consumer Goods',     'Diversified FMCG'),
  ('TITAN',      'Titan Company Limited',              'NSE', 'Consumer Durables',              'Gems, Jewellery And Watches'),
  ('ADANIENT',   'Adani Enterprises Limited',          'NSE', 'Metals & Mining',                'Trading - Minerals'),
  ('ADANIPORTS', 'Adani Ports and Special Economic Zone Limited', 'NSE', 'Services',            'Port & Port services'),
  ('WIPRO',      'Wipro Limited',                      'NSE', 'Information Technology',         'Computers - Software & Consulting'),
  ('HCLTECH',    'HCL Technologies Limited',           'NSE', 'Information Technology',         'Computers - Software & Consulting'),
  ('BAJFINANCE', 'Bajaj Finance Limited',              'NSE', 'Financial Services',             'Non Banking Financial Company (NBFC)');
```

- [ ] **Step 5: Write the ISIN script** `scripts/nse/isin-lookup.mjs`, and allow Node globals for scripts in ESLint

```js
// Emits UPDATE statements that set official ISIN + company name from NSE's EQUITY_L.csv.
// Usage: node scripts/nse/isin-lookup.mjs <EQUITY_L.csv> <SYMBOL...> > supabase/seeds/03_stock_isins.sql
import { readFileSync } from 'node:fs';
import process from 'node:process';

const [file, ...symbols] = process.argv.slice(2);
if (!file || symbols.length === 0) {
  console.error('usage: isin-lookup.mjs <EQUITY_L.csv> <SYMBOL...>');
  process.exit(2);
}

function parseLine(line) {
  const cells = [];
  let cell = '';
  let quoted = false;
  for (const ch of line) {
    if (ch === '"') quoted = !quoted;
    else if (ch === ',' && !quoted) {
      cells.push(cell.trim());
      cell = '';
    } else cell += ch;
  }
  cells.push(cell.trim());
  return cells;
}

const sql = (s) => `'${s.replaceAll("'", "''")}'`;
const [header, ...rows] = readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
const cols = parseLine(header).map((h) => h.toUpperCase());
const iSym = cols.indexOf('SYMBOL');
const iName = cols.indexOf('NAME OF COMPANY');
const iIsin = cols.indexOf('ISIN NUMBER');
if ([iSym, iName, iIsin].includes(-1)) {
  console.error(`unexpected EQUITY_L.csv header: ${header}`);
  process.exit(1);
}

const bySymbol = new Map(rows.map(parseLine).map((r) => [r[iSym], r]));
let missing = 0;
console.log('-- Generated by scripts/nse/isin-lookup.mjs from NSE EQUITY_L.csv. Do not hand-edit.');
for (const symbol of symbols) {
  const row = bySymbol.get(symbol);
  if (!row) {
    console.error(`NOT FOUND in EQUITY_L.csv: ${symbol}`);
    missing += 1;
    continue;
  }
  console.log(
    `update public.stocks set isin = ${sql(row[iIsin])}, isin_verified = true, company_name = ${sql(row[iName])} ` +
      `where exchange = 'NSE' and symbol = ${sql(symbol)};`,
  );
}
process.exit(missing > 0 ? 1 : 0);
```

Run `pnpm add -Dw globals`, then append to the `tseslint.config(...)` list in `eslint.config.js` (adding `import globals from 'globals';` at the top):

```js
  { files: ['scripts/**/*.mjs'], languageOptions: { globals: globals.node } },
```

- [ ] **Step 6: Fetch the official equity list and generate ISINs**

```bash
mkdir -p .cache/nse
curl -fsSL -A "Mozilla/5.0" -o .cache/nse/EQUITY_L.csv https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv
node scripts/nse/isin-lookup.mjs .cache/nse/EQUITY_L.csv RELIANCE TCS INFY HDFCBANK ICICIBANK SBIN BHARTIARTL ITC LT AXISBANK KOTAKBANK MARUTI SUNPHARMA HINDUNILVR TITAN ADANIENT ADANIPORTS WIPRO HCLTECH BAJFINANCE > supabase/seeds/03_stock_isins.sql
```

Expected: exit 0 and 20 `update` lines.
**If curl gets 403 or any symbol is NOT FOUND:** stop and ask the owner to download `EQUITY_L.csv` from nseindia.com into `.cache/nse/`, then re-run. If that's not possible, write `03_stock_isins.sql` containing only the comment line `-- ISINs pending owner verification`. ISINs then stay NULL with `isin_verified = false`. **Never type ISINs from memory.**

- [ ] **Step 7: Write the holiday script** `scripts/nse/holidays-to-sql.mjs`

```js
// Converts NSE holiday-master JSON (capital market segment "CM") into exchange_holidays inserts.
// The same trading-holiday list is applied to BSE equity (exchanges publish a common equity calendar);
// the owner verifies it against the BSE circular.
// Usage: node scripts/nse/holidays-to-sql.mjs <holidays.json> <year> > supabase/seeds/06_holidays_2026.sql
import { readFileSync } from 'node:fs';
import process from 'node:process';

const [file, year] = process.argv.slice(2);
if (!file || !/^\d{4}$/.test(year ?? '')) {
  console.error('usage: holidays-to-sql.mjs <holidays.json> <year>');
  process.exit(2);
}

const MONTHS = {
  Jan: '01',
  Feb: '02',
  Mar: '03',
  Apr: '04',
  May: '05',
  Jun: '06',
  Jul: '07',
  Aug: '08',
  Sep: '09',
  Oct: '10',
  Nov: '11',
  Dec: '12',
};
const toIso = (d) => {
  const [dd, mon, yyyy] = d.split('-');
  if (!MONTHS[mon] || !dd || !yyyy) throw new Error(`unparseable tradingDate: ${d}`);
  return `${yyyy}-${MONTHS[mon]}-${dd.padStart(2, '0')}`;
};
const sql = (s) => `'${s.replaceAll("'", "''")}'`;

const rows = JSON.parse(readFileSync(file, 'utf8')).CM;
if (!Array.isArray(rows) || rows.length === 0) {
  console.error('no "CM" (capital market) holidays found in file');
  process.exit(1);
}
const holidays = rows
  .map((r) => ({ date: toIso(r.tradingDate), description: String(r.description).trim() }))
  .filter((h) => h.date.startsWith(`${year}-`));
if (holidays.length === 0) {
  console.error(`no holidays for ${year}`);
  process.exit(1);
}

const values = holidays.flatMap((h) =>
  ['NSE', 'BSE'].map(
    (ex) => `  ('${ex}', '${h.date}', ${sql(h.description)}, 'EQUITY', 'nse:holiday-master')`,
  ),
);
console.log(
  `-- Generated by scripts/nse/holidays-to-sql.mjs (${year}). Verified by owner before commit.`,
);
console.log(
  'insert into public.exchange_holidays (exchange, holiday_date, description, segment, source) values',
);
console.log(`${values.join(',\n')}\non conflict (exchange, holiday_date, segment) do nothing;`);
```

- [ ] **Step 8: Fetch holidays and generate the seed**

```bash
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
curl -fsSL -c .cache/nse/cookies -A "$UA" https://www.nseindia.com/ -o /dev/null
curl -fsSL -b .cache/nse/cookies -A "$UA" -H "Referer: https://www.nseindia.com/resources/exchange-communication-holidays" \
  "https://www.nseindia.com/api/holiday-master?type=trading" -o .cache/nse/holidays.json
node scripts/nse/holidays-to-sql.mjs .cache/nse/holidays.json 2026 > supabase/seeds/06_holidays_2026.sql
```

Expected: exit 0 and roughly 15 dates × 2 exchanges.
**If NSE blocks the request:** stop and ask the owner to paste the official 2026 trading-holiday list (date + description). Write it into the same insert format with `source = 'owner'`. **Never type holidays from memory.**

- [ ] **Step 9: Write** `supabase/seeds/04_provider_symbols.sql`

```sql
-- mock: internal symbol (always valid). yahoo: unverified until Phase 3's live lookup.
insert into public.provider_symbols (provider, stock_id, provider_symbol, verified)
select 'mock', id, symbol, true from public.stocks where exchange = 'NSE';
insert into public.provider_symbols (provider, stock_id, provider_symbol, verified)
select 'yahoo', id, symbol || '.NS', false from public.stocks where exchange = 'NSE';

insert into public.provider_symbols (provider, market_id, provider_symbol, verified)
select 'mock', id, symbol, true from public.markets;
insert into public.provider_symbols (provider, market_id, provider_symbol, verified)
select 'yahoo', m.id, v.yahoo_symbol, false
  from (values ('NIFTY50', '^NSEI'), ('SENSEX', '^BSESN'), ('BANKNIFTY', '^NSEBANK'), ('NIFTYIT', '^CNXIT'),
               ('NIFTYPHARMA', '^CNXPHARMA'), ('NIFTYAUTO', '^CNXAUTO'), ('NIFTYFMCG', '^CNXFMCG'),
               ('NIFTYMETAL', '^CNXMETAL'), ('NIFTYREALTY', '^CNXREALTY'),
               ('NIFTYFINSERVICE', 'NIFTY_FIN_SERVICE.NS'), ('NIFTYENERGY', '^CNXENERGY'),
               ('INDIAVIX', '^INDIAVIX')) v(symbol, yahoo_symbol)
  join public.markets m on m.symbol = v.symbol;
```

- [ ] **Step 10: Write** `supabase/seeds/05_stock_market_links.sql`

```sql
insert into public.stock_market_links (stock_id, market_id, link_type)
select s.id, m.id, 'BENCHMARK' from public.stocks s cross join public.markets m
 where s.exchange = 'NSE' and m.symbol = 'NIFTY50';

insert into public.stock_market_links (stock_id, market_id, link_type)
select s.id, m.id, 'SECTOR_INDEX'
  from (values ('TCS', 'NIFTYIT'), ('INFY', 'NIFTYIT'), ('WIPRO', 'NIFTYIT'), ('HCLTECH', 'NIFTYIT'),
               ('HDFCBANK', 'BANKNIFTY'), ('ICICIBANK', 'BANKNIFTY'), ('SBIN', 'BANKNIFTY'),
               ('AXISBANK', 'BANKNIFTY'), ('KOTAKBANK', 'BANKNIFTY'),
               ('HDFCBANK', 'NIFTYFINSERVICE'), ('ICICIBANK', 'NIFTYFINSERVICE'), ('SBIN', 'NIFTYFINSERVICE'),
               ('AXISBANK', 'NIFTYFINSERVICE'), ('KOTAKBANK', 'NIFTYFINSERVICE'), ('BAJFINANCE', 'NIFTYFINSERVICE'),
               ('ITC', 'NIFTYFMCG'), ('HINDUNILVR', 'NIFTYFMCG'),
               ('MARUTI', 'NIFTYAUTO'), ('SUNPHARMA', 'NIFTYPHARMA'), ('RELIANCE', 'NIFTYENERGY')) v(stock, idx)
  join public.stocks s on s.symbol = v.stock and s.exchange = 'NSE'
  join public.markets m on m.symbol = v.idx;
```

- [ ] **Step 11: Write** `supabase/seeds/07_config.sql`

```sql
insert into public.scoring_configs (version, is_active, notes, weights, thresholds) values (
  'v1', true, 'Initial weights from PRD §8.2; thresholds from PRD §8.5',
  '{"technical":30,"quality":10,"valuation":10,"news":20,"momentum":15,"market_context":15}',
  '{"buy_overall_min":65,"strong_buy_overall_min":80,"avoid_overall_max":35,"strong_sell_overall_max":25,
    "extended_above_sma50_pct":8,"rsi_overbought":70,"min_risk_reward":2,"stop_atr_multiple":1.5,
    "entry_atr_width":0.5,"risk_per_trade_pct":1,"min_daily_bars":200,"valuation_low_pctile":30,
    "valuation_high_pctile":70,"min_sector_peers":4,"news_half_life_days":7}'
);

insert into public.app_settings (key, value, description) values
  ('paper_initial_balance',          '1000000', 'Starting paper cash in INR per data mode'),
  ('llm_daily_budget_inr',           '100',     'Hard cap on estimated LLM spend per IST day'),
  ('analysis_min_interval_minutes',  '30',      'Minimum gap between AI analyses of one stock'),
  ('quote_staleness_minutes',        '20',      'Paper orders rejected if the latest price is older'),
  ('allow_orders_when_market_closed','false',   'If true, paper orders fill at last close and are labelled'),
  ('auto_paper_trade',               'false',   'Never auto-execute AI signals unless explicitly enabled'),
  ('news_relevance_threshold',       '0.5',     'Skip LLM sentiment for mentions below this relevance');

insert into public.paper_fee_schedules
  (name, is_active, brokerage_pct, brokerage_max, stt_buy_pct, stt_sell_pct, exchange_txn_pct, sebi_fee_pct, stamp_duty_buy_pct, gst_pct, notes)
values
  ('zero', true, 0, null, 0, 0, 0, 0, 0, 0, 'No charges. Active until the owner verifies a real schedule.'),
  ('india_delivery_estimate', false, 0, 20, 0.1, 0.1, 0.00297, 0.0001, 0.015, 18,
   'ESTIMATE for equity delivery (percent values). VERIFY against your broker contract note before activating.');
```

- [ ] **Step 12: Apply seeds and run the full suite**

Run: `pnpm db:reset && pnpm db:test`
Expected: all 10 files `ok`. Then lint the scripts: `pnpm lint`, expected clean.

- [ ] **Step 13: OWNER VERIFICATION CHECKPOINT (stop)**

Show the owner, as tables:

- `select symbol, company_name, isin, isin_verified, sector, industry from public.stocks order by symbol;`
- `select exchange, holiday_date, description from public.exchange_holidays order by holiday_date, exchange;`
- `select * from public.paper_fee_schedules;`

Run these with `docker exec -i $(docker ps -qf name=supabase_db) psql -U postgres -c "<query>"`.
Wait for confirmation, apply any corrections to the seed files, and re-run Step 12.

- [ ] **Step 14: Commit**

```bash
git add supabase/seeds supabase/config.toml supabase/tests scripts .gitignore eslint.config.js package.json pnpm-lock.yaml
git commit -m "feat(db): seed instruments, provider symbols, links, 2026 holidays and default config" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 11: Database documentation and Phase 1 verification report

**Files:**

- Create: `docs/database.md`

- [ ] **Step 1: Write `docs/database.md`.** Contents: purpose; conventions (UTC, `data_mode`, domains); the ERD from PRD §7.9; one subsection per migration (tables, key constraints, why); the function contracts (`is_market_open`, `next_market_open`, `match_documents`, `execute_paper_order`, `handle_new_user`); the security model (RLS + revokes, backend as privileged role); seed provenance (NSE EQUITY_L.csv, NSE holiday master, owner-verified fees); how to add a stock (insert `stocks`, `provider_symbols`, `stock_market_links`, with no code change); and how to run, reset and test.

- [ ] **Step 2: Full clean verification**

```bash
pnpm db:stop --no-backup && pnpm db:start && pnpm db:reset && pnpm db:test
pnpm lint && pnpm format:check
```

Expected: every pgTAP file `ok`, `All tests successful.`, lint and format clean.

- [ ] **Step 3: Collect the report numbers**

```bash
docker exec -i $(docker ps -qf name=supabase_db) psql -U postgres -At -c "
select 'tables', count(*) from pg_tables where schemaname='public'
union all select 'stocks', count(*) from public.stocks
union all select 'markets', count(*) from public.markets
union all select 'provider_symbols', count(*) from public.provider_symbols
union all select 'stock_market_links', count(*) from public.stock_market_links
union all select 'holidays', count(*) from public.exchange_holidays
union all select 'verified_isins', count(*) from public.stocks where isin_verified;"
```

- [ ] **Step 4: Commit and STOP**

```bash
git add docs/database.md
git commit -m "docs: database design, contracts and operations" -m "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

Report to the owner: migrations created, tables and functions, test output, seed counts, and any NULL/unverified items. **Wait for approval before Phase 2.**
