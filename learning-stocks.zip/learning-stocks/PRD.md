# PRD — AI Stock Research & Paper-Trading Platform (India: NSE/BSE)

> **Status:** v1.0 · 2026-10-05 · source of truth for design decisions.
> **Audience:** the owner/operator (personal use) and anyone implementing the system.
> **Disclaimer (product-wide):** AI analysis is for personal research and paper trading only. It is **not investment advice**, and no outcome is guaranteed.

---

## 1. Product goals

The platform works like an experienced equity analyst's research desk for Indian stocks. For any supported stock it answers:

1. **What is happening?** Price, trend, momentum, volume, market and sector context.
2. **Is it worth considering?** Business quality, valuation (cheap, fair or expensive), news flow.
3. **When might it be a good time to act?** Buy zone, wait for a pullback, wait for confirmation, avoid or reduce.
4. **At what price?** Entry zone, stop-loss, targets, risk/reward and a position-size hint.
5. **What could go wrong?** Key risks, invalidation level, data gaps, confidence.
6. **What is the evidence?** Every number traces back to stored data, and every claim to a cited source.

Users can then **paper-trade** these ideas with ₹10,00,000 of virtual capital and track P&L.

### Non-goals (v1)

- Real-money trading, broker connectivity or automatic order execution.
- Public or multi-tenant distribution. The tool is personal. Publishing buy/sell calls to others is regulated in India (SEBI Research Analyst regulations).
- Derivatives (F&O), intraday short selling, or options analytics.
- Predicting prices. The system expresses **biases with confidence**, never certainties.

### Language rules (enforced in prompts and output validation)

- Use: _AI Sentiment, Bullish/Neutral/Bearish, Confidence, Risk Level, Technical/Fundamental/News/Overall Score, AI Analysis, Paper Trade Signal, Bias._
- Write it like this: _"AI analysis indicates a bullish bias based on the available market, technical, fundamental and news data."_
- Banned: _"guaranteed", "will definitely", "sure-shot", "certain to rise/fall", "risk-free"._ If output contains these, it is rejected and regenerated.

---

## 2. Users & key scenarios

| Role   | Description                                                     |
| ------ | --------------------------------------------------------------- |
| OWNER  | The single primary user. Full access, including admin triggers  |
| ADMIN  | Same as OWNER, minus account ownership (optional second person) |
| VIEWER | Read-only (optional)                                            |

**Scenarios**

1. In the morning, open the dashboard and see the NIFTY 50/SENSEX state, the AI market regime, and which stocks are in a buy zone or need waiting.
2. Open `/stocks/RELIANCE` and understand within 30 seconds the action state, entry zone, stop, targets, valuation, risks and why.
3. Ask the RAG assistant _"What news is driving this stock?"_ and get a cited answer.
4. Click **Paper Buy** on an AI Paper Trade Signal, then track P&L on `/portfolio`.
5. On `/admin`, see that the 10:05 market sync failed for 2 symbols, retry it, and check LLM spend.

---

## 3. Features

### 3.1 Market overview (dashboard `/`)

- Header: app name, stock search (symbol/company/ISIN), **market status** (Open/Closed/Holiday + next open, in IST).
- Index cards: NIFTY 50, SENSEX, BANK NIFTY, NIFTY IT, NIFTY PHARMA (configurable list). Each card shows price, change, change %, and freshness.
- **AI Market Sentiment:** sentiment, confidence, score, risk level, regime (RISK_ON/NEUTRAL/RISK_OFF), summary, key drivers, key risks, positive and negative sectors.
- **Worth Considering** table: stock, price, change %, action state, valuation label, technical/news/AI scores, R:R, sentiment, risk. Sortable and filterable.
- **Latest News:** headline, source, published time, linked stocks, sentiment, impact.

### 3.2 Stock detail (`/stocks/:symbol`)

- Header: company, symbol, exchange, price, change, change %, market status, **"Data updated X min ago · source"**.
- **Decision card** (top of page): action state, recommendation bias, entry zone, stop-loss, T1/T2, R:R, valuation label, confidence, risk level, invalidation condition, "AI analysis generated X min ago".
- **Chart:** candlesticks, timeframes 1D/1W/1M/3M/6M/1Y/5Y, overlays SMA 20/50/200, horizontal lines for entry zone, SL and targets, volume pane.
- **Technical panel:** RSI, MACD, SMA 20/50/200, EMA, ADX, ATR, Bollinger, Stochastic, VWAP, volume vs average, technical score, plus a plain-language interpretation per indicator (no predictive claims).
- **Fundamentals & valuation panel:** P/E, P/B, EPS, ROE, ROCE, D/E, dividend yield, margins, FCF, revenue/profit growth, quarterly and annual results. A missing value shows **"unavailable"**. If everything is missing: **"Fundamental data unavailable"**.
- **AI analysis panel:** sentiment, confidence, overall score, trend, risk level, recommendation bias, summary, a "Why?" section (reasoning), positive and negative factors, key risks, catalysts, invalidation, **FACT vs AI INTERPRETATION** sections, cited sources, data freshness.
- **News panel:** headline, source, published time, sentiment, impact, AI summary, link to the source.
- **RAG assistant:** Q&A answered from retrieved data only, with sources shown.
- **AI Paper Trade Signal + order box:** entry, target, stop, R:R, confidence, reasoning, suggested quantity. **Paper Buy/Sell only by manual click.**

### 3.3 Portfolio (`/portfolio`)

Account summary (cash, invested, market value, realised/unrealised/total P&L, return % vs NIFTY 50), positions, order history, trade history.

### 3.4 Admin (`/admin`)

Health of DB, market API, news API and LLM. Cron job runs (last success/failure, records processed, duration). Failures list. LLM calls and spend vs daily budget. Buttons: Sync Market, Sync News, Sync Fundamentals, Run Technical, Run Evaluation, Run AI Analysis, Generate Market Summary, Purge Mock Data.

### 3.5 Future-ready (architecture only in v1)

Stock comparison (2–5 stocks: performance, scores, valuation, quality, risk); broker-API market data adapter; additional LLM providers (Anthropic, Gemini, local).

---

## 4. Architecture

```
                     USER (browser)
                          │  HTTPS (JWT from Supabase Auth)
                          ▼
                Next.js frontend (no secrets, no business logic)
                          │  REST /api/*
                          ▼
        Fastify backend API ───────────── pg-boss worker (cron + queues)
          │ routes → controllers → services → repositories   │ same services
          ▼                                                  ▼
  Services: MarketData · News · Fundamentals · MarketCalendar · TechnicalAnalysis
            Levels · Scoring · Valuation · Decision · Sentiment · Embedding · RAG
            AIAnalysis · MarketSummary · TradeSignal · PaperTrading · Portfolio · SystemHealth
          │                                   │
          ▼                                   ▼
  Providers (adapters behind interfaces)   Supabase PostgreSQL + pgvector
   MarketDataProvider: Mock | Yahoo         reference · market · fundamentals · news
   NewsProvider: Mock | RSS | NewsAPI       embeddings · evaluations · AI · paper · ops
   FundamentalsProvider: Mock | Yahoo
   LLMProvider: Mock | OpenAI (Anthropic/Gemini/Local later)
```

### 4.1 Layers

1. **Frontend:** renders backend DTOs. It holds only public config (`NEXT_PUBLIC_*`) and uses Supabase Auth for login.
2. **Backend API:** authentication, authorization, validation, rate limiting, caching, job triggers, business logic.
3. **Data/AI processing:** ingestion, indicators, deterministic scoring, embeddings, RAG, LLM calls. It runs in the worker process and reuses the same service classes.
4. **Database:** the single source of persisted truth. The SQL migrations are the schema of record.

### 4.2 Principles

- **Deterministic before generative.** Indicators, scores, valuation bands, levels and action states are computed by code. The LLM explains them and interprets news. LLM numbers never override computed numbers; it is the other way round.
- **Providers are replaceable.** No business code imports a provider SDK. Selection happens in `providers/factory.ts` from env.
- **Honest data.** If data is missing, the system says so (`INSUFFICIENT_DATA`, "unavailable"). Every value carries `source` and `as_of`.
- **Mock and live are isolated.** Every data-bearing row has `data_mode ∈ {MOCK, LIVE}`, which is part of unique keys and filters.
- **Failure isolation.** One instrument or article failing never aborts a batch.
- **Cost-aware AI.** LLM calls are gated by input hashing, intervals and a daily budget.

### 4.3 Tech stack

| Concern  | Choice                                                                            |
| -------- | --------------------------------------------------------------------------------- |
| Language | TypeScript (strict), Node ≥ 22, pnpm workspaces                                   |
| Backend  | Fastify, zod, Kysely + `pg`, pino, pg-boss                                        |
| DB       | Supabase Postgres (local Docker → cloud), pgvector, pgTAP for DB tests            |
| Frontend | Next.js App Router, Tailwind, shadcn/ui, lightweight-charts, Recharts             |
| AI       | OpenAI chat with Structured Outputs; `text-embedding-3-small` (1536-d)            |
| Tests    | Vitest (unit/integration), pgTAP, Playwright (E2E smoke)                          |
| DI       | Hand-written composition root (`backend/src/container.ts`), constructor injection |

### 4.4 Repository layout

```
PRD.md  IMPLEMENTATION_PLAN.md  README.md  .env.example  docs/
supabase/{config.toml, migrations/, seeds/*.sql (applied in order), tests/database/}
packages/shared/      zod schemas, DTO types, enums (no I/O, no secrets)
backend/{prompts/, src/{config,domain,providers,repositories,services,technical,scoring,
         rag,ai,paperTrading,jobs,routes,controllers,middleware,utils}, container.ts,
         server.ts, worker.ts, tests/}
frontend/             Next.js app
```

---

## 5. Indian market specifics

- **Exchanges:** NSE and BSE. A stock row is one _listing_ `(exchange, symbol)`. Listings of the same company share an ISIN.
- **Currency:** INR. Display uses Indian digit grouping (`en-IN`): ₹10,00,000.
- **Time:** stored as UTC `timestamptz`, displayed in **IST (Asia/Kolkata)**.
- **Session:** regular equity session 09:15–15:30 IST, Monday–Friday, **excluding exchange holidays** from `exchange_holidays` (loaded from the official exchange list and maintained yearly). Special sessions (e.g. Muhurat trading) are represented with `special_open/special_close`.
- **MarketCalendarService** (TS, canonical) provides `isTradingDay(date, exchange)`, `isOpen(ts, exchange)`, `nextOpen(ts)`, `previousTradingDay(date)` and `sessionBounds(date)`. A SQL mirror `is_market_open()` exists for views and tests.
- **Indices** (seed): NIFTY 50, SENSEX, NIFTY BANK, NIFTY IT, NIFTY PHARMA, NIFTY AUTO, NIFTY FMCG, NIFTY METAL, NIFTY REALTY, NIFTY FINANCIAL SERVICES, **NIFTY ENERGY** (sector context for RELIANCE), and **India VIX** (volatility regime).
- **Seed stocks** (data, not code): RELIANCE, TCS, INFY, HDFCBANK, ICICIBANK, SBIN, BHARTIARTL, ITC, LT, AXISBANK, KOTAKBANK, MARUTI, SUNPHARMA, HINDUNILVR, TITAN, ADANIENT, ADANIPORTS, WIPRO, HCLTECH, BAJFINANCE (NSE listings). ISINs come from NSE's official equity master. No value is typed from memory.
- **Provider symbol mapping** lives in `provider_symbols` (e.g. yahoo → `RELIANCE.NS`, `^NSEI`). Adding a stock means inserting rows, with no code change.

---

## 6. Data providers

### 6.1 Interfaces (backend/src/providers/*/types.ts)

```ts
interface MarketDataProvider {
  readonly name: string;
  capabilities(): ProviderCapabilities; // exchanges, intervals, realtime|delayed|eod
  getQuote(ref: InstrumentRef): Promise<Quote>;
  getHistorical(ref: InstrumentRef, from: Date, to: Date, interval: BarInterval): Promise<Bar[]>;
  getIndexQuote(ref: InstrumentRef): Promise<Quote>;
}
interface NewsProvider {
  readonly name: string;
  fetchForInstrument(q: NewsQuery): Promise<RawArticle[]>;
  fetchMarketNews(q: NewsQuery): Promise<RawArticle[]>;
}
interface FundamentalsProvider {
  readonly name: string;
  capabilities(): FundamentalsCapabilities; // which fields it can supply
  getSnapshot(ref: InstrumentRef): Promise<FundamentalSnapshot>;
  getStatements(ref: InstrumentRef, period: 'QUARTERLY' | 'ANNUAL'): Promise<FinancialStatement[]>;
}
interface LLMProvider {
  readonly name: string;
  completeStructured<T>(req: {
    system: string;
    user: string;
    schema: ZodType<T>;
    schemaName: string;
    model?: string;
    temperature?: number;
  }): Promise<LLMResult<T>>;
  embed(texts: string[]): Promise<number[][]>;
}
```

`InstrumentRef` carries the internal ID plus the provider symbol resolved from `provider_symbols`.

### 6.2 Adapters (v1)

| Kind         | Adapter                                                  | Notes                                                                                    |
| ------------ | -------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| Market       | `MockMarketDataProvider`                                 | Deterministic seeded GBM, sector-correlated. Base levels in a fixture file labelled MOCK |
| Market       | `YahooMarketDataProvider`                                | `yahoo-finance2`. Unofficial; may be delayed; declared `delayed` in capabilities         |
| News         | `MockNewsProvider`, `RssNewsProvider`, `NewsApiProvider` | RSS default (Google News search + Indian business feeds; personal use)                   |
| Fundamentals | `MockFundamentalsProvider`, `YahooFundamentalsProvider`  | Unsupported fields → `null`                                                              |
| LLM          | `MockLLMProvider`, `OpenAIProvider`                      | Mock returns schema-valid output derived from its input                                  |

### 6.3 Factory & config

`MARKET_DATA_PROVIDER`, `NEWS_PROVIDER`, `FUNDAMENTALS_PROVIDER`, `LLM_PROVIDER`; `MOCK_DATA=true` forces all four to mock and `data_mode=MOCK`.

### 6.4 Resilience

- `httpClient` with timeout (default 10 s). `withRetry`: 3 attempts, exponential backoff with jitter, respects `Retry-After`.
- **No retry** on auth failures (401/403) or validation errors. The provider is marked `AUTH_FAILED` in health.
- Per-provider token bucket throttle.
- Error taxonomy: `TIMEOUT · RATE_LIMITED · AUTH_FAILED · INVALID_RESPONSE · EMPTY_RESPONSE · NETWORK · PROVIDER_DOWN · UNSUPPORTED`.
- Batch isolation: per-instrument try/catch. The result is `{fetched, inserted, skipped, failed, failures[]}`.
- `UNSUPPORTED` (e.g. a provider lacks BSE coverage) is logged and shown in the UI. Nothing is ever substituted.

### 6.5 Data quality (before insert)

Symbol resolves; timestamp not in the future and (intraday) within session; `open, high, low, close > 0`; `high ≥ max(open, close, low)`; `low ≤ min(open, close)`; `volume ≥ 0`. Rejected rows are counted and logged. The DB repeats these as CHECK constraints.

---

## 7. Database schema

Conventions: `uuid` PK (`gen_random_uuid()`), `created_at/updated_at timestamptz` (trigger-maintained), prices and money `numeric(18,4)`, scores `numeric(5,2)` in 0–100, closed sets as Postgres enums, RLS enabled on every table. The backend connects with a privileged role, and the browser never queries tables directly.

### 7.1 Enums

`exchange_code (NSE, BSE)`, `market_type (BROAD_INDEX, SECTOR_INDEX, VOLATILITY)`, `data_mode (MOCK, LIVE)`, `bar_interval (1m, 5m, 15m, 1d)`, `sentiment (BULLISH, NEUTRAL, BEARISH)`, `impact_level (LOW, MEDIUM, HIGH)`, `trend (UPTREND, SIDEWAYS, DOWNTREND)`, `risk_level (LOW, MEDIUM, HIGH, VERY_HIGH)`, `recommendation_bias (STRONG_BUY_BIAS, BUY_BIAS, HOLD_BIAS, SELL_BIAS, STRONG_SELL_BIAS)`, `action_state (BUY_ZONE, WAIT_FOR_PULLBACK, WAIT_FOR_CONFIRMATION, HOLD, REDUCE, AVOID, INSUFFICIENT_DATA)`, `valuation_label (UNDERVALUED, FAIR, OVERVALUED, INSUFFICIENT_DATA)`, `market_regime (RISK_ON, NEUTRAL, RISK_OFF)`, `trade_side (BUY, SELL)`, `order_status (PENDING, EXECUTED, REJECTED, CANCELLED)`, `order_source (MANUAL, AI_SIGNAL)`, `signal_type (BUY, SELL, HOLD)`, `signal_status (ACTIVE, TRIGGERED, EXPIRED, INVALIDATED)`, `period_type (QUARTERLY, ANNUAL, TTM)`, `link_type (BENCHMARK, SECTOR_INDEX, CONSTITUENT)`, `user_role (OWNER, ADMIN, VIEWER)`, `job_status (STARTED, SUCCESS, PARTIAL, FAILED, SKIPPED)`, `analysis_status (OK, FAILED, INSUFFICIENT_DATA)`.

### 7.2 Reference

- **markets**: id, symbol, name, exchange, market_type, sector, description, is_active, created_at, updated_at. UNIQUE(exchange, symbol).
- **stocks**: id, symbol, company_name, exchange, isin, isin_verified bool, sector, industry, market_cap numeric, currency (default 'INR'), is_active, created_at, updated_at. UNIQUE(exchange, symbol); INDEX(isin); trigram index on company_name for search.
- **provider_symbols**: id, provider text, stock_id?, market_id?, provider_symbol, created_at. CHECK exactly one of stock_id/market_id. UNIQUE(provider, stock_id) and UNIQUE(provider, market_id) as partial indexes.
- **stock_market_links**: stock_id, market_id, link_type. PK(stock_id, market_id, link_type).
- **exchange_holidays**: id, exchange, holiday_date, description, segment (default 'EQUITY'), special_open time?, special_close time?, source, created_at. UNIQUE(exchange, holiday_date, segment).

### 7.3 Market data

- **market_data**: id, stock_id?, market_id?, data_mode, timeframe (`bar_interval`; `interval` is an SQL keyword), ts, open, high, low, close, adjusted_close, volume bigint, change, change_percent, vwap, source, created_at. CHECK exactly one owner; OHLC CHECKs. Partial UNIQUE(stock_id, data_mode, timeframe, ts, source) WHERE stock_id IS NOT NULL; same for market_id. INDEX(stock_id, data_mode, timeframe, ts DESC), (market_id, data_mode, timeframe, ts DESC).
- **technical_indicators**: id, stock_id, data_mode, timeframe, ts, sma_20, sma_50, sma_200, ema_20, ema_50, ema_200, rsi_14, macd, macd_signal, macd_histogram, bollinger_upper/middle/lower, atr_14, adx_14, stoch_k, stoch_d, vwap, volume_sma_20, pivots jsonb, created_at. UNIQUE(stock_id, data_mode, timeframe, ts).

### 7.4 Fundamentals

- **fundamental_snapshots**: id, stock_id, data_mode, as_of, source, market_cap, pe, pb, eps_ttm, roe, roce, debt_to_equity, dividend_yield, operating_margin, net_margin, free_cash_flow, revenue_ttm, net_profit_ttm, revenue_growth_yoy, profit_growth_yoy, book_value_per_share, beta, raw jsonb, created_at. UNIQUE(stock_id, data_mode, as_of, source). All metrics nullable.
- **financial_statements**: id, stock_id, data_mode, period_type, period_end date, source, revenue, operating_profit, net_profit, eps, total_debt, total_equity, cash_from_operations, capex, raw jsonb, created_at. UNIQUE(stock_id, data_mode, period_type, period_end, source).

### 7.5 News & RAG

- **news**: id, data_mode, title, description, content, source, source_url, author, published_at, fetched_at, language (default 'en'), content_hash, created_at. UNIQUE(data_mode, content_hash); UNIQUE(data_mode, source_url).
- **news_mentions**: news_id, stock_id?, market_id?, relevance_score numeric(4,3), matched_by text. CHECK exactly one owner. Partial unique per owner.
- **news_ai_analysis**: id, news_id, stock_id?, sentiment, sentiment_score (0–100, 50 = neutral), confidence (0–100), relevance_score, impact_level, summary, positive_factors jsonb, negative_factors jsonb, reasoning jsonb, model, prompt_version, created_at. UNIQUE(news_id, stock_id, prompt_version) (NULLS NOT DISTINCT).
- **document_embeddings**: id, data_mode, source_type (NEWS, FINANCIALS, AI_ANALYSIS, MARKET_SUMMARY), source_id uuid, stock_id?, chunk_index, content, content_hash, embedding vector(1536), embedding_model, metadata jsonb, published_at, created_at. UNIQUE(source_type, source_id, chunk_index, embedding_model). HNSW index (`vector_cosine_ops`).

### 7.6 Evaluation & AI

- **scoring_configs**: id, version text UNIQUE, weights jsonb, thresholds jsonb, is_active, notes, created_at. Exactly one active (partial unique index).
- **stock_evaluations** _(deterministic)_: id, stock_id, data_mode, evaluated_at, data_as_of, scoring_config_version, technical_score, quality_score, valuation_score, news_score, momentum_score, market_context_score, overall_score, risk_score, risk_level, trend, valuation_label, market_regime, action_state, recommendation_bias, entry_low, entry_high, stop_loss, target_1, target_2, risk_reward, position_size_hint, invalidation text, factors_available jsonb, inputs jsonb, input_hash, created_at. UNIQUE(stock_id, data_mode, input_hash).
- **stock_ai_analysis**: id, stock_id, evaluation_id, data_mode, analysis_time, data_as_of, status, sentiment, sentiment_score, confidence, technical_score, fundamental_score, news_score, momentum_score, risk_score, overall_score, trend, risk_level, recommendation, summary, reasoning jsonb, key_positive_factors jsonb, key_negative_factors jsonb, key_risks jsonb, catalysts jsonb, invalidation_conditions jsonb, facts jsonb, interpretation jsonb, insufficient_data jsonb, sources jsonb, input_hash, model, prompt_version, created_at. UNIQUE(stock_id, data_mode, input_hash, prompt_version).
- **market_ai_summary**: id, market_id, data_mode, analysis_time, data_as_of, sentiment, sentiment_score, confidence, trend, regime, risk_level, summary, key_drivers jsonb, key_risks jsonb, sectors_positive jsonb, sectors_negative jsonb, sources jsonb, input_hash, model, prompt_version, created_at. UNIQUE(market_id, data_mode, input_hash, prompt_version).
- **ai_trade_signals**: id, stock_id, analysis_id, evaluation_id, data_mode, signal, confidence, entry_price, entry_low, entry_high, target_price, target_2, stop_loss, risk_reward_ratio, suggested_quantity, reasoning jsonb, valid_until, status, created_at.
- **ai_qa_log**: id, stock_id, data_mode, user_id, question, question_hash, context_hash, answer jsonb, sources jsonb, model, prompt_version, created_at. INDEX(stock_id, question_hash, context_hash).

### 7.7 Paper trading

- **user_profiles**: user_id PK → auth.users, display_name, role, created_at, updated_at.
- **paper_fee_schedules**: id, name, is_active, brokerage_pct, brokerage_max, stt_buy_pct, stt_sell_pct, exchange_txn_pct, sebi_fee_pct, stamp_duty_buy_pct, gst_pct, notes, created_at. Defaults are user-verified; an all-zero schedule is allowed.
- **paper_accounts**: id, user_id, data_mode, initial_balance, available_cash, portfolio_value, realized_pnl, total_pnl, created_at, updated_at. UNIQUE(user_id, data_mode). CHECK available_cash ≥ 0.
- **paper_positions**: id, account_id, stock_id, quantity, average_buy_price, current_price, unrealized_pnl, created_at, updated_at. UNIQUE(account_id, stock_id). CHECK quantity > 0 (a fully exited position is deleted).
- **paper_orders**: id, account_id, stock_id, order_type (trade_side), quantity, requested_price, executed_price, fees, status, reject_reason, order_source, signal_id?, price_as_of, created_at, executed_at. CHECK quantity > 0.
- **paper_trades**: id, account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl, created_at.

### 7.8 Ops & config

- **app_settings**: key PK, value jsonb, updated_at (job intervals, LLM budget, staleness thresholds, auto-paper-trade flag).
- **system_logs**: id, job_run_id uuid, service, job_name, operation, status (job_status), message, records_fetched, records_inserted, records_skipped, records_failed, records_processed, started_at, finished_at, execution_time_ms, error_details jsonb, created_at. INDEX(job_name, created_at DESC).
- **llm_calls**: id, purpose, provider, model, prompt_version, input_tokens, output_tokens, est_cost_inr, latency_ms, cache_hit, status, error, created_at.

### 7.9 Relationships (ERD summary)

```
markets ─< market_data >─ stocks            stocks ─< provider_symbols >─ markets
stocks ─< stock_market_links >─ markets     stocks ─< technical_indicators
stocks ─< fundamental_snapshots, financial_statements
news ─< news_mentions >─ stocks|markets     news ─< news_ai_analysis
document_embeddings → stocks (and polymorphic source_type/source_id)
stocks ─< stock_evaluations ─< stock_ai_analysis ─< ai_trade_signals
markets ─< market_ai_summary                stocks ─< ai_qa_log
auth.users ─ user_profiles ─< paper_accounts ─< paper_positions, paper_orders ─< paper_trades
paper_orders >─ ai_trade_signals (optional)
```

### 7.10 Functions, triggers, views

- `set_updated_at()` trigger on tables with `updated_at`.
- `handle_new_user()` trigger on `auth.users` creates the `user_profiles` row (first user = OWNER) and the MOCK and LIVE `paper_accounts`, using `app_settings.paper_initial_balance`.
- `is_market_open(exchange, ts) → bool` and `next_market_open(exchange, ts) → timestamptz`.
- `match_documents(query_embedding vector, p_stock_id uuid, p_data_mode, p_since timestamptz, p_k int, p_source_types text[]) → table(id, source_type, source_id, content, metadata, published_at, similarity)`. Uses iterative HNSW scan (or over-fetch) so filtered queries still return k rows.
- `execute_paper_order(p_account_id, p_stock_id, p_side, p_qty, p_price, p_fees, p_source, p_signal_id, p_price_as_of) → paper_orders`. Runs in one transaction with `FOR UPDATE` row locks. Insufficient cash, oversell and non-positive quantity produce a REJECTED order with a reason. On success it writes the order, trade, position (weighted-average cost; deleted at qty 0), cash and realised P&L.
- Views: `v_latest_quotes`, `v_latest_stock_evaluation`, `v_latest_stock_ai_analysis` (per `data_mode`).

### 7.11 Duplicate protection

market_data `(owner, data_mode, timeframe, ts, source)` · news `content_hash`, `source_url` · news_ai_analysis `(news, stock, prompt_version)` · embeddings `(source, chunk, model)` · evaluations `(stock, mode, input_hash)` · AI analysis `(stock, mode, input_hash, prompt_version)`.

---

## 8. Analytics engine (deterministic)

### 8.1 Technical indicators (`technical/indicators.ts`)

Computed from stored bars with a vetted library, verified in tests against reference values: SMA 20/50/200, EMA 20/50/200, RSI 14, MACD (12, 26, 9), Bollinger (20, 2), ATR 14, ADX 14, Stochastic (14, 3), VWAP (intraday), volume SMA 20. Insufficient history leaves the indicator `null`, never extrapolated.

### 8.2 Factor scores (`scoring/ScoringEngine.ts`), each 0–100 or null

| Factor         | Default weight | Inputs                                                                                                   |
| -------------- | -------------- | -------------------------------------------------------------------------------------------------------- |
| Technical      | 30             | Trend regime (close vs SMA50/200, SMA200 slope), MACD state, RSI zone, ADX strength, volume confirmation |
| Quality        | 10             | ROE/ROCE, D/E (banks/NBFCs exempt), margin trend, revenue/profit growth consistency                      |
| Valuation      | 10             | P/E, P/B vs own history band and sector median (≥ 4 peers), earnings yield                               |
| News           | 20             | Recency-decayed (half-life configurable), relevance-weighted mean news sentiment                         |
| Momentum       | 15             | 1M/3M/6M returns, relative strength vs NIFTY 50 and sector index                                         |
| Market context | 15             | NIFTY 50 regime, sector-index trend, India VIX level/percentile                                          |

- **Null-aware:** missing factors are dropped, the weights are renormalised, and `factors_available` is recorded. Confidence is scaled by data coverage.
- **Risk score** (separate, 0–100, higher means riskier): ATR %, beta vs NIFTY, 1Y max drawdown, distance to stop, upcoming results (if known). It maps to `risk_level`.
- Weights and thresholds live in `scoring_configs` (versioned). Every evaluation records the version used.

### 8.3 Valuation (`scoring/ValuationEngine.ts`)

- Own-history band: P/E series = daily close ÷ TTM EPS (where EPS history exists). Percentile of the current P/E gives a label: ≤ 30th → UNDERVALUED, 30–70 → FAIR, ≥ 70th → OVERVALUED (thresholds configurable).
- Sector-relative: used only with ≥ 4 peers with data.
- Neither available → `INSUFFICIENT_DATA`. The LLM never estimates fair value.

### 8.4 Levels (`technical/levels.ts`)

Swing pivots (lookback N) clustered within 0.5×ATR form support/resistance zones, plus SMA 50/200 and the 52-week high/low.

- **Entry zone:** nearest support zone [S, S + 0.5×ATR], or the SMA20–SMA50 pullback band in a confirmed uptrend.
- **Stop-loss:** support − k×ATR (k = 1.5 default).
- **Targets:** T1 = next resistance zone, T2 = the one after (or 2R/3R if no resistance above).
- **R:R** = (T1 − entry_mid) ÷ (entry_mid − stop).
- **Position-size hint:** floor(risk_pct × capital ÷ (entry_mid − stop)), risk_pct = 1% by default.

### 8.5 Decision (`scoring/DecisionEngine.ts`)

An ordered rule table (first match wins, thresholds in config):

1. Insufficient bars (< 200 daily) or missing price → `INSUFFICIENT_DATA`.
2. Overall < avoid threshold, or (trend DOWNTREND ∧ regime RISK_OFF ∧ quality weak) → `AVOID`; if a paper position is held → `REDUCE`.
3. Trend DOWNTREND or close < SMA200 (quality/valuation acceptable) → `WAIT_FOR_CONFIRMATION`.
4. Extended: close > SMA50 × (1 + x%) or RSI > 70 or close > entry_high + 1×ATR → `WAIT_FOR_PULLBACK`.
5. Overall ≥ buy threshold ∧ valuation ≠ OVERVALUED ∧ close within the entry zone ∧ regime ≠ RISK_OFF ∧ R:R ≥ 2 → `BUY_ZONE`.
6. Otherwise → `HOLD`.

Mapping to recommendation bias: BUY_ZONE with overall ≥ 80 gives STRONG_BUY_BIAS, otherwise BUY_BIAS. WAIT_* and HOLD give HOLD_BIAS. REDUCE gives SELL_BIAS. AVOID with overall < 25 gives STRONG_SELL_BIAS, otherwise SELL_BIAS.

The paper signal is BUY for BUY_ZONE, SELL for REDUCE/AVOID with an open position, and HOLD otherwise. Every state includes an **invalidation** sentence with a computed price.

---

## 9. AI behavior

### 9.1 Prompts (`backend/prompts/`, versioned files; version stored on every output)

`news_sentiment_v1.txt`, `stock_analysis_v1.txt`, `market_analysis_v1.txt`, `trade_signal_v1.txt`, `stock_qa_v1.txt`.

Shared rules in every prompt:

- Persona: a senior Indian equity research analyst with 25+ years of experience.
- Use **only** the supplied context. If something is missing, say `INSUFFICIENT_DATA` and do not invent prices, results, news, indicators, announcements or targets.
- Separate **FACT** (directly from context, cite source IDs) from **INTERPRETATION** (your reasoning).
- The supplied scores, levels and action state are computed by code: **explain them, never alter them**.
- Always discuss market and sector context, risks, and what would invalidate the thesis.
- Use bias language. Never guarantee.

### 9.2 Stock analysis output schema (zod, Structured Outputs)

```json
{
  "sentiment": "BULLISH|NEUTRAL|BEARISH",
  "sentiment_score": 0,
  "confidence": 0,
  "technical_score": 0,
  "fundamental_score": 0,
  "news_score": 0,
  "momentum_score": 0,
  "risk_score": 0,
  "overall_score": 0,
  "trend": "UPTREND|SIDEWAYS|DOWNTREND",
  "risk_level": "LOW|MEDIUM|HIGH|VERY_HIGH",
  "recommendation": "STRONG_BUY_BIAS|BUY_BIAS|HOLD_BIAS|SELL_BIAS|STRONG_SELL_BIAS",
  "summary": "string",
  "reasoning": ["string"],
  "positive_factors": ["string"],
  "negative_factors": ["string"],
  "key_risks": ["string"],
  "catalysts": ["string"],
  "invalidation_conditions": ["string"],
  "facts": [{ "statement": "string", "source_ids": ["string"] }],
  "interpretation": ["string"],
  "insufficient_data": ["string"]
}
```

**Post-validation:** zod parse (1 repair attempt, then status FAILED) → every cited `source_id` must exist in the context → **all numeric scores, trend, risk_level and recommendation are overwritten from `stock_evaluations`** → banned-phrase check → store.

### 9.3 Other outputs

- **News sentiment:** `{sentiment, sentiment_score(0–100, 50 = neutral), confidence, relevance_score, impact_level, summary, positive_factors[], negative_factors[], reasoning[]}` per (article, stock).
- **Market summary:** `{sentiment, sentiment_score, confidence, trend, regime, risk_level, summary, key_drivers[], key_risks[], sectors_positive[], sectors_negative[]}`. Regime and trend are overwritten from deterministic market context.
- **Trade signal narrative:** reasoning only. Signal, prices and quantity come from the evaluation.
- **Q&A:** `{answer, facts[{statement, source_ids}], interpretation[], insufficient_data[]}`.

### 9.4 Explainability checklist (every analysis answers)

What is the sentiment? · Why? · What data supports it (cited)? · What are the risks? · What invalidates the thesis? · How confident (and why that confidence)? · When was the data collected (`data_as_of`) and when was the analysis generated?

---

## 10. RAG architecture

- **Corpus:** news chunks (title + description + content, ~500 tokens, 50 overlap), financial-results summaries (generated deterministically from `financial_statements`), and prior AI analysis and market summaries.
- **Embedding:** once per `content_hash` × model. Only new or changed content is embedded.
- **Retrieval for stock X:** `match_documents(q, stock_id=X, since=now-180d, k=24)` → re-rank by `similarity × recency_decay × relevance` → MMR → top 8. Market-level docs (stock_id null) are added for context questions.
- **Context builder:** builds structured blocks with stable IDs: `[Q1] quote`, `[P1] performance`, `[T1] technicals`, `[F1] fundamentals`, `[V1] valuation`, `[E1] evaluation/levels`, `[M1] market context`, `[N1..N8] retrieved docs`, `[A1] previous analysis`. Each block has `as_of`. **Numbers are only supplied via structured blocks**, never parsed out of retrieved text.
- **Citation validator:** rejects unknown IDs and flags facts without citations.
- **Q&A cache:** by `(stock, normalized question hash, context_hash)`.

---

## 11. Paper trading

- Starting balance ₹10,00,000 per `data_mode` account. No real money, no broker.
- `PaperTradingService.placeOrder({symbol, side, qty, source, signalId?})`:
  1. Validate that qty is a positive integer and the symbol is active.
  2. Price = latest quote for the active `data_mode`. If older than the staleness threshold, **reject** (`STALE_PRICE`).
  3. If the market is closed, reject by default (`MARKET_CLOSED`). Optional setting: execute at last close, labelled "simulated at last close".
  4. `FeeCalculator` applies the active fee schedule (brokerage capped, STT, exchange, SEBI, stamp duty on buy, GST on brokerage and exchange).
  5. `execute_paper_order(...)` runs atomically. Rejections are stored with `reject_reason` (INSUFFICIENT_FUNDS, INSUFFICIENT_QUANTITY). Invalid input (quantity ≤ 0, price or fees invalid) is not stored: the function raises SQLSTATE 22023 (`INVALID_QUANTITY` / `INVALID_PRICE` / `INVALID_FEES`), and `PaperTradingService` validates before calling it.
- Long-only in v1 (no shorting). Realised P&L = (sell price − avg cost) × qty − fees.
- `PortfolioService`: marks to market, unrealised/realised/total P&L, return % and benchmark comparison vs NIFTY 50 since account creation.
- **AI signals never execute automatically.** `AUTO_PAPER_TRADE=false` by default. Even when enabled, it applies only to paper trading.

---

## 12. API specification (backend, prefix `/api`)

Response envelope: `{ data, meta: { data_mode, generated_at, freshness } }`. Errors: `{ error: { code, message, details? } }`.

### Public-to-authenticated reads (JWT required; rate limit 120/min)

| Method | Path                                             | Returns                                                                                                                                                           |
| ------ | ------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET    | `/markets`                                       | Indices with latest quote + status                                                                                                                                |
| GET    | `/market-summary`                                | Latest market AI summary + regime                                                                                                                                 |
| GET    | `/market-status`                                 | Open/closed/holiday + next open (IST)                                                                                                                             |
| GET    | `/stocks?query=&sector=&action=`                 | Stock list with latest scores                                                                                                                                     |
| GET    | `/stocks/:symbol`                                | **Aggregate:** `{stock, quote, performance, technical, fundamental, valuation, decision, news[], sentiment, ai_analysis, signal, market_context, data_freshness}` |
| GET    | `/stocks/:symbol/quote`                          | Latest quote                                                                                                                                                      |
| GET    | `/stocks/:symbol/history?range=1D..5Y&interval=` | Bars + overlay series                                                                                                                                             |
| GET    | `/stocks/:symbol/technical`                      | Latest indicators + interpretations + technical score                                                                                                             |
| GET    | `/stocks/:symbol/fundamentals`                   | Snapshot + statements (nulls as unavailable)                                                                                                                      |
| GET    | `/stocks/:symbol/evaluation`                     | Deterministic scores, levels, action state                                                                                                                        |
| GET    | `/stocks/:symbol/news`                           | Articles + per-stock AI sentiment                                                                                                                                 |
| GET    | `/stocks/:symbol/sentiment`                      | Aggregated news sentiment                                                                                                                                         |
| GET    | `/stocks/:symbol/analysis`                       | Latest AI analysis                                                                                                                                                |
| GET    | `/stocks/:symbol/ai-summary`                     | Compact AI view for cards                                                                                                                                         |
| GET    | `/portfolio`                                     | Account, positions, P&L                                                                                                                                           |
| GET    | `/paper-trade/orders`, `/paper-trade/trades`     | History                                                                                                                                                           |
| GET    | `/system-status`                                 | Providers, DB status, last syncs, last AI run, failed jobs, market status, LLM budget                                                                             |

### Actions (JWT; admin-only marked †; strict limits)

| Method | Path                   | Body                                              | Limit   |
| ------ | ---------------------- | ------------------------------------------------- | ------- |
| POST   | `/sync/market` †       | `{symbols?, interval?}`                           | 6/hour  |
| POST   | `/sync/news` †         | `{symbols?}`                                      | 6/hour  |
| POST   | `/sync/fundamentals` † | `{symbols?}`                                      | 4/day   |
| POST   | `/jobs/:name/run` †    | `{}`                                              | 10/hour |
| POST   | `/ai/analyze` †        | `{symbol}` (returns cached if input unchanged)    | 20/hour |
| POST   | `/ai/regenerate` †     | `{symbol}` (bypasses hash cache; budget enforced) | 5/hour  |
| POST   | `/stocks/:symbol/qa`   | `{question}` (≤ 500 chars)                        | 30/hour |
| POST   | `/paper-trade/order`   | `{symbol, side, quantity, signal_id?}`            | 60/hour |
| POST   | `/paper-trade/close`   | `{symbol}` (sell the full position)               | 60/hour |

Sync endpoints **enqueue** pg-boss jobs (deduplicated by singleton key) and return `202 {job_id}`. Results appear in `/system-status`.

---

## 13. Jobs (pg-boss worker, timezone Asia/Kolkata)

| Job                    | Schedule                            | Gate                                     | Then                                                         |
| ---------------------- | ----------------------------------- | ---------------------------------------- | ------------------------------------------------------------ |
| `market.sync.intraday` | every 5 min, 09:15–15:30            | `isOpen()`                               | `technical.compute` → `evaluation.compute`                   |
| `market.sync.eod`      | 16:00                               | trading day                              | daily bars for stocks, indices, VIX → technical → evaluation |
| `fundamentals.sync`    | 18:00 daily                         | —                                        | evaluation                                                   |
| `news.sync`            | every 10 min                        | —                                        | `embeddings.generate` → `news.sentiment` (new only)          |
| `ai.stock.analyze`     | every 30 min in session + after EOD | input_hash changed, min interval, budget | `signals.generate`                                           |
| `ai.market.summary`    | every 30 min in session             | input_hash changed                       | —                                                            |
| `ai.daily.summary`     | 16:15                               | trading day                              | —                                                            |
| `signals.expire`       | every 15 min                        | —                                        | —                                                            |
| `holidays.check`       | weekly                              | —                                        | warns if the next year's holidays are missing                |

Intervals are configurable in `app_settings`. Each run writes `system_logs` with job name, start/end, duration, fetched/inserted/skipped/failed counts, status and error. Singleton keys prevent overlap. Manual triggers reuse the same jobs.

---

## 14. Caching & cost control

- In-memory LRU (`Cache` interface; swappable for Redis later). TTLs: quotes 30 s, aggregates 60 s, market summary and analysis until a newer row exists (invalidated on job completion).
- **LLM is never called** on page load, refresh, chart change, price tick, or for duplicate news or identical inputs.
- Gates: `input_hash`, minimum re-analysis interval, relevance threshold for news sentiment, **daily ₹ budget** (`LLM_DAILY_BUDGET_INR`). Once exhausted, cached results are served and system status shows `LLM_BUDGET_EXHAUSTED`.
- `llm_calls` records tokens and estimated cost per call. The admin page shows spend.

---

## 15. Security

- Secrets live only in backend env. The frontend gets only `NEXT_PUBLIC_API_BASE_URL`, `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`. CI checks the built bundle for secret patterns.
- Supabase Auth for login. The backend verifies the JWT (JWKS / project secret) and loads the role from `user_profiles`. Admin routes need OWNER/ADMIN.
- RLS on all tables. With no anon policies, the browser cannot read tables directly. Service-role access is backend-only.
- Input validation with zod on every route. Symbol whitelist via DB lookup. Parameterised SQL only (Kysely).
- `@fastify/rate-limit` per user and IP, plus per-route limits (§12). CORS restricted to the frontend origin. Helmet headers.
- Prompt-injection hygiene: retrieved text is wrapped as data with an instruction not to follow it. Outputs are schema-validated.
- `.env` is never committed. `.env.example` documents every variable.

---

## 16. Observability

- pino JSON logs with `job_run_id` / `request_id` correlation.
- `GET /api/system-status`: `market_data_provider, news_provider, fundamentals_provider, llm_provider, data_mode, database_status, last_market_sync, last_news_sync, last_ai_analysis, last_successful_job, failed_jobs[], market_status, llm_budget`.

---

## 17. Testing strategy

- **TDD** in every phase (Vitest). Unit tests for MarketCalendarService, indicators (reference values), LevelsService, ScoringEngine, ValuationEngine, DecisionEngine, FeeCalculator, PaperTradingService, PortfolioService, RAG context builder and citation validator, AI output validators, retry/backoff, providers (recorded fixtures), NewsService dedupe.
- **Integration** (local Supabase): repositories, `execute_paper_order`, `match_documents`, full mock pipeline (sync → indicators → evaluation → embeddings → mock AI → signal → paper order).
- **DB** (pgTAP): schema, constraints, functions, RLS.
- **API** (Fastify `inject`): auth, validation, rate limits, envelopes.
- **E2E** (Playwright, mock mode): success criteria 1–25.
- **Required edge cases:** missing market data, missing news, AI unavailable, provider unavailable, duplicate news, duplicate market data, invalid stock, market closed, market holiday, insufficient paper balance, overselling, invalid quantity, stale price, LLM invalid JSON, budget exhausted, provider auth failure (no retry loop).

---

## 18. Deployment

- **DB:** Supabase cloud project. `supabase link` + `supabase db push` applies the same migrations, then seed the reference data.
- **Backend API + worker:** two processes from one image (`node dist/server.js`, `node dist/worker.js`) on a container host (Render, Fly.io or Railway). The worker must be a single instance (pg-boss handles locking regardless).
- **Frontend:** Vercel (or the same host). Env limited to `NEXT_PUBLIC_*`.
- Details in `docs/deployment.md`.

---

## 19. Risks & limitations

| Risk                                                     | Mitigation                                                                           |
| -------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| Yahoo is unofficial (ToS, breakage, delays, symbol gaps) | Adapter isolation, `capabilities()`, freshness badges, broker-API adapter later      |
| Partial Indian fundamentals coverage (ROCE, history)     | Null-aware scoring, lower confidence, "unavailable" UI                               |
| News licensing and quality; RSS often lacks full text    | Personal use. Analyse title + description when that's all there is                   |
| LLM hallucination                                        | Deterministic overwrite, citation validation, INSUFFICIENT_DATA, banned-phrase guard |
| Regulatory (SEBI RA rules)                               | Personal-use scope, persistent disclaimer, no public distribution                    |
| Holiday calendar drift                                   | Yearly load + `holidays.check` warning                                               |
| Corporate actions distort indicators                     | Adjusted close; full recompute on history refresh                                    |
| LLM cost                                                 | Hash gating, budget cap, `llm_calls` visibility                                      |
| Small seed universe weakens sector-relative valuation    | ≥ 4 peer rule; own-history fallback                                                  |

---

## 20. Success criteria

1. Dashboard opens. 2. NIFTY 50 and SENSEX visible. 3. Search finds RELIANCE. 4. RELIANCE page opens. 5. Current or last price shown with freshness. 6. Historical chart. 7. Technical indicators. 8. Relevant news. 9. News has AI sentiment. 10. RAG retrieves relevant info with sources. 11. Structured AI analysis. 12. AI explains its reasoning. 13. Confidence shown. 14. Risk shown. 15. Market context included. 16. Jobs auto-refresh data. 17. Manual refresh works. 18. Paper BUY works. 19. Paper SELL works. 20. Portfolio P&L works. 21. System logs work. 22. Mock mode works. 23. Providers switch by config only. 24. No secrets in the frontend bundle. 25. Tests pass. **Plus:** 26. Each stock shows an action state, entry zone, stop, targets, valuation label and invalidation, all deterministically computed and explained by AI.
