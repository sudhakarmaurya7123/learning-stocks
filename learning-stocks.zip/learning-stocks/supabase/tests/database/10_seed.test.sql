begin;
create extension if not exists pgtap with schema extensions;
select plan(11);

select is((select count(*)::int from public.stocks where exchange = 'NSE' and is_active), 20, '20 seeded NSE stocks');
select is((select count(*)::int from public.markets where is_active), 12, '12 seeded markets incl. VIX');
select is((select count(*)::int from public.markets where market_type = 'VOLATILITY'), 1, 'India VIX present');
select is((select count(*)::int from public.provider_symbols where provider = 'mock'), 32, 'mock mapping for every instrument');
select is((select count(*)::int from public.provider_symbols where provider = 'yahoo'), 32, 'yahoo mapping for every instrument');
select is((select count(*)::int from public.stocks s where not exists (
            select 1 from public.stock_market_links l join public.markets m on m.id = l.market_id
             where l.stock_id = s.id and l.link_type = 'BENCHMARK' and m.symbol = 'NIFTY50')),
  0, 'every stock benchmarked to NIFTY 50');
select ok((select count(*) from public.exchange_holidays where exchange = 'NSE' and extract(year from holiday_date) = 2026) >= 1,
  '2026 NSE holidays loaded');
select is((select count(*)::int from public.scoring_configs where is_active), 1, 'one active scoring config');
select is((select (weights->>'technical')::int + (weights->>'quality')::int + (weights->>'valuation')::int
                + (weights->>'news')::int + (weights->>'momentum')::int + (weights->>'market_context')::int
             from public.scoring_configs where is_active), 100, 'active weights sum to 100');
select is((select (value #>> '{}')::numeric from public.app_settings where key = 'paper_initial_balance'), 1000000::numeric, 'paper balance setting');
select is((select name from public.paper_fee_schedules where is_active), 'zero', 'zero-fee schedule active until owner verifies charges');

select * from finish();
rollback;
