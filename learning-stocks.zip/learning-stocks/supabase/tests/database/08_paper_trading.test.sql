begin;
create extension if not exists pgtap with schema extensions;
select plan(21);

create temp table expected as
  select case when exists (select 1 from public.user_profiles where role = 'OWNER') then 'VIEWER' else 'OWNER' end as first_role;

insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-0000000000a1', 'paper-a@test.local'),
  ('00000000-0000-0000-0000-0000000000a2', 'paper-b@test.local');
insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');

create temp table t as select
  (select id from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000a1' and data_mode = 'MOCK') as acc,
  (select id from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000a2' and data_mode = 'LIVE') as acc2,
  (select id from public.stocks where symbol = 'TESTA') as stock;

-- new-user trigger
select is((select role::text from public.user_profiles where user_id = '00000000-0000-0000-0000-0000000000a1'),
          (select first_role from expected), 'first user becomes OWNER (if none exists)');
select is((select role::text from public.user_profiles where user_id = '00000000-0000-0000-0000-0000000000a2'),
          'VIEWER', 'later users become VIEWER');
select is((select count(*)::int from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000a1'),
          2, 'one MOCK and one LIVE paper account');
select is((select available_cash from public.paper_accounts where id = (select acc from t)),
          1000000.0000::numeric, 'starting cash ₹10,00,000');

-- validation
select throws_ok($$select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 0, 100)$$,
  '22023', 'INVALID_QUANTITY', 'qty 0 rejected');
select throws_ok($$select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 1, 0)$$,
  '22023', 'INVALID_PRICE', 'price 0 rejected');

-- buy 10 @ 100 + 5 fees -> avg 100.5, cash 998995
select is((public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 10, 100, 5)).status::text,
  'EXECUTED', 'buy executes');
select is((select average_buy_price from public.paper_positions where account_id = (select acc from t)),
  100.5000::numeric, 'avg cost includes buy fees');
select is((select available_cash from public.paper_accounts where id = (select acc from t)),
  998995.0000::numeric, 'cash debited price*qty + fees');

-- buy 10 @ 110 + 5 -> avg (1005 + 1105)/20 = 105.5
select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 10, 110, 5);
select is((select average_buy_price from public.paper_positions where account_id = (select acc from t)),
  105.5000::numeric, 'weighted average cost');
select is((select quantity from public.paper_positions where account_id = (select acc from t)), 20, 'qty 20');

-- oversell rejected, nothing changes
select is((public.execute_paper_order((select acc from t), (select stock from t), 'SELL', 21, 120)).reject_reason,
  'INSUFFICIENT_QUANTITY', 'cannot sell more than held');
select is((select quantity from public.paper_positions where account_id = (select acc from t)), 20, 'qty unchanged after reject');

-- sell 5 @ 120 - 3 fees -> realised (120-105.5)*5 - 3 = 69.5
-- Call the volatile function exactly once in FROM; inside a WHERE it would run once per scanned row.
create temp table sell1 as
  select * from public.execute_paper_order((select acc from t), (select stock from t), 'SELL', 5, 120, 3);
select is((select realized_pnl from public.paper_trades where order_id = (select id from sell1)),
  69.5000::numeric, 'realised P&L on partial sell');

-- sell remaining 15 @ 100 -> realised -82.5; position deleted; account realised -13; cash 999987
select public.execute_paper_order((select acc from t), (select stock from t), 'SELL', 15, 100, 0);
select is((select count(*)::int from public.paper_positions where account_id = (select acc from t)), 0, 'full exit deletes position');
select is((select realized_pnl from public.paper_accounts where id = (select acc from t)), -13.0000::numeric, 'account realised P&L');
select is((select available_cash from public.paper_accounts where id = (select acc from t)), 999987.0000::numeric, 'cash reconciles');

-- re-entry starts a fresh average
select public.execute_paper_order((select acc from t), (select stock from t), 'BUY', 1, 200, 0);
select is((select average_buy_price from public.paper_positions where account_id = (select acc from t)),
  200.0000::numeric, 're-entry has fresh average cost');

-- cash boundary on the second account: cost + fees == cash executes; one paisa more is rejected
select is((public.execute_paper_order((select acc2 from t), (select stock from t), 'BUY', 1, 1000000.01, 0)).reject_reason,
  'INSUFFICIENT_FUNDS', 'one paisa over cash rejected');
select is((public.execute_paper_order((select acc2 from t), (select stock from t), 'BUY', 1, 999990, 10)).status::text,
  'EXECUTED', 'exact cash executes');
select is((select available_cash from public.paper_accounts where id = (select acc2 from t)), 0.0000::numeric, 'cash exactly zero');

select * from finish();
rollback;
