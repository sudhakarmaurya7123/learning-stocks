begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

select has_view('public', 'v_latest_quotes', 'latest quotes view');
select has_view('public', 'v_latest_stock_evaluation', 'latest evaluation view');
select has_view('public', 'v_latest_stock_ai_analysis', 'latest AI analysis view');

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity),
  0, 'RLS enabled on every public table');

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');
insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
select id, 'MOCK', '1d', ts, 100, 101, 99, c, 10, 'mock' from public.stocks,
  (values ('2026-10-01 15:30+05:30'::timestamptz, 100), ('2026-10-02 15:30+05:30', 101)) v(ts, c)
where symbol = 'TESTA';
select is((select price::numeric from public.v_latest_quotes q join public.stocks s on s.id = q.stock_id
            where s.symbol = 'TESTA' and q.data_mode = 'MOCK'), 101.0000::numeric, 'latest quote is newest bar');

set local role anon;
select throws_ok($$select count(*) from public.stocks$$, '42501', null, 'anon cannot read tables');
select throws_ok($$select count(*) from public.v_latest_quotes$$, '42501', null, 'anon cannot read views');
reset role;

set local role authenticated;
select throws_ok($$select public.execute_paper_order(gen_random_uuid(), gen_random_uuid(), 'BUY', 1, 1)$$,
  '42501', null, 'browser roles cannot execute paper orders directly');
reset role;

select * from finish();
rollback;
