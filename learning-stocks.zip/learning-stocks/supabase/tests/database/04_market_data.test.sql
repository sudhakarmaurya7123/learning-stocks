begin;
create extension if not exists pgtap with schema extensions;
select plan(9);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');
insert into public.markets (symbol, name, exchange, market_type) values ('TESTIDX', 'Test Index', 'NSE', 'BROAD_INDEX');
create temp table ids as
  select (select id from public.stocks where symbol = 'TESTA') as stock_id,
         (select id from public.markets where symbol = 'TESTIDX') as market_id;

select lives_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 100, 105, 99, 104, 1000, 'mock' from ids$$, 'valid bar inserts');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 100, 105, 99, 104, 1000, 'mock' from ids$$,
  '23505', null, 'duplicate (stock, mode, timeframe, ts, source) rejected');
select lives_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'LIVE', '1d', '2026-10-05 10:00+05:30', 100, 105, 99, 104, 1000, 'yahoo' from ids$$, 'same ts in LIVE mode allowed');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 100, 98, 99, 99, 1000, 'mock' from ids$$,
  '23514', null, 'high < low rejected');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 106, 105, 99, 104, 1000, 'mock' from ids$$,
  '23514', null, 'open above high rejected');
select throws_ok($$insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 100, 105, 99, 104, -1, 'mock' from ids$$,
  '23514', null, 'negative volume rejected');
select throws_ok($$insert into public.market_data (stock_id, market_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
  select stock_id, market_id, 'MOCK', '1d', '2026-10-06 10:00+05:30', 100, 105, 99, 104, 1, 'mock' from ids$$,
  '23514', null, 'bar with two owners rejected');

insert into public.technical_indicators (stock_id, data_mode, timeframe, ts, rsi_14)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 61 from ids;
select throws_ok($$insert into public.technical_indicators (stock_id, data_mode, timeframe, ts, rsi_14)
  select stock_id, 'MOCK', '1d', '2026-10-05 10:00+05:30', 62 from ids$$,
  '23505', null, 'duplicate indicator row rejected');
select throws_ok($$insert into public.technical_indicators (stock_id, data_mode, timeframe, ts, rsi_14)
  select stock_id, 'MOCK', '1d', '2026-10-07 10:00+05:30', 101 from ids$$,
  '23514', null, 'RSI > 100 rejected');

select * from finish();
rollback;
