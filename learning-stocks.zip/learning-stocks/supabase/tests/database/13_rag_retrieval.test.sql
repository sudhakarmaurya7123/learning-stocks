begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE'), ('TESTB', 'Test B Ltd', 'NSE');

create function pg_temp.vec(a float8, b float8) returns extensions.vector
language sql immutable as $$
  select ((array[a, b] || array_fill(0::float8, array[1534]))::float8[])::extensions.vector(1536)
$$;

-- One article, two stocks, one null (market-level) row: all allowed.
create temp table art as select gen_random_uuid() as id;
select lives_ok($$
  insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
  select 'MOCK'::public.data_mode, 'NEWS', (select id from art), s.id, 'shared text', md5('shared text'), pg_temp.vec(1, 0), 'm1', '2026-10-01'::timestamptz
    from public.stocks s where s.symbol in ('TESTA', 'TESTB')
  union all
  select 'MOCK'::public.data_mode, 'NEWS', (select id from art), null, 'shared text', md5('shared text'), pg_temp.vec(1, 0), 'm1', '2026-10-01'::timestamptz
$$, 'the same chunk may be stored once per stock and once market-level');

select throws_ok($$
  insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model)
  select 'MOCK', 'NEWS', (select id from art), null, 'x', md5('x'), pg_temp.vec(1, 0), 'm1'
$$, '23505', null, 'a second market-level row for the same chunk is rejected (nulls not distinct)');

-- Same content under another model.
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'other model', md5('other model'), pg_temp.vec(1, 0), 'm2', '2026-10-01'
  from public.stocks s where s.symbol = 'TESTA';

select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol = 'TESTA'), null, 10, null, 'm1')),
  1, 'p_embedding_model keeps only that model''s vectors');
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol = 'TESTA'), null, 10)),
  2, 'without a model filter both models match (old positional call still works)');
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', null, null, 10, null, 'm1', true)),
  1, 'p_market_only returns only stock_id IS NULL rows');
select is(
  (select bool_and(stock_id is null) from public.match_documents(pg_temp.vec(1, 0), 'MOCK', null, null, 10, null, null, true)),
  true, 'market-only rows have no stock');
select throws_ok(
  $$select * from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol = 'TESTA'), null, 10, null, null, true)$$,
  '22023', null, 'stock filter and market-only are mutually exclusive');

set local role anon;
select throws_ok(
  $$select * from public.match_documents(array_fill(0.1::float8, array[1536])::extensions.vector, 'MOCK')$$,
  '42501', null, 'browser roles cannot run vector search');
reset role;

select * from finish();
rollback;
