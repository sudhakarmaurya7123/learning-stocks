begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

select has_table('public', t, 'table ' || t)
  from unnest(array['app_settings','scoring_configs','system_logs','llm_calls']) t;

update public.scoring_configs set is_active = false;
insert into public.scoring_configs (version, weights, thresholds, is_active) values ('test-a', '{}', '{}', true);
select throws_ok($$insert into public.scoring_configs (version, weights, thresholds, is_active) values ('test-b', '{}', '{}', true)$$,
  '23505', null, 'only one active scoring config');

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');
insert into public.stock_evaluations (stock_id, data_mode, data_as_of, scoring_config_version, overall_score, action_state, input_hash)
select id, 'MOCK', now(), 'test-a', 72, 'BUY_ZONE', 'h1' from public.stocks where symbol = 'TESTA';

insert into public.stock_ai_analysis (stock_id, evaluation_id, data_mode, data_as_of, status, summary, input_hash, model, prompt_version)
select e.stock_id, e.id, 'MOCK', now(), 'OK', 's', 'h1', 'mock', 'stock_analysis_v1' from public.stock_evaluations e where input_hash = 'h1';
select throws_ok($$insert into public.stock_ai_analysis (stock_id, evaluation_id, data_mode, data_as_of, status, summary, input_hash, model, prompt_version)
  select e.stock_id, e.id, 'MOCK', now(), 'OK', 's', 'h1', 'mock', 'stock_analysis_v1' from public.stock_evaluations e where input_hash = 'h1'$$,
  '23505', null, 'identical input hash + prompt is not re-analysed (LLM cost guard)');

select throws_ok($$insert into public.stock_evaluations (stock_id, data_mode, data_as_of, scoring_config_version, overall_score, action_state, input_hash)
  select id, 'MOCK', now(), 'test-a', 120, 'HOLD', 'h2' from public.stocks where symbol = 'TESTA'$$,
  '23514', null, 'overall_score > 100 rejected');
select throws_ok($$insert into public.stock_evaluations (stock_id, data_mode, data_as_of, scoring_config_version, action_state, input_hash, entry_low, entry_high)
  select id, 'MOCK', now(), 'test-a', 'HOLD', 'h3', 110, 100 from public.stocks where symbol = 'TESTA'$$,
  '23514', null, 'entry_low > entry_high rejected');

select * from finish();
rollback;
