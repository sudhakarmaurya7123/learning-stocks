begin;
create extension if not exists pgtap with schema extensions;
select plan(10);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE'), ('TESTB', 'Test B Ltd', 'NSE');

-- 1536-d test vector with only the first two components set.
create function pg_temp.vec(a float8, b float8) returns extensions.vector
language sql immutable as $$
  select ((array[a, b] || array_fill(0::float8, array[1534]))::float8[])::extensions.vector(1536)
$$;

-- News dedupe ----------------------------------------------------------------
insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
values ('MOCK', 'A wins order', 'mock', 'https://example.test/a', '2026-10-05 08:00+05:30', repeat('a', 64));
select throws_ok($$insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
  values ('MOCK', 'A wins order (syndicated)', 'mock2', 'https://example.test/a-copy', now(), repeat('a', 64))$$,
  '23505', null, 'duplicate content_hash rejected');
select throws_ok($$insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
  values ('MOCK', 'Other', 'mock', 'https://example.test/a', now(), repeat('b', 64))$$,
  '23505', null, 'duplicate source_url rejected');
select throws_ok($$insert into public.news (data_mode, title, source, source_url, published_at, content_hash)
  values ('MOCK', 'Bad hash', 'mock', 'https://example.test/c', now(), 'not-a-sha256')$$,
  '23514', null, 'content_hash must be sha256 hex');

-- news_ai_analysis dedupe incl. market-level (stock_id null) -------------------
insert into public.news_ai_analysis (news_id, stock_id, sentiment, sentiment_score, confidence, relevance_score, impact_level, summary, model, prompt_version)
select id, null, 'NEUTRAL', 50, 60, 0.5, 'LOW', 's', 'mock', 'news_sentiment_v1' from public.news where source_url = 'https://example.test/a';
select throws_ok($$insert into public.news_ai_analysis (news_id, stock_id, sentiment, sentiment_score, confidence, relevance_score, impact_level, summary, model, prompt_version)
  select id, null, 'NEUTRAL', 50, 60, 0.5, 'LOW', 's', 'mock', 'news_sentiment_v1' from public.news where source_url = 'https://example.test/a'$$,
  '23505', null, 'same (news, null stock, prompt_version) analysed only once');

-- Embeddings + match_documents ------------------------------------------------
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, v.content, md5(v.content), pg_temp.vec(1, v.b), 'test', '2026-10-01'
from public.stocks s, (values ('a-near', 0.1), ('a-mid', 0.5), ('a-far', 2.0)) v(content, b)
where s.symbol = 'TESTA';

select is(
  (select content from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), null, 3) limit 1),
  'a-near', 'nearest document first');

-- 50 closer docs for TESTB must not starve a TESTA-filtered query.
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'b-' || g, md5('b-' || g), pg_temp.vec(1, 0), 'test', '2026-10-01'
from public.stocks s, generate_series(1, 50) g where s.symbol = 'TESTB';
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'a-extra-' || g, md5('a-extra-' || g), pg_temp.vec(1, 1), 'test', '2026-10-01'
from public.stocks s, generate_series(1, 10) g where s.symbol = 'TESTA';

set local enable_seqscan = off; set local enable_sort = off;  -- force the HNSW index path so post-filtering is exercised
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), null, 5)),
  5, 'stock filter still returns k rows');
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), null, 5) m
    where m.stock_id <> (select id from public.stocks where symbol='TESTA')),
  0, 'stock filter returns only that stock');

insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'LIVE', 'NEWS', gen_random_uuid(), id, 'a-live', md5('a-live'), pg_temp.vec(1, 0), 'test', '2026-10-01' from public.stocks where symbol = 'TESTA';
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', null, null, 100) where content = 'a-live'),
  0, 'MOCK search never returns LIVE documents');

select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol='TESTA'), '2026-10-02', 5)),
  0, 'since filter excludes older docs');

select throws_ok($$insert into public.document_embeddings (data_mode, source_type, source_id, content, content_hash, embedding, embedding_model)
  values ('MOCK', 'TWEET', gen_random_uuid(), 'x', 'x', pg_temp.vec(1,0), 'test')$$,
  '23514', null, 'unknown source_type rejected');

select * from finish();
rollback;
