begin;
create extension if not exists pgtap with schema extensions;
select plan(4);

insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE');

select lives_ok($$insert into public.fundamental_snapshots (stock_id, data_mode, as_of, source, pe)
  select id, 'MOCK', '2026-10-05', 'mock', 24.5 from public.stocks where symbol='TESTA'$$,
  'snapshot with only P/E (all else unavailable) inserts');
select throws_ok($$insert into public.fundamental_snapshots (stock_id, data_mode, as_of, source)
  select id, 'MOCK', '2026-10-05', 'mock' from public.stocks where symbol='TESTA'$$,
  '23505', null, 'duplicate snapshot per day/source rejected');
select lives_ok($$insert into public.financial_statements (stock_id, data_mode, period_type, period_end, source, revenue, net_profit)
  select id, 'MOCK', 'QUARTERLY', '2026-06-30', 'mock', 1000, 120 from public.stocks where symbol='TESTA'$$,
  'quarterly statement inserts');
select throws_ok($$insert into public.financial_statements (stock_id, data_mode, period_type, period_end, source)
  select id, 'MOCK', 'QUARTERLY', '2026-06-30', 'mock' from public.stocks where symbol='TESTA'$$,
  '23505', null, 'duplicate statement period rejected');

select * from finish();
rollback;
