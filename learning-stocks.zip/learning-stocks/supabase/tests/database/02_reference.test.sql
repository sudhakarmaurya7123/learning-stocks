begin;
create extension if not exists pgtap with schema extensions;
select plan(12);

select has_table('public', t, 'table ' || t) from unnest(array['markets','stocks','provider_symbols','stock_market_links','exchange_holidays']) t;

insert into public.stocks (symbol, company_name, exchange, sector) values ('TESTA', 'Test A Ltd', 'NSE', 'Testing');
insert into public.markets (symbol, name, exchange, market_type) values ('TESTIDX', 'Test Index', 'NSE', 'BROAD_INDEX');

select throws_ok($$insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Dup', 'NSE')$$,
  '23505', null, 'stock symbol unique per exchange');
select lives_ok($$insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Same co on BSE', 'BSE')$$,
  'same symbol allowed on another exchange');
select throws_ok($$insert into public.stocks (symbol, company_name, exchange, isin) values ('TESTB', 'Bad', 'NSE', 'US0378331005')$$,
  '23514', null, 'non-Indian ISIN rejected');
select throws_ok($$insert into public.stocks (symbol, company_name, exchange) values ('bad sym', 'Bad', 'NSE')$$,
  '23514', null, 'lowercase/space symbol rejected');

select throws_ok($$insert into public.provider_symbols (provider, stock_id, market_id, provider_symbol)
  values ('yahoo', (select id from public.stocks where symbol='TESTA' and exchange='NSE'),
                   (select id from public.markets where symbol='TESTIDX'), 'X')$$,
  '23514', null, 'provider symbol must have exactly one owner');
select throws_ok($$insert into public.provider_symbols (provider, provider_symbol) values ('yahoo', 'X')$$,
  '23514', null, 'provider symbol with no owner rejected');

select throws_ok($$insert into public.exchange_holidays (exchange, holiday_date, description, special_open)
  values ('NSE', '2026-12-31', 'half-specified special session', '18:00')$$,
  '23514', null, 'special session needs both open and close');

select * from finish();
rollback;
