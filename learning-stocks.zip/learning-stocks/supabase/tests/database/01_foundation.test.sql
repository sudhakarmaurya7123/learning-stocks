begin;
create extension if not exists pgtap with schema extensions;
select plan(8);

select has_extension('vector', 'pgvector installed');
select has_extension('pg_trgm', 'pg_trgm installed');
select ok(
  string_to_array((select extversion from pg_extension where extname = 'vector'), '.')::int[] >= array[0,8,0],
  'pgvector >= 0.8.0 (needed for hnsw.iterative_scan)'
);
select has_enum('public', 'data_mode', 'data_mode enum exists');
select enum_has_labels('public', 'action_state',
  array['BUY_ZONE','WAIT_FOR_PULLBACK','WAIT_FOR_CONFIRMATION','HOLD','REDUCE','AVOID','INSUFFICIENT_DATA']);
select enum_has_labels('public', 'recommendation_bias',
  array['STRONG_BUY_BIAS','BUY_BIAS','HOLD_BIAS','SELL_BIAS','STRONG_SELL_BIAS']);
select throws_ok($$select 100.01::public.score$$, '23514', null, 'score domain rejects > 100');
select throws_ok($$select 0::public.price$$, '23514', null, 'price domain rejects 0');

select * from finish();
rollback;
