-- Regression tests from the Phase 1 final review.
begin;
create extension if not exists pgtap with schema extensions;
select plan(7);

-- 1. Functions created later must not be executable by browser roles. ---------------
create function public.zz_probe_fn() returns int language sql as 'select 1';
select ok(not has_function_privilege('anon', 'public.zz_probe_fn()', 'execute'),
  'anon cannot execute functions created after the lockdown');
select ok(not has_function_privilege('authenticated', 'public.zz_probe_fn()', 'execute'),
  'authenticated cannot execute functions created after the lockdown');

-- 2. v_latest_quotes must not scan every bar to answer one instrument. ----------------
insert into public.stocks (symbol, company_name, exchange) values ('TESTA', 'Test A Ltd', 'NSE'), ('TESTB', 'Test B Ltd', 'NSE');
insert into public.market_data (stock_id, data_mode, timeframe, ts, open, high, low, close, volume, source)
select s.id, 'MOCK', '1m', timestamptz '2026-10-05 09:15+05:30' + g * interval '1 minute', 100, 101, 99, 100, 1, 'mock'
  from public.stocks s, generate_series(1, 1000) g where s.symbol in ('TESTA', 'TESTB');
analyze public.market_data;

create function pg_temp.market_data_rows_read(q text) returns numeric language plpgsql as $$
declare plan jsonb; begin
  execute 'explain (analyze, format json) ' || q into plan;
  return (select coalesce(max((n->>'Actual Rows')::numeric * coalesce((n->>'Actual Loops')::numeric, 1)), 0)
            from jsonb_path_query(plan, 'strict $.**') n
           where jsonb_typeof(n) = 'object' and n->>'Relation Name' = 'market_data');
end $$;
select ok(pg_temp.market_data_rows_read(
  $q$select * from public.v_latest_quotes where data_mode = 'MOCK' and stock_id = (select id from public.stocks where symbol = 'TESTA')$q$) <= 2,
  'latest quote for one stock reads at most a couple of bars, not the whole table');

-- 3. A stock-filtered vector search returns k rows even when many closer docs belong to other stocks.
create function pg_temp.vec(a float8, b float8) returns extensions.vector
language sql immutable as $$
  select ((array[a, b] || array_fill(0::float8, array[1534]))::float8[])::extensions.vector(1536)
$$;
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'b-' || g, md5('b-' || g), pg_temp.vec(1, g / 10000.0), 'test', '2026-10-01'
  from public.stocks s, generate_series(1, 300) g where s.symbol = 'TESTB';
insert into public.document_embeddings (data_mode, source_type, source_id, stock_id, content, content_hash, embedding, embedding_model, published_at)
select 'MOCK', 'NEWS', gen_random_uuid(), s.id, 'a-' || g, md5('a-' || g), pg_temp.vec(1, 5 + g), 'test', '2026-10-01'
  from public.stocks s, generate_series(1, 30) g where s.symbol = 'TESTA';
-- Shrink the HNSW scan budget so the scale problem shows up with a small corpus.
set local hnsw.max_scan_tuples = 50;
set local hnsw.ef_search = 10;
set local enable_seqscan = off;
set local enable_sort = off;
select is(
  (select count(*)::int from public.match_documents(pg_temp.vec(1, 0), 'MOCK', (select id from public.stocks where symbol = 'TESTA'), null, 24)),
  24, 'stock-filtered search returns k rows despite many closer docs of other stocks');
reset enable_seqscan;
reset enable_sort;

-- 4. Paper orders round price and fees once, so order/trade rows reconcile with cash. --
insert into auth.users (id, email) values ('00000000-0000-0000-0000-0000000000c1', 'hardening@test.local');
create temp table acct as
  select id from public.paper_accounts where user_id = '00000000-0000-0000-0000-0000000000c1' and data_mode = 'MOCK';
create temp table buy1 as
  select * from public.execute_paper_order((select id from acct), (select id from public.stocks where symbol = 'TESTA'), 'BUY', 3, 10.00003, 0.00001);
select is((select available_cash from public.paper_accounts where id = (select id from acct)),
  1000000 - (select quantity * executed_price + fees from buy1),
  'cash debit equals the stored order (qty × executed_price + fees)');
select throws_ok(
  $$select public.execute_paper_order((select id from acct), (select id from public.stocks where symbol = 'TESTA'), 'BUY', 1, 0.00004)$$,
  '22023', 'INVALID_PRICE', 'price that rounds to zero is rejected as INVALID_PRICE');
select is((select count(*)::int from public.paper_orders where account_id = (select id from acct)), 1,
  'no order row written for an invalid price');

select * from finish();
rollback;
