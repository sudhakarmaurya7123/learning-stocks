begin;
create extension if not exists pgtap with schema extensions;
select plan(15);

-- Isolate from seeded holidays in the test window (rolled back at the end).
delete from public.exchange_holidays where holiday_date between '2026-10-05' and '2026-10-12';
insert into public.exchange_holidays (exchange, holiday_date, description) values ('NSE', '2026-10-07', 'TEST HOLIDAY (Wed)');
insert into public.exchange_holidays (exchange, holiday_date, description, special_open, special_close)
  values ('NSE', '2026-10-11', 'TEST SPECIAL SESSION (Sun)', '18:00', '19:00');

-- 2026-10-05 is a Monday.
select is(public.is_market_open('NSE', '2026-10-05 09:14:59+05:30'), false, '09:14:59 IST closed');
select is(public.is_market_open('NSE', '2026-10-05 09:15:00+05:30'), true,  '09:15 IST open');
select is(public.is_market_open('NSE', '2026-10-05 15:29:59+05:30'), true,  '15:29:59 IST open');
select is(public.is_market_open('NSE', '2026-10-05 15:30:00+05:30'), false, '15:30 IST closed');
select is(public.is_market_open('NSE', '2026-10-05 03:45:00+00'),    true,  '03:45 UTC = 09:15 IST open');
select is(public.is_market_open('NSE', '2026-10-05 22:00:00+00'),    false, '22:00 UTC = 03:30 IST next day closed');
select is(public.is_market_open('NSE', '2026-10-10 11:00:00+05:30'), false, 'Saturday closed');
select is(public.is_market_open('NSE', '2026-10-07 11:00:00+05:30'), false, 'holiday closed');
select is(public.is_market_open('BSE', '2026-10-07 11:00:00+05:30'), true,  'holiday is per-exchange');
select is(public.is_market_open('NSE', '2026-10-11 18:30:00+05:30'), true,  'special session open');
select is(public.is_market_open('NSE', '2026-10-11 17:59:00+05:30'), false, 'before special session closed');

select is(public.next_market_open('NSE', '2026-10-05 09:00:00+05:30'), '2026-10-05 09:15:00+05:30'::timestamptz, 'pre-open -> same day 09:15');
select is(public.next_market_open('NSE', '2026-10-05 16:00:00+05:30'), '2026-10-06 09:15:00+05:30'::timestamptz, 'after close -> next day');
select is(public.next_market_open('NSE', '2026-10-06 16:00:00+05:30'), '2026-10-08 09:15:00+05:30'::timestamptz, 'skips holiday');
select is(public.next_market_open('NSE', '2026-10-09 16:00:00+05:30'), '2026-10-11 18:00:00+05:30'::timestamptz, 'finds weekend special session');

select * from finish();
rollback;
