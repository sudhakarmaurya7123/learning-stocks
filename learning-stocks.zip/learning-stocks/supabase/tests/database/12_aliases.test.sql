begin;
create extension if not exists pgtap with schema extensions;
select plan(6);

select has_column('public', 'stocks', 'aliases', 'stocks.aliases exists');
select has_column('public', 'markets', 'aliases', 'markets.aliases exists');
select throws_ok($$update public.stocks set aliases = array['RIL', ''] where symbol = 'RELIANCE'$$,
  '23514', null, 'empty alias rejected');
select ok((select 'RIL' = any (aliases) from public.stocks where symbol = 'RELIANCE' and exchange = 'NSE'),
  'RELIANCE alias RIL seeded');
select ok((select 'Bank Nifty' = any (aliases) from public.markets where symbol = 'BANKNIFTY'),
  'BANKNIFTY alias seeded');

select ok((select not ('VIX' = any (aliases)) from public.markets where symbol = 'INDIAVIX'),
  'bare VIX alias not used (would match US VIX headlines)');

select * from finish();
rollback;
