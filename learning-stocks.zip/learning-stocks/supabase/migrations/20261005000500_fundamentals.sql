-- All metrics nullable: unavailable data stays NULL and is shown as "unavailable". Never estimated.
create table public.fundamental_snapshots (
  id                   uuid primary key default gen_random_uuid(),
  stock_id             uuid not null references public.stocks (id) on delete cascade,
  data_mode            public.data_mode not null,
  as_of                date not null,
  source               text not null,
  market_cap           numeric(20,2),
  pe                   numeric(10,2),
  pb                   numeric(10,2),
  eps_ttm              numeric(18,4),
  roe                  numeric(8,2),
  roce                 numeric(8,2),
  debt_to_equity       numeric(10,4),
  dividend_yield       numeric(8,4),
  operating_margin     numeric(8,2),
  net_margin           numeric(8,2),
  free_cash_flow       numeric(20,2),
  revenue_ttm          numeric(20,2),
  net_profit_ttm       numeric(20,2),
  revenue_growth_yoy   numeric(8,2),
  profit_growth_yoy    numeric(8,2),
  book_value_per_share numeric(18,4),
  beta                 numeric(8,4),
  raw                  jsonb not null default '{}'::jsonb,
  created_at           timestamptz not null default now(),
  unique (stock_id, data_mode, as_of, source)
);

create table public.financial_statements (
  id                   uuid primary key default gen_random_uuid(),
  stock_id             uuid not null references public.stocks (id) on delete cascade,
  data_mode            public.data_mode not null,
  period_type          public.period_type not null,
  period_end           date not null,
  source               text not null,
  revenue              numeric(20,2),
  operating_profit     numeric(20,2),
  net_profit           numeric(20,2),
  eps                  numeric(18,4),
  total_debt           numeric(20,2),
  total_equity         numeric(20,2),
  cash_from_operations numeric(20,2),
  capex                numeric(20,2),
  raw                  jsonb not null default '{}'::jsonb,
  created_at           timestamptz not null default now(),
  unique (stock_id, data_mode, period_type, period_end, source)
);
create index financial_statements_lookup_idx on public.financial_statements (stock_id, data_mode, period_type, period_end desc);
