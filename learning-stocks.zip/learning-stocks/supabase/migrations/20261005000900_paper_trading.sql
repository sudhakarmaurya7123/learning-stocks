create table public.user_profiles (
  user_id      uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  role         public.user_role not null default 'VIEWER',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger user_profiles_updated_at before update on public.user_profiles for each row execute function public.set_updated_at();

-- Indian charges are configurable; seeded values must be verified by the owner.
create table public.paper_fee_schedules (
  id                 uuid primary key default gen_random_uuid(),
  name               text not null unique,
  is_active          boolean not null default false,
  brokerage_pct      numeric(8,5) not null default 0 check (brokerage_pct      >= 0),
  brokerage_max      numeric(12,2)                  check (brokerage_max      >= 0),
  stt_buy_pct        numeric(8,5) not null default 0 check (stt_buy_pct        >= 0),
  stt_sell_pct       numeric(8,5) not null default 0 check (stt_sell_pct       >= 0),
  exchange_txn_pct   numeric(8,5) not null default 0 check (exchange_txn_pct   >= 0),
  sebi_fee_pct       numeric(8,5) not null default 0 check (sebi_fee_pct       >= 0),
  stamp_duty_buy_pct numeric(8,5) not null default 0 check (stamp_duty_buy_pct >= 0),
  gst_pct            numeric(8,5) not null default 0 check (gst_pct            >= 0),
  notes              text,
  created_at         timestamptz not null default now()
);
create unique index paper_fee_schedules_one_active on public.paper_fee_schedules (is_active) where is_active;

create table public.paper_accounts (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.user_profiles (user_id) on delete cascade,
  data_mode       public.data_mode not null,
  initial_balance numeric(18,4) not null check (initial_balance > 0),
  available_cash  numeric(18,4) not null check (available_cash >= 0),
  portfolio_value numeric(18,4) not null default 0,
  realized_pnl    numeric(18,4) not null default 0,
  total_pnl       numeric(18,4) not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (user_id, data_mode)
);
create trigger paper_accounts_updated_at before update on public.paper_accounts for each row execute function public.set_updated_at();

create table public.paper_positions (
  id                uuid primary key default gen_random_uuid(),
  account_id        uuid not null references public.paper_accounts (id) on delete cascade,
  stock_id          uuid not null references public.stocks (id),
  quantity          integer not null check (quantity > 0),
  average_buy_price numeric(18,4) not null check (average_buy_price > 0),
  current_price     numeric(18,4),
  unrealized_pnl    numeric(18,4) not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (account_id, stock_id)
);
create trigger paper_positions_updated_at before update on public.paper_positions for each row execute function public.set_updated_at();

create table public.paper_orders (
  id              uuid primary key default gen_random_uuid(),
  account_id      uuid not null references public.paper_accounts (id) on delete cascade,
  stock_id        uuid not null references public.stocks (id),
  order_type      public.trade_side not null,
  quantity        integer not null check (quantity > 0),
  requested_price numeric(18,4) check (requested_price > 0),
  executed_price  numeric(18,4) check (executed_price > 0),
  fees            numeric(18,4) not null default 0 check (fees >= 0),
  status          public.order_status not null,
  reject_reason   text,
  order_source    public.order_source not null default 'MANUAL',
  signal_id       uuid references public.ai_trade_signals (id) on delete set null,
  price_as_of     timestamptz,
  created_at      timestamptz not null default now(),
  executed_at     timestamptz,
  constraint paper_orders_reject_reason check ((status = 'REJECTED') = (reject_reason is not null))
);
create index paper_orders_account_idx on public.paper_orders (account_id, created_at desc);

create table public.paper_trades (
  id           uuid primary key default gen_random_uuid(),
  account_id   uuid not null references public.paper_accounts (id) on delete cascade,
  stock_id     uuid not null references public.stocks (id),
  order_id     uuid not null unique references public.paper_orders (id) on delete cascade,
  side         public.trade_side not null,
  quantity     integer not null check (quantity > 0),
  price        numeric(18,4) not null check (price > 0),
  fees         numeric(18,4) not null default 0 check (fees >= 0),
  realized_pnl numeric(18,4) not null default 0,
  created_at   timestamptz not null default now()
);
create index paper_trades_account_idx on public.paper_trades (account_id, created_at desc);

-- New auth user -> profile (first user is OWNER) + one paper account per data mode.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer
set search_path = public
as $$
declare
  v_balance numeric(18,4) := coalesce(
    (select (value #>> '{}')::numeric from public.app_settings where key = 'paper_initial_balance'), 1000000);
  v_role public.user_role := case
    when exists (select 1 from public.user_profiles where role = 'OWNER') then 'VIEWER'
    else 'OWNER' end;
begin
  insert into public.user_profiles (user_id, display_name, role) values (new.id, new.email, v_role);
  insert into public.paper_accounts (user_id, data_mode, initial_balance, available_cash, portfolio_value)
  values (new.id, 'MOCK', v_balance, v_balance, v_balance),
         (new.id, 'LIVE', v_balance, v_balance, v_balance);
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Atomic paper execution. Row locks serialise concurrent orders per account and position.
create or replace function public.execute_paper_order(
  p_account_id  uuid,
  p_stock_id    uuid,
  p_side        public.trade_side,
  p_quantity    integer,
  p_price       numeric,
  p_fees        numeric             default 0,
  p_source      public.order_source default 'MANUAL',
  p_signal_id   uuid                default null,
  p_price_as_of timestamptz         default now()
) returns public.paper_orders
language plpgsql
set search_path = public
as $$
declare
  v_account  public.paper_accounts;
  v_position public.paper_positions;
  v_order    public.paper_orders;
  v_cost     numeric(18,4);
  v_proceeds numeric(18,4);
  v_realized numeric(18,4);
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'INVALID_QUANTITY' using errcode = '22023';
  end if;
  if p_price is null or p_price <= 0 then
    raise exception 'INVALID_PRICE' using errcode = '22023';
  end if;
  if p_fees is null or p_fees < 0 then
    raise exception 'INVALID_FEES' using errcode = '22023';
  end if;

  select * into v_account from public.paper_accounts where id = p_account_id for update;
  if not found then
    raise exception 'ACCOUNT_NOT_FOUND' using errcode = 'P0002';
  end if;

  select * into v_position
    from public.paper_positions
   where account_id = p_account_id and stock_id = p_stock_id
     for update;

  if p_side = 'BUY' then
    v_cost := p_quantity * p_price + p_fees;

    if v_cost > v_account.available_cash then
      insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, status, reject_reason, order_source, signal_id, price_as_of)
      values (p_account_id, p_stock_id, p_side, p_quantity, p_price, 'REJECTED', 'INSUFFICIENT_FUNDS', p_source, p_signal_id, p_price_as_of)
      returning * into v_order;
      return v_order;
    end if;

    insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, executed_price, fees, status, order_source, signal_id, price_as_of, executed_at)
    values (p_account_id, p_stock_id, p_side, p_quantity, p_price, p_price, p_fees, 'EXECUTED', p_source, p_signal_id, p_price_as_of, now())
    returning * into v_order;

    if v_position.id is null then
      insert into public.paper_positions (account_id, stock_id, quantity, average_buy_price, current_price)
      values (p_account_id, p_stock_id, p_quantity, round(v_cost / p_quantity, 4), p_price);
    else
      update public.paper_positions
         set average_buy_price = round((quantity * average_buy_price + v_cost) / (quantity + p_quantity), 4),
             quantity          = quantity + p_quantity,
             current_price     = p_price
       where id = v_position.id;
    end if;

    insert into public.paper_trades (account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl)
    values (p_account_id, p_stock_id, v_order.id, p_side, p_quantity, p_price, p_fees, 0);

    update public.paper_accounts set available_cash = available_cash - v_cost where id = p_account_id;

  else -- SELL (long-only: cannot exceed holdings)
    if v_position.id is null or v_position.quantity < p_quantity then
      insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, status, reject_reason, order_source, signal_id, price_as_of)
      values (p_account_id, p_stock_id, p_side, p_quantity, p_price, 'REJECTED', 'INSUFFICIENT_QUANTITY', p_source, p_signal_id, p_price_as_of)
      returning * into v_order;
      return v_order;
    end if;

    v_proceeds := p_quantity * p_price - p_fees;
    v_realized := (p_price - v_position.average_buy_price) * p_quantity - p_fees;

    insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, executed_price, fees, status, order_source, signal_id, price_as_of, executed_at)
    values (p_account_id, p_stock_id, p_side, p_quantity, p_price, p_price, p_fees, 'EXECUTED', p_source, p_signal_id, p_price_as_of, now())
    returning * into v_order;

    insert into public.paper_trades (account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl)
    values (p_account_id, p_stock_id, v_order.id, p_side, p_quantity, p_price, p_fees, v_realized);

    if v_position.quantity = p_quantity then
      delete from public.paper_positions where id = v_position.id;
    else
      update public.paper_positions
         set quantity = quantity - p_quantity, current_price = p_price
       where id = v_position.id;
    end if;

    update public.paper_accounts
       set available_cash = available_cash + v_proceeds,
           realized_pnl   = realized_pnl + v_realized
     where id = p_account_id;
  end if;

  return v_order;
end $$;
