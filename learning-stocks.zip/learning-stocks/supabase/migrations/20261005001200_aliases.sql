-- Alternative names used by news mention matching (e.g. 'RIL', 'L&T', 'Bank Nifty').
-- Data, not code: adding an alias is an UPDATE. Matching rules: docs/architecture.md (News).
alter table public.stocks
  add column aliases text[] not null default '{}',
  add constraint stocks_aliases_valid
    check (array_position(aliases, null) is null and array_position(aliases, '') is null);

alter table public.markets
  add column aliases text[] not null default '{}',
  add constraint markets_aliases_valid
    check (array_position(aliases, null) is null and array_position(aliases, '') is null);
