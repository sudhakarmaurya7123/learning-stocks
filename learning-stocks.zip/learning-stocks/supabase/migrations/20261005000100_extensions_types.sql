-- Extensions -----------------------------------------------------------------
create extension if not exists vector with schema extensions;
create extension if not exists pg_trgm with schema extensions;

-- Enums (closed sets; mirrored in packages/shared) -----------------------------
create type public.exchange_code       as enum ('NSE', 'BSE');
create type public.market_type         as enum ('BROAD_INDEX', 'SECTOR_INDEX', 'VOLATILITY');
create type public.data_mode           as enum ('MOCK', 'LIVE');
create type public.bar_interval        as enum ('1m', '5m', '15m', '1d');
create type public.sentiment           as enum ('BULLISH', 'NEUTRAL', 'BEARISH');
create type public.impact_level        as enum ('LOW', 'MEDIUM', 'HIGH');
create type public.trend               as enum ('UPTREND', 'SIDEWAYS', 'DOWNTREND');
create type public.risk_level          as enum ('LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH');
create type public.recommendation_bias as enum ('STRONG_BUY_BIAS', 'BUY_BIAS', 'HOLD_BIAS', 'SELL_BIAS', 'STRONG_SELL_BIAS');
create type public.action_state        as enum ('BUY_ZONE', 'WAIT_FOR_PULLBACK', 'WAIT_FOR_CONFIRMATION', 'HOLD', 'REDUCE', 'AVOID', 'INSUFFICIENT_DATA');
create type public.valuation_label     as enum ('UNDERVALUED', 'FAIR', 'OVERVALUED', 'INSUFFICIENT_DATA');
create type public.market_regime       as enum ('RISK_ON', 'NEUTRAL', 'RISK_OFF');
create type public.trade_side          as enum ('BUY', 'SELL');
create type public.order_status        as enum ('PENDING', 'EXECUTED', 'REJECTED', 'CANCELLED');
create type public.order_source        as enum ('MANUAL', 'AI_SIGNAL');
create type public.signal_type         as enum ('BUY', 'SELL', 'HOLD');
create type public.signal_status       as enum ('ACTIVE', 'TRIGGERED', 'EXPIRED', 'INVALIDATED');
create type public.period_type         as enum ('QUARTERLY', 'ANNUAL', 'TTM');
create type public.link_type           as enum ('BENCHMARK', 'SECTOR_INDEX', 'CONSTITUENT');
create type public.user_role           as enum ('OWNER', 'ADMIN', 'VIEWER');
create type public.job_status          as enum ('STARTED', 'SUCCESS', 'PARTIAL', 'FAILED', 'SKIPPED');
create type public.analysis_status     as enum ('OK', 'FAILED', 'INSUFFICIENT_DATA');

-- Domains ----------------------------------------------------------------------
-- 0..100 score; for sentiment, 50 = neutral.
create domain public.score as numeric(5,2) check (value >= 0 and value <= 100);
-- Strictly positive INR price.
create domain public.price as numeric(18,4) check (value > 0);
