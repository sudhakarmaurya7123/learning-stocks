create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := clock_timestamp();
  return new;
end $$;

create table public.markets (
  id          uuid primary key default gen_random_uuid(),
  symbol      text not null check (symbol ~ '^[A-Z0-9&_.-]{1,32}$'),
  name        text not null,
  exchange    public.exchange_code not null,
  market_type public.market_type not null,
  sector      text,
  description text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (exchange, symbol)
);

create table public.stocks (
  id            uuid primary key default gen_random_uuid(),
  symbol        text not null check (symbol ~ '^[A-Z0-9&_.-]{1,32}$'),
  company_name  text not null,
  exchange      public.exchange_code not null,
  isin          text check (isin ~ '^IN[A-Z0-9]{9}[0-9]$'),
  isin_verified boolean not null default false,
  sector        text,
  industry      text,
  market_cap    numeric(20,2) check (market_cap >= 0),
  currency      char(3) not null default 'INR',
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (exchange, symbol),
  constraint stocks_verified_isin_present check (not isin_verified or isin is not null)
);
create index stocks_isin_idx on public.stocks (isin);
create index stocks_company_name_trgm_idx on public.stocks using gin (company_name extensions.gin_trgm_ops);

create table public.provider_symbols (
  id              uuid primary key default gen_random_uuid(),
  provider        text not null check (provider ~ '^[a-z0-9_]+$'),
  stock_id        uuid references public.stocks (id) on delete cascade,
  market_id       uuid references public.markets (id) on delete cascade,
  provider_symbol text not null,
  verified        boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint provider_symbols_one_owner check (num_nonnulls(stock_id, market_id) = 1)
);
create unique index provider_symbols_stock_uq  on public.provider_symbols (provider, stock_id)  where stock_id is not null;
create unique index provider_symbols_market_uq on public.provider_symbols (provider, market_id) where market_id is not null;
create unique index provider_symbols_symbol_uq on public.provider_symbols (provider, provider_symbol);

create table public.stock_market_links (
  stock_id   uuid not null references public.stocks (id) on delete cascade,
  market_id  uuid not null references public.markets (id) on delete cascade,
  link_type  public.link_type not null,
  created_at timestamptz not null default now(),
  primary key (stock_id, market_id, link_type)
);
create index stock_market_links_market_idx on public.stock_market_links (market_id);

create table public.exchange_holidays (
  id            uuid primary key default gen_random_uuid(),
  exchange      public.exchange_code not null,
  holiday_date  date not null,
  description   text not null,
  segment       text not null default 'EQUITY',
  special_open  time,
  special_close time,
  source        text not null default 'manual',
  created_at    timestamptz not null default now(),
  unique (exchange, holiday_date, segment),
  constraint exchange_holidays_special_pair  check ((special_open is null) = (special_close is null)),
  constraint exchange_holidays_special_order check (special_open is null or special_open < special_close)
);

create trigger markets_updated_at          before update on public.markets          for each row execute function public.set_updated_at();
create trigger stocks_updated_at           before update on public.stocks           for each row execute function public.set_updated_at();
create trigger provider_symbols_updated_at before update on public.provider_symbols for each row execute function public.set_updated_at();
