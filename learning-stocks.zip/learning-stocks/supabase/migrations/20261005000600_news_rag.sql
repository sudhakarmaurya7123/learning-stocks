create table public.news (
  id           uuid primary key default gen_random_uuid(),
  data_mode    public.data_mode not null,
  title        text not null check (length(title) between 1 and 1000),
  description  text,
  content      text,
  source       text not null,
  source_url   text not null,
  author       text,
  published_at timestamptz not null,
  fetched_at   timestamptz not null default now(),
  language     text not null default 'en',
  content_hash text not null check (content_hash ~ '^[a-f0-9]{64}$'),
  created_at   timestamptz not null default now(),
  unique (data_mode, content_hash),
  unique (data_mode, source_url)
);
create index news_published_idx on public.news (data_mode, published_at desc);

create table public.news_mentions (
  id              uuid primary key default gen_random_uuid(),
  news_id         uuid not null references public.news (id) on delete cascade,
  stock_id        uuid references public.stocks (id) on delete cascade,
  market_id       uuid references public.markets (id) on delete cascade,
  relevance_score numeric(4,3) not null check (relevance_score between 0 and 1),
  matched_by      text not null,
  created_at      timestamptz not null default now(),
  constraint news_mentions_one_owner check (num_nonnulls(stock_id, market_id) = 1)
);
create unique index news_mentions_stock_uq  on public.news_mentions (news_id, stock_id)  where stock_id  is not null;
create unique index news_mentions_market_uq on public.news_mentions (news_id, market_id) where market_id is not null;
create index news_mentions_stock_idx  on public.news_mentions (stock_id)  where stock_id  is not null;
create index news_mentions_market_idx on public.news_mentions (market_id) where market_id is not null;

create table public.news_ai_analysis (
  id               uuid primary key default gen_random_uuid(),
  news_id          uuid not null references public.news (id) on delete cascade,
  stock_id         uuid references public.stocks (id) on delete cascade,
  sentiment        public.sentiment not null,
  sentiment_score  public.score not null,
  confidence       public.score not null,
  relevance_score  numeric(4,3) not null check (relevance_score between 0 and 1),
  impact_level     public.impact_level not null,
  summary          text not null,
  positive_factors jsonb not null default '[]'::jsonb,
  negative_factors jsonb not null default '[]'::jsonb,
  reasoning        jsonb not null default '[]'::jsonb,
  model            text not null,
  prompt_version   text not null,
  created_at       timestamptz not null default now(),
  constraint news_ai_analysis_once unique nulls not distinct (news_id, stock_id, prompt_version)
);
create index news_ai_analysis_stock_idx on public.news_ai_analysis (stock_id, created_at desc);

create table public.document_embeddings (
  id              uuid primary key default gen_random_uuid(),
  data_mode       public.data_mode not null,
  source_type     text not null check (source_type in ('NEWS', 'FINANCIALS', 'AI_ANALYSIS', 'MARKET_SUMMARY')),
  source_id       uuid not null,
  stock_id        uuid references public.stocks (id) on delete cascade,
  chunk_index     integer not null default 0 check (chunk_index >= 0),
  content         text not null,
  content_hash    text not null,
  embedding       extensions.vector(1536) not null,
  embedding_model text not null,
  metadata        jsonb not null default '{}'::jsonb,
  published_at    timestamptz,
  created_at      timestamptz not null default now(),
  unique (source_type, source_id, chunk_index, embedding_model)
);
create index document_embeddings_hnsw_idx on public.document_embeddings
  using hnsw (embedding extensions.vector_cosine_ops);
create index document_embeddings_filter_idx on public.document_embeddings (data_mode, stock_id, published_at desc);

-- Filtered cosine search. iterative_scan keeps scanning the HNSW graph until
-- enough rows pass the WHERE filters (pgvector >= 0.8), so a stock filter still yields k rows.
create or replace function public.match_documents(
  p_query_embedding extensions.vector(1536),
  p_data_mode       public.data_mode,
  p_stock_id        uuid        default null,
  p_since           timestamptz default null,
  p_k               integer     default 8,
  p_source_types    text[]      default null
)
returns table (
  id           uuid,
  source_type  text,
  source_id    uuid,
  stock_id     uuid,
  content      text,
  metadata     jsonb,
  published_at timestamptz,
  similarity   double precision
)
language sql stable
set search_path = public, extensions
set hnsw.iterative_scan = 'strict_order'
as $$
  select d.id, d.source_type, d.source_id, d.stock_id, d.content, d.metadata, d.published_at,
         1 - (d.embedding <=> p_query_embedding) as similarity
    from public.document_embeddings d
   where d.data_mode = p_data_mode
     and (p_stock_id is null or d.stock_id = p_stock_id)
     and (p_since is null or d.published_at >= p_since)
     and (p_source_types is null or d.source_type = any (p_source_types))
   order by d.embedding <=> p_query_embedding
   limit greatest(p_k, 1)
$$;
