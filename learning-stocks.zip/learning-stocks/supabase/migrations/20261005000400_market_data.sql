create table public.market_data (
  id             uuid primary key default gen_random_uuid(),
  stock_id       uuid references public.stocks (id) on delete cascade,
  market_id      uuid references public.markets (id) on delete cascade,
  data_mode      public.data_mode not null,
  timeframe      public.bar_interval not null,
  ts             timestamptz not null,
  open           public.price not null,
  high           public.price not null,
  low            public.price not null,
  close          public.price not null,
  adjusted_close public.price,
  volume         bigint not null default 0 check (volume >= 0),
  change         numeric(18,4),
  change_percent numeric(9,4),
  vwap           public.price,
  source         text not null,
  created_at     timestamptz not null default now(),
  constraint market_data_one_owner check (num_nonnulls(stock_id, market_id) = 1),
  constraint market_data_ohlc check (high >= greatest(open, close, low) and low <= least(open, close))
);
-- Partial unique indexes: a plain UNIQUE over nullable owner columns would not deduplicate.
create unique index market_data_stock_uq  on public.market_data (stock_id,  data_mode, timeframe, ts, source) where stock_id  is not null;
create unique index market_data_market_uq on public.market_data (market_id, data_mode, timeframe, ts, source) where market_id is not null;
create index market_data_stock_latest_idx  on public.market_data (stock_id,  data_mode, timeframe, ts desc) where stock_id  is not null;
create index market_data_market_latest_idx on public.market_data (market_id, data_mode, timeframe, ts desc) where market_id is not null;

create table public.technical_indicators (
  id               uuid primary key default gen_random_uuid(),
  stock_id         uuid not null references public.stocks (id) on delete cascade,
  data_mode        public.data_mode not null,
  timeframe        public.bar_interval not null,
  ts               timestamptz not null,
  sma_20           numeric(18,4),
  sma_50           numeric(18,4),
  sma_200          numeric(18,4),
  ema_20           numeric(18,4),
  ema_50           numeric(18,4),
  ema_200          numeric(18,4),
  rsi_14           public.score,
  macd             numeric(18,4),
  macd_signal      numeric(18,4),
  macd_histogram   numeric(18,4),
  bollinger_upper  numeric(18,4),
  bollinger_middle numeric(18,4),
  bollinger_lower  numeric(18,4),
  atr_14           numeric(18,4) check (atr_14 >= 0),
  adx_14           public.score,
  stoch_k          public.score,
  stoch_d          public.score,
  vwap             numeric(18,4),
  volume_sma_20    numeric(20,2) check (volume_sma_20 >= 0),
  pivots           jsonb not null default '{}'::jsonb,
  created_at       timestamptz not null default now(),
  unique (stock_id, data_mode, timeframe, ts)
);
