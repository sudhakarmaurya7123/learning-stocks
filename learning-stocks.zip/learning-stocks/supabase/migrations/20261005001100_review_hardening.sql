-- Fixes from the Phase 1 final review.

-- 1. Postgres grants EXECUTE on new functions to PUBLIC globally; a per-schema default ACL
--    cannot remove that. Revoke it for every function the migration role creates from now on.
alter default privileges for role postgres revoke execute on functions from public;

-- 2. Latest quote per instrument via an index-backed LATERAL lookup, so filtering on one
--    instrument reads one bar instead of sorting the whole table. Ties break on timeframe, then source.
drop index if exists public.market_data_stock_latest_idx;
drop index if exists public.market_data_market_latest_idx;
create index market_data_stock_latest_idx  on public.market_data (stock_id,  data_mode, ts desc) where stock_id  is not null;
create index market_data_market_latest_idx on public.market_data (market_id, data_mode, ts desc) where market_id is not null;

create or replace view public.v_latest_quotes with (security_invoker = true) as
select s.id as stock_id, null::uuid as market_id, m.data_mode, q.timeframe, q.ts, q.close as price,
       q.change, q.change_percent, q.volume, q.source
  from public.stocks s
 cross join unnest(enum_range(null::public.data_mode)) as m (data_mode)
 cross join lateral (
        select md.timeframe, md.ts, md.close, md.change, md.change_percent, md.volume, md.source
          from public.market_data md
         where md.stock_id = s.id and md.data_mode = m.data_mode
         order by md.ts desc, md.timeframe, md.source
         limit 1) q
union all
select null::uuid, mk.id, m.data_mode, q.timeframe, q.ts, q.close, q.change, q.change_percent, q.volume, q.source
  from public.markets mk
 cross join unnest(enum_range(null::public.data_mode)) as m (data_mode)
 cross join lateral (
        select md.timeframe, md.ts, md.close, md.change, md.change_percent, md.volume, md.source
          from public.market_data md
         where md.market_id = mk.id and md.data_mode = m.data_mode
         order by md.ts desc, md.timeframe, md.source
         limit 1) q;

-- 3. Stock-filtered searches use an exact scan over that stock's (small) corpus. An approximate
--    HNSW scan with a selective filter stops after hnsw.max_scan_tuples and can return 0 rows.
--    Unfiltered (market-wide) searches keep the HNSW path with iterative scan.
create or replace function public.match_documents(
  p_query_embedding extensions.vector(1536),
  p_data_mode       public.data_mode,
  p_stock_id        uuid        default null,
  p_since           timestamptz default null,
  p_k               integer     default 8,
  p_source_types    text[]      default null
)
returns table (
  id           uuid,
  source_type  text,
  source_id    uuid,
  stock_id     uuid,
  content      text,
  metadata     jsonb,
  published_at timestamptz,
  similarity   double precision
)
language plpgsql stable
set search_path = public, extensions
set hnsw.iterative_scan = 'strict_order'
as $$
#variable_conflict use_column
begin
  if p_stock_id is not null then
    return query
      with candidates as materialized (
        select d.id, d.source_type, d.source_id, d.stock_id, d.content, d.metadata, d.published_at, d.embedding
          from public.document_embeddings d
         where d.data_mode = p_data_mode
           and d.stock_id = p_stock_id
           and (p_since is null or d.published_at >= p_since)
           and (p_source_types is null or d.source_type = any (p_source_types)))
      select c.id, c.source_type, c.source_id, c.stock_id, c.content, c.metadata, c.published_at,
             1 - (c.embedding <=> p_query_embedding)
        from candidates c
       order by c.embedding <=> p_query_embedding
       limit greatest(p_k, 1);
  else
    return query
      select d.id, d.source_type, d.source_id, d.stock_id, d.content, d.metadata, d.published_at,
             1 - (d.embedding <=> p_query_embedding)
        from public.document_embeddings d
       where d.data_mode = p_data_mode
         and (p_since is null or d.published_at >= p_since)
         and (p_source_types is null or d.source_type = any (p_source_types))
       order by d.embedding <=> p_query_embedding
       limit greatest(p_k, 1);
  end if;
end $$;

-- 4. execute_paper_order: round price and fees to 4 dp before validating and booking.
create or replace function public.execute_paper_order(
  p_account_id  uuid,
  p_stock_id    uuid,
  p_side        public.trade_side,
  p_quantity    integer,
  p_price       numeric,
  p_fees        numeric             default 0,
  p_source      public.order_source default 'MANUAL',
  p_signal_id   uuid                default null,
  p_price_as_of timestamptz         default now()
) returns public.paper_orders
language plpgsql
set search_path = public
as $$
declare
  v_account  public.paper_accounts;
  v_position public.paper_positions;
  v_order    public.paper_orders;
  v_cost     numeric(18,4);
  v_proceeds numeric(18,4);
  v_realized numeric(18,4);
begin
  -- Round once at entry so the stored order/trade rows reconcile exactly with the cash movement.
  p_price := round(p_price, 4);
  p_fees  := round(p_fees, 4);

  if p_quantity is null or p_quantity <= 0 then
    raise exception 'INVALID_QUANTITY' using errcode = '22023';
  end if;
  if p_price is null or p_price <= 0 then
    raise exception 'INVALID_PRICE' using errcode = '22023';
  end if;
  if p_fees is null or p_fees < 0 then
    raise exception 'INVALID_FEES' using errcode = '22023';
  end if;

  select * into v_account from public.paper_accounts where id = p_account_id for update;
  if not found then
    raise exception 'ACCOUNT_NOT_FOUND' using errcode = 'P0002';
  end if;

  select * into v_position
    from public.paper_positions
   where account_id = p_account_id and stock_id = p_stock_id
     for update;

  if p_side = 'BUY' then
    v_cost := p_quantity * p_price + p_fees;

    if v_cost > v_account.available_cash then
      insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, status, reject_reason, order_source, signal_id, price_as_of)
      values (p_account_id, p_stock_id, p_side, p_quantity, p_price, 'REJECTED', 'INSUFFICIENT_FUNDS', p_source, p_signal_id, p_price_as_of)
      returning * into v_order;
      return v_order;
    end if;

    insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, executed_price, fees, status, order_source, signal_id, price_as_of, executed_at)
    values (p_account_id, p_stock_id, p_side, p_quantity, p_price, p_price, p_fees, 'EXECUTED', p_source, p_signal_id, p_price_as_of, now())
    returning * into v_order;

    if v_position.id is null then
      insert into public.paper_positions (account_id, stock_id, quantity, average_buy_price, current_price)
      values (p_account_id, p_stock_id, p_quantity, round(v_cost / p_quantity, 4), p_price);
    else
      update public.paper_positions
         set average_buy_price = round((quantity * average_buy_price + v_cost) / (quantity + p_quantity), 4),
             quantity          = quantity + p_quantity,
             current_price     = p_price
       where id = v_position.id;
    end if;

    insert into public.paper_trades (account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl)
    values (p_account_id, p_stock_id, v_order.id, p_side, p_quantity, p_price, p_fees, 0);

    update public.paper_accounts set available_cash = available_cash - v_cost where id = p_account_id;

  else -- SELL (long-only: cannot exceed holdings)
    if v_position.id is null or v_position.quantity < p_quantity then
      insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, status, reject_reason, order_source, signal_id, price_as_of)
      values (p_account_id, p_stock_id, p_side, p_quantity, p_price, 'REJECTED', 'INSUFFICIENT_QUANTITY', p_source, p_signal_id, p_price_as_of)
      returning * into v_order;
      return v_order;
    end if;

    v_proceeds := p_quantity * p_price - p_fees;
    v_realized := (p_price - v_position.average_buy_price) * p_quantity - p_fees;

    insert into public.paper_orders (account_id, stock_id, order_type, quantity, requested_price, executed_price, fees, status, order_source, signal_id, price_as_of, executed_at)
    values (p_account_id, p_stock_id, p_side, p_quantity, p_price, p_price, p_fees, 'EXECUTED', p_source, p_signal_id, p_price_as_of, now())
    returning * into v_order;

    insert into public.paper_trades (account_id, stock_id, order_id, side, quantity, price, fees, realized_pnl)
    values (p_account_id, p_stock_id, v_order.id, p_side, p_quantity, p_price, p_fees, v_realized);

    if v_position.quantity = p_quantity then
      delete from public.paper_positions where id = v_position.id;
    else
      update public.paper_positions
         set quantity = quantity - p_quantity, current_price = p_price
       where id = v_position.id;
    end if;

    update public.paper_accounts
       set available_cash = available_cash + v_proceeds,
           realized_pnl   = realized_pnl + v_realized
     where id = p_account_id;
  end if;

  return v_order;
end $$;
