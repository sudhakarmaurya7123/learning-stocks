-- SQL mirror of MarketCalendarService (TS is canonical; keep both in sync).
-- Regular equity session: [09:15, 15:30) Asia/Kolkata, Mon-Fri, minus holidays.
-- A holiday row with special_open/special_close is a special session (e.g. Muhurat trading).

create or replace function public.is_market_open(p_exchange public.exchange_code, p_ts timestamptz)
returns boolean
language plpgsql stable
set search_path = public
as $$
declare
  v_local   timestamp := p_ts at time zone 'Asia/Kolkata';
  v_date    date      := v_local::date;
  v_time    time      := v_local::time;
  v_holiday public.exchange_holidays;
begin
  select * into v_holiday
    from public.exchange_holidays
   where exchange = p_exchange and segment = 'EQUITY' and holiday_date = v_date;

  if found then
    return v_holiday.special_open is not null
       and v_time >= v_holiday.special_open
       and v_time <  v_holiday.special_close;
  end if;

  if extract(isodow from v_date) in (6, 7) then
    return false;
  end if;

  return v_time >= time '09:15' and v_time < time '15:30';
end $$;

create or replace function public.next_market_open(p_exchange public.exchange_code, p_ts timestamptz)
returns timestamptz
language plpgsql stable
set search_path = public
as $$
declare
  v_start   date := (p_ts at time zone 'Asia/Kolkata')::date;
  v_day     date;
  v_holiday public.exchange_holidays;
  v_open    timestamptz;
begin
  for i in 0..30 loop
    v_day := v_start + i;

    select * into v_holiday
      from public.exchange_holidays
     where exchange = p_exchange and segment = 'EQUITY' and holiday_date = v_day;

    if found then
      v_open := case when v_holiday.special_open is null then null
                     else (v_day + v_holiday.special_open) at time zone 'Asia/Kolkata' end;
    elsif extract(isodow from v_day) in (6, 7) then
      v_open := null;
    else
      v_open := (v_day + time '09:15') at time zone 'Asia/Kolkata';
    end if;

    if v_open is not null and v_open > p_ts then
      return v_open;
    end if;
  end loop;

  return null;
end $$;
