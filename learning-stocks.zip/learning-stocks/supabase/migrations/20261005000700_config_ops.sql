create table public.app_settings (
  key         text primary key check (key ~ '^[a-z0-9_]+$'),
  value       jsonb not null,
  description text,
  updated_at  timestamptz not null default now()
);
create trigger app_settings_updated_at before update on public.app_settings for each row execute function public.set_updated_at();

create table public.scoring_configs (
  id         uuid primary key default gen_random_uuid(),
  version    text not null unique,
  weights    jsonb not null,
  thresholds jsonb not null,
  is_active  boolean not null default false,
  notes      text,
  created_at timestamptz not null default now()
);
create unique index scoring_configs_one_active on public.scoring_configs (is_active) where is_active;

create table public.system_logs (
  id                uuid primary key default gen_random_uuid(),
  job_run_id        uuid,
  service           text not null,
  job_name          text,
  operation         text not null,
  status            public.job_status not null,
  message           text,
  records_fetched   integer not null default 0 check (records_fetched   >= 0),
  records_inserted  integer not null default 0 check (records_inserted  >= 0),
  records_skipped   integer not null default 0 check (records_skipped   >= 0),
  records_failed    integer not null default 0 check (records_failed    >= 0),
  records_processed integer not null default 0 check (records_processed >= 0),
  started_at        timestamptz,
  finished_at       timestamptz,
  execution_time_ms integer check (execution_time_ms >= 0),
  error_details     jsonb,
  created_at        timestamptz not null default now()
);
create index system_logs_job_idx on public.system_logs (job_name, created_at desc);
create index system_logs_status_idx on public.system_logs (status, created_at desc);

create table public.llm_calls (
  id             uuid primary key default gen_random_uuid(),
  purpose        text not null,
  provider       text not null,
  model          text not null,
  prompt_version text,
  input_tokens   integer not null default 0 check (input_tokens  >= 0),
  output_tokens  integer not null default 0 check (output_tokens >= 0),
  est_cost_inr   numeric(12,4) not null default 0 check (est_cost_inr >= 0),
  latency_ms     integer check (latency_ms >= 0),
  cache_hit      boolean not null default false,
  status         text not null check (status in ('OK', 'FAILED', 'INVALID_OUTPUT', 'BUDGET_EXCEEDED')),
  error          text,
  created_at     timestamptz not null default now()
);
create index llm_calls_created_idx on public.llm_calls (created_at desc);
