-- Phase 6: one embedding row per (chunk, stock) so an article mentioning several stocks is
-- retrievable for each of them. The vector itself is computed once per content hash and reused.
alter table public.document_embeddings
  drop constraint document_embeddings_source_type_source_id_chunk_index_embed_key;
alter table public.document_embeddings
  add constraint document_embeddings_chunk_stock_uq
  unique nulls not distinct (source_type, source_id, chunk_index, embedding_model, stock_id);

-- Vector reuse: same text + model (+ mode) -> same embedding, never embedded twice.
create index document_embeddings_hash_idx
  on public.document_embeddings (data_mode, embedding_model, content_hash);

-- Adding parameters needs drop + create (create or replace would leave an ambiguous overload).
drop function public.match_documents(extensions.vector, public.data_mode, uuid, timestamptz, integer, text[]);

-- `supabase migration up` runs as a non-superuser: load pgvector in this session first so
-- hnsw.iterative_scan is a real (user-settable) parameter for the function's SET clause.
select '[1]'::extensions.vector;

create function public.match_documents(
  p_query_embedding extensions.vector(1536),
  p_data_mode       public.data_mode,
  p_stock_id        uuid        default null,
  p_since           timestamptz default null,
  p_k               integer     default 8,
  p_source_types    text[]      default null,
  p_embedding_model text        default null,
  p_market_only     boolean     default false
)
returns table (
  id           uuid,
  source_type  text,
  source_id    uuid,
  stock_id     uuid,
  content      text,
  metadata     jsonb,
  published_at timestamptz,
  similarity   double precision
)
language plpgsql stable
set search_path = public, extensions
set hnsw.iterative_scan = 'strict_order'
as $$
#variable_conflict use_column
begin
  if p_stock_id is not null and p_market_only then
    raise exception 'p_stock_id and p_market_only are mutually exclusive' using errcode = '22023';
  end if;
  if p_stock_id is not null then
    return query
      with candidates as materialized (
        select d.id, d.source_type, d.source_id, d.stock_id, d.content, d.metadata, d.published_at, d.embedding
          from public.document_embeddings d
         where d.data_mode = p_data_mode
           and d.stock_id = p_stock_id
           and (p_since is null or d.published_at >= p_since)
           and (p_source_types is null or d.source_type = any (p_source_types))
           and (p_embedding_model is null or d.embedding_model = p_embedding_model))
      select c.id, c.source_type, c.source_id, c.stock_id, c.content, c.metadata, c.published_at,
             1 - (c.embedding <=> p_query_embedding)
        from candidates c
       order by c.embedding <=> p_query_embedding
       limit greatest(p_k, 1);
  else
    return query
      select d.id, d.source_type, d.source_id, d.stock_id, d.content, d.metadata, d.published_at,
             1 - (d.embedding <=> p_query_embedding)
        from public.document_embeddings d
       where d.data_mode = p_data_mode
         and (not p_market_only or d.stock_id is null)
         and (p_since is null or d.published_at >= p_since)
         and (p_source_types is null or d.source_type = any (p_source_types))
         and (p_embedding_model is null or d.embedding_model = p_embedding_model)
       order by d.embedding <=> p_query_embedding
       limit greatest(p_k, 1);
  end if;
end $$;

revoke execute on function public.match_documents(extensions.vector, public.data_mode, uuid, timestamptz, integer, text[], text, boolean)
  from public, anon, authenticated;
