create view public.v_latest_quotes with (security_invoker = true) as
select distinct on (coalesce(stock_id, market_id), data_mode)
       stock_id, market_id, data_mode, timeframe, ts, close as price, change, change_percent, volume, source
  from public.market_data
 order by coalesce(stock_id, market_id), data_mode, ts desc, timeframe;

create view public.v_latest_stock_evaluation with (security_invoker = true) as
select distinct on (stock_id, data_mode) *
  from public.stock_evaluations
 order by stock_id, data_mode, evaluated_at desc;

create view public.v_latest_stock_ai_analysis with (security_invoker = true) as
select distinct on (stock_id, data_mode) *
  from public.stock_ai_analysis
 where status = 'OK'
 order by stock_id, data_mode, analysis_time desc;

-- Lockdown: the browser never touches tables. The backend connects as a privileged role.
do $$
declare r record;
begin
  for r in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', r.tablename);
  end loop;
end $$;

revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke all on tables    from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
