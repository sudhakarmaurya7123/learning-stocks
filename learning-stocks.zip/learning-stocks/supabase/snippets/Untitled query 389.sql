select symbol, company_name, isin, sector from stocks order by symbol;
select is_market_open('NSE', now()), next_market_open('NSE', now());
