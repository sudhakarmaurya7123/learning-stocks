insert into public.markets (symbol, name, exchange, market_type, sector, description) values
  ('NIFTY50',         'NIFTY 50',                 'NSE', 'BROAD_INDEX',  null,                              'NSE benchmark index of 50 large caps'),
  ('SENSEX',          'SENSEX',                   'BSE', 'BROAD_INDEX',  null,                              'BSE benchmark index of 30 large caps'),
  ('BANKNIFTY',       'NIFTY BANK',               'NSE', 'SECTOR_INDEX', 'Financial Services',              'Banking sector index'),
  ('NIFTYIT',         'NIFTY IT',                 'NSE', 'SECTOR_INDEX', 'Information Technology',          'IT sector index'),
  ('NIFTYPHARMA',     'NIFTY PHARMA',             'NSE', 'SECTOR_INDEX', 'Healthcare',                      'Pharma sector index'),
  ('NIFTYAUTO',       'NIFTY AUTO',               'NSE', 'SECTOR_INDEX', 'Automobile and Auto Components',  'Auto sector index'),
  ('NIFTYFMCG',       'NIFTY FMCG',               'NSE', 'SECTOR_INDEX', 'Fast Moving Consumer Goods',      'FMCG sector index'),
  ('NIFTYMETAL',      'NIFTY METAL',              'NSE', 'SECTOR_INDEX', 'Metals & Mining',                 'Metal sector index'),
  ('NIFTYREALTY',     'NIFTY REALTY',             'NSE', 'SECTOR_INDEX', 'Realty',                          'Realty sector index'),
  ('NIFTYFINSERVICE', 'NIFTY FINANCIAL SERVICES', 'NSE', 'SECTOR_INDEX', 'Financial Services',              'Financial services sector index'),
  ('NIFTYENERGY',     'NIFTY ENERGY',             'NSE', 'SECTOR_INDEX', 'Oil Gas & Consumable Fuels',      'Energy sector index'),
  ('INDIAVIX',        'INDIA VIX',                'NSE', 'VOLATILITY',   null,                              'Expected 30-day NIFTY volatility');
