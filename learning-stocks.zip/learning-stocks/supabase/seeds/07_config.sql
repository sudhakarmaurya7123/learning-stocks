insert into public.scoring_configs (version, is_active, notes, weights, thresholds) values (
  'v1', true, 'Initial weights from PRD §8.2; thresholds from PRD §8.5',
  '{"technical":30,"quality":10,"valuation":10,"news":20,"momentum":15,"market_context":15}',
  '{"buy_overall_min":65,"strong_buy_overall_min":80,"avoid_overall_max":35,"strong_sell_overall_max":25,
    "extended_above_sma50_pct":8,"rsi_overbought":70,"min_risk_reward":2,"stop_atr_multiple":1.5,
    "entry_atr_width":0.5,"risk_per_trade_pct":1,"min_daily_bars":200,"valuation_low_pctile":30,
    "valuation_high_pctile":70,"min_sector_peers":4,"news_half_life_days":7}'
);

insert into public.app_settings (key, value, description) values
  ('paper_initial_balance',          '1000000', 'Starting paper cash in INR per data mode'),
  ('llm_daily_budget_inr',           '100',     'Hard cap on estimated LLM spend per IST day'),
  ('analysis_min_interval_minutes',  '30',      'Minimum gap between AI analyses of one stock'),
  ('quote_staleness_minutes',        '20',      'Paper orders rejected if the latest price is older'),
  ('allow_orders_when_market_closed','false',   'If true, paper orders fill at last close and are labelled'),
  ('auto_paper_trade',               'false',   'Never auto-execute AI signals unless explicitly enabled'),
  ('news_relevance_threshold',       '0.5',     'Skip LLM sentiment for mentions below this relevance');

insert into public.paper_fee_schedules
  (name, is_active, brokerage_pct, brokerage_max, stt_buy_pct, stt_sell_pct, exchange_txn_pct, sebi_fee_pct, stamp_duty_buy_pct, gst_pct, notes)
values
  ('zero', true, 0, null, 0, 0, 0, 0, 0, 0, 'No charges. Active until the owner verifies a real schedule.'),
  ('india_delivery_estimate', false, 0, 20, 0.1, 0.1, 0.00297, 0.0001, 0.015, 18,
   'ESTIMATE for equity delivery (percent values). VERIFY against your broker contract note before activating.');
