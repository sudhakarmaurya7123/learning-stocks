-- mock: internal symbol (always valid). yahoo: unverified until Phase 3's live lookup.
insert into public.provider_symbols (provider, stock_id, provider_symbol, verified)
select 'mock', id, symbol, true from public.stocks where exchange = 'NSE';
insert into public.provider_symbols (provider, stock_id, provider_symbol, verified)
select 'yahoo', id, symbol || '.NS', false from public.stocks where exchange = 'NSE';

insert into public.provider_symbols (provider, market_id, provider_symbol, verified)
select 'mock', id, symbol, true from public.markets;
insert into public.provider_symbols (provider, market_id, provider_symbol, verified)
select 'yahoo', m.id, v.yahoo_symbol, false
  from (values ('NIFTY50', '^NSEI'), ('SENSEX', '^BSESN'), ('BANKNIFTY', '^NSEBANK'), ('NIFTYIT', '^CNXIT'),
               ('NIFTYPHARMA', '^CNXPHARMA'), ('NIFTYAUTO', '^CNXAUTO'), ('NIFTYFMCG', '^CNXFMCG'),
               ('NIFTYMETAL', '^CNXMETAL'), ('NIFTYREALTY', '^CNXREALTY'),
               ('NIFTYFINSERVICE', 'NIFTY_FIN_SERVICE.NS'), ('NIFTYENERGY', '^CNXENERGY'),
               ('INDIAVIX', '^INDIAVIX')) v(symbol, yahoo_symbol)
  join public.markets m on m.symbol = v.symbol;
