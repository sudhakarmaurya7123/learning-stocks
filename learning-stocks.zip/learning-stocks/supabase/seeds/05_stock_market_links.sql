insert into public.stock_market_links (stock_id, market_id, link_type)
select s.id, m.id, 'BENCHMARK' from public.stocks s cross join public.markets m
 where s.exchange = 'NSE' and m.symbol = 'NIFTY50';

insert into public.stock_market_links (stock_id, market_id, link_type)
select s.id, m.id, 'SECTOR_INDEX'
  from (values ('TCS', 'NIFTYIT'), ('INFY', 'NIFTYIT'), ('WIPRO', 'NIFTYIT'), ('HCLTECH', 'NIFTYIT'),
               ('HDFCBANK', 'BANKNIFTY'), ('ICICIBANK', 'BANKNIFTY'), ('SBIN', 'BANKNIFTY'),
               ('AXISBANK', 'BANKNIFTY'), ('KOTAKBANK', 'BANKNIFTY'),
               ('HDFCBANK', 'NIFTYFINSERVICE'), ('ICICIBANK', 'NIFTYFINSERVICE'), ('SBIN', 'NIFTYFINSERVICE'),
               ('AXISBANK', 'NIFTYFINSERVICE'), ('KOTAKBANK', 'NIFTYFINSERVICE'), ('BAJFINANCE', 'NIFTYFINSERVICE'),
               ('ITC', 'NIFTYFMCG'), ('HINDUNILVR', 'NIFTYFMCG'),
               ('MARUTI', 'NIFTYAUTO'), ('SUNPHARMA', 'NIFTYPHARMA'), ('RELIANCE', 'NIFTYENERGY')) v(stock, idx)
  join public.stocks s on s.symbol = v.stock and s.exchange = 'NSE'
  join public.markets m on m.symbol = v.idx;
