-- News-matching aliases. OWNER: verify. Precision beats recall: a wrong alias attaches unrelated news.
-- The company name (minus "Limited") and the symbol (3+ chars) are matched automatically; list only extra names.
-- An alias with no lowercase letters (RIL, SBI, L&T) matches case-sensitively; others ignore case.
-- No bare "VIX": it would match US (CBOE) VIX headlines.
update public.stocks s set aliases = v.aliases
  from (values
    ('RELIANCE',   array['RIL']),
    ('TCS',        array['Tata Consultancy']),
    ('SBIN',       array['SBI']),
    ('BHARTIARTL', array['Airtel']),
    ('LT',         array['L&T', 'Larsen and Toubro']),
    ('KOTAKBANK',  array['Kotak Bank']),
    ('MARUTI',     array['Maruti Suzuki', 'Maruti']),
    ('SUNPHARMA',  array['Sun Pharma']),
    ('HINDUNILVR', array['HUL']),
    ('ADANIPORTS', array['Adani Ports', 'APSEZ']),
    ('HCLTECH',    array['HCLTech', 'HCL Tech'])
  ) as v(symbol, aliases)
 where s.symbol = v.symbol and s.exchange = 'NSE';

update public.markets m set aliases = v.aliases
  from (values
    ('NIFTY50',         array['Nifty 50', 'Nifty50', 'Nifty']),
    ('SENSEX',          array['Sensex', 'BSE Sensex']),
    ('BANKNIFTY',       array['Nifty Bank', 'Bank Nifty']),
    ('NIFTYIT',         array['Nifty IT']),
    ('NIFTYPHARMA',     array['Nifty Pharma']),
    ('NIFTYAUTO',       array['Nifty Auto']),
    ('NIFTYFMCG',       array['Nifty FMCG']),
    ('NIFTYMETAL',      array['Nifty Metal']),
    ('NIFTYREALTY',     array['Nifty Realty']),
    ('NIFTYFINSERVICE', array['Nifty Financial Services', 'Nifty Fin Service', 'FinNifty', 'Fin Nifty']),
    ('NIFTYENERGY',     array['Nifty Energy']),
    ('INDIAVIX',        array['India VIX'])
  ) as v(symbol, aliases)
 where m.symbol = v.symbol;
